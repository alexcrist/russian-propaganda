Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483755447397412865",
  "text" : "RT @vj44: POTUS has instructed his team to prep an executive order banning job discrimination for fed employees on the basis of gender iden\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pride",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483746646573207553",
    "text" : "POTUS has instructed his team to prep an executive order banning job discrimination for fed employees on the basis of gender identity #pride",
    "id" : 483746646573207553,
    "created_at" : "2014-06-30 22:59:22 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 483755447397412865,
  "created_at" : "2014-06-30 23:34:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 68, 77 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "NotMyBossesBusiness",
      "indices" : [ 114, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Y9mOm2lXDd",
      "expanded_url" : "http:\/\/youtu.be\/dIWc9hypPdw",
      "display_url" : "youtu.be\/dIWc9hypPdw"
    } ]
  },
  "geo" : { },
  "id_str" : "483751573005557760",
  "text" : "\"Women should make personal health care decisions for themselves.\" \u2014@PressSec: http:\/\/t.co\/Y9mOm2lXDd #HobbyLobby #NotMyBossesBusiness",
  "id" : 483751573005557760,
  "created_at" : "2014-06-30 23:18:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreK4All",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Z9zwe9rdNC",
      "expanded_url" : "http:\/\/go.wh.gov\/iwWWxP",
      "display_url" : "go.wh.gov\/iwWWxP"
    } ]
  },
  "geo" : { },
  "id_str" : "483735531025473536",
  "text" : "Learn more about how we can empower our kids to bridge the word gap \u2192 http:\/\/t.co\/Z9zwe9rdNC #PreK4All",
  "id" : 483735531025473536,
  "created_at" : "2014-06-30 22:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/483726794479398912\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/3okYioNhkK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BraK9LeCYAAnOSU.png",
      "id_str" : "483726793644335104",
      "id" : 483726793644335104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BraK9LeCYAAnOSU.png",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3okYioNhkK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483726794479398912",
  "text" : "The U.S. \"condemns in the strongest possible terms this senseless act of terror against innocent youth.\" \u2014Obama http:\/\/t.co\/3okYioNhkK",
  "id" : 483726794479398912,
  "created_at" : "2014-06-30 21:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483714220534792192",
  "text" : "RT @WHLive: \"We have to do better for all wounded warriors. We have to do better for all our veterans.\" \u2014Obama nominating Bob McDonald for \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483714188419010560",
    "text" : "\"We have to do better for all wounded warriors. We have to do better for all our veterans.\" \u2014Obama nominating Bob McDonald for VA Secretary",
    "id" : 483714188419010560,
    "created_at" : "2014-06-30 20:50:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 483714220534792192,
  "created_at" : "2014-06-30 20:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483712941574074368",
  "text" : "\"We need to change the way the VA does business. We need to regain the trust of our veterans with a VA that is more effective.\" \u2014Obama",
  "id" : 483712941574074368,
  "created_at" : "2014-06-30 20:45:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483711660285526018",
  "text" : "\"Providing the highest quality care when our veterans need it\u2014that\u2019s your incentive.\" \u2014President Obama to Veterans Affairs staff",
  "id" : 483711660285526018,
  "created_at" : "2014-06-30 20:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483710880279183360",
  "text" : "\"Those responsible for manipulating or falsifying records at the VA\u2014and those who tolerated it\u2014are being held accountable.\" \u2014President Obama",
  "id" : 483710880279183360,
  "created_at" : "2014-06-30 20:37:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 69, 84 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/BksxJJarTr",
      "expanded_url" : "http:\/\/go.wh.gov\/HV6WQS",
      "display_url" : "go.wh.gov\/HV6WQS"
    } ]
  },
  "geo" : { },
  "id_str" : "483710235144908801",
  "text" : "Happening now: President Obama makes a personnel announcement at the @DeptVetAffairs \u2192 http:\/\/t.co\/BksxJJarTr",
  "id" : 483710235144908801,
  "created_at" : "2014-06-30 20:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/483709283646074880\/photo\/1",
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/eWfEYixadv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrZ7B6pCcAAuV3o.png",
      "id_str" : "483709282840375296",
      "id" : 483709282840375296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrZ7B6pCcAAuV3o.png",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eWfEYixadv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483709283646074880",
  "text" : "\"I extend my deepest &amp; heartfelt condolences to the families of Eyal Yifrach, Gilad Shaar &amp; Naftali Fraenkel\" \u2014Obama http:\/\/t.co\/eWfEYixadv",
  "id" : 483709283646074880,
  "created_at" : "2014-06-30 20:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483691847513292800",
  "text" : "\"We built this country together. We defended this country together. It makes us special. It makes us strong. It makes us Americans.\" \u2014Obama",
  "id" : 483691847513292800,
  "created_at" : "2014-06-30 19:21:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483691165670453248",
  "text" : "\u201CPass a bill. Solve a problem. Don\u2019t just say no on something everybody agrees needs to be done.\u201D \u2014Obama to the House GOP #ImmigrationReform",
  "id" : 483691165670453248,
  "created_at" : "2014-06-30 19:18:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483689899431034881",
  "text" : "\"Today, I\u2019m beginning a new effort to fix as much of our immigration system as I can on my own, without Congress.\" \u2014President Obama",
  "id" : 483689899431034881,
  "created_at" : "2014-06-30 19:13:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483689778764718081",
  "text" : "\"Their failure to pass a darn bill is bad for our security...our economy...and our future.\" \u2014Obama on the House GOP #ImmigrationReform",
  "id" : 483689778764718081,
  "created_at" : "2014-06-30 19:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483689546086088704",
  "text" : "\"It makes no sense. It\u2019s not on the level. It\u2019s just politics, plain and simple.\" \u2014Obama on the House GOP blocking #ImmigrationReform",
  "id" : 483689546086088704,
  "created_at" : "2014-06-30 19:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483688851853295616",
  "text" : "RT @WHLive: Obama: \"I sent a letter to Congressional leaders asking that they work with me to address the urgent humanitarian challenge on \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483688821448785920",
    "text" : "Obama: \"I sent a letter to Congressional leaders asking that they work with me to address the urgent humanitarian challenge on the border.\"",
    "id" : 483688821448785920,
    "created_at" : "2014-06-30 19:09:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 483688851853295616,
  "created_at" : "2014-06-30 19:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483688056420323328",
  "text" : "RT @WHLive: \"Republicans in the House...have refused to allow an up-or-down vote on...any legislation to fix our broken immigration system.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483687980427923456",
    "text" : "\"Republicans in the House...have refused to allow an up-or-down vote on...any legislation to fix our broken immigration system.\" \u2014Obama",
    "id" : 483687980427923456,
    "created_at" : "2014-06-30 19:06:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 483688056420323328,
  "created_at" : "2014-06-30 19:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 38, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/UzN82YaRJw",
      "expanded_url" : "http:\/\/go.wh.gov\/2EqciS",
      "display_url" : "go.wh.gov\/2EqciS"
    } ]
  },
  "geo" : { },
  "id_str" : "483687841424490497",
  "text" : "Watch live: President Obama speaks on #ImmigrationReform \u2192 http:\/\/t.co\/UzN82YaRJw",
  "id" : 483687841424490497,
  "created_at" : "2014-06-30 19:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/UzN82YaRJw",
      "expanded_url" : "http:\/\/go.wh.gov\/2EqciS",
      "display_url" : "go.wh.gov\/2EqciS"
    } ]
  },
  "geo" : { },
  "id_str" : "483673843404652547",
  "text" : "At 2:50pm ET, President Obama will deliver a statement on #ImmigrationReform. Watch \u2192 http:\/\/t.co\/UzN82YaRJw",
  "id" : 483673843404652547,
  "created_at" : "2014-06-30 18:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "NotMyBossesBusiness",
      "indices" : [ 108, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483653983123169280",
  "text" : "RT if you agree: Women\u2014not their bosses\u2014should be able to make their own health care decisions. #HobbyLobby #NotMyBossesBusiness",
  "id" : 483653983123169280,
  "created_at" : "2014-06-30 16:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 24, 33 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 92, 103 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483651477546991616",
  "text" : "RT @WHLive: Watch live: @PressSec discusses today's #HobbyLobby Supreme Court Ruling in the @WhiteHouse Briefing Room \u2192 http:\/\/t.co\/XLhcoqM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 12, 21 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 80, 91 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 40, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/XLhcoqMPWC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "483651426573635585",
    "text" : "Watch live: @PressSec discusses today's #HobbyLobby Supreme Court Ruling in the @WhiteHouse Briefing Room \u2192 http:\/\/t.co\/XLhcoqMPWC",
    "id" : 483651426573635585,
    "created_at" : "2014-06-30 16:41:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 483651477546991616,
  "created_at" : "2014-06-30 16:41:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 95, 104 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "483651099556347904",
  "text" : "\"President Obama believes...women should make personal health care decisions for themselves.\" \u2014@PressSec: http:\/\/t.co\/b4tqL3oo0v #HobbyLobby",
  "id" : 483651099556347904,
  "created_at" : "2014-06-30 16:39:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "483283767725813760",
  "text" : "President Obama's Weekly Address: Focusing on the Economic Priorities for the Middle Class Nationwide. Watch \u2192 http:\/\/t.co\/DPC7l5mqXY",
  "id" : 483283767725813760,
  "created_at" : "2014-06-29 16:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "483268671024795649",
  "text" : "\"Today, over the past 51 months, our businesses have created 9.4 million new jobs.\" \u2014President Obama: http:\/\/t.co\/DPC7l5mqXY",
  "id" : 483268671024795649,
  "created_at" : "2014-06-29 15:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "483258615780737025",
  "text" : "\"Rather than more tax breaks for millionaires, let\u2019s give more tax breaks to help working families\" \u2014President Obama: http:\/\/t.co\/DPC7l5mqXY",
  "id" : 483258615780737025,
  "created_at" : "2014-06-29 14:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "483248598755188736",
  "text" : "In this week\u2019s address, the President discussed his trip to Minneapolis where he met a working mother named Rebekah: http:\/\/t.co\/DPC7l5mqXY",
  "id" : 483248598755188736,
  "created_at" : "2014-06-29 14:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/4Pd6N5Qhkm",
      "expanded_url" : "http:\/\/wh.gov\/l6LmZ",
      "display_url" : "wh.gov\/l6LmZ"
    } ]
  },
  "geo" : { },
  "id_str" : "483051015269138432",
  "text" : "\"Ramadan Kareem.\" \u2014President Obama extends his best wishes to the Muslim community on the beginning of Ramadan: http:\/\/t.co\/4Pd6N5Qhkm",
  "id" : 483051015269138432,
  "created_at" : "2014-06-29 00:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "482981791112761346",
  "text" : "\"Republicans in Congress keep blocking or voting down almost every serious idea to strengthen the middle class.\" http:\/\/t.co\/DPC7l5mqXY",
  "id" : 482981791112761346,
  "created_at" : "2014-06-28 20:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "482971704889602049",
  "text" : "Obama: \"We know from our history that our economy doesn\u2019t grow from the top-down, it grows from the middle-out.\" http:\/\/t.co\/DPC7l5mqXY",
  "id" : 482971704889602049,
  "created_at" : "2014-06-28 19:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "482961728955617281",
  "text" : "\"We are stronger as a nation when we offer a fair shot to every American.\" \u2014President Obama: http:\/\/t.co\/DPC7l5mqXY #OpportunityForAll",
  "id" : 482961728955617281,
  "created_at" : "2014-06-28 19:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DPC7l5mqXY",
      "expanded_url" : "http:\/\/go.wh.gov\/fan2Q2",
      "display_url" : "go.wh.gov\/fan2Q2"
    } ]
  },
  "geo" : { },
  "id_str" : "482953135363588097",
  "text" : "\"We do better when the middle class does better. That\u2019s the American way\" \u2014President Obama: http:\/\/t.co\/DPC7l5mqXY #OpportunityForAll",
  "id" : 482953135363588097,
  "created_at" : "2014-06-28 18:26:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482551157890760705",
  "text" : "RT @PressSec: POTUS: \"Cynicism is a choice, and hope is a better choice. Every day, I am lucky enough to receive a thousand acts of hope.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DayInTheLife",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482550701457829888",
    "text" : "POTUS: \"Cynicism is a choice, and hope is a better choice. Every day, I am lucky enough to receive a thousand acts of hope.\" #DayInTheLife",
    "id" : 482550701457829888,
    "created_at" : "2014-06-27 15:47:07 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 482551157890760705,
  "created_at" : "2014-06-27 15:48:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482551014630113280",
  "text" : "\"I'm never going to get cynical. I'm going to stay hopeful, and I hope you do, too.\" \u2014President Obama",
  "id" : 482551014630113280,
  "created_at" : "2014-06-27 15:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ccgeYlGmMC",
      "expanded_url" : "http:\/\/wh.gov\/year-of-action",
      "display_url" : "wh.gov\/year-of-action"
    } ]
  },
  "geo" : { },
  "id_str" : "482550585737347075",
  "text" : "\"Don't get cynical. Despite all of the frustrations, America is making progress\" \u2014President Obama: http:\/\/t.co\/ccgeYlGmMC #OpportunityForAll",
  "id" : 482550585737347075,
  "created_at" : "2014-06-27 15:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482549094335127552",
  "text" : "\"If you\u2019re mad at me for helping people on my own then join me and we\u2019ll do it together.\" \u2014President Obama to Republicans and Congress",
  "id" : 482549094335127552,
  "created_at" : "2014-06-27 15:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482547929727922176",
  "text" : "\"We can't afford to wait for Congress...and that's why I'm going ahead without them when I can.\" \u2014President Obama",
  "id" : 482547929727922176,
  "created_at" : "2014-06-27 15:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482547674051543040",
  "text" : "RT @WHLive: \"Sometimes...they just don't know what folks are going through.\" \u2014Obama on Republicans in Congress who block steps to help the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482547552194412544",
    "text" : "\"Sometimes...they just don't know what folks are going through.\" \u2014Obama on Republicans in Congress who block steps to help the middle class",
    "id" : 482547552194412544,
    "created_at" : "2014-06-27 15:34:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 482547674051543040,
  "created_at" : "2014-06-27 15:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 84, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482546129016340480",
  "text" : "\"We\u2019re fighting to guarantee every child a world-class education.\" \u2014President Obama #CollegeOpportunity",
  "id" : 482546129016340480,
  "created_at" : "2014-06-27 15:28:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482545762199687168",
  "text" : "\"You're the reason I ran for President, because those stories are stories I've lived.\" \u2014President Obama in MN #OpportunityForAll",
  "id" : 482545762199687168,
  "created_at" : "2014-06-27 15:27:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "482544347574177793",
  "text" : "Happening now: President Obama speaks on the economy in Minneapolis. Watch: http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 482544347574177793,
  "created_at" : "2014-06-27 15:21:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/482508940149026817\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/VDpPLkEpDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrI3UedCUAAi25c.jpg",
      "id_str" : "482508934993825792",
      "id" : 482508934993825792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrI3UedCUAAi25c.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VDpPLkEpDA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uNT8gTxjDI",
      "expanded_url" : "http:\/\/go.wh.gov\/1DHv9G",
      "display_url" : "go.wh.gov\/1DHv9G"
    } ]
  },
  "geo" : { },
  "id_str" : "482508940149026817",
  "text" : "\"You guys are the reason I ran. You\u2019re who I\u2019m thinking about every single day.\" \u2014Obama: http:\/\/t.co\/uNT8gTxjDI http:\/\/t.co\/VDpPLkEpDA",
  "id" : 482508940149026817,
  "created_at" : "2014-06-27 13:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/glAmjmwN2f",
      "expanded_url" : "https:\/\/vine.co\/v\/MtEFh7W7uhM",
      "display_url" : "vine.co\/v\/MtEFh7W7uhM"
    } ]
  },
  "geo" : { },
  "id_str" : "482331256919568385",
  "text" : "President Obama stops in for a cone at the Grand Ole Creamery in St. Paul, Minnesota \u2192 https:\/\/t.co\/glAmjmwN2f \uD83C\uDF66\uD83C\uDF66\uD83C\uDF66",
  "id" : 482331256919568385,
  "created_at" : "2014-06-27 01:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/4O7ux1zTik",
      "expanded_url" : "http:\/\/youtu.be\/9U_7kIZ6wm4",
      "display_url" : "youtu.be\/9U_7kIZ6wm4"
    } ]
  },
  "geo" : { },
  "id_str" : "482325385729015808",
  "text" : "\"We can make life a little better for American families who are doing their best.\" \u2014President Obama: http:\/\/t.co\/4O7ux1zTik",
  "id" : 482325385729015808,
  "created_at" : "2014-06-27 00:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 20, 33 ],
      "id_str" : "18023868",
      "id" : 18023868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482272709523804160",
  "text" : "RT @PressSec: Today @MassGovernor signed a law raising the state's $8 per hour minimum wage to $11 per hour by 2017. #RaiseTheWage http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Baker",
        "screen_name" : "MassGovernor",
        "indices" : [ 6, 19 ],
        "id_str" : "18023868",
        "id" : 18023868
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/482272340034600960\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/XNC4I6uBKD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFgIwYCQAEJ7pu.png",
        "id_str" : "482272338646286337",
        "id" : 482272338646286337,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFgIwYCQAEJ7pu.png",
        "sizes" : [ {
          "h" : 112,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 885
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 885
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XNC4I6uBKD"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482272340034600960",
    "text" : "Today @MassGovernor signed a law raising the state's $8 per hour minimum wage to $11 per hour by 2017. #RaiseTheWage http:\/\/t.co\/XNC4I6uBKD",
    "id" : 482272340034600960,
    "created_at" : "2014-06-26 21:21:00 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 482272709523804160,
  "created_at" : "2014-06-26 21:22:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 22, 35 ],
      "id_str" : "18023868",
      "id" : 18023868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaisetheWage",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482267262154731520",
  "text" : "RT @vj44: Congrats to @MassGovernor on raising the minimum wage to $11 by 2017. 13th state to #RaisetheWage, including MN where POTUS is to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Baker",
        "screen_name" : "MassGovernor",
        "indices" : [ 12, 25 ],
        "id_str" : "18023868",
        "id" : 18023868
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaisetheWage",
        "indices" : [ 84, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482263549796831233",
    "text" : "Congrats to @MassGovernor on raising the minimum wage to $11 by 2017. 13th state to #RaisetheWage, including MN where POTUS is today!",
    "id" : 482263549796831233,
    "created_at" : "2014-06-26 20:46:04 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 482267262154731520,
  "created_at" : "2014-06-26 21:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482262423186182144",
  "text" : "\"Cynicism is popular these days, but hope's better.\" \u2014President Obama",
  "id" : 482262423186182144,
  "created_at" : "2014-06-26 20:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482261684724436994",
  "text" : "\"You guys are the reason I ran. You\u2019re who I\u2019m thinking about every single day\" \u2014President Obama to Americans working hard to make ends meet",
  "id" : 482261684724436994,
  "created_at" : "2014-06-26 20:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482259853088681984",
  "text" : "RT @WHLive: \u201CThe deficit has come down by more than half since I came into office.\u201D \u2014President Obama at a Minneapolis town hall: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7QlV2qtocP",
        "expanded_url" : "http:\/\/go.wh.gov\/6qN5mC",
        "display_url" : "go.wh.gov\/6qN5mC"
      } ]
    },
    "geo" : { },
    "id_str" : "482259818410156032",
    "text" : "\u201CThe deficit has come down by more than half since I came into office.\u201D \u2014President Obama at a Minneapolis town hall: http:\/\/t.co\/7QlV2qtocP",
    "id" : 482259818410156032,
    "created_at" : "2014-06-26 20:31:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 482259853088681984,
  "created_at" : "2014-06-26 20:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482258050636845056",
  "text" : "RT @WHLive: \u201CYour child is less likely to get asthma.\u201D \u2014President Obama on the benefits of recently-proposed clean power plant standards #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482257980889767936",
    "text" : "\u201CYour child is less likely to get asthma.\u201D \u2014President Obama on the benefits of recently-proposed clean power plant standards #ActOnClimate",
    "id" : 482257980889767936,
    "created_at" : "2014-06-26 20:23:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 482258050636845056,
  "created_at" : "2014-06-26 20:24:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/482256112272818176\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/be4VGnq8Yq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFRYOJCUAA9HQQ.jpg",
      "id_str" : "482256111660060672",
      "id" : 482256111660060672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFRYOJCUAA9HQQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/be4VGnq8Yq"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "FamiliesSucceed",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482256112272818176",
  "text" : "\u201CIf you\u2019re doing the same job, you should make the same pay. Period.\u201D \u2014President Obama #EqualPay #FamiliesSucceed http:\/\/t.co\/be4VGnq8Yq",
  "id" : 482256112272818176,
  "created_at" : "2014-06-26 20:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/482255691567333376\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ZdK6t1X7tK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFQ_u6CIAAFMgh.jpg",
      "id_str" : "482255690958774272",
      "id" : 482255690958774272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFQ_u6CIAAFMgh.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZdK6t1X7tK"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482255691567333376",
  "text" : "\u201CWhen companies adopt family-friendly policies, their productivity goes up.\u201D \u2014President Obama #FamiliesSucceed http:\/\/t.co\/ZdK6t1X7tK",
  "id" : 482255691567333376,
  "created_at" : "2014-06-26 20:14:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482254824952459266",
  "text" : "\u201CPeggy and Joan\u2026I\u2019m always rooting for them.\u201D \u2014Obama on how the issues these Mad Men characters face remind him of his grandmother #EqualPay",
  "id" : 482254824952459266,
  "created_at" : "2014-06-26 20:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482250643118489602",
  "text" : "\u201CYou don\u2019t play as well if you\u2019ve only got half the team.\u201D \u2014President Obama on why we need more #WomenInSTEM",
  "id" : 482250643118489602,
  "created_at" : "2014-06-26 19:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInSTEM",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482249917046738944",
  "text" : "\"We are a nation of inventors &amp; tinkerers, and we expand the boundaries of what\u2019s possible through science.\" \u2014President Obama #InvestInSTEM",
  "id" : 482249917046738944,
  "created_at" : "2014-06-26 19:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482248321197568000",
  "text" : "RT @WHLive: \u201CI wasn't born into a wealthy family. I\u2019m only here because of my education.\u201D \u2014Obama on why he's fighting to make college more \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482248264348336128",
    "text" : "\u201CI wasn't born into a wealthy family. I\u2019m only here because of my education.\u201D \u2014Obama on why he's fighting to make college more affordable",
    "id" : 482248264348336128,
    "created_at" : "2014-06-26 19:45:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 482248321197568000,
  "created_at" : "2014-06-26 19:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482247077712236544",
  "text" : "\u201CThis is the only advanced country that tolerates something like this.\u201D \u2014President Obama on why Congress needs to act to reduce gun violence",
  "id" : 482247077712236544,
  "created_at" : "2014-06-26 19:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/482245313533845505\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/5FSdeWmTwZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFHjplCEAES0yf.png",
      "id_str" : "482245312887525377",
      "id" : 482245312887525377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFHjplCEAES0yf.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/5FSdeWmTwZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482245313533845505",
  "text" : "\u201CThat is the central challenge that drives me every single day.\u201D \u2014Obama on expanding opportunity for more Americans http:\/\/t.co\/5FSdeWmTwZ",
  "id" : 482245313533845505,
  "created_at" : "2014-06-26 19:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 76, 85 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USMNT",
      "indices" : [ 124, 130 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482243919426899968",
  "text" : "\u201CWe were in the toughest grouping, and we got through.\u201D \u2014President Obama on @USSoccer advancing out of the \u201CGroup of Death\u201D #USMNT #WorldCup",
  "id" : 482243919426899968,
  "created_at" : "2014-06-26 19:28:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/z2c3yBDS82",
      "expanded_url" : "http:\/\/go.wh.gov\/6qN5mC",
      "display_url" : "go.wh.gov\/6qN5mC"
    } ]
  },
  "geo" : { },
  "id_str" : "482242234839216128",
  "text" : "Starting soon: President Obama hosts a town hall in Minneapolis. Watch \u2192 http:\/\/t.co\/z2c3yBDS82 #OpportunityForAll",
  "id" : 482242234839216128,
  "created_at" : "2014-06-26 19:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482240098323693568",
  "text" : "RT @PressSec: Just enjoyed a \"Jucy Lucy\" [sic] at Matt's Bar. Delicious. Potus enjoyed his too. Now, the town hall at Minnehaha Park is abt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482239939392700416",
    "text" : "Just enjoyed a \"Jucy Lucy\" [sic] at Matt's Bar. Delicious. Potus enjoyed his too. Now, the town hall at Minnehaha Park is abt to start.",
    "id" : 482239939392700416,
    "created_at" : "2014-06-26 19:12:15 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 482240098323693568,
  "created_at" : "2014-06-26 19:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 12, 21 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IStillBelieve",
      "indices" : [ 76, 90 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482237522664505344",
  "text" : "Congrats to @USSoccer on advancing to the next round. Tough loss today, but #IStillBelieve. #USMNT #WorldCup \u2013bo",
  "id" : 482237522664505344,
  "created_at" : "2014-06-26 19:02:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482228522220412928",
  "text" : "RT @PressSec: Just landed in Minnesota w Potus.  First up, lunch with a working mom who wrote him a letter abt the challenges facing workin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482217801906536448",
    "text" : "Just landed in Minnesota w Potus.  First up, lunch with a working mom who wrote him a letter abt the challenges facing working families.",
    "id" : 482217801906536448,
    "created_at" : "2014-06-26 17:44:17 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 482228522220412928,
  "created_at" : "2014-06-26 18:26:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Mills",
      "screen_name" : "dougmillsnyt",
      "indices" : [ 3, 16 ],
      "id_str" : "87761810",
      "id" : 87761810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldcup",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482215677042753536",
  "text" : "RT @dougmillsnyt: President Obama watches the USA vs Germany World Cup game aboard Air Force One enroute to Minneapolis. #worldcup http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dougmillsnyt\/status\/482215333411831808\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/bK2OGz5Xnd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEsSYxCMAAt0UL.jpg",
        "id_str" : "482215329502736384",
        "id" : 482215329502736384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEsSYxCMAAt0UL.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1431,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/bK2OGz5Xnd"
      } ],
      "hashtags" : [ {
        "text" : "worldcup",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482215333411831808",
    "text" : "President Obama watches the USA vs Germany World Cup game aboard Air Force One enroute to Minneapolis. #worldcup http:\/\/t.co\/bK2OGz5Xnd",
    "id" : 482215333411831808,
    "created_at" : "2014-06-26 17:34:29 +0000",
    "user" : {
      "name" : "Doug Mills",
      "screen_name" : "dougmillsnyt",
      "protected" : false,
      "id_str" : "87761810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388914843\/mills_normal.jpg",
      "id" : 87761810,
      "verified" : true
    }
  },
  "id" : 482215677042753536,
  "created_at" : "2014-06-26 17:35:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/482211192954699777\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/cCgx8JRzCv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEohkXCUAEweOL.jpg",
      "id_str" : "482211192266444801",
      "id" : 482211192266444801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEohkXCUAEweOL.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/cCgx8JRzCv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/LvulmC5sHi",
      "expanded_url" : "http:\/\/go.wh.gov\/nKUYud",
      "display_url" : "go.wh.gov\/nKUYud"
    } ]
  },
  "geo" : { },
  "id_str" : "482211192954699777",
  "text" : "\u2708 Wheels up \u2708: President Obama's headed to MN to visit Rebekah\u2014a mom who wrote him a letter: http:\/\/t.co\/LvulmC5sHi http:\/\/t.co\/cCgx8JRzCv",
  "id" : 482211192954699777,
  "created_at" : "2014-06-26 17:18:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/482187813329186816\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/YnsQO3LQIc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEOwkkCQAArlkJ.jpg",
      "id_str" : "482182862716682240",
      "id" : 482182862716682240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEOwkkCQAArlkJ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/YnsQO3LQIc"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/RxPSPdYBLA",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "482187813329186816",
  "text" : "For the sake of our kids and our future, President Obama's taking steps to #ActOnClimate \u2192 http:\/\/t.co\/RxPSPdYBLA http:\/\/t.co\/YnsQO3LQIc",
  "id" : 482187813329186816,
  "created_at" : "2014-06-26 15:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 95, 104 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsDoThis",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "USAvsGER",
      "indices" : [ 106, 115 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482186822249095171",
  "text" : "RT @VP: Vice President Biden believes.\nTim Howard believes.\nDo you believe?\n\n#LetsDoThis, team @ussoccer. #USAvsGER #USMNT http:\/\/t.co\/wfUp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 87, 96 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/482186407881216001\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/wfUpHliFsl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrER-vsCcAI8_pO.png",
        "id_str" : "482186404756090882",
        "id" : 482186404756090882,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrER-vsCcAI8_pO.png",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 906,
          "resize" : "fit",
          "w" : 1295
        } ],
        "display_url" : "pic.twitter.com\/wfUpHliFsl"
      } ],
      "hashtags" : [ {
        "text" : "LetsDoThis",
        "indices" : [ 69, 80 ]
      }, {
        "text" : "USAvsGER",
        "indices" : [ 98, 107 ]
      }, {
        "text" : "USMNT",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482186407881216001",
    "text" : "Vice President Biden believes.\nTim Howard believes.\nDo you believe?\n\n#LetsDoThis, team @ussoccer. #USAvsGER #USMNT http:\/\/t.co\/wfUpHliFsl",
    "id" : 482186407881216001,
    "created_at" : "2014-06-26 15:39:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 482186822249095171,
  "created_at" : "2014-06-26 15:41:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/58rziqpL0N",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/06\/26\/business\/ikea-plans-to-increase-minimum-hourly-pay.html",
      "display_url" : "nytimes.com\/2014\/06\/26\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482182590003433472",
  "text" : "RT @Lehrich44: IKEA: raising minimum wage \"a win-win-win for our co-workers, our customers and our stores\" http:\/\/t.co\/58rziqpL0N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/58rziqpL0N",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/06\/26\/business\/ikea-plans-to-increase-minimum-hourly-pay.html",
        "display_url" : "nytimes.com\/2014\/06\/26\/bus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482182421052661760",
    "text" : "IKEA: raising minimum wage \"a win-win-win for our co-workers, our customers and our stores\" http:\/\/t.co\/58rziqpL0N",
    "id" : 482182421052661760,
    "created_at" : "2014-06-26 15:23:42 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 482182590003433472,
  "created_at" : "2014-06-26 15:24:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 3, 12 ],
      "id_str" : "7563792",
      "id" : 7563792
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "USAvGER",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "LetsDoThis",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482174207263268865",
  "text" : "RT @ussoccer: The @WhiteHouse is watching today and we can't wait to see the support around the #USA!  #USAvGER #LetsDoThis http:\/\/t.co\/6fK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ussoccer\/status\/482133574175703040\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/6fKPXHuK6J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrDh7kyIEAAqrLg.png",
        "id_str" : "482133573731094528",
        "id" : 482133573731094528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrDh7kyIEAAqrLg.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6fKPXHuK6J"
      } ],
      "hashtags" : [ {
        "text" : "USA",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "USAvGER",
        "indices" : [ 89, 97 ]
      }, {
        "text" : "LetsDoThis",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482133574175703040",
    "text" : "The @WhiteHouse is watching today and we can't wait to see the support around the #USA!  #USAvGER #LetsDoThis http:\/\/t.co\/6fKPXHuK6J",
    "id" : 482133574175703040,
    "created_at" : "2014-06-26 12:09:36 +0000",
    "user" : {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "protected" : false,
      "id_str" : "7563792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704355346622586884\/oGZUl3xk_normal.jpg",
      "id" : 7563792,
      "verified" : true
    }
  },
  "id" : 482174207263268865,
  "created_at" : "2014-06-26 14:51:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482163765451190273",
  "text" : "RT @pfeiffer44: The House Republicans deciding to sue the President for doing his job tells you how little of their own job they have done \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482152271304982528",
    "text" : "The House Republicans deciding to sue the President for doing his job tells you how little of their own job they have done this year",
    "id" : 482152271304982528,
    "created_at" : "2014-06-26 13:23:54 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 482163765451190273,
  "created_at" : "2014-06-26 14:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IKEA USA News",
      "screen_name" : "IKEAUSANews",
      "indices" : [ 19, 31 ],
      "id_str" : "2294627450",
      "id" : 2294627450
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/VaKR6tFhhw",
      "expanded_url" : "http:\/\/wapo.st\/1mg1uO6",
      "display_url" : "wapo.st\/1mg1uO6"
    } ]
  },
  "geo" : { },
  "id_str" : "482158778813796352",
  "text" : "Great news: Today, @IkeaUSANews announced it will raise its minimum wage to more than $10\/hour by 2015: http:\/\/t.co\/VaKR6tFhhw #RaiseTheWage",
  "id" : 482158778813796352,
  "created_at" : "2014-06-26 13:49:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IKEA USA News",
      "screen_name" : "IKEAUSANews",
      "indices" : [ 3, 15 ],
      "id_str" : "2294627450",
      "id" : 2294627450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482152481376698368",
  "text" : "RT @IKEAUSANews: In Jan 2015, IKEA will adopt a new min hourly wage for co-workers\u2013new average min is $10.76\u2013$3.51 over nat\u2019l min wage http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/IvlF3kypTf",
        "expanded_url" : "http:\/\/bit.ly\/1qKIL4L",
        "display_url" : "bit.ly\/1qKIL4L"
      } ]
    },
    "geo" : { },
    "id_str" : "482138243652399104",
    "text" : "In Jan 2015, IKEA will adopt a new min hourly wage for co-workers\u2013new average min is $10.76\u2013$3.51 over nat\u2019l min wage http:\/\/t.co\/IvlF3kypTf",
    "id" : 482138243652399104,
    "created_at" : "2014-06-26 12:28:09 +0000",
    "user" : {
      "name" : "IKEA USA News",
      "screen_name" : "IKEAUSANews",
      "protected" : false,
      "id_str" : "2294627450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423844902531641344\/6nRXFXRF_normal.png",
      "id" : 2294627450,
      "verified" : true
    }
  },
  "id" : 482152481376698368,
  "created_at" : "2014-06-26 13:24:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481915505356570626\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ClZnhXMWIg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrAbmSdCIAAisy5.jpg",
      "id_str" : "481915504731234304",
      "id" : 481915504731234304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrAbmSdCIAAisy5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ClZnhXMWIg"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481915505356570626",
  "text" : "President Obama's climate plan will protect our health by preventing asthma attacks and heart attacks. #ActOnClimate http:\/\/t.co\/ClZnhXMWIg",
  "id" : 481915505356570626,
  "created_at" : "2014-06-25 21:43:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/dACzpN5IUa",
      "expanded_url" : "http:\/\/petitions.whitehouse.gov",
      "display_url" : "petitions.whitehouse.gov"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/YBilRYSATk",
      "expanded_url" : "http:\/\/wh.gov\/l6fCO",
      "display_url" : "wh.gov\/l6fCO"
    } ]
  },
  "geo" : { },
  "id_str" : "481903385226924035",
  "text" : "RT @Lubin44: We just made http:\/\/t.co\/dACzpN5IUa more user-friendly than ever. Check it out: http:\/\/t.co\/YBilRYSATk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/dACzpN5IUa",
        "expanded_url" : "http:\/\/petitions.whitehouse.gov",
        "display_url" : "petitions.whitehouse.gov"
      }, {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/YBilRYSATk",
        "expanded_url" : "http:\/\/wh.gov\/l6fCO",
        "display_url" : "wh.gov\/l6fCO"
      } ]
    },
    "geo" : { },
    "id_str" : "481892215170793472",
    "text" : "We just made http:\/\/t.co\/dACzpN5IUa more user-friendly than ever. Check it out: http:\/\/t.co\/YBilRYSATk",
    "id" : 481892215170793472,
    "created_at" : "2014-06-25 20:10:31 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 481903385226924035,
  "created_at" : "2014-06-25 20:54:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 34, 45 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 59, 68 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481889296144953344",
  "text" : "RT @PressSec: Josh here (formerly @jearnest44) taking over @PressSec. To kick things off, I guess I'll take some q's. What's going on? #Ask\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "jearnest44",
        "indices" : [ 20, 31 ],
        "id_str" : "369238541",
        "id" : 369238541
      }, {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 45, 54 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481889152372596738",
    "text" : "Josh here (formerly @jearnest44) taking over @PressSec. To kick things off, I guess I'll take some q's. What's going on? #AskPressSec",
    "id" : 481889152372596738,
    "created_at" : "2014-06-25 19:58:21 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 481889296144953344,
  "created_at" : "2014-06-25 19:58:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarkeyMemo",
      "screen_name" : "MARKEYMEMO",
      "indices" : [ 3, 14 ],
      "id_str" : "3047090620",
      "id" : 3047090620
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarkeyMemo\/status\/481887718373617665\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/3bZvFtr1r9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrACU29CUAAWsyX.jpg",
      "id_str" : "481887717500801024",
      "id" : 481887717500801024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrACU29CUAAWsyX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3bZvFtr1r9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 18, 31 ]
    }, {
      "text" : "health",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481887800057692161",
  "text" : "RT @MarkeyMemo: I #ActOnClimate to create jobs, protect our #health, economy &amp; future http:\/\/t.co\/3bZvFtr1r9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkeyMemo\/status\/481887718373617665\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/3bZvFtr1r9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrACU29CUAAWsyX.jpg",
        "id_str" : "481887717500801024",
        "id" : 481887717500801024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrACU29CUAAWsyX.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3bZvFtr1r9"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      }, {
        "text" : "health",
        "indices" : [ 44, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481887718373617665",
    "text" : "I #ActOnClimate to create jobs, protect our #health, economy &amp; future http:\/\/t.co\/3bZvFtr1r9",
    "id" : 481887718373617665,
    "created_at" : "2014-06-25 19:52:39 +0000",
    "user" : {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "protected" : false,
      "id_str" : "21406834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739889609262411780\/qDeJ7rdE_normal.jpg",
      "id" : 21406834,
      "verified" : true
    }
  },
  "id" : 481887800057692161,
  "created_at" : "2014-06-25 19:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActonClimate",
      "indices" : [ 66, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481873064880140288",
  "text" : "RT @USDA: Farmers already feel effects of climate change. We must #ActonClimate for today's producers &amp; for our next generation http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDA\/status\/481866230593097733\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/mNVRwcvpTn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_uyDkCMAAGelw.jpg",
        "id_str" : "481866228869246976",
        "id" : 481866228869246976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_uyDkCMAAGelw.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/mNVRwcvpTn"
      } ],
      "hashtags" : [ {
        "text" : "ActonClimate",
        "indices" : [ 56, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481866230593097733",
    "text" : "Farmers already feel effects of climate change. We must #ActonClimate for today's producers &amp; for our next generation http:\/\/t.co\/mNVRwcvpTn",
    "id" : 481866230593097733,
    "created_at" : "2014-06-25 18:27:16 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 481873064880140288,
  "created_at" : "2014-06-25 18:54:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481865732691886080",
  "text" : "President Obama's climate policies from the past year will save consumers more than $60 billion in energy costs through 2030. #ActOnClimate",
  "id" : 481865732691886080,
  "created_at" : "2014-06-25 18:25:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Champion",
      "screen_name" : "SamChampion",
      "indices" : [ 48, 60 ],
      "id_str" : "21232507",
      "id" : 21232507
    }, {
      "name" : "Fabien Cousteau",
      "screen_name" : "FCousteau",
      "indices" : [ 67, 77 ],
      "id_str" : "17758502",
      "id" : 17758502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/pJ5PHEPSQf",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "481858730058059777",
  "text" : "At 2pm ET, dive into a #WeTheGeeks Hangout with @SamChampion &amp; @FCousteau on oceans and climate change: http:\/\/t.co\/pJ5PHEPSQf #ActOnClimate",
  "id" : 481858730058059777,
  "created_at" : "2014-06-25 17:57:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481845648204263425\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zq7CRug8jF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_cEDwCYAEXk3t.jpg",
      "id_str" : "481845647436308481",
      "id" : 481845647436308481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_cEDwCYAEXk3t.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zq7CRug8jF"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481845648204263425",
  "text" : "FACT: President Obama's acting to cut nearly 3 billion tons of carbon pollution between 2020 and 2025. #ActOnClimate http:\/\/t.co\/zq7CRug8jF",
  "id" : 481845648204263425,
  "created_at" : "2014-06-25 17:05:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481830221528965120\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ymi3cypUMy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_OCF6CQAA1gXF.jpg",
      "id_str" : "481830220492587008",
      "id" : 481830220492587008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_OCF6CQAA1gXF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ymi3cypUMy"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/l5sVvDgeUP",
      "expanded_url" : "http:\/\/go.wh.gov\/4EqJLU",
      "display_url" : "go.wh.gov\/4EqJLU"
    } ]
  },
  "geo" : { },
  "id_str" : "481830221528965120",
  "text" : "For the sake of our kids and our planet, President Obama's taking steps to #ActOnClimate \u2192 http:\/\/t.co\/l5sVvDgeUP http:\/\/t.co\/Ymi3cypUMy",
  "id" : 481830221528965120,
  "created_at" : "2014-06-25 16:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/481821958984974336\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/XZWNvaXZKg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_GhFAIQAAORAh.jpg",
      "id_str" : "481821956732633088",
      "id" : 481821956732633088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_GhFAIQAAORAh.jpg",
      "sizes" : [ {
        "h" : 944,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 944,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XZWNvaXZKg"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481823852654129153",
  "text" : "RT @PAniskoff44: I #ActOnClimate because there should\u2019ve been more snow this day, at 14,000 feet: http:\/\/t.co\/XZWNvaXZKg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/481821958984974336\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/XZWNvaXZKg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_GhFAIQAAORAh.jpg",
        "id_str" : "481821956732633088",
        "id" : 481821956732633088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_GhFAIQAAORAh.jpg",
        "sizes" : [ {
          "h" : 944,
          "resize" : "fit",
          "w" : 944
        }, {
          "h" : 944,
          "resize" : "fit",
          "w" : 944
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XZWNvaXZKg"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481821958984974336",
    "text" : "I #ActOnClimate because there should\u2019ve been more snow this day, at 14,000 feet: http:\/\/t.co\/XZWNvaXZKg",
    "id" : 481821958984974336,
    "created_at" : "2014-06-25 15:31:21 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 481823852654129153,
  "created_at" : "2014-06-25 15:38:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481818831216578560",
  "text" : "RT @ErnestMoniz: I #ActOnClimate because we have a moral obligation to leave a cleaner, safer planet behind for our children. Why do you?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481815105156292609",
    "text" : "I #ActOnClimate because we have a moral obligation to leave a cleaner, safer planet behind for our children. Why do you?",
    "id" : 481815105156292609,
    "created_at" : "2014-06-25 15:04:07 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 481818831216578560,
  "created_at" : "2014-06-25 15:18:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "MountRainierNPS",
      "screen_name" : "MountRainierNPS",
      "indices" : [ 110, 126 ],
      "id_str" : "316742293",
      "id" : 316742293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481816661394464768",
  "text" : "RT @SecretaryJewell: I #ActOnClimate so that future generations can enjoy America's amazing public lands like @MountRainierNPS. SJ http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MountRainierNPS",
        "screen_name" : "MountRainierNPS",
        "indices" : [ 89, 105 ],
        "id_str" : "316742293",
        "id" : 316742293
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SecretaryJewell\/status\/481814237699133440\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/iwbseuhWVh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq-_fpNIQAAFknB.jpg",
        "id_str" : "481814235509702656",
        "id" : 481814235509702656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq-_fpNIQAAFknB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1800
        } ],
        "display_url" : "pic.twitter.com\/iwbseuhWVh"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481814237699133440",
    "text" : "I #ActOnClimate so that future generations can enjoy America's amazing public lands like @MountRainierNPS. SJ http:\/\/t.co\/iwbseuhWVh",
    "id" : 481814237699133440,
    "created_at" : "2014-06-25 15:00:40 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 481816661394464768,
  "created_at" : "2014-06-25 15:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/l5sVvDgeUP",
      "expanded_url" : "http:\/\/go.wh.gov\/4EqJLU",
      "display_url" : "go.wh.gov\/4EqJLU"
    } ]
  },
  "geo" : { },
  "id_str" : "481809324738879489",
  "text" : "One year ago, President Obama announced his Climate Action Plan. Check out the progress we've made to #ActOnClimate \u2192 http:\/\/t.co\/l5sVvDgeUP",
  "id" : 481809324738879489,
  "created_at" : "2014-06-25 14:41:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 37, 42 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/PH5KZcgCYb",
      "expanded_url" : "http:\/\/go.wh.gov\/bkoCXw",
      "display_url" : "go.wh.gov\/bkoCXw"
    } ]
  },
  "geo" : { },
  "id_str" : "481646772180090880",
  "text" : "\"This is a movement, not a moment.\" \u2014@VJ44. What you missed at yesterday\u2019s Working Families Summit: http:\/\/t.co\/PH5KZcgCYb #FamiliesSucceed",
  "id" : 481646772180090880,
  "created_at" : "2014-06-25 03:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 20, 27 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 34, 42 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 102, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PH5KZcgCYb",
      "expanded_url" : "http:\/\/go.wh.gov\/bkoCXw",
      "display_url" : "go.wh.gov\/bkoCXw"
    } ]
  },
  "geo" : { },
  "id_str" : "481632920608595968",
  "text" : "The President, @VP, @FLOTUS &amp; @DrBiden spent yesterday talking about how we can help more working #FamiliesSucceed \u2192 http:\/\/t.co\/PH5KZcgCYb",
  "id" : 481632920608595968,
  "created_at" : "2014-06-25 03:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/NoIIk0ftNG",
      "expanded_url" : "http:\/\/go.wh.gov\/bkoCXw",
      "display_url" : "go.wh.gov\/bkoCXw"
    } ]
  },
  "geo" : { },
  "id_str" : "481618888808218624",
  "text" : "In case you missed it: Check out the conversation from the Working Families Summit on helping more #FamiliesSucceed \u2192 http:\/\/t.co\/NoIIk0ftNG",
  "id" : 481618888808218624,
  "created_at" : "2014-06-25 02:04:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481591765586432000\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/Uh8cwoGzRN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq71KJxCAAIWVcL.jpg",
      "id_str" : "481591764944289794",
      "id" : 481591764944289794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq71KJxCAAIWVcL.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/Uh8cwoGzRN"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 79, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/COAMtGNQKv",
      "expanded_url" : "http:\/\/go.wh.gov\/wZoKKj",
      "display_url" : "go.wh.gov\/wZoKKj"
    } ]
  },
  "geo" : { },
  "id_str" : "481591765586432000",
  "text" : "The President stopped by Chipotle &amp; sat down with folks to discuss helping #FamiliesSucceed: http:\/\/t.co\/COAMtGNQKv http:\/\/t.co\/Uh8cwoGzRN",
  "id" : 481591765586432000,
  "created_at" : "2014-06-25 00:16:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresCup2013",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "481571475712147456",
  "text" : "Happening now: President Obama hosts the 2013 Presidents Cup team at the White House \u2192 http:\/\/t.co\/b4tqL3oo0v #PresCup2013",
  "id" : 481571475712147456,
  "created_at" : "2014-06-24 22:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 104, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481562111366406146",
  "text" : "RT @FLOTUS: \u201CHaving a fair wage\u2026improves the bottom line for companies.\u201D \u2014The First Lady at yesterday's #FamiliesSucceed Summit: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 92, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/oHohCUHy7Q",
        "expanded_url" : "http:\/\/go.wh.gov\/3KUjPZ",
        "display_url" : "go.wh.gov\/3KUjPZ"
      } ]
    },
    "geo" : { },
    "id_str" : "481527226635014144",
    "text" : "\u201CHaving a fair wage\u2026improves the bottom line for companies.\u201D \u2014The First Lady at yesterday's #FamiliesSucceed Summit: http:\/\/t.co\/oHohCUHy7Q",
    "id" : 481527226635014144,
    "created_at" : "2014-06-24 20:00:11 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 481562111366406146,
  "created_at" : "2014-06-24 22:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cqBrjZB63c",
      "expanded_url" : "http:\/\/go.wh.gov\/D3Cyte",
      "display_url" : "go.wh.gov\/D3Cyte"
    } ]
  },
  "geo" : { },
  "id_str" : "481499478051287041",
  "text" : "\u201CI\u2019m writing to let you know what it\u2019s like for us out here in the middle of the country\u201D \u2014Rebekah to the President: http:\/\/t.co\/cqBrjZB63c",
  "id" : 481499478051287041,
  "created_at" : "2014-06-24 18:09:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481490813604884480",
  "text" : "RT @Schultz44: ICYMI: 48 nominees for Ambassador are pending in Senate, 26 on Senate floor -- waiting average of 262 days.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481482949117087745",
    "text" : "ICYMI: 48 nominees for Ambassador are pending in Senate, 26 on Senate floor -- waiting average of 262 days.",
    "id" : 481482949117087745,
    "created_at" : "2014-06-24 17:04:15 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 481490813604884480,
  "created_at" : "2014-06-24 17:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/L3kWszxPKR",
      "expanded_url" : "http:\/\/go.wh.gov\/5i7j4X",
      "display_url" : "go.wh.gov\/5i7j4X"
    } ]
  },
  "geo" : { },
  "id_str" : "481456130431123456",
  "text" : "RT @Simas44: The President will spend Thursday in Minnesota living a day in Rebekah\u2019s shoes. Hear her story \u2192 http:\/\/t.co\/L3kWszxPKR #Oppor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 120, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/L3kWszxPKR",
        "expanded_url" : "http:\/\/go.wh.gov\/5i7j4X",
        "display_url" : "go.wh.gov\/5i7j4X"
      } ]
    },
    "geo" : { },
    "id_str" : "481443368606507008",
    "text" : "The President will spend Thursday in Minnesota living a day in Rebekah\u2019s shoes. Hear her story \u2192 http:\/\/t.co\/L3kWszxPKR #OpportunityForAll",
    "id" : 481443368606507008,
    "created_at" : "2014-06-24 14:26:58 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 481456130431123456,
  "created_at" : "2014-06-24 15:17:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityforAll",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/42GRageU1D",
      "expanded_url" : "http:\/\/go.wh.gov\/5i7j4X",
      "display_url" : "go.wh.gov\/5i7j4X"
    } ]
  },
  "geo" : { },
  "id_str" : "481437838949752832",
  "text" : "Rebekah wrote a letter to the President. Now she's meeting him. Watch her story \u2192 http:\/\/t.co\/42GRageU1D #OpportunityforAll",
  "id" : 481437838949752832,
  "created_at" : "2014-06-24 14:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481198144525705216",
  "text" : "RT @FLOTUS: \u201CTrailblazing can hurt sometimes\u2026but you\u2019re doing it for the men and women who don\u2019t have that voice.\u201D \u2014The First Lady #Familie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 119, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481197685794693121",
    "text" : "\u201CTrailblazing can hurt sometimes\u2026but you\u2019re doing it for the men and women who don\u2019t have that voice.\u201D \u2014The First Lady #FamiliesSucceed",
    "id" : 481197685794693121,
    "created_at" : "2014-06-23 22:10:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 481198144525705216,
  "created_at" : "2014-06-23 22:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481193796659867649",
  "text" : "RT @FLOTUS: \u201COur first job is to make sure that our kids are on point. That is the most important legacy we\u2019ll leave.\u201D \u2014The First Lady #Fam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 123, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481193503574478848",
    "text" : "\u201COur first job is to make sure that our kids are on point. That is the most important legacy we\u2019ll leave.\u201D \u2014The First Lady #FamiliesSucceed",
    "id" : 481193503574478848,
    "created_at" : "2014-06-23 21:54:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 481193796659867649,
  "created_at" : "2014-06-23 21:55:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481190484426387456\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lsY0pq1DIp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq2IMflCMAAb8mW.jpg",
      "id_str" : "481190483415150592",
      "id" : 481190483415150592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq2IMflCMAAb8mW.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lsY0pq1DIp"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/eY9Or2IBnP",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481190484426387456",
  "text" : "Our economy is stronger because women make up nearly half of our workforce: http:\/\/t.co\/eY9Or2IBnP #FamiliesSucceed http:\/\/t.co\/lsY0pq1DIp",
  "id" : 481190484426387456,
  "created_at" : "2014-06-23 21:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481176569163952128\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JEBxGaHDEh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq17ihDCAAEfGxt.jpg",
      "id_str" : "481176568115363841",
      "id" : 481176568115363841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq17ihDCAAEfGxt.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JEBxGaHDEh"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 11, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/A8GvhkaIJN",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481176569163952128",
  "text" : "Let's help #FamiliesSucceed by making sure our workplace policies allow for work-life balance. http:\/\/t.co\/A8GvhkaIJN http:\/\/t.co\/JEBxGaHDEh",
  "id" : 481176569163952128,
  "created_at" : "2014-06-23 20:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/A8GvhkaIJN",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481147230263341056",
  "text" : "On average, women are still paid less than men for doing the same work.\nIt's time to change that \u2192 http:\/\/t.co\/A8GvhkaIJN #FamiliesSucceed",
  "id" : 481147230263341056,
  "created_at" : "2014-06-23 18:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481140383930679296",
  "text" : "\"I take this personally because I\u2019m the husband of a brilliant woman who struggled to balance work and raising our girls.\" \u2014President Obama",
  "id" : 481140383930679296,
  "created_at" : "2014-06-23 18:23:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481139603454566401",
  "text" : "\"Women are no longer charged more for being women.\" \u2014President Obama on the Affordable Care Act #FamiliesSucceed",
  "id" : 481139603454566401,
  "created_at" : "2014-06-23 18:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/481139013559283713\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/DkLa5ZkBSO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1ZYghCMAAFSvk.jpg",
      "id_str" : "481139012778733568",
      "id" : 481139012778733568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1ZYghCMAAFSvk.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DkLa5ZkBSO"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 45, 58 ]
    }, {
      "text" : "FamiliesSucceed",
      "indices" : [ 59, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481139013559283713",
  "text" : "\"America deserves a raise.\" \u2014President Obama #RaiseTheWage #FamiliesSucceed http:\/\/t.co\/DkLa5ZkBSO",
  "id" : 481139013559283713,
  "created_at" : "2014-06-23 18:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481138591557767168",
  "text" : "Obama: \"Since I asked Congress to raise the minimum wage last year...13 states have taken steps to raise it on their own.\" #FamiliesSucceed",
  "id" : 481138591557767168,
  "created_at" : "2014-06-23 18:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481136351426134016\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Sxoy8D1PAb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1W9jWCUAEbECV.jpg",
      "id_str" : "481136350658187265",
      "id" : 481136350658187265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1W9jWCUAEbECV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Sxoy8D1PAb"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481136351426134016",
  "text" : "\"When women succeed, America succeeds, so there's no such thing as a 'women's issue.'\" \u2014Obama #FamiliesSucceed http:\/\/t.co\/Sxoy8D1PAb",
  "id" : 481136351426134016,
  "created_at" : "2014-06-23 18:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 83, 99 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481135782535917568",
  "text" : "\"Parents who work full-time should earn enough to pay the bills.\" \u2014President Obama #FamiliesSucceed #RaiseTheWage",
  "id" : 481135782535917568,
  "created_at" : "2014-06-23 18:04:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481135680274575361",
  "text" : "\"Family leave, childcare, flexibility, a decent wage\u2014these aren\u2019t frills. They\u2019re basic needs.\" \u2014President Obama #FamiliesSucceed",
  "id" : 481135680274575361,
  "created_at" : "2014-06-23 18:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481135270361047040\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/HXuBz5LzTJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1V-oQCIAEsqr8.jpg",
      "id_str" : "481135269643427841",
      "id" : 481135269643427841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1V-oQCIAEsqr8.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HXuBz5LzTJ"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481135270361047040",
  "text" : "\"Nearly 28 million Americans would benefit if we raised the minimum wage to $10.10.\" \u2014Obama #FamiliesSucceed http:\/\/t.co\/HXuBz5LzTJ",
  "id" : 481135270361047040,
  "created_at" : "2014-06-23 18:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 102, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481134849248731136",
  "text" : "\"Many women can\u2019t even get a paid day off to give birth.\" \u2014President Obama on the need for paid leave #FamiliesSucceed",
  "id" : 481134849248731136,
  "created_at" : "2014-06-23 18:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481134715152633856",
  "text" : "President Obama: \"Flexibility makes workers happier, and helps companies lower turnover and raise productivity.\" #FamiliesSucceed",
  "id" : 481134715152633856,
  "created_at" : "2014-06-23 18:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481133205815558144",
  "text" : "RT @WHLive: \"I just walked over to Chipotle for lunch...it had been a while since I had their burrito bowl.\" \u2014President Obama: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kYyzbYRhUz",
        "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
        "display_url" : "WorkingFamiliesSummit.org"
      } ]
    },
    "geo" : { },
    "id_str" : "481133064853413889",
    "text" : "\"I just walked over to Chipotle for lunch...it had been a while since I had their burrito bowl.\" \u2014President Obama: http:\/\/t.co\/kYyzbYRhUz",
    "id" : 481133064853413889,
    "created_at" : "2014-06-23 17:53:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 481133205815558144,
  "created_at" : "2014-06-23 17:54:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/eY9Or2IBnP",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481132358180290560",
  "text" : "Happening now: President Obama speaks on how we can help more working #FamiliesSucceed \u2192 http:\/\/t.co\/eY9Or2IBnP",
  "id" : 481132358180290560,
  "created_at" : "2014-06-23 17:51:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 75, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/eY9Or2IBnP",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481130296566632448",
  "text" : "Starting soon: Watch President Obama speak on how we can help more working #FamiliesSucceed \u2192 http:\/\/t.co\/eY9Or2IBnP",
  "id" : 481130296566632448,
  "created_at" : "2014-06-23 17:42:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481118341651001344\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/tQq1M5Bpyd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1GlPKCcAA06rg.jpg",
      "id_str" : "481118340736249856",
      "id" : 481118340736249856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1GlPKCcAA06rg.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tQq1M5Bpyd"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481118341651001344",
  "text" : "FACT: 24% of married women earn more than their husbands\u2014compared to only 7% in 1970. #FamiliesSucceed http:\/\/t.co\/tQq1M5Bpyd",
  "id" : 481118341651001344,
  "created_at" : "2014-06-23 16:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "indices" : [ 3, 10 ],
      "id_str" : "207686162",
      "id" : 207686162
    }, {
      "name" : "Old Navy Official",
      "screen_name" : "OldNavy",
      "indices" : [ 86, 94 ],
      "id_str" : "18462539",
      "id" : 18462539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481110920379510784",
  "text" : "RT @GapInc: \"It's not only the right thing to do but is also right for our business.\" @OldNavy VP on raising our U.S. min. hourly rate #Fam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Old Navy Official",
        "screen_name" : "OldNavy",
        "indices" : [ 74, 82 ],
        "id_str" : "18462539",
        "id" : 18462539
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 123, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481106956653187073",
    "text" : "\"It's not only the right thing to do but is also right for our business.\" @OldNavy VP on raising our U.S. min. hourly rate #FamiliesSucceed",
    "id" : 481106956653187073,
    "created_at" : "2014-06-23 16:10:11 +0000",
    "user" : {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "protected" : false,
      "id_str" : "207686162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634867462404599808\/vrI08ztG_normal.jpg",
      "id" : 207686162,
      "verified" : true
    }
  },
  "id" : 481110920379510784,
  "created_at" : "2014-06-23 16:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZQ8eWa7Y5t",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/nine_facts_about_family_and_work_real_final.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481101925166092290",
  "text" : "RT @CEABetsey: Christina Hendricks knows the 9 facts about families and work, you should too #FamiliesSucceed http:\/\/t.co\/ZQ8eWa7Y5t http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/481101347002269696\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ychpjsYiPc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq03IACCcAEinus.jpg",
        "id_str" : "481101345785540609",
        "id" : 481101345785540609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq03IACCcAEinus.jpg",
        "sizes" : [ {
          "h" : 785,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2947,
          "resize" : "fit",
          "w" : 2252
        }, {
          "h" : 1340,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ychpjsYiPc"
      } ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 78, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ZQ8eWa7Y5t",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/nine_facts_about_family_and_work_real_final.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481101347002269696",
    "text" : "Christina Hendricks knows the 9 facts about families and work, you should too #FamiliesSucceed http:\/\/t.co\/ZQ8eWa7Y5t http:\/\/t.co\/ychpjsYiPc",
    "id" : 481101347002269696,
    "created_at" : "2014-06-23 15:47:54 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 481101925166092290,
  "created_at" : "2014-06-23 15:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 102, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481098387115487232",
  "text" : "RT @USDOL: More women are breadwinners in US households. It's time for workplace policies that match. #FamiliesSucceed http:\/\/t.co\/ySj0Mt6t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/481098308199268352\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/ySj0Mt6t8X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq00XIJCYAAzYqH.png",
        "id_str" : "481098307125534720",
        "id" : 481098307125534720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq00XIJCYAAzYqH.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ySj0Mt6t8X"
      } ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 91, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481098308199268352",
    "text" : "More women are breadwinners in US households. It's time for workplace policies that match. #FamiliesSucceed http:\/\/t.co\/ySj0Mt6t8X",
    "id" : 481098308199268352,
    "created_at" : "2014-06-23 15:35:49 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 481098387115487232,
  "created_at" : "2014-06-23 15:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/481088151453044737\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0CfTjhZUp6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0rH7bCUAEsL-1.jpg",
      "id_str" : "481088150408679425",
      "id" : 481088150408679425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0rH7bCUAEsL-1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0CfTjhZUp6"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 51, 60 ]
    }, {
      "text" : "FamiliesSucceed",
      "indices" : [ 100, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/A8GvhkaIJN",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481088151453044737",
  "text" : "RT if you agree: It's time to make sure women earn #EqualPay for equal work. http:\/\/t.co\/A8GvhkaIJN #FamiliesSucceed http:\/\/t.co\/0CfTjhZUp6",
  "id" : 481088151453044737,
  "created_at" : "2014-06-23 14:55:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 107, 123 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/oqZnoGRjCX",
      "expanded_url" : "http:\/\/huff.to\/V5nc1S",
      "display_url" : "huff.to\/V5nc1S"
    } ]
  },
  "geo" : { },
  "id_str" : "481079835926986752",
  "text" : "\u201CParents who work full-time should earn enough to pay the bills.\u201D \u2014President Obama: http:\/\/t.co\/oqZnoGRjCX #FamiliesSucceed #RaiseTheWage",
  "id" : 481079835926986752,
  "created_at" : "2014-06-23 14:22:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 79, 82 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481076701666213888",
  "text" : "RT @WHLive: \"Family-friendly policies reduce turnover and boost performance.\" \u2014@VP Biden on how we can help more working #FamiliesSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 67, 70 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 109, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481076674252263424",
    "text" : "\"Family-friendly policies reduce turnover and boost performance.\" \u2014@VP Biden on how we can help more working #FamiliesSucceed",
    "id" : 481076674252263424,
    "created_at" : "2014-06-23 14:09:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 481076701666213888,
  "created_at" : "2014-06-23 14:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481076313386917889",
  "text" : "RT @VP: \"If you give it a shot, I think you'll find the return is overwhelming.\" -VP to corporate executives on creating family-friendly po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481076217492144128",
    "text" : "\"If you give it a shot, I think you'll find the return is overwhelming.\" -VP to corporate executives on creating family-friendly policies",
    "id" : 481076217492144128,
    "created_at" : "2014-06-23 14:08:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 481076313386917889,
  "created_at" : "2014-06-23 14:08:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 84, 87 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481075935463350272",
  "text" : "\"It\u2019s about creating policies that allow your workers to balance family and work.\" \u2014@VP to America's business leaders #FamiliesSucceed",
  "id" : 481075935463350272,
  "created_at" : "2014-06-23 14:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481075025316167680",
  "text" : "RT @VP: \"They helped raise me as much as I helped raise them.\" -VP Biden on spending time with his children #FamiliesSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 100, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481074062479745024",
    "text" : "\"They helped raise me as much as I helped raise them.\" -VP Biden on spending time with his children #FamiliesSucceed",
    "id" : 481074062479745024,
    "created_at" : "2014-06-23 13:59:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 481075025316167680,
  "created_at" : "2014-06-23 14:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 24, 27 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 48, 59 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/kYyzbYRhUz",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481069905794842624",
  "text" : "RT @WHLive: Watch live: @VP Biden speaks at the @WhiteHouse Summit on Working Families \u2192 http:\/\/t.co\/kYyzbYRhUz #FamiliesSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 12, 15 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 36, 47 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 100, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/kYyzbYRhUz",
        "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
        "display_url" : "WorkingFamiliesSummit.org"
      } ]
    },
    "geo" : { },
    "id_str" : "481069876677976064",
    "text" : "Watch live: @VP Biden speaks at the @WhiteHouse Summit on Working Families \u2192 http:\/\/t.co\/kYyzbYRhUz #FamiliesSucceed",
    "id" : 481069876677976064,
    "created_at" : "2014-06-23 13:42:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 481069905794842624,
  "created_at" : "2014-06-23 13:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 123, 132 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481066607100583936",
  "text" : "RT @USDOL: \"I am proud to announce today that we are investing in new research to understand the benefits of paid leave.\" -@LaborSec #Famil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 112, 121 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481066556957655040",
    "text" : "\"I am proud to announce today that we are investing in new research to understand the benefits of paid leave.\" -@LaborSec #FamiliesSucceed",
    "id" : 481066556957655040,
    "created_at" : "2014-06-23 13:29:39 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 481066607100583936,
  "created_at" : "2014-06-23 13:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/gzZMdPtk8e",
      "expanded_url" : "http:\/\/workingfamiliessummit.org",
      "display_url" : "workingfamiliessummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481065956371095552",
  "text" : "RT @VP: Starting soon: VP Biden speaks at the White House Summit on Working Families http:\/\/t.co\/gzZMdPtk8e #FamiliesSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 100, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/gzZMdPtk8e",
        "expanded_url" : "http:\/\/workingfamiliessummit.org",
        "display_url" : "workingfamiliessummit.org"
      } ]
    },
    "geo" : { },
    "id_str" : "481065569349685249",
    "text" : "Starting soon: VP Biden speaks at the White House Summit on Working Families http:\/\/t.co\/gzZMdPtk8e #FamiliesSucceed",
    "id" : 481065569349685249,
    "created_at" : "2014-06-23 13:25:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 481065956371095552,
  "created_at" : "2014-06-23 13:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 50, 55 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/481064458824192001\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OO7Jp6RqEO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0Vk1xCAAAzo5h.jpg",
      "id_str" : "481064457850716160",
      "id" : 481064457850716160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0Vk1xCAAAzo5h.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OO7Jp6RqEO"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481064535755722753",
  "text" : "RT @WHLive: \"We need to raise the minimum wage.\" \u2014@VJ44 at the Working Families Summit #FamiliesSucceed http:\/\/t.co\/OO7Jp6RqEO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 38, 43 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/481064458824192001\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/OO7Jp6RqEO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0Vk1xCAAAzo5h.jpg",
        "id_str" : "481064457850716160",
        "id" : 481064457850716160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0Vk1xCAAAzo5h.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OO7Jp6RqEO"
      } ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 75, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481064458824192001",
    "text" : "\"We need to raise the minimum wage.\" \u2014@VJ44 at the Working Families Summit #FamiliesSucceed http:\/\/t.co\/OO7Jp6RqEO",
    "id" : 481064458824192001,
    "created_at" : "2014-06-23 13:21:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 481064535755722753,
  "created_at" : "2014-06-23 13:21:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 27, 32 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 37, 46 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 60, 71 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/kYyzbYRhUz",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481063162113183744",
  "text" : "RT @WHLive: Happening now: @VJ44 and @LaborSec speak at the @WhiteHouse Summit on Working Families. Watch \u2192 http:\/\/t.co\/kYyzbYRhUz #Familie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 15, 20 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 25, 34 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 48, 59 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 119, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/kYyzbYRhUz",
        "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
        "display_url" : "WorkingFamiliesSummit.org"
      } ]
    },
    "geo" : { },
    "id_str" : "481063123240386560",
    "text" : "Happening now: @VJ44 and @LaborSec speak at the @WhiteHouse Summit on Working Families. Watch \u2192 http:\/\/t.co\/kYyzbYRhUz #FamiliesSucceed",
    "id" : 481063123240386560,
    "created_at" : "2014-06-23 13:16:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 481063162113183744,
  "created_at" : "2014-06-23 13:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 28, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/HaYweD8yt9",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481062136685535232",
  "text" : "RT @NancyPelosi: Let's help #FamiliesSucceed by making sure our workplace policies catch up with our workplaces\u2192http:\/\/t.co\/HaYweD8yt9 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/481058941292802049\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/KveVWX479r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0QjsoIgAA3-Ak.jpg",
        "id_str" : "481058940659466240",
        "id" : 481058940659466240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0QjsoIgAA3-Ak.jpg",
        "sizes" : [ {
          "h" : 601,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KveVWX479r"
      } ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 11, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/HaYweD8yt9",
        "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
        "display_url" : "WorkingFamiliesSummit.org"
      } ]
    },
    "geo" : { },
    "id_str" : "481058941292802049",
    "text" : "Let's help #FamiliesSucceed by making sure our workplace policies catch up with our workplaces\u2192http:\/\/t.co\/HaYweD8yt9 http:\/\/t.co\/KveVWX479r",
    "id" : 481058941292802049,
    "created_at" : "2014-06-23 12:59:23 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 481062136685535232,
  "created_at" : "2014-06-23 13:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 40, 47 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/eY9Or2IBnP",
      "expanded_url" : "http:\/\/WorkingFamiliesSummit.org",
      "display_url" : "WorkingFamiliesSummit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481058785935765504",
  "text" : "Don't miss President Obama, the @VP and @FLOTUS speak at today's Working Families Summit. Tune in starting at 9am ET: http:\/\/t.co\/eY9Or2IBnP",
  "id" : 481058785935765504,
  "created_at" : "2014-06-23 12:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/480809976026255360\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/32I9jPDrOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqwFXa4CEAE0q9S.jpg",
      "id_str" : "480765160131268609",
      "id" : 480765160131268609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqwFXa4CEAE0q9S.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/32I9jPDrOd"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480809976026255360",
  "text" : "FACT: The increase in women in the workforce since the 1970's has grown our economy by 13.5%. #FamiliesSucceed http:\/\/t.co\/32I9jPDrOd",
  "id" : 480809976026255360,
  "created_at" : "2014-06-22 20:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/fnOEwJa7gK",
      "expanded_url" : "http:\/\/go.wh.gov\/suNHLY",
      "display_url" : "go.wh.gov\/suNHLY"
    } ]
  },
  "geo" : { },
  "id_str" : "480794888896659456",
  "text" : "In advance of Monday\u2019s Working Families Summit, here are 9 facts on working families in America \u2192 http:\/\/t.co\/fnOEwJa7gK #FamiliesSucceed",
  "id" : 480794888896659456,
  "created_at" : "2014-06-22 19:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QPX7vic35j",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnWtM",
      "display_url" : "go.wh.gov\/FGnWtM"
    } ]
  },
  "geo" : { },
  "id_str" : "480776025966538754",
  "text" : "\"Flexibility can make workers more productive and reduce worker turnover and...that\u2019s good for business.\" \u2014Obama: http:\/\/t.co\/QPX7vic35j",
  "id" : 480776025966538754,
  "created_at" : "2014-06-22 18:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/480765651863478273\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/PcBavxVNcG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqwFz_4CAAAY8Pc.jpg",
      "id_str" : "480765651099713536",
      "id" : 480765651099713536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqwFz_4CAAAY8Pc.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PcBavxVNcG"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 65, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/5cI9S7RiBT",
      "expanded_url" : "http:\/\/go.wh.gov\/suNHLY",
      "display_url" : "go.wh.gov\/suNHLY"
    } ]
  },
  "geo" : { },
  "id_str" : "480765651863478273",
  "text" : "It's time to update our workplaces policies to help more working #FamiliesSucceed: http:\/\/t.co\/5cI9S7RiBT http:\/\/t.co\/PcBavxVNcG",
  "id" : 480765651863478273,
  "created_at" : "2014-06-22 17:33:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    }, {
      "name" : "Kevin Johnson",
      "screen_name" : "KJ_MayorJohnson",
      "indices" : [ 19, 35 ],
      "id_str" : "16621525",
      "id" : 16621525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mayors2014",
      "indices" : [ 95, 106 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480759822905004032",
  "text" : "RT @DavidAgnew44: .@KJ_MayorJohnson leads mayors in signing a new Climate Protection Agreement #Mayors2014 #ActOnClimate http:\/\/t.co\/gWOHwP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Johnson",
        "screen_name" : "KJ_MayorJohnson",
        "indices" : [ 1, 17 ],
        "id_str" : "16621525",
        "id" : 16621525
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DavidAgnew44\/status\/480730022726995969\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/gWOHwPqqkE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqvlaFJCMAEPaWD.jpg",
        "id_str" : "480730021464518657",
        "id" : 480730021464518657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqvlaFJCMAEPaWD.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/gWOHwPqqkE"
      } ],
      "hashtags" : [ {
        "text" : "Mayors2014",
        "indices" : [ 77, 88 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 89, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480730022726995969",
    "text" : ".@KJ_MayorJohnson leads mayors in signing a new Climate Protection Agreement #Mayors2014 #ActOnClimate http:\/\/t.co\/gWOHwPqqkE",
    "id" : 480730022726995969,
    "created_at" : "2014-06-22 15:12:23 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 480759822905004032,
  "created_at" : "2014-06-22 17:10:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 44, 52 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 59, 70 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USMCDallas2014",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/TY02juKYph",
      "expanded_url" : "http:\/\/usmayors.org\/82ndAnnualMeeting",
      "display_url" : "usmayors.org\/82ndAnnualMeet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480728592309956610",
  "text" : "RT @ErnestMoniz: Looking forward to joining @GinaEPA &amp; @arneduncan at #USMCDallas2014 this weekend \u2192 http:\/\/t.co\/TY02juKYph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 27, 35 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 42, 53 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USMCDallas2014",
        "indices" : [ 57, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/TY02juKYph",
        "expanded_url" : "http:\/\/usmayors.org\/82ndAnnualMeeting",
        "display_url" : "usmayors.org\/82ndAnnualMeet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480406074882019329",
    "text" : "Looking forward to joining @GinaEPA &amp; @arneduncan at #USMCDallas2014 this weekend \u2192 http:\/\/t.co\/TY02juKYph",
    "id" : 480406074882019329,
    "created_at" : "2014-06-21 17:45:08 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 480728592309956610,
  "created_at" : "2014-06-22 15:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 55, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/QPX7vic35j",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnWtM",
      "display_url" : "go.wh.gov\/FGnWtM"
    } ]
  },
  "geo" : { },
  "id_str" : "480727679440678912",
  "text" : "President Obama's Weekly Address: Helping more working #FamiliesSucceed \u2192 http:\/\/t.co\/QPX7vic35j",
  "id" : 480727679440678912,
  "created_at" : "2014-06-22 15:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/QPX7vic35j",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnWtM",
      "display_url" : "go.wh.gov\/FGnWtM"
    } ]
  },
  "geo" : { },
  "id_str" : "480440100640149506",
  "text" : "\"We\u2019re bringing together business leaders &amp; workers to talk about the challenges that working parents face.\" \u2014Obama: http:\/\/t.co\/QPX7vic35j",
  "id" : 480440100640149506,
  "created_at" : "2014-06-21 20:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mayors14",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480423245481779200",
  "text" : "RT @arneduncan: Great meeting with U.S. Conference of Mayors! City leaders are looking to increase access to early ed. #mayors14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mayors14",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480370955790065664",
    "text" : "Great meeting with U.S. Conference of Mayors! City leaders are looking to increase access to early ed. #mayors14",
    "id" : 480370955790065664,
    "created_at" : "2014-06-21 15:25:35 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 480423245481779200,
  "created_at" : "2014-06-21 18:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QPX7vic35j",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnWtM",
      "display_url" : "go.wh.gov\/FGnWtM"
    } ]
  },
  "geo" : { },
  "id_str" : "480398515428798464",
  "text" : "\"My top priority is rebuilding an economy where everybody who works hard has the chance to get ahead.\" \u2014Obama: http:\/\/t.co\/QPX7vic35j",
  "id" : 480398515428798464,
  "created_at" : "2014-06-21 17:15:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 120, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/QPX7vic35j",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnWtM",
      "display_url" : "go.wh.gov\/FGnWtM"
    } ]
  },
  "geo" : { },
  "id_str" : "480379731133489152",
  "text" : "\"All Americans should be able to afford to care for a family member in need.\" \u2014President Obama: http:\/\/t.co\/QPX7vic35j  #FamiliesSucceed",
  "id" : 480379731133489152,
  "created_at" : "2014-06-21 16:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/jaTltRUET9",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnWtM",
      "display_url" : "go.wh.gov\/FGnWtM"
    } ]
  },
  "geo" : { },
  "id_str" : "480363079138811904",
  "text" : "\"Family leave. Childcare. Flexibility. These aren\u2019t frills\u2014they\u2019re basic needs.\" \u2014President Obama: http:\/\/t.co\/jaTltRUET9 #FamiliesSucceed",
  "id" : 480363079138811904,
  "created_at" : "2014-06-21 14:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 23, 32 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Jay Carney",
      "screen_name" : "JayCarney",
      "indices" : [ 59, 69 ],
      "id_str" : "2577476334",
      "id" : 2577476334
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/480128881215959040\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/G7sMjF5UyB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqnCrFaCIAI8TJd.jpg",
      "id_str" : "480128880733200386",
      "id" : 480128880733200386,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqnCrFaCIAI8TJd.jpg",
      "sizes" : [ {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G7sMjF5UyB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480128881215959040",
  "text" : "Thanks for everything, @PressSec! Enjoy your new podium at @JayCarney. http:\/\/t.co\/G7sMjF5UyB",
  "id" : 480128881215959040,
  "created_at" : "2014-06-20 23:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "olmstead15",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vyqyT1CGye",
      "expanded_url" : "http:\/\/1.usa.gov\/1igjdKm",
      "display_url" : "1.usa.gov\/1igjdKm"
    } ]
  },
  "geo" : { },
  "id_str" : "480122080172978176",
  "text" : "RT @PAniskoff44: 15 yrs after Olmstead we remain committed to community living for people w disabilities. #olmstead15 http:\/\/t.co\/vyqyT1CGye",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "olmstead15",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/vyqyT1CGye",
        "expanded_url" : "http:\/\/1.usa.gov\/1igjdKm",
        "display_url" : "1.usa.gov\/1igjdKm"
      } ]
    },
    "geo" : { },
    "id_str" : "480033045958123520",
    "text" : "15 yrs after Olmstead we remain committed to community living for people w disabilities. #olmstead15 http:\/\/t.co\/vyqyT1CGye",
    "id" : 480033045958123520,
    "created_at" : "2014-06-20 17:02:51 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 480122080172978176,
  "created_at" : "2014-06-20 22:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/480096257399332864\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DnCoQGGSmY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmlAHmCQAA5_Gi.jpg",
      "id_str" : "480096256748830720",
      "id" : 480096256748830720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmlAHmCQAA5_Gi.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DnCoQGGSmY"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/5cI9S7RiBT",
      "expanded_url" : "http:\/\/go.wh.gov\/suNHLY",
      "display_url" : "go.wh.gov\/suNHLY"
    } ]
  },
  "geo" : { },
  "id_str" : "480096257399332864",
  "text" : "Our economy is stronger because women make up nearly half of our workforce: http:\/\/t.co\/5cI9S7RiBT #FamiliesSucceed http:\/\/t.co\/DnCoQGGSmY",
  "id" : 480096257399332864,
  "created_at" : "2014-06-20 21:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GIBill70th",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/lwsuNAq4jE",
      "expanded_url" : "http:\/\/go.wh.gov\/R3zc1T",
      "display_url" : "go.wh.gov\/R3zc1T"
    } ]
  },
  "geo" : { },
  "id_str" : "480083548972781568",
  "text" : "\"You pick the school, and we\u2019ll help pick up the bill.\" \u2014Obama on the 70th anniversary of the GI Bill: http:\/\/t.co\/lwsuNAq4jE #GIBill70th",
  "id" : 480083548972781568,
  "created_at" : "2014-06-20 20:23:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/480076739503460352\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/niv6TogBo0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmTQCECIAA3K2Z.jpg",
      "id_str" : "480076738932645888",
      "id" : 480076738932645888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmTQCECIAA3K2Z.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/niv6TogBo0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480076739503460352",
  "text" : "Women are increasingly the breadwinners in more American households. It's time for workplace policies that match. http:\/\/t.co\/niv6TogBo0",
  "id" : 480076739503460352,
  "created_at" : "2014-06-20 19:56:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/5cI9S7RiBT",
      "expanded_url" : "http:\/\/go.wh.gov\/suNHLY",
      "display_url" : "go.wh.gov\/suNHLY"
    } ]
  },
  "geo" : { },
  "id_str" : "480072864763490308",
  "text" : "In advance of Monday\u2019s Working Families Summit, here's the latest on working families in America \u2192 http:\/\/t.co\/5cI9S7RiBT #FamiliesSucceed",
  "id" : 480072864763490308,
  "created_at" : "2014-06-20 19:41:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 109, 121 ]
    }, {
      "text" : "SLD2014",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480058805112565760",
  "text" : "RT @FLOTUS: \u201CKeep that college degree as your north star, so you can\u2019t let this summer go to waste.\u201D \u2014FLOTUS #ReachHigher #SLD2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 97, 109 ]
      }, {
        "text" : "SLD2014",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480055486595624961",
    "text" : "\u201CKeep that college degree as your north star, so you can\u2019t let this summer go to waste.\u201D \u2014FLOTUS #ReachHigher #SLD2014",
    "id" : 480055486595624961,
    "created_at" : "2014-06-20 18:32:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 480058805112565760,
  "created_at" : "2014-06-20 18:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 26, 29 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 31, 38 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 45, 53 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pW7qCXcRLo",
      "expanded_url" : "http:\/\/go.wh.gov\/E2ACP7",
      "display_url" : "go.wh.gov\/E2ACP7"
    } ]
  },
  "geo" : { },
  "id_str" : "480049944532115456",
  "text" : "Join President Obama, the @VP, @FLOTUS &amp; @DrBiden at the Working Families Summit on Monday for a #WHSocial \u2192 http:\/\/t.co\/pW7qCXcRLo",
  "id" : 480049944532115456,
  "created_at" : "2014-06-20 18:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 103, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/8PKONGHsZq",
      "expanded_url" : "http:\/\/go.wh.gov\/1ygu3X",
      "display_url" : "go.wh.gov\/1ygu3X"
    } ]
  },
  "geo" : { },
  "id_str" : "480042418469732352",
  "text" : "\"It is an opportunity to honor the resilience of those who flee violence &amp; persecution.\" \u2014Obama on #WorldRefugeeDay: http:\/\/t.co\/8PKONGHsZq",
  "id" : 480042418469732352,
  "created_at" : "2014-06-20 17:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/480036297256734720\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/fVIvqM4A2d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqlud-uCMAA6Gba.png",
      "id_str" : "480036296623009792",
      "id" : 480036296623009792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqlud-uCMAA6Gba.png",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 1342
      } ],
      "display_url" : "pic.twitter.com\/fVIvqM4A2d"
    } ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 29, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/zT9X3qDoBQ",
      "expanded_url" : "http:\/\/go.wh.gov\/1ygu3X",
      "display_url" : "go.wh.gov\/1ygu3X"
    } ]
  },
  "geo" : { },
  "id_str" : "480036297256734720",
  "text" : "President Obama commemorates #WorldRefugeeDay \u2192 http:\/\/t.co\/zT9X3qDoBQ http:\/\/t.co\/fVIvqM4A2d",
  "id" : 480036297256734720,
  "created_at" : "2014-06-20 17:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/z2hO8lc8C1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=z1B8n_xqB8g",
      "display_url" : "youtube.com\/watch?v=z1B8n_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480004441148764160",
  "text" : "RT @USAID: A threat to girls\u2019 education anywhere is a threat to progress everywhere. #LetGirlsLearn https:\/\/t.co\/z2hO8lc8C1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/z2hO8lc8C1",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=z1B8n_xqB8g",
        "display_url" : "youtube.com\/watch?v=z1B8n_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479973685416456192",
    "text" : "A threat to girls\u2019 education anywhere is a threat to progress everywhere. #LetGirlsLearn https:\/\/t.co\/z2hO8lc8C1",
    "id" : 479973685416456192,
    "created_at" : "2014-06-20 13:06:58 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 480004441148764160,
  "created_at" : "2014-06-20 15:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parade Magazine",
      "screen_name" : "ParadeMagazine",
      "indices" : [ 3, 18 ],
      "id_str" : "18682378",
      "id" : 18682378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/64fasMBfeW",
      "expanded_url" : "http:\/\/bit.ly\/1lCnKai",
      "display_url" : "bit.ly\/1lCnKai"
    } ]
  },
  "geo" : { },
  "id_str" : "479990219811594240",
  "text" : "RT @ParadeMagazine: \"My first 4 jobs were minimum wage or close to it.\u201D - President Obama http:\/\/t.co\/64fasMBfeW #FamiliesSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.wildfireapp.com\/?utm_source=Twitter&utm_medium=Tweet&utm_campaign=via%2BWildfire%2BSuite\" rel=\"nofollow\"\u003EWildfire Suite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/64fasMBfeW",
        "expanded_url" : "http:\/\/bit.ly\/1lCnKai",
        "display_url" : "bit.ly\/1lCnKai"
      } ]
    },
    "geo" : { },
    "id_str" : "479988300653293568",
    "text" : "\"My first 4 jobs were minimum wage or close to it.\u201D - President Obama http:\/\/t.co\/64fasMBfeW #FamiliesSucceed",
    "id" : 479988300653293568,
    "created_at" : "2014-06-20 14:05:03 +0000",
    "user" : {
      "name" : "Parade Magazine",
      "screen_name" : "ParadeMagazine",
      "protected" : false,
      "id_str" : "18682378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530373520081960960\/9EKpzZGr_normal.jpeg",
      "id" : 18682378,
      "verified" : true
    }
  },
  "id" : 479990219811594240,
  "created_at" : "2014-06-20 14:12:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FMLA",
      "indices" : [ 136, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/SvaB4O4TR6",
      "expanded_url" : "http:\/\/1.usa.gov\/1np2py7",
      "display_url" : "1.usa.gov\/1np2py7"
    } ]
  },
  "geo" : { },
  "id_str" : "479984705174274048",
  "text" : "RT @LaborSec: RT if you agree: No one should have to choose between succeeding at work &amp; caring for family.  http:\/\/t.co\/SvaB4O4TR6 #FMLA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FMLA",
        "indices" : [ 122, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/SvaB4O4TR6",
        "expanded_url" : "http:\/\/1.usa.gov\/1np2py7",
        "display_url" : "1.usa.gov\/1np2py7"
      } ]
    },
    "geo" : { },
    "id_str" : "479980242405449728",
    "text" : "RT if you agree: No one should have to choose between succeeding at work &amp; caring for family.  http:\/\/t.co\/SvaB4O4TR6 #FMLA",
    "id" : 479980242405449728,
    "created_at" : "2014-06-20 13:33:02 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 479984705174274048,
  "created_at" : "2014-06-20 13:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/479787111067840512\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oYdL6bQliJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqiDPIZCcAAv1BV.jpg",
      "id_str" : "479777656288735232",
      "id" : 479777656288735232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqiDPIZCcAAv1BV.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oYdL6bQliJ"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479787111067840512",
  "text" : "\u201CKyle\u2026displayed a heroism in the blink of an eye that will inspire for generations\" \u2014Obama awarding the #MedalOfHonor http:\/\/t.co\/oYdL6bQliJ",
  "id" : 479787111067840512,
  "created_at" : "2014-06-20 00:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/pFaOQ76BRJ",
      "expanded_url" : "http:\/\/go.wh.gov\/L87k6Z",
      "display_url" : "go.wh.gov\/L87k6Z"
    } ]
  },
  "geo" : { },
  "id_str" : "479778287653122048",
  "text" : "\"I urge Congress to follow Massachusetts\u2019 lead and lift wages for 28 million Americans.\" \u2014Obama: http:\/\/t.co\/pFaOQ76BRJ #RaiseTheWage",
  "id" : 479778287653122048,
  "created_at" : "2014-06-20 00:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/479772088140435456\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/EYmInABisS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqh-K_ICUAEGByq.jpg",
      "id_str" : "479772087523889153",
      "id" : 479772087523889153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqh-K_ICUAEGByq.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EYmInABisS"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479772088140435456",
  "text" : "Great news: MA voted to raise its min wage to $11\/hour.\nIt's time for Congress to #RaiseTheWage for all Americans. http:\/\/t.co\/EYmInABisS",
  "id" : 479772088140435456,
  "created_at" : "2014-06-19 23:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/479753859133636608\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/qMr7fUkjZQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqhtl67CUAALaya.png",
      "id_str" : "479753858554417152",
      "id" : 479753858554417152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqhtl67CUAALaya.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 911
      } ],
      "display_url" : "pic.twitter.com\/qMr7fUkjZQ"
    } ],
    "hashtags" : [ {
      "text" : "Juneteenth",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/BdE2mBAakb",
      "expanded_url" : "http:\/\/go.wh.gov\/HAuZj9",
      "display_url" : "go.wh.gov\/HAuZj9"
    } ]
  },
  "geo" : { },
  "id_str" : "479753859133636608",
  "text" : "President Obama on the observance of #Juneteenth \u2192 http:\/\/t.co\/BdE2mBAakb http:\/\/t.co\/qMr7fUkjZQ",
  "id" : 479753859133636608,
  "created_at" : "2014-06-19 22:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479723071784644608",
  "text" : "RT @vj44: Hey everyone! Ready to answer your questions on how we can help more working #FamiliesSucceed. Let's get started! http:\/\/t.co\/Lyl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/479722220072493058\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/LylwZFCUJk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqhQ0T0IQAAMjUY.jpg",
        "id_str" : "479722219917295616",
        "id" : 479722219917295616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqhQ0T0IQAAMjUY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LylwZFCUJk"
      } ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 77, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479722220072493058",
    "text" : "Hey everyone! Ready to answer your questions on how we can help more working #FamiliesSucceed. Let's get started! http:\/\/t.co\/LylwZFCUJk",
    "id" : 479722220072493058,
    "created_at" : "2014-06-19 20:27:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 479723071784644608,
  "created_at" : "2014-06-19 20:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 89, 94 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 27, 36 ]
    }, {
      "text" : "FairPay",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479720668830126080",
  "text" : "RT @LaborSec: Questions on #EqualPay, #FairPay or what working families need to succeed? @vj44 will be taking your Qs at 4:30pm ET. Use #Fa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 75, 80 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "FairPay",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "FamiliesSucceed",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479717396559589376",
    "text" : "Questions on #EqualPay, #FairPay or what working families need to succeed? @vj44 will be taking your Qs at 4:30pm ET. Use #FamiliesSucceed.",
    "id" : 479717396559589376,
    "created_at" : "2014-06-19 20:08:34 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 479720668830126080,
  "created_at" : "2014-06-19 20:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 26, 31 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479716576351244290",
  "text" : "RT @NancyPelosi: Met with @vj44 to talk Working Families Summit on 6\/23. Join her twitter chat at 4:30 ET today! #FamiliesSucceed http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 9, 14 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/479714399977230336\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/CRKBfg3ppq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqhJtFCIQAA9fYx.png",
        "id_str" : "479714399109005312",
        "id" : 479714399109005312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqhJtFCIQAA9fYx.png",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 949
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 949
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 124,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CRKBfg3ppq"
      } ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 96, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479714399977230336",
    "text" : "Met with @vj44 to talk Working Families Summit on 6\/23. Join her twitter chat at 4:30 ET today! #FamiliesSucceed http:\/\/t.co\/CRKBfg3ppq",
    "id" : 479714399977230336,
    "created_at" : "2014-06-19 19:56:40 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 479716576351244290,
  "created_at" : "2014-06-19 20:05:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 14, 19 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 61, 74 ]
    }, {
      "text" : "FamiliesSucceed",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479700223044751360",
  "text" : "At 4:30pm ET, @VJ44 will answer your questions on #EqualPay, #RaiseTheWage, and working families. Ask away using #FamiliesSucceed.",
  "id" : 479700223044751360,
  "created_at" : "2014-06-19 19:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479696320631160832",
  "text" : "RT @WHLive: Obama: \"Kyle says he\u2019ll wear this medal for all who serve...for those who didn\u2019t make it back &amp; for those who struggle still.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfHonor",
        "indices" : [ 131, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479696253430026244",
    "text" : "Obama: \"Kyle says he\u2019ll wear this medal for all who serve...for those who didn\u2019t make it back &amp; for those who struggle still.\" #MedalOfHonor",
    "id" : 479696253430026244,
    "created_at" : "2014-06-19 18:44:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479696320631160832,
  "created_at" : "2014-06-19 18:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 12, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479695739250298880",
  "text" : "Obama: \"The #MedalOfHonor is presented for gallantry on the field of battle. Today, we also recognize Kyle Carpenter for his valor since.\"",
  "id" : 479695739250298880,
  "created_at" : "2014-06-19 18:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479694714459795456",
  "text" : "RT @WHLive: \"Kyle, you not only saved your brother in arms. You displayed a heroism in the blink of an eye that will inspire for generation\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479694032927719424",
    "text" : "\"Kyle, you not only saved your brother in arms. You displayed a heroism in the blink of an eye that will inspire for generations.\" \u2014Obama",
    "id" : 479694032927719424,
    "created_at" : "2014-06-19 18:35:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479694714459795456,
  "created_at" : "2014-06-19 18:38:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479693708909355009",
  "text" : "Obama: \"This United States Marine, faced down that terrible explosive power...with his own body...to protect a fellow Marine.\" #MedalOfHonor",
  "id" : 479693708909355009,
  "created_at" : "2014-06-19 18:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 42, 55 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "479692781732913152",
  "text" : "Happening now: President Obama awards the #MedalOfHonor to Corporal Kyle Carpenter. Watch \u2192 http:\/\/t.co\/7QUc084BX3 #HonoringVets",
  "id" : 479692781732913152,
  "created_at" : "2014-06-19 18:30:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479683405765148674",
  "text" : "\"American combat troops are not going to be fighting in Iraq again.\" \u2014President Obama",
  "id" : 479683405765148674,
  "created_at" : "2014-06-19 17:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479682605877846016",
  "text" : "RT @WHLive: \"The most important question we should all be asking\u2026is what is in the national security interests of the United States.\" \u2014Pres\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479681955165138945",
    "text" : "\"The most important question we should all be asking\u2026is what is in the national security interests of the United States.\" \u2014President Obama",
    "id" : 479681955165138945,
    "created_at" : "2014-06-19 17:47:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479682605877846016,
  "created_at" : "2014-06-19 17:50:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479681748037824512",
  "text" : "\"The United States will not pursue military options that support one sect inside of Iraq at the expense of another.\" \u2014President Obama",
  "id" : 479681748037824512,
  "created_at" : "2014-06-19 17:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479681541199904769",
  "text" : "\"Above all, Iraqi leaders must rise above their differences and come together around a political plan for Iraq\u2019s future.\" \u2014President Obama",
  "id" : 479681541199904769,
  "created_at" : "2014-06-19 17:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479681226731978752",
  "text" : "\"As President, I have no greater priority than the safety of our men and women serving overseas.\" \u2014President Obama",
  "id" : 479681226731978752,
  "created_at" : "2014-06-19 17:44:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479681141554044929",
  "text" : "RT @WHLive: \"First, we are working to secure our Embassy and personnel operating inside of Iraq.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479681110470062080",
    "text" : "\"First, we are working to secure our Embassy and personnel operating inside of Iraq.\" \u2014President Obama",
    "id" : 479681110470062080,
    "created_at" : "2014-06-19 17:44:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479681141554044929,
  "created_at" : "2014-06-19 17:44:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/dAxYqm7ITY",
      "expanded_url" : "http:\/\/go.wh.gov\/nkVsrR",
      "display_url" : "go.wh.gov\/nkVsrR"
    } ]
  },
  "geo" : { },
  "id_str" : "479678130568048640",
  "text" : "Happening now: President Obama speaks on the situation in Iraq. Watch \u2192 http:\/\/t.co\/dAxYqm7ITY",
  "id" : 479678130568048640,
  "created_at" : "2014-06-19 17:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479673859927719937",
  "text" : "RT @NSCPress: The timing for the President's statement on #Iraq has been updated to 1:15pm ET.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 44, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479666235744219136",
    "text" : "The timing for the President's statement on #Iraq has been updated to 1:15pm ET.",
    "id" : 479666235744219136,
    "created_at" : "2014-06-19 16:45:17 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 479673859927719937,
  "created_at" : "2014-06-19 17:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "479638767129886720",
  "text" : "At 12:30pm ET, President Obama will deliver a statement from the Briefing Room on the situation in Iraq \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 479638767129886720,
  "created_at" : "2014-06-19 14:56:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479636430604742656",
  "text" : "RT @vj44: Live at 4:30 PM ET today, I'll be answering your Q's on how we can help more working families!  Ask away using #FamiliesSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 111, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479632040166313985",
    "text" : "Live at 4:30 PM ET today, I'll be answering your Q's on how we can help more working families!  Ask away using #FamiliesSucceed",
    "id" : 479632040166313985,
    "created_at" : "2014-06-19 14:29:24 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 479636430604742656,
  "created_at" : "2014-06-19 14:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479626754899070976",
  "text" : "RT @WHLive: Watch live: President Obama meets with his Export Council on making it easier for small businesses to boost exports \u2192 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/fSS80ZxH94",
        "expanded_url" : "http:\/\/go.wh.gov\/dMG7wu",
        "display_url" : "go.wh.gov\/dMG7wu"
      } ]
    },
    "geo" : { },
    "id_str" : "479626727585767425",
    "text" : "Watch live: President Obama meets with his Export Council on making it easier for small businesses to boost exports \u2192 http:\/\/t.co\/fSS80ZxH94",
    "id" : 479626727585767425,
    "created_at" : "2014-06-19 14:08:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479626754899070976,
  "created_at" : "2014-06-19 14:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sf1deI4k48",
      "expanded_url" : "http:\/\/youtu.be\/h9GwdKBagik",
      "display_url" : "youtu.be\/h9GwdKBagik"
    } ]
  },
  "geo" : { },
  "id_str" : "479418383247872002",
  "text" : "RT @FLOTUS: \"In every generation, immigrants have earned their place as part of 'We the People.'\" \u2014The First Lady: http:\/\/t.co\/sf1deI4k48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/sf1deI4k48",
        "expanded_url" : "http:\/\/youtu.be\/h9GwdKBagik",
        "display_url" : "youtu.be\/h9GwdKBagik"
      } ]
    },
    "geo" : { },
    "id_str" : "479409535577120768",
    "text" : "\"In every generation, immigrants have earned their place as part of 'We the People.'\" \u2014The First Lady: http:\/\/t.co\/sf1deI4k48",
    "id" : 479409535577120768,
    "created_at" : "2014-06-18 23:45:14 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 479418383247872002,
  "created_at" : "2014-06-19 00:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/479398193944616960\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PWmpJTeXjJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqcqHdjCQAAduSL.jpg",
      "id_str" : "479398193017274368",
      "id" : 479398193017274368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqcqHdjCQAAduSL.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PWmpJTeXjJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479400512409059328",
  "text" : "RT @FLOTUS: \"The fact is, America needs you.\u201D \u2014The First Lady to 50 new U.S. citizens at a Naturalization Ceremony http:\/\/t.co\/PWmpJTeXjJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/479398193944616960\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/PWmpJTeXjJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqcqHdjCQAAduSL.jpg",
        "id_str" : "479398193017274368",
        "id" : 479398193017274368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqcqHdjCQAAduSL.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PWmpJTeXjJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479398193944616960",
    "text" : "\"The fact is, America needs you.\u201D \u2014The First Lady to 50 new U.S. citizens at a Naturalization Ceremony http:\/\/t.co\/PWmpJTeXjJ",
    "id" : 479398193944616960,
    "created_at" : "2014-06-18 23:00:10 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 479400512409059328,
  "created_at" : "2014-06-18 23:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 91, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479383871671533570",
  "text" : "RT @vj44: Join me tomorrow at 4:30 PM ET to discuss the WH Summit on Working Families. Use #FamiliesSucceed to tweet me ur Qs: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 81, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/jSY0qMBMOk",
        "expanded_url" : "http:\/\/go.wh.gov\/to22Bt",
        "display_url" : "go.wh.gov\/to22Bt"
      } ]
    },
    "geo" : { },
    "id_str" : "479383055522877441",
    "text" : "Join me tomorrow at 4:30 PM ET to discuss the WH Summit on Working Families. Use #FamiliesSucceed to tweet me ur Qs: http:\/\/t.co\/jSY0qMBMOk",
    "id" : 479383055522877441,
    "created_at" : "2014-06-18 22:00:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 479383871671533570,
  "created_at" : "2014-06-18 22:03:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/479350804764438528\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZDvG5da2lb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqb_BEmCQAAkQq1.jpg",
      "id_str" : "479350804239761408",
      "id" : 479350804239761408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqb_BEmCQAAkQq1.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZDvG5da2lb"
    } ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/xw80gvKQSL",
      "expanded_url" : "http:\/\/wh.gov\/maker-faire",
      "display_url" : "wh.gov\/maker-faire"
    } ]
  },
  "geo" : { },
  "id_str" : "479350804764438528",
  "text" : "Check out the projects from today's 1st-ever White House Maker Faire \u2192 http:\/\/t.co\/xw80gvKQSL #NationOfMakers http:\/\/t.co\/ZDvG5da2lb",
  "id" : 479350804764438528,
  "created_at" : "2014-06-18 19:51:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/34qjO6CBXq",
      "expanded_url" : "http:\/\/1.usa.gov\/1pe5fsE",
      "display_url" : "1.usa.gov\/1pe5fsE"
    } ]
  },
  "geo" : { },
  "id_str" : "479311447722573824",
  "text" : "RT @jesseclee44: This is why they call it the \"Affordable Care Act\"--life-changing for millions... http:\/\/t.co\/34qjO6CBXq http:\/\/t.co\/9wWHF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/479295251912208384\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/9wWHF8pOqI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqbMfLKCcAAPIBF.jpg",
        "id_str" : "479295246304440320",
        "id" : 479295246304440320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqbMfLKCcAAPIBF.jpg",
        "sizes" : [ {
          "h" : 642,
          "resize" : "fit",
          "w" : 1028
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9wWHF8pOqI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/34qjO6CBXq",
        "expanded_url" : "http:\/\/1.usa.gov\/1pe5fsE",
        "display_url" : "1.usa.gov\/1pe5fsE"
      } ]
    },
    "geo" : { },
    "id_str" : "479295251912208384",
    "text" : "This is why they call it the \"Affordable Care Act\"--life-changing for millions... http:\/\/t.co\/34qjO6CBXq http:\/\/t.co\/9wWHF8pOqI",
    "id" : 479295251912208384,
    "created_at" : "2014-06-18 16:11:07 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 479311447722573824,
  "created_at" : "2014-06-18 17:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ojhXUFW4tm",
      "expanded_url" : "https:\/\/vine.co\/v\/MTurerZIeuI",
      "display_url" : "vine.co\/v\/MTurerZIeuI"
    } ]
  },
  "geo" : { },
  "id_str" : "479303732380061696",
  "text" : "Yep. There's a robotic giraffe named Russell on the South Lawn at the White House Maker Faire. #NationOfMakers https:\/\/t.co\/ojhXUFW4tm",
  "id" : 479303732380061696,
  "created_at" : "2014-06-18 16:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 78, 93 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/znD8Lv6krh",
      "expanded_url" : "https:\/\/vine.co\/v\/MTBl6HiErnp",
      "display_url" : "vine.co\/v\/MTBl6HiErnp"
    } ]
  },
  "geo" : { },
  "id_str" : "479297323345125376",
  "text" : "\"If you can imagine it, then you can do it, whatever it is.\u201D \u2014President Obama #NationOfMakers #MadeInAmerica https:\/\/t.co\/znD8Lv6krh",
  "id" : 479297323345125376,
  "created_at" : "2014-06-18 16:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/DWh2PpRS9s",
      "expanded_url" : "https:\/\/vine.co\/v\/MTBKA2eEWYL",
      "display_url" : "vine.co\/v\/MTBKA2eEWYL"
    } ]
  },
  "geo" : { },
  "id_str" : "479295064917958656",
  "text" : "\"Looking at some of these exhibits, it was just incredible what was being done.\" \u2014President Obama #NationOfMakers https:\/\/t.co\/DWh2PpRS9s",
  "id" : 479295064917958656,
  "created_at" : "2014-06-18 16:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479294792997036032",
  "text" : "RT @WHLive: \"Across our country, ordinary Americans are inventing incredible things and...bring them to these fairs.\" \u2014President Obama #Nat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479294755147616256",
    "text" : "\"Across our country, ordinary Americans are inventing incredible things and...bring them to these fairs.\" \u2014President Obama #NationOfMakers",
    "id" : 479294755147616256,
    "created_at" : "2014-06-18 16:09:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479294792997036032,
  "created_at" : "2014-06-18 16:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/479294418566909953\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/MXuYkvYABP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqbLu8nCIAEDiaq.jpg",
      "id_str" : "479294417765801985",
      "id" : 479294417765801985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqbLu8nCIAEDiaq.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MXuYkvYABP"
    } ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 87, 102 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479294418566909953",
  "text" : "\"Our manufacturing sector's been adding jobs for the 1st time since the 1990s.\" \u2014Obama #NationOfMakers #MadeInAmerica http:\/\/t.co\/MXuYkvYABP",
  "id" : 479294418566909953,
  "created_at" : "2014-06-18 16:07:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/xw80gvKQSL",
      "expanded_url" : "http:\/\/wh.gov\/maker-faire",
      "display_url" : "wh.gov\/maker-faire"
    } ]
  },
  "geo" : { },
  "id_str" : "479293514438967296",
  "text" : "Watch live: President Obama speaks on the importance of making &amp; manufacturing at the WH Maker Faire: http:\/\/t.co\/xw80gvKQSL #NationOfMakers",
  "id" : 479293514438967296,
  "created_at" : "2014-06-18 16:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/22NQWpM2AG",
      "expanded_url" : "http:\/\/wh.gov\/maker-faire",
      "display_url" : "wh.gov\/maker-faire"
    } ]
  },
  "geo" : { },
  "id_str" : "479283297542221825",
  "text" : "RT @WHLive: Watch live: Tour the first-ever @WhiteHouse Maker Faire with President Obama \u2192 http:\/\/t.co\/22NQWpM2AG #NationOfMakers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/22NQWpM2AG",
        "expanded_url" : "http:\/\/wh.gov\/maker-faire",
        "display_url" : "wh.gov\/maker-faire"
      } ]
    },
    "geo" : { },
    "id_str" : "479282970469990401",
    "text" : "Watch live: Tour the first-ever @WhiteHouse Maker Faire with President Obama \u2192 http:\/\/t.co\/22NQWpM2AG #NationOfMakers",
    "id" : 479282970469990401,
    "created_at" : "2014-06-18 15:22:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479283297542221825,
  "created_at" : "2014-06-18 15:23:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/479252728493772800\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/z1PNY4Ytpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqal0KXCAAAv5Iz.jpg",
      "id_str" : "479252725914271744",
      "id" : 479252725914271744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqal0KXCAAAv5Iz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/z1PNY4Ytpf"
    } ],
    "hashtags" : [ {
      "text" : "robots",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "NationOfMakers",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479277938668752897",
  "text" : "RT @whitehouseostp: These girls make #robots. #NationOfMakers http:\/\/t.co\/z1PNY4Ytpf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/479252728493772800\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/z1PNY4Ytpf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqal0KXCAAAv5Iz.jpg",
        "id_str" : "479252725914271744",
        "id" : 479252725914271744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqal0KXCAAAv5Iz.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/z1PNY4Ytpf"
      } ],
      "hashtags" : [ {
        "text" : "robots",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "NationOfMakers",
        "indices" : [ 26, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479252728493772800",
    "text" : "These girls make #robots. #NationOfMakers http:\/\/t.co\/z1PNY4Ytpf",
    "id" : 479252728493772800,
    "created_at" : "2014-06-18 13:22:09 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 479277938668752897,
  "created_at" : "2014-06-18 15:02:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/OQtL0MdytG",
      "expanded_url" : "https:\/\/vine.co\/u\/944054069482373120",
      "display_url" : "vine.co\/u\/944054069482\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "479277095131299840",
  "text" : "At 11am ET, watch President Obama tour the 1st-ever White House Maker Faire: http:\/\/t.co\/b4tqL3oo0v https:\/\/t.co\/OQtL0MdytG #NationOfMakers",
  "id" : 479277095131299840,
  "created_at" : "2014-06-18 14:58:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheScienceGuy\/status\/479258763761680386\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/erpVMefpia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqarTdlCAAEfh4D.jpg",
      "id_str" : "479258761207349249",
      "id" : 479258761207349249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqarTdlCAAEfh4D.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/erpVMefpia"
    } ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479272657360146433",
  "text" : "RT @TheScienceGuy: Let's create a future of efficient manufacture and lead the world.#NationOfMakers http:\/\/t.co\/erpVMefpia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheScienceGuy\/status\/479258763761680386\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/erpVMefpia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqarTdlCAAEfh4D.jpg",
        "id_str" : "479258761207349249",
        "id" : 479258761207349249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqarTdlCAAEfh4D.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/erpVMefpia"
      } ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 66, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479258763761680386",
    "text" : "Let's create a future of efficient manufacture and lead the world.#NationOfMakers http:\/\/t.co\/erpVMefpia",
    "id" : 479258763761680386,
    "created_at" : "2014-06-18 13:46:08 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 479272657360146433,
  "created_at" : "2014-06-18 14:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 62, 73 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/pCgJ2UJRA1",
      "expanded_url" : "http:\/\/wh.gov\/maker-faire",
      "display_url" : "wh.gov\/maker-faire"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XD7tcmalXY",
      "expanded_url" : "https:\/\/vine.co\/v\/MTB5qhJFKl3",
      "display_url" : "vine.co\/v\/MTB5qhJFKl3"
    } ]
  },
  "geo" : { },
  "id_str" : "479271491004268544",
  "text" : "RT @WHLive: Banana piano?\nRobotic giraffe?\nTune in now to the @WhiteHouse Maker Faire: http:\/\/t.co\/pCgJ2UJRA1 https:\/\/t.co\/XD7tcmalXY #Nati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 50, 61 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/pCgJ2UJRA1",
        "expanded_url" : "http:\/\/wh.gov\/maker-faire",
        "display_url" : "wh.gov\/maker-faire"
      }, {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/XD7tcmalXY",
        "expanded_url" : "https:\/\/vine.co\/v\/MTB5qhJFKl3",
        "display_url" : "vine.co\/v\/MTB5qhJFKl3"
      } ]
    },
    "geo" : { },
    "id_str" : "479271058546384896",
    "text" : "Banana piano?\nRobotic giraffe?\nTune in now to the @WhiteHouse Maker Faire: http:\/\/t.co\/pCgJ2UJRA1 https:\/\/t.co\/XD7tcmalXY #NationOfMakers",
    "id" : 479271058546384896,
    "created_at" : "2014-06-18 14:34:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 479271491004268544,
  "created_at" : "2014-06-18 14:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "HuffPost Live",
      "screen_name" : "HuffPostLive",
      "indices" : [ 108, 121 ],
      "id_str" : "278093318",
      "id" : 278093318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479268497122271232",
  "text" : "RT @LaborSec: Today at 10:30am ET I'll be taking your questions on how to help working #FamiliesSucceed via @HuffPostLive. Watch: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Live",
        "screen_name" : "HuffPostLive",
        "indices" : [ 94, 107 ],
        "id_str" : "278093318",
        "id" : 278093318
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 73, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/HDOVyAQaWq",
        "expanded_url" : "http:\/\/huff.lv\/1vAkGxw",
        "display_url" : "huff.lv\/1vAkGxw"
      } ]
    },
    "geo" : { },
    "id_str" : "479256452628873217",
    "text" : "Today at 10:30am ET I'll be taking your questions on how to help working #FamiliesSucceed via @HuffPostLive. Watch: http:\/\/t.co\/HDOVyAQaWq",
    "id" : 479256452628873217,
    "created_at" : "2014-06-18 13:36:57 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 479268497122271232,
  "created_at" : "2014-06-18 14:24:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/479251792677834752\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/8XfvX9OHLe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqak9y6CcAAYnx7.jpg",
      "id_str" : "479251791905714176",
      "id" : 479251791905714176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqak9y6CcAAYnx7.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8XfvX9OHLe"
    } ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/xw80gvKQSL",
      "expanded_url" : "http:\/\/wh.gov\/maker-faire",
      "display_url" : "wh.gov\/maker-faire"
    } ]
  },
  "geo" : { },
  "id_str" : "479251792677834752",
  "text" : "Tune in for the first-ever White House Maker Faire starting at 10am ET: http:\/\/t.co\/xw80gvKQSL #NationOfMakers http:\/\/t.co\/8XfvX9OHLe",
  "id" : 479251792677834752,
  "created_at" : "2014-06-18 13:18:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 110, 125 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/hHeVUweJ8u",
      "expanded_url" : "http:\/\/wh.gov\/lHSxW",
      "display_url" : "wh.gov\/lHSxW"
    } ]
  },
  "geo" : { },
  "id_str" : "479247275068125184",
  "text" : "\u201CI call upon all Americans to\u2026encourage a new generation of makers.\u201D \u2014President Obama: http:\/\/t.co\/hHeVUweJ8u #NationOfMakers #MadeInAmerica",
  "id" : 479247275068125184,
  "created_at" : "2014-06-18 13:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 92, 103 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479246484731600896",
  "text" : "RT @whitehouseostp: The makers have arrived! Giving a final shine to a biodiesel car on the @WhiteHouse driveway. #NationOfMakers http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 72, 83 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/479246407446970369\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/VNnjh889zG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqagDw4CQAAkEn1.jpg",
        "id_str" : "479246396881518592",
        "id" : 479246396881518592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqagDw4CQAAkEn1.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VNnjh889zG"
      } ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 94, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479246407446970369",
    "text" : "The makers have arrived! Giving a final shine to a biodiesel car on the @WhiteHouse driveway. #NationOfMakers http:\/\/t.co\/VNnjh889zG",
    "id" : 479246407446970369,
    "created_at" : "2014-06-18 12:57:02 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 479246484731600896,
  "created_at" : "2014-06-18 12:57:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/479013579090571264\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/92Gx3kYeB4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqXMT8WCUAAOCKu.jpg",
      "id_str" : "479013578372960256",
      "id" : 479013578372960256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqXMT8WCUAAOCKu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/92Gx3kYeB4"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 70, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/UEsfJp9LbU",
      "expanded_url" : "http:\/\/go.wh.gov\/9XUAGv",
      "display_url" : "go.wh.gov\/9XUAGv"
    } ]
  },
  "geo" : { },
  "id_str" : "479013579090571264",
  "text" : "Entrepreneurship in American manufacturing = \u2191\nhttp:\/\/t.co\/UEsfJp9LbU #MadeInAmerica http:\/\/t.co\/92Gx3kYeB4",
  "id" : 479013579090571264,
  "created_at" : "2014-06-17 21:31:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "indices" : [ 3, 10 ],
      "id_str" : "2525192749",
      "id" : 2525192749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/bDKETjtjjs",
      "expanded_url" : "http:\/\/wh.gov\/lHSxW",
      "display_url" : "wh.gov\/lHSxW"
    } ]
  },
  "geo" : { },
  "id_str" : "479008741451628544",
  "text" : "RT @Phil44: \u201CI, BARACK OBAMA, President of the United States ... proclaim June 18 as National Day of Making.\u201D http:\/\/t.co\/bDKETjtjjs #Natio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/bDKETjtjjs",
        "expanded_url" : "http:\/\/wh.gov\/lHSxW",
        "display_url" : "wh.gov\/lHSxW"
      } ]
    },
    "geo" : { },
    "id_str" : "479007204331122689",
    "text" : "\u201CI, BARACK OBAMA, President of the United States ... proclaim June 18 as National Day of Making.\u201D http:\/\/t.co\/bDKETjtjjs #NationOfMakers",
    "id" : 479007204331122689,
    "created_at" : "2014-06-17 21:06:31 +0000",
    "user" : {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "protected" : false,
      "id_str" : "2525192749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470938302095183874\/eFAyUNAe_normal.jpeg",
      "id" : 2525192749,
      "verified" : true
    }
  },
  "id" : 479008741451628544,
  "created_at" : "2014-06-17 21:12:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OurOcean2014",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/JXlGguak0N",
      "expanded_url" : "http:\/\/youtu.be\/QTLDfGQKxA0",
      "display_url" : "youtu.be\/QTLDfGQKxA0"
    } ]
  },
  "geo" : { },
  "id_str" : "479003990710288384",
  "text" : "RT @StateDept: President Obama delivered a video address to #OurOcean2014 this morning. Watch it here: http:\/\/t.co\/JXlGguak0N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OurOcean2014",
        "indices" : [ 45, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/JXlGguak0N",
        "expanded_url" : "http:\/\/youtu.be\/QTLDfGQKxA0",
        "display_url" : "youtu.be\/QTLDfGQKxA0"
      } ]
    },
    "geo" : { },
    "id_str" : "478999220355997696",
    "text" : "President Obama delivered a video address to #OurOcean2014 this morning. Watch it here: http:\/\/t.co\/JXlGguak0N",
    "id" : 478999220355997696,
    "created_at" : "2014-06-17 20:34:48 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 479003990710288384,
  "created_at" : "2014-06-17 20:53:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478986715114135552\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/AQP06akS6S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWyypfCIAAfFxQ.jpg",
      "id_str" : "478985518584045568",
      "id" : 478985518584045568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWyypfCIAAfFxQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AQP06akS6S"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478986715114135552",
  "text" : "FACT: More businesses are actively considering bringing production back from China to the U.S. #MadeInAmerica http:\/\/t.co\/AQP06akS6S",
  "id" : 478986715114135552,
  "created_at" : "2014-06-17 19:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478977898645188610\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vo71evWvZG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWpSrVCcAEBp8k.jpg",
      "id_str" : "478975073718530049",
      "id" : 478975073718530049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWpSrVCcAEBp8k.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vo71evWvZG"
    } ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/d9ly4dvU6C",
      "expanded_url" : "http:\/\/wh.gov\/makerfaire",
      "display_url" : "wh.gov\/makerfaire"
    } ]
  },
  "geo" : { },
  "id_str" : "478977898645188610",
  "text" : "Everything you need to know for tomorrow\u2019s 1st-ever White House Maker Faire \u2192 http:\/\/t.co\/d9ly4dvU6C #NationOfMakers http:\/\/t.co\/vo71evWvZG",
  "id" : 478977898645188610,
  "created_at" : "2014-06-17 19:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478970163916963840",
  "text" : "RT @WHLive: \"Eisenhower worked with Democrats to build an Interstate Highway System. Research and development didn't used to be partisan.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478970123983028224",
    "text" : "\"Eisenhower worked with Democrats to build an Interstate Highway System. Research and development didn't used to be partisan.\" \u2014Obama",
    "id" : 478970123983028224,
    "created_at" : "2014-06-17 18:39:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 478970163916963840,
  "created_at" : "2014-06-17 18:39:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478969677218336768",
  "text" : "\"We've got $2 trillion worth of deferred maintenance.\" \u2014Obama on why Congress should invest in fixing our roads and bridges #RebuildAmerica",
  "id" : 478969677218336768,
  "created_at" : "2014-06-17 18:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechShop",
      "screen_name" : "techshop",
      "indices" : [ 67, 76 ],
      "id_str" : "86150666",
      "id" : 86150666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478968240291717121\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0V9s7lO70O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWjE3TCUAE5TKl.png",
      "id_str" : "478968239343423489",
      "id" : 478968239343423489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWjE3TCUAE5TKl.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0V9s7lO70O"
    } ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xw80gvKQSL",
      "expanded_url" : "http:\/\/wh.gov\/maker-faire",
      "display_url" : "wh.gov\/maker-faire"
    } ]
  },
  "geo" : { },
  "id_str" : "478968240291717121",
  "text" : "\"I'm a big believer in our kids making stuff.\" \u2014President Obama at @TechShop: http:\/\/t.co\/xw80gvKQSL #NationOfMakers http:\/\/t.co\/0V9s7lO70O",
  "id" : 478968240291717121,
  "created_at" : "2014-06-17 18:31:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478964910677065730\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/toYHjPHecg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWgDB0CAAA0UfA.png",
      "id_str" : "478964909271547904",
      "id" : 478964909271547904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWgDB0CAAA0UfA.png",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/toYHjPHecg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478964910677065730",
  "text" : "\"Our middle class was built in part because unions were able to negotiate weekends &amp; overtime &amp; benefits.\" \u2014Obama http:\/\/t.co\/toYHjPHecg",
  "id" : 478964910677065730,
  "created_at" : "2014-06-17 18:18:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechShop",
      "screen_name" : "techshop",
      "indices" : [ 107, 116 ],
      "id_str" : "86150666",
      "id" : 86150666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478961748570296320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/oaGpNyBRA3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWdLArCYAAS8k7.png",
      "id_str" : "478961747869458432",
      "id" : 478961747869458432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWdLArCYAAS8k7.png",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oaGpNyBRA3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478961748570296320",
  "text" : "\"A lot of companies are realizing that family-friendly policies end up being good for business.\" \u2014Obama at @TechShop http:\/\/t.co\/oaGpNyBRA3",
  "id" : 478961748570296320,
  "created_at" : "2014-06-17 18:05:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478958785336471552",
  "text" : "\"I want to make sure that if you work hard in this country\u2026you can make it.\" \u2014Obama on investing in American manufacturing #MadeInAmerica",
  "id" : 478958785336471552,
  "created_at" : "2014-06-17 17:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/478956806409306112\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yXdi2aVJIw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWYrUpCAAA8012.jpg",
      "id_str" : "478956805427429376",
      "id" : 478956805427429376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWYrUpCAAA8012.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yXdi2aVJIw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478956806409306112",
  "text" : "\"We've made enormous progress over the last several years in revitalizing American manufacturing.\" \u2014President Obama http:\/\/t.co\/yXdi2aVJIw",
  "id" : 478956806409306112,
  "created_at" : "2014-06-17 17:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechShop",
      "screen_name" : "techshop",
      "indices" : [ 75, 84 ],
      "id_str" : "86150666",
      "id" : 86150666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/jChLqPciTR",
      "expanded_url" : "http:\/\/go.wh.gov\/WWpxSe",
      "display_url" : "go.wh.gov\/WWpxSe"
    } ]
  },
  "geo" : { },
  "id_str" : "478955844629852160",
  "text" : "Watch live: President Obama speaks at a town hall on U.S. manufacturing at @TechShop in Pittsburgh \u2192 http:\/\/t.co\/jChLqPciTR #MadeInAmerica",
  "id" : 478955844629852160,
  "created_at" : "2014-06-17 17:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechShop",
      "screen_name" : "techshop",
      "indices" : [ 73, 82 ],
      "id_str" : "86150666",
      "id" : 86150666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "478953879594610688",
  "text" : "At 1:45pm ET, President Obama holds a town hall on U.S. manufacturing at @TechShop in Pittsburgh \u2192 http:\/\/t.co\/b4tqL3oo0v #MadeInAmerica",
  "id" : 478953879594610688,
  "created_at" : "2014-06-17 17:34:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WkeTXqPLvE",
      "expanded_url" : "http:\/\/www.wh.gov\/makerfaire",
      "display_url" : "wh.gov\/makerfaire"
    } ]
  },
  "geo" : { },
  "id_str" : "478952320534056961",
  "text" : "RT @whitehouseostp: TOMORROW! White House Maker Faire + National Day of Making. What'll you make? #NationOfMakers http:\/\/t.co\/WkeTXqPLvE ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Phil44\/status\/478618011608563713\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/qfLIoqpvPQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqRkixnCcAAUXt2.jpg",
        "id_str" : "478618009003520000",
        "id" : 478618009003520000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqRkixnCcAAUXt2.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/qfLIoqpvPQ"
      } ],
      "hashtags" : [ {
        "text" : "NationOfMakers",
        "indices" : [ 78, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/WkeTXqPLvE",
        "expanded_url" : "http:\/\/www.wh.gov\/makerfaire",
        "display_url" : "wh.gov\/makerfaire"
      } ]
    },
    "geo" : { },
    "id_str" : "478944375150772224",
    "text" : "TOMORROW! White House Maker Faire + National Day of Making. What'll you make? #NationOfMakers http:\/\/t.co\/WkeTXqPLvE http:\/\/t.co\/qfLIoqpvPQ",
    "id" : 478944375150772224,
    "created_at" : "2014-06-17 16:56:52 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 478952320534056961,
  "created_at" : "2014-06-17 17:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478945247586553856\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/gQgT6YSryB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWLXifCcAEGkQK.png",
      "id_str" : "478942171895066625",
      "id" : 478942171895066625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWLXifCcAEGkQK.png",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 905
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 905
      } ],
      "display_url" : "pic.twitter.com\/gQgT6YSryB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wj1pYH3ERZ",
      "expanded_url" : "http:\/\/go.wh.gov\/nszk3b",
      "display_url" : "go.wh.gov\/nszk3b"
    } ]
  },
  "geo" : { },
  "id_str" : "478945247586553856",
  "text" : "President Obama on the apprehension of Ahmed Abu Khatallah \u2192 http:\/\/t.co\/wj1pYH3ERZ http:\/\/t.co\/gQgT6YSryB",
  "id" : 478945247586553856,
  "created_at" : "2014-06-17 17:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478940373847666688\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/AeU0P6t7mL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqWJu0kCAAALGAl.jpg",
      "id_str" : "478940372861583360",
      "id" : 478940372861583360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqWJu0kCAAALGAl.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AeU0P6t7mL"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/UEsfJp9LbU",
      "expanded_url" : "http:\/\/go.wh.gov\/9XUAGv",
      "display_url" : "go.wh.gov\/9XUAGv"
    } ]
  },
  "geo" : { },
  "id_str" : "478940373847666688",
  "text" : "RT to spread the word: American manufacturing is on the rise. http:\/\/t.co\/UEsfJp9LbU #MadeInAmerica http:\/\/t.co\/AeU0P6t7mL",
  "id" : 478940373847666688,
  "created_at" : "2014-06-17 16:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Cook",
      "screen_name" : "tim_cook",
      "indices" : [ 3, 12 ],
      "id_str" : "1636590253",
      "id" : 1636590253
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 24, 35 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "ENDA",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478926765336051712",
  "text" : "RT @tim_cook: I applaud @WhiteHouse decision to ban #LGBT discrimination at fed contractors. House must act on #ENDA.  A matter of basic hu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 38, 43 ]
      }, {
        "text" : "ENDA",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478915599838355456",
    "text" : "I applaud @WhiteHouse decision to ban #LGBT discrimination at fed contractors. House must act on #ENDA.  A matter of basic human dignity.",
    "id" : 478915599838355456,
    "created_at" : "2014-06-17 15:02:31 +0000",
    "user" : {
      "name" : "Tim Cook",
      "screen_name" : "tim_cook",
      "protected" : false,
      "id_str" : "1636590253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000483764274\/ebce94fb34c055f3dc238627a576d251_normal.jpeg",
      "id" : 1636590253,
      "verified" : true
    }
  },
  "id" : 478926765336051712,
  "created_at" : "2014-06-17 15:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OurOcean2014",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qjofd8xE2c",
      "expanded_url" : "http:\/\/wapo.st\/1lAaaCM",
      "display_url" : "wapo.st\/1lAaaCM"
    } ]
  },
  "geo" : { },
  "id_str" : "478923168716185600",
  "text" : "Spread the word: President Obama's taking steps to protect some of our most precious marine landscapes: http:\/\/t.co\/qjofd8xE2c #OurOcean2014",
  "id" : 478923168716185600,
  "created_at" : "2014-06-17 15:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 73, 83 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478914940754223104",
  "text" : "RT @StateDept: Starting at 11am ET: Charting a Path Forward panel led by @JohnKerry announces new commitments. Watch: http:\/\/t.co\/GSAmc4wvr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 58, 68 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OurOcean2014",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/GSAmc4wvrJ",
        "expanded_url" : "http:\/\/state.gov\/ourocean",
        "display_url" : "state.gov\/ourocean"
      } ]
    },
    "geo" : { },
    "id_str" : "478914089301729280",
    "text" : "Starting at 11am ET: Charting a Path Forward panel led by @JohnKerry announces new commitments. Watch: http:\/\/t.co\/GSAmc4wvrJ. #OurOcean2014",
    "id" : 478914089301729280,
    "created_at" : "2014-06-17 14:56:31 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 478914940754223104,
  "created_at" : "2014-06-17 14:59:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 54, 63 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/gFoBmSAPlI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G8pBqsYPZjE&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=G8pBqs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478907777470185472",
  "text" : "RT @VP: Behind the scenes video \u2192 VP Biden visits the @ussoccer team's locker room at the #WorldCup. http:\/\/t.co\/gFoBmSAPlI #USMNT #GoTeamU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 46, 55 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "USMNT",
        "indices" : [ 116, 122 ]
      }, {
        "text" : "GoTeamUSA",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/gFoBmSAPlI",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G8pBqsYPZjE&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=G8pBqs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "478897639136985088",
    "text" : "Behind the scenes video \u2192 VP Biden visits the @ussoccer team's locker room at the #WorldCup. http:\/\/t.co\/gFoBmSAPlI #USMNT #GoTeamUSA",
    "id" : 478897639136985088,
    "created_at" : "2014-06-17 13:51:09 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 478907777470185472,
  "created_at" : "2014-06-17 14:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 20, 29 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "HuffPost Live",
      "screen_name" : "HuffPostLive",
      "indices" : [ 89, 102 ],
      "id_str" : "278093318",
      "id" : 278093318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkingFamilies",
      "indices" : [ 68, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/pF5Y6qIoTS",
      "expanded_url" : "http:\/\/1.usa.gov\/1paqCcs",
      "display_url" : "1.usa.gov\/1paqCcs"
    } ]
  },
  "geo" : { },
  "id_str" : "478903950813700096",
  "text" : "RT @USDOL: Tune in: @LaborSec takes your questions on issues facing #WorkingFamilies via @HuffPostLive: http:\/\/t.co\/pF5Y6qIoTS http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 9, 18 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "HuffPost Live",
        "screen_name" : "HuffPostLive",
        "indices" : [ 78, 91 ],
        "id_str" : "278093318",
        "id" : 278093318
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/478667862010499072\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/eUXzFWMMev",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSR4fjCcAAwKzU.png",
        "id_str" : "478667860135276544",
        "id" : 478667860135276544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSR4fjCcAAwKzU.png",
        "sizes" : [ {
          "h" : 507,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 866,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 888,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/eUXzFWMMev"
      } ],
      "hashtags" : [ {
        "text" : "WorkingFamilies",
        "indices" : [ 57, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/pF5Y6qIoTS",
        "expanded_url" : "http:\/\/1.usa.gov\/1paqCcs",
        "display_url" : "1.usa.gov\/1paqCcs"
      } ]
    },
    "geo" : { },
    "id_str" : "478667862010499072",
    "text" : "Tune in: @LaborSec takes your questions on issues facing #WorkingFamilies via @HuffPostLive: http:\/\/t.co\/pF5Y6qIoTS http:\/\/t.co\/eUXzFWMMev",
    "id" : 478667862010499072,
    "created_at" : "2014-06-16 22:38:06 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 478903950813700096,
  "created_at" : "2014-06-17 14:16:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478890317996105728",
  "text" : "Our thoughts and prayers are with the families of 3 Israeli teens who were kidnapped last week. May they be reunited with their sons soon.",
  "id" : 478890317996105728,
  "created_at" : "2014-06-17 13:22:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 52, 61 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/478719743747043328\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/xE9FkYR3hv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqTBEP9CYAAvzOy.png",
      "id_str" : "478719739154292736",
      "id" : 478719739154292736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqTBEP9CYAAvzOy.png",
      "sizes" : [ {
        "h" : 755,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 988,
        "resize" : "fit",
        "w" : 1340
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xE9FkYR3hv"
    } ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/wdVABpotkX",
      "expanded_url" : "http:\/\/instagram.com\/p\/pU9PNHFwR4\/",
      "display_url" : "instagram.com\/p\/pU9PNHFwR4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "478728478700077056",
  "text" : "RT @VP: One nation. One team. Keep making us proud, @ussoccer!  #WorldCup #GoTeamUSA #USMNT http:\/\/t.co\/wdVABpotkX http:\/\/t.co\/xE9FkYR3hv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 44, 53 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/478719743747043328\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/xE9FkYR3hv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqTBEP9CYAAvzOy.png",
        "id_str" : "478719739154292736",
        "id" : 478719739154292736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqTBEP9CYAAvzOy.png",
        "sizes" : [ {
          "h" : 755,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 988,
          "resize" : "fit",
          "w" : 1340
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xE9FkYR3hv"
      } ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 56, 65 ]
      }, {
        "text" : "GoTeamUSA",
        "indices" : [ 66, 76 ]
      }, {
        "text" : "USMNT",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/wdVABpotkX",
        "expanded_url" : "http:\/\/instagram.com\/p\/pU9PNHFwR4\/",
        "display_url" : "instagram.com\/p\/pU9PNHFwR4\/"
      } ]
    },
    "geo" : { },
    "id_str" : "478719743747043328",
    "text" : "One nation. One team. Keep making us proud, @ussoccer!  #WorldCup #GoTeamUSA #USMNT http:\/\/t.co\/wdVABpotkX http:\/\/t.co\/xE9FkYR3hv",
    "id" : 478719743747043328,
    "created_at" : "2014-06-17 02:04:15 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 478728478700077056,
  "created_at" : "2014-06-17 02:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 3, 12 ],
      "id_str" : "7563792",
      "id" : 7563792
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 29, 32 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ussoccer\/status\/478693620552589312\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/K0XttdUsOz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSpT5NCAAA8rxV.jpg",
      "id_str" : "478693619646201856",
      "id" : 478693619646201856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSpT5NCAAA8rxV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/K0XttdUsOz"
    } ],
    "hashtags" : [ {
      "text" : "USMNT",
      "indices" : [ 47, 53 ]
    }, {
      "text" : "OneNationOneTeam",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478695273892302848",
  "text" : "RT @ussoccer: After the win, @VP addresses the #USMNT in the locker room. #OneNationOneTeam http:\/\/t.co\/K0XttdUsOz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 15, 18 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ussoccer\/status\/478693620552589312\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/K0XttdUsOz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSpT5NCAAA8rxV.jpg",
        "id_str" : "478693619646201856",
        "id" : 478693619646201856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSpT5NCAAA8rxV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/K0XttdUsOz"
      } ],
      "hashtags" : [ {
        "text" : "USMNT",
        "indices" : [ 33, 39 ]
      }, {
        "text" : "OneNationOneTeam",
        "indices" : [ 60, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478693620552589312",
    "text" : "After the win, @VP addresses the #USMNT in the locker room. #OneNationOneTeam http:\/\/t.co\/K0XttdUsOz",
    "id" : 478693620552589312,
    "created_at" : "2014-06-17 00:20:27 +0000",
    "user" : {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "protected" : false,
      "id_str" : "7563792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704355346622586884\/oGZUl3xk_normal.jpg",
      "id" : 7563792,
      "verified" : true
    }
  },
  "id" : 478695273892302848,
  "created_at" : "2014-06-17 00:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 15, 24 ],
      "id_str" : "7563792",
      "id" : 7563792
    }, {
      "name" : "Clint Dempsey",
      "screen_name" : "clint_dempsey",
      "indices" : [ 43, 57 ],
      "id_str" : "431429137",
      "id" : 431429137
    }, {
      "name" : "John Anthony Brooks",
      "screen_name" : "j_brooks25",
      "indices" : [ 62, 73 ],
      "id_str" : "2370233761",
      "id" : 2370233761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAvsGhana",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "OnToTheNextOne",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478693883107618817",
  "text" : "What a win for @USSoccer! Those goals from @Clint_Dempsey and @J_Brooks25 were amazing. You make us all proud. #USAvsGhana #OnToTheNextOne",
  "id" : 478693883107618817,
  "created_at" : "2014-06-17 00:21:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 3, 12 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAvGHA",
      "indices" : [ 38, 46 ]
    }, {
      "text" : "Chills",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "USA",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478660323134537729",
  "text" : "RT @ussoccer: Well, that was awesome. #USAvGHA #Chills #USA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAvGHA",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "Chills",
        "indices" : [ 33, 40 ]
      }, {
        "text" : "USA",
        "indices" : [ 41, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478657611039260674",
    "text" : "Well, that was awesome. #USAvGHA #Chills #USA",
    "id" : 478657611039260674,
    "created_at" : "2014-06-16 21:57:22 +0000",
    "user" : {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "protected" : false,
      "id_str" : "7563792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704355346622586884\/oGZUl3xk_normal.jpg",
      "id" : 7563792,
      "verified" : true
    }
  },
  "id" : 478660323134537729,
  "created_at" : "2014-06-16 22:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 23, 32 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/478649371014090752\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/V6TNg1i9NP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSBELBCEAA12eF.jpg",
      "id_str" : "478649369084694528",
      "id" : 478649369084694528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSBELBCEAA12eF.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/V6TNg1i9NP"
    } ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 55, 64 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "USAvGHA",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478649617052352512",
  "text" : "RT @VP: RT to wish the @USSoccer team good luck in the #WorldCup! We\u2019re rooting for you. #GoTeamUSA #USAvGHA #USMNT http:\/\/t.co\/V6TNg1i9NP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 15, 24 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/478649371014090752\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/V6TNg1i9NP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqSBELBCEAA12eF.jpg",
        "id_str" : "478649369084694528",
        "id" : 478649369084694528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqSBELBCEAA12eF.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/V6TNg1i9NP"
      } ],
      "hashtags" : [ {
        "text" : "WorldCup",
        "indices" : [ 47, 56 ]
      }, {
        "text" : "GoTeamUSA",
        "indices" : [ 81, 91 ]
      }, {
        "text" : "USAvGHA",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "USMNT",
        "indices" : [ 101, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478649371014090752",
    "text" : "RT to wish the @USSoccer team good luck in the #WorldCup! We\u2019re rooting for you. #GoTeamUSA #USAvGHA #USMNT http:\/\/t.co\/V6TNg1i9NP",
    "id" : 478649371014090752,
    "created_at" : "2014-06-16 21:24:37 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 478649617052352512,
  "created_at" : "2014-06-16 21:25:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 40, 49 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 81, 91 ]
    }, {
      "text" : "USAvGHA",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/A0gNdpIbj2",
      "expanded_url" : "https:\/\/vine.co\/v\/MIDFLvaXbDX",
      "display_url" : "vine.co\/v\/MIDFLvaXbDX"
    } ]
  },
  "geo" : { },
  "id_str" : "478646001864290304",
  "text" : "President Obama's got a message for the @USSoccer team \u2192 https:\/\/t.co\/A0gNdpIbj2 #GoTeamUSA #USAvGHA #WorldCup #USMNT",
  "id" : 478646001864290304,
  "created_at" : "2014-06-16 21:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 31, 49 ]
    }, {
      "text" : "ActOnCIR",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/SXn6Os1fWB",
      "expanded_url" : "http:\/\/go.wh.gov\/w9xarB",
      "display_url" : "go.wh.gov\/w9xarB"
    } ]
  },
  "geo" : { },
  "id_str" : "478640108912914432",
  "text" : "Nobel Laureates on why passing #ImmigrationReform is vital for American innovation and entrepreneurship \u2192 http:\/\/t.co\/SXn6Os1fWB #ActOnCIR",
  "id" : 478640108912914432,
  "created_at" : "2014-06-16 20:47:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UC Irvine",
      "screen_name" : "UCIrvine",
      "indices" : [ 52, 61 ],
      "id_str" : "19669207",
      "id" : 19669207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9Ff5F5QrVn",
      "expanded_url" : "http:\/\/youtu.be\/Xjt9Pi5Dz_A",
      "display_url" : "youtu.be\/Xjt9Pi5Dz_A"
    } ]
  },
  "geo" : { },
  "id_str" : "478631681898061825",
  "text" : "\u201CThis is a fight that America must lead.\u201D \u2014Obama at @UCIrvine announcing a $1 billion competition to #ActOnClimate: http:\/\/t.co\/9Ff5F5QrVn",
  "id" : 478631681898061825,
  "created_at" : "2014-06-16 20:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/EH0WNHtlyq",
      "expanded_url" : "http:\/\/youtu.be\/Xjt9Pi5Dz_A",
      "display_url" : "youtu.be\/Xjt9Pi5Dz_A"
    } ]
  },
  "geo" : { },
  "id_str" : "478618036249694208",
  "text" : "\u201CCan you imagine a more worthy goal\u2026than protecting the world we leave to our children?\u201D \u2014Obama: http:\/\/t.co\/EH0WNHtlyq #ActOnClimate",
  "id" : 478618036249694208,
  "created_at" : "2014-06-16 19:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478610359751020546\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3NbeOnDdDB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqRdlfpCUAIc14o.jpg",
      "id_str" : "478610359138275330",
      "id" : 478610359138275330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqRdlfpCUAIc14o.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/3NbeOnDdDB"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aClPfoVKBw",
      "expanded_url" : "http:\/\/go.wh.gov\/yGT5L6",
      "display_url" : "go.wh.gov\/yGT5L6"
    } ]
  },
  "geo" : { },
  "id_str" : "478610359751020546",
  "text" : "\u201CCynicism is a choice. Hope is a better choice.\u201D \u2014Obama on why it's time to #ActOnClimate: http:\/\/t.co\/aClPfoVKBw http:\/\/t.co\/3NbeOnDdDB",
  "id" : 478610359751020546,
  "created_at" : "2014-06-16 18:49:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478600404456833024",
  "text" : "RT if you agree: Banning federal contractors from discriminating against #LGBT workers is the right thing to do for America and our economy.",
  "id" : 478600404456833024,
  "created_at" : "2014-06-16 18:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/h6YoCAim9g",
      "expanded_url" : "http:\/\/ti.me\/1jue1NL",
      "display_url" : "ti.me\/1jue1NL"
    } ]
  },
  "geo" : { },
  "id_str" : "478591643646300160",
  "text" : "Every American worker should be treated with dignity regardless of their sexual orientation or gender identity \u2192 http:\/\/t.co\/h6YoCAim9g",
  "id" : 478591643646300160,
  "created_at" : "2014-06-16 17:35:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478587520192884736",
  "text" : "Share the news: President Obama will prohibit federal contractors from discriminating on the basis of sexual orientation or gender identity.",
  "id" : 478587520192884736,
  "created_at" : "2014-06-16 17:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 12, 22 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 108, 127 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GxMT1d6xiS",
      "expanded_url" : "http:\/\/nyti.ms\/1kWPtkR",
      "display_url" : "nyti.ms\/1kWPtkR"
    } ]
  },
  "geo" : { },
  "id_str" : "478550161220968448",
  "text" : "Great news: @Starbucks will provide free college tuition to thousands of employees \u2192 http:\/\/t.co\/GxMT1d6xiS #CollegeOpportunity #ReachHigher",
  "id" : 478550161220968448,
  "created_at" : "2014-06-16 14:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 33, 43 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478538236818489344",
  "text" : "RT @vj44: Huge announcement from @Starbucks - giving workers the opportunity to finish college &amp; reach their American dream: http:\/\/t.co\/y6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Starbucks Coffee",
        "screen_name" : "Starbucks",
        "indices" : [ 23, 33 ],
        "id_str" : "30973",
        "id" : 30973
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/y6UIFv1jfW",
        "expanded_url" : "http:\/\/nyti.ms\/1kWPtkR",
        "display_url" : "nyti.ms\/1kWPtkR"
      } ]
    },
    "geo" : { },
    "id_str" : "478525365397508096",
    "text" : "Huge announcement from @Starbucks - giving workers the opportunity to finish college &amp; reach their American dream: http:\/\/t.co\/y6UIFv1jfW",
    "id" : 478525365397508096,
    "created_at" : "2014-06-16 13:11:52 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 478538236818489344,
  "created_at" : "2014-06-16 14:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cfCLA5wXQd",
      "expanded_url" : "http:\/\/youtu.be\/70wsOvkZUMA",
      "display_url" : "youtu.be\/70wsOvkZUMA"
    } ]
  },
  "geo" : { },
  "id_str" : "478361471764951040",
  "text" : "\u201CEvery American, including every Native American, deserves the chance to work hard and get ahead.\u201D \u2014President Obama: http:\/\/t.co\/cfCLA5wXQd",
  "id" : 478361471764951040,
  "created_at" : "2014-06-16 02:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/0LODMqXh46",
      "expanded_url" : "http:\/\/go.wh.gov\/divAQT",
      "display_url" : "go.wh.gov\/divAQT"
    } ]
  },
  "geo" : { },
  "id_str" : "478322792434126848",
  "text" : "\u201CMake a difference in your community by serving as the kind of mentor\u2026many children lack.\u201D \u2014Holder: http:\/\/t.co\/0LODMqXh46 #MyBrothersKeeper",
  "id" : 478322792434126848,
  "created_at" : "2014-06-15 23:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/478242631516835840\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/kUsXpDDL8U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqMPI3JCEAAECqV.jpg",
      "id_str" : "478242630346608640",
      "id" : 478242630346608640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqMPI3JCEAAECqV.jpg",
      "sizes" : [ {
        "h" : 661,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kUsXpDDL8U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478271585992704001",
  "text" : "RT @VP: Happy Father's Day! http:\/\/t.co\/kUsXpDDL8U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/478242631516835840\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/kUsXpDDL8U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqMPI3JCEAAECqV.jpg",
        "id_str" : "478242630346608640",
        "id" : 478242630346608640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqMPI3JCEAAECqV.jpg",
        "sizes" : [ {
          "h" : 661,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kUsXpDDL8U"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478242631516835840",
    "text" : "Happy Father's Day! http:\/\/t.co\/kUsXpDDL8U",
    "id" : 478242631516835840,
    "created_at" : "2014-06-15 18:28:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 478271585992704001,
  "created_at" : "2014-06-15 20:23:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyFathersDay",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "478220439613759488",
  "text" : "\"Dads work hard. So our country should do what we can to make sure their hard work pays off\" \u2014Obama: http:\/\/t.co\/Bqubcxrr20 #HappyFathersDay",
  "id" : 478220439613759488,
  "created_at" : "2014-06-15 17:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyFathersDay",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "478209109003476992",
  "text" : "\"What we give our fathers can never match what our fathers give us.\" \u2014President Obama: http:\/\/t.co\/Bqubcxrr20 #HappyFathersDay",
  "id" : 478209109003476992,
  "created_at" : "2014-06-15 16:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "478197768532406272",
  "text" : "Obama: \"For Michelle &amp; our girls, I try every day to be the husband &amp; father my family didn\u2019t have when I was young.\" http:\/\/t.co\/Bqubcxrr20",
  "id" : 478197768532406272,
  "created_at" : "2014-06-15 15:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/478189701161963520\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/mZjefIHaWz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLe_8GCQAAOxFy.jpg",
      "id_str" : "478189700499259392",
      "id" : 478189700499259392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLe_8GCQAAOxFy.jpg",
      "sizes" : [ {
        "h" : 761,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mZjefIHaWz"
    } ],
    "hashtags" : [ {
      "text" : "HappyFathersDay",
      "indices" : [ 12, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478192354923651073",
  "text" : "RT @FLOTUS: #HappyFathersDay, Barack! Our girls are lucky to have such a great Dad. -mo http:\/\/t.co\/mZjefIHaWz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/478189701161963520\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/mZjefIHaWz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLe_8GCQAAOxFy.jpg",
        "id_str" : "478189700499259392",
        "id" : 478189700499259392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLe_8GCQAAOxFy.jpg",
        "sizes" : [ {
          "h" : 761,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 761,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mZjefIHaWz"
      } ],
      "hashtags" : [ {
        "text" : "HappyFathersDay",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478189701161963520",
    "text" : "#HappyFathersDay, Barack! Our girls are lucky to have such a great Dad. -mo http:\/\/t.co\/mZjefIHaWz",
    "id" : 478189701161963520,
    "created_at" : "2014-06-15 14:58:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 478192354923651073,
  "created_at" : "2014-06-15 15:08:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USArmy\/status\/478182381715587072\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ICLhSPbwHy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLYVzIIEAAhCTR.jpg",
      "id_str" : "478182379467837440",
      "id" : 478182379467837440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLYVzIIEAAhCTR.jpg",
      "sizes" : [ {
        "h" : 715,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ICLhSPbwHy"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/USArmy\/status\/478182381715587072\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ICLhSPbwHy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLYV04IEAA8q3b.jpg",
      "id_str" : "478182379937599488",
      "id" : 478182379937599488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLYV04IEAA8q3b.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ICLhSPbwHy"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/USArmy\/status\/478182381715587072\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ICLhSPbwHy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLYV1XIUAAEcT9.jpg",
      "id_str" : "478182380067639296",
      "id" : 478182380067639296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLYV1XIUAAEcT9.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ICLhSPbwHy"
    } ],
    "hashtags" : [ {
      "text" : "USArmy",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "HappyFathersDay",
      "indices" : [ 41, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478191574623727616",
  "text" : "RT @USArmy: To all of the #USArmy dads - #HappyFathersDay! http:\/\/t.co\/ICLhSPbwHy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USArmy\/status\/478182381715587072\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/ICLhSPbwHy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLYVzIIEAAhCTR.jpg",
        "id_str" : "478182379467837440",
        "id" : 478182379467837440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLYVzIIEAAhCTR.jpg",
        "sizes" : [ {
          "h" : 715,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ICLhSPbwHy"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/USArmy\/status\/478182381715587072\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/ICLhSPbwHy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLYV04IEAA8q3b.jpg",
        "id_str" : "478182379937599488",
        "id" : 478182379937599488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLYV04IEAA8q3b.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ICLhSPbwHy"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/USArmy\/status\/478182381715587072\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/ICLhSPbwHy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLYV1XIUAAEcT9.jpg",
        "id_str" : "478182380067639296",
        "id" : 478182380067639296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLYV1XIUAAEcT9.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ICLhSPbwHy"
      } ],
      "hashtags" : [ {
        "text" : "USArmy",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "HappyFathersDay",
        "indices" : [ 29, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478182381715587072",
    "text" : "To all of the #USArmy dads - #HappyFathersDay! http:\/\/t.co\/ICLhSPbwHy",
    "id" : 478182381715587072,
    "created_at" : "2014-06-15 14:28:58 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 478191574623727616,
  "created_at" : "2014-06-15 15:05:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/478185191039447043\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/QlYA9B1u0y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqLVod0CUAA-C1b.jpg",
      "id_str" : "478179401629061120",
      "id" : 478179401629061120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqLVod0CUAA-C1b.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/QlYA9B1u0y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478185191039447043",
  "text" : "Happy Father's Day! http:\/\/t.co\/QlYA9B1u0y",
  "id" : 478185191039447043,
  "created_at" : "2014-06-15 14:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "478175130841915394",
  "text" : "\"There\u2019s nothing more precious in life than the time we spend with our children.\" \u2014President Obama on Father's Day: http:\/\/t.co\/Bqubcxrr20",
  "id" : 478175130841915394,
  "created_at" : "2014-06-15 14:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UC Irvine",
      "screen_name" : "UCIrvine",
      "indices" : [ 21, 30 ],
      "id_str" : "19669207",
      "id" : 19669207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477935709412933632",
  "text" : "RT @Podesta44: Today @UCIrvine POTUS announced $1b competition for communities to build resilience to climate change: http:\/\/t.co\/4HrPj8epr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UC Irvine",
        "screen_name" : "UCIrvine",
        "indices" : [ 6, 15 ],
        "id_str" : "19669207",
        "id" : 19669207
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/4HrPj8eprR",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/06\/14\/fact-sheet-national-disaster-resilience-competition",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477934343969841154",
    "text" : "Today @UCIrvine POTUS announced $1b competition for communities to build resilience to climate change: http:\/\/t.co\/4HrPj8eprR #ActOnClimate",
    "id" : 477934343969841154,
    "created_at" : "2014-06-14 22:03:21 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 477935709412933632,
  "created_at" : "2014-06-14 22:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/477926968894439424\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/mc0rYADqAP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqHwC44CIAAfbFa.jpg",
      "id_str" : "477926967895793664",
      "id" : 477926967895793664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqHwC44CIAAfbFa.jpg",
      "sizes" : [ {
        "h" : 723,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 723,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/mc0rYADqAP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477926968894439424",
  "text" : "\"That's what young people are, they're sacred.\" \u2014President Obama at the Standing Rock Sioux Tribe Reservation http:\/\/t.co\/mc0rYADqAP",
  "id" : 477926968894439424,
  "created_at" : "2014-06-14 21:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/DJRkPHnRAC",
      "expanded_url" : "http:\/\/wh.gov\/MyBrothersKeeper",
      "display_url" : "wh.gov\/MyBrothersKeep\u2026"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "477918435683229696",
  "text" : "\"If you want to be a mentor to a young man in your community, you can find out how at http:\/\/t.co\/DJRkPHnRAC\" \u2014Obama: http:\/\/t.co\/Bqubcxrr20",
  "id" : 477918435683229696,
  "created_at" : "2014-06-14 21:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "477865627659431937",
  "text" : "\"Any of us can do our part to be a mentor, a sounding board, a role model for a kid who needs one.\" \u2014President Obama: http:\/\/t.co\/Bqubcxrr20",
  "id" : 477865627659431937,
  "created_at" : "2014-06-14 17:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "477850509680734209",
  "text" : "\"I know how important it is to have a dad in your life\u2014because I grew up without my father around.\" \u2014President Obama: http:\/\/t.co\/Bqubcxrr20",
  "id" : 477850509680734209,
  "created_at" : "2014-06-14 16:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UC Irvine",
      "screen_name" : "UCIrvine",
      "indices" : [ 65, 74 ],
      "id_str" : "19669207",
      "id" : 19669207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    }, {
      "text" : "ClassOf2014",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "477834111495573504",
  "text" : "Starting soon: President Obama gives the commencement address at @UCIrvine. Watch \u2192 http:\/\/t.co\/7QUc084BX3 #ActOnClimate #ClassOf2014",
  "id" : 477834111495573504,
  "created_at" : "2014-06-14 15:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmyBDay",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/XGKQNbvuRR",
      "expanded_url" : "http:\/\/www.army.mil\/birthday\/239\/",
      "display_url" : "army.mil\/birthday\/239\/"
    } ]
  },
  "geo" : { },
  "id_str" : "477830634636079104",
  "text" : "RT @USArmy: Happy #ArmyBDay, Soldiers! \n\nThanks for serving with professionalism for 239 years: http:\/\/t.co\/XGKQNbvuRR. http:\/\/t.co\/xB4rSvE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USArmy\/status\/477829319470120960\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/xB4rSvEB19",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqGXO6GCAAEX0BQ.jpg",
        "id_str" : "477829317846499329",
        "id" : 477829317846499329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqGXO6GCAAEX0BQ.jpg",
        "sizes" : [ {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xB4rSvEB19"
      } ],
      "hashtags" : [ {
        "text" : "ArmyBDay",
        "indices" : [ 6, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/XGKQNbvuRR",
        "expanded_url" : "http:\/\/www.army.mil\/birthday\/239\/",
        "display_url" : "army.mil\/birthday\/239\/"
      } ]
    },
    "geo" : { },
    "id_str" : "477829319470120960",
    "text" : "Happy #ArmyBDay, Soldiers! \n\nThanks for serving with professionalism for 239 years: http:\/\/t.co\/XGKQNbvuRR. http:\/\/t.co\/xB4rSvEB19",
    "id" : 477829319470120960,
    "created_at" : "2014-06-14 15:06:02 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 477830634636079104,
  "created_at" : "2014-06-14 15:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyFathersDay",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "477824095048855554",
  "text" : "\"No parent who works full-time should have to raise a family in poverty.\" \u2014President Obama: http:\/\/t.co\/Bqubcxrr20 #HappyFathersDay",
  "id" : 477824095048855554,
  "created_at" : "2014-06-14 14:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Bqubcxrr20",
      "expanded_url" : "http:\/\/go.wh.gov\/xcvpwU",
      "display_url" : "go.wh.gov\/xcvpwU"
    } ]
  },
  "geo" : { },
  "id_str" : "477813465369681922",
  "text" : "\"What makes you a man isn\u2019t the ability to have a child\u2014it\u2019s the courage to raise one.\" \u2014Obama: http:\/\/t.co\/Bqubcxrr20 #MyBrothersKeeper",
  "id" : 477813465369681922,
  "created_at" : "2014-06-14 14:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndianCountry",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477572447294595072",
  "text" : "\"Every American, including every Native American, deserves the chance to work hard and get ahead.\" \u2014President Obama #IndianCountry",
  "id" : 477572447294595072,
  "created_at" : "2014-06-13 22:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndianCountry",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "477570608985677824",
  "text" : "Happening now: President Obama speaks at the Cannon Ball Flag Day Celebration \u2192 http:\/\/t.co\/7QUc084BX3 #IndianCountry",
  "id" : 477570608985677824,
  "created_at" : "2014-06-13 21:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477481905362059264",
  "text" : "Obama: \"The U.S. will do our part. But understand that ultimately it's up to the Iraqis, as a sovereign nation, to solve their problems.\"",
  "id" : 477481905362059264,
  "created_at" : "2014-06-13 16:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477481777162752000",
  "text" : "President Obama: \"Nobody has an interest in seeing terrorists gain a foothold inside of Iraq.\"",
  "id" : 477481777162752000,
  "created_at" : "2014-06-13 16:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477481655561891840",
  "text" : "\"Any action that we may take\u2026has to be joined by a serious and sincere effort by Iraq\u2019s leaders.\" \u2014President Obama",
  "id" : 477481655561891840,
  "created_at" : "2014-06-13 16:04:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "477480311581081600",
  "text" : "Watch live: President Obama speaks on the situation in Iraq \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 477480311581081600,
  "created_at" : "2014-06-13 15:59:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/bpPDIdQiWy",
      "expanded_url" : "http:\/\/go.wh.gov\/4RRFrR",
      "display_url" : "go.wh.gov\/4RRFrR"
    } ]
  },
  "geo" : { },
  "id_str" : "477474056477089792",
  "text" : "At 11:50am ET, President Obama delivers a statement on the situation in Iraq. Watch \u2192 http:\/\/t.co\/bpPDIdQiWy",
  "id" : 477474056477089792,
  "created_at" : "2014-06-13 15:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 13, 20 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HardG",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/Ej7BeV4fRI",
      "expanded_url" : "http:\/\/youtu.be\/M6soSKgW-MI",
      "display_url" : "youtu.be\/M6soSKgW-MI"
    } ]
  },
  "geo" : { },
  "id_str" : "477462500674650112",
  "text" : "At his first @Tumblr Q&amp;A, POTUS:\n1. Answered questions on education and more\n2. Took a stance on \"GIF\" #HardG\nWatch \u2192 http:\/\/t.co\/Ej7BeV4fRI",
  "id" : 477462500674650112,
  "created_at" : "2014-06-13 14:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477237296626794497",
  "text" : "RT @FLOTUS: Deeply saddened to hear of Ruby Dee's passing. I'll never forget seeing her in \"Do the Right Thing\" on my first date with Barac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477236475248246785",
    "text" : "Deeply saddened to hear of Ruby Dee's passing. I'll never forget seeing her in \"Do the Right Thing\" on my first date with Barack. -mo",
    "id" : 477236475248246785,
    "created_at" : "2014-06-12 23:50:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 477237296626794497,
  "created_at" : "2014-06-12 23:53:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "George Bush",
      "screen_name" : "GeorgeHWBush",
      "indices" : [ 43, 56 ],
      "id_str" : "475988505",
      "id" : 475988505
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/477225897767239681\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/aYgZv0dLmh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp9ybNMCEAIqmEw.jpg",
      "id_str" : "477225897246724098",
      "id" : 477225897246724098,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp9ybNMCEAIqmEw.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 953
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 953
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aYgZv0dLmh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477226122867118080",
  "text" : "RT @FLOTUS: Happy 90th birthday, President @GeorgeHWBush! http:\/\/t.co\/aYgZv0dLmh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Bush",
        "screen_name" : "GeorgeHWBush",
        "indices" : [ 31, 44 ],
        "id_str" : "475988505",
        "id" : 475988505
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/477225897767239681\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/aYgZv0dLmh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp9ybNMCEAIqmEw.jpg",
        "id_str" : "477225897246724098",
        "id" : 477225897246724098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp9ybNMCEAIqmEw.jpg",
        "sizes" : [ {
          "h" : 1100,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aYgZv0dLmh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477225897767239681",
    "text" : "Happy 90th birthday, President @GeorgeHWBush! http:\/\/t.co\/aYgZv0dLmh",
    "id" : 477225897767239681,
    "created_at" : "2014-06-12 23:08:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 477226122867118080,
  "created_at" : "2014-06-12 23:09:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Bush",
      "screen_name" : "GeorgeHWBush",
      "indices" : [ 1, 14 ],
      "id_str" : "475988505",
      "id" : 475988505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthday41",
      "indices" : [ 69, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "477061870478581760",
  "geo" : { },
  "id_str" : "477203154891595776",
  "in_reply_to_user_id" : 475988505,
  "text" : ".@GeorgeHWBush Hope you enjoyed the view, George. Wishing you a very #HappyBirthday41! -bo",
  "id" : 477203154891595776,
  "in_reply_to_status_id" : 477061870478581760,
  "created_at" : "2014-06-12 21:37:52 +0000",
  "in_reply_to_screen_name" : "GeorgeHWBush",
  "in_reply_to_user_id_str" : "475988505",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/JOO03WPAMh",
      "expanded_url" : "http:\/\/go.wh.gov\/gAziBu",
      "display_url" : "go.wh.gov\/gAziBu"
    } ]
  },
  "geo" : { },
  "id_str" : "477190380757463040",
  "text" : "Clean power plant standards are good for our health: They'll prevent up to 2,100 heart attacks in 2030. http:\/\/t.co\/JOO03WPAMh #ActOnClimate",
  "id" : 477190380757463040,
  "created_at" : "2014-06-12 20:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Abbott",
      "screen_name" : "TonyAbbottMHR",
      "indices" : [ 3, 17 ],
      "id_str" : "93766096",
      "id" : 93766096
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TonyAbbottMHR\/status\/477149654467870721\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/6lzzp9Mpkw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp8tFO2IUAAOobf.jpg",
      "id_str" : "477149653432291328",
      "id" : 477149653432291328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp8tFO2IUAAOobf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6lzzp9Mpkw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477173000689954816",
  "text" : "MT @TonyAbbottMHR: Pleasure to meet with President Obama today\u2014Australia &amp; America share an extraordinary friendship http:\/\/t.co\/6lzzp9Mpkw",
  "id" : 477173000689954816,
  "created_at" : "2014-06-12 19:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoRollback",
      "indices" : [ 97, 108 ]
    }, {
      "text" : "LunchWithFLOTUS",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477169244279697408",
  "text" : "RT @FLOTUS: Thanks so much for the questions. We all need to keep fighting for our kids' health. #NoRollback! #LunchWithFLOTUS -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoRollback",
        "indices" : [ 85, 96 ]
      }, {
        "text" : "LunchWithFLOTUS",
        "indices" : [ 98, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477165121400090624",
    "text" : "Thanks so much for the questions. We all need to keep fighting for our kids' health. #NoRollback! #LunchWithFLOTUS -mo",
    "id" : 477165121400090624,
    "created_at" : "2014-06-12 19:06:44 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 477169244279697408,
  "created_at" : "2014-06-12 19:23:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 95, 111 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    }, {
      "name" : "kynectky",
      "screen_name" : "kynectky",
      "indices" : [ 116, 125 ],
      "id_str" : "1336773938",
      "id" : 1336773938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477142210165481472",
  "text" : "RT @Simas44: Truly amazing ACA news. Kentucky cuts uninsured rate in half!! Congratulations to @GovSteveBeshear and @kynectky! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcia Snyder",
        "screen_name" : "GovSteveBeshear",
        "indices" : [ 82, 98 ],
        "id_str" : "4549215252",
        "id" : 4549215252
      }, {
        "name" : "kynectky",
        "screen_name" : "kynectky",
        "indices" : [ 103, 112 ],
        "id_str" : "1336773938",
        "id" : 1336773938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/e52KF7NN72",
        "expanded_url" : "http:\/\/bit.ly\/TOGKXD",
        "display_url" : "bit.ly\/TOGKXD"
      } ]
    },
    "geo" : { },
    "id_str" : "477141378502524928",
    "text" : "Truly amazing ACA news. Kentucky cuts uninsured rate in half!! Congratulations to @GovSteveBeshear and @kynectky! http:\/\/t.co\/e52KF7NN72",
    "id" : 477141378502524928,
    "created_at" : "2014-06-12 17:32:24 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 477142210165481472,
  "created_at" : "2014-06-12 17:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477122950194147328",
  "text" : "RT @FLOTUS: At 2:30pm ET, the First Lady will answer your questions on school nutrition and healthy lunches. Ask away using #LunchWithFLOTU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LunchWithFLOTUS",
        "indices" : [ 112, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477122895119147008",
    "text" : "At 2:30pm ET, the First Lady will answer your questions on school nutrition and healthy lunches. Ask away using #LunchWithFLOTUS.",
    "id" : 477122895119147008,
    "created_at" : "2014-06-12 16:18:57 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 477122950194147328,
  "created_at" : "2014-06-12 16:19:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "George Bush",
      "screen_name" : "GeorgeHWBush",
      "indices" : [ 18, 31 ],
      "id_str" : "475988505",
      "id" : 475988505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthday41",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477117165158813696",
  "text" : "RT @VP: President @GeorgeHWBush was a hero during WW2, and he\u2019s still a hero today. Happy birthday, 41. \u2013VP #HappyBirthday41 http:\/\/t.co\/fl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Bush",
        "screen_name" : "GeorgeHWBush",
        "indices" : [ 10, 23 ],
        "id_str" : "475988505",
        "id" : 475988505
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/477109383886024704\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/flasksDBUK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp8IdBcIUAA_sTh.png",
        "id_str" : "477109380220211200",
        "id" : 477109380220211200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp8IdBcIUAA_sTh.png",
        "sizes" : [ {
          "h" : 1176,
          "resize" : "fit",
          "w" : 1764
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/flasksDBUK"
      } ],
      "hashtags" : [ {
        "text" : "HappyBirthday41",
        "indices" : [ 100, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477109383886024704",
    "text" : "President @GeorgeHWBush was a hero during WW2, and he\u2019s still a hero today. Happy birthday, 41. \u2013VP #HappyBirthday41 http:\/\/t.co\/flasksDBUK",
    "id" : 477109383886024704,
    "created_at" : "2014-06-12 15:25:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 477117165158813696,
  "created_at" : "2014-06-12 15:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Bush",
      "screen_name" : "GeorgeHWBush",
      "indices" : [ 31, 44 ],
      "id_str" : "475988505",
      "id" : 475988505
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/477104270483804160\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/X0VeaLm6Up",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp8DzioCcAAVhqo.jpg",
      "id_str" : "477104269527511040",
      "id" : 477104269527511040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp8DzioCcAAVhqo.jpg",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/X0VeaLm6Up"
    } ],
    "hashtags" : [ {
      "text" : "HappyBirthday41",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477104270483804160",
  "text" : "Happy 90th birthday, President @GeorgeHWBush! Hope you're wearing your birthday socks. #HappyBirthday41 http:\/\/t.co\/X0VeaLm6Up",
  "id" : 477104270483804160,
  "created_at" : "2014-06-12 15:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 60, 67 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LunchWithFLOTUS",
      "indices" : [ 74, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477089131911475200",
  "text" : "Have questions on school nutrition and healthy lunches? Ask @FLOTUS using #LunchWithFLOTUS and she'll answer some at 2:30pm ET.",
  "id" : 477089131911475200,
  "created_at" : "2014-06-12 14:04:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476838370090287104",
  "text" : "RT @FLOTUS: Hey guys! Tomorrow at 2:30pm ET, I'll answer your questions on school nutrition and healthy lunches. Ask away using #LunchWithF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LunchWithFLOTUS",
        "indices" : [ 116, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476836114427154432",
    "text" : "Hey guys! Tomorrow at 2:30pm ET, I'll answer your questions on school nutrition and healthy lunches. Ask away using #LunchWithFLOTUS. -mo",
    "id" : 476836114427154432,
    "created_at" : "2014-06-11 21:19:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 476838370090287104,
  "created_at" : "2014-06-11 21:28:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476833394035138561",
  "text" : "\"If we all keep fighting to put opportunity within the reach of anyone willing to work for it, then America will be stronger.\" \u2014Obama",
  "id" : 476833394035138561,
  "created_at" : "2014-06-11 21:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476832685151629312",
  "text" : "\"Don't boo, just remember to vote.\" \u2014Obama on Senate Republicans blocking a bill that would've helped students pay back their student loans",
  "id" : 476832685151629312,
  "created_at" : "2014-06-11 21:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476832255688445952\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/9opAb3VMK6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp4MaNlCUAAI0qr.jpg",
      "id_str" : "476832255008985088",
      "id" : 476832255008985088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp4MaNlCUAAI0qr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9opAb3VMK6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476832255688445952",
  "text" : "\"We\u2019re working to help more students pay back the loans that they take out when they go to college.\" \u2014Obama http:\/\/t.co\/9opAb3VMK6",
  "id" : 476832255688445952,
  "created_at" : "2014-06-11 21:04:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476831562953011200",
  "text" : "\"We don\u2019t settle. We out-work, we out-innovate, we out-hustle the competition. And when we do, nobody can beat us.\" \u2014Obama on America",
  "id" : 476831562953011200,
  "created_at" : "2014-06-11 21:01:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476831348330463232",
  "text" : "\"Every single child should have the opportunity you\u2019ve had to go as far as their talents and hard work will take them.\" \u2014President Obama",
  "id" : 476831348330463232,
  "created_at" : "2014-06-11 21:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476830803179995136",
  "text" : "\"You\u2019re giving back to the folks who gave you so much. And whatever you do next, I hope you keep giving back.\" \u2014Obama to 2014 graduates",
  "id" : 476830803179995136,
  "created_at" : "2014-06-11 20:58:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476830467744747521",
  "text" : "\"A lot of people made an investment in you. I can\u2019t imagine a better investment.\" \u2014President Obama to the class of 2014 #OpportunityForAll",
  "id" : 476830467744747521,
  "created_at" : "2014-06-11 20:56:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476829389179469824",
  "text" : "\"I was raised by a single mom, with the help of my grandparents. We didn\u2019t have a lot of money.\" \u2014President Obama #OpportunityForAll",
  "id" : 476829389179469824,
  "created_at" : "2014-06-11 20:52:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476829090612117505",
  "text" : "\"I want you to remember that each of us is only here because somebody, somewhere invested in our success.\" \u2014Obama #OpportunityForAll",
  "id" : 476829090612117505,
  "created_at" : "2014-06-11 20:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476828304117215232",
  "text" : "\"I\u2019m here today because there is nothing ordinary about Worcester Tech or the Class of 2014.\" \u2014President Obama",
  "id" : 476828304117215232,
  "created_at" : "2014-06-11 20:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "476827298138566656",
  "text" : "Happening now: President Obama speaks at the Worcester Technical High School commencement \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 476827298138566656,
  "created_at" : "2014-06-11 20:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 42, 49 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GIF",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "ObamaIRL",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/pkri36y2K1",
      "expanded_url" : "http:\/\/go.wh.gov\/aDCwPJ",
      "display_url" : "go.wh.gov\/aDCwPJ"
    } ]
  },
  "geo" : { },
  "id_str" : "476781687364276224",
  "text" : "Yesterday, President Obama held his first @Tumblr Q&amp;A on college affordability\u2014and made his first #GIF: http:\/\/t.co\/pkri36y2K1 #ObamaIRL",
  "id" : 476781687364276224,
  "created_at" : "2014-06-11 17:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMA",
      "screen_name" : "AmerMedicalAssn",
      "indices" : [ 20, 36 ],
      "id_str" : "27922157",
      "id" : 27922157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/476742994234982400\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/IrztFbfMsd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp27OhBCAAAIL2C.jpg",
      "id_str" : "476742993626398720",
      "id" : 476742993626398720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp27OhBCAAAIL2C.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IrztFbfMsd"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476742994234982400",
  "text" : "Share the news: The @AmerMedicalAssn supports President Obama's clean power plant standards. #ActOnClimate http:\/\/t.co\/IrztFbfMsd",
  "id" : 476742994234982400,
  "created_at" : "2014-06-11 15:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476729301644378113\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Puum6xrxnj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp2uxf4CEAAsfw_.jpg",
      "id_str" : "476729300964478976",
      "id" : 476729300964478976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp2uxf4CEAAsfw_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Puum6xrxnj"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 30, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/O92s3S46jp",
      "expanded_url" : "http:\/\/go.wh.gov\/cjzxpU",
      "display_url" : "go.wh.gov\/cjzxpU"
    } ]
  },
  "geo" : { },
  "id_str" : "476729301644378113",
  "text" : "Let's keep fighting to expand #CollegeOpportunity for more Americans \u2192 http:\/\/t.co\/O92s3S46jp http:\/\/t.co\/Puum6xrxnj",
  "id" : 476729301644378113,
  "created_at" : "2014-06-11 14:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Karp",
      "screen_name" : "davidkarp",
      "indices" : [ 44, 54 ],
      "id_str" : "794329",
      "id" : 794329
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 89, 96 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/TfsB3DIQao",
      "expanded_url" : "http:\/\/go.wh.gov\/bu3SzF",
      "display_url" : "go.wh.gov\/bu3SzF"
    } ]
  },
  "geo" : { },
  "id_str" : "476563786472910849",
  "text" : "\u201CI\u2019ve never talked to a President before.\u201D \u2014@DavidKarp to President Obama during today's @Tumblr Q&amp;A: http:\/\/t.co\/TfsB3DIQao #ObamaIRL",
  "id" : 476563786472910849,
  "created_at" : "2014-06-11 03:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476505874182443008\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cQOjjHLUk8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpzjkT3CAAA4hL_.jpg",
      "id_str" : "476505873540317184",
      "id" : 476505873540317184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpzjkT3CAAA4hL_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cQOjjHLUk8"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 97, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476505874182443008",
  "text" : "Yesterday, President Obama acted to help nearly 5 million Americans pay off their student loans. #CollegeOpportunity http:\/\/t.co\/cQOjjHLUk8",
  "id" : 476505874182443008,
  "created_at" : "2014-06-10 23:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476499432154738689",
  "text" : "RT @arneduncan: Our hearts go out to the Reynolds HS community. How many more students must we lose before committing to reduce gun violenc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476483362371428352",
    "text" : "Our hearts go out to the Reynolds HS community. How many more students must we lose before committing to reduce gun violence in our schools?",
    "id" : 476483362371428352,
    "created_at" : "2014-06-10 21:57:40 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 476499432154738689,
  "created_at" : "2014-06-10 23:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Karp",
      "screen_name" : "davidkarp",
      "indices" : [ 29, 39 ],
      "id_str" : "794329",
      "id" : 794329
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/476488246424522754\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/O5UQVU23wf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpzTiPYCYAAjIbJ.png",
      "id_str" : "476488245790793728",
      "id" : 476488245790793728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpzTiPYCYAAjIbJ.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/O5UQVU23wf"
    } ],
    "hashtags" : [ {
      "text" : "GIF",
      "indices" : [ 57, 61 ]
    }, {
      "text" : "ObamaIRL",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/trvV2VyLfn",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1ILDbvl",
      "display_url" : "tmblr.co\/ZW21es1ILDbvl"
    } ]
  },
  "geo" : { },
  "id_str" : "476488246424522754",
  "text" : "In which President Obama and @DavidKarp make a fist bump #GIF \u2192 http:\/\/t.co\/trvV2VyLfn #ObamaIRL http:\/\/t.co\/O5UQVU23wf",
  "id" : 476488246424522754,
  "created_at" : "2014-06-10 22:17:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 66, 73 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "David Karp",
      "screen_name" : "davidkarp",
      "indices" : [ 87, 97 ],
      "id_str" : "794329",
      "id" : 794329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476471299037200387",
  "text" : "\"It is Sasha's birthday today!\" \u2014President Obama finishing up his @Tumblr Q&amp;A with @DavidKarp #ObamaIRL",
  "id" : 476471299037200387,
  "created_at" : "2014-06-10 21:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476470624756719616",
  "text" : "\u201CDon\u2019t get cynical. Guard against cynicism\u2026the world is less violent than it has ever been.\u201D \u2014President Obama to young Americans #ObamaIRL",
  "id" : 476470624756719616,
  "created_at" : "2014-06-10 21:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476470004742119424",
  "text" : "\"The United States does not have a monopoly on crazy people.\" \u2014President Obama on why we need legislation to prevent gun violence #ObamaIRL",
  "id" : 476470004742119424,
  "created_at" : "2014-06-10 21:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476468836225802240",
  "text" : "\u201CIf public opinion does not demand change in Congress, it will not change.\u201D \u2014President Obama on legislation to prevent gun violence",
  "id" : 476468836225802240,
  "created_at" : "2014-06-10 20:59:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 95, 102 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 135, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SQXxnDI665",
      "expanded_url" : "http:\/\/WhiteHouse.Tumblr.com",
      "display_url" : "WhiteHouse.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "476467614731206656",
  "text" : "\"Michelle, when I work out with her, she puts me to shame.\" \u2014President Obama in his first-ever @Tumblr Q&amp;A: http:\/\/t.co\/SQXxnDI665 #ObamaIRL",
  "id" : 476467614731206656,
  "created_at" : "2014-06-10 20:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476466159701987328",
  "text" : "President Obama: \u201CToo many of us see college as a box to check\u2026as opposed to an opportunity...to figure out what are we good at.\" #ObamaIRL",
  "id" : 476466159701987328,
  "created_at" : "2014-06-10 20:49:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/476464374144843776\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/g20kdXahM2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpy90qpCQAA575K.jpg",
      "id_str" : "476464373091680256",
      "id" : 476464373091680256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpy90qpCQAA575K.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g20kdXahM2"
    } ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476464374144843776",
  "text" : "\u201CA college education is the surest\u2026path into the middle class.\u201D \u2014Obama on making college more affordable #ObamaIRL http:\/\/t.co\/g20kdXahM2",
  "id" : 476464374144843776,
  "created_at" : "2014-06-10 20:42:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476463087789547520",
  "text" : "\u201CUltimately, you are going to do best at something you care deeply about.\u201D \u2014President Obama giving career advice to students #ObamaIRL",
  "id" : 476463087789547520,
  "created_at" : "2014-06-10 20:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 17, 24 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/apuVnhd3G8",
      "expanded_url" : "http:\/\/StudentAid.gov",
      "display_url" : "StudentAid.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "476461122875559936",
  "text" : "\u201CI hope that the @Tumblr community helps to spread the word.\u201D \u2014Obama on capping loan payments at 10% of your income: http:\/\/t.co\/apuVnhd3G8",
  "id" : 476461122875559936,
  "created_at" : "2014-06-10 20:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476458988406853633\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/dOK9VxjkY1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpy47K4CQAACeKS.jpg",
      "id_str" : "476458987265605632",
      "id" : 476458987265605632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpy47K4CQAACeKS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dOK9VxjkY1"
    } ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 90, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476458988406853633",
  "text" : "President Obama: \u201CIt continues to be a very smart investment to go to college.\u201D #ObamaIRL #CollegeOpportunity http:\/\/t.co\/dOK9VxjkY1",
  "id" : 476458988406853633,
  "created_at" : "2014-06-10 20:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 90, 97 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476458390659796992",
  "text" : "RT @WHLive: Obama: \u201CWe\u2019re constantly looking for new ways to reach new audiences\u2026a lot of @Tumblr users are impacted by student debt.\u201D #Oba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 78, 85 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaIRL",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476458351757635585",
    "text" : "Obama: \u201CWe\u2019re constantly looking for new ways to reach new audiences\u2026a lot of @Tumblr users are impacted by student debt.\u201D #ObamaIRL",
    "id" : 476458351757635585,
    "created_at" : "2014-06-10 20:18:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 476458390659796992,
  "created_at" : "2014-06-10 20:18:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 49, 56 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/SQXxnDI665",
      "expanded_url" : "http:\/\/WhiteHouse.Tumblr.com",
      "display_url" : "WhiteHouse.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "476457687748988928",
  "text" : "Watch live: President Obama holds his first-ever @Tumblr Q&amp;A on education \u2192 http:\/\/t.co\/SQXxnDI665 #ObamaIRL #CollegeOpportunity",
  "id" : 476457687748988928,
  "created_at" : "2014-06-10 20:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "indices" : [ 3, 19 ],
      "id_str" : "67215899",
      "id" : 67215899
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 77, 84 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 112, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476451032328048640",
  "text" : "RT @YoungInvincible: At 4pm ET, join us &amp; Pres. Obama for his first-ever @Tumblr Q&amp;A on #highered &amp; #CollegeOpportunity \u2192 http:\/\/t.co\/RPkoj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 56, 63 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 75, 84 ]
      }, {
        "text" : "CollegeOpportunity",
        "indices" : [ 91, 110 ]
      }, {
        "text" : "ObamaIRL",
        "indices" : [ 136, 145 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/RPkojR2FUf",
        "expanded_url" : "http:\/\/WhiteHouse.Tumblr.com",
        "display_url" : "WhiteHouse.Tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "476448443008057344",
    "text" : "At 4pm ET, join us &amp; Pres. Obama for his first-ever @Tumblr Q&amp;A on #highered &amp; #CollegeOpportunity \u2192 http:\/\/t.co\/RPkojR2FUf #ObamaIRL",
    "id" : 476448443008057344,
    "created_at" : "2014-06-10 19:38:55 +0000",
    "user" : {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "protected" : false,
      "id_str" : "67215899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691632503577161728\/Zj3TLgji_normal.png",
      "id" : 67215899,
      "verified" : false
    }
  },
  "id" : 476451032328048640,
  "created_at" : "2014-06-10 19:49:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Anderson",
      "screen_name" : "linds_anderson",
      "indices" : [ 3, 18 ],
      "id_str" : "19176040",
      "id" : 19176040
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/linds_anderson\/status\/476445642986758144\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/O9sOzUc8BY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpysyZLCcAA78qy.png",
      "id_str" : "476445642345050112",
      "id" : 476445642345050112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpysyZLCcAA78qy.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/O9sOzUc8BY"
    } ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/CbX9iRN46E",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/87898952028\/higher-education-is-the-most-important-investment",
      "display_url" : "whitehouse.tumblr.com\/post\/878989520\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476447970536480768",
  "text" : "RT @linds_anderson: Who's tuning into Tumblr for #ObamaIRL? Should be interesting! http:\/\/t.co\/CbX9iRN46E http:\/\/t.co\/O9sOzUc8BY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/linds_anderson\/status\/476445642986758144\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/O9sOzUc8BY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpysyZLCcAA78qy.png",
        "id_str" : "476445642345050112",
        "id" : 476445642345050112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpysyZLCcAA78qy.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/O9sOzUc8BY"
      } ],
      "hashtags" : [ {
        "text" : "ObamaIRL",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/CbX9iRN46E",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/87898952028\/higher-education-is-the-most-important-investment",
        "display_url" : "whitehouse.tumblr.com\/post\/878989520\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "476445642986758144",
    "text" : "Who's tuning into Tumblr for #ObamaIRL? Should be interesting! http:\/\/t.co\/CbX9iRN46E http:\/\/t.co\/O9sOzUc8BY",
    "id" : 476445642986758144,
    "created_at" : "2014-06-10 19:27:47 +0000",
    "user" : {
      "name" : "Lindsay Anderson",
      "screen_name" : "linds_anderson",
      "protected" : false,
      "id_str" : "19176040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675437180970381312\/-_gBxVmY_normal.png",
      "id" : 19176040,
      "verified" : false
    }
  },
  "id" : 476447970536480768,
  "created_at" : "2014-06-10 19:37:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 51, 58 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SQXxnDI665",
      "expanded_url" : "http:\/\/WhiteHouse.Tumblr.com",
      "display_url" : "WhiteHouse.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "476437304115228673",
  "text" : "At 4pm ET, join President Obama for his first-ever @Tumblr Q&amp;A on education and college affordability \u2192 http:\/\/t.co\/SQXxnDI665 #ObamaIRL",
  "id" : 476437304115228673,
  "created_at" : "2014-06-10 18:54:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Goldschmidt",
      "screen_name" : "alexandergold",
      "indices" : [ 3, 17 ],
      "id_str" : "14326874",
      "id" : 14326874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b93H6JHnNn",
      "expanded_url" : "http:\/\/instagram.com\/p\/pEpjToybaw\/",
      "display_url" : "instagram.com\/p\/pEpjToybaw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "476430899404603393",
  "text" : "RT @alexandergold: Wearing a suit today for Barack. Can't believe I'm going to #ObamaIRL with Tumblr! http:\/\/t.co\/b93H6JHnNn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaIRL",
        "indices" : [ 60, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/b93H6JHnNn",
        "expanded_url" : "http:\/\/instagram.com\/p\/pEpjToybaw\/",
        "display_url" : "instagram.com\/p\/pEpjToybaw\/"
      } ]
    },
    "geo" : { },
    "id_str" : "476422131278831617",
    "text" : "Wearing a suit today for Barack. Can't believe I'm going to #ObamaIRL with Tumblr! http:\/\/t.co\/b93H6JHnNn",
    "id" : 476422131278831617,
    "created_at" : "2014-06-10 17:54:22 +0000",
    "user" : {
      "name" : "Alex Goldschmidt",
      "screen_name" : "alexandergold",
      "protected" : false,
      "id_str" : "14326874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796448677728382976\/MB9UOiah_normal.jpg",
      "id" : 14326874,
      "verified" : true
    }
  },
  "id" : 476430899404603393,
  "created_at" : "2014-06-10 18:29:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476426230091497473\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/LrvXPKyAWg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpybIaBCAAE_UQR.jpg",
      "id_str" : "476426229319335937",
      "id" : 476426229319335937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpybIaBCAAE_UQR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LrvXPKyAWg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/O92s3S46jp",
      "expanded_url" : "http:\/\/go.wh.gov\/cjzxpU",
      "display_url" : "go.wh.gov\/cjzxpU"
    } ]
  },
  "geo" : { },
  "id_str" : "476426230091497473",
  "text" : "Here's why President Obama's fighting to make higher education more affordable \u2192 http:\/\/t.co\/O92s3S46jp http:\/\/t.co\/LrvXPKyAWg",
  "id" : 476426230091497473,
  "created_at" : "2014-06-10 18:10:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476421040059723777",
  "text" : "RT @VP: Three things we can do to grow the economy:  \n1) Invest in infrastructure  \n2) Build the most skilled workforce \n3) Pass an immigra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476417784386424832",
    "text" : "Three things we can do to grow the economy:  \n1) Invest in infrastructure  \n2) Build the most skilled workforce \n3) Pass an immigration bill",
    "id" : 476417784386424832,
    "created_at" : "2014-06-10 17:37:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 476421040059723777,
  "created_at" : "2014-06-10 17:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayAct",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476410132382097408",
  "text" : "RT @vj44: When the #EqualPayAct was signed, women earned 59\u00A2 for every $1 a man made. Today it\u2019s 77\u00A2 &amp; Pres Obama continues to fight for #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayAct",
        "indices" : [ 9, 21 ]
      }, {
        "text" : "equalwages",
        "indices" : [ 131, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476408202008223744",
    "text" : "When the #EqualPayAct was signed, women earned 59\u00A2 for every $1 a man made. Today it\u2019s 77\u00A2 &amp; Pres Obama continues to fight for #equalwages",
    "id" : 476408202008223744,
    "created_at" : "2014-06-10 16:59:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 476410132382097408,
  "created_at" : "2014-06-10 17:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BE2H1zIKaR",
      "expanded_url" : "http:\/\/go.wh.gov\/jpWFvy",
      "display_url" : "go.wh.gov\/jpWFvy"
    } ]
  },
  "geo" : { },
  "id_str" : "476401004636692481",
  "text" : "RT @FLOTUS: \"My college story can be yours.\" \u2014The First Lady on helping more young people access higher education: http:\/\/t.co\/BE2H1zIKaR #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/BE2H1zIKaR",
        "expanded_url" : "http:\/\/go.wh.gov\/jpWFvy",
        "display_url" : "go.wh.gov\/jpWFvy"
      } ]
    },
    "geo" : { },
    "id_str" : "476400341316296704",
    "text" : "\"My college story can be yours.\" \u2014The First Lady on helping more young people access higher education: http:\/\/t.co\/BE2H1zIKaR #ReachHigher",
    "id" : 476400341316296704,
    "created_at" : "2014-06-10 16:27:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 476401004636692481,
  "created_at" : "2014-06-10 16:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/476396302893191168\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZjTcjaU0CY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpx_6alCQAA9QZ9.jpg",
      "id_str" : "476396302138228736",
      "id" : 476396302138228736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpx_6alCQAA9QZ9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZjTcjaU0CY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476396302893191168",
  "text" : "Higher education is the best investment you can make in your future.\nHere's one way we're making it more affordable. http:\/\/t.co\/ZjTcjaU0CY",
  "id" : 476396302893191168,
  "created_at" : "2014-06-10 16:11:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/hZ5AI9cRXf",
      "expanded_url" : "http:\/\/go.wh.gov\/PkZcc7",
      "display_url" : "go.wh.gov\/PkZcc7"
    } ]
  },
  "geo" : { },
  "id_str" : "476380476504956928",
  "text" : "Yesterday, President Obama took action to make college more affordable.\nToday, he's answering your Q's \u2192 http:\/\/t.co\/hZ5AI9cRXf #ObamaIRL",
  "id" : 476380476504956928,
  "created_at" : "2014-06-10 15:08:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 24, 31 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/SQXxnDI665",
      "expanded_url" : "http:\/\/WhiteHouse.Tumblr.com",
      "display_url" : "WhiteHouse.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "476371348311527424",
  "text" : "TODAY:\nPresident Obama.\n@Tumblr.\nAnd your education questions.\nWatch today's Q&amp;A at 4pm ET \u2192 http:\/\/t.co\/SQXxnDI665 #ObamaIRL",
  "id" : 476371348311527424,
  "created_at" : "2014-06-10 14:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476358915131998209\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ihreVEkTop",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpxd6LJCAAAnalx.jpg",
      "id_str" : "476358914598895616",
      "id" : 476358914598895616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpxd6LJCAAAnalx.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ihreVEkTop"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/7APfDzPPVc",
      "expanded_url" : "http:\/\/go.wh.gov\/xGogon",
      "display_url" : "go.wh.gov\/xGogon"
    } ]
  },
  "geo" : { },
  "id_str" : "476358915131998209",
  "text" : "\u201CA higher education is the single best investment that you can make in yourself.\" \u2014Obama: http:\/\/t.co\/7APfDzPPVc http:\/\/t.co\/ihreVEkTop",
  "id" : 476358915131998209,
  "created_at" : "2014-06-10 13:43:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 116, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ROBT3UdpJR",
      "expanded_url" : "http:\/\/youtu.be\/Mz5prW9iw14",
      "display_url" : "youtu.be\/Mz5prW9iw14"
    } ]
  },
  "geo" : { },
  "id_str" : "476159340928192512",
  "text" : "\u201CThis should be a no-brainer.\u201D \u2013Obama on helping more Americans pay off their student loans: http:\/\/t.co\/ROBT3UdpJR #CollegeOpportunity",
  "id" : 476159340928192512,
  "created_at" : "2014-06-10 00:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/RfIQgvhb07",
      "expanded_url" : "http:\/\/go.wh.gov\/AZvDkp",
      "display_url" : "go.wh.gov\/AZvDkp"
    } ]
  },
  "geo" : { },
  "id_str" : "476151405435052033",
  "text" : "\u201CNo hardworking young person should be priced out of a higher education.\u201D \u2013President Obama: http:\/\/t.co\/RfIQgvhb07 #CollegeOpportunity",
  "id" : 476151405435052033,
  "created_at" : "2014-06-09 23:58:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 91, 98 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/cQVpICC85X",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1IG86Qq",
      "display_url" : "tmblr.co\/ZW21es1IG86Qq"
    } ]
  },
  "geo" : { },
  "id_str" : "476143783130955776",
  "text" : "\"I have two teenage daughters, so that I am hip to all these things.\" \u2014Obama on tomorrow's @Tumblr Q&amp;A on education: http:\/\/t.co\/cQVpICC85X",
  "id" : 476143783130955776,
  "created_at" : "2014-06-09 23:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476110309204447232\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/cI37bPsqzK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpt7zZZCQAA0uze.jpg",
      "id_str" : "476110308537155584",
      "id" : 476110308537155584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpt7zZZCQAA0uze.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cI37bPsqzK"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 20, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/nBOcSMSLmB",
      "expanded_url" : "http:\/\/go.wh.gov\/ALWR3V",
      "display_url" : "go.wh.gov\/ALWR3V"
    } ]
  },
  "geo" : { },
  "id_str" : "476110309204447232",
  "text" : "It's time to expand #CollegeOpportunity by making higher education more affordable \u2192 http:\/\/t.co\/nBOcSMSLmB http:\/\/t.co\/cI37bPsqzK",
  "id" : 476110309204447232,
  "created_at" : "2014-06-09 21:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "UConn Huskies",
      "screen_name" : "UConnHuskies",
      "indices" : [ 117, 130 ],
      "id_str" : "28363841",
      "id" : 28363841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476099744260169730",
  "text" : "RT @WHLive: \"I couldn\u2019t be prouder of the example that they've set for young women like my daughters.\" \u2014Obama on the @UConnHuskies women's \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UConn Huskies",
        "screen_name" : "UConnHuskies",
        "indices" : [ 105, 118 ],
        "id_str" : "28363841",
        "id" : 28363841
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476099672206241793",
    "text" : "\"I couldn\u2019t be prouder of the example that they've set for young women like my daughters.\" \u2014Obama on the @UConnHuskies women's team",
    "id" : 476099672206241793,
    "created_at" : "2014-06-09 20:33:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 476099744260169730,
  "created_at" : "2014-06-09 20:33:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "UConn Huskies",
      "screen_name" : "UConnHuskies",
      "indices" : [ 84, 97 ],
      "id_str" : "28363841",
      "id" : 28363841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BleedBlue",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476097842831196160",
  "text" : "RT @WHLive: \"Give it up for the men\u2019s and women\u2019s college basketball champions, the @UConnHuskies!\" \u2014President Obama #BleedBlue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UConn Huskies",
        "screen_name" : "UConnHuskies",
        "indices" : [ 72, 85 ],
        "id_str" : "28363841",
        "id" : 28363841
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BleedBlue",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476097340894633987",
    "text" : "\"Give it up for the men\u2019s and women\u2019s college basketball champions, the @UConnHuskies!\" \u2014President Obama #BleedBlue",
    "id" : 476097340894633987,
    "created_at" : "2014-06-09 20:23:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 476097842831196160,
  "created_at" : "2014-06-09 20:25:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UConn Huskies",
      "screen_name" : "UConnHuskies",
      "indices" : [ 56, 69 ],
      "id_str" : "28363841",
      "id" : 28363841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BleedBlue",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "476093817108836352",
  "text" : "Starting soon: President Obama honors the NCAA Champion @UConnHuskies men's and women's basketball teams \u2192 http:\/\/t.co\/b4tqL3oo0v #BleedBlue",
  "id" : 476093817108836352,
  "created_at" : "2014-06-09 20:09:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/476080151126495232\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sCy7nIxVsb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BptgX7SCQAAmSru.jpg",
      "id_str" : "476080149784313856",
      "id" : 476080149784313856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BptgX7SCQAAmSru.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sCy7nIxVsb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476080151126495232",
  "text" : "Today's action on student loans would help nearly 5 million people cap their loan payments at 10% of their income. http:\/\/t.co\/sCy7nIxVsb",
  "id" : 476080151126495232,
  "created_at" : "2014-06-09 19:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476064798711775232",
  "text" : "\"This week, they have the chance to help millions of young Americans. I hope they do.\" \u2014Obama on Republicans in Congress #CollegeOpportunity",
  "id" : 476064798711775232,
  "created_at" : "2014-06-09 18:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 116, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476063780162772992",
  "text" : "\u201CI ran for this office to help more young people go to college, graduate, and pay off their debt.\u201D \u2014President Obama #CollegeOpportunity",
  "id" : 476063780162772992,
  "created_at" : "2014-06-09 18:10:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 49, 56 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 114, 133 ]
    }, {
      "text" : "ObamaIRL",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xQNI1VbG97",
      "expanded_url" : "http:\/\/ObamaIRL.Tumblr.com",
      "display_url" : "ObamaIRL.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "476062844866547712",
  "text" : "\"Tomorrow, I\u2019m doing a student loan Q&amp;A with @Tumblr to help spread the word.\" \u2014Obama: http:\/\/t.co\/xQNI1VbG97 #CollegeOpportunity #ObamaIRL",
  "id" : 476062844866547712,
  "created_at" : "2014-06-09 18:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476061594750025728",
  "text" : "\"Americans now owe more on student loans than they do on credit cards.\" \u2014Obama on why he's fighting to make college more affordable",
  "id" : 476061594750025728,
  "created_at" : "2014-06-09 18:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476060914232598528",
  "text" : "RT @WHLive: \"We expanded grants for low-income students. We created a new tuition tax credit for middle-class families.\" \u2014Obama http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/476060882062278657\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/TkGeAB2mKZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BptO2W8CUAAlhBI.jpg",
        "id_str" : "476060881395011584",
        "id" : 476060881395011584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BptO2W8CUAAlhBI.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TkGeAB2mKZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476060882062278657",
    "text" : "\"We expanded grants for low-income students. We created a new tuition tax credit for middle-class families.\" \u2014Obama http:\/\/t.co\/TkGeAB2mKZ",
    "id" : 476060882062278657,
    "created_at" : "2014-06-09 17:58:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 476060914232598528,
  "created_at" : "2014-06-09 17:59:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 91, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476060591597965315",
  "text" : "\"No hardworking young person should be priced out of a higher education.\" \u2014President Obama #CollegeOpportunity",
  "id" : 476060591597965315,
  "created_at" : "2014-06-09 17:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476059791715213312\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eHFDI6n0CD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BptN24QCMAQ70VT.jpg",
      "id_str" : "476059790825631748",
      "id" : 476059790825631748,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BptN24QCMAQ70VT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eHFDI6n0CD"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 96, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476059791715213312",
  "text" : "President Obama: \"Some higher education...is going to be your surest path to the middle class.\" #CollegeOpportunity http:\/\/t.co\/eHFDI6n0CD",
  "id" : 476059791715213312,
  "created_at" : "2014-06-09 17:54:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476059188192616449\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/VmgNir4Gck",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BptNTxQCcAAqN9N.jpg",
      "id_str" : "476059187651178496",
      "id" : 476059187651178496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BptNTxQCcAAqN9N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VmgNir4Gck"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476059188192616449",
  "text" : "\"A higher education is the single best investment that you can make in yourself and your future.\" \u2014President Obama http:\/\/t.co\/VmgNir4Gck",
  "id" : 476059188192616449,
  "created_at" : "2014-06-09 17:52:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Y2bOfmLbw1",
      "expanded_url" : "http:\/\/go.wh.gov\/KWpGJk",
      "display_url" : "go.wh.gov\/KWpGJk"
    } ]
  },
  "geo" : { },
  "id_str" : "476058856343482368",
  "text" : "Happening now: President Obama announces new steps to reduce the burden of student loan debt \u2192 http:\/\/t.co\/Y2bOfmLbw1 #CollegeOpportunity",
  "id" : 476058856343482368,
  "created_at" : "2014-06-09 17:50:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ut7uri7Tph",
      "expanded_url" : "http:\/\/go.wh.gov\/KWpGJk",
      "display_url" : "go.wh.gov\/KWpGJk"
    } ]
  },
  "geo" : { },
  "id_str" : "476054919107993600",
  "text" : "Watch President Obama announce a new plan to reduce the burden of student loan debt at 1:45pm ET: http:\/\/t.co\/ut7uri7Tph #CollegeOpportunity",
  "id" : 476054919107993600,
  "created_at" : "2014-06-09 17:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476043421841649664\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9CRhIEnkB7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bps--CpCEAE8lQJ.jpg",
      "id_str" : "476043421199503361",
      "id" : 476043421199503361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bps--CpCEAE8lQJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9CRhIEnkB7"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 92, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/nBOcSMSLmB",
      "expanded_url" : "http:\/\/go.wh.gov\/ALWR3V",
      "display_url" : "go.wh.gov\/ALWR3V"
    } ]
  },
  "geo" : { },
  "id_str" : "476043421841649664",
  "text" : "Here's how President Obama has helped make college more affordable \u2192 http:\/\/t.co\/nBOcSMSLmB #CollegeOpportunity http:\/\/t.co\/9CRhIEnkB7",
  "id" : 476043421841649664,
  "created_at" : "2014-06-09 16:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476037698809901057\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/AX0CRzUQbY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bps5w5zCQAAz-HV.jpg",
      "id_str" : "476037697929101312",
      "id" : 476037697929101312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bps5w5zCQAAz-HV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AX0CRzUQbY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476037698809901057",
  "text" : "President Obama's action on student loans would help millions of Americans lower their monthly loan payments. http:\/\/t.co\/AX0CRzUQbY",
  "id" : 476037698809901057,
  "created_at" : "2014-06-09 16:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476023846068555776\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TkOAXJ5unz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpstKlvCYAAb2wt.jpg",
      "id_str" : "476023845569060864",
      "id" : 476023845569060864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpstKlvCYAAb2wt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TkOAXJ5unz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476023846068555776",
  "text" : "RT if you agree: Higher education is the best investment you can make in your future. Let's make it more affordable. http:\/\/t.co\/TkOAXJ5unz",
  "id" : 476023846068555776,
  "created_at" : "2014-06-09 15:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qxI8mXzp4x",
      "expanded_url" : "http:\/\/ti.me\/1oCuDrV",
      "display_url" : "ti.me\/1oCuDrV"
    } ]
  },
  "geo" : { },
  "id_str" : "476013991508987906",
  "text" : "RT @pfeiffer44: Very significant executive action today to help reduce student loan debt, part of pen phone push http:\/\/t.co\/qxI8mXzp4x via\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TIMEPolitics",
        "screen_name" : "TIMEPolitics",
        "indices" : [ 124, 137 ],
        "id_str" : "15723290",
        "id" : 15723290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/qxI8mXzp4x",
        "expanded_url" : "http:\/\/ti.me\/1oCuDrV",
        "display_url" : "ti.me\/1oCuDrV"
      } ]
    },
    "geo" : { },
    "id_str" : "475994054669238272",
    "text" : "Very significant executive action today to help reduce student loan debt, part of pen phone push http:\/\/t.co\/qxI8mXzp4x via @TIMEPolitics",
    "id" : 475994054669238272,
    "created_at" : "2014-06-09 13:33:20 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 476013991508987906,
  "created_at" : "2014-06-09 14:52:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 48, 55 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/476008376531308546\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/wfyXHhMowx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpsbETICIAAA6h9.jpg",
      "id_str" : "476003946285113344",
      "id" : 476003946285113344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpsbETICIAAA6h9.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/wfyXHhMowx"
    } ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/6RJWXvnG2H",
      "expanded_url" : "http:\/\/ObamaIRL.Tumblr.com",
      "display_url" : "ObamaIRL.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "476008376531308546",
  "text" : "Got an education question for President Obama's @Tumblr Q&amp;A?\nAsk away \u2192 http:\/\/t.co\/6RJWXvnG2H #ObamaIRL http:\/\/t.co\/wfyXHhMowx",
  "id" : 476008376531308546,
  "created_at" : "2014-06-09 14:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/SDZlDM3P70",
      "expanded_url" : "http:\/\/nyti.ms\/UkWoKL",
      "display_url" : "nyti.ms\/UkWoKL"
    } ]
  },
  "geo" : { },
  "id_str" : "476002973731262465",
  "text" : "President Obama's taking new steps to help millions of Americans pay off their student loans \u2192 http:\/\/t.co\/SDZlDM3P70 #CollegeOpportunity",
  "id" : 476002973731262465,
  "created_at" : "2014-06-09 14:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/0YEO6uKKIZ",
      "expanded_url" : "http:\/\/youtu.be\/eLk77gMOPhY",
      "display_url" : "youtu.be\/eLk77gMOPhY"
    } ]
  },
  "geo" : { },
  "id_str" : "475683754162147328",
  "text" : "\"I\u2019ll keep fighting to give more young people the chance to earn their own piece of the American Dream.\" \u2014Obama: http:\/\/t.co\/0YEO6uKKIZ",
  "id" : 475683754162147328,
  "created_at" : "2014-06-08 17:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0YEO6uKKIZ",
      "expanded_url" : "http:\/\/youtu.be\/eLk77gMOPhY",
      "display_url" : "youtu.be\/eLk77gMOPhY"
    } ]
  },
  "geo" : { },
  "id_str" : "475661074536992768",
  "text" : "\"The typical graduate of a 4-year college earns $15,000 more\/year than someone w\/ just a high school degree.\" \u2014Obama: http:\/\/t.co\/0YEO6uKKIZ",
  "id" : 475661074536992768,
  "created_at" : "2014-06-08 15:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/DKLZtcZGql",
      "expanded_url" : "http:\/\/nyti.ms\/UkWoKL",
      "display_url" : "nyti.ms\/UkWoKL"
    } ]
  },
  "geo" : { },
  "id_str" : "475647591669960707",
  "text" : "Tomorrow, President Obama is announcing new steps to help millions of Americans pay off their student loans \u2192 http:\/\/t.co\/DKLZtcZGql",
  "id" : 475647591669960707,
  "created_at" : "2014-06-08 14:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 89, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/0YEO6uKKIZ",
      "expanded_url" : "http:\/\/youtu.be\/eLk77gMOPhY",
      "display_url" : "youtu.be\/eLk77gMOPhY"
    } ]
  },
  "geo" : { },
  "id_str" : "475638429623918592",
  "text" : "President Obama's weekly address: Supporting America's students \u2192 http:\/\/t.co\/0YEO6uKKIZ #CollegeOpportunity",
  "id" : 475638429623918592,
  "created_at" : "2014-06-08 14:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0YEO6uKKIZ",
      "expanded_url" : "http:\/\/youtu.be\/eLk77gMOPhY",
      "display_url" : "youtu.be\/eLk77gMOPhY"
    } ]
  },
  "geo" : { },
  "id_str" : "475321313116954625",
  "text" : "\"We reformed a student loan system that gave away billions of taxpayer dollars to big banks.\" \u2014President Obama: http:\/\/t.co\/0YEO6uKKIZ",
  "id" : 475321313116954625,
  "created_at" : "2014-06-07 17:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "indices" : [ 3, 10 ],
      "id_str" : "2169098419",
      "id" : 2169098419
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 42, 49 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475315231175221248",
  "text" : "RT @Alex44: TUESDAY:\nPresident Obama.\nAnd @Tumblr.\nAt the @WhiteHouse.\nWith all of your education questions.\nAsk away \u2192 http:\/\/t.co\/r60puY2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 30, 37 ],
        "id_str" : "52484614",
        "id" : 52484614
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 46, 57 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaIRL",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/r60puY2oCR",
        "expanded_url" : "http:\/\/ObamaIRL.Tumblr.com",
        "display_url" : "ObamaIRL.Tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "475292593946099712",
    "text" : "TUESDAY:\nPresident Obama.\nAnd @Tumblr.\nAt the @WhiteHouse.\nWith all of your education questions.\nAsk away \u2192 http:\/\/t.co\/r60puY2oCR #ObamaIRL",
    "id" : 475292593946099712,
    "created_at" : "2014-06-07 15:05:59 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 475315231175221248,
  "created_at" : "2014-06-07 16:35:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 98, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/0YEO6uKKIZ",
      "expanded_url" : "http:\/\/youtu.be\/eLk77gMOPhY",
      "display_url" : "youtu.be\/eLk77gMOPhY"
    } ]
  },
  "geo" : { },
  "id_str" : "475298696519639040",
  "text" : "President Obama on how he's taking steps to make college more affordable \u2192 http:\/\/t.co\/0YEO6uKKIZ #CollegeOpportunity",
  "id" : 475298696519639040,
  "created_at" : "2014-06-07 15:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0YEO6uKKIZ",
      "expanded_url" : "http:\/\/youtu.be\/eLk77gMOPhY",
      "display_url" : "youtu.be\/eLk77gMOPhY"
    } ]
  },
  "geo" : { },
  "id_str" : "475283305743400962",
  "text" : "\"The surest pathway into the middle class is some form of higher education.\" \u2014President Obama: http:\/\/t.co\/0YEO6uKKIZ #CollegeOpportunity",
  "id" : 475283305743400962,
  "created_at" : "2014-06-07 14:29:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/475044111012364288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/codDdmHkJq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpeyGeLCEAAGk5E.jpg",
      "id_str" : "475044109959172096",
      "id" : 475044109959172096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpeyGeLCEAAGk5E.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/codDdmHkJq"
    } ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/vmxaJmXnHE",
      "expanded_url" : "http:\/\/go.wh.gov\/QZs6As",
      "display_url" : "go.wh.gov\/QZs6As"
    } ]
  },
  "geo" : { },
  "id_str" : "475044111012364288",
  "text" : "\"Whenever the world makes you cynical, stop and think of these men.\" \u2014President Obama: http:\/\/t.co\/vmxaJmXnHE #DDay http:\/\/t.co\/codDdmHkJq",
  "id" : 475044111012364288,
  "created_at" : "2014-06-06 22:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/vmxaJmXnHE",
      "expanded_url" : "http:\/\/go.wh.gov\/QZs6As",
      "display_url" : "go.wh.gov\/QZs6As"
    } ]
  },
  "geo" : { },
  "id_str" : "475038159911518208",
  "text" : "\"It was here\u2014on these shores\u2014that the tide was turned in that common struggle for freedom.\" \u2014Obama in Normandy: http:\/\/t.co\/vmxaJmXnHE #DDay",
  "id" : 475038159911518208,
  "created_at" : "2014-06-06 22:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/475009603466719232\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/DIc2gQi8q0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpeSt4yCcAA8uaK.jpg",
      "id_str" : "475009602744905728",
      "id" : 475009602744905728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpeSt4yCcAA8uaK.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DIc2gQi8q0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475009603466719232",
  "text" : "Happy National Donut Day! \uD83C\uDF69 http:\/\/t.co\/DIc2gQi8q0",
  "id" : 475009603466719232,
  "created_at" : "2014-06-06 20:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/cT6c6c9ibH",
      "expanded_url" : "http:\/\/youtu.be\/WfdJUBiq7tA",
      "display_url" : "youtu.be\/WfdJUBiq7tA"
    } ]
  },
  "geo" : { },
  "id_str" : "474999195003129856",
  "text" : "#DDay is \"a chance to remember those who gave their lives for the freedom we enjoy today.\" \u2014President Obama: http:\/\/t.co\/cT6c6c9ibH",
  "id" : 474999195003129856,
  "created_at" : "2014-06-06 19:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Bb26C1EbQe",
      "expanded_url" : "http:\/\/youtu.be\/WfdJUBiq7tA",
      "display_url" : "youtu.be\/WfdJUBiq7tA"
    } ]
  },
  "geo" : { },
  "id_str" : "474991507414720512",
  "text" : "\"The men who stormed the beaches of Normandy that day changed the course of human history.\" \u2014President Obama: http:\/\/t.co\/Bb26C1EbQe #DDay",
  "id" : 474991507414720512,
  "created_at" : "2014-06-06 19:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474987701813645312",
  "text" : "RT @PressSec: Check out this behind-the-scenes video, narrated by the President, of the 70th Anniversary of D-Day at Normandy. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/SfrdZcw5gY",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=WfdJUBiq7tA",
        "display_url" : "youtube.com\/watch?v=WfdJUB\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474986256913670144",
    "text" : "Check out this behind-the-scenes video, narrated by the President, of the 70th Anniversary of D-Day at Normandy. https:\/\/t.co\/SfrdZcw5gY",
    "id" : 474986256913670144,
    "created_at" : "2014-06-06 18:48:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 474987701813645312,
  "created_at" : "2014-06-06 18:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CIA",
      "screen_name" : "CIA",
      "indices" : [ 3, 7 ],
      "id_str" : "2359926157",
      "id" : 2359926157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474983216856965120",
  "text" : "RT @CIA: We can neither confirm nor deny that this is our first tweet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474971393852182528",
    "text" : "We can neither confirm nor deny that this is our first tweet.",
    "id" : 474971393852182528,
    "created_at" : "2014-06-06 17:49:39 +0000",
    "user" : {
      "name" : "CIA",
      "screen_name" : "CIA",
      "protected" : false,
      "id_str" : "2359926157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474250448757481472\/QcQ_P01E_normal.jpeg",
      "id" : 2359926157,
      "verified" : true
    }
  },
  "id" : 474983216856965120,
  "created_at" : "2014-06-06 18:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474971497652441088",
  "text" : "\"These men waged war so that we might know peace. They sacrificed so that we might be free.\" \u2014Obama on the 70th anniversary of #DDay",
  "id" : 474971497652441088,
  "created_at" : "2014-06-06 17:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474964978802622465",
  "text" : "RT @DrBiden: My thoughts are with those who so bravely fought 70 years ago today.-Jill #DDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DDay",
        "indices" : [ 74, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474934169802637312",
    "text" : "My thoughts are with those who so bravely fought 70 years ago today.-Jill #DDay",
    "id" : 474934169802637312,
    "created_at" : "2014-06-06 15:21:44 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 474964978802622465,
  "created_at" : "2014-06-06 17:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474962817775570944",
  "text" : "RT @VP: 1 million: That's the number of jobs our businesses have added so far this year -- but there's more work to do. http:\/\/t.co\/9jqV69m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/474956107790557184\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/9jqV69mCTT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpdiD_lCIAEjM52.jpg",
        "id_str" : "474956106456768513",
        "id" : 474956106456768513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpdiD_lCIAEjM52.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9jqV69mCTT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474956107790557184",
    "text" : "1 million: That's the number of jobs our businesses have added so far this year -- but there's more work to do. http:\/\/t.co\/9jqV69mCTT",
    "id" : 474956107790557184,
    "created_at" : "2014-06-06 16:48:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 474962817775570944,
  "created_at" : "2014-06-06 17:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DDay",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/1kUJvBf9nI",
      "expanded_url" : "http:\/\/youtu.be\/ewcQ9hCP9rM",
      "display_url" : "youtu.be\/ewcQ9hCP9rM"
    } ]
  },
  "geo" : { },
  "id_str" : "474953578218807296",
  "text" : "\"Whenever the world makes you cynical, stop &amp; think of these men.\" \u2014President Obama on the 70th anniversary of #DDay: http:\/\/t.co\/1kUJvBf9nI",
  "id" : 474953578218807296,
  "created_at" : "2014-06-06 16:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474932532320804866",
  "text" : "FACT: The unemployment rate for college graduates age 25 and \u2191 is 3.2%, compared to 6.5% for those with only a high school diploma.",
  "id" : 474932532320804866,
  "created_at" : "2014-06-06 15:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474917160054059008\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/xrxny1RSEc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "id_str" : "474917159269720065",
      "id" : 474917159269720065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xrxny1RSEc"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/e20FxCRXRN",
      "expanded_url" : "http:\/\/go.wh.gov\/Cizt6X",
      "display_url" : "go.wh.gov\/Cizt6X"
    } ]
  },
  "geo" : { },
  "id_str" : "474921171780005889",
  "text" : "FACT: Our businesses added 216,000 jobs in May\u2014but there's more work to do: http:\/\/t.co\/e20FxCRXRN #ActOnJobs http:\/\/t.co\/xrxny1RSEc",
  "id" : 474921171780005889,
  "created_at" : "2014-06-06 14:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474917160054059008\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/xrxny1RSEc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "id_str" : "474917159269720065",
      "id" : 474917159269720065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xrxny1RSEc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474917160054059008",
  "text" : "Our businesses have added:\n9.4 million jobs over 51 months \u2714\nMore than 1 million this year \u2714\n216,000 in May \u2714\n\u2192 http:\/\/t.co\/xrxny1RSEc",
  "id" : 474917160054059008,
  "created_at" : "2014-06-06 14:14:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474683393989304321\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/qco9EhJ6yh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZjC_RCcAAL0uI.jpg",
      "id_str" : "474675713727950848",
      "id" : 474675713727950848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZjC_RCcAAL0uI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qco9EhJ6yh"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RxPSPdYBLA",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "474683393989304321",
  "text" : "Every nation needs to take steps to #ActOnClimate. Here's how we're doing our part \u2192 http:\/\/t.co\/RxPSPdYBLA http:\/\/t.co\/qco9EhJ6yh",
  "id" : 474683393989304321,
  "created_at" : "2014-06-05 22:45:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 17, 24 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YS1D2sGpwC",
      "expanded_url" : "http:\/\/go.wh.gov\/bHjs35",
      "display_url" : "go.wh.gov\/bHjs35"
    } ]
  },
  "geo" : { },
  "id_str" : "474672062356017152",
  "text" : "President Obama.\n@Tumblr.\nAnd YOU.\nOn Tuesday.\nTalking education.\nAt the White House.\nIs this real life?\nIt could be: http:\/\/t.co\/YS1D2sGpwC",
  "id" : 474672062356017152,
  "created_at" : "2014-06-05 22:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474664044545470464\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/GwtwuQfbXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZYbsXCEAA9KwX.jpg",
      "id_str" : "474664043521642496",
      "id" : 474664043521642496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZYbsXCEAA9KwX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 651,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 977,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GwtwuQfbXh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/fxenKulmrx",
      "expanded_url" : "http:\/\/go.wh.gov\/TEACWn",
      "display_url" : "go.wh.gov\/TEACWn"
    } ]
  },
  "geo" : { },
  "id_str" : "474664044545470464",
  "text" : "Get the latest on President Obama's meetings with the G7 leaders \u2192 http:\/\/t.co\/fxenKulmrx http:\/\/t.co\/GwtwuQfbXh",
  "id" : 474664044545470464,
  "created_at" : "2014-06-05 21:28:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/71VFkFc4fo",
      "expanded_url" : "http:\/\/youtu.be\/480NUosxmIg",
      "display_url" : "youtu.be\/480NUosxmIg"
    } ]
  },
  "geo" : { },
  "id_str" : "474635554953633796",
  "text" : "Go behind the scenes with President Obama on his trip to Poland, Belgium, and France \u2192 http:\/\/t.co\/71VFkFc4fo #WestWingWeek",
  "id" : 474635554953633796,
  "created_at" : "2014-06-05 19:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/OJNMIIx9BE",
      "expanded_url" : "http:\/\/go.wh.gov\/aKzPPR",
      "display_url" : "go.wh.gov\/aKzPPR"
    } ]
  },
  "geo" : { },
  "id_str" : "474626791047307264",
  "text" : "\"Sylvia is a proven manager who knows how to deliver results.\" \u2014Obama on Sylvia Mathews Burwell's confirmation: http:\/\/t.co\/OJNMIIx9BE",
  "id" : 474626791047307264,
  "created_at" : "2014-06-05 19:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 93, 100 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474622770383708160\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/IbVcq2K359",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYy5PxCYAA4Zro.png",
      "id_str" : "474622769800306688",
      "id" : 474622769800306688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYy5PxCYAA4Zro.png",
      "sizes" : [ {
        "h" : 234,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IbVcq2K359"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474622770383708160",
  "text" : "Great news: Sylvia Mathews Burwell was just confirmed by the Senate as the next Secretary of @HHSGov \u2192 http:\/\/t.co\/IbVcq2K359",
  "id" : 474622770383708160,
  "created_at" : "2014-06-05 18:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yK5p4KmkVb",
      "expanded_url" : "http:\/\/youtu.be\/xwZKiH4Egdc",
      "display_url" : "youtu.be\/xwZKiH4Egdc"
    } ]
  },
  "geo" : { },
  "id_str" : "474615416619147264",
  "text" : "\"I make absolutely no apologies for making sure that we get back a young man to his parents.\" \u2014President Obama: http:\/\/t.co\/yK5p4KmkVb",
  "id" : 474615416619147264,
  "created_at" : "2014-06-05 18:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/MUb3622Fmu",
      "expanded_url" : "http:\/\/youtu.be\/xwZKiH4Egdc",
      "display_url" : "youtu.be\/xwZKiH4Egdc"
    } ]
  },
  "geo" : { },
  "id_str" : "474608549436612608",
  "text" : "\"We do not leave anybody wearing the American uniform behind.\" \u2014President Obama: http:\/\/t.co\/MUb3622Fmu",
  "id" : 474608549436612608,
  "created_at" : "2014-06-05 17:47:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "Colonial Nat'l Park",
      "screen_name" : "ColonialParkNPS",
      "indices" : [ 114, 130 ],
      "id_str" : "45854914",
      "id" : 45854914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474595259562074112",
  "text" : "RT @SecretaryJewell: We need to #ActOnClimate to help slow impacts on important cultural resources like Jamestown @ColonialParkNPS. SJ http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colonial Nat'l Park",
        "screen_name" : "ColonialParkNPS",
        "indices" : [ 93, 109 ],
        "id_str" : "45854914",
        "id" : 45854914
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/474593617500467200\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/I1k9eb15VK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYYYSHIAAE6Kfw.jpg",
        "id_str" : "474593616191815681",
        "id" : 474593616191815681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYYYSHIAAE6Kfw.jpg",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/I1k9eb15VK"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 11, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474593617500467200",
    "text" : "We need to #ActOnClimate to help slow impacts on important cultural resources like Jamestown @ColonialParkNPS. SJ http:\/\/t.co\/I1k9eb15VK",
    "id" : 474593617500467200,
    "created_at" : "2014-06-05 16:48:30 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 474595259562074112,
  "created_at" : "2014-06-05 16:55:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 78, 85 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/xQNI1VbG97",
      "expanded_url" : "http:\/\/ObamaIRL.Tumblr.com",
      "display_url" : "ObamaIRL.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "474582720535068672",
  "text" : "Have questions for President Obama on education? Ask away before his 1st-ever @Tumblr Q&amp;A on Tuesday \u2192 http:\/\/t.co\/xQNI1VbG97 #ObamaIRL",
  "id" : 474582720535068672,
  "created_at" : "2014-06-05 16:05:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 49, 56 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474575119910961153\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RxWwxav4bP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYHjnMCMAAFtEf.jpg",
      "id_str" : "474575119130439680",
      "id" : 474575119130439680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYHjnMCMAAFtEf.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/RxWwxav4bP"
    } ],
    "hashtags" : [ {
      "text" : "ObamaIRL",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2QoGlgtUPm",
      "expanded_url" : "http:\/\/go.wh.gov\/wYksfp",
      "display_url" : "go.wh.gov\/wYksfp"
    } ]
  },
  "geo" : { },
  "id_str" : "474575119910961153",
  "text" : "Join President Obama on Tuesday for his 1st-ever @Tumblr Q&amp;A on education \u2192 http:\/\/t.co\/2QoGlgtUPm #ObamaIRL http:\/\/t.co\/RxWwxav4bP",
  "id" : 474575119910961153,
  "created_at" : "2014-06-05 15:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G7Brussels",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474550123700449280",
  "text" : "\"Mr. Putin has the chance to get back into a lane of international law.\" \u2014President Obama on Russia and the situation in Ukraine #G7Brussels",
  "id" : 474550123700449280,
  "created_at" : "2014-06-05 13:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "474546792349335552",
  "text" : "Happening now: President Obama holds a joint press conference with British Prime Minister David Cameron \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 474546792349335552,
  "created_at" : "2014-06-05 13:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/474307833115451392\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/XOe1f9rnHZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpUUdfVCEAAPnnb.jpg",
      "id_str" : "474307832615931904",
      "id" : 474307832615931904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpUUdfVCEAAPnnb.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/XOe1f9rnHZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/r87S545sHt",
      "expanded_url" : "http:\/\/go.wh.gov\/AekaYa",
      "display_url" : "go.wh.gov\/AekaYa"
    } ]
  },
  "geo" : { },
  "id_str" : "474307833115451392",
  "text" : "\"We stand together, now and forever, for your freedom is ours.\" \u2014President Obama in Poland: http:\/\/t.co\/r87S545sHt http:\/\/t.co\/XOe1f9rnHZ",
  "id" : 474307833115451392,
  "created_at" : "2014-06-04 21:52:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474289079354679296",
  "text" : "RT @VP: 60%: That\u2019s the percentage of jobs by the end of this decade that will require some kind of education past high school. #InvestInWo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvestInWorkers",
        "indices" : [ 120, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474284015802126336",
    "text" : "60%: That\u2019s the percentage of jobs by the end of this decade that will require some kind of education past high school. #InvestInWorkers",
    "id" : 474284015802126336,
    "created_at" : "2014-06-04 20:18:15 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 474289079354679296,
  "created_at" : "2014-06-04 20:38:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474264222516666370\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/o1u0CRfQL1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpTszBBCQAAd94Z.jpg",
      "id_str" : "474264221971005440",
      "id" : 474264221971005440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpTszBBCQAAd94Z.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/o1u0CRfQL1"
    } ],
    "hashtags" : [ {
      "text" : "HappyNationalRunningDay",
      "indices" : [ 13, 37 ]
    }, {
      "text" : "LetsMove",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474264222516666370",
  "text" : "It's a race! #HappyNationalRunningDay #LetsMove http:\/\/t.co\/o1u0CRfQL1",
  "id" : 474264222516666370,
  "created_at" : "2014-06-04 18:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Go",
      "screen_name" : "okgo",
      "indices" : [ 29, 34 ],
      "id_str" : "6815302",
      "id" : 6815302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ibgVAtT6gA",
      "expanded_url" : "http:\/\/youtu.be\/HaTgKLym0Dg",
      "display_url" : "youtu.be\/HaTgKLym0Dg"
    } ]
  },
  "geo" : { },
  "id_str" : "474256847956746240",
  "text" : "\"Making stuff: It's good for @OkGo...it's good for America.\" http:\/\/t.co\/ibgVAtT6gA #NationOfMakers",
  "id" : 474256847956746240,
  "created_at" : "2014-06-04 18:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474251748862078976",
  "text" : "RT @FLOTUS: \"When a veteran comes home kissing the ground, it is unacceptable that he should have to sleep on it\" \u2014FLOTUS on ending veteran\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474251466358935554",
    "text" : "\"When a veteran comes home kissing the ground, it is unacceptable that he should have to sleep on it\" \u2014FLOTUS on ending veteran homelessness",
    "id" : 474251466358935554,
    "created_at" : "2014-06-04 18:08:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 474251748862078976,
  "created_at" : "2014-06-04 18:10:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Go",
      "screen_name" : "okgo",
      "indices" : [ 47, 52 ],
      "id_str" : "6815302",
      "id" : 6815302
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationOfMakers",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/BAMI0mX39s",
      "expanded_url" : "http:\/\/youtu.be\/HaTgKLym0Dg",
      "display_url" : "youtu.be\/HaTgKLym0Dg"
    } ]
  },
  "geo" : { },
  "id_str" : "474240145928224768",
  "text" : "\"Tim, what are you doing?\"\n\"I'm making stuff!\"\n@OkGo announces the 1st-ever @WhiteHouse Maker Faire \u2192 http:\/\/t.co\/BAMI0mX39s #NationOfMakers",
  "id" : 474240145928224768,
  "created_at" : "2014-06-04 17:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OK Go",
      "screen_name" : "okgo",
      "indices" : [ 3, 8 ],
      "id_str" : "6815302",
      "id" : 6815302
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationofMakers",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474239702766485504",
  "text" : "RT @okgo: .@WhiteHouse is having a Maker Faire June 18, and Tim &amp; Damian are here to tell you all about it. #NationofMakers http:\/\/t.co\/uMm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationofMakers",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/uMmLRWsL9K",
        "expanded_url" : "http:\/\/youtu.be\/HaTgKLym0Dg",
        "display_url" : "youtu.be\/HaTgKLym0Dg"
      } ]
    },
    "geo" : { },
    "id_str" : "474237068349276160",
    "text" : ".@WhiteHouse is having a Maker Faire June 18, and Tim &amp; Damian are here to tell you all about it. #NationofMakers http:\/\/t.co\/uMmLRWsL9K",
    "id" : 474237068349276160,
    "created_at" : "2014-06-04 17:11:42 +0000",
    "user" : {
      "name" : "OK Go",
      "screen_name" : "okgo",
      "protected" : false,
      "id_str" : "6815302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696884733008072704\/iNwKsiY8_normal.jpg",
      "id" : 6815302,
      "verified" : true
    }
  },
  "id" : 474239702766485504,
  "created_at" : "2014-06-04 17:22:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/2FRLswnfMq",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "474214450535596032",
  "text" : "President Obama's clean power plant standards would:\n\u2193 carbon pollution by 30%\n\u2193 soot &amp; smog by 25%\n#ActOnClimate \u2192 http:\/\/t.co\/2FRLswnfMq",
  "id" : 474214450535596032,
  "created_at" : "2014-06-04 15:41:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474204118722936834",
  "text" : "RT @SenatorReid: When a man or woman puts on the uniform of a U.S. service member, they have America\u2019s uncompromising support.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474183503551430656",
    "text" : "When a man or woman puts on the uniform of a U.S. service member, they have America\u2019s uncompromising support.",
    "id" : 474183503551430656,
    "created_at" : "2014-06-04 13:38:51 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 474204118722936834,
  "created_at" : "2014-06-04 15:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/BhPquOqDFd",
      "expanded_url" : "http:\/\/go.wh.gov\/1qhfWG",
      "display_url" : "go.wh.gov\/1qhfWG"
    } ]
  },
  "geo" : { },
  "id_str" : "474189417293549568",
  "text" : "Here's the latest on how President Obama's clean power plant standards will protect our kids' health: http:\/\/t.co\/BhPquOqDFd #ActOnClimate",
  "id" : 474189417293549568,
  "created_at" : "2014-06-04 14:02:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 15, 23 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "reddit AMA",
      "screen_name" : "reddit_AMA",
      "indices" : [ 26, 37 ],
      "id_str" : "524487620",
      "id" : 524487620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AMA",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/N0afqlp0UU",
      "expanded_url" : "http:\/\/redd.it\/278lmb",
      "display_url" : "redd.it\/278lmb"
    } ]
  },
  "geo" : { },
  "id_str" : "473948096154447873",
  "text" : "Happening now: @GinaEPA's @reddit_AMA on President Obama's clean power plant standards. Ask away \u2192 http:\/\/t.co\/N0afqlp0UU #AMA #ActOnClimate",
  "id" : 473948096154447873,
  "created_at" : "2014-06-03 22:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 24, 32 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473929630991536128",
  "text" : "RT @FLOTUS: Great news: @USEdGov just announced $75 million to help more high school students prepare for college. #ReachHigher http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 12, 20 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/473928430850150400\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/1nLCAevvkg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpO7ZWDCIAE4yP9.jpg",
        "id_str" : "473928429893459969",
        "id" : 473928429893459969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpO7ZWDCIAE4yP9.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/1nLCAevvkg"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473928430850150400",
    "text" : "Great news: @USEdGov just announced $75 million to help more high school students prepare for college. #ReachHigher http:\/\/t.co\/1nLCAevvkg",
    "id" : 473928430850150400,
    "created_at" : "2014-06-03 20:45:17 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 473929630991536128,
  "created_at" : "2014-06-03 20:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 75, 82 ],
      "id_str" : "811377",
      "id" : 811377
    }, {
      "name" : "Follow us @Shop6pm!",
      "screen_name" : "6pm",
      "indices" : [ 89, 93 ],
      "id_str" : "1507235672",
      "id" : 1507235672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473902511410409473",
  "text" : "RT @GinaEPA: Hey Everyone, I\u2019m taking questions on the Clean Power Plan on @Reddit TODAY @6PM ET. Ask Me Anything! #ActOnClimate http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reddit",
        "screen_name" : "reddit",
        "indices" : [ 62, 69 ],
        "id_str" : "811377",
        "id" : 811377
      }, {
        "name" : "Follow us @Shop6pm!",
        "screen_name" : "6pm",
        "indices" : [ 76, 80 ],
        "id_str" : "1507235672",
        "id" : 1507235672
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/473899708721946625\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Mn8gCZEesG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpOhRCeCUAApEz8.jpg",
        "id_str" : "473899699896733696",
        "id" : 473899699896733696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpOhRCeCUAApEz8.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Mn8gCZEesG"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473899708721946625",
    "text" : "Hey Everyone, I\u2019m taking questions on the Clean Power Plan on @Reddit TODAY @6PM ET. Ask Me Anything! #ActOnClimate http:\/\/t.co\/Mn8gCZEesG",
    "id" : 473899708721946625,
    "created_at" : "2014-06-03 18:51:09 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 473902511410409473,
  "created_at" : "2014-06-03 19:02:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/473900008845348865\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/F49SvUKZHx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpOhi_ECIAAThAH.jpg",
      "id_str" : "473900008220008448",
      "id" : 473900008220008448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpOhi_ECIAAThAH.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/F49SvUKZHx"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/2FRLswnfMq",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "473900008845348865",
  "text" : "RT if you agree: We have a moral obligation to protect our kids' health \u2192 http:\/\/t.co\/2FRLswnfMq #ActOnClimate http:\/\/t.co\/F49SvUKZHx",
  "id" : 473900008845348865,
  "created_at" : "2014-06-03 18:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/CkVTj2D9WI",
      "expanded_url" : "http:\/\/go.wh.gov\/7eVpvq",
      "display_url" : "go.wh.gov\/7eVpvq"
    } ]
  },
  "geo" : { },
  "id_str" : "473890133683757056",
  "text" : "Get the inside scoop on President Obama's trip to Poland, Belgium, and France \u2192 http:\/\/t.co\/CkVTj2D9WI",
  "id" : 473890133683757056,
  "created_at" : "2014-06-03 18:13:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/473881532525203457\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/fykAPzJfOL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpOQvg-CUAETk_9.jpg",
      "id_str" : "473881531782418433",
      "id" : 473881531782418433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpOQvg-CUAETk_9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fykAPzJfOL"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473881532525203457",
  "text" : "President Obama's clean power plant standards =\nFewer lost work days \u2714\nFewer school absences \u2714\n#ActOnClimate http:\/\/t.co\/fykAPzJfOL",
  "id" : 473881532525203457,
  "created_at" : "2014-06-03 17:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 24, 32 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/473862934049742849\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/4tBmjbWhhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpN_0r6CcAAeocn.png",
      "id_str" : "473862928920113152",
      "id" : 473862928920113152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpN_0r6CcAAeocn.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1202,
        "resize" : "fit",
        "w" : 1802
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4tBmjbWhhN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473873098396422144",
  "text" : "RT @VP: Happy birthday, @DrBiden! http:\/\/t.co\/4tBmjbWhhN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 16, 24 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/473862934049742849\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/4tBmjbWhhN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpN_0r6CcAAeocn.png",
        "id_str" : "473862928920113152",
        "id" : 473862928920113152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpN_0r6CcAAeocn.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1202,
          "resize" : "fit",
          "w" : 1802
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4tBmjbWhhN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473862934049742849",
    "text" : "Happy birthday, @DrBiden! http:\/\/t.co\/4tBmjbWhhN",
    "id" : 473862934049742849,
    "created_at" : "2014-06-03 16:25:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 473873098396422144,
  "created_at" : "2014-06-03 17:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/473866235214856192\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/nOWGkHzn5B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpOC1GGCQAACMNB.jpg",
      "id_str" : "473866234484637696",
      "id" : 473866234484637696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpOC1GGCQAACMNB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nOWGkHzn5B"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/BhPquOqDFd",
      "expanded_url" : "http:\/\/go.wh.gov\/1qhfWG",
      "display_url" : "go.wh.gov\/1qhfWG"
    } ]
  },
  "geo" : { },
  "id_str" : "473866235214856192",
  "text" : "Every American deserves the right to breathe clean air: http:\/\/t.co\/BhPquOqDFd #ActOnClimate http:\/\/t.co\/nOWGkHzn5B",
  "id" : 473866235214856192,
  "created_at" : "2014-06-03 16:38:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/lM3sfRCRpV",
      "expanded_url" : "http:\/\/go.wh.gov\/CTVwi2",
      "display_url" : "go.wh.gov\/CTVwi2"
    } ]
  },
  "geo" : { },
  "id_str" : "473845332388765698",
  "text" : "President Obama's clean power plant standards will help prevent more kids from getting asthma \u2192 http:\/\/t.co\/lM3sfRCRpV #ActOnClimate",
  "id" : 473845332388765698,
  "created_at" : "2014-06-03 15:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473837068100325376",
  "text" : "\"Regardless of the circumstances, we still get an American soldier back if he's held in captivity. Period.\" \u2014Obama on Sergeant Bowe Bergdahl",
  "id" : 473837068100325376,
  "created_at" : "2014-06-03 14:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Embassy Warsaw",
      "screen_name" : "USEmbassyWarsaw",
      "indices" : [ 3, 19 ],
      "id_str" : "78558366",
      "id" : 78558366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaPL",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473830110467223553",
  "text" : "RT @USEmbassyWarsaw: President Obama -  \"As friends and as allies, we stand united, together and forever. Na zawsze razem\" #ObamaPL http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USEmbassyWarsaw\/status\/473819913413750784\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/6nnoHUGcMJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpNYsvOCAAAZbXi.jpg",
        "id_str" : "473819911416840192",
        "id" : 473819911416840192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpNYsvOCAAAZbXi.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6nnoHUGcMJ"
      } ],
      "hashtags" : [ {
        "text" : "ObamaPL",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473819913413750784",
    "text" : "President Obama -  \"As friends and as allies, we stand united, together and forever. Na zawsze razem\" #ObamaPL http:\/\/t.co\/6nnoHUGcMJ",
    "id" : 473819913413750784,
    "created_at" : "2014-06-03 13:34:05 +0000",
    "user" : {
      "name" : "US Embassy Warsaw",
      "screen_name" : "USEmbassyWarsaw",
      "protected" : false,
      "id_str" : "78558366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671629213024321536\/AQih6xaY_normal.jpg",
      "id" : 78558366,
      "verified" : true
    }
  },
  "id" : 473830110467223553,
  "created_at" : "2014-06-03 14:14:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/I1VORe88le",
      "expanded_url" : "http:\/\/wh.gov\/ClimateChange",
      "display_url" : "wh.gov\/ClimateChange"
    } ]
  },
  "geo" : { },
  "id_str" : "473824366128803840",
  "text" : "Here's why President Obama's clean power plant standards are a big win for our kids' health \u2192 http:\/\/t.co\/I1VORe88le #ActOnClimate",
  "id" : 473824366128803840,
  "created_at" : "2014-06-03 13:51:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/lM3sfRCRpV",
      "expanded_url" : "http:\/\/go.wh.gov\/CTVwi2",
      "display_url" : "go.wh.gov\/CTVwi2"
    } ]
  },
  "geo" : { },
  "id_str" : "473615118865932288",
  "text" : "President Obama shares a moment with young asthma patients. Watch \u2192 http:\/\/t.co\/lM3sfRCRpV #ActOnClimate",
  "id" : 473615118865932288,
  "created_at" : "2014-06-03 00:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 3, 15 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473609464205934592",
  "text" : "RT @YosemiteNPS: We invite you to check out Yosemite's natural operating system. We're good on a computer, but unmatched in person! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YosemiteNPS\/status\/473539321937805312\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ZjTJO74tdQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJZgMSCEAAFO-A.jpg",
        "id_str" : "473539320414867456",
        "id" : 473539320414867456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJZgMSCEAAFO-A.jpg",
        "sizes" : [ {
          "h" : 1023,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 905,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZjTJO74tdQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473539321937805312",
    "text" : "We invite you to check out Yosemite's natural operating system. We're good on a computer, but unmatched in person! http:\/\/t.co\/ZjTJO74tdQ",
    "id" : 473539321937805312,
    "created_at" : "2014-06-02 18:59:06 +0000",
    "user" : {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "protected" : false,
      "id_str" : "18726942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2729953592\/5afe7b5385c9388e33684f8083294beb_normal.png",
      "id" : 18726942,
      "verified" : true
    }
  },
  "id" : 473609464205934592,
  "created_at" : "2014-06-02 23:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/pHp1OwCMAB",
      "expanded_url" : "http:\/\/youtu.be\/ewNH9rP9y94",
      "display_url" : "youtu.be\/ewNH9rP9y94"
    } ]
  },
  "geo" : { },
  "id_str" : "473604814618652672",
  "text" : "\"Do you have asthma as well?\" \u2014A young asthma patient to President Obama: http:\/\/t.co\/pHp1OwCMAB #ActOnClimate",
  "id" : 473604814618652672,
  "created_at" : "2014-06-02 23:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Gore",
      "screen_name" : "algore",
      "indices" : [ 3, 10 ],
      "id_str" : "17220934",
      "id" : 17220934
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 20, 24 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473594828396441600",
  "text" : "RT @algore: Today's @EPA announcement is the most important step taken to combat the climate crisis in our country\u2019s history. http:\/\/t.co\/T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 8, 12 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/TCguLC73Kn",
        "expanded_url" : "http:\/\/ow.ly\/xwmEJ",
        "display_url" : "ow.ly\/xwmEJ"
      } ]
    },
    "geo" : { },
    "id_str" : "473456771596816384",
    "text" : "Today's @EPA announcement is the most important step taken to combat the climate crisis in our country\u2019s history. http:\/\/t.co\/TCguLC73Kn",
    "id" : 473456771596816384,
    "created_at" : "2014-06-02 13:31:05 +0000",
    "user" : {
      "name" : "Al Gore",
      "screen_name" : "algore",
      "protected" : false,
      "id_str" : "17220934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628967431327756288\/_jnfhFgP_normal.jpg",
      "id" : 17220934,
      "verified" : true
    }
  },
  "id" : 473594828396441600,
  "created_at" : "2014-06-02 22:39:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/IKuB4vh8Ab",
      "expanded_url" : "http:\/\/www.governor.maryland.gov\/blog\/?p=10450",
      "display_url" : "governor.maryland.gov\/blog\/?p=10450"
    } ]
  },
  "geo" : { },
  "id_str" : "473589959010820096",
  "text" : "RT @GovernorOMalley: I applaud the President's plan to reduce CO2 pollution from existing power plants http:\/\/t.co\/IKuB4vh8Ab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/IKuB4vh8Ab",
        "expanded_url" : "http:\/\/www.governor.maryland.gov\/blog\/?p=10450",
        "display_url" : "governor.maryland.gov\/blog\/?p=10450"
      } ]
    },
    "geo" : { },
    "id_str" : "473477899774099456",
    "text" : "I applaud the President's plan to reduce CO2 pollution from existing power plants http:\/\/t.co\/IKuB4vh8Ab",
    "id" : 473477899774099456,
    "created_at" : "2014-06-02 14:55:02 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 473589959010820096,
  "created_at" : "2014-06-02 22:20:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473565995613683712",
  "text" : "\"We do not have to choose between the health of our economy and the health of our kids. We can do both.\" \u2014President Obama #ActOnClimate",
  "id" : 473565995613683712,
  "created_at" : "2014-06-02 20:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/RxPSPdYBLA",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "473559746364973056",
  "text" : "\"These new standards are going to help us leave our children a safer and more stable world.\" \u2014Obama: http:\/\/t.co\/RxPSPdYBLA #ActOnClimate",
  "id" : 473559746364973056,
  "created_at" : "2014-06-02 20:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 3, 15 ],
      "id_str" : "133880286",
      "id" : 133880286
    }, {
      "name" : "NRDC",
      "screen_name" : "NRDC",
      "indices" : [ 20, 25 ],
      "id_str" : "18713552",
      "id" : 18713552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Carbon",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "Climate",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473555934573510657",
  "text" : "RT @LeoDiCaprio: RT @NRDC BIG NEWS! EPA Announces New Limits on #Carbon Pollution that Will Protect Health &amp; Tackle #Climate Change http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NRDC",
        "screen_name" : "NRDC",
        "indices" : [ 3, 8 ],
        "id_str" : "18713552",
        "id" : 18713552
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Carbon",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "Climate",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/kut1nkIEQh",
        "expanded_url" : "http:\/\/j.mp\/1tBsvQH",
        "display_url" : "j.mp\/1tBsvQH"
      } ]
    },
    "geo" : { },
    "id_str" : "473530853864128512",
    "text" : "RT @NRDC BIG NEWS! EPA Announces New Limits on #Carbon Pollution that Will Protect Health &amp; Tackle #Climate Change http:\/\/t.co\/kut1nkIEQh",
    "id" : 473530853864128512,
    "created_at" : "2014-06-02 18:25:28 +0000",
    "user" : {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "protected" : false,
      "id_str" : "133880286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694662257586892802\/mdc5ELjj_normal.jpg",
      "id" : 133880286,
      "verified" : true
    }
  },
  "id" : 473555934573510657,
  "created_at" : "2014-06-02 20:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/473553318435110912\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/W44uYS69dr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJmO9DCQAAcjev.jpg",
      "id_str" : "473553317918818304",
      "id" : 473553317918818304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJmO9DCQAAcjev.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/W44uYS69dr"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473553318435110912",
  "text" : "\"We are reducing the carbon pollution that hurts the health of our kids and...the planet.\" \u2014Obama #ActOnClimate http:\/\/t.co\/W44uYS69dr",
  "id" : 473553318435110912,
  "created_at" : "2014-06-02 19:54:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473547325378658304",
  "text" : "RT @AmbassadorPower: POTUS steps to #ActOnClimate by \u2193 carbon pollution make US a leader in efforts to address climate change. Learn more\u2192 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 15, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xD5xl4o92D",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/climate-change",
        "display_url" : "whitehouse.gov\/climate-change"
      } ]
    },
    "geo" : { },
    "id_str" : "473498002846261248",
    "text" : "POTUS steps to #ActOnClimate by \u2193 carbon pollution make US a leader in efforts to address climate change. Learn more\u2192 http:\/\/t.co\/xD5xl4o92D",
    "id" : 473498002846261248,
    "created_at" : "2014-06-02 16:14:55 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 473547325378658304,
  "created_at" : "2014-06-02 19:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 18, 22 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473536539902115842",
  "text" : "RT @ErnestMoniz: .@EPA's Clean Power Plan is a common-sense proposal to #ActOnClimate &amp; create clean energy jobs. My statement \u2192 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 1, 5 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 55, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Qx1wUT1xV0",
        "expanded_url" : "http:\/\/go.usa.gov\/8dWm",
        "display_url" : "go.usa.gov\/8dWm"
      } ]
    },
    "geo" : { },
    "id_str" : "473504581193052162",
    "text" : ".@EPA's Clean Power Plan is a common-sense proposal to #ActOnClimate &amp; create clean energy jobs. My statement \u2192 http:\/\/t.co\/Qx1wUT1xV0",
    "id" : 473504581193052162,
    "created_at" : "2014-06-02 16:41:04 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 473536539902115842,
  "created_at" : "2014-06-02 18:48:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Hollen",
      "screen_name" : "ChrisVanHollen",
      "indices" : [ 3, 18 ],
      "id_str" : "18137749",
      "id" : 18137749
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisVanHollen\/status\/473529545795313664\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/kBmUyGUiFt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJQnHGCUAAfhmY.jpg",
      "id_str" : "473529543676809216",
      "id" : 473529543676809216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJQnHGCUAAfhmY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kBmUyGUiFt"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473529892592967681",
  "text" : "RT @ChrisVanHollen: FACT: The President's plan to clean up our power plants will save lives. #ActOnClimate http:\/\/t.co\/kBmUyGUiFt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisVanHollen\/status\/473529545795313664\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/kBmUyGUiFt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJQnHGCUAAfhmY.jpg",
        "id_str" : "473529543676809216",
        "id" : 473529543676809216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJQnHGCUAAfhmY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kBmUyGUiFt"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473529545795313664",
    "text" : "FACT: The President's plan to clean up our power plants will save lives. #ActOnClimate http:\/\/t.co\/kBmUyGUiFt",
    "id" : 473529545795313664,
    "created_at" : "2014-06-02 18:20:16 +0000",
    "user" : {
      "name" : "Chris Van Hollen",
      "screen_name" : "ChrisVanHollen",
      "protected" : false,
      "id_str" : "18137749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740184981134290948\/g6mNTvEh_normal.jpg",
      "id" : 18137749,
      "verified" : true
    }
  },
  "id" : 473529892592967681,
  "created_at" : "2014-06-02 18:21:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/473522996028522496\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VfdLVHdWJF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpJKp8qCcAAtOsF.jpg",
      "id_str" : "473522995344863232",
      "id" : 473522995344863232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpJKp8qCcAAtOsF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VfdLVHdWJF"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473522996028522496",
  "text" : "FACT: President Obama's clean power plant standards will reduce lost work days and school absences. #ActOnClimate http:\/\/t.co\/VfdLVHdWJF",
  "id" : 473522996028522496,
  "created_at" : "2014-06-02 17:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News Politics",
      "screen_name" : "ABCPolitics",
      "indices" : [ 3, 15 ],
      "id_str" : "16815644",
      "id" : 16815644
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 22, 26 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473516533264957440",
  "text" : "RT @ABCPolitics: NEW: @ABC News poll:\n\n7 in 10 see global warming as serious problem\n\n70% support limiting emissions\n\nMORE: http:\/\/t.co\/5lh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 5, 9 ],
        "id_str" : "28785486",
        "id" : 28785486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/5lhiOGyktz",
        "expanded_url" : "http:\/\/abcn.ws\/1nI93nX",
        "display_url" : "abcn.ws\/1nI93nX"
      } ]
    },
    "geo" : { },
    "id_str" : "473513330548543489",
    "text" : "NEW: @ABC News poll:\n\n7 in 10 see global warming as serious problem\n\n70% support limiting emissions\n\nMORE: http:\/\/t.co\/5lhiOGyktz",
    "id" : 473513330548543489,
    "created_at" : "2014-06-02 17:15:50 +0000",
    "user" : {
      "name" : "ABC News Politics",
      "screen_name" : "ABCPolitics",
      "protected" : false,
      "id_str" : "16815644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471678921621008384\/rTCCKGJr_normal.jpeg",
      "id" : 16815644,
      "verified" : true
    }
  },
  "id" : 473516533264957440,
  "created_at" : "2014-06-02 17:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473512725789024256",
  "text" : "RT @VP: Our plan to #ActOnClimate will:   \nCut carbon emission by 30% \u2713\nAvoid up to 6,500 deaths\/yr \u2713\nCreate tens of thousands of jobs \u2713",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473492990657576961",
    "text" : "Our plan to #ActOnClimate will:   \nCut carbon emission by 30% \u2713\nAvoid up to 6,500 deaths\/yr \u2713\nCreate tens of thousands of jobs \u2713",
    "id" : 473492990657576961,
    "created_at" : "2014-06-02 15:55:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 473512725789024256,
  "created_at" : "2014-06-02 17:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sierra Club",
      "screen_name" : "sierraclub",
      "indices" : [ 3, 14 ],
      "id_str" : "34113439",
      "id" : 34113439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473510433824190464",
  "text" : "RT @sierraclub: FACT: President Obama's clean power plant standards will prevent up to 6,600 premature deaths\/year. #ActOnClimate http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sierraclub\/status\/473496545074360320\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Bat0J9QwEb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIymR7IEAAB01C.jpg",
        "id_str" : "473496544055136256",
        "id" : 473496544055136256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIymR7IEAAB01C.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Bat0J9QwEb"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473496545074360320",
    "text" : "FACT: President Obama's clean power plant standards will prevent up to 6,600 premature deaths\/year. #ActOnClimate http:\/\/t.co\/Bat0J9QwEb",
    "id" : 473496545074360320,
    "created_at" : "2014-06-02 16:09:08 +0000",
    "user" : {
      "name" : "Sierra Club",
      "screen_name" : "sierraclub",
      "protected" : false,
      "id_str" : "34113439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796403288262475777\/TnaMEVYQ_normal.jpg",
      "id" : 34113439,
      "verified" : true
    }
  },
  "id" : 473510433824190464,
  "created_at" : "2014-06-02 17:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/NSyGujgHfn",
      "expanded_url" : "http:\/\/wh.gov\/ClimateChange",
      "display_url" : "wh.gov\/ClimateChange"
    } ]
  },
  "geo" : { },
  "id_str" : "473498087558639617",
  "text" : "FACT: President Obama's clean power plant standards would prevent 310,000 lost work days per year. http:\/\/t.co\/NSyGujgHfn #ActOnClimate",
  "id" : 473498087558639617,
  "created_at" : "2014-06-02 16:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Henry A. Waxman",
      "screen_name" : "WaxmanClimate",
      "indices" : [ 3, 17 ],
      "id_str" : "785414496",
      "id" : 785414496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473494648405889024",
  "text" : "RT @WaxmanClimate: Clean Power Plan\u2019s health and climate benefits of up to $93 billion in 2030 dwarf the costs. #ActOnClimate http:\/\/t.co\/0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/0xyBXJS1Sr",
        "expanded_url" : "http:\/\/1.usa.gov\/1jMeEBe",
        "display_url" : "1.usa.gov\/1jMeEBe"
      } ]
    },
    "geo" : { },
    "id_str" : "473480971933999106",
    "text" : "Clean Power Plan\u2019s health and climate benefits of up to $93 billion in 2030 dwarf the costs. #ActOnClimate http:\/\/t.co\/0xyBXJS1Sr",
    "id" : 473480971933999106,
    "created_at" : "2014-06-02 15:07:15 +0000",
    "user" : {
      "name" : "Rep. Henry A. Waxman",
      "screen_name" : "WaxmanClimate",
      "protected" : false,
      "id_str" : "785414496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2550008991\/sva9pp1tvfqix7r7xjhb_normal.jpeg",
      "id" : 785414496,
      "verified" : true
    }
  },
  "id" : 473494648405889024,
  "created_at" : "2014-06-02 16:01:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/473489013576597505\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/Dy4ETZfnG8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIrv6WCUAAPbOa.jpg",
      "id_str" : "473489012942852096",
      "id" : 473489012942852096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIrv6WCUAAPbOa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Dy4ETZfnG8"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473489013576597505",
  "text" : "Spread the word: The President's clean power plant standards would reduce soot &amp; smog by 25% in 2030. #ActOnClimate http:\/\/t.co\/Dy4ETZfnG8",
  "id" : 473489013576597505,
  "created_at" : "2014-06-02 15:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 31, 35 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473484261048455168",
  "text" : "RT @SecretaryJewell: I applaud @EPA\u2019s common sense, flexible steps to work with states to reduce carbon pollution &amp; protect public health. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 10, 14 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473479880198197248",
    "text" : "I applaud @EPA\u2019s common sense, flexible steps to work with states to reduce carbon pollution &amp; protect public health. SJ #ActOnClimate",
    "id" : 473479880198197248,
    "created_at" : "2014-06-02 15:02:54 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 473484261048455168,
  "created_at" : "2014-06-02 15:20:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 99, 107 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/JFwUrxcZUd",
      "expanded_url" : "http:\/\/epa.gov",
      "display_url" : "epa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "473477998306684928",
  "text" : "RT @WHLive: \"We will never...have to choose between a healthy economy and a healthy environment.\" \u2014@GinaEPA: http:\/\/t.co\/JFwUrxcZUd #ActOnC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 87, 95 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/JFwUrxcZUd",
        "expanded_url" : "http:\/\/epa.gov",
        "display_url" : "epa.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "473477780496453632",
    "text" : "\"We will never...have to choose between a healthy economy and a healthy environment.\" \u2014@GinaEPA: http:\/\/t.co\/JFwUrxcZUd #ActOnClimate",
    "id" : 473477780496453632,
    "created_at" : "2014-06-02 14:54:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 473477998306684928,
  "created_at" : "2014-06-02 14:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 76, 84 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/473476717928271872\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/YuYsIK0CTI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIgkN8CYAAnUXh.jpg",
      "id_str" : "473476717416177664",
      "id" : 473476717416177664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIgkN8CYAAnUXh.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YuYsIK0CTI"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473476717928271872",
  "text" : "\"This is an investment in better health and a better future for our kids.\" \u2014@GinaEPA #ActOnClimate http:\/\/t.co\/YuYsIK0CTI",
  "id" : 473476717928271872,
  "created_at" : "2014-06-02 14:50:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/i2AOoIboJH",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/06\/02\/numbers-epas-proposed-new-carbon-pollution-standards-power-plants",
      "display_url" : "whitehouse.gov\/blog\/2014\/06\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473475167637999616",
  "text" : "RT @Podesta44: By the numbers: EPA\u2019s carbon pollution limits will spur innovation, create jobs, &amp; cut electric bills http:\/\/t.co\/i2AOoIboJH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 129, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/i2AOoIboJH",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/06\/02\/numbers-epas-proposed-new-carbon-pollution-standards-power-plants",
        "display_url" : "whitehouse.gov\/blog\/2014\/06\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473466924517838848",
    "text" : "By the numbers: EPA\u2019s carbon pollution limits will spur innovation, create jobs, &amp; cut electric bills http:\/\/t.co\/i2AOoIboJH #ActOnClimate",
    "id" : 473466924517838848,
    "created_at" : "2014-06-02 14:11:26 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 473475167637999616,
  "created_at" : "2014-06-02 14:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 48, 56 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/473473078660321280\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Igl7OGXG4c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIdQX2CQAEwyxZ.jpg",
      "id_str" : "473473077943091201",
      "id" : 473473077943091201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIdQX2CQAEwyxZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Igl7OGXG4c"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Ff78UZdiq7",
      "expanded_url" : "http:\/\/epa.gov",
      "display_url" : "epa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "473473078660321280",
  "text" : "\"We have a moral obligation to #ActOnClimate.\" \u2014@GinaEPA on clean power plant standards: http:\/\/t.co\/Ff78UZdiq7 http:\/\/t.co\/Igl7OGXG4c",
  "id" : 473473078660321280,
  "created_at" : "2014-06-02 14:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Cunningham",
      "screen_name" : "CunningDC",
      "indices" : [ 3, 13 ],
      "id_str" : "117232710",
      "id" : 117232710
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 58, 62 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CO2",
      "indices" : [ 71, 75 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/uGKfUcGamh",
      "expanded_url" : "http:\/\/www.ceres.org\/press\/press-releases\/unilever-vf-corp.-mars-incorporated-and-new-york-state-comptroller-join-173-companies-and-investors-in-supporting-epa2019s-new-carbon-standard",
      "display_url" : "ceres.org\/press\/press-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "473471281078501376",
  "text" : "RT @CunningDC: BREAKING: 173 companies, investors endorse @EPA rule on #CO2 http:\/\/t.co\/uGKfUcGamh #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 43, 47 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CO2",
        "indices" : [ 56, 60 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 84, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/uGKfUcGamh",
        "expanded_url" : "http:\/\/www.ceres.org\/press\/press-releases\/unilever-vf-corp.-mars-incorporated-and-new-york-state-comptroller-join-173-companies-and-investors-in-supporting-epa2019s-new-carbon-standard",
        "display_url" : "ceres.org\/press\/press-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473468334206648320",
    "text" : "BREAKING: 173 companies, investors endorse @EPA rule on #CO2 http:\/\/t.co\/uGKfUcGamh #ActOnClimate",
    "id" : 473468334206648320,
    "created_at" : "2014-06-02 14:17:02 +0000",
    "user" : {
      "name" : "Ryan Cunningham",
      "screen_name" : "CunningDC",
      "protected" : false,
      "id_str" : "117232710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464148938669318144\/Xtd621pB_normal.png",
      "id" : 117232710,
      "verified" : false
    }
  },
  "id" : 473471281078501376,
  "created_at" : "2014-06-02 14:28:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Lung Assoc.",
      "screen_name" : "LungAssociation",
      "indices" : [ 3, 19 ],
      "id_str" : "17049255",
      "id" : 17049255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473468900550926336",
  "text" : "RT @LungAssociation: Pres Obama just announced proposed carbon pollution standards that would protect health of millions. Our statement: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/WHbvcyi8hN",
        "expanded_url" : "http:\/\/bit.ly\/1pzzRGD",
        "display_url" : "bit.ly\/1pzzRGD"
      } ]
    },
    "geo" : { },
    "id_str" : "473451307932454912",
    "text" : "Pres Obama just announced proposed carbon pollution standards that would protect health of millions. Our statement: http:\/\/t.co\/WHbvcyi8hN",
    "id" : 473451307932454912,
    "created_at" : "2014-06-02 13:09:22 +0000",
    "user" : {
      "name" : "American Lung Assoc.",
      "screen_name" : "LungAssociation",
      "protected" : false,
      "id_str" : "17049255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793832199393083396\/tXG5UoDG_normal.jpg",
      "id" : 17049255,
      "verified" : false
    }
  },
  "id" : 473468900550926336,
  "created_at" : "2014-06-02 14:19:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/NSyGujgHfn",
      "expanded_url" : "http:\/\/wh.gov\/ClimateChange",
      "display_url" : "wh.gov\/ClimateChange"
    } ]
  },
  "geo" : { },
  "id_str" : "473465338583977985",
  "text" : "FACT: President Obama's clean power plant standards would prevent 180,000 school absences per year. http:\/\/t.co\/NSyGujgHfn #ActOnClimate",
  "id" : 473465338583977985,
  "created_at" : "2014-06-02 14:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473458431748505600",
  "text" : "RT @GinaEPA: What a big day! Our proposed Clean Power Plan will #ActOnClimate &amp; protect the health of our kids. Find out more http:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 51, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/C983HYAJDp",
        "expanded_url" : "http:\/\/www2.epa.gov\/carbon-pollution-standards",
        "display_url" : "www2.epa.gov\/carbon-polluti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "473457025784221697",
    "text" : "What a big day! Our proposed Clean Power Plan will #ActOnClimate &amp; protect the health of our kids. Find out more http:\/\/t.co\/C983HYAJDp",
    "id" : 473457025784221697,
    "created_at" : "2014-06-02 13:32:06 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 473458431748505600,
  "created_at" : "2014-06-02 13:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/473455787365662720\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/qu55I4ihhT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpINh5OCMAESPZn.jpg",
      "id_str" : "473455786773852161",
      "id" : 473455786773852161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpINh5OCMAESPZn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qu55I4ihhT"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473455787365662720",
  "text" : "RT to spread the word: President Obama just took a big step to #ActOnClimate and protect our health. http:\/\/t.co\/qu55I4ihhT",
  "id" : 473455787365662720,
  "created_at" : "2014-06-02 13:27:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 10, 14 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/NSyGujgHfn",
      "expanded_url" : "http:\/\/wh.gov\/ClimateChange",
      "display_url" : "wh.gov\/ClimateChange"
    } ]
  },
  "geo" : { },
  "id_str" : "473452038571847681",
  "text" : "Big news: @EPA just proposed carbon pollution standards for power plants to protect our kids' health \u2192 http:\/\/t.co\/NSyGujgHfn #ActOnClimate",
  "id" : 473452038571847681,
  "created_at" : "2014-06-02 13:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/473275954127974401\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/FVLqQKc0sB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpFp-PAIYAAgRKD.jpg",
      "id_str" : "473275953750499328",
      "id" : 473275953750499328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpFp-PAIYAAgRKD.jpg",
      "sizes" : [ {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FVLqQKc0sB"
    } ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "EarthRightNow",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/SzKE9QBfU8",
      "expanded_url" : "http:\/\/climate.nasa.gov\/evidence",
      "display_url" : "climate.nasa.gov\/evidence"
    } ]
  },
  "geo" : { },
  "id_str" : "473291503587299328",
  "text" : "RT @NASA: As seen on #Cosmos: Climate change: http:\/\/t.co\/SzKE9QBfU8\u00A0\u00A0\u00A0#EarthRightNow http:\/\/t.co\/FVLqQKc0sB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/473275954127974401\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/FVLqQKc0sB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpFp-PAIYAAgRKD.jpg",
        "id_str" : "473275953750499328",
        "id" : 473275953750499328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpFp-PAIYAAgRKD.jpg",
        "sizes" : [ {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/FVLqQKc0sB"
      } ],
      "hashtags" : [ {
        "text" : "Cosmos",
        "indices" : [ 11, 18 ]
      }, {
        "text" : "EarthRightNow",
        "indices" : [ 61, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/SzKE9QBfU8",
        "expanded_url" : "http:\/\/climate.nasa.gov\/evidence",
        "display_url" : "climate.nasa.gov\/evidence"
      } ]
    },
    "geo" : { },
    "id_str" : "473275954127974401",
    "text" : "As seen on #Cosmos: Climate change: http:\/\/t.co\/SzKE9QBfU8\u00A0\u00A0\u00A0#EarthRightNow http:\/\/t.co\/FVLqQKc0sB",
    "id" : 473275954127974401,
    "created_at" : "2014-06-02 01:32:35 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 473291503587299328,
  "created_at" : "2014-06-02 02:34:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "473154551600533504",
  "text" : "\"Every four minutes, another American home or business goes solar.\" \u2014President Obama: http:\/\/t.co\/vH98WRY86K #ActOnClimate",
  "id" : 473154551600533504,
  "created_at" : "2014-06-01 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "473131883300024320",
  "text" : "\"Climate change is no longer a distant threat\u2014it has moved firmly into the present.\" \u2014President Obama: http:\/\/t.co\/vH98WRY86K #ActOnClimate",
  "id" : 473131883300024320,
  "created_at" : "2014-06-01 16:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "473109261384302592",
  "text" : "\"For the sake of all our kids, we\u2019ve got to do more.\" \u2014President Obama on reducing carbon pollution: http:\/\/t.co\/vH98WRY86K #ActOnClimate",
  "id" : 473109261384302592,
  "created_at" : "2014-06-01 14:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]