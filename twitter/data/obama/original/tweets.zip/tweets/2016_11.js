Grailbird.data.tweets_2016_11 = 
[ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/AaiB2A6iNg",
      "expanded_url" : "http:\/\/snpy.tv\/2f3WnrO",
      "display_url" : "snpy.tv\/2f3WnrO"
    } ]
  },
  "geo" : { },
  "id_str" : "798914779213500422",
  "text" : "\"Nothing can break the spirit of the Greek people. You will overcome this period of challenge\" \u2014@POTUS in Athens https:\/\/t.co\/AaiB2A6iNg",
  "id" : 798914779213500422,
  "created_at" : "2016-11-16 15:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/dyXIgY2hcv",
      "expanded_url" : "http:\/\/snpy.tv\/2fF7a9R",
      "display_url" : "snpy.tv\/2fF7a9R"
    } ]
  },
  "geo" : { },
  "id_str" : "798909747357450240",
  "text" : "\"We've proven that you can grow the economy and reduce the carbon emissions that cause climate change\" \u2014@POTUS https:\/\/t.co\/dyXIgY2hcv",
  "id" : 798909747357450240,
  "created_at" : "2016-11-16 15:25:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/OZRd5o4wRL",
      "expanded_url" : "http:\/\/snpy.tv\/2f3VOy5",
      "display_url" : "snpy.tv\/2f3VOy5"
    } ]
  },
  "geo" : { },
  "id_str" : "798908490152448001",
  "text" : "\"The basic longing to live with dignity...these yearnings are universal. They burn in every human heart.\" \u2014@POTUS https:\/\/t.co\/OZRd5o4wRL",
  "id" : 798908490152448001,
  "created_at" : "2016-11-16 15:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 61, 75 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798907196469870592",
  "text" : "RT @SecBurwell: Over a million people selected plans through @HealthCareGov in the first 12 days of Open Enrollment. #GetCovered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 45, 59 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798902493631696896",
    "text" : "Over a million people selected plans through @HealthCareGov in the first 12 days of Open Enrollment. #GetCovered",
    "id" : 798902493631696896,
    "created_at" : "2016-11-16 14:56:12 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 798907196469870592,
  "created_at" : "2016-11-16 15:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/PIO9dG2qjX",
      "expanded_url" : "http:\/\/snpy.tv\/2fwHTBp",
      "display_url" : "snpy.tv\/2fwHTBp"
    } ]
  },
  "geo" : { },
  "id_str" : "798899681472421888",
  "text" : "\"Democracy...allows us to peacefully work through our differences, and move closer to our ideals\" \u2014@POTUS in Greece https:\/\/t.co\/PIO9dG2qjX",
  "id" : 798899681472421888,
  "created_at" : "2016-11-16 14:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/fegVH0ZMiZ",
      "expanded_url" : "http:\/\/snpy.tv\/2fVEjNS",
      "display_url" : "snpy.tv\/2fVEjNS"
    } ]
  },
  "geo" : { },
  "id_str" : "798893390775615492",
  "text" : "\"We can't look backwards for answers, we have to look forward.\" \u2014@POTUS on a global economy that works for all https:\/\/t.co\/fegVH0ZMiZ",
  "id" : 798893390775615492,
  "created_at" : "2016-11-16 14:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/U1JdFreaeD",
      "expanded_url" : "http:\/\/snpy.tv\/2fVC4dG",
      "display_url" : "snpy.tv\/2fVC4dG"
    } ]
  },
  "geo" : { },
  "id_str" : "798884581923397632",
  "text" : "\u201CIn all of our nations it will always be our citizens who decide the kind of countries we will be\u201D \u2014@POTUS in Greece https:\/\/t.co\/U1JdFreaeD",
  "id" : 798884581923397632,
  "created_at" : "2016-11-16 13:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/unlbc5VHNu",
      "expanded_url" : "http:\/\/snpy.tv\/2fYdyKi",
      "display_url" : "snpy.tv\/2fYdyKi"
    } ]
  },
  "geo" : { },
  "id_str" : "798877430207365121",
  "text" : "\"The flame first lit here\u2026was fanned by America\u2019s founders who declared that 'We, the People' shall rule\" \u2014@POTUS https:\/\/t.co\/unlbc5VHNu",
  "id" : 798877430207365121,
  "created_at" : "2016-11-16 13:16:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798872343007334400",
  "text" : "\u201CI still believe there\u2019s more of what Greeks call philotimo\u2014love and respect and kindness for family and community and country\" \u2014@POTUS",
  "id" : 798872343007334400,
  "created_at" : "2016-11-16 12:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798871271706685440",
  "text" : "\"Progress is never guaranteed. Progress has to be earned by every generation. But I believe history gives us hope.\" \u2014@POTUS in Athens",
  "id" : 798871271706685440,
  "created_at" : "2016-11-16 12:52:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798870387773865984",
  "text" : "\"We must make clear that governments exist to serve the interests of citizens, and not the other way around.\"  \u2014@POTUS",
  "id" : 798870387773865984,
  "created_at" : "2016-11-16 12:48:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798869792912502784",
  "text" : "\"We have to keep making government more open, more efficient, more effective in responding to the daily needs of citizens.\" \u2014@POTUS",
  "id" : 798869792912502784,
  "created_at" : "2016-11-16 12:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798868003832168448\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/NQbHiAxwcZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxYl-xKVIAA5p7o.jpg",
      "id_str" : "798867744183623680",
      "id" : 798867744183623680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxYl-xKVIAA5p7o.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/NQbHiAxwcZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798868003832168448",
  "text" : "\u201CToday our uninsured rate is at its lowest level on record.\u201D \u2014@POTUS on our progress https:\/\/t.co\/NQbHiAxwcZ",
  "id" : 798868003832168448,
  "created_at" : "2016-11-16 12:39:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798867687644479488\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/AWHWyEWV6u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxYl5hkUkAAVOai.jpg",
      "id_str" : "798867654098325504",
      "id" : 798867654098325504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxYl5hkUkAAVOai.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/AWHWyEWV6u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798867687644479488",
  "text" : "Today, our businesses have created more than 15 million new jobs.\u201D \u2014@POTUS https:\/\/t.co\/AWHWyEWV6u",
  "id" : 798867687644479488,
  "created_at" : "2016-11-16 12:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798865284014735360",
  "text" : "\"My Administration will do everything we can to support the smoothest transition possible\u2014because that\u2019s how democracy has to work\" \u2014@POTUS",
  "id" : 798865284014735360,
  "created_at" : "2016-11-16 12:28:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798865030569742336",
  "text" : "\u201CThe next American president and I could not be more different\u2026But American democracy is bigger than any one person.\u201D \u2014@POTUS",
  "id" : 798865030569742336,
  "created_at" : "2016-11-16 12:27:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798864959996305408",
  "text" : "\"We compete hard in campaigns. But even after elections, democracy depends on a peaceful transition of power\" \u2014@POTUS",
  "id" : 798864959996305408,
  "created_at" : "2016-11-16 12:27:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798864573965148160",
  "text" : "\u201CFree and fair elections\u2014because citizens must be able to choose their own leaders, even if your candidate doesn\u2019t always win.\u201D \u2014@POTUS",
  "id" : 798864573965148160,
  "created_at" : "2016-11-16 12:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798864325653970944",
  "text" : "\u201CFreedom of speech and assembly\u2014because true legitimacy can only come from the people, who must never be silenced.\u201D \u2014@POTUS in Athens",
  "id" : 798864325653970944,
  "created_at" : "2016-11-16 12:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798863906416500736",
  "text" : "\"Democracy\u2026is imperfect. It can be slow. It can be frustrating. It can be hard. It can be messy.\" \u2014@POTUS speaking in Athens, Greece",
  "id" : 798863906416500736,
  "created_at" : "2016-11-16 12:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "NATO",
      "screen_name" : "NATO",
      "indices" : [ 20, 25 ],
      "id_str" : "83795099",
      "id" : 83795099
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798863127819460609",
  "text" : "RT @NSC44: \u201CToday's @NATO\u2014the world\u2019s greatest alliance\u2014is as strong and ready as it has ever been\u201D-@POTUS speaking in Greece. \nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NATO",
        "screen_name" : "NATO",
        "indices" : [ 9, 14 ],
        "id_str" : "83795099",
        "id" : 83795099
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 89, 95 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/kuFNYXT4hY",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/president-obama-delivers-remarks-stavros-niarchos-foundation-cultural-center",
        "display_url" : "whitehouse.gov\/live\/president\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798862658955079681",
    "text" : "\u201CToday's @NATO\u2014the world\u2019s greatest alliance\u2014is as strong and ready as it has ever been\u201D-@POTUS speaking in Greece. \nhttps:\/\/t.co\/kuFNYXT4hY",
    "id" : 798862658955079681,
    "created_at" : "2016-11-16 12:17:54 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 798863127819460609,
  "created_at" : "2016-11-16 12:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798863066473660416",
  "text" : "\u201CCountries that uphold democratic governance tend to be more just, more stable &amp; more successful\u201D \u2014@POTUS in Athens",
  "id" : 798863066473660416,
  "created_at" : "2016-11-16 12:19:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798859646186373122",
  "text" : "\"I came here with all the gratitude that Greece\u2014'this small, great world'\u2014has given humanity through the ages.\" \u2014@POTUS in Athens",
  "id" : 798859646186373122,
  "created_at" : "2016-11-16 12:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/EDN3hVWRXQ",
      "expanded_url" : "http:\/\/go.wh.gov\/euDhot",
      "display_url" : "go.wh.gov\/euDhot"
    } ]
  },
  "geo" : { },
  "id_str" : "798859035965472768",
  "text" : "RT @WHLive: Happening now: @POTUS speaks in Athens\u2014the birthplace of democracy\u2014during his final foreign trip: https:\/\/t.co\/EDN3hVWRXQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/EDN3hVWRXQ",
        "expanded_url" : "http:\/\/go.wh.gov\/euDhot",
        "display_url" : "go.wh.gov\/euDhot"
      } ]
    },
    "geo" : { },
    "id_str" : "798858941526482945",
    "text" : "Happening now: @POTUS speaks in Athens\u2014the birthplace of democracy\u2014during his final foreign trip: https:\/\/t.co\/EDN3hVWRXQ",
    "id" : 798858941526482945,
    "created_at" : "2016-11-16 12:03:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 798859035965472768,
  "created_at" : "2016-11-16 12:03:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ZoEtmIdbi6",
      "expanded_url" : "http:\/\/go.wh.gov\/euDhot",
      "display_url" : "go.wh.gov\/euDhot"
    } ]
  },
  "geo" : { },
  "id_str" : "798851233540755456",
  "text" : "At 6:50am ET, @POTUS speaks in Athens\u2014the birthplace of democracy\u2014during his final foreign trip. Tune in: https:\/\/t.co\/ZoEtmIdbi6",
  "id" : 798851233540755456,
  "created_at" : "2016-11-16 11:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Usher Raymond IV",
      "screen_name" : "Usher",
      "indices" : [ 3, 9 ],
      "id_str" : "40908929",
      "id" : 40908929
    }, {
      "name" : "BET",
      "screen_name" : "BET",
      "indices" : [ 72, 76 ],
      "id_str" : "16560657",
      "id" : 16560657
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Usher\/status\/798693545196613635\/video\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/iVXSY1DmIM",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/798693339457388544\/pu\/img\/bxPVvjQ3i0wDZasb.jpg",
      "id_str" : "798693339457388544",
      "id" : 798693339457388544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/798693339457388544\/pu\/img\/bxPVvjQ3i0wDZasb.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iVXSY1DmIM"
    } ],
    "hashtags" : [ {
      "text" : "ThankYouObama",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798711247705407490",
  "text" : "RT @Usher: Tonight is all about Love &amp; Happiness. Watch at 9P\/8C on @BET. #ThankYouObama https:\/\/t.co\/iVXSY1DmIM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BET",
        "screen_name" : "BET",
        "indices" : [ 61, 65 ],
        "id_str" : "16560657",
        "id" : 16560657
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Usher\/status\/798693545196613635\/video\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/iVXSY1DmIM",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/798693339457388544\/pu\/img\/bxPVvjQ3i0wDZasb.jpg",
        "id_str" : "798693339457388544",
        "id" : 798693339457388544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/798693339457388544\/pu\/img\/bxPVvjQ3i0wDZasb.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iVXSY1DmIM"
      } ],
      "hashtags" : [ {
        "text" : "ThankYouObama",
        "indices" : [ 67, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798693545196613635",
    "text" : "Tonight is all about Love &amp; Happiness. Watch at 9P\/8C on @BET. #ThankYouObama https:\/\/t.co\/iVXSY1DmIM",
    "id" : 798693545196613635,
    "created_at" : "2016-11-16 01:05:54 +0000",
    "user" : {
      "name" : "Usher Raymond IV",
      "screen_name" : "Usher",
      "protected" : false,
      "id_str" : "40908929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740943946646491137\/mEUrvXAO_normal.jpg",
      "id" : 40908929,
      "verified" : true
    }
  },
  "id" : 798711247705407490,
  "created_at" : "2016-11-16 02:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798706292302942209\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/bEQ3GiCSo5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxWTFhDXUAQXfe_.jpg",
      "id_str" : "798706231909240836",
      "id" : 798706231909240836,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxWTFhDXUAQXfe_.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bEQ3GiCSo5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798706292302942209",
  "text" : "\"I want to thank the Greek people publicly for their humanitarian response to the crisis of so many migrants and refugees\" \u2014@POTUS in Athens https:\/\/t.co\/bEQ3GiCSo5",
  "id" : 798706292302942209,
  "created_at" : "2016-11-16 01:56:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "NATO",
      "screen_name" : "NATO",
      "indices" : [ 99, 104 ],
      "id_str" : "83795099",
      "id" : 83795099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798693687140249600",
  "text" : "RT @NSC44: The US values Greece as a democratic &amp; stable member of the Euro-Atlantic family, a @NATO ally, &amp; a member state of the European\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NATO",
        "screen_name" : "NATO",
        "indices" : [ 88, 93 ],
        "id_str" : "83795099",
        "id" : 83795099
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSC44\/status\/798692896543305728\/photo\/1",
        "indices" : [ 144, 167 ],
        "url" : "https:\/\/t.co\/HcdDUHUPSo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxWG7q7UkAAxEKd.jpg",
        "id_str" : "798692868621635584",
        "id" : 798692868621635584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxWG7q7UkAAxEKd.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/HcdDUHUPSo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798692896543305728",
    "text" : "The US values Greece as a democratic &amp; stable member of the Euro-Atlantic family, a @NATO ally, &amp; a member state of the European Union. https:\/\/t.co\/HcdDUHUPSo",
    "id" : 798692896543305728,
    "created_at" : "2016-11-16 01:03:20 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 798693687140249600,
  "created_at" : "2016-11-16 01:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798689990167371777",
  "text" : "RT @LaborSec: The minimum wage isn't a red or a blue issue. Congrats to AZ, CO, ME and WA for voting to #RaiseTheWage: https:\/\/t.co\/zUAd1OZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/zUAd1OZSPG",
        "expanded_url" : "https:\/\/blog.dol.gov\/2016\/11\/10\/states-will-raisethewage-for-more-than-2-million-workers\/",
        "display_url" : "blog.dol.gov\/2016\/11\/10\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "796813860871225344",
    "text" : "The minimum wage isn't a red or a blue issue. Congrats to AZ, CO, ME and WA for voting to #RaiseTheWage: https:\/\/t.co\/zUAd1OZSPG",
    "id" : 796813860871225344,
    "created_at" : "2016-11-10 20:36:43 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 798689990167371777,
  "created_at" : "2016-11-16 00:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798653215512199168",
  "text" : "RT @FactsOnClimate: When we #ActOnClimate, we protect our planet\u2014and our economy. Here's how climate change could cost us billions: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/798646825481891841\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/XdpuDizyV5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxVdCCLUAAA3pcz.jpg",
        "id_str" : "798646798453571584",
        "id" : 798646798453571584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxVdCCLUAAA3pcz.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/XdpuDizyV5"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 8, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/pfT2JqdZ4I",
        "expanded_url" : "http:\/\/go.wh.gov\/2aA4PB",
        "display_url" : "go.wh.gov\/2aA4PB"
      } ]
    },
    "geo" : { },
    "id_str" : "798646825481891841",
    "text" : "When we #ActOnClimate, we protect our planet\u2014and our economy. Here's how climate change could cost us billions: https:\/\/t.co\/pfT2JqdZ4I https:\/\/t.co\/XdpuDizyV5",
    "id" : 798646825481891841,
    "created_at" : "2016-11-15 22:00:15 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 798653215512199168,
  "created_at" : "2016-11-15 22:25:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798640901857755136\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/zwLHYVyJ8l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxVXigPW8AQ58H6.jpg",
      "id_str" : "798640759209652228",
      "id" : 798640759209652228,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxVXigPW8AQ58H6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zwLHYVyJ8l"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 11, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fWufnSgeMj",
      "expanded_url" : "http:\/\/go.wh.gov\/2aA4PB",
      "display_url" : "go.wh.gov\/2aA4PB"
    } ]
  },
  "geo" : { },
  "id_str" : "798640901857755136",
  "text" : "Failing to #ActOnClimate could cost us billions each year. Here's why we can't afford to ignore these risks: https:\/\/t.co\/fWufnSgeMj https:\/\/t.co\/zwLHYVyJ8l",
  "id" : 798640901857755136,
  "created_at" : "2016-11-15 21:36:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798634716907900928",
  "text" : "RT @AmbassadorRice: As winter approaches, we can all do more to help refugees in need. Learn more about our efforts to #AidRefugees: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/jElTSt2VM1",
        "expanded_url" : "http:\/\/aidrefugees.gov",
        "display_url" : "aidrefugees.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "798621442128519168",
    "text" : "As winter approaches, we can all do more to help refugees in need. Learn more about our efforts to #AidRefugees: https:\/\/t.co\/jElTSt2VM1",
    "id" : 798621442128519168,
    "created_at" : "2016-11-15 20:19:24 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 798634716907900928,
  "created_at" : "2016-11-15 21:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798604649645412352",
  "text" : "RT @Interior: New methane rule means cutting natural gas waste &amp; cleaner air while ensuring fair return to taxpayers https:\/\/t.co\/P79i4uXuJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/798577061560520705\/photo\/1",
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/lhJorwRx74",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxUdO75WgAEsfbM.jpg",
        "id_str" : "798576651361746945",
        "id" : 798576651361746945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxUdO75WgAEsfbM.jpg",
        "sizes" : [ {
          "h" : 736,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/lhJorwRx74"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/P79i4uXuJ5",
        "expanded_url" : "http:\/\/on.doi.gov\/2fuBCpx",
        "display_url" : "on.doi.gov\/2fuBCpx"
      } ]
    },
    "geo" : { },
    "id_str" : "798577061560520705",
    "text" : "New methane rule means cutting natural gas waste &amp; cleaner air while ensuring fair return to taxpayers https:\/\/t.co\/P79i4uXuJ5 https:\/\/t.co\/lhJorwRx74",
    "id" : 798577061560520705,
    "created_at" : "2016-11-15 17:23:02 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 798604649645412352,
  "created_at" : "2016-11-15 19:12:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Mp5JEi0okc",
      "expanded_url" : "https:\/\/medium.com\/the-white-house\/the-president-abroad-a-look-ahead-at-greece-germany-and-peru-265b9c00a94e#.kkloecrq6",
      "display_url" : "medium.com\/the-white-hous\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "798593974797672449",
  "text" : "RT @AmbassadorRice: Happy to be back in Greece! The democratic values we share are the bedrock of our partnership. \nhttps:\/\/t.co\/Mp5JEi0okc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/Mp5JEi0okc",
        "expanded_url" : "https:\/\/medium.com\/the-white-house\/the-president-abroad-a-look-ahead-at-greece-germany-and-peru-265b9c00a94e#.kkloecrq6",
        "display_url" : "medium.com\/the-white-hous\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798536257487781888",
    "text" : "Happy to be back in Greece! The democratic values we share are the bedrock of our partnership. \nhttps:\/\/t.co\/Mp5JEi0okc",
    "id" : 798536257487781888,
    "created_at" : "2016-11-15 14:40:54 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 798593974797672449,
  "created_at" : "2016-11-15 18:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798590791572537344",
  "text" : "RT @OMBPress: Failure to address climate change could cost the Federal Govt &amp; taxpayers hundreds of billions of dollars each year: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/LdPJJUuRIZ",
        "expanded_url" : "http:\/\/bit.ly\/2fUNQZd",
        "display_url" : "bit.ly\/2fUNQZd"
      } ]
    },
    "geo" : { },
    "id_str" : "798585212435206144",
    "text" : "Failure to address climate change could cost the Federal Govt &amp; taxpayers hundreds of billions of dollars each year: https:\/\/t.co\/LdPJJUuRIZ",
    "id" : 798585212435206144,
    "created_at" : "2016-11-15 17:55:26 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 798590791572537344,
  "created_at" : "2016-11-15 18:17:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VyPrS7g30R",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSabroad",
      "display_url" : "go.wh.gov\/POTUSabroad"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/NLCn3VfcHf",
      "expanded_url" : "http:\/\/snpy.tv\/2fscSye",
      "display_url" : "snpy.tv\/2fscSye"
    } ]
  },
  "geo" : { },
  "id_str" : "798571271847952384",
  "text" : "\u201CAmerica will be right there with you as your partner, and as your friend.\u201D \u2014@POTUS: https:\/\/t.co\/VyPrS7g30R https:\/\/t.co\/NLCn3VfcHf",
  "id" : 798571271847952384,
  "created_at" : "2016-11-15 17:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798563201109655552",
  "text" : "RT @NSC44: Today @POTUS is in Greece for the first day of his final planned foreign trip in office. Follow along for updates: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/CLUqlfSu4K",
        "expanded_url" : "https:\/\/medium.com\/the-white-house\/the-president-abroad-a-look-ahead-at-greece-germany-and-peru-265b9c00a94e#.fory3ejcl",
        "display_url" : "medium.com\/the-white-hous\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798562557954904065",
    "text" : "Today @POTUS is in Greece for the first day of his final planned foreign trip in office. Follow along for updates: https:\/\/t.co\/CLUqlfSu4K",
    "id" : 798562557954904065,
    "created_at" : "2016-11-15 16:25:25 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 798563201109655552,
  "created_at" : "2016-11-15 16:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798557918400540672",
  "text" : "RT @VP: Tough. Gracious. Fair. Jill and I knew Gwen Ifill. She set the highest bar to the end, defining the character of America, inspiring\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798557374684524544",
    "text" : "Tough. Gracious. Fair. Jill and I knew Gwen Ifill. She set the highest bar to the end, defining the character of America, inspiring us all.",
    "id" : 798557374684524544,
    "created_at" : "2016-11-15 16:04:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 798557918400540672,
  "created_at" : "2016-11-15 16:06:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Alexis Tsipras",
      "screen_name" : "tsipras_eu",
      "indices" : [ 45, 56 ],
      "id_str" : "2292454922",
      "id" : 2292454922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BDXY7VdZmH",
      "expanded_url" : "http:\/\/snpy.tv\/2fUiHFq",
      "display_url" : "snpy.tv\/2fUiHFq"
    } ]
  },
  "geo" : { },
  "id_str" : "798542364369371140",
  "text" : "\"Kalispera.\" Watch @POTUS speak alongside PM @tsipras_eu in Athens\u2014his first stop on his final planned foreign trip: https:\/\/t.co\/BDXY7VdZmH",
  "id" : 798542364369371140,
  "created_at" : "2016-11-15 15:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798538039811194880",
  "text" : "\"We are proud to count Greece as one of our closest allies and one of our greatest friends. Efharisto.\" \u2014@POTUS",
  "id" : 798538039811194880,
  "created_at" : "2016-11-15 14:47:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798537451329490945",
  "text" : "\"I want to thank the Greek people publicly for their humanitarian response to the crisis of so many migrants and refugees\" \u2014@POTUS",
  "id" : 798537451329490945,
  "created_at" : "2016-11-15 14:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798536648065617921",
  "text" : "\"We cannot simply look to austerity as a strategy\" \u2014@POTUS on Greece's economic recovery",
  "id" : 798536648065617921,
  "created_at" : "2016-11-15 14:42:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798536383706976257",
  "text" : "\"We cannot simply look to austerity as a strategy\" \u2014@POTUS on Greek's economic recovery",
  "id" : 798536383706976257,
  "created_at" : "2016-11-15 14:41:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798535803102117888",
  "text" : "\"The ideas of ancient Greece helped inspire America's Founding Fathers as they reached for democracy.\" \u2014@POTUS",
  "id" : 798535803102117888,
  "created_at" : "2016-11-15 14:39:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Alexis Tsipras",
      "screen_name" : "tsipras_eu",
      "indices" : [ 48, 59 ],
      "id_str" : "2292454922",
      "id" : 2292454922
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798531463184547840\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/ALoXmosqh5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxT0GDnWEAE1Gs6.jpg",
      "id_str" : "798531418838142977",
      "id" : 798531418838142977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxT0GDnWEAE1Gs6.jpg",
      "sizes" : [ {
        "h" : 803,
        "resize" : "fit",
        "w" : 1438
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 1438
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ALoXmosqh5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/x0Dzuium7L",
      "expanded_url" : "http:\/\/go.wh.gov\/DGgBXV",
      "display_url" : "go.wh.gov\/DGgBXV"
    } ]
  },
  "geo" : { },
  "id_str" : "798531463184547840",
  "text" : "Happening now: Watch @POTUS join Prime Minister @Tsipras_EU of Greece for a press conference: https:\/\/t.co\/x0Dzuium7L https:\/\/t.co\/ALoXmosqh5",
  "id" : 798531463184547840,
  "created_at" : "2016-11-15 14:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Tsipras",
      "screen_name" : "tsipras_eu",
      "indices" : [ 3, 14 ],
      "id_str" : "2292454922",
      "id" : 2292454922
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798523879262220288",
  "text" : "RT @tsipras_eu: We warmly welcome in Athens @POTUS Barack Obama. A meeting of great importance for our country and Europe. https:\/\/t.co\/M0p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 28, 34 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tsipras_eu\/status\/798519530066767872\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/M0pe0sPr3O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxTpE87XcAAeDG5.jpg",
        "id_str" : "798519305235296256",
        "id" : 798519305235296256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxTpE87XcAAeDG5.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2730,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/M0pe0sPr3O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798519530066767872",
    "text" : "We warmly welcome in Athens @POTUS Barack Obama. A meeting of great importance for our country and Europe. https:\/\/t.co\/M0pe0sPr3O",
    "id" : 798519530066767872,
    "created_at" : "2016-11-15 13:34:26 +0000",
    "user" : {
      "name" : "Alexis Tsipras",
      "screen_name" : "tsipras_eu",
      "protected" : false,
      "id_str" : "2292454922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450651293183250433\/7J-RPp4v_normal.jpeg",
      "id" : 2292454922,
      "verified" : true
    }
  },
  "id" : 798523879262220288,
  "created_at" : "2016-11-15 13:51:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Alexis Tsipras",
      "screen_name" : "tsipras_eu",
      "indices" : [ 70, 81 ],
      "id_str" : "2292454922",
      "id" : 2292454922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/x0Dzuium7L",
      "expanded_url" : "http:\/\/go.wh.gov\/DGgBXV",
      "display_url" : "go.wh.gov\/DGgBXV"
    } ]
  },
  "geo" : { },
  "id_str" : "798522837267021825",
  "text" : "Tune in at 8:55am ET as @POTUS holds a press conference with Greek PM @Tsipras_EU: https:\/\/t.co\/x0Dzuium7L",
  "id" : 798522837267021825,
  "created_at" : "2016-11-15 13:47:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/NLCn3VwO5P",
      "expanded_url" : "http:\/\/snpy.tv\/2fscSye",
      "display_url" : "snpy.tv\/2fscSye"
    } ]
  },
  "geo" : { },
  "id_str" : "798355518830084100",
  "text" : "Stronger bonds between nations begin with a hello. See how @POTUS has greeted people abroad over the past 8 years: https:\/\/t.co\/NLCn3VwO5P",
  "id" : 798355518830084100,
  "created_at" : "2016-11-15 02:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798350544850980864",
  "text" : "RT @rhodes44: Tonight @POTUS departed on his final planned foreign trip. Here's what he will be doing in Greece, Germany, &amp; Peru: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 8, 14 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/N5y2E2VyGb",
        "expanded_url" : "https:\/\/medium.com\/@rhodes44\/the-president-abroad-a-look-ahead-at-greece-germany-and-peru-265b9c00a94e#.2426sxml3",
        "display_url" : "medium.com\/@rhodes44\/the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798349187595309056",
    "text" : "Tonight @POTUS departed on his final planned foreign trip. Here's what he will be doing in Greece, Germany, &amp; Peru: https:\/\/t.co\/N5y2E2VyGb",
    "id" : 798349187595309056,
    "created_at" : "2016-11-15 02:17:33 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 798350544850980864,
  "created_at" : "2016-11-15 02:22:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798315419421450240\/photo\/1",
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/AZmfEPtq3Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxQvXgIUcAAxaUQ.jpg",
      "id_str" : "798315114759745536",
      "id" : 798315114759745536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxQvXgIUcAAxaUQ.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/AZmfEPtq3Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/9JgTRwG2Sm",
      "expanded_url" : "http:\/\/go.wh.gov\/hnhgvj",
      "display_url" : "go.wh.gov\/hnhgvj"
    } ]
  },
  "geo" : { },
  "id_str" : "798315419421450240",
  "text" : "\u201CAmerica at its best is inclusive and not exclusive\u201D \u2014@POTUS in today's press conference. Watch \u2192 https:\/\/t.co\/9JgTRwG2Sm https:\/\/t.co\/AZmfEPtq3Q",
  "id" : 798315419421450240,
  "created_at" : "2016-11-15 00:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/zN7q9p3tuE",
      "expanded_url" : "http:\/\/snpy.tv\/2fa7tsy",
      "display_url" : "snpy.tv\/2fa7tsy"
    } ]
  },
  "geo" : { },
  "id_str" : "798315319177711616",
  "text" : "RT @NSC44: Tonight @POTUS departs on his final planned foreign trip. Here's what he said before takeoff: https:\/\/t.co\/zN7q9p3tuE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 8, 14 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/zN7q9p3tuE",
        "expanded_url" : "http:\/\/snpy.tv\/2fa7tsy",
        "display_url" : "snpy.tv\/2fa7tsy"
      } ]
    },
    "geo" : { },
    "id_str" : "798303548303900672",
    "text" : "Tonight @POTUS departs on his final planned foreign trip. Here's what he said before takeoff: https:\/\/t.co\/zN7q9p3tuE",
    "id" : 798303548303900672,
    "created_at" : "2016-11-14 23:16:12 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 798315319177711616,
  "created_at" : "2016-11-15 00:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798308612904861696\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/NV5qY3ZLrZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxQpBfmUcAAtNEZ.jpg",
      "id_str" : "798308139590250496",
      "id" : 798308139590250496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxQpBfmUcAAtNEZ.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/NV5qY3ZLrZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798308612904861696",
  "text" : "\"Gwen was a friend of ours. She was an extraordinary journalist.\" \u2014@POTUS on the passing of Gwen Ifill https:\/\/t.co\/NV5qY3ZLrZ",
  "id" : 798308612904861696,
  "created_at" : "2016-11-14 23:36:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/dxdktoSQJ3",
      "expanded_url" : "http:\/\/snpy.tv\/2fA06vo",
      "display_url" : "snpy.tv\/2fA06vo"
    } ]
  },
  "geo" : { },
  "id_str" : "798294441970769920",
  "text" : "\"These are kids who were brought here by their parents...pledged allegiance to the flag\" \u2014@POTUS on DREAMers https:\/\/t.co\/dxdktoSQJ3",
  "id" : 798294441970769920,
  "created_at" : "2016-11-14 22:40:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/dLThW0dIEd",
      "expanded_url" : "http:\/\/snpy.tv\/2fQEBFJ",
      "display_url" : "snpy.tv\/2fQEBFJ"
    } ]
  },
  "geo" : { },
  "id_str" : "798291168010215425",
  "text" : ".@POTUS on how acting to combat climate change can help the environment and grow the economy: https:\/\/t.co\/dLThW0dIEd",
  "id" : 798291168010215425,
  "created_at" : "2016-11-14 22:27:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/jqZ9hatp4K",
      "expanded_url" : "http:\/\/snpy.tv\/2fQDhmm",
      "display_url" : "snpy.tv\/2fQDhmm"
    } ]
  },
  "geo" : { },
  "id_str" : "798286891137187840",
  "text" : "\"To unravel a deal that's working &amp; preventing Iran from pursuing a nuclear weapon would be hard to explain\" \u2014@POTUS https:\/\/t.co\/jqZ9hatp4K",
  "id" : 798286891137187840,
  "created_at" : "2016-11-14 22:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/hBpYmRWedU",
      "expanded_url" : "http:\/\/snpy.tv\/2fag2Uo",
      "display_url" : "snpy.tv\/2fag2Uo"
    } ]
  },
  "geo" : { },
  "id_str" : "798284379286016000",
  "text" : "\"My role is to make sure that when I hand off this White House, that it is in the best possible shape.\" \u2014@POTUS https:\/\/t.co\/hBpYmRWedU",
  "id" : 798284379286016000,
  "created_at" : "2016-11-14 22:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/tINMH4FuY3",
      "expanded_url" : "http:\/\/snpy.tv\/2fzQtN9",
      "display_url" : "snpy.tv\/2fzQtN9"
    } ]
  },
  "geo" : { },
  "id_str" : "798281121289146369",
  "text" : ".@POTUS highlights the progress we've made together over the last 8 years: https:\/\/t.co\/tINMH4FuY3",
  "id" : 798281121289146369,
  "created_at" : "2016-11-14 21:47:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/AilDhtSoTl",
      "expanded_url" : "http:\/\/snpy.tv\/2fzKAQ1",
      "display_url" : "snpy.tv\/2fzKAQ1"
    } ]
  },
  "geo" : { },
  "id_str" : "798277977876230145",
  "text" : "\"There's no weakening of...America's commitment to maintaining a strong and robust NATO relationship\"\u2014@POTUS https:\/\/t.co\/AilDhtSoTl",
  "id" : 798277977876230145,
  "created_at" : "2016-11-14 21:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798274594528325632\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/jsphBpYbUS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxQJ_KFVEAAwyG0.jpg",
      "id_str" : "798274014594535424",
      "id" : 798274014594535424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxQJ_KFVEAAwyG0.jpg",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/jsphBpYbUS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798274594528325632",
  "text" : "\"People who have health insurance are benefiting in all sorts of ways that they may not be aware of.\" \u2014@POTUS on the Affordable Care Act https:\/\/t.co\/jsphBpYbUS",
  "id" : 798274594528325632,
  "created_at" : "2016-11-14 21:21:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MncG2mHkhk",
      "expanded_url" : "http:\/\/snpy.tv\/2fzLRqd",
      "display_url" : "snpy.tv\/2fzLRqd"
    } ]
  },
  "geo" : { },
  "id_str" : "798273070343536645",
  "text" : "\"Gwen was a friend of ours. She was an extraordinary journalist\" \u2014@POTUS on the passing of Gwen Ifill: https:\/\/t.co\/MncG2mHkhk",
  "id" : 798273070343536645,
  "created_at" : "2016-11-14 21:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/i9hVfhPFJc",
      "expanded_url" : "http:\/\/snpy.tv\/2gb7IYK",
      "display_url" : "snpy.tv\/2gb7IYK"
    } ]
  },
  "geo" : { },
  "id_str" : "798271485660041216",
  "text" : "\u201CMy team stands ready to accelerate in the next steps that are required to ensure a smooth transition.\u201D \u2014@POTUS https:\/\/t.co\/i9hVfhPFJc",
  "id" : 798271485660041216,
  "created_at" : "2016-11-14 21:08:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/iuTzouCqru",
      "expanded_url" : "http:\/\/snpy.tv\/2fa7tsy",
      "display_url" : "snpy.tv\/2fa7tsy"
    } ]
  },
  "geo" : { },
  "id_str" : "798270031406788608",
  "text" : "\u201CIt\u2019s essential to our national security and it\u2019s essential to global stability\u201D \u2014@POTUS on a strong &amp; united Europe https:\/\/t.co\/iuTzouCqru",
  "id" : 798270031406788608,
  "created_at" : "2016-11-14 21:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798266886068862976",
  "text" : "\u201CAmerica at its best is inclusive and not exclusive. That we insist on the dignity and God-given potential and worth of every child\u201D \u2014@POTUS",
  "id" : 798266886068862976,
  "created_at" : "2016-11-14 20:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9JgTRwos0O",
      "expanded_url" : "http:\/\/go.wh.gov\/hnhgvj",
      "display_url" : "go.wh.gov\/hnhgvj"
    } ]
  },
  "geo" : { },
  "id_str" : "798265361464524800",
  "text" : "\"Michelle and I want to offer our deepest condolences to Gwen Ifill\u2019s family and all of you\u2026on her passing\" \u2014@POTUS: https:\/\/t.co\/9JgTRwos0O",
  "id" : 798265361464524800,
  "created_at" : "2016-11-14 20:44:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9JgTRwos0O",
      "expanded_url" : "http:\/\/go.wh.gov\/hnhgvj",
      "display_url" : "go.wh.gov\/hnhgvj"
    } ]
  },
  "geo" : { },
  "id_str" : "798263125439037441",
  "text" : "Happening now: @POTUS speaks to the press before departing on his trip to Greece, Germany, and Peru: https:\/\/t.co\/9JgTRwos0O",
  "id" : 798263125439037441,
  "created_at" : "2016-11-14 20:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/9JgTRwos0O",
      "expanded_url" : "http:\/\/go.wh.gov\/hnhgvj",
      "display_url" : "go.wh.gov\/hnhgvj"
    } ]
  },
  "geo" : { },
  "id_str" : "798251814231699456",
  "text" : "Tune in at 3:15pm ET as @POTUS holds a press conference ahead of his trip to Greece, Germany, and Peru: https:\/\/t.co\/9JgTRwos0O",
  "id" : 798251814231699456,
  "created_at" : "2016-11-14 19:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 35, 39 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798239046833057792\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Lj8Iy2ILUp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxPqAWwUsAA2D2i.jpg",
      "id_str" : "798238850803871744",
      "id" : 798238850803871744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxPqAWwUsAA2D2i.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 909
      } ],
      "display_url" : "pic.twitter.com\/Lj8Iy2ILUp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798239046833057792",
  "text" : "Today, @POTUS spoke with President @EPN of Mexico about the progress our two countries have made together: https:\/\/t.co\/Lj8Iy2ILUp",
  "id" : 798239046833057792,
  "created_at" : "2016-11-14 18:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 54, 61 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798233905396645888\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/EblyENqjXE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxPk9hWWEAAUJAo.jpg",
      "id_str" : "798233304549953536",
      "id" : 798233304549953536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxPk9hWWEAAUJAo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/EblyENqjXE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/n0rj6B7QxJ",
      "expanded_url" : "http:\/\/go.wh.gov\/E2NSko",
      "display_url" : "go.wh.gov\/E2NSko"
    } ]
  },
  "geo" : { },
  "id_str" : "798233905396645888",
  "text" : "\u201CWe have cut veterans\u2019 homelessness nearly in half.\u201D \u2014@FLOTUS on taking action for our veterans: https:\/\/t.co\/n0rj6B7QxJ https:\/\/t.co\/EblyENqjXE",
  "id" : 798233905396645888,
  "created_at" : "2016-11-14 18:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 121, 128 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798232974881857536",
  "text" : "RT @WHLive: \"It is absolutely possible to solve this problem once and for all if we come together and we take action.\"  \u2014@FLOTUS #EndVetera\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 109, 116 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EndVeteranHomelessness",
        "indices" : [ 117, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "798232824625197057",
    "text" : "\"It is absolutely possible to solve this problem once and for all if we come together and we take action.\"  \u2014@FLOTUS #EndVeteranHomelessness",
    "id" : 798232824625197057,
    "created_at" : "2016-11-14 18:35:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 798232974881857536,
  "created_at" : "2016-11-14 18:35:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 1, 8 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndVeteransHomelessness",
      "indices" : [ 90, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/n0rj6Bprph",
      "expanded_url" : "http:\/\/go.wh.gov\/E2NSko",
      "display_url" : "go.wh.gov\/E2NSko"
    } ]
  },
  "geo" : { },
  "id_str" : "798230711266254849",
  "text" : ".@FLOTUS welcomes community leaders from across the country to talk about our progress to #EndVeteransHomelessness: https:\/\/t.co\/n0rj6Bprph",
  "id" : 798230711266254849,
  "created_at" : "2016-11-14 18:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homelessness",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798226866125553664",
  "text" : "RT @SecretaryCastro: Delaware becomes the third state to effectively end veteran #homelessness, leading the way for the other 47 states. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "homelessness",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/7myfl2O3xi",
        "expanded_url" : "https:\/\/medium.com\/@SecretaryCastro\/delaware-proves-ending-veteran-homelessness-is-possible-50f75a4bfa35#.rdc5g8k1v",
        "display_url" : "medium.com\/@SecretaryCast\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798211477094203394",
    "text" : "Delaware becomes the third state to effectively end veteran #homelessness, leading the way for the other 47 states. https:\/\/t.co\/7myfl2O3xi",
    "id" : 798211477094203394,
    "created_at" : "2016-11-14 17:10:20 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 798226866125553664,
  "created_at" : "2016-11-14 18:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/798224958153494528\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/8ozcqSrs2X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxPdKEZVIAA0Tg5.jpg",
      "id_str" : "798224724023123968",
      "id" : 798224724023123968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxPdKEZVIAA0Tg5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8ozcqSrs2X"
    } ],
    "hashtags" : [ {
      "text" : "EndVeteranHomelessness",
      "indices" : [ 76, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/n0rj6B7QxJ",
      "expanded_url" : "http:\/\/go.wh.gov\/E2NSko",
      "display_url" : "go.wh.gov\/E2NSko"
    } ]
  },
  "geo" : { },
  "id_str" : "798224958153494528",
  "text" : "Since 2010, we\u2019ve cut veteran homelessness almost in half. Together, we can #EndVeteranHomelessness: https:\/\/t.co\/n0rj6B7QxJ https:\/\/t.co\/8ozcqSrs2X",
  "id" : 798224958153494528,
  "created_at" : "2016-11-14 18:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MissionInnovation",
      "indices" : [ 87, 105 ]
    }, {
      "text" : "COP22",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "798214273218572289",
  "text" : "RT @ErnestMoniz: The global energy economy is going to be a low-carbon energy economy. #MissionInnovation is paving the way. #COP22\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/798211559369543680\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/JRLM9PPGy6",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/783770451512262657\/img\/gXUwg_LfCZchue6m.jpg",
        "id_str" : "783770451512262657",
        "id" : 783770451512262657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/783770451512262657\/img\/gXUwg_LfCZchue6m.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JRLM9PPGy6"
      } ],
      "hashtags" : [ {
        "text" : "MissionInnovation",
        "indices" : [ 70, 88 ]
      }, {
        "text" : "COP22",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/DIfEMOB3IC",
        "expanded_url" : "http:\/\/energy.gov\/articles\/mission-innovation-ministers-gather-cop22-public-event",
        "display_url" : "energy.gov\/articles\/missi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "798211559369543680",
    "text" : "The global energy economy is going to be a low-carbon energy economy. #MissionInnovation is paving the way. #COP22\nhttps:\/\/t.co\/DIfEMOB3IC https:\/\/t.co\/JRLM9PPGy6",
    "id" : 798211559369543680,
    "created_at" : "2016-11-14 17:10:40 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 798214273218572289,
  "created_at" : "2016-11-14 17:21:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WH Internship",
      "screen_name" : "WHInternship",
      "indices" : [ 74, 87 ],
      "id_str" : "4530405972",
      "id" : 4530405972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EWUuui5QwA",
      "expanded_url" : "http:\/\/snpy.tv\/2fPIvmb",
      "display_url" : "snpy.tv\/2fPIvmb"
    } ]
  },
  "geo" : { },
  "id_str" : "797963303255441408",
  "text" : "\"Be kind, be useful, be fearless.\" Watch @POTUS offer advice to his final @WHInternship class in this #WestWingWeek: https:\/\/t.co\/EWUuui5QwA",
  "id" : 797963303255441408,
  "created_at" : "2016-11-14 00:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797872917480636416\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/TNCcmxc4h1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxKTKwwXgAADuWT.jpg",
      "id_str" : "797861897093742592",
      "id" : 797861897093742592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxKTKwwXgAADuWT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/TNCcmxc4h1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797872917480636416",
  "text" : "FACT: Since 2010, we\u2019ve cut veteran homelessness almost in half. https:\/\/t.co\/TNCcmxc4h1",
  "id" : 797872917480636416,
  "created_at" : "2016-11-13 18:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paris",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "Bataclan",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797861732421169152",
  "text" : "RT @JohnKerry: Our thoughts &amp; prayers are w\/ people of #Paris on 1-year anniversary of terror attacks. Re-opening of #Bataclan is a testame\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Paris",
        "indices" : [ 44, 50 ]
      }, {
        "text" : "Bataclan",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797830488673161217",
    "text" : "Our thoughts &amp; prayers are w\/ people of #Paris on 1-year anniversary of terror attacks. Re-opening of #Bataclan is a testament to resilience",
    "id" : 797830488673161217,
    "created_at" : "2016-11-13 15:56:26 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 797861732421169152,
  "created_at" : "2016-11-13 18:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 95, 110 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/txE8WsLsLn",
      "expanded_url" : "http:\/\/nationalinterest.org\/feature\/susan-rice-american-leadership-the-asia-pacific-must-18391",
      "display_url" : "nationalinterest.org\/feature\/susan-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "797858563305668608",
  "text" : "RT @NSC44: \"The US is a Pacific power, underwriting regional stability for more than 70 years\"-@AmbassadorRice https:\/\/t.co\/txE8WsLsLn @The\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Rice",
        "screen_name" : "AmbassadorRice",
        "indices" : [ 84, 99 ],
        "id_str" : "19674502",
        "id" : 19674502
      }, {
        "name" : "National Interest",
        "screen_name" : "TheNatlInterest",
        "indices" : [ 124, 140 ],
        "id_str" : "152311372",
        "id" : 152311372
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/txE8WsLsLn",
        "expanded_url" : "http:\/\/nationalinterest.org\/feature\/susan-rice-american-leadership-the-asia-pacific-must-18391",
        "display_url" : "nationalinterest.org\/feature\/susan-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "797852527404269568",
    "text" : "\"The US is a Pacific power, underwriting regional stability for more than 70 years\"-@AmbassadorRice https:\/\/t.co\/txE8WsLsLn @TheNatlInterest",
    "id" : 797852527404269568,
    "created_at" : "2016-11-13 17:24:00 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 797858563305668608,
  "created_at" : "2016-11-13 17:47:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/LVLDxvAo93",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797845975511535616",
  "text" : "Watch @POTUS thank America's veterans for their service and sacrifice in this week's address: https:\/\/t.co\/LVLDxvAo93",
  "id" : 797845975511535616,
  "created_at" : "2016-11-13 16:57:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankYouVeterans",
      "indices" : [ 13, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797586783491997696",
  "text" : "RT @Denis44: #ThankYouVeterans:\n\u2713Cut veteran homelessness in half\n\u2713Mental healthcare 2 more vets than ever\n\u2713In-state tuition 4 recently tra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankYouVeterans",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797215182611156992",
    "text" : "#ThankYouVeterans:\n\u2713Cut veteran homelessness in half\n\u2713Mental healthcare 2 more vets than ever\n\u2713In-state tuition 4 recently transitioned vets",
    "id" : 797215182611156992,
    "created_at" : "2016-11-11 23:11:25 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 797586783491997696,
  "created_at" : "2016-11-12 23:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Antarctica",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797585447719489536",
  "text" : "RT @JohnKerry: Here in #Antarctica w\/ some of the world's top researchers. The science is clear: #climatechange is real, and we ignore it a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JohnKerry\/status\/797333066632990721\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/uHPxw4Qj5L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxCyMT9VEAEDI43.jpg",
        "id_str" : "797333058630258689",
        "id" : 797333058630258689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxCyMT9VEAEDI43.jpg",
        "sizes" : [ {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uHPxw4Qj5L"
      } ],
      "hashtags" : [ {
        "text" : "Antarctica",
        "indices" : [ 8, 19 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 82, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797333066632990721",
    "text" : "Here in #Antarctica w\/ some of the world's top researchers. The science is clear: #climatechange is real, and we ignore it at our own peril. https:\/\/t.co\/uHPxw4Qj5L",
    "id" : 797333066632990721,
    "created_at" : "2016-11-12 06:59:51 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 797585447719489536,
  "created_at" : "2016-11-12 23:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/LVLDxvAo93",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797583915276005377",
  "text" : "It's up to us to live in our own lives the values for which America's veterans were prepared to give theirs: https:\/\/t.co\/LVLDxvAo93",
  "id" : 797583915276005377,
  "created_at" : "2016-11-12 23:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797544498733535232\/photo\/1",
      "indices" : [ 126, 149 ],
      "url" : "https:\/\/t.co\/V3xitDpNZX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxExb5jUcAA-Og8.jpg",
      "id_str" : "797472964396478464",
      "id" : 797472964396478464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxExb5jUcAA-Og8.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/V3xitDpNZX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797544498733535232",
  "text" : "Not all of the wounds of war are visible. Under @POTUS, we've increased mental health care funding for vets by more than 75%. https:\/\/t.co\/V3xitDpNZX",
  "id" : 797544498733535232,
  "created_at" : "2016-11-12 21:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/LVLDxvAo93",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797529403517452292",
  "text" : "\u201CWe can show how much we love our country by loving our neighbors as ourselves.\u201D \u2014@POTUS https:\/\/t.co\/LVLDxvAo93",
  "id" : 797529403517452292,
  "created_at" : "2016-11-12 20:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonorAVet",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/LVLDxvAo93",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797523110069227520",
  "text" : "\"To all of you who served and who still do: thank you.\" \u2014@POTUS to America's veterans #HonorAVet https:\/\/t.co\/LVLDxvAo93",
  "id" : 797523110069227520,
  "created_at" : "2016-11-12 19:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797514309303607297\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7Uds3fEqjb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxEoIZ1WEAA0Qiu.jpg",
      "id_str" : "797462733859983360",
      "id" : 797462733859983360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxEoIZ1WEAA0Qiu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/7Uds3fEqjb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797514309303607297",
  "text" : "FACT: Since its peak in 2011, we've cut veteran unemployment by more than half. https:\/\/t.co\/7Uds3fEqjb",
  "id" : 797514309303607297,
  "created_at" : "2016-11-12 19:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LVLDxviMKt",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797499211637895168",
  "text" : "\"It\u2019s up to us to summon some of the courage and humility our veterans show\" \u2014@POTUS on the spirit of #VeteransDay https:\/\/t.co\/LVLDxviMKt",
  "id" : 797499211637895168,
  "created_at" : "2016-11-12 18:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/LVLDxviMKt",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797491653355278336",
  "text" : "\"Soldiers, sailors, airmen, Marines, and coastguardsmen...represent every corner of our country\" \u2014@POTUS https:\/\/t.co\/LVLDxviMKt",
  "id" : 797491653355278336,
  "created_at" : "2016-11-12 17:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LVLDxvAo93",
      "expanded_url" : "http:\/\/go.wh.gov\/auZ3X8",
      "display_url" : "go.wh.gov\/auZ3X8"
    } ]
  },
  "geo" : { },
  "id_str" : "797476557577220096",
  "text" : "\"To bridge our differences, we look to the principles that are more enduring than politics.\" \u2014@POTUS honors our vets https:\/\/t.co\/LVLDxvAo93",
  "id" : 797476557577220096,
  "created_at" : "2016-11-12 16:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 3, 17 ],
      "id_str" : "102455692",
      "id" : 102455692
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 61, 75 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797232796297297920",
  "text" : "RT @ArlingtonNatl: Taps, the last call of the day, sounds at @ArlingtonNatl. A sincere thank you to all of those who have served our nation\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlington Cemetery",
        "screen_name" : "ArlingtonNatl",
        "indices" : [ 42, 56 ],
        "id_str" : "102455692",
        "id" : 102455692
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ArlingtonNatl\/status\/797191666838994944\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/GhgneYoch6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CxAxlfyW8AAQ1Cr.jpg",
        "id_str" : "797191654302216192",
        "id" : 797191654302216192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxAxlfyW8AAQ1Cr.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/GhgneYoch6"
      } ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797191666838994944",
    "text" : "Taps, the last call of the day, sounds at @ArlingtonNatl. A sincere thank you to all of those who have served our nation. Happy #VeteransDay https:\/\/t.co\/GhgneYoch6",
    "id" : 797191666838994944,
    "created_at" : "2016-11-11 21:37:59 +0000",
    "user" : {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "protected" : false,
      "id_str" : "102455692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3211777843\/4f62ca799ab1c5a8945e1f125209cf31_normal.jpeg",
      "id" : 102455692,
      "verified" : true
    }
  },
  "id" : 797232796297297920,
  "created_at" : "2016-11-12 00:21:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797229797441236992\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/0tQv3ao3Py",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxBT1QyXgAA9YlB.jpg",
      "id_str" : "797229308548972544",
      "id" : 797229308548972544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxBT1QyXgAA9YlB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/0tQv3ao3Py"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/L1rE4pCzU8",
      "expanded_url" : "http:\/\/go.wh.gov\/H3kuWD",
      "display_url" : "go.wh.gov\/H3kuWD"
    } ]
  },
  "geo" : { },
  "id_str" : "797229797441236992",
  "text" : "Today, @POTUS announced new steps to help veterans further their education. Read a letter from one of them: https:\/\/t.co\/L1rE4pCzU8 https:\/\/t.co\/0tQv3ao3Py",
  "id" : 797229797441236992,
  "created_at" : "2016-11-12 00:09:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797211906448756736\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/xYpUUJnwwX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxBD5DfXcAAwarR.jpg",
      "id_str" : "797211781513048064",
      "id" : 797211781513048064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxBD5DfXcAAwarR.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      } ],
      "display_url" : "pic.twitter.com\/xYpUUJnwwX"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797211906448756736\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/xYpUUJnwwX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxBD5CHWgAAu9zd.jpg",
      "id_str" : "797211781143887872",
      "id" : 797211781143887872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxBD5CHWgAAu9zd.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/xYpUUJnwwX"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797211906448756736\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/xYpUUJnwwX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxBD6tnXAAAMO7T.jpg",
      "id_str" : "797211810000732160",
      "id" : 797211810000732160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxBD6tnXAAAMO7T.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/xYpUUJnwwX"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/F8XEiS8aUJ",
      "expanded_url" : "http:\/\/go.wh.gov\/X8UKpb",
      "display_url" : "go.wh.gov\/X8UKpb"
    } ]
  },
  "geo" : { },
  "id_str" : "797211906448756736",
  "text" : "Go behind the scenes with veterans who are now serving our Commander-in-Chief as White House staffers: https:\/\/t.co\/F8XEiS8aUJ #VeteransDay https:\/\/t.co\/xYpUUJnwwX",
  "id" : 797211906448756736,
  "created_at" : "2016-11-11 22:58:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/EkhJX871CH",
      "expanded_url" : "http:\/\/snpy.tv\/2fE4Xft",
      "display_url" : "snpy.tv\/2fE4Xft"
    } ]
  },
  "geo" : { },
  "id_str" : "797193434675060736",
  "text" : "\"We owe you our thanks. We owe you our respect. We owe you our freedom.\" \u2014@POTUS to America\u2019s veterans #VeteransDay https:\/\/t.co\/EkhJX871CH",
  "id" : 797193434675060736,
  "created_at" : "2016-11-11 21:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797182111656660992\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/fa1L2WDmtr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxAKwvzUoAAqMQZ.jpg",
      "id_str" : "797148966626304000",
      "id" : 797148966626304000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxAKwvzUoAAqMQZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/fa1L2WDmtr"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797182111656660992",
  "text" : "Progress: Over the last three and a half years, we\u2019ve reduced the disability claims backlog for veterans by nearly 90%. #VeteransDay https:\/\/t.co\/fa1L2WDmtr",
  "id" : 797182111656660992,
  "created_at" : "2016-11-11 21:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797167012430626816\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/0NQcW2QKS8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxAKnUxUkAA2k_9.jpg",
      "id_str" : "797148804751331328",
      "id" : 797148804751331328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxAKnUxUkAA2k_9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0NQcW2QKS8"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797167012430626816",
  "text" : "Under @POTUS, we\u2019ve helped nearly 1.7 million veterans and their families get an education. #VeteransDay https:\/\/t.co\/0NQcW2QKS8",
  "id" : 797167012430626816,
  "created_at" : "2016-11-11 20:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/UxUNAqniMB",
      "expanded_url" : "http:\/\/snpy.tv\/2eZTgi3",
      "display_url" : "snpy.tv\/2eZTgi3"
    } ]
  },
  "geo" : { },
  "id_str" : "797155686769627137",
  "text" : ".@POTUS on the example America\u2019s veterans set for us all: https:\/\/t.co\/UxUNAqniMB",
  "id" : 797155686769627137,
  "created_at" : "2016-11-11 19:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 21, 26 ],
      "id_str" : "19263978",
      "id" : 19263978
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/797119031429861376\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/NsF3kB63Ll",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_vg9jXAAA9fuz.jpg",
      "id_str" : "797084324646424576",
      "id" : 797084324646424576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_vg9jXAAA9fuz.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/NsF3kB63Ll"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797151353239904257",
  "text" : "RT @FLOTUS: From the @Cavs and the First Lady - thank you. #VeteransDay https:\/\/t.co\/NsF3kB63Ll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cleveland Cavaliers",
        "screen_name" : "cavs",
        "indices" : [ 9, 14 ],
        "id_str" : "19263978",
        "id" : 19263978
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/797119031429861376\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/NsF3kB63Ll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_vg9jXAAA9fuz.jpg",
        "id_str" : "797084324646424576",
        "id" : 797084324646424576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_vg9jXAAA9fuz.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/NsF3kB63Ll"
      } ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 47, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797119031429861376",
    "text" : "From the @Cavs and the First Lady - thank you. #VeteransDay https:\/\/t.co\/NsF3kB63Ll",
    "id" : 797119031429861376,
    "created_at" : "2016-11-11 16:49:21 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 797151353239904257,
  "created_at" : "2016-11-11 18:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797145526458286084\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/EVlPFJPPgm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxAHn28VQAQKu8f.jpg",
      "id_str" : "797145515389435908",
      "id" : 797145515389435908,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxAHn28VQAQKu8f.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 1569,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1569,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 918
      } ],
      "display_url" : "pic.twitter.com\/EVlPFJPPgm"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797145526458286084\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/EVlPFJPPgm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxAHn21UAAAvCT7.jpg",
      "id_str" : "797145515359993856",
      "id" : 797145515359993856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxAHn21UAAAvCT7.jpg",
      "sizes" : [ {
        "h" : 1567,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 919
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1567,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/EVlPFJPPgm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/lSqDGQWts8",
      "expanded_url" : "http:\/\/go.wh.gov\/VeteransDay",
      "display_url" : "go.wh.gov\/VeteransDay"
    } ]
  },
  "geo" : { },
  "id_str" : "797145526458286084",
  "text" : "\"Thank you...for your service and sacrifice.\" \u2014@POTUS responds to a veteran\u2019s letter: https:\/\/t.co\/lSqDGQWts8 https:\/\/t.co\/EVlPFJPPgm",
  "id" : 797145526458286084,
  "created_at" : "2016-11-11 18:34:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 35, 42 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonorAVet",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797140512314638336",
  "text" : "RT @DrBiden: My father served as a @USNavy signalman during World War II. He was very proud of his military service. So am I. #HonorAVet \u2014J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 22, 29 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/797129181943529472\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/ekqgOnJfSF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_4wpqWQAAB83S.jpg",
        "id_str" : "797129173768749056",
        "id" : 797129173768749056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_4wpqWQAAB83S.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/ekqgOnJfSF"
      } ],
      "hashtags" : [ {
        "text" : "HonorAVet",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797129181943529472",
    "text" : "My father served as a @USNavy signalman during World War II. He was very proud of his military service. So am I. #HonorAVet \u2014Jill https:\/\/t.co\/ekqgOnJfSF",
    "id" : 797129181943529472,
    "created_at" : "2016-11-11 17:29:41 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 797140512314638336,
  "created_at" : "2016-11-11 18:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/EkhJX8oD1h",
      "expanded_url" : "http:\/\/snpy.tv\/2fE4Xft",
      "display_url" : "snpy.tv\/2fE4Xft"
    } ]
  },
  "geo" : { },
  "id_str" : "797133589368422400",
  "text" : "\"Whenever the world makes you cynical; whenever you seek true humility and selflessness\u2014look to a veteran.\" \u2014@POTUS https:\/\/t.co\/EkhJX8oD1h",
  "id" : 797133589368422400,
  "created_at" : "2016-11-11 17:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797129396649938944",
  "text" : "RT @POTUS: Today, we honor those who honored our country with its highest form of service. We owe our veterans our thanks, our respect and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797128959578271744",
    "text" : "Today, we honor those who honored our country with its highest form of service. We owe our veterans our thanks, our respect and our freedom.",
    "id" : 797128959578271744,
    "created_at" : "2016-11-11 17:28:48 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 797129396649938944,
  "created_at" : "2016-11-11 17:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797120713178173441",
  "text" : "\"We can show how much we love our country by loving our neighbors as ourselves.\" \u2014@POTUS on carrying forward the spirit of #VeteransDay",
  "id" : 797120713178173441,
  "created_at" : "2016-11-11 16:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797120496974303232\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/nXgNgfAeap",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_w1pkUQAALzAv.jpg",
      "id_str" : "797120463549775872",
      "id" : 797120463549775872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_w1pkUQAALzAv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/nXgNgfAeap"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797120496974303232",
  "text" : "\"We have to keep cutting the disability claims backlog.\" \u2014@POTUS on the steps we're taking to honor America's veterans #VeteransDay https:\/\/t.co\/nXgNgfAeap",
  "id" : 797120496974303232,
  "created_at" : "2016-11-11 16:55:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797120209148669952\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/59hnmUC3Rc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_wl-FUkAAH-it.jpg",
      "id_str" : "797120194179010560",
      "id" : 797120194179010560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_wl-FUkAAH-it.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/59hnmUC3Rc"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797120209148669952",
  "text" : "\"Together, we must continue to keep that sacred trust with our veterans and honor their good work with our own\" \u2014@POTUS on #VeteransDay https:\/\/t.co\/59hnmUC3Rc",
  "id" : 797120209148669952,
  "created_at" : "2016-11-11 16:54:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797119686617997312\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/GNlWpDSzGc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_wEkSUoAAatiA.jpg",
      "id_str" : "797119620318535680",
      "id" : 797119620318535680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_wEkSUoAAatiA.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/GNlWpDSzGc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797119686617997312",
  "text" : "\"We\u2019re delivering more mental health care services to more veterans than ever before...not all of the wounds of war are visible.\" \u2014@POTUS https:\/\/t.co\/GNlWpDSzGc",
  "id" : 797119686617997312,
  "created_at" : "2016-11-11 16:51:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/797119302369505281\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/4MBqrngchY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_vxcVVIAAJ0sl.jpg",
      "id_str" : "797119291766153216",
      "id" : 797119291766153216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_vxcVVIAAJ0sl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4MBqrngchY"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797119302369505281",
  "text" : "\"Today, more veterans have access to health care and fewer are unemployed.\" \u2014@POTUS on #VeteransDay https:\/\/t.co\/4MBqrngchY",
  "id" : 797119302369505281,
  "created_at" : "2016-11-11 16:50:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 62, 76 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/797118888110596096\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/1OoZpXrat1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw_vTJcUUAELzx-.jpg",
      "id_str" : "797118771299110913",
      "id" : 797118771299110913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw_vTJcUUAELzx-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1OoZpXrat1"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797118888110596096",
  "text" : "\"We\u2019ve cut veterans' homelessness almost in half.\" \u2014@POTUS at @ArlingtonNatl Cemetery #VeteransDay https:\/\/t.co\/1OoZpXrat1",
  "id" : 797118888110596096,
  "created_at" : "2016-11-11 16:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797118532999933952",
  "text" : "\"It is up to us to always make sure they get the care they need...we\u2019ve increased funding for veterans by more than 85 percent.\" \u2014@POTUS",
  "id" : 797118532999933952,
  "created_at" : "2016-11-11 16:47:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797117975560122368",
  "text" : "\"Whenever the world makes you cynical; whenever you seek true humility, and true selflessness\u2014look to a veteran.\" \u2014@POTUS on #VeteransDay",
  "id" : 797117975560122368,
  "created_at" : "2016-11-11 16:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797117636178046977",
  "text" : "RT @WHLive: \"It is the example of the single most diverse institution in our country...all forged into common service\" \u2014@POTUS #VeteransDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 108, 114 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 115, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797117500714577920",
    "text" : "\"It is the example of the single most diverse institution in our country...all forged into common service\" \u2014@POTUS #VeteransDay",
    "id" : 797117500714577920,
    "created_at" : "2016-11-11 16:43:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 797117636178046977,
  "created_at" : "2016-11-11 16:43:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797117265061748736",
  "text" : "RT @WHLive: \"It is the example of a military that meets every mission, one united team, all looking out for one another\" \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 110, 116 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797117149177331712",
    "text" : "\"It is the example of a military that meets every mission, one united team, all looking out for one another\" \u2014@POTUS",
    "id" : 797117149177331712,
    "created_at" : "2016-11-11 16:41:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 797117265061748736,
  "created_at" : "2016-11-11 16:42:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797117036363218944",
  "text" : "\"As we search for ways to come together...some of our best examples are the men and women we salute on Veterans Day.\" \u2014@POTUS",
  "id" : 797117036363218944,
  "created_at" : "2016-11-11 16:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797116817462489088",
  "text" : "\"The American instinct has never been to find isolation in opposite corners. It is to find strength in our common creed\" \u2014@POTUS",
  "id" : 797116817462489088,
  "created_at" : "2016-11-11 16:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797116697916407813",
  "text" : "\"We owe you our thanks, our respect, and our freedom.\" \u2014@POTUS to America's veterans #HonoringVets",
  "id" : 797116697916407813,
  "created_at" : "2016-11-11 16:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 110, 124 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797116595189547010",
  "text" : "\"Today, on Veterans Day, we honor those who honored our country with its highest form of service.\" \u2014@POTUS at @ArlingtonNatl Cemetery",
  "id" : 797116595189547010,
  "created_at" : "2016-11-11 16:39:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/lSqDGQWts8",
      "expanded_url" : "http:\/\/go.wh.gov\/VeteransDay",
      "display_url" : "go.wh.gov\/VeteransDay"
    } ]
  },
  "geo" : { },
  "id_str" : "797111603007262720",
  "text" : "Tune in: @POTUS honors America's service members and veterans at Arlington National Cemetery on #VeteransDay. https:\/\/t.co\/lSqDGQWts8",
  "id" : 797111603007262720,
  "created_at" : "2016-11-11 16:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/lSqDGQWts8",
      "expanded_url" : "http:\/\/go.wh.gov\/VeteransDay",
      "display_url" : "go.wh.gov\/VeteransDay"
    } ]
  },
  "geo" : { },
  "id_str" : "797106568810627072",
  "text" : "Happening now: @POTUS lays a wreath at the Tomb of the Unknown Soldier at Arlington National Cemetery: https:\/\/t.co\/lSqDGQWts8",
  "id" : 797106568810627072,
  "created_at" : "2016-11-11 15:59:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797104968947924992",
  "text" : "RT @vj44: Thankful to those that have served our country and the sacrifices they and their families have made for our freedom #VeteransDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "797096102625472512",
    "text" : "Thankful to those that have served our country and the sacrifices they and their families have made for our freedom #VeteransDay",
    "id" : 797096102625472512,
    "created_at" : "2016-11-11 15:18:14 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 797104968947924992,
  "created_at" : "2016-11-11 15:53:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 3, 8 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    }, {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 33, 48 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "797086639021588480",
  "text" : "RT @USDS: How we're working with @DeptVetAffairs to ensure our Veterans have access to the health care they deserve: \n\nhttps:\/\/t.co\/0ZnMOLX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Veterans Affairs",
        "screen_name" : "DeptVetAffairs",
        "indices" : [ 23, 38 ],
        "id_str" : "78408666",
        "id" : 78408666
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/0ZnMOLX6hx",
        "expanded_url" : "https:\/\/medium.com\/the-u-s-digital-service\/technically-speaking-how-we-built-a-new-health-care-application-for-veterans-bfc77a457f71#.bs2b0bmkv",
        "display_url" : "medium.com\/the-u-s-digita\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "797077987560751104",
    "text" : "How we're working with @DeptVetAffairs to ensure our Veterans have access to the health care they deserve: \n\nhttps:\/\/t.co\/0ZnMOLX6hx",
    "id" : 797077987560751104,
    "created_at" : "2016-11-11 14:06:15 +0000",
    "user" : {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "protected" : false,
      "id_str" : "2983206962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557352808672817152\/HWxVbTrV_normal.png",
      "id" : 2983206962,
      "verified" : true
    }
  },
  "id" : 797086639021588480,
  "created_at" : "2016-11-11 14:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 36, 41 ],
      "id_str" : "10126672",
      "id" : 10126672
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/796830899102957569\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/zxE0aHskPG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw7pb1tXcAAbuAK.jpg",
      "id_str" : "796830848574255104",
      "id" : 796830848574255104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw7pb1tXcAAbuAK.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/zxE0aHskPG"
    } ],
    "hashtags" : [ {
      "text" : "SemperFi",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796830899102957569",
  "text" : "Today we celebrate 241 years of the @USMC defending our country and the American people. #SemperFi https:\/\/t.co\/zxE0aHskPG",
  "id" : 796830899102957569,
  "created_at" : "2016-11-10 21:44:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 102, 107 ],
      "id_str" : "19263978",
      "id" : 19263978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/E82ea3Dq5l",
      "expanded_url" : "http:\/\/snpy.tv\/2fFFUZE",
      "display_url" : "snpy.tv\/2fFFUZE"
    } ]
  },
  "geo" : { },
  "id_str" : "796806482423640064",
  "text" : "\"Let\u2019s give it up for the world champs one last time!\" \u2014@POTUS honors the 2016 NBA Champion Cleveland @Cavs https:\/\/t.co\/E82ea3Dq5l",
  "id" : 796806482423640064,
  "created_at" : "2016-11-10 20:07:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 7, 12 ],
      "id_str" : "19263978",
      "id" : 19263978
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/796799679589679104\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/HuIn6KFOkz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw7NDfQW8AQcqrB.jpg",
      "id_str" : "796799643904569348",
      "id" : 796799643904569348,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw7NDfQW8AQcqrB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 672,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 1437
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 1437
      } ],
      "display_url" : "pic.twitter.com\/HuIn6KFOkz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796799679589679104",
  "text" : "\"These @Cavs exemplify a growing generation of athletes that are using their platforms to speak out\" \u2014@POTUS applauds the 2016 NBA Champions https:\/\/t.co\/HuIn6KFOkz",
  "id" : 796799679589679104,
  "created_at" : "2016-11-10 19:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796799094534574080",
  "text" : "RT @WHLive: \"This city has been through a lot...But through it all, Cleveland was always 'Believeland.'\" \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 94, 100 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "796799025563467777",
    "text" : "\"This city has been through a lot...But through it all, Cleveland was always 'Believeland.'\" \u2014@POTUS",
    "id" : 796799025563467777,
    "created_at" : "2016-11-10 19:37:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 796799094534574080,
  "created_at" : "2016-11-10 19:38:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 122, 127 ],
      "id_str" : "19263978",
      "id" : 19263978
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/796798337370427392\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/zcLVqfykal",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw7LxuEXAAAngtl.jpg",
      "id_str" : "796798239131500544",
      "id" : 796798239131500544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw7LxuEXAAAngtl.jpg",
      "sizes" : [ {
        "h" : 797,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/zcLVqfykal"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796798337370427392",
  "text" : "\"We finally said it: 'World Champion' and 'Cleveland' in the same sentence.\" \u2014@POTUS on the 2016 NBA Championship winning @Cavs team https:\/\/t.co\/zcLVqfykal",
  "id" : 796798337370427392,
  "created_at" : "2016-11-10 19:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 70, 75 ],
      "id_str" : "19263978",
      "id" : 19263978
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/796796439917686784\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/a0VSNTMhDX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw7KHr-W8AEz1km.jpg",
      "id_str" : "796796417503326209",
      "id" : 796796417503326209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw7KHr-W8AEz1km.jpg",
      "sizes" : [ {
        "h" : 662,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 1440
      } ],
      "display_url" : "pic.twitter.com\/a0VSNTMhDX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/otaerC6RbD",
      "expanded_url" : "http:\/\/go.wh.gov\/D1m4pr",
      "display_url" : "go.wh.gov\/D1m4pr"
    } ]
  },
  "geo" : { },
  "id_str" : "796796439917686784",
  "text" : "Happening now: Watch @POTUS celebrate the 2016 NBA Champion Cleveland @Cavs: https:\/\/t.co\/otaerC6RbD https:\/\/t.co\/a0VSNTMhDX",
  "id" : 796796439917686784,
  "created_at" : "2016-11-10 19:27:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 72, 77 ],
      "id_str" : "19263978",
      "id" : 19263978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/otaerC6RbD",
      "expanded_url" : "http:\/\/go.wh.gov\/D1m4pr",
      "display_url" : "go.wh.gov\/D1m4pr"
    } ]
  },
  "geo" : { },
  "id_str" : "796794353540878336",
  "text" : "Tune in at 2:20pm ET as @POTUS welcomes the 2016 NBA Champion Cleveland @Cavs: https:\/\/t.co\/otaerC6RbD",
  "id" : 796794353540878336,
  "created_at" : "2016-11-10 19:19:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/VvaQqwzQu6",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "796763963216236544",
  "text" : "RT @SecBurwell: Best day yet this Open Enrollment. Nov 9: Over 100K plan selections on https:\/\/t.co\/VvaQqwzQu6. Consumers shopping &amp; enroll\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 132, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/VvaQqwzQu6",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "796759995530563585",
    "text" : "Best day yet this Open Enrollment. Nov 9: Over 100K plan selections on https:\/\/t.co\/VvaQqwzQu6. Consumers shopping &amp; enrolling. #GetCovered",
    "id" : 796759995530563585,
    "created_at" : "2016-11-10 17:02:40 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 796763963216236544,
  "created_at" : "2016-11-10 17:18:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/796499012232900608\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/E7vTnuVsEX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cw27f_tVIAA8p9M.jpg",
      "id_str" : "796498867466346496",
      "id" : 796498867466346496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cw27f_tVIAA8p9M.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/E7vTnuVsEX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/6g1AMST29u",
      "expanded_url" : "http:\/\/go.wh.gov\/WJ48yw",
      "display_url" : "go.wh.gov\/WJ48yw"
    } ]
  },
  "geo" : { },
  "id_str" : "796499012232900608",
  "text" : "\"We all go forward, with a presumption of good faith in our fellow citizens.\" \u2014@POTUS speaking in the Rose Garden: https:\/\/t.co\/6g1AMST29u https:\/\/t.co\/E7vTnuVsEX",
  "id" : 796499012232900608,
  "created_at" : "2016-11-09 23:45:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/pxvMRA7h09",
      "expanded_url" : "http:\/\/snpy.tv\/2fZJnoH",
      "display_url" : "snpy.tv\/2fZJnoH"
    } ]
  },
  "geo" : { },
  "id_str" : "796482985268756480",
  "text" : "\"To the young people...Don\u2019t get cynical. Don\u2019t ever think you can\u2019t make a difference.\" \u2014@POTUS https:\/\/t.co\/pxvMRA7h09",
  "id" : 796482985268756480,
  "created_at" : "2016-11-09 22:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/pxvMRA7h09",
      "expanded_url" : "http:\/\/snpy.tv\/2fZJnoH",
      "display_url" : "snpy.tv\/2fZJnoH"
    } ]
  },
  "geo" : { },
  "id_str" : "796413489401233408",
  "text" : "\"We have to remember that we\u2019re actually all on one team.\" \u2014@POTUS speaking in the Rose Garden https:\/\/t.co\/pxvMRA7h09",
  "id" : 796413489401233408,
  "created_at" : "2016-11-09 18:05:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/pxvMRA7h09",
      "expanded_url" : "http:\/\/snpy.tv\/2fZJnoH",
      "display_url" : "snpy.tv\/2fZJnoH"
    } ]
  },
  "geo" : { },
  "id_str" : "796409991020351489",
  "text" : "\"The peaceful transition of power is one of the hallmarks of our democracy.\" \u2014@POTUS https:\/\/t.co\/pxvMRA7h09",
  "id" : 796409991020351489,
  "created_at" : "2016-11-09 17:51:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/6g1AMST29u",
      "expanded_url" : "http:\/\/go.wh.gov\/WJ48yw",
      "display_url" : "go.wh.gov\/WJ48yw"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pxvMRA7h09",
      "expanded_url" : "http:\/\/snpy.tv\/2fZJnoH",
      "display_url" : "snpy.tv\/2fZJnoH"
    } ]
  },
  "geo" : { },
  "id_str" : "796406930076008451",
  "text" : "Watch @POTUS address the nation on the next steps we can take to come together as a country: https:\/\/t.co\/6g1AMST29u https:\/\/t.co\/pxvMRA7h09",
  "id" : 796406930076008451,
  "created_at" : "2016-11-09 17:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/6g1AMST29u",
      "expanded_url" : "http:\/\/go.wh.gov\/WJ48yw",
      "display_url" : "go.wh.gov\/WJ48yw"
    } ]
  },
  "geo" : { },
  "id_str" : "796402079392825344",
  "text" : "Happening now: Watch @POTUS speak on the election and next steps we can take to come together as a country: https:\/\/t.co\/6g1AMST29u",
  "id" : 796402079392825344,
  "created_at" : "2016-11-09 17:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/6g1AMST29u",
      "expanded_url" : "http:\/\/go.wh.gov\/WJ48yw",
      "display_url" : "go.wh.gov\/WJ48yw"
    } ]
  },
  "geo" : { },
  "id_str" : "796380334652801025",
  "text" : "Watch live at 12:15pm ET: @POTUS speaks on the election and next steps we can take to come together as a country: https:\/\/t.co\/6g1AMST29u",
  "id" : 796380334652801025,
  "created_at" : "2016-11-09 15:54:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/796035412942880768\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/5wMLRptPaD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwwVSKqUUAEA9vB.jpg",
      "id_str" : "796034635981410305",
      "id" : 796034635981410305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwwVSKqUUAEA9vB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/5wMLRptPaD"
    } ],
    "hashtags" : [ {
      "text" : "ElectionDay",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796035412942880768",
  "text" : "It's #ElectionDay. Don't forget to vote! https:\/\/t.co\/5wMLRptPaD",
  "id" : 796035412942880768,
  "created_at" : "2016-11-08 17:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/796023062768525312\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/035DOFV9Zd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwwKWvHVEAAUnLr.jpg",
      "id_str" : "796022619858341888",
      "id" : 796022619858341888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwwKWvHVEAAUnLr.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 445
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 785
      }, {
        "h" : 2041,
        "resize" : "fit",
        "w" : 1335
      }, {
        "h" : 2041,
        "resize" : "fit",
        "w" : 1335
      } ],
      "display_url" : "pic.twitter.com\/035DOFV9Zd"
    } ],
    "hashtags" : [ {
      "text" : "ElectionDay",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "796023062768525312",
  "text" : "\"My message to every American is simple: Get out there and vote.\" \u2014@POTUS #ElectionDay https:\/\/t.co\/035DOFV9Zd",
  "id" : 796023062768525312,
  "created_at" : "2016-11-08 16:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/795792962076770304\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/1VhsZHaXMW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwsfeUYW8AQumGc.jpg",
      "id_str" : "795764364888436740",
      "id" : 795764364888436740,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwsfeUYW8AQumGc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1VhsZHaXMW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795792962076770304",
  "text" : "We've come a long way. https:\/\/t.co\/1VhsZHaXMW",
  "id" : 795792962076770304,
  "created_at" : "2016-11-08 01:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/795735431719636992\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/vP2w9SNqUH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwsFBWzWgAAHOwL.jpg",
      "id_str" : "795735280019996672",
      "id" : 795735280019996672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwsFBWzWgAAHOwL.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/vP2w9SNqUH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Vn4bMh8eLE",
      "expanded_url" : "http:\/\/go.wh.gov\/LzxNEC",
      "display_url" : "go.wh.gov\/LzxNEC"
    } ]
  },
  "geo" : { },
  "id_str" : "795735431719636992",
  "text" : "Under @POTUS, 15.5 million new private-sector jobs have been created over the past 80 months. This is progress: https:\/\/t.co\/Vn4bMh8eLE https:\/\/t.co\/vP2w9SNqUH",
  "id" : 795735431719636992,
  "created_at" : "2016-11-07 21:11:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 13, 20 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/795698598763708417\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/HRcKfXwehr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cwrjp_5VEAEljRd.jpg",
      "id_str" : "795698594850344961",
      "id" : 795698594850344961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cwrjp_5VEAEljRd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HRcKfXwehr"
    } ],
    "hashtags" : [ {
      "text" : "fightflu",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/vyaq7kVpN8",
      "expanded_url" : "http:\/\/bit.ly\/Xi5c2G",
      "display_url" : "bit.ly\/Xi5c2G"
    } ]
  },
  "geo" : { },
  "id_str" : "795703434343305220",
  "text" : "RT @HHSGov: .@CDCgov recommends you take 3 steps to #fightflu this season \u2192 https:\/\/t.co\/vyaq7kVpN8 https:\/\/t.co\/HRcKfXwehr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CDC",
        "screen_name" : "CDCgov",
        "indices" : [ 1, 8 ],
        "id_str" : "146569971",
        "id" : 146569971
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/795698598763708417\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/HRcKfXwehr",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cwrjp_5VEAEljRd.jpg",
        "id_str" : "795698594850344961",
        "id" : 795698594850344961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cwrjp_5VEAEljRd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HRcKfXwehr"
      } ],
      "hashtags" : [ {
        "text" : "fightflu",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/vyaq7kVpN8",
        "expanded_url" : "http:\/\/bit.ly\/Xi5c2G",
        "display_url" : "bit.ly\/Xi5c2G"
      } ]
    },
    "geo" : { },
    "id_str" : "795698598763708417",
    "text" : ".@CDCgov recommends you take 3 steps to #fightflu this season \u2192 https:\/\/t.co\/vyaq7kVpN8 https:\/\/t.co\/HRcKfXwehr",
    "id" : 795698598763708417,
    "created_at" : "2016-11-07 18:45:03 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 795703434343305220,
  "created_at" : "2016-11-07 19:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/795701582268657664\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/kR6QXN2MHC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwrl7v0UsAAwHP7.jpg",
      "id_str" : "795701098795282432",
      "id" : 795701098795282432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwrl7v0UsAAwHP7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/kR6QXN2MHC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/pw1Xv6Otuq",
      "expanded_url" : "http:\/\/go.wh.gov\/ULzYQv",
      "display_url" : "go.wh.gov\/ULzYQv"
    } ]
  },
  "geo" : { },
  "id_str" : "795701582268657664",
  "text" : "Read @POTUS's full statement on the passing of Janet Reno, our nation's first female Attorney General: https:\/\/t.co\/pw1Xv6Otuq https:\/\/t.co\/kR6QXN2MHC",
  "id" : 795701582268657664,
  "created_at" : "2016-11-07 18:56:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 26, 32 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/795683502708563968\/video\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Q7ADpqmJ8d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
      "id_str" : "781143135065808901",
      "id" : 781143135065808901,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Q7ADpqmJ8d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/vogOikqYLO",
      "expanded_url" : "https:\/\/fafsa.ed.gov\/",
      "display_url" : "fafsa.ed.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "795689790284959745",
  "text" : "RT @usedgov: Fill out the @FAFSA! https:\/\/t.co\/vogOikqYLO https:\/\/t.co\/Q7ADpqmJ8d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Federal Student Aid",
        "screen_name" : "FAFSA",
        "indices" : [ 13, 19 ],
        "id_str" : "188001904",
        "id" : 188001904
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/795683502708563968\/video\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/Q7ADpqmJ8d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
        "id_str" : "781143135065808901",
        "id" : 781143135065808901,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Q7ADpqmJ8d"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/vogOikqYLO",
        "expanded_url" : "https:\/\/fafsa.ed.gov\/",
        "display_url" : "fafsa.ed.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "795683502708563968",
    "text" : "Fill out the @FAFSA! https:\/\/t.co\/vogOikqYLO https:\/\/t.co\/Q7ADpqmJ8d",
    "id" : 795683502708563968,
    "created_at" : "2016-11-07 17:45:04 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 795689790284959745,
  "created_at" : "2016-11-07 18:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/795683963432030209\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/v3XcvaPm8m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwrWDC-XEAEQJRV.jpg",
      "id_str" : "795683632010694657",
      "id" : 795683632010694657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwrWDC-XEAEQJRV.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/v3XcvaPm8m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795683963432030209",
  "text" : "When @POTUS took office, we were in the worst economic crisis of our lifetimes. Today, U.S. businesses have created 15.5 million new jobs. https:\/\/t.co\/v3XcvaPm8m",
  "id" : 795683963432030209,
  "created_at" : "2016-11-07 17:46:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 83, 88 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Recode\/status\/795589141769625600\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Glf9ZXkG1x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwqAG5YW8AALOgD.jpg",
      "id_str" : "795589140154871808",
      "id" : 795589140154871808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwqAG5YW8AALOgD.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Glf9ZXkG1x"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jFuSXOkyas",
      "expanded_url" : "http:\/\/www.recode.net\/2016\/11\/7\/13546638\/dj-patil-white-house-silicon-valley-data-scientist-recode-podcast?utm_campaign=recode.net&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "recode.net\/2016\/11\/7\/1354\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795642951745597440",
  "text" : "RT @Recode: Techies should take a \u2018tour of duty\u2019 in government, says White House\u2019s @DJ44 https:\/\/t.co\/jFuSXOkyas https:\/\/t.co\/Glf9ZXkG1x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.voxmedia.com\" rel=\"nofollow\"\u003EVox Media\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DJ Patil",
        "screen_name" : "DJ44",
        "indices" : [ 71, 76 ],
        "id_str" : "3030922321",
        "id" : 3030922321
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Recode\/status\/795589141769625600\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/Glf9ZXkG1x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwqAG5YW8AALOgD.jpg",
        "id_str" : "795589140154871808",
        "id" : 795589140154871808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwqAG5YW8AALOgD.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Glf9ZXkG1x"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/jFuSXOkyas",
        "expanded_url" : "http:\/\/www.recode.net\/2016\/11\/7\/13546638\/dj-patil-white-house-silicon-valley-data-scientist-recode-podcast?utm_campaign=recode.net&utm_content=chorus&utm_medium=social&utm_source=twitter",
        "display_url" : "recode.net\/2016\/11\/7\/1354\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "795589141769625600",
    "text" : "Techies should take a \u2018tour of duty\u2019 in government, says White House\u2019s @DJ44 https:\/\/t.co\/jFuSXOkyas https:\/\/t.co\/Glf9ZXkG1x",
    "id" : 795589141769625600,
    "created_at" : "2016-11-07 11:30:07 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 795642951745597440,
  "created_at" : "2016-11-07 15:03:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 3, 16 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795638521012875264",
  "text" : "RT @LorettaLynch: Janet Reno was an inspiration &amp; trailblazer for so many women in law enforcement &amp; government -- including me. She will b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "795630917905772544",
    "text" : "Janet Reno was an inspiration &amp; trailblazer for so many women in law enforcement &amp; government -- including me. She will be dearly missed.",
    "id" : 795630917905772544,
    "created_at" : "2016-11-07 14:16:07 +0000",
    "user" : {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "protected" : false,
      "id_str" : "3290070855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657296962052468736\/BBNYJ8rH_normal.jpg",
      "id" : 3290070855,
      "verified" : true
    }
  },
  "id" : 795638521012875264,
  "created_at" : "2016-11-07 14:46:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/HWCWAHCy6W",
      "expanded_url" : "http:\/\/snpy.tv\/2eDIGPU",
      "display_url" : "snpy.tv\/2eDIGPU"
    } ]
  },
  "geo" : { },
  "id_str" : "795462673571966976",
  "text" : "Catch Superman and a message from @POTUS in this #WestWingWeek: https:\/\/t.co\/HWCWAHCy6W",
  "id" : 795462673571966976,
  "created_at" : "2016-11-07 03:07:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 57, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/HWCWAHCy6W",
      "expanded_url" : "http:\/\/snpy.tv\/2eDIGPU",
      "display_url" : "snpy.tv\/2eDIGPU"
    } ]
  },
  "geo" : { },
  "id_str" : "795460711686275073",
  "text" : "\"These like look a couple of Obamas right here!\" \u2014@POTUS #WestWingWeek https:\/\/t.co\/HWCWAHCy6W",
  "id" : 795460711686275073,
  "created_at" : "2016-11-07 02:59:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ai0E7mE9Bh",
      "expanded_url" : "http:\/\/go.wh.gov\/4GSkHT",
      "display_url" : "go.wh.gov\/4GSkHT"
    } ]
  },
  "geo" : { },
  "id_str" : "795361363275042817",
  "text" : "\"If you haven\u2019t gotten covered yet, now\u2019s the time to do it.\" \u2014@POTUS\n#GetCovered at https:\/\/t.co\/GNfbftrfo3 https:\/\/t.co\/ai0E7mE9Bh",
  "id" : 795361363275042817,
  "created_at" : "2016-11-06 20:25:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ai0E7mVKZR",
      "expanded_url" : "http:\/\/go.wh.gov\/4GSkHT",
      "display_url" : "go.wh.gov\/4GSkHT"
    } ]
  },
  "geo" : { },
  "id_str" : "795295366291881985",
  "text" : "FACT: Most Americans who get coverage through https:\/\/t.co\/GNfbft9Ewv can find a plan that costs less than $75\/mo. https:\/\/t.co\/ai0E7mVKZR",
  "id" : 795295366291881985,
  "created_at" : "2016-11-06 16:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/795022890936713221\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/XCDgu4guoi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwhxznmUAAAeXNj.jpg",
      "id_str" : "795010465847836672",
      "id" : 795010465847836672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwhxznmUAAAeXNj.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/XCDgu4guoi"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5r9E9h6WeU",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "795022890936713221",
  "text" : "For the first time ever, more than 90% of Americans have health insurance. Join them and #GetCovered today: https:\/\/t.co\/5r9E9h6WeU https:\/\/t.co\/XCDgu4guoi",
  "id" : 795022890936713221,
  "created_at" : "2016-11-05 22:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ai0E7mVKZR",
      "expanded_url" : "http:\/\/go.wh.gov\/4GSkHT",
      "display_url" : "go.wh.gov\/4GSkHT"
    } ]
  },
  "geo" : { },
  "id_str" : "795011811305201664",
  "text" : "Free preventive care \u2713\nYoung people can stay on their parents\u2019 plan until 26 \u2713\n#GetCovered: https:\/\/t.co\/GNfbft9Ewv\nhttps:\/\/t.co\/ai0E7mVKZR",
  "id" : 795011811305201664,
  "created_at" : "2016-11-05 21:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795009108311212032",
  "text" : "RT @HHSGov: SHARE: Open Enrollment for 2017 is here! Most will be able to #GetCovered for less than $75\/month after tax credits. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/794917451624497152\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/FdvlCFeRff",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwgdNRhVQAEjbTY.jpg",
        "id_str" : "794917448109604865",
        "id" : 794917448109604865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwgdNRhVQAEjbTY.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/FdvlCFeRff"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 62, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/w434uyZuRY",
        "expanded_url" : "http:\/\/go.usa.gov\/xkFvQ",
        "display_url" : "go.usa.gov\/xkFvQ"
      } ]
    },
    "geo" : { },
    "id_str" : "794917451624497152",
    "text" : "SHARE: Open Enrollment for 2017 is here! Most will be able to #GetCovered for less than $75\/month after tax credits. https:\/\/t.co\/w434uyZuRY https:\/\/t.co\/FdvlCFeRff",
    "id" : 794917451624497152,
    "created_at" : "2016-11-05 15:01:03 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 795009108311212032,
  "created_at" : "2016-11-05 21:05:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ai0E7mVKZR",
      "expanded_url" : "http:\/\/go.wh.gov\/4GSkHT",
      "display_url" : "go.wh.gov\/4GSkHT"
    } ]
  },
  "geo" : { },
  "id_str" : "795006199439781889",
  "text" : "\u201CIf you haven\u2019t gotten covered yet, now\u2019s the time to do it. It\u2019s open enrollment season.\u201D \u2014@POTUS #GetCovered https:\/\/t.co\/ai0E7mVKZR",
  "id" : 795006199439781889,
  "created_at" : "2016-11-05 20:53:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/794954941370503168\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/E0izkvvcMv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwgJ9RoUsAAmLXK.jpg",
      "id_str" : "794896282540093440",
      "id" : 794896282540093440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwgJ9RoUsAAmLXK.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/E0izkvvcMv"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/5r9E9gPkQk",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "794954941370503168",
  "text" : "Don\u2019t wait: Join the millions who now have access to affordable health coverage. #GetCovered today \u2192 https:\/\/t.co\/5r9E9gPkQk https:\/\/t.co\/E0izkvvcMv",
  "id" : 794954941370503168,
  "created_at" : "2016-11-05 17:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ai0E7mE9Bh",
      "expanded_url" : "http:\/\/go.wh.gov\/4GSkHT",
      "display_url" : "go.wh.gov\/4GSkHT"
    } ]
  },
  "geo" : { },
  "id_str" : "794936060857880576",
  "text" : "\u201CNever in American history has the uninsured rate been lower than it is right now.\u201D \u2014@POTUS #GetCovered https:\/\/t.co\/ai0E7mE9Bh",
  "id" : 794936060857880576,
  "created_at" : "2016-11-05 16:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ai0E7mVKZR",
      "expanded_url" : "http:\/\/go.wh.gov\/4GSkHT",
      "display_url" : "go.wh.gov\/4GSkHT"
    } ]
  },
  "geo" : { },
  "id_str" : "794924736593719297",
  "text" : "\"Today, 20 million more American adults know the financial security of health insurance.\" \u2014@POTUS #GetCovered https:\/\/t.co\/ai0E7mVKZR",
  "id" : 794924736593719297,
  "created_at" : "2016-11-05 15:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HBO PR",
      "screen_name" : "HBOPR",
      "indices" : [ 3, 9 ],
      "id_str" : "2153490764",
      "id" : 2153490764
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Bill Maher",
      "screen_name" : "billmaher",
      "indices" : [ 97, 107 ],
      "id_str" : "19697415",
      "id" : 19697415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RealTime",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794664464301826049",
  "text" : "RT @HBOPR: Just four days before the presidential election, @POTUS will appear on #RealTime with @billmaher Friday, Nov. 4: https:\/\/t.co\/aY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 49, 55 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Bill Maher",
        "screen_name" : "billmaher",
        "indices" : [ 86, 96 ],
        "id_str" : "19697415",
        "id" : 19697415
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HBOPR\/status\/793890812677484544\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/CPnIWbV7Mn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwRz7DWWgAEUzSF.jpg",
        "id_str" : "793886892672581633",
        "id" : 793886892672581633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwRz7DWWgAEUzSF.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1876,
          "resize" : "fit",
          "w" : 2814
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/CPnIWbV7Mn"
      } ],
      "hashtags" : [ {
        "text" : "RealTime",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/aYOUPGT2uS",
        "expanded_url" : "http:\/\/itsh.bo\/ObamaAnnct",
        "display_url" : "itsh.bo\/ObamaAnnct"
      } ]
    },
    "geo" : { },
    "id_str" : "793890812677484544",
    "text" : "Just four days before the presidential election, @POTUS will appear on #RealTime with @billmaher Friday, Nov. 4: https:\/\/t.co\/aYOUPGT2uS https:\/\/t.co\/CPnIWbV7Mn",
    "id" : 793890812677484544,
    "created_at" : "2016-11-02 19:01:34 +0000",
    "user" : {
      "name" : "HBO PR",
      "screen_name" : "HBOPR",
      "protected" : false,
      "id_str" : "2153490764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655013077482496000\/XRaMgMvs_normal.jpg",
      "id" : 2153490764,
      "verified" : true
    }
  },
  "id" : 794664464301826049,
  "created_at" : "2016-11-04 22:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bear Grylls",
      "screen_name" : "BearGrylls",
      "indices" : [ 3, 14 ],
      "id_str" : "41692369",
      "id" : 41692369
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/hT4U8Jiyn8",
      "expanded_url" : "https:\/\/twitter.com\/deese44\/status\/794580821290217472",
      "display_url" : "twitter.com\/deese44\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794629251576184832",
  "text" : "RT @BearGrylls: A great moment for the future of our earth @POTUS https:\/\/t.co\/hT4U8Jiyn8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 43, 49 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/hT4U8Jiyn8",
        "expanded_url" : "https:\/\/twitter.com\/deese44\/status\/794580821290217472",
        "display_url" : "twitter.com\/deese44\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "794587018584002560",
    "text" : "A great moment for the future of our earth @POTUS https:\/\/t.co\/hT4U8Jiyn8",
    "id" : 794587018584002560,
    "created_at" : "2016-11-04 17:08:02 +0000",
    "user" : {
      "name" : "Bear Grylls",
      "screen_name" : "BearGrylls",
      "protected" : false,
      "id_str" : "41692369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697132535227117568\/t7VqgKGd_normal.jpg",
      "id" : 41692369,
      "verified" : true
    }
  },
  "id" : 794629251576184832,
  "created_at" : "2016-11-04 19:55:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/794622374691926017\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/4pkxQf4FuV",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CwcQlQhVQAA0tkg.jpg",
      "id_str" : "794622091530158080",
      "id" : 794622091530158080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CwcQlQhVQAA0tkg.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4pkxQf4FuV"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/k4HSl7ziaV",
      "expanded_url" : "http:\/\/go.wh.gov\/TTKBqq",
      "display_url" : "go.wh.gov\/TTKBqq"
    } ]
  },
  "geo" : { },
  "id_str" : "794622374691926017",
  "text" : "Today, the #ParisAgreement enters into force, years sooner than predicted. Here's why that matters for our planet: https:\/\/t.co\/k4HSl7ziaV https:\/\/t.co\/4pkxQf4FuV",
  "id" : 794622374691926017,
  "created_at" : "2016-11-04 19:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794614394751631360",
  "text" : "RT @JohnKerry: Today the #ParisAgreement goes into effect. Proud of this step taken by the int'l community &amp; energized to keep up work on #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JohnKerry\/status\/794601480875634688\/photo\/1",
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/GgigtYjM1m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwb9u_UXAAA5hwl.jpg",
        "id_str" : "794601367990108160",
        "id" : 794601367990108160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwb9u_UXAAA5hwl.jpg",
        "sizes" : [ {
          "h" : 1355,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 794,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1355,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/GgigtYjM1m"
      } ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 10, 25 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 127, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794601480875634688",
    "text" : "Today the #ParisAgreement goes into effect. Proud of this step taken by the int'l community &amp; energized to keep up work on #climatechange. https:\/\/t.co\/GgigtYjM1m",
    "id" : 794601480875634688,
    "created_at" : "2016-11-04 18:05:30 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 794614394751631360,
  "created_at" : "2016-11-04 18:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/794592827837583362\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/63bfxvoONf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwbyY28UkAAfG_M.jpg",
      "id_str" : "794588893156773888",
      "id" : 794588893156773888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwbyY28UkAAfG_M.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/63bfxvoONf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/at8cs4afpw",
      "expanded_url" : "http:\/\/go.wh.gov\/M5FkJi",
      "display_url" : "go.wh.gov\/M5FkJi"
    } ]
  },
  "geo" : { },
  "id_str" : "794592827837583362",
  "text" : ".@POTUS has commuted more sentences than the past 11 presidents combined. Today, he granted 72 more: https:\/\/t.co\/at8cs4afpw https:\/\/t.co\/63bfxvoONf",
  "id" : 794592827837583362,
  "created_at" : "2016-11-04 17:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/794580821290217472\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/0zz8C3wx1t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwbqo82VEAEklUV.jpg",
      "id_str" : "794580373527138305",
      "id" : 794580373527138305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwbqo82VEAEklUV.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/0zz8C3wx1t"
    } ],
    "hashtags" : [ {
      "text" : "ThanksObama",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794581848303144962",
  "text" : "RT @Deese44: The Paris Agreement enters into force TODAY - years earlier than many predicted. \n#ThanksObama https:\/\/t.co\/0zz8C3wx1t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/794580821290217472\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/0zz8C3wx1t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwbqo82VEAEklUV.jpg",
        "id_str" : "794580373527138305",
        "id" : 794580373527138305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwbqo82VEAEklUV.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/0zz8C3wx1t"
      } ],
      "hashtags" : [ {
        "text" : "ThanksObama",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794580821290217472",
    "text" : "The Paris Agreement enters into force TODAY - years earlier than many predicted. \n#ThanksObama https:\/\/t.co\/0zz8C3wx1t",
    "id" : 794580821290217472,
    "created_at" : "2016-11-04 16:43:25 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 794581848303144962,
  "created_at" : "2016-11-04 16:47:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/794573274227191808\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/7TPWImMAUw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwbkExGVEAIk7Oh.jpg",
      "id_str" : "794573154827964418",
      "id" : 794573154827964418,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwbkExGVEAIk7Oh.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/7TPWImMAUw"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/tcrWsAkEmy",
      "expanded_url" : "http:\/\/go.wh.gov\/7R3G9j",
      "display_url" : "go.wh.gov\/7R3G9j"
    } ]
  },
  "geo" : { },
  "id_str" : "794573274227191808",
  "text" : "Our economy added 161,000 jobs in October\u2014extending the longest streak of total job growth on record \u2192 https:\/\/t.co\/tcrWsAkEmy #JobsReport https:\/\/t.co\/7TPWImMAUw",
  "id" : 794573274227191808,
  "created_at" : "2016-11-04 16:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794569537504976896",
  "text" : "RT @VP: Never bet against the American worker:\n161,000 new jobs in October \u2713\nWages grew 2.8% this past year \u2713\nOn track for 3.1% by the end\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/794566115166810112\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/1IDvqPbg4f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwbcn6UXAAARm0E.jpg",
        "id_str" : "794564962505129984",
        "id" : 794564962505129984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwbcn6UXAAARm0E.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 965,
          "resize" : "fit",
          "w" : 1447
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 965,
          "resize" : "fit",
          "w" : 1447
        } ],
        "display_url" : "pic.twitter.com\/1IDvqPbg4f"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794566115166810112",
    "text" : "Never bet against the American worker:\n161,000 new jobs in October \u2713\nWages grew 2.8% this past year \u2713\nOn track for 3.1% by the end of 2016 \u2713 https:\/\/t.co\/1IDvqPbg4f",
    "id" : 794566115166810112,
    "created_at" : "2016-11-04 15:44:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 794569537504976896,
  "created_at" : "2016-11-04 15:58:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/l7ILUR7f0D",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/11\/04\/employment-situation-october",
      "display_url" : "whitehouse.gov\/blog\/2016\/11\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794562089478070272",
  "text" : "RT @JoiningForces: Since its peak, the unemployment rate for veterans has been cut by more than half \u2192 https:\/\/t.co\/l7ILUR7f0D https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/794557210206597124\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/jQGUzENqnZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwbVjvXXgAIZpfN.jpg",
        "id_str" : "794557194264084482",
        "id" : 794557194264084482,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwbVjvXXgAIZpfN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 911
        } ],
        "display_url" : "pic.twitter.com\/jQGUzENqnZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/l7ILUR7f0D",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/11\/04\/employment-situation-october",
        "display_url" : "whitehouse.gov\/blog\/2016\/11\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "794557210206597124",
    "text" : "Since its peak, the unemployment rate for veterans has been cut by more than half \u2192 https:\/\/t.co\/l7ILUR7f0D https:\/\/t.co\/jQGUzENqnZ",
    "id" : 794557210206597124,
    "created_at" : "2016-11-04 15:09:35 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 794562089478070272,
  "created_at" : "2016-11-04 15:28:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fiyU4nyHa8",
      "expanded_url" : "https:\/\/blog.dol.gov\/2016\/11\/04\/october-jobs-report-shows-how-far-weve-come\/",
      "display_url" : "blog.dol.gov\/2016\/11\/04\/oct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794555022226780160",
  "text" : "RT @LaborSec: Our economy shows continued strength month after month. Americans are getting the raise they deserve. https:\/\/t.co\/fiyU4nyHa8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsReport",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/fiyU4nyHa8",
        "expanded_url" : "https:\/\/blog.dol.gov\/2016\/11\/04\/october-jobs-report-shows-how-far-weve-come\/",
        "display_url" : "blog.dol.gov\/2016\/11\/04\/oct\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "794546597375967232",
    "text" : "Our economy shows continued strength month after month. Americans are getting the raise they deserve. https:\/\/t.co\/fiyU4nyHa8 #JobsReport",
    "id" : 794546597375967232,
    "created_at" : "2016-11-04 14:27:25 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 794555022226780160,
  "created_at" : "2016-11-04 15:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/794553137545678849\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/MKJ4ViJ7VI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwbR2fpUUAIG_T3.jpg",
      "id_str" : "794553118415409154",
      "id" : 794553118415409154,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwbR2fpUUAIG_T3.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/MKJ4ViJ7VI"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/tcrWsAkEmy",
      "expanded_url" : "http:\/\/go.wh.gov\/7R3G9j",
      "display_url" : "go.wh.gov\/7R3G9j"
    } ]
  },
  "geo" : { },
  "id_str" : "794553137545678849",
  "text" : "Wages \u2191\nUnemployment \u2193\n15.5 million jobs added \u2713\n\nThis is what progress looks like: https:\/\/t.co\/tcrWsAkEmy #JobsReport https:\/\/t.co\/MKJ4ViJ7VI",
  "id" : 794553137545678849,
  "created_at" : "2016-11-04 14:53:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/794542060250415104\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QdlhISHR6M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwbHP5mUcAA8Qiz.jpg",
      "id_str" : "794541460250980352",
      "id" : 794541460250980352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwbHP5mUcAA8Qiz.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/QdlhISHR6M"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/tcrWsAkEmy",
      "expanded_url" : "http:\/\/go.wh.gov\/7R3G9j",
      "display_url" : "go.wh.gov\/7R3G9j"
    } ]
  },
  "geo" : { },
  "id_str" : "794542060250415104",
  "text" : "Good news: Our businesses have added 15.5 million jobs over the past 80 months \u2192 https:\/\/t.co\/tcrWsAkEmy #JobsReport https:\/\/t.co\/QdlhISHR6M",
  "id" : 794542060250415104,
  "created_at" : "2016-11-04 14:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Andy Slavitt",
      "screen_name" : "ASlavitt",
      "indices" : [ 57, 66 ],
      "id_str" : "1383272101",
      "id" : 1383272101
    }, {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "indices" : [ 71, 87 ],
      "id_str" : "67215899",
      "id" : 67215899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794540936814530561",
  "text" : "RT @vj44: Looking forward to today\u2019s Q&amp;A on ACA with @ASlavitt and @YoungInvincible starting 10:15am ET. Get your questions in now w\/ #GetC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Slavitt",
        "screen_name" : "ASlavitt",
        "indices" : [ 47, 56 ],
        "id_str" : "1383272101",
        "id" : 1383272101
      }, {
        "name" : "Young Invincibles",
        "screen_name" : "YoungInvincible",
        "indices" : [ 61, 77 ],
        "id_str" : "67215899",
        "id" : 67215899
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794534315736629248",
    "text" : "Looking forward to today\u2019s Q&amp;A on ACA with @ASlavitt and @YoungInvincible starting 10:15am ET. Get your questions in now w\/ #GetCovered!",
    "id" : 794534315736629248,
    "created_at" : "2016-11-04 13:38:37 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 794540936814530561,
  "created_at" : "2016-11-04 14:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 20, 25 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/794371569351016453\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/AvthcdzcQw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwYsT6GUAAAHKi5.jpg",
      "id_str" : "794371104802340864",
      "id" : 794371104802340864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwYsT6GUAAAHKi5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/AvthcdzcQw"
    } ],
    "hashtags" : [ {
      "text" : "WorldSeries",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794371569351016453",
  "text" : "Today @POTUS called @Cubs Manager Joe Maddon to officially invite the #WorldSeries championship team to the White House. https:\/\/t.co\/AvthcdzcQw",
  "id" : 794371569351016453,
  "created_at" : "2016-11-04 02:51:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/PJ7xIKP3Vo",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "794322691838853120",
  "text" : "RT @POTUS: It's pretty simple: Find a plan, get covered, earn some peace of mind. Start today: https:\/\/t.co\/PJ7xIKP3Vo https:\/\/t.co\/ZBQdNz8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/794322003754790913\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ZBQdNz8s80",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwX_GEnUkAEyLS6.jpg",
        "id_str" : "794299143942344704",
        "id" : 794299143942344704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwX_GEnUkAEyLS6.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 1433
        } ],
        "display_url" : "pic.twitter.com\/ZBQdNz8s80"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/PJ7xIKP3Vo",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "794322003754790913",
    "text" : "It's pretty simple: Find a plan, get covered, earn some peace of mind. Start today: https:\/\/t.co\/PJ7xIKP3Vo https:\/\/t.co\/ZBQdNz8s80",
    "id" : 794322003754790913,
    "created_at" : "2016-11-03 23:34:58 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 794322691838853120,
  "created_at" : "2016-11-03 23:37:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/794305656245383172\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/FKGb6GrL4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwXhQ6rUQAAhTnX.jpg",
      "id_str" : "794288590045855744",
      "id" : 794288590045855744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwXhQ6rUQAAhTnX.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/FKGb6GrL4A"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IJJnqSxeSD",
      "expanded_url" : "http:\/\/go.wh.gov\/EQe1gr",
      "display_url" : "go.wh.gov\/EQe1gr"
    } ]
  },
  "geo" : { },
  "id_str" : "794305656245383172",
  "text" : "Here's how we're taking key steps forward to ensure our roads are accessible for electric vehicles coast-to-coast: https:\/\/t.co\/IJJnqSxeSD https:\/\/t.co\/FKGb6GrL4A",
  "id" : 794305656245383172,
  "created_at" : "2016-11-03 22:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Andy Slavitt",
      "screen_name" : "ASlavitt",
      "indices" : [ 61, 70 ],
      "id_str" : "1383272101",
      "id" : 1383272101
    }, {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "indices" : [ 76, 92 ],
      "id_str" : "67215899",
      "id" : 67215899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794304995403264000",
  "text" : "RT @vj44: Questions on the ACA and open enrollment? Join me, @ASlavitt, and @YoungInvincible for a Q&amp;A at 10:15am ET tomorrow using #GetCov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Slavitt",
        "screen_name" : "ASlavitt",
        "indices" : [ 51, 60 ],
        "id_str" : "1383272101",
        "id" : 1383272101
      }, {
        "name" : "Young Invincibles",
        "screen_name" : "YoungInvincible",
        "indices" : [ 66, 82 ],
        "id_str" : "67215899",
        "id" : 67215899
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794303775972478979",
    "text" : "Questions on the ACA and open enrollment? Join me, @ASlavitt, and @YoungInvincible for a Q&amp;A at 10:15am ET tomorrow using #GetCovered!",
    "id" : 794303775972478979,
    "created_at" : "2016-11-03 22:22:32 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 794304995403264000,
  "created_at" : "2016-11-03 22:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794294773360119808",
  "text" : "RT @USAID: We have a lot to be proud of\u2014and hopeful for\u2014as we commemorate 55 years of promoting the dignity and freedom of people everywher\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USAID\/status\/794292650958434304\/video\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/uy7atbhF9e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwXkp0GXUAQ6HDz.jpg",
        "id_str" : "794291010494832640",
        "id" : 794291010494832640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwXkp0GXUAQ6HDz.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/uy7atbhF9e"
      } ],
      "hashtags" : [ {
        "text" : "USAID55",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794292650958434304",
    "text" : "We have a lot to be proud of\u2014and hopeful for\u2014as we commemorate 55 years of promoting the dignity and freedom of people everywhere. #USAID55 https:\/\/t.co\/uy7atbhF9e",
    "id" : 794292650958434304,
    "created_at" : "2016-11-03 21:38:19 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 794294773360119808,
  "created_at" : "2016-11-03 21:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/794288028508299264\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/zw5JURLsQi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwXgsVaUsAEC_Nr.jpg",
      "id_str" : "794287961567178753",
      "id" : 794287961567178753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwXgsVaUsAEC_Nr.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/zw5JURLsQi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/IJJnqSfDu3",
      "expanded_url" : "http:\/\/go.wh.gov\/EQe1gr",
      "display_url" : "go.wh.gov\/EQe1gr"
    } ]
  },
  "geo" : { },
  "id_str" : "794288028508299264",
  "text" : "25,000 miles \u2713\n35 states \u2713\nCoast-to-coast \u2713\n\nTaking a road trip in an electric vehicle will be easier than ever: https:\/\/t.co\/IJJnqSfDu3 https:\/\/t.co\/zw5JURLsQi",
  "id" : 794288028508299264,
  "created_at" : "2016-11-03 21:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794275890284797952",
  "text" : "RT @WhiteHouseCEQ: Big news: 24 state &amp; local governments have committed to putting more than 2,500 new EVs on the road \u2192 https:\/\/t.co\/04CV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 131, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/04CVWDPzfS",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/11\/03\/obama-administration-announces-new-actions-accelerate-deployment",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "794262099757178880",
    "text" : "Big news: 24 state &amp; local governments have committed to putting more than 2,500 new EVs on the road \u2192 https:\/\/t.co\/04CVWDPzfS #ActOnClimate",
    "id" : 794262099757178880,
    "created_at" : "2016-11-03 19:36:55 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 794275890284797952,
  "created_at" : "2016-11-03 20:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 14, 20 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/794273891900223488\/photo\/1",
      "indices" : [ 126, 149 ],
      "url" : "https:\/\/t.co\/0cMfFsbyPb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwXTBdIVEAAD7xa.jpg",
      "id_str" : "794272931253653504",
      "id" : 794272931253653504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwXTBdIVEAAD7xa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0cMfFsbyPb"
    } ],
    "hashtags" : [ {
      "text" : "USAID55",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794273891900223488",
  "text" : "For 55 years, @USAID has exemplified America's values abroad\u2014while advancing the safety and prosperity here at home. #USAID55 https:\/\/t.co\/0cMfFsbyPb",
  "id" : 794273891900223488,
  "created_at" : "2016-11-03 20:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/szbIZXCsW0",
      "expanded_url" : "https:\/\/twitter.com\/nymagPR\/status\/794215685530460160",
      "display_url" : "twitter.com\/nymagPR\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "794257434676109312",
  "text" : ".@POTUS has commuted more sentences than the last 11 presidents combined. Hear from 4 Americans whose lives were changed: https:\/\/t.co\/szbIZXCsW0",
  "id" : 794257434676109312,
  "created_at" : "2016-11-03 19:18:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gayle Smith",
      "screen_name" : "GayleSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "4362952695",
      "id" : 4362952695
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 31, 37 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAID55",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794242338402861056",
  "text" : "RT @GayleSmith: 55 years after @USAID was first created, here are 5 reasons why I'm more hopeful than ever for the future #USAID55\n\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USAID",
        "screen_name" : "USAID",
        "indices" : [ 15, 21 ],
        "id_str" : "36683668",
        "id" : 36683668
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAID55",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/BzfhND4rm8",
        "expanded_url" : "https:\/\/medium.com\/usaid-2030\/our-greatest-quest-yet-89f2830a372c#.sepc0l4pv",
        "display_url" : "medium.com\/usaid-2030\/our\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "794194274761981953",
    "text" : "55 years after @USAID was first created, here are 5 reasons why I'm more hopeful than ever for the future #USAID55\n\nhttps:\/\/t.co\/BzfhND4rm8",
    "id" : 794194274761981953,
    "created_at" : "2016-11-03 15:07:25 +0000",
    "user" : {
      "name" : "Gayle Smith",
      "screen_name" : "GayleSmith",
      "protected" : false,
      "id_str" : "4362952695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723577327335145472\/jahpvNQ8_normal.jpg",
      "id" : 4362952695,
      "verified" : true
    }
  },
  "id" : 794242338402861056,
  "created_at" : "2016-11-03 18:18:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naz Riahi",
      "screen_name" : "nazriahi",
      "indices" : [ 3, 12 ],
      "id_str" : "50315155",
      "id" : 50315155
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 95, 106 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794209326973919232",
  "text" : "RT @nazriahi: Thrilled beyond measure that  @POTUS responded to a piece I wrote about visiting @WhiteHouse for #SXSL So surreal! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 30, 36 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 81, 92 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/4Fz8YrCuhc",
        "expanded_url" : "https:\/\/medium.com\/@PresidentObama\/a-few-weeks-ago-we-brought-artists-creators-and-entrepreneurs-to-the-white-house-for-an-event-1608555f4a91#.4bc2mshq5",
        "display_url" : "medium.com\/@PresidentObam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "794207770245414914",
    "text" : "Thrilled beyond measure that  @POTUS responded to a piece I wrote about visiting @WhiteHouse for #SXSL So surreal! https:\/\/t.co\/4Fz8YrCuhc \u2026",
    "id" : 794207770245414914,
    "created_at" : "2016-11-03 16:01:02 +0000",
    "user" : {
      "name" : "Naz Riahi",
      "screen_name" : "nazriahi",
      "protected" : false,
      "id_str" : "50315155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683018995654619136\/8iytzjHp_normal.jpg",
      "id" : 50315155,
      "verified" : false
    }
  },
  "id" : 794209326973919232,
  "created_at" : "2016-11-03 16:07:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 77, 82 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/794196061728423936\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/OuqiMMaAo2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwWNGp8WIAExoW3.jpg",
      "id_str" : "794196054778454017",
      "id" : 794196054778454017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwWNGp8WIAExoW3.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/OuqiMMaAo2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794201554370719745",
  "text" : "RT @vj44: Anita in the Beast w\/ @POTUS on the \"happiest day of her life.\" Go @Cubs!! https:\/\/t.co\/OuqiMMaAo2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 67, 72 ],
        "id_str" : "41144996",
        "id" : 41144996
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/794196061728423936\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/OuqiMMaAo2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwWNGp8WIAExoW3.jpg",
        "id_str" : "794196054778454017",
        "id" : 794196054778454017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwWNGp8WIAExoW3.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/OuqiMMaAo2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794196061728423936",
    "text" : "Anita in the Beast w\/ @POTUS on the \"happiest day of her life.\" Go @Cubs!! https:\/\/t.co\/OuqiMMaAo2",
    "id" : 794196061728423936,
    "created_at" : "2016-11-03 15:14:31 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 794201554370719745,
  "created_at" : "2016-11-03 15:36:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 24, 29 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794057886506905600",
  "text" : "RT @POTUS: It happened: @Cubs win World Series. That's change even this South Sider can believe in. Want to come to the White House before\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 13, 18 ],
        "id_str" : "41144996",
        "id" : 41144996
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794057504871346176",
    "text" : "It happened: @Cubs win World Series. That's change even this South Sider can believe in. Want to come to the White House before I leave?",
    "id" : 794057504871346176,
    "created_at" : "2016-11-03 06:03:56 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 794057886506905600,
  "created_at" : "2016-11-03 06:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 15, 20 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlytheW",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794043448710021120",
  "text" : "RT @FLOTUS: Go @Cubs, go! Been rooting for you since I was a kid, and so incredibly proud tonight. #FlytheW -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 3, 8 ],
        "id_str" : "41144996",
        "id" : 41144996
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlytheW",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "794040022143995904",
    "text" : "Go @Cubs, go! Been rooting for you since I was a kid, and so incredibly proud tonight. #FlytheW -mo",
    "id" : 794040022143995904,
    "created_at" : "2016-11-03 04:54:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 794043448710021120,
  "created_at" : "2016-11-03 05:08:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/793965665677819905\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/quM1FjRuu5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwS3obvUQAEtgrX.jpg",
      "id_str" : "793961339592916993",
      "id" : 793961339592916993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwS3obvUQAEtgrX.jpg",
      "sizes" : [ {
        "h" : 526,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/quM1FjRuu5"
    } ],
    "hashtags" : [ {
      "text" : "WorldSeries",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793965665677819905",
  "text" : "Play ball! #WorldSeries https:\/\/t.co\/quM1FjRuu5",
  "id" : 793965665677819905,
  "created_at" : "2016-11-02 23:59:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/793944806695243776\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/F8HVZ6dZ6z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwSofdZUcAAy60-.jpg",
      "id_str" : "793944692744286208",
      "id" : 793944692744286208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwSofdZUcAAy60-.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/F8HVZ6dZ6z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/OyRJdVZikg",
      "expanded_url" : "http:\/\/go.wh.gov\/bCZs7b",
      "display_url" : "go.wh.gov\/bCZs7b"
    } ]
  },
  "geo" : { },
  "id_str" : "793944806695243776",
  "text" : "Record-high fuel economy \u2713\nGreenhouse gas emissions \u2193 \n\nHere's how today's news benefits consumers and our planet: https:\/\/t.co\/OyRJdVZikg https:\/\/t.co\/F8HVZ6dZ6z",
  "id" : 793944806695243776,
  "created_at" : "2016-11-02 22:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/793936012091146240\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/KmGTh4QUEq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwSgkphXAAAjXeH.jpg",
      "id_str" : "793935985805557760",
      "id" : 793935985805557760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwSgkphXAAAjXeH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/KmGTh4QUEq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/nlyVhecwqu",
      "expanded_url" : "http:\/\/go.wh.gov\/dxSAmN",
      "display_url" : "go.wh.gov\/dxSAmN"
    } ]
  },
  "geo" : { },
  "id_str" : "793936012091146240",
  "text" : "Read @POTUS\u2019s statement on the shooting of police officers in Des Moines, Iowa: https:\/\/t.co\/nlyVhecwqu https:\/\/t.co\/KmGTh4QUEq",
  "id" : 793936012091146240,
  "created_at" : "2016-11-02 22:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "ARPA-E",
      "screen_name" : "ARPAE",
      "indices" : [ 31, 37 ],
      "id_str" : "55308417",
      "id" : 55308417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793886763257176064",
  "text" : "RT @ErnestMoniz: Big news from @ARPAE: $32 million for connected and automated cars. Could reduce vehicle energy use by 20% \n\u2B07\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ARPA-E",
        "screen_name" : "ARPAE",
        "indices" : [ 14, 20 ],
        "id_str" : "55308417",
        "id" : 55308417
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/793847038601461760\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/6iq1qwd1Fm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwRPejsWIAEyV_l.jpg",
        "id_str" : "793846820719960065",
        "id" : 793846820719960065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwRPejsWIAEyV_l.jpg",
        "sizes" : [ {
          "h" : 1715,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1171,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 686,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/6iq1qwd1Fm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/0FDEJUG6oz",
        "expanded_url" : "http:\/\/energy.gov\/articles\/department-energy-announces-10-new-projects-improve-connected-and-automated-vehicle",
        "display_url" : "energy.gov\/articles\/depar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793847038601461760",
    "text" : "Big news from @ARPAE: $32 million for connected and automated cars. Could reduce vehicle energy use by 20% \n\u2B07\nhttps:\/\/t.co\/0FDEJUG6oz https:\/\/t.co\/6iq1qwd1Fm",
    "id" : 793847038601461760,
    "created_at" : "2016-11-02 16:07:37 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 793886763257176064,
  "created_at" : "2016-11-02 18:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793878666858160128",
  "text" : "RT @GinaEPA: Great news for car drivers &amp; the climate \u2013 GHG standards are being met &amp; average fuel economy is at a record high! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/uslANR1cll",
        "expanded_url" : "https:\/\/www.epa.gov\/newsreleases\/automakers-outperform-greenhouse-gas-emissions-standards-4th-consecutive-year",
        "display_url" : "epa.gov\/newsreleases\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793854556274888704",
    "text" : "Great news for car drivers &amp; the climate \u2013 GHG standards are being met &amp; average fuel economy is at a record high! https:\/\/t.co\/uslANR1cll",
    "id" : 793854556274888704,
    "created_at" : "2016-11-02 16:37:29 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 793878666858160128,
  "created_at" : "2016-11-02 18:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/kGBBhFRAiN",
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/793605912468529153",
      "display_url" : "twitter.com\/whitehouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793611593368035328",
  "text" : "RT @Goldman44: Halloween candy already running low? Some bonus treats here. https:\/\/t.co\/kGBBhFRAiN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/kGBBhFRAiN",
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/793605912468529153",
        "display_url" : "twitter.com\/whitehouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793607380856545280",
    "text" : "Halloween candy already running low? Some bonus treats here. https:\/\/t.co\/kGBBhFRAiN",
    "id" : 793607380856545280,
    "created_at" : "2016-11-02 00:15:18 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 793611593368035328,
  "created_at" : "2016-11-02 00:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/MWXIh0gcut",
      "expanded_url" : "http:\/\/snpy.tv\/2eZ5BmN",
      "display_url" : "snpy.tv\/2eZ5BmN"
    } ]
  },
  "geo" : { },
  "id_str" : "793605912468529153",
  "text" : "\u201CSuperman, you\u2019ve got to give me a high-five!\u201D #ObamaAndKids https:\/\/t.co\/MWXIh0gcut",
  "id" : 793605912468529153,
  "created_at" : "2016-11-02 00:09:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/793595245770387456\/photo\/1",
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/MrP8cHIkpE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwNqXlIWEAAvN0B.jpg",
      "id_str" : "793594912683986944",
      "id" : 793594912683986944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwNqXlIWEAAvN0B.jpg",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/MrP8cHIkpE"
    } ],
    "hashtags" : [ {
      "text" : "NationalAuthorsDay",
      "indices" : [ 3, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/UVIyi864am",
      "expanded_url" : "http:\/\/go.wh.gov\/V47mnV",
      "display_url" : "go.wh.gov\/V47mnV"
    } ]
  },
  "geo" : { },
  "id_str" : "793595245770387456",
  "text" : "On #NationalAuthorsDay, take a look back at @POTUS's interview with renowned novelist Marilynne Robinson: https:\/\/t.co\/UVIyi864am https:\/\/t.co\/MrP8cHIkpE",
  "id" : 793595245770387456,
  "created_at" : "2016-11-01 23:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793575828932009984",
  "text" : "RT @lacasablanca: La t\u00EDpica Latina tarda 22 meses en ganar lo que un hombre blanco gana en 12 meses. Tenemos que cerrar la brecha salarial.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lacasablanca\/status\/793573507867090944\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/qhaehEvWzS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwNWYk6UEAAhTOI.jpg",
        "id_str" : "793572939572449280",
        "id" : 793572939572449280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwNWYk6UEAAhTOI.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/qhaehEvWzS"
      } ],
      "hashtags" : [ {
        "text" : "LatinaEqualPay",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "793573507867090944",
    "text" : "La t\u00EDpica Latina tarda 22 meses en ganar lo que un hombre blanco gana en 12 meses. Tenemos que cerrar la brecha salarial. #LatinaEqualPay https:\/\/t.co\/qhaehEvWzS",
    "id" : 793573507867090944,
    "created_at" : "2016-11-01 22:00:42 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 793575828932009984,
  "created_at" : "2016-11-01 22:09:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793563478464139264",
  "text" : "RT @Cecilia44: At #SXSL, a digital tool launched to help workers unite their voices and build better, more equitable workplaces. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 3, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/OlNaFLcUsh",
        "expanded_url" : "https:\/\/medium.com\/the-white-house\/twelve-months-of-worker-voice-8be681f2e571#.83ilyt759",
        "display_url" : "medium.com\/the-white-hous\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793559819546267650",
    "text" : "At #SXSL, a digital tool launched to help workers unite their voices and build better, more equitable workplaces. https:\/\/t.co\/OlNaFLcUsh",
    "id" : 793559819546267650,
    "created_at" : "2016-11-01 21:06:19 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 793563478464139264,
  "created_at" : "2016-11-01 21:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/793551178554630145\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/4K288RHVVc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwNCTyOXEAALyjA.jpg",
      "id_str" : "793550867014291456",
      "id" : 793550867014291456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwNCTyOXEAALyjA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1433,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1433,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/4K288RHVVc"
    } ],
    "hashtags" : [ {
      "text" : "LatinaEqualPay",
      "indices" : [ 3, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793551178554630145",
  "text" : "On #LatinaEqualPay Day, we mark the work that remains to ensure that all Americans receive equal pay for equal work. https:\/\/t.co\/4K288RHVVc",
  "id" : 793551178554630145,
  "created_at" : "2016-11-01 20:31:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/793503013709221890\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LimQHFZKSH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwMWOWdWEAAifg-.jpg",
      "id_str" : "793502395149979648",
      "id" : 793502395149979648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwMWOWdWEAAifg-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/LimQHFZKSH"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/5r9E9h6WeU",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "793503013709221890",
  "text" : "RT so your friends know: You can sign up for health coverage starting TODAY \u2192 https:\/\/t.co\/5r9E9h6WeU #GetCovered https:\/\/t.co\/LimQHFZKSH",
  "id" : 793503013709221890,
  "created_at" : "2016-11-01 17:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Architectural Digest",
      "screen_name" : "ArchDigest",
      "indices" : [ 3, 14 ],
      "id_str" : "26576457",
      "id" : 26576457
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 17, 24 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/TBqoXn4l8k",
      "expanded_url" : "http:\/\/archdg.co\/lJTywND",
      "display_url" : "archdg.co\/lJTywND"
    } ]
  },
  "geo" : { },
  "id_str" : "793472317502398468",
  "text" : "RT @ArchDigest: .@FLOTUS and @POTUS give us a rare glimpse into their life inside the White House: https:\/\/t.co\/TBqoXn4l8k https:\/\/t.co\/Hln\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 1, 8 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ArchDigest\/status\/793431112982925312\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/HlnpH47KtV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwLVXtHXEAEAWO8.jpg",
        "id_str" : "793431087594803201",
        "id" : 793431087594803201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwLVXtHXEAEAWO8.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 971
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 971
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 971
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/HlnpH47KtV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/TBqoXn4l8k",
        "expanded_url" : "http:\/\/archdg.co\/lJTywND",
        "display_url" : "archdg.co\/lJTywND"
      } ]
    },
    "geo" : { },
    "id_str" : "793431112982925312",
    "text" : ".@FLOTUS and @POTUS give us a rare glimpse into their life inside the White House: https:\/\/t.co\/TBqoXn4l8k https:\/\/t.co\/HlnpH47KtV",
    "id" : 793431112982925312,
    "created_at" : "2016-11-01 12:34:53 +0000",
    "user" : {
      "name" : "Architectural Digest",
      "screen_name" : "ArchDigest",
      "protected" : false,
      "id_str" : "26576457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793431238044426244\/Eqm_u7Um_normal.jpg",
      "id" : 26576457,
      "verified" : true
    }
  },
  "id" : 793472317502398468,
  "created_at" : "2016-11-01 15:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/VvaQqwzQu6",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "793452314958913536",
  "text" : "RT @SecBurwell: The Health Insurance Marketplace is open for business! Shop. Compare. Enroll. https:\/\/t.co\/VvaQqwzQu6 #GetCovered https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SecBurwell\/status\/793428013652307968\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/PiaS8FtjpR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwLR0BSXEAAH-5W.jpg",
        "id_str" : "793427175999475712",
        "id" : 793427175999475712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwLR0BSXEAAH-5W.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        } ],
        "display_url" : "pic.twitter.com\/PiaS8FtjpR"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/VvaQqwzQu6",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "793428013652307968",
    "text" : "The Health Insurance Marketplace is open for business! Shop. Compare. Enroll. https:\/\/t.co\/VvaQqwzQu6 #GetCovered https:\/\/t.co\/PiaS8FtjpR",
    "id" : 793428013652307968,
    "created_at" : "2016-11-01 12:22:34 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 793452314958913536,
  "created_at" : "2016-11-01 13:59:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]