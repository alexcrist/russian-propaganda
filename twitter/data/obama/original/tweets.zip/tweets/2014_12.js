Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 39, 51 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550468618472136705",
  "text" : "RT @FLOTUS: In its first year, see how @ReachHigher inspired more students to complete their education and achieve their dreams \u2192 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 27, 39 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zj7hf5N9EL",
        "expanded_url" : "http:\/\/go.wh.gov\/mefe8z",
        "display_url" : "go.wh.gov\/mefe8z"
      } ]
    },
    "geo" : { },
    "id_str" : "550441451264307202",
    "text" : "In its first year, see how @ReachHigher inspired more students to complete their education and achieve their dreams \u2192 http:\/\/t.co\/zj7hf5N9EL",
    "id" : 550441451264307202,
    "created_at" : "2015-01-01 00:00:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 550468618472136705,
  "created_at" : "2015-01-01 01:48:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/550402163131023360\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/4kWcAF2vom",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6NroqACUAAO2js.jpg",
      "id_str" : "550401925682712576",
      "id" : 550401925682712576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6NroqACUAAO2js.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4kWcAF2vom"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/A6LunmYwCh",
      "expanded_url" : "http:\/\/go.wh.gov\/2014-photos",
      "display_url" : "go.wh.gov\/2014-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "550402163131023360",
  "text" : "Oval Office race: http:\/\/t.co\/A6LunmYwCh http:\/\/t.co\/4kWcAF2vom",
  "id" : 550402163131023360,
  "created_at" : "2014-12-31 21:24:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/F6vr2JZeoa",
      "expanded_url" : "http:\/\/WH.gov\/2014-in-photos",
      "display_url" : "WH.gov\/2014-in-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "550396932800380928",
  "text" : "RT @petesouza: ICYMI. My year of behind-the-scenes photos of the Obama presidency: http:\/\/t.co\/F6vr2JZeoa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/F6vr2JZeoa",
        "expanded_url" : "http:\/\/WH.gov\/2014-in-photos",
        "display_url" : "WH.gov\/2014-in-photos"
      } ]
    },
    "geo" : { },
    "id_str" : "550358746489040896",
    "text" : "ICYMI. My year of behind-the-scenes photos of the Obama presidency: http:\/\/t.co\/F6vr2JZeoa",
    "id" : 550358746489040896,
    "created_at" : "2014-12-31 18:32:04 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 550396932800380928,
  "created_at" : "2014-12-31 21:03:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 75, 85 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/550346424140185600\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/DQNsTDy8eX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6M4uacCQAAIwHL.jpg",
      "id_str" : "550345949491380224",
      "id" : 550345949491380224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6M4uacCQAAIwHL.jpg",
      "sizes" : [ {
        "h" : 563,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 906
      }, {
        "h" : 993,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 906
      } ],
      "display_url" : "pic.twitter.com\/DQNsTDy8eX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/A6LunmYwCh",
      "expanded_url" : "http:\/\/go.wh.gov\/2014-photos",
      "display_url" : "go.wh.gov\/2014-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "550346424140185600",
  "text" : "Scroll through the best White House photos from 2014, with commentary from @PeteSouza \u2192 http:\/\/t.co\/A6LunmYwCh http:\/\/t.co\/DQNsTDy8eX",
  "id" : 550346424140185600,
  "created_at" : "2014-12-31 17:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/550329410587754496\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/rSXVuMRy8E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6MpWhUCYAAwfAj.jpg",
      "id_str" : "550329046345605120",
      "id" : 550329046345605120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6MpWhUCYAAwfAj.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rSXVuMRy8E"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/c84BftixkB",
      "expanded_url" : "http:\/\/go.wh.gov\/ptyb8N",
      "display_url" : "go.wh.gov\/ptyb8N"
    } ]
  },
  "geo" : { },
  "id_str" : "550329410587754496",
  "text" : "Tiaras.\nPresident Obama.\n#WomenInSTEM.\nHere are 9 ways we geeked out in 2014 \u2192 http:\/\/t.co\/c84BftixkB http:\/\/t.co\/rSXVuMRy8E",
  "id" : 550329410587754496,
  "created_at" : "2014-12-31 16:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/550322403835142146\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/vzDdz1YTjK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6MjTp1IgAEUaWR.jpg",
      "id_str" : "550322400022528001",
      "id" : 550322400022528001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6MjTp1IgAEUaWR.jpg",
      "sizes" : [ {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vzDdz1YTjK"
    } ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550324020810625025",
  "text" : "RT @Interior: Here's an amazing display of the northern lights over Kodiak Natl Wildlife Refuge in #Alaska. http:\/\/t.co\/vzDdz1YTjK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/550322403835142146\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/vzDdz1YTjK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6MjTp1IgAEUaWR.jpg",
        "id_str" : "550322400022528001",
        "id" : 550322400022528001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6MjTp1IgAEUaWR.jpg",
        "sizes" : [ {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vzDdz1YTjK"
      } ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "550322403835142146",
    "text" : "Here's an amazing display of the northern lights over Kodiak Natl Wildlife Refuge in #Alaska. http:\/\/t.co\/vzDdz1YTjK",
    "id" : 550322403835142146,
    "created_at" : "2014-12-31 16:07:40 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 550324020810625025,
  "created_at" : "2014-12-31 16:14:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ppzuGtBkzO",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "550319153274716161",
  "text" : "Our businesses added 2.65 million jobs in the first 11 months of 2014 \u2192 http:\/\/t.co\/ppzuGtBkzO http:\/\/t.co\/PfRpRQmFS2",
  "id" : 550319153274716161,
  "created_at" : "2014-12-31 15:54:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/FWWmfKGaPN",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TpLlDzBEko",
      "expanded_url" : "http:\/\/go.wh.gov\/GpoTt7",
      "display_url" : "go.wh.gov\/GpoTt7"
    } ]
  },
  "geo" : { },
  "id_str" : "550057146168393728",
  "text" : "Thanks to the ACA, 6.5 million Americans have signed up for or renewed 2015 coverage on http:\/\/t.co\/FWWmfKGaPN alone: http:\/\/t.co\/TpLlDzBEko",
  "id" : 550057146168393728,
  "created_at" : "2014-12-30 22:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546002141962186752\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/aMORbS4OEj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PFEh1CEAA0bgY.jpg",
      "id_str" : "545996661432913920",
      "id" : 545996661432913920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PFEh1CEAA0bgY.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/aMORbS4OEj"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "550003479993782272",
  "text" : "America's uninsured rate hit a near-record low in 2014 \u2192 http:\/\/t.co\/ov04rn5OgS #ACAWorks http:\/\/t.co\/aMORbS4OEj",
  "id" : 550003479993782272,
  "created_at" : "2014-12-30 19:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/547155543001792512\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AROcpiRnhl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5fjASBCYAAvPN9.jpg",
      "id_str" : "547155473724497920",
      "id" : 547155473724497920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5fjASBCYAAvPN9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AROcpiRnhl"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549988412208340992",
  "text" : "In 2014, President Obama took the most important step to date by the U.S. to #ActOnClimate \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/AROcpiRnhl",
  "id" : 549988412208340992,
  "created_at" : "2014-12-30 18:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549965688572366848",
  "text" : "2014 in review: President Obama became the first President to write a line of code \u2192 http:\/\/t.co\/ov04rn5OgS",
  "id" : 549965688572366848,
  "created_at" : "2014-12-30 16:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547095936107675648\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/mJ3abhSgSB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5es2JCCYAA1J9c.jpg",
      "id_str" : "547095925886181376",
      "id" : 547095925886181376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5es2JCCYAA1J9c.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mJ3abhSgSB"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549950575836545025",
  "text" : "FACT: 2014 saw the largest health coverage gains in four decades \u2192 http:\/\/t.co\/ov04rn5OgS #ACAWorks #GetCovered http:\/\/t.co\/mJ3abhSgSB",
  "id" : 549950575836545025,
  "created_at" : "2014-12-30 15:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549935467081113601",
  "text" : "America\u2019s businesses added 10.9 million jobs over 57 straight months of job growth \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/PfRpRQmFS2",
  "id" : 549935467081113601,
  "created_at" : "2014-12-30 14:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549716565394874368",
  "text" : "Our businesses added 2.65 million jobs in the first 11 months of 2014 \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/PfRpRQmFS2",
  "id" : 549716565394874368,
  "created_at" : "2014-12-30 00:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540557923886596096\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/OfPEx9V6RC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ByjGZCUAAYFZF.jpg",
      "id_str" : "540557902621069312",
      "id" : 540557902621069312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ByjGZCUAAYFZF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OfPEx9V6RC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549693949044989952",
  "text" : "2014 in review: America's high school graduation rate is the highest it's ever been \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/OfPEx9V6RC",
  "id" : 549693949044989952,
  "created_at" : "2014-12-29 22:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549676247307935744",
  "text" : "2014 in review: President Obama's bringing our longest war to a responsible end in Afghanistan \u2192 http:\/\/t.co\/ov04rn5OgS",
  "id" : 549676247307935744,
  "created_at" : "2014-12-29 21:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 42, 46 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/531819820028018688\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ifCoS1ty8j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2FnQmJCcAE_e8X.jpg",
      "id_str" : "531819765820452865",
      "id" : 531819765820452865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2FnQmJCcAE_e8X.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ifCoS1ty8j"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549666218966151170",
  "text" : "2014 in review: President Obama urged the @FCC to keep the internet open and free \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/ifCoS1ty8j",
  "id" : 549666218966151170,
  "created_at" : "2014-12-29 20:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542421655134273536\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KjBC3F3Qzv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cRh9ACMAAuHt5.jpg",
      "id_str" : "542421555129495552",
      "id" : 542421555129495552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cRh9ACMAAuHt5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KjBC3F3Qzv"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549656235608264704",
  "text" : "President Obama took steps to fix our broken immigration system in 2014 \u2192 http:\/\/t.co\/ov04rn5OgS #ImmigrationAction http:\/\/t.co\/KjBC3F3Qzv",
  "id" : 549656235608264704,
  "created_at" : "2014-12-29 20:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547155543001792512\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/AROcpiRnhl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5fjASBCYAAvPN9.jpg",
      "id_str" : "547155473724497920",
      "id" : 547155473724497920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5fjASBCYAAvPN9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AROcpiRnhl"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549648611147919360",
  "text" : "President Obama took historic steps to cut carbon pollution and #ActOnClimate in 2014 \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/AROcpiRnhl",
  "id" : 549648611147919360,
  "created_at" : "2014-12-29 19:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547095936107675648\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mJ3abhSgSB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5es2JCCYAA1J9c.jpg",
      "id_str" : "547095925886181376",
      "id" : 547095925886181376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5es2JCCYAA1J9c.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mJ3abhSgSB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549638508688576513",
  "text" : "Thanks to the Affordable Care Act, about 10 million Americans gained health coverage in 2014 \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/mJ3abhSgSB",
  "id" : 549638508688576513,
  "created_at" : "2014-12-29 18:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ov04rn5OgS",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549630997621260288",
  "text" : "FACT: 2014 was the strongest year of job growth since the 1990s \u2192 http:\/\/t.co\/ov04rn5OgS http:\/\/t.co\/PfRpRQmFS2",
  "id" : 549630997621260288,
  "created_at" : "2014-12-29 18:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ppzuGtBkzO",
      "expanded_url" : "http:\/\/go.wh.gov\/year-in-review",
      "display_url" : "go.wh.gov\/year-in-review"
    } ]
  },
  "geo" : { },
  "id_str" : "549624635680358400",
  "text" : "America made a lot of progress this year. Check out the highlights from 2014 \u2192 http:\/\/t.co\/ppzuGtBkzO http:\/\/t.co\/PfRpRQmFS2",
  "id" : 549624635680358400,
  "created_at" : "2014-12-29 17:54:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/549285969128861698\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/0nNdyMZzDJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B590oC0CQAAs2EZ.png",
      "id_str" : "549285910861201408",
      "id" : 549285910861201408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B590oC0CQAAs2EZ.png",
      "sizes" : [ {
        "h" : 606,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0nNdyMZzDJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549365856585924608",
  "text" : "\"We enter a new year with new confidence, indebted to our fellow Americans in uniform who keep us safe &amp; free\" \u2014Obama http:\/\/t.co\/0nNdyMZzDJ",
  "id" : 549365856585924608,
  "created_at" : "2014-12-29 00:46:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549301707919065088",
  "text" : "\"Compared to the nearly 180,000 American troops in Iraq and Afghanistan when I took office, we now have fewer than 15,000\" \u2014President Obama",
  "id" : 549301707919065088,
  "created_at" : "2014-12-28 20:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/549285969128861698\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/0nNdyMZzDJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B590oC0CQAAs2EZ.png",
      "id_str" : "549285910861201408",
      "id" : 549285910861201408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B590oC0CQAAs2EZ.png",
      "sizes" : [ {
        "h" : 606,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0nNdyMZzDJ"
    } ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549290893187223552",
  "text" : "\"The longest war in American history is coming to a responsible conclusion.\" \u2014President Obama #Afghanistan http:\/\/t.co\/0nNdyMZzDJ",
  "id" : 549290893187223552,
  "created_at" : "2014-12-28 19:48:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/549285969128861698\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0nNdyMZzDJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B590oC0CQAAs2EZ.png",
      "id_str" : "549285910861201408",
      "id" : 549285910861201408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B590oC0CQAAs2EZ.png",
      "sizes" : [ {
        "h" : 606,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0nNdyMZzDJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549285969128861698",
  "text" : "\"Thanks to the extraordinary sacrifices of our men and women in uniform, our combat mission in Afghanistan is ending\" http:\/\/t.co\/0nNdyMZzDJ",
  "id" : 549285969128861698,
  "created_at" : "2014-12-28 19:29:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 30, 46 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549277865024700416",
  "text" : "RT @lacasablanca: Congrats to @SecretaryCastro and his wife Erica for the birth of their beautiful son Cristi\u00E1n Juli\u00E1n Castro! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juli\u00E1n Castro",
        "screen_name" : "SecretaryCastro",
        "indices" : [ 12, 28 ],
        "id_str" : "2695663285",
        "id" : 2695663285
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryCastro\/status\/549025256602882048\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/xBWNGgSUYu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B56Hj9vIQAAZxwI.jpg",
        "id_str" : "549025256523186176",
        "id" : 549025256523186176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B56Hj9vIQAAZxwI.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/xBWNGgSUYu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "549277765179297794",
    "text" : "Congrats to @SecretaryCastro and his wife Erica for the birth of their beautiful son Cristi\u00E1n Juli\u00E1n Castro! http:\/\/t.co\/xBWNGgSUYu",
    "id" : 549277765179297794,
    "created_at" : "2014-12-28 18:56:38 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 549277865024700416,
  "created_at" : "2014-12-28 18:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548921319627423744",
  "text" : "RT @VP: \"I speak for the whole nation when I say our hearts ache for you.\" -VP Biden to the family of Officer Rafael Ramos http:\/\/t.co\/Ohd1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/548863327360004097\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Ohd1lzFvYc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B530SaQCIAEsQRP.png",
        "id_str" : "548863326730461185",
        "id" : 548863326730461185,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B530SaQCIAEsQRP.png",
        "sizes" : [ {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 832
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 832
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ohd1lzFvYc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "548863327360004097",
    "text" : "\"I speak for the whole nation when I say our hearts ache for you.\" -VP Biden to the family of Officer Rafael Ramos http:\/\/t.co\/Ohd1lzFvYc",
    "id" : 548863327360004097,
    "created_at" : "2014-12-27 15:29:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 548921319627423744,
  "created_at" : "2014-12-27 19:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/548575562856669184\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/O9cgkwmzKE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5zukDcCIAA0Pvn.jpg",
      "id_str" : "548575557797945344",
      "id" : 548575557797945344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5zukDcCIAA0Pvn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O9cgkwmzKE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/b1xzCYDNWH",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/12\/23\/year-review-top-ten-moments-vice-president-biden",
      "display_url" : "whitehouse.gov\/blog\/2014\/12\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "548577158684504065",
  "text" : "RT @VP: From selfies to Being Biden, check out some of the best digital moments of 2014 \u2192 http:\/\/t.co\/b1xzCYDNWH http:\/\/t.co\/O9cgkwmzKE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/548575562856669184\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/O9cgkwmzKE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5zukDcCIAA0Pvn.jpg",
        "id_str" : "548575557797945344",
        "id" : 548575557797945344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5zukDcCIAA0Pvn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/O9cgkwmzKE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/b1xzCYDNWH",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/12\/23\/year-review-top-ten-moments-vice-president-biden",
        "display_url" : "whitehouse.gov\/blog\/2014\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "548575562856669184",
    "text" : "From selfies to Being Biden, check out some of the best digital moments of 2014 \u2192 http:\/\/t.co\/b1xzCYDNWH http:\/\/t.co\/O9cgkwmzKE",
    "id" : 548575562856669184,
    "created_at" : "2014-12-26 20:26:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 548577158684504065,
  "created_at" : "2014-12-26 20:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/548544430954008576\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/obYCxUWwVG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5zSNB_CUAAI_Ta.png",
      "id_str" : "548544375945318400",
      "id" : 548544375945318400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5zSNB_CUAAI_Ta.png",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 797
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 797
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/obYCxUWwVG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548544430954008576",
  "text" : "\u201CMichelle and I extend our warmest wishes to those celebrating Kwanzaa.\u201D \u2014President Obama http:\/\/t.co\/obYCxUWwVG",
  "id" : 548544430954008576,
  "created_at" : "2014-12-26 18:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418245818295271424\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/dXoh9AHSka",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc3oWwgIQAAVG68.jpg",
      "id_str" : "418245818089750528",
      "id" : 418245818089750528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc3oWwgIQAAVG68.jpg",
      "sizes" : [ {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dXoh9AHSka"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/WBLXS5YV1J",
      "expanded_url" : "http:\/\/go.wh.gov\/RVnmqp",
      "display_url" : "go.wh.gov\/RVnmqp"
    } ]
  },
  "geo" : { },
  "id_str" : "548531215058632705",
  "text" : "2014 in review: Check out our top tweets of the year \u2192 http:\/\/t.co\/WBLXS5YV1J http:\/\/t.co\/dXoh9AHSka",
  "id" : 548531215058632705,
  "created_at" : "2014-12-26 17:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MerryChristmas",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/DnWhPTtXUA",
      "expanded_url" : "http:\/\/go.wh.gov\/y4DgKx",
      "display_url" : "go.wh.gov\/y4DgKx"
    } ]
  },
  "geo" : { },
  "id_str" : "548282056992497664",
  "text" : "\"We wish you and your family a happy and healthy 2015.\" \u2014President Obama: http:\/\/t.co\/DnWhPTtXUA #MerryChristmas",
  "id" : 548282056992497664,
  "created_at" : "2014-12-26 01:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/548257795645378560\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/SK5EQjtYXi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5vNhmpCcAAmlW0.jpg",
      "id_str" : "548257756847697920",
      "id" : 548257756847697920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5vNhmpCcAAmlW0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SK5EQjtYXi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548257795645378560",
  "text" : "Merry Christmas! http:\/\/t.co\/SK5EQjtYXi",
  "id" : 548257795645378560,
  "created_at" : "2014-12-25 23:23:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/i3BJMMofoj",
      "expanded_url" : "http:\/\/JoiningForces.gov",
      "display_url" : "JoiningForces.gov"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/DnWhPTtXUA",
      "expanded_url" : "http:\/\/go.wh.gov\/y4DgKx",
      "display_url" : "go.wh.gov\/y4DgKx"
    } ]
  },
  "geo" : { },
  "id_str" : "548199019537633281",
  "text" : "\"You can visit http:\/\/t.co\/i3BJMMofoj to find out how you can honor and support the troops.\" \u2014President Obama: http:\/\/t.co\/DnWhPTtXUA",
  "id" : 548199019537633281,
  "created_at" : "2014-12-25 19:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 26, 33 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MerryChristmas",
      "indices" : [ 51, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/DnWhPTtXUA",
      "expanded_url" : "http:\/\/go.wh.gov\/y4DgKx",
      "display_url" : "go.wh.gov\/y4DgKx"
    } ]
  },
  "geo" : { },
  "id_str" : "548176383306784768",
  "text" : "Watch President Obama and @FLOTUS wish Americans a #MerryChristmas \u2192 http:\/\/t.co\/DnWhPTtXUA",
  "id" : 548176383306784768,
  "created_at" : "2014-12-25 18:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 70, 77 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MerryChristmas",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/DnWhPTtXUA",
      "expanded_url" : "http:\/\/go.wh.gov\/y4DgKx",
      "display_url" : "go.wh.gov\/y4DgKx"
    } ]
  },
  "geo" : { },
  "id_str" : "548153768701726722",
  "text" : "\"It\u2019s up to all of us to serve them as well as they have served us.\" \u2014@FLOTUS on honoring our troops: http:\/\/t.co\/DnWhPTtXUA #MerryChristmas",
  "id" : 548153768701726722,
  "created_at" : "2014-12-25 16:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MerryChristmas",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/DnWhPTtXUA",
      "expanded_url" : "http:\/\/go.wh.gov\/y4DgKx",
      "display_url" : "go.wh.gov\/y4DgKx"
    } ]
  },
  "geo" : { },
  "id_str" : "548138669492547584",
  "text" : "\"Today is about family and being together with the ones you love.\" \u2014President Obama: http:\/\/t.co\/DnWhPTtXUA #MerryChristmas",
  "id" : 548138669492547584,
  "created_at" : "2014-12-25 15:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 50, 57 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DnWhPTtXUA",
      "expanded_url" : "http:\/\/go.wh.gov\/y4DgKx",
      "display_url" : "go.wh.gov\/y4DgKx"
    } ]
  },
  "geo" : { },
  "id_str" : "548116032502525954",
  "text" : "\"Merry Christmas everybody!\" \u2014President Obama and @FLOTUS in the weekly address: http:\/\/t.co\/DnWhPTtXUA",
  "id" : 548116032502525954,
  "created_at" : "2014-12-25 14:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/drkgln74ry",
      "expanded_url" : "http:\/\/noradsanta.org",
      "display_url" : "noradsanta.org"
    } ]
  },
  "geo" : { },
  "id_str" : "547950993435287552",
  "text" : "RT @FLOTUS: The First Lady and NORAD are helping to track Santa's sleigh. Follow along with them \u2192 http:\/\/t.co\/drkgln74ry http:\/\/t.co\/nR62B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/547950831405117441\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/nR62BIriAk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5q2NY1CMAAgWJT.jpg",
        "id_str" : "547950645798383616",
        "id" : 547950645798383616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5q2NY1CMAAgWJT.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/nR62BIriAk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/drkgln74ry",
        "expanded_url" : "http:\/\/noradsanta.org",
        "display_url" : "noradsanta.org"
      } ]
    },
    "geo" : { },
    "id_str" : "547950831405117441",
    "text" : "The First Lady and NORAD are helping to track Santa's sleigh. Follow along with them \u2192 http:\/\/t.co\/drkgln74ry http:\/\/t.co\/nR62BIriAk",
    "id" : 547950831405117441,
    "created_at" : "2014-12-25 03:03:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 547950993435287552,
  "created_at" : "2014-12-25 03:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "BeringLandBridgeNP",
      "screen_name" : "BeringLandNPS",
      "indices" : [ 82, 96 ],
      "id_str" : "65670121",
      "id" : 65670121
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/547885676382126082\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/4uopspdIID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5p7HVWCIAIyguN.jpg",
      "id_str" : "547885670597795842",
      "id" : 547885670597795842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5p7HVWCIAIyguN.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4uopspdIID"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547885979101855745",
  "text" : "RT @Interior: Looks like the reindeer are getting ready for the big ride tonight! @BeringLandNPS http:\/\/t.co\/4uopspdIID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BeringLandBridgeNP",
        "screen_name" : "BeringLandNPS",
        "indices" : [ 68, 82 ],
        "id_str" : "65670121",
        "id" : 65670121
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/547885676382126082\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/4uopspdIID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5p7HVWCIAIyguN.jpg",
        "id_str" : "547885670597795842",
        "id" : 547885670597795842,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5p7HVWCIAIyguN.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4uopspdIID"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "547885676382126082",
    "text" : "Looks like the reindeer are getting ready for the big ride tonight! @BeringLandNPS http:\/\/t.co\/4uopspdIID",
    "id" : 547885676382126082,
    "created_at" : "2014-12-24 22:44:59 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 547885979101855745,
  "created_at" : "2014-12-24 22:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "NORAD Santa",
      "screen_name" : "NoradSanta",
      "indices" : [ 92, 103 ],
      "id_str" : "16460682",
      "id" : 16460682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Santa",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wn7zyRwf4X",
      "expanded_url" : "http:\/\/noradsanta.org",
      "display_url" : "noradsanta.org"
    } ]
  },
  "geo" : { },
  "id_str" : "547770299010527232",
  "text" : "RT @DeptofDefense: It begins! Follow #Santa as he makes his way around the world, using the @NoradSanta Tracker at http:\/\/t.co\/wn7zyRwf4X.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NORAD Santa",
        "screen_name" : "NoradSanta",
        "indices" : [ 73, 84 ],
        "id_str" : "16460682",
        "id" : 16460682
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Santa",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/wn7zyRwf4X",
        "expanded_url" : "http:\/\/noradsanta.org",
        "display_url" : "noradsanta.org"
      } ]
    },
    "geo" : { },
    "id_str" : "547722189177647104",
    "text" : "It begins! Follow #Santa as he makes his way around the world, using the @NoradSanta Tracker at http:\/\/t.co\/wn7zyRwf4X.",
    "id" : 547722189177647104,
    "created_at" : "2014-12-24 11:55:20 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 547770299010527232,
  "created_at" : "2014-12-24 15:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 104, 118 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547527617445109760",
  "text" : "RT @FLOTUS: Progress to end veteran homelessness \u2713\nVeteran Employment Center launched \u2713\nRecap 2014 from @JoiningForces: http:\/\/t.co\/3HlKjh6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 92, 106 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/3HlKjh6DD6",
        "expanded_url" : "http:\/\/go.wh.gov\/xmc87d",
        "display_url" : "go.wh.gov\/xmc87d"
      } ]
    },
    "geo" : { },
    "id_str" : "547514998973812736",
    "text" : "Progress to end veteran homelessness \u2713\nVeteran Employment Center launched \u2713\nRecap 2014 from @JoiningForces: http:\/\/t.co\/3HlKjh6DD6",
    "id" : 547514998973812736,
    "created_at" : "2014-12-23 22:12:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 547527617445109760,
  "created_at" : "2014-12-23 23:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547464603136196609\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b2E3cr45V0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5j79SdCQAAAcK_.jpg",
      "id_str" : "547464385069727744",
      "id" : 547464385069727744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5j79SdCQAAAcK_.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/b2E3cr45V0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/whKbGHr7EU",
      "expanded_url" : "http:\/\/go.wh.gov\/ozS2e1",
      "display_url" : "go.wh.gov\/ozS2e1"
    } ]
  },
  "geo" : { },
  "id_str" : "547464603136196609",
  "text" : "Good news: Our economy is growing at the fastest pace in 11 years \u2192 http:\/\/t.co\/whKbGHr7EU http:\/\/t.co\/b2E3cr45V0",
  "id" : 547464603136196609,
  "created_at" : "2014-12-23 18:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dzNDiwwIu7",
      "expanded_url" : "http:\/\/go.wh.gov\/CxgMbq",
      "display_url" : "go.wh.gov\/CxgMbq"
    } ]
  },
  "geo" : { },
  "id_str" : "547456026799534084",
  "text" : "Thanks to the Affordable Care Act, nearly 6.4 million Americans have already signed up for or renewed 2015 coverage: http:\/\/t.co\/dzNDiwwIu7",
  "id" : 547456026799534084,
  "created_at" : "2014-12-23 18:17:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547433337066098689\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/neMAb4ZXli",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5jfjGkCUAA3PxS.jpg",
      "id_str" : "547433148875689984",
      "id" : 547433148875689984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5jfjGkCUAA3PxS.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/neMAb4ZXli"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/whKbGHr7EU",
      "expanded_url" : "http:\/\/go.wh.gov\/ozS2e1",
      "display_url" : "go.wh.gov\/ozS2e1"
    } ]
  },
  "geo" : { },
  "id_str" : "547433337066098689",
  "text" : "Wages: \u2191\nGDP: \u2191\nConsumer spending: \u2191\nBusiness investment: \u2191\nhttp:\/\/t.co\/whKbGHr7EU http:\/\/t.co\/neMAb4ZXli",
  "id" : 547433337066098689,
  "created_at" : "2014-12-23 16:47:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/y1qiXkBvGw",
      "expanded_url" : "http:\/\/go.wh.gov\/ozS2e1",
      "display_url" : "go.wh.gov\/ozS2e1"
    } ]
  },
  "geo" : { },
  "id_str" : "547422632434753538",
  "text" : "RT @VP: FACT: Our economy grew at a 5% rate last quarter\u2014the strongest quarter of growth since 2003 \u2192 http:\/\/t.co\/y1qiXkBvGw http:\/\/t.co\/Bj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/547421579433754624\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BjEZOAb7fO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5jVBiNIIAALH8s.jpg",
        "id_str" : "547421577063964672",
        "id" : 547421577063964672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5jVBiNIIAALH8s.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/BjEZOAb7fO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/y1qiXkBvGw",
        "expanded_url" : "http:\/\/go.wh.gov\/ozS2e1",
        "display_url" : "go.wh.gov\/ozS2e1"
      } ]
    },
    "geo" : { },
    "id_str" : "547421579433754624",
    "text" : "FACT: Our economy grew at a 5% rate last quarter\u2014the strongest quarter of growth since 2003 \u2192 http:\/\/t.co\/y1qiXkBvGw http:\/\/t.co\/BjEZOAb7fO",
    "id" : 547421579433754624,
    "created_at" : "2014-12-23 16:00:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 547422632434753538,
  "created_at" : "2014-12-23 16:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547417121668726784\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/JUSWHVhHED",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5jQ3SVCQAA1lN1.jpg",
      "id_str" : "547417002956963840",
      "id" : 547417002956963840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5jQ3SVCQAA1lN1.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/JUSWHVhHED"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/whKbGHr7EU",
      "expanded_url" : "http:\/\/go.wh.gov\/ozS2e1",
      "display_url" : "go.wh.gov\/ozS2e1"
    } ]
  },
  "geo" : { },
  "id_str" : "547417121668726784",
  "text" : "RT to spread the word: Our economy is growing at the fastest pace in 11 years \u2192 http:\/\/t.co\/whKbGHr7EU http:\/\/t.co\/JUSWHVhHED",
  "id" : 547417121668726784,
  "created_at" : "2014-12-23 15:43:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/p04OEsoz5x",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/12\/23\/third-estimate-gdp-third-quarter-2014",
      "display_url" : "whitehouse.gov\/blog\/2014\/12\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "547403381573419009",
  "text" : "RT @CEAChair: Real GDP grew 5.0% at an annual rate in Q3\u2014the strongest single quarter since 2003 http:\/\/t.co\/p04OEsoz5x http:\/\/t.co\/g9Rj9Xt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/547403306012643329\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/g9Rj9XtMbe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5jEZ-DCQAAZCk5.jpg",
        "id_str" : "547403305157017600",
        "id" : 547403305157017600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5jEZ-DCQAAZCk5.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/g9Rj9XtMbe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/p04OEsoz5x",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/12\/23\/third-estimate-gdp-third-quarter-2014",
        "display_url" : "whitehouse.gov\/blog\/2014\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "547403306012643329",
    "text" : "Real GDP grew 5.0% at an annual rate in Q3\u2014the strongest single quarter since 2003 http:\/\/t.co\/p04OEsoz5x http:\/\/t.co\/g9Rj9XtMbe",
    "id" : 547403306012643329,
    "created_at" : "2014-12-23 14:48:13 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 547403381573419009,
  "created_at" : "2014-12-23 14:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/542421655134273536\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KjBC3F3Qzv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cRh9ACMAAuHt5.jpg",
      "id_str" : "542421555129495552",
      "id" : 542421555129495552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cRh9ACMAAuHt5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KjBC3F3Qzv"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 57, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/5C5RpbojZu",
      "expanded_url" : "http:\/\/go.wh.gov\/tfhJYb",
      "display_url" : "go.wh.gov\/tfhJYb"
    } ]
  },
  "geo" : { },
  "id_str" : "547172010707546115",
  "text" : "2014 in review: President Obama took the most meaningful #ImmigrationAction in decades \u2192 http:\/\/t.co\/5C5RpbojZu http:\/\/t.co\/KjBC3F3Qzv",
  "id" : 547172010707546115,
  "created_at" : "2014-12-22 23:29:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547155543001792512\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AROcpiRnhl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5fjASBCYAAvPN9.jpg",
      "id_str" : "547155473724497920",
      "id" : 547155473724497920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5fjASBCYAAvPN9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AROcpiRnhl"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5C5RpbojZu",
      "expanded_url" : "http:\/\/go.wh.gov\/tfhJYb",
      "display_url" : "go.wh.gov\/tfhJYb"
    } ]
  },
  "geo" : { },
  "id_str" : "547155543001792512",
  "text" : "In 2014, President Obama took the most important step to date by the U.S. to #ActOnClimate \u2192 http:\/\/t.co\/5C5RpbojZu http:\/\/t.co\/AROcpiRnhl",
  "id" : 547155543001792512,
  "created_at" : "2014-12-22 22:23:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/TQKuRI6UKo",
      "expanded_url" : "http:\/\/go.wh.gov\/tfhJYb",
      "display_url" : "go.wh.gov\/tfhJYb"
    } ]
  },
  "geo" : { },
  "id_str" : "547143666561982464",
  "text" : "President Obama took more than 80 executive actions this year. Here's a recap of the progress we made in 2014: http:\/\/t.co\/TQKuRI6UKo",
  "id" : 547143666561982464,
  "created_at" : "2014-12-22 21:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 46, 52 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/QuWmX1RJp1",
      "expanded_url" : "http:\/\/bzfd.it\/13aAnC3",
      "display_url" : "bzfd.it\/13aAnC3"
    } ]
  },
  "geo" : { },
  "id_str" : "547119296745205760",
  "text" : "Going home for the holidays? Here are 10 ways @USDOT is making holiday travel safer and easier \u2192 http:\/\/t.co\/QuWmX1RJp1",
  "id" : 547119296745205760,
  "created_at" : "2014-12-22 19:59:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 13, 26 ]
    }, {
      "text" : "ImmigrationAction",
      "indices" : [ 29, 47 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5C5RpbojZu",
      "expanded_url" : "http:\/\/go.wh.gov\/tfhJYb",
      "display_url" : "go.wh.gov\/tfhJYb"
    } ]
  },
  "geo" : { },
  "id_str" : "547114266206023680",
  "text" : "Big steps to #ActOnClimate \u2713\n#ImmigrationAction \u2713\nProgress to #RaiseTheWage \u2713\nRecap President Obama's year of action: http:\/\/t.co\/5C5RpbojZu",
  "id" : 547114266206023680,
  "created_at" : "2014-12-22 19:39:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547095936107675648\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mJ3abhSgSB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5es2JCCYAA1J9c.jpg",
      "id_str" : "547095925886181376",
      "id" : 547095925886181376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5es2JCCYAA1J9c.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mJ3abhSgSB"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/uUmvf5pXup",
      "expanded_url" : "http:\/\/go.wh.gov\/gFTRyr",
      "display_url" : "go.wh.gov\/gFTRyr"
    } ]
  },
  "geo" : { },
  "id_str" : "547095936107675648",
  "text" : "FACT: 2014 has seen the largest health coverage gains in four decades \u2192 http:\/\/t.co\/uUmvf5pXup #ACAWorks #GetCovered http:\/\/t.co\/mJ3abhSgSB",
  "id" : 547095936107675648,
  "created_at" : "2014-12-22 18:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/547076714438721536\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/quV3Ny6zio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5ebTZUCcAAbgL1.jpg",
      "id_str" : "547076637263556608",
      "id" : 547076637263556608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5ebTZUCcAAbgL1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/quV3Ny6zio"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/d9wUpV2aTT",
      "expanded_url" : "http:\/\/go.wh.gov\/RpCCXj",
      "display_url" : "go.wh.gov\/RpCCXj"
    } ]
  },
  "geo" : { },
  "id_str" : "547076714438721536",
  "text" : "President Obama's taking new steps to reestablish diplomatic relations with Cuba: http:\/\/t.co\/d9wUpV2aTT #CubaPolicy http:\/\/t.co\/quV3Ny6zio",
  "id" : 547076714438721536,
  "created_at" : "2014-12-22 17:10:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/AbFZgv7L41",
      "expanded_url" : "http:\/\/youtu.be\/gH9mXrB2sWA",
      "display_url" : "youtu.be\/gH9mXrB2sWA"
    } ]
  },
  "geo" : { },
  "id_str" : "547061673799192578",
  "text" : "President Obama is protecting Alaska's Bristol Bay, which helps to produce 40% of America's wild-caught seafood: http:\/\/t.co\/AbFZgv7L41",
  "id" : 547061673799192578,
  "created_at" : "2014-12-22 16:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/TBaxNAtUK9",
      "expanded_url" : "http:\/\/on.doi.gov\/1GNfmuq",
      "display_url" : "on.doi.gov\/1GNfmuq"
    } ]
  },
  "geo" : { },
  "id_str" : "546873511655247872",
  "text" : "RT @Interior: Our most popular pic last week is of Bristol Bay. Learn how Pres. Obama is protecting it: http:\/\/t.co\/TBaxNAtUK9 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/546791525783707648\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ToJAsTDfPK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5aX_W5CUAEpHLX.jpg",
        "id_str" : "546791519504453633",
        "id" : 546791519504453633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5aX_W5CUAEpHLX.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1023
        } ],
        "display_url" : "pic.twitter.com\/ToJAsTDfPK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/TBaxNAtUK9",
        "expanded_url" : "http:\/\/on.doi.gov\/1GNfmuq",
        "display_url" : "on.doi.gov\/1GNfmuq"
      } ]
    },
    "geo" : { },
    "id_str" : "546791525783707648",
    "text" : "Our most popular pic last week is of Bristol Bay. Learn how Pres. Obama is protecting it: http:\/\/t.co\/TBaxNAtUK9 http:\/\/t.co\/ToJAsTDfPK",
    "id" : 546791525783707648,
    "created_at" : "2014-12-21 22:17:13 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 546873511655247872,
  "created_at" : "2014-12-22 03:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546772128721162240",
  "text" : "\"In less than two weeks, after more than 13 years, our combat mission in Afghanistan will be over.\" \u2014President Obama: http:\/\/t.co\/taHPUO34e9",
  "id" : 546772128721162240,
  "created_at" : "2014-12-21 21:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/546016255644139520\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KcNadYQ98d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PW4i7CIAATkiI.jpg",
      "id_str" : "546016246777389056",
      "id" : 546016246777389056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PW4i7CIAATkiI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KcNadYQ98d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546741984769998849",
  "text" : "\"Since I took office, we have cut our deficits by about two-thirds.\" \u2014President Obama: http:\/\/t.co\/taHPUO34e9 http:\/\/t.co\/KcNadYQ98d",
  "id" : 546741984769998849,
  "created_at" : "2014-12-21 19:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546711802050928642",
  "text" : "\"Thanks to the Affordable Care Act, about 10 million Americans have gained health insurance in the past year\" \u2014Obama: http:\/\/t.co\/taHPUO34e9",
  "id" : 546711802050928642,
  "created_at" : "2014-12-21 17:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546553525875253248\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/NAeTxpV70U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5W_YMaCIAARNjU.png",
      "id_str" : "546553352163565568",
      "id" : 546553352163565568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5W_YMaCIAARNjU.png",
      "sizes" : [ {
        "h" : 112,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 755
      } ],
      "display_url" : "pic.twitter.com\/NAeTxpV70U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546553525875253248",
  "text" : "\"I unconditionally condemn today's murder of two police officers in New York City.\" \u2014President Obama: http:\/\/t.co\/NAeTxpV70U",
  "id" : 546553525875253248,
  "created_at" : "2014-12-21 06:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546455048104853504",
  "text" : "\"The auto industry we rescued is on track for its strongest year since 2005.\" \u2014President Obama: http:\/\/t.co\/taHPUO34e9",
  "id" : 546455048104853504,
  "created_at" : "2014-12-21 00:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546428633540071425",
  "text" : "\"Our investments in American manufacturing have helped fuel its best stretch of job growth since the \u201890s.\" \u2014Obama: http:\/\/t.co\/taHPUO34e9",
  "id" : 546428633540071425,
  "created_at" : "2014-12-20 22:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 28, 39 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/3w3g3BdDzp",
      "expanded_url" : "http:\/\/go.wh.gov\/cL9uPn",
      "display_url" : "go.wh.gov\/cL9uPn"
    } ]
  },
  "geo" : { },
  "id_str" : "546417282813931522",
  "text" : "\"Worst\" year in Washington? @Pfeiffer44 breaks down why 2014 was a year of progress for America \u2192 http:\/\/t.co\/3w3g3BdDzp",
  "id" : 546417282813931522,
  "created_at" : "2014-12-20 21:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546405975171661824",
  "text" : "\"In a hopeful sign for middle-class families, wages are on the rise again.\" \u2014President Obama in his weekly address: http:\/\/t.co\/taHPUO34e9",
  "id" : 546405975171661824,
  "created_at" : "2014-12-20 20:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/taHPUO34e9",
      "expanded_url" : "http:\/\/go.wh.gov\/fpSfmf",
      "display_url" : "go.wh.gov\/fpSfmf"
    } ]
  },
  "geo" : { },
  "id_str" : "546372752609800195",
  "text" : "\"Over the past 57 months, our businesses have created nearly 11 million new jobs.\" \u2014Obama: http:\/\/t.co\/taHPUO34e9 http:\/\/t.co\/PfRpRQmFS2",
  "id" : 546372752609800195,
  "created_at" : "2014-12-20 18:33:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaPresser",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/BfknpECbzX",
      "expanded_url" : "http:\/\/snpy.tv\/1zdiGjd",
      "display_url" : "snpy.tv\/1zdiGjd"
    } ]
  },
  "geo" : { },
  "id_str" : "546048157612642304",
  "text" : "Watch President Obama break down why 2014 was a year of progress for America. #ObamaPresser http:\/\/t.co\/BfknpECbzX",
  "id" : 546048157612642304,
  "created_at" : "2014-12-19 21:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546028295356047361\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PfRpRQmFS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "id_str" : "546028192843059202",
      "id" : 546028192843059202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Phv5fCUAI2g8a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PfRpRQmFS2"
    } ],
    "hashtags" : [ {
      "text" : "ObamaPresser",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546028295356047361",
  "text" : "\u201CThrough persistent effort and faith in the American people\u2026the economy\u2019s gotten better.\u201D \u2014Obama #ObamaPresser http:\/\/t.co\/PfRpRQmFS2",
  "id" : 546028295356047361,
  "created_at" : "2014-12-19 19:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546021608201003008\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mrTGF5ziyt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PbfRdCIAAjNJa.jpg",
      "id_str" : "546021310149566464",
      "id" : 546021310149566464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PbfRdCIAAjNJa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mrTGF5ziyt"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546021608201003008",
  "text" : "\u201CThrough engagement we have a better chance of bringing about change than we would have otherwise\u201D \u2014Obama #CubaPolicy http:\/\/t.co\/mrTGF5ziyt",
  "id" : 546021608201003008,
  "created_at" : "2014-12-19 19:17:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FBI",
      "screen_name" : "FBI",
      "indices" : [ 5, 9 ],
      "id_str" : "17629860",
      "id" : 17629860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546019098438541312",
  "text" : "\u201CThe @FBI announced today and we can confirm that North Korea engaged in this attack.\u201D \u2014President Obama on Sony",
  "id" : 546019098438541312,
  "created_at" : "2014-12-19 19:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546018226400808961",
  "text" : "\"We cannot have a society in which some dictator someplace can start imposing censorship here in the United States.\" \u2014President Obama",
  "id" : 546018226400808961,
  "created_at" : "2014-12-19 19:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546017210683371520",
  "text" : "\"We have set the stage for this American moment, and I\u2019m going to spend every minute of my last two years making sure we seize it.\" \u2014Obama",
  "id" : 546017210683371520,
  "created_at" : "2014-12-19 19:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546016650080681984\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/zJdekwzX5c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PXMtjCMAAzqgL.jpg",
      "id_str" : "546016593226903552",
      "id" : 546016593226903552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PXMtjCMAAzqgL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zJdekwzX5c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546016650080681984",
  "text" : "\"Over the past four years, we\u2019ve put more people back to work than all other advanced economies combined.\" \u2014Obama http:\/\/t.co\/zJdekwzX5c",
  "id" : 546016650080681984,
  "created_at" : "2014-12-19 18:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546016500297912321",
  "text" : "RT @WHLive: \"In less than two weeks, after more than 13 years, our combat mission in Afghanistan will be over.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "546016481540972545",
    "text" : "\"In less than two weeks, after more than 13 years, our combat mission in Afghanistan will be over.\" \u2014President Obama",
    "id" : 546016481540972545,
    "created_at" : "2014-12-19 18:57:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 546016500297912321,
  "created_at" : "2014-12-19 18:57:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546016419960205314\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Xl5qZ5WrFy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PXCMjCQAAp-6n.jpg",
      "id_str" : "546016412569845760",
      "id" : 546016412569845760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PXCMjCQAAp-6n.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Xl5qZ5WrFy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546016419960205314",
  "text" : "\"We\u2019re leading global efforts to combat climate change, including last month\u2019s historic agreement with China\" \u2014Obama http:\/\/t.co\/Xl5qZ5WrFy",
  "id" : 546016419960205314,
  "created_at" : "2014-12-19 18:57:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/546016255644139520\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KcNadYQ98d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PW4i7CIAATkiI.jpg",
      "id_str" : "546016246777389056",
      "id" : 546016246777389056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PW4i7CIAATkiI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KcNadYQ98d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546016255644139520",
  "text" : "\"We\u2019ve cut our deficits by about two-thirds since I took office, bringing them below their 40-year average.\" \u2014Obama http:\/\/t.co\/KcNadYQ98d",
  "id" : 546016255644139520,
  "created_at" : "2014-12-19 18:56:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546016103239921666",
  "text" : "\"Thanks to the Affordable Care Act, about 10 million Americans have gained health insurance just this past year.\" \u2014Obama #ACAWorks",
  "id" : 546016103239921666,
  "created_at" : "2014-12-19 18:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546015969726844929",
  "text" : "\"Our investments in American manufacturing have helped fuel its best stretch of job growth since \u201890s.\" \u2014President Obama #MadeInAmerica",
  "id" : 546015969726844929,
  "created_at" : "2014-12-19 18:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546015815418404864\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/uewpXWPHU2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PWfM_CQAAZqdo.jpg",
      "id_str" : "546015811391864832",
      "id" : 546015811391864832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PWfM_CQAAZqdo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uewpXWPHU2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546015815418404864",
  "text" : "\"Over a 57-month streak, our businesses have created nearly 11 million new jobs.\" \u2014President Obama http:\/\/t.co\/uewpXWPHU2",
  "id" : 546015815418404864,
  "created_at" : "2014-12-19 18:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546015740524892160",
  "text" : "\"The steps we took early on to rescue our economy...helped make 2014 the strongest year for job growth since the 1990s.\" \u2014President Obama",
  "id" : 546015740524892160,
  "created_at" : "2014-12-19 18:54:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546015679233536001",
  "text" : "\"There is no doubt that we can enter the New Year with new confidence that America is making significant strides.\" \u2014President Obama",
  "id" : 546015679233536001,
  "created_at" : "2014-12-19 18:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0QXOcbVSTS",
      "expanded_url" : "http:\/\/go.wh.gov\/mLvefw",
      "display_url" : "go.wh.gov\/mLvefw"
    } ]
  },
  "geo" : { },
  "id_str" : "546015453508694017",
  "text" : "Happening now: President Obama holds a press conference from the White House. Watch \u2192 http:\/\/t.co\/0QXOcbVSTS",
  "id" : 546015453508694017,
  "created_at" : "2014-12-19 18:53:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/0QXOcbVSTS",
      "expanded_url" : "http:\/\/go.wh.gov\/mLvefw",
      "display_url" : "go.wh.gov\/mLvefw"
    } ]
  },
  "geo" : { },
  "id_str" : "546005366945742848",
  "text" : "Watch President Obama hold a press conference from the White House at 1:30pm ET \u2192 http:\/\/t.co\/0QXOcbVSTS",
  "id" : 546005366945742848,
  "created_at" : "2014-12-19 18:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/546002141962186752\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/aMORbS4OEj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PFEh1CEAA0bgY.jpg",
      "id_str" : "545996661432913920",
      "id" : 545996661432913920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PFEh1CEAA0bgY.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/aMORbS4OEj"
    } ],
    "hashtags" : [ {
      "text" : "2014In5Words",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/OUZUwTrh4l",
      "expanded_url" : "https:\/\/medium.com\/@pfeiffer44\/breaking-down-the-worst-year-in-washington-b3bb4ceeabf",
      "display_url" : "medium.com\/@pfeiffer44\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "546002141962186752",
  "text" : "#2014In5Words: Uninsured rate near record low \u2192 https:\/\/t.co\/OUZUwTrh4l #ACAWorks http:\/\/t.co\/aMORbS4OEj",
  "id" : 546002141962186752,
  "created_at" : "2014-12-19 18:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545994250513444864\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/bw1xLdcq27",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5PCyNNCUAA3RHC.jpg",
      "id_str" : "545994147635548160",
      "id" : 545994147635548160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5PCyNNCUAA3RHC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bw1xLdcq27"
    } ],
    "hashtags" : [ {
      "text" : "2014In5Words",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/OUZUwTrh4l",
      "expanded_url" : "https:\/\/medium.com\/@pfeiffer44\/breaking-down-the-worst-year-in-washington-b3bb4ceeabf",
      "display_url" : "medium.com\/@pfeiffer44\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545994250513444864",
  "text" : "10 million Americans gained coverage \u2192 https:\/\/t.co\/OUZUwTrh4l #2014In5Words http:\/\/t.co\/bw1xLdcq27",
  "id" : 545994250513444864,
  "created_at" : "2014-12-19 17:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545987728160985088\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Q1AEWOFYYU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5O8uUbCEAAWln9.jpg",
      "id_str" : "545987483784056832",
      "id" : 545987483784056832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5O8uUbCEAAWln9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q1AEWOFYYU"
    } ],
    "hashtags" : [ {
      "text" : "2014In5Words",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/OUZUwTrh4l",
      "expanded_url" : "https:\/\/medium.com\/@pfeiffer44\/breaking-down-the-worst-year-in-washington-b3bb4ceeabf",
      "display_url" : "medium.com\/@pfeiffer44\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545987728160985088",
  "text" : "\"A year of great progress.\" https:\/\/t.co\/OUZUwTrh4l #2014In5Words http:\/\/t.co\/Q1AEWOFYYU",
  "id" : 545987728160985088,
  "created_at" : "2014-12-19 17:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545972646995705856\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/DnE4SvEuDl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5OvMoGCIAAWQBZ.jpg",
      "id_str" : "545972611297976320",
      "id" : 545972611297976320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5OvMoGCIAAWQBZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DnE4SvEuDl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/OUZUwTrh4l",
      "expanded_url" : "https:\/\/medium.com\/@pfeiffer44\/breaking-down-the-worst-year-in-washington-b3bb4ceeabf",
      "display_url" : "medium.com\/@pfeiffer44\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545972646995705856",
  "text" : "Year in review: 2014 has been the strongest year of job growth since the 1990s \u2192 https:\/\/t.co\/OUZUwTrh4l http:\/\/t.co\/DnE4SvEuDl",
  "id" : 545972646995705856,
  "created_at" : "2014-12-19 16:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "craignewmark",
      "screen_name" : "craignewmark",
      "indices" : [ 3, 16 ],
      "id_str" : "14368074",
      "id" : 14368074
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 68, 79 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7UNyeHcUbZ",
      "expanded_url" : "https:\/\/medium.com\/@pfeiffer44\/breaking-down-the-worst-year-in-washington-b3bb4ceeabf?source=tw-bd66d1db3e64-1419003892977",
      "display_url" : "medium.com\/@pfeiffer44\/br\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545971138371665920",
  "text" : "RT @craignewmark: \u201CBreaking Down the \u2018Worst\u2019 Year in Washington\u201D by @pfeiffer44 https:\/\/t.co\/7UNyeHcUbZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 50, 61 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/7UNyeHcUbZ",
        "expanded_url" : "https:\/\/medium.com\/@pfeiffer44\/breaking-down-the-worst-year-in-washington-b3bb4ceeabf?source=tw-bd66d1db3e64-1419003892977",
        "display_url" : "medium.com\/@pfeiffer44\/br\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "545968089670512641",
    "text" : "\u201CBreaking Down the \u2018Worst\u2019 Year in Washington\u201D by @pfeiffer44 https:\/\/t.co\/7UNyeHcUbZ",
    "id" : 545968089670512641,
    "created_at" : "2014-12-19 15:45:10 +0000",
    "user" : {
      "name" : "craignewmark",
      "screen_name" : "craignewmark",
      "protected" : false,
      "id_str" : "14368074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649304642946383873\/mZaX3rwz_normal.jpg",
      "id" : 14368074,
      "verified" : true
    }
  },
  "id" : 545971138371665920,
  "created_at" : "2014-12-19 15:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 28, 39 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/3w3g3BdDzp",
      "expanded_url" : "http:\/\/go.wh.gov\/cL9uPn",
      "display_url" : "go.wh.gov\/cL9uPn"
    } ]
  },
  "geo" : { },
  "id_str" : "545964680179494912",
  "text" : "\"Worst\" year in Washington? @Pfeiffer44 breaks down why 2014 was a year of progress for America \u2192 http:\/\/t.co\/3w3g3BdDzp",
  "id" : 545964680179494912,
  "created_at" : "2014-12-19 15:31:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Surgeon_General\/status\/545713244875554816\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/6jdBAUYN6I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5LDTehIcAEvy5x.jpg",
      "id_str" : "545713244242210817",
      "id" : 545713244242210817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5LDTehIcAEvy5x.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6jdBAUYN6I"
    } ],
    "hashtags" : [ {
      "text" : "SurgeonGeneral",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545721381363933185",
  "text" : "RT @Surgeon_General: Honored to be America\u2019s Doctor and the 19th #SurgeonGeneral. \u2013VM http:\/\/t.co\/6jdBAUYN6I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Surgeon_General\/status\/545713244875554816\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/6jdBAUYN6I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5LDTehIcAEvy5x.jpg",
        "id_str" : "545713244242210817",
        "id" : 545713244242210817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5LDTehIcAEvy5x.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/6jdBAUYN6I"
      } ],
      "hashtags" : [ {
        "text" : "SurgeonGeneral",
        "indices" : [ 44, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545713244875554816",
    "text" : "Honored to be America\u2019s Doctor and the 19th #SurgeonGeneral. \u2013VM http:\/\/t.co\/6jdBAUYN6I",
    "id" : 545713244875554816,
    "created_at" : "2014-12-18 22:52:31 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 545721381363933185,
  "created_at" : "2014-12-18 23:24:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Oxivrzrt3I",
      "expanded_url" : "http:\/\/go.wh.gov\/X8A4EA",
      "display_url" : "go.wh.gov\/X8A4EA"
    } ]
  },
  "geo" : { },
  "id_str" : "545707630656618497",
  "text" : "Trust between law enforcement and the communities they serve is essential. See how we're working to help build it: http:\/\/t.co\/Oxivrzrt3I",
  "id" : 545707630656618497,
  "created_at" : "2014-12-18 22:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ntvlXG4ppU",
      "expanded_url" : "http:\/\/go.wh.gov\/X8A4EA",
      "display_url" : "go.wh.gov\/X8A4EA"
    } ]
  },
  "geo" : { },
  "id_str" : "545701386072367104",
  "text" : "President Obama just created a task force to help strengthen community policing. Get the facts: http:\/\/t.co\/ntvlXG4ppU",
  "id" : 545701386072367104,
  "created_at" : "2014-12-18 22:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5tO97bv5oq",
      "expanded_url" : "https:\/\/medium.com\/@PresidentObama\/the-u-s-and-cuba-bdad5845439a",
      "display_url" : "medium.com\/@PresidentObam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545685767545446400",
  "text" : "\"It\u2019s time to cut loose the shackles of the past and reach for a new and better future.\" \u2014Obama on his #CubaPolicy: https:\/\/t.co\/5tO97bv5oq",
  "id" : 545685767545446400,
  "created_at" : "2014-12-18 21:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545672181813104640\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qW5JUzP0ix",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5KdfuuCIAAIsP0.jpg",
      "id_str" : "545671673307865088",
      "id" : 545671673307865088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5KdfuuCIAAIsP0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qW5JUzP0ix"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/wWsFHTmpKf",
      "expanded_url" : "http:\/\/go.wh.gov\/gFTRyr",
      "display_url" : "go.wh.gov\/gFTRyr"
    } ]
  },
  "geo" : { },
  "id_str" : "545672181813104640",
  "text" : "FACT: 2014 has seen the largest health coverage gains in four decades \u2192 http:\/\/t.co\/wWsFHTmpKf #ACAWorks #GetCovered http:\/\/t.co\/qW5JUzP0ix",
  "id" : 545672181813104640,
  "created_at" : "2014-12-18 20:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskDrH",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/1l7Qx9Tgh5",
      "expanded_url" : "http:\/\/wh.gov\/irKzf",
      "display_url" : "wh.gov\/irKzf"
    } ]
  },
  "geo" : { },
  "id_str" : "545664979371061248",
  "text" : "RT @whitehouseostp: WATCH: Dr. John Holdren answers first batch of #AskDrH climate q's  \u2192 http:\/\/t.co\/1l7Qx9Tgh5 #ActOnClimate http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskDrH",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/1l7Qx9Tgh5",
        "expanded_url" : "http:\/\/wh.gov\/irKzf",
        "display_url" : "wh.gov\/irKzf"
      }, {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/O5oNjiPImM",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9aPqiPuFjdQ",
        "display_url" : "youtube.com\/watch?v=9aPqiP\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "545664909191950337",
    "text" : "WATCH: Dr. John Holdren answers first batch of #AskDrH climate q's  \u2192 http:\/\/t.co\/1l7Qx9Tgh5 #ActOnClimate http:\/\/t.co\/O5oNjiPImM",
    "id" : 545664909191950337,
    "created_at" : "2014-12-18 19:40:26 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 545664979371061248,
  "created_at" : "2014-12-18 19:40:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545649863984431105\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/VeuvGMPfHf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5KJoHMCMAARnmD.jpg",
      "id_str" : "545649827082547200",
      "id" : 545649827082547200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5KJoHMCMAARnmD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VeuvGMPfHf"
    } ],
    "hashtags" : [ {
      "text" : "Progress",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/wWsFHTmpKf",
      "expanded_url" : "http:\/\/go.wh.gov\/gFTRyr",
      "display_url" : "go.wh.gov\/gFTRyr"
    } ]
  },
  "geo" : { },
  "id_str" : "545649863984431105",
  "text" : "#Progress: An estimated 10 million Americans gained health coverage in 2014 \u2192 http:\/\/t.co\/wWsFHTmpKf #ACAWorks http:\/\/t.co\/VeuvGMPfHf",
  "id" : 545649863984431105,
  "created_at" : "2014-12-18 18:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/545645160189939712\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pKVXjWP7A4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5KFMSlCMAEG53_.png",
      "id_str" : "545644951057346561",
      "id" : 545644951057346561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5KFMSlCMAEG53_.png",
      "sizes" : [ {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/pKVXjWP7A4"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/YV80EzncGv",
      "expanded_url" : "http:\/\/wp.me\/p5HMd-fgSd",
      "display_url" : "wp.me\/p5HMd-fgSd"
    } ]
  },
  "geo" : { },
  "id_str" : "545645160189939712",
  "text" : "Share the good news: The number of uninsured Americans is near a historic low \u2192 http:\/\/t.co\/YV80EzncGv #ACAWorks http:\/\/t.co\/pKVXjWP7A4",
  "id" : 545645160189939712,
  "created_at" : "2014-12-18 18:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/545623078680952833\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/wirEcysUHm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5JxGtXCIAAbRnL.jpg",
      "id_str" : "545622864934608896",
      "id" : 545622864934608896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5JxGtXCIAAbRnL.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wirEcysUHm"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ZgRZAZnMn8",
      "expanded_url" : "http:\/\/go.wh.gov\/GSVgRo",
      "display_url" : "go.wh.gov\/GSVgRo"
    } ]
  },
  "geo" : { },
  "id_str" : "545623078680952833",
  "text" : "\"To the Cuban people, America extends a hand of friendship.\" \u2014President Obama: http:\/\/t.co\/ZgRZAZnMn8 #CubaPolicy http:\/\/t.co\/wirEcysUHm",
  "id" : 545623078680952833,
  "created_at" : "2014-12-18 16:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/lsBajzoxw0",
      "expanded_url" : "http:\/\/snpy.tv\/1yYEMRz",
      "display_url" : "snpy.tv\/1yYEMRz"
    } ]
  },
  "geo" : { },
  "id_str" : "545607397801463809",
  "text" : "Watch President Obama announce his new #CubaPolicy: http:\/\/t.co\/lsBajzoxw0",
  "id" : 545607397801463809,
  "created_at" : "2014-12-18 15:51:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/545342725084966912\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/tKkJ2cq1bX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5FyKBUCcAIK8Lz.jpg",
      "id_str" : "545342546365280258",
      "id" : 545342546365280258,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5FyKBUCcAIK8Lz.jpg",
      "sizes" : [ {
        "h" : 347,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 893
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 893
      } ],
      "display_url" : "pic.twitter.com\/tKkJ2cq1bX"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545345263485726721",
  "text" : "RT @vj44: So glad to see Alan Gross safe and sound with his family again. #CubaPolicy http:\/\/t.co\/tKkJ2cq1bX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/545342725084966912\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/tKkJ2cq1bX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5FyKBUCcAIK8Lz.jpg",
        "id_str" : "545342546365280258",
        "id" : 545342546365280258,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5FyKBUCcAIK8Lz.jpg",
        "sizes" : [ {
          "h" : 347,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 893
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 893
        } ],
        "display_url" : "pic.twitter.com\/tKkJ2cq1bX"
      } ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 64, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545342725084966912",
    "text" : "So glad to see Alan Gross safe and sound with his family again. #CubaPolicy http:\/\/t.co\/tKkJ2cq1bX",
    "id" : 545342725084966912,
    "created_at" : "2014-12-17 22:20:12 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 545345263485726721,
  "created_at" : "2014-12-17 22:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/545334624616865792\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/rOeFEY3GQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Fqm0OCQAEQjoV.jpg",
      "id_str" : "545334244973625345",
      "id" : 545334244973625345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Fqm0OCQAEQjoV.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rOeFEY3GQv"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ZeORP4H0jr",
      "expanded_url" : "http:\/\/go.wh.gov\/uyLvUE",
      "display_url" : "go.wh.gov\/uyLvUE"
    } ]
  },
  "geo" : { },
  "id_str" : "545334624616865792",
  "text" : "Welcome home, Alan Gross. http:\/\/t.co\/ZeORP4H0jr #CubaPolicy http:\/\/t.co\/rOeFEY3GQv",
  "id" : 545334624616865792,
  "created_at" : "2014-12-17 21:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hanukkah",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545331582056153088",
  "text" : "\"The light of hope will always outlast the fires of hate. That\u2019s what the #Hanukkah story teaches us.\" \u2014President Obama",
  "id" : 545331582056153088,
  "created_at" : "2014-12-17 21:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545330441503252480",
  "text" : "RT @WHLive: \"With his health deteriorating, his family worried he might not make it out alive. But he never gave up.\" \u2014Obama on Alan Gross \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545330381923180544",
    "text" : "\"With his health deteriorating, his family worried he might not make it out alive. But he never gave up.\" \u2014Obama on Alan Gross #CubaPolicy",
    "id" : 545330381923180544,
    "created_at" : "2014-12-17 21:31:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 545330441503252480,
  "created_at" : "2014-12-17 21:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545329935884091392",
  "text" : "\"After being unjustly held in Cuba for more than five years, American Alan Gross is free.\" \u2014President Obama #CubaPolicy",
  "id" : 545329935884091392,
  "created_at" : "2014-12-17 21:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/506MGZ3uIv",
      "expanded_url" : "http:\/\/go.wh.gov\/DuhR72",
      "display_url" : "go.wh.gov\/DuhR72"
    } ]
  },
  "geo" : { },
  "id_str" : "545329665296969728",
  "text" : "\"Happy Hanukkah, everybody!\" \u2014President Obama at a Hanukkah reception at the White House. Watch: http:\/\/t.co\/506MGZ3uIv",
  "id" : 545329665296969728,
  "created_at" : "2014-12-17 21:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 59, 68 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/TMiQd0W0TB",
      "expanded_url" : "http:\/\/bloom.bg\/1GMSc7t",
      "display_url" : "bloom.bg\/1GMSc7t"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "545329075703644160",
  "text" : "\"Obamacare's best week yet brings 1 million new sign-ups\" \u2014@Business: http:\/\/t.co\/TMiQd0W0TB #ACAWorks\n#GetCovered: http:\/\/t.co\/NSeLHFvc62.",
  "id" : 545329075703644160,
  "created_at" : "2014-12-17 21:25:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Qrzp5zODZk",
      "expanded_url" : "http:\/\/snpy.tv\/1yYEMRz",
      "display_url" : "snpy.tv\/1yYEMRz"
    } ]
  },
  "geo" : { },
  "id_str" : "545318836832960512",
  "text" : "\"50 years have shown that isolation hasn\u2019t worked. It\u2019s time for a new approach.\" \u2014President Obama #CubaPolicy http:\/\/t.co\/Qrzp5zODZk",
  "id" : 545318836832960512,
  "created_at" : "2014-12-17 20:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545308787720986624\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/pKfE4Cv0tr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5FS-JDCAAAwm7A.jpg",
      "id_str" : "545308257422540800",
      "id" : 545308257422540800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5FS-JDCAAAwm7A.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pKfE4Cv0tr"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ZeORP4H0jr",
      "expanded_url" : "http:\/\/go.wh.gov\/uyLvUE",
      "display_url" : "go.wh.gov\/uyLvUE"
    } ]
  },
  "geo" : { },
  "id_str" : "545308787720986624",
  "text" : "RT to share how President Obama is charting a new course in U.S.-Cuba relations: http:\/\/t.co\/ZeORP4H0jr #CubaPolicy http:\/\/t.co\/pKfE4Cv0tr",
  "id" : 545308787720986624,
  "created_at" : "2014-12-17 20:05:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/lhKvftIGrI",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/charting-a-new-course-on-cuba-d4081b40adb5",
      "display_url" : "medium.com\/@WhiteHouse\/ch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "545304232052535310",
  "text" : "Get the facts on President Obama's new #CubaPolicy: https:\/\/t.co\/lhKvftIGrI",
  "id" : 545304232052535310,
  "created_at" : "2014-12-17 19:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Chamber",
      "screen_name" : "USChamber",
      "indices" : [ 93, 103 ],
      "id_str" : "85606078",
      "id" : 85606078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/dgRlTCQdQs",
      "expanded_url" : "http:\/\/uscham.com\/1sAGqGD",
      "display_url" : "uscham.com\/1sAGqGD"
    } ]
  },
  "geo" : { },
  "id_str" : "545296083656536064",
  "text" : "\"Commercial exchange between the U.S. and Cuban private sectors will bring shared benefits\" \u2014@USChamber: http:\/\/t.co\/dgRlTCQdQs #CubaPolicy",
  "id" : 545296083656536064,
  "created_at" : "2014-12-17 19:14:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545292156055732224",
  "text" : "RT @GovernorOMalley: Welcome home to Maryland, Alan Gross. Here's wishing you boundless joy with your friends and family this holiday seaso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545291909644976128",
    "text" : "Welcome home to Maryland, Alan Gross. Here's wishing you boundless joy with your friends and family this holiday season.",
    "id" : 545291909644976128,
    "created_at" : "2014-12-17 18:58:16 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 545292156055732224,
  "created_at" : "2014-12-17 18:59:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 1, 10 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545291379920756736\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Nk559Nn8tm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5FDOvRCEAAFMwt.png",
      "id_str" : "545290950373675008",
      "id" : 545290950373675008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5FDOvRCEAAFMwt.png",
      "sizes" : [ {
        "h" : 314,
        "resize" : "fit",
        "w" : 934
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 934
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Nk559Nn8tm"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/wIgkkJeTsf",
      "expanded_url" : "http:\/\/bit.ly\/1AI3RlK",
      "display_url" : "bit.ly\/1AI3RlK"
    } ]
  },
  "geo" : { },
  "id_str" : "545291379920756736",
  "text" : ".@Pontifex expresses his support for today's #CubaPolicy announcement by President Obama: http:\/\/t.co\/wIgkkJeTsf http:\/\/t.co\/Nk559Nn8tm",
  "id" : 545291379920756736,
  "created_at" : "2014-12-17 18:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545276513772257280",
  "text" : "RT @lacasablanca: Estados Unidos est\u00E1 tomando medidas hist\u00F3ricas para trazar un nuevo rumbo en nuestras relaciones con Cuba #CubaPolicy htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/545276443601543168\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xDmxmw2ocM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5E2CSDCAAA0jJZ.jpg",
        "id_str" : "545276442720731136",
        "id" : 545276442720731136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5E2CSDCAAA0jJZ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xDmxmw2ocM"
      } ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545276443601543168",
    "text" : "Estados Unidos est\u00E1 tomando medidas hist\u00F3ricas para trazar un nuevo rumbo en nuestras relaciones con Cuba #CubaPolicy http:\/\/t.co\/xDmxmw2ocM",
    "id" : 545276443601543168,
    "created_at" : "2014-12-17 17:56:49 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 545276513772257280,
  "created_at" : "2014-12-17 17:57:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545271060417875968\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dJMxK2IAor",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5ExFsNCMAAcJWl.jpg",
      "id_str" : "545271003723476992",
      "id" : 545271003723476992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5ExFsNCMAAcJWl.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dJMxK2IAor"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ZeORP4H0jr",
      "expanded_url" : "http:\/\/go.wh.gov\/uyLvUE",
      "display_url" : "go.wh.gov\/uyLvUE"
    } ]
  },
  "geo" : { },
  "id_str" : "545271060417875968",
  "text" : "President Obama speaks with President Ra\u00FAl Castro of Cuba before announcing his #CubaPolicy: http:\/\/t.co\/ZeORP4H0jr http:\/\/t.co\/dJMxK2IAor",
  "id" : 545271060417875968,
  "created_at" : "2014-12-17 17:35:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Qrzp5zODZk",
      "expanded_url" : "http:\/\/snpy.tv\/1yYEMRz",
      "display_url" : "snpy.tv\/1yYEMRz"
    } ]
  },
  "geo" : { },
  "id_str" : "545268614656323584",
  "text" : "\"To the Cuban people, America extends a hand of friendship.\" \u2014President Obama\nWatch the full video. #CubaPolicy http:\/\/t.co\/Qrzp5zODZk",
  "id" : 545268614656323584,
  "created_at" : "2014-12-17 17:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545266506183872512",
  "text" : "\"Today, America chooses to cut loose the shackles of the past, so as to reach for a better future.\" \u2014President Obama #CubaPolicy",
  "id" : 545266506183872512,
  "created_at" : "2014-12-17 17:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545266143460483072",
  "text" : "RT @WHLive: \"Let us leave behind the legacy of both colonization &amp; communism\u2014the tyranny of drug cartels, dictators &amp; sham elections\" \u2014Obam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 137, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545266116629499904",
    "text" : "\"Let us leave behind the legacy of both colonization &amp; communism\u2014the tyranny of drug cartels, dictators &amp; sham elections\" \u2014Obama #CubaPolicy",
    "id" : 545266116629499904,
    "created_at" : "2014-12-17 17:15:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 545266143460483072,
  "created_at" : "2014-12-17 17:15:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545265785438867457\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/aUYC1VcBlb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5EsVn_CIAArHH_.jpg",
      "id_str" : "545265779910778880",
      "id" : 545265779910778880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5EsVn_CIAArHH_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aUYC1VcBlb"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ZeORP4H0jr",
      "expanded_url" : "http:\/\/go.wh.gov\/uyLvUE",
      "display_url" : "go.wh.gov\/uyLvUE"
    } ]
  },
  "geo" : { },
  "id_str" : "545265785438867457",
  "text" : "\"To the Cuban people, America extends a hand of friendship.\" \u2014President Obama: http:\/\/t.co\/ZeORP4H0jr #CubaPolicy http:\/\/t.co\/aUYC1VcBlb",
  "id" : 545265785438867457,
  "created_at" : "2014-12-17 17:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545265571026059264",
  "text" : "\"We should not allow U.S. sanctions to add to the burden of Cuban citizens we seek to help.\" \u2014President Obama #CubaPolicy",
  "id" : 545265571026059264,
  "created_at" : "2014-12-17 17:13:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545265458559979520",
  "text" : "RT @WHLive: \"It does not serve America\u2019s interests, or the Cuban people, to try to push Cuba toward collapse.\" \u2014President Obama #CubaPolicy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545265436414066688",
    "text" : "\"It does not serve America\u2019s interests, or the Cuban people, to try to push Cuba toward collapse.\" \u2014President Obama #CubaPolicy",
    "id" : 545265436414066688,
    "created_at" : "2014-12-17 17:13:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 545265458559979520,
  "created_at" : "2014-12-17 17:13:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545265101037522944",
  "text" : "RT @WHLive: \"I have authorized increased telecommunications connections between the United States and Cuba.\" \u2014President Obama #CubaPolicy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 114, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545264964580040704",
    "text" : "\"I have authorized increased telecommunications connections between the United States and Cuba.\" \u2014President Obama #CubaPolicy",
    "id" : 545264964580040704,
    "created_at" : "2014-12-17 17:11:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 545265101037522944,
  "created_at" : "2014-12-17 17:11:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545264843020701696",
  "text" : "\"Increased commerce is good for Americans and for the Cuban people.\" \u2014President Obama #CubaPolicy",
  "id" : 545264843020701696,
  "created_at" : "2014-12-17 17:10:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545264562413400064",
  "text" : "\"We are taking steps to increase travel, commerce, and the flow of information to, and from, Cuba.\" \u2014President Obama #CubaPolicy",
  "id" : 545264562413400064,
  "created_at" : "2014-12-17 17:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545264307722678273\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dppjtoqGWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5Eq_foCcAAa18p.jpg",
      "id_str" : "545264300198096896",
      "id" : 545264300198096896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5Eq_foCcAAa18p.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dppjtoqGWP"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545264307722678273",
  "text" : "\"These 50 years have shown that isolation hasn\u2019t worked. It\u2019s time for a new approach.\" \u2014President Obama #CubaPolicy http:\/\/t.co\/dppjtoqGWP",
  "id" : 545264307722678273,
  "created_at" : "2014-12-17 17:08:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545264173228105729",
  "text" : "\"I believe that we can do more to support the Cuban people, and promote our values, through engagement.\" \u2014President Obama #CubaPolicy",
  "id" : 545264173228105729,
  "created_at" : "2014-12-17 17:08:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545264033666834432",
  "text" : "\"I have instructed Secretary Kerry to immediately begin discussions with Cuba to re-establish diplomatic relations\" \u2014Obama #CubaPolicy",
  "id" : 545264033666834432,
  "created_at" : "2014-12-17 17:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545263850786811905",
  "text" : "\"Today, Alan returned home\u2014reunited with his family at long last.\" \u2014President Obama on Alan Gross #CubaPolicy",
  "id" : 545263850786811905,
  "created_at" : "2014-12-17 17:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545263569621643265",
  "text" : "\"We lifted restrictions for Cuban-Americans to travel and send remittances to their families in Cuba.\" \u2014President Obama #CubaPolicy",
  "id" : 545263569621643265,
  "created_at" : "2014-12-17 17:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545263442815250432",
  "text" : "RT @WHLive: \"When I came into office\u2014I promised to re-examine our #CubaPolicy.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "545263417586511872",
    "text" : "\"When I came into office\u2014I promised to re-examine our #CubaPolicy.\" \u2014President Obama",
    "id" : 545263417586511872,
    "created_at" : "2014-12-17 17:05:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 545263442815250432,
  "created_at" : "2014-12-17 17:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545262902391754752\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/QPwRenJTfA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5EptqxCIAAPXRz.jpg",
      "id_str" : "545262894439342080",
      "id" : 545262894439342080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5EptqxCIAAPXRz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QPwRenJTfA"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545262902391754752",
  "text" : "\"We will begin to normalize relations between our two countries.\" \u2014President Obama #CubaPolicy http:\/\/t.co\/QPwRenJTfA",
  "id" : 545262902391754752,
  "created_at" : "2014-12-17 17:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545262659885486080",
  "text" : "\"We will end an outdated approach that, for decades, has failed to advance our interests\" \u2014President Obama #CubaPolicy",
  "id" : 545262659885486080,
  "created_at" : "2014-12-17 17:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545262596106887168",
  "text" : "\"Today, the United States of America is changing its relationship with the people of Cuba.\" \u2014President Obama #CubaPolicy",
  "id" : 545262596106887168,
  "created_at" : "2014-12-17 17:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 70, 78 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ZeORP4H0jr",
      "expanded_url" : "http:\/\/go.wh.gov\/uyLvUE",
      "display_url" : "go.wh.gov\/uyLvUE"
    } ]
  },
  "geo" : { },
  "id_str" : "545260590822744064",
  "text" : "Watch President Obama deliver a statement on our #CubaPolicy from the @Cabinet Room at 12pm ET \u2192 http:\/\/t.co\/ZeORP4H0jr",
  "id" : 545260590822744064,
  "created_at" : "2014-12-17 16:53:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/d9wUpV2aTT",
      "expanded_url" : "http:\/\/go.wh.gov\/RpCCXj",
      "display_url" : "go.wh.gov\/RpCCXj"
    } ]
  },
  "geo" : { },
  "id_str" : "545257113195249665",
  "text" : "Today, the U.S. is taking historic steps to chart a new course in our relations with Cuba: http:\/\/t.co\/d9wUpV2aTT #CubaPolicy",
  "id" : 545257113195249665,
  "created_at" : "2014-12-17 16:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/4B9jNPM958",
      "expanded_url" : "http:\/\/go.wh.gov\/uyLvUE",
      "display_url" : "go.wh.gov\/uyLvUE"
    } ]
  },
  "geo" : { },
  "id_str" : "545218996287856640",
  "text" : "At 12pm ET today, President Obama will deliver a statement on Cuba from the Cabinet Room: http:\/\/t.co\/4B9jNPM958",
  "id" : 545218996287856640,
  "created_at" : "2014-12-17 14:08:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/545001739657572352\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/dfoHTHHyFU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5A1X0FCMAI9Agf.png",
      "id_str" : "544994238144851970",
      "id" : 544994238144851970,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5A1X0FCMAI9Agf.png",
      "sizes" : [ {
        "h" : 417,
        "resize" : "fit",
        "w" : 1041
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dfoHTHHyFU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545001739657572352",
  "text" : "\"From my family to yours, Chag Sameach.\" \u2014Obama wishing Jews across America and around the world a Happy Hanukkah http:\/\/t.co\/dfoHTHHyFU",
  "id" : 545001739657572352,
  "created_at" : "2014-12-16 23:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/TBaxNAtUK9",
      "expanded_url" : "http:\/\/on.doi.gov\/1GNfmuq",
      "display_url" : "on.doi.gov\/1GNfmuq"
    } ]
  },
  "geo" : { },
  "id_str" : "544995033011597312",
  "text" : "RT @Interior: Bristol Bay has world-class fisheries &amp; stunning beauty. Learn how Pres Obama is protecting it http:\/\/t.co\/TBaxNAtUK9 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/544994634054000641\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/Afbq8hF60Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B5A1u1AIQAAdwbv.jpg",
        "id_str" : "544994633529704448",
        "id" : 544994633529704448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5A1u1AIQAAdwbv.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1361,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Afbq8hF60Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/TBaxNAtUK9",
        "expanded_url" : "http:\/\/on.doi.gov\/1GNfmuq",
        "display_url" : "on.doi.gov\/1GNfmuq"
      } ]
    },
    "geo" : { },
    "id_str" : "544994634054000641",
    "text" : "Bristol Bay has world-class fisheries &amp; stunning beauty. Learn how Pres Obama is protecting it http:\/\/t.co\/TBaxNAtUK9 http:\/\/t.co\/Afbq8hF60Z",
    "id" : 544994634054000641,
    "created_at" : "2014-12-16 23:17:00 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 544995033011597312,
  "created_at" : "2014-12-16 23:18:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544994766765572097",
  "text" : "RT @SecretaryJewell: Just now, the President took action to protect a place called Bristol Bay \u2013 watch here to see why that matters http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/XOIZCmBWZw",
        "expanded_url" : "http:\/\/youtu.be\/gH9mXrB2sWA",
        "display_url" : "youtu.be\/gH9mXrB2sWA"
      } ]
    },
    "geo" : { },
    "id_str" : "544991843365433344",
    "text" : "Just now, the President took action to protect a place called Bristol Bay \u2013 watch here to see why that matters http:\/\/t.co\/XOIZCmBWZw",
    "id" : 544991843365433344,
    "created_at" : "2014-12-16 23:05:55 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 544994766765572097,
  "created_at" : "2014-12-16 23:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544985280025882624\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/kcVkkX2aEA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5AtAXRCMAIrz0t.jpg",
      "id_str" : "544985039180541954",
      "id" : 544985039180541954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5AtAXRCMAIrz0t.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kcVkkX2aEA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/hcGH4Dkega",
      "expanded_url" : "http:\/\/youtu.be\/gH9mXrB2sWA",
      "display_url" : "youtu.be\/gH9mXrB2sWA"
    } ]
  },
  "geo" : { },
  "id_str" : "544985280025882624",
  "text" : "FACT: Alaska's Bristol Bay supports $2 billion each year in commercial fishing \u2192 http:\/\/t.co\/hcGH4Dkega http:\/\/t.co\/kcVkkX2aEA",
  "id" : 544985280025882624,
  "created_at" : "2014-12-16 22:39:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544980032662155264\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/heR8ed8mqN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5AobzCCEAEjBH2.jpg",
      "id_str" : "544980012932141057",
      "id" : 544980012932141057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5AobzCCEAEjBH2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/heR8ed8mqN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/hcGH4Dkega",
      "expanded_url" : "http:\/\/youtu.be\/gH9mXrB2sWA",
      "display_url" : "youtu.be\/gH9mXrB2sWA"
    } ]
  },
  "geo" : { },
  "id_str" : "544980032662155264",
  "text" : "Big news: President Obama just took action to protect Alaska's Bristol Bay \u2192 http:\/\/t.co\/hcGH4Dkega http:\/\/t.co\/heR8ed8mqN",
  "id" : 544980032662155264,
  "created_at" : "2014-12-16 22:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/hcGH4Dkega",
      "expanded_url" : "http:\/\/youtu.be\/gH9mXrB2sWA",
      "display_url" : "youtu.be\/gH9mXrB2sWA"
    } ]
  },
  "geo" : { },
  "id_str" : "544977088394973184",
  "text" : "I just took action to protect one of our greatest national treasures: Alaska's Bristol Bay. http:\/\/t.co\/hcGH4Dkega -bo",
  "id" : 544977088394973184,
  "created_at" : "2014-12-16 22:07:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ubsZAOiJL3",
      "expanded_url" : "http:\/\/go.wh.gov\/xN6Z5C",
      "display_url" : "go.wh.gov\/xN6Z5C"
    } ]
  },
  "geo" : { },
  "id_str" : "544930052610072576",
  "text" : "\"When I opened the envelop containing my insurance card, I got a bit teary eyed\" \u2014Lynnette from Maryland: http:\/\/t.co\/ubsZAOiJL3 #GetCovered",
  "id" : 544930052610072576,
  "created_at" : "2014-12-16 19:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544919110811779072\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/lzX8JXXFPL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4_wrVLCYAA5A4M.jpg",
      "id_str" : "544918707143598080",
      "id" : 544918707143598080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4_wrVLCYAA5A4M.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lzX8JXXFPL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/pPlUtTa7ew",
      "expanded_url" : "http:\/\/go.wh.gov\/fXhNtp",
      "display_url" : "go.wh.gov\/fXhNtp"
    } ]
  },
  "geo" : { },
  "id_str" : "544919110811779072",
  "text" : "\"You are the backbone of the greatest nation on earth.\" \u2014President Obama to our troops: http:\/\/t.co\/pPlUtTa7ew http:\/\/t.co\/lzX8JXXFPL",
  "id" : 544919110811779072,
  "created_at" : "2014-12-16 18:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544862834006310914\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/oZB0lpHVmY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4-9uqaCUAIzT8g.png",
      "id_str" : "544862689290244098",
      "id" : 544862689290244098,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4-9uqaCUAIzT8g.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 112,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 909
      } ],
      "display_url" : "pic.twitter.com\/oZB0lpHVmY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544862834006310914",
  "text" : "\"The United States condemns in the strongest possible terms today\u2019s horrific attack\u2026in Peshawar, Pakistan.\" \u2014Obama http:\/\/t.co\/oZB0lpHVmY",
  "id" : 544862834006310914,
  "created_at" : "2014-12-16 14:33:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544641700916764672\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/bfzZfZcNfq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B470t4PCAAIS55b.jpg",
      "id_str" : "544641673985130498",
      "id" : 544641673985130498,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B470t4PCAAIS55b.jpg",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bfzZfZcNfq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544641700916764672",
  "text" : "\"Vivek's confirmation makes us better positioned to save lives around the world &amp; protect the American people\" \u2014Obama http:\/\/t.co\/bfzZfZcNfq",
  "id" : 544641700916764672,
  "created_at" : "2014-12-15 23:54:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/544639044827627520\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/p9YrMwmfk1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B47yK1rCAAAEPQo.jpg",
      "id_str" : "544638872978587648",
      "id" : 544638872978587648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B47yK1rCAAAEPQo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/p9YrMwmfk1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544639521074073600",
  "text" : "RT @FLOTUS: \u266B The Obamas come a-caroling! \u266B http:\/\/t.co\/p9YrMwmfk1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/544639044827627520\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/p9YrMwmfk1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B47yK1rCAAAEPQo.jpg",
        "id_str" : "544638872978587648",
        "id" : 544638872978587648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B47yK1rCAAAEPQo.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/p9YrMwmfk1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544639044827627520",
    "text" : "\u266B The Obamas come a-caroling! \u266B http:\/\/t.co\/p9YrMwmfk1",
    "id" : 544639044827627520,
    "created_at" : "2014-12-15 23:44:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 544639521074073600,
  "created_at" : "2014-12-15 23:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544626915835781121\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/EE6wchI0NT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B47nNJLCYAANtly.jpg",
      "id_str" : "544626817944936448",
      "id" : 544626817944936448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B47nNJLCYAANtly.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EE6wchI0NT"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredToday",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544626915835781121",
  "text" : "Today's the deadline to sign up for health coverage that starts Jan. 1st: http:\/\/t.co\/NSeLHFvc62 #GetCoveredToday http:\/\/t.co\/EE6wchI0NT",
  "id" : 544626915835781121,
  "created_at" : "2014-12-15 22:55:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544586382258085888",
  "text" : "\"You are the backbone of the greatest nation on earth\u2014and you always will be that.\" \u2014President Obama to our troops",
  "id" : 544586382258085888,
  "created_at" : "2014-12-15 20:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544586203555590144",
  "text" : "\"What makes us the best is all of you. It\u2019s your character and your our willingness to say, 'send me.'\" \u2014President Obama to our troops",
  "id" : 544586203555590144,
  "created_at" : "2014-12-15 20:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Rv0x6vd1qt",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "544584595711078400",
  "text" : "RT @WHLive: \u201CThere are people who are alive today because of what you guys do. That\u2019s American leadership.\u201D \u2014Obama: http:\/\/t.co\/Rv0x6vd1qt \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 127, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Rv0x6vd1qt",
        "expanded_url" : "http:\/\/wh.gov\/ebola-response",
        "display_url" : "wh.gov\/ebola-response"
      } ]
    },
    "geo" : { },
    "id_str" : "544584573699366912",
    "text" : "\u201CThere are people who are alive today because of what you guys do. That\u2019s American leadership.\u201D \u2014Obama: http:\/\/t.co\/Rv0x6vd1qt #Ebola",
    "id" : 544584573699366912,
    "created_at" : "2014-12-15 20:07:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 544584595711078400,
  "created_at" : "2014-12-15 20:07:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544583724759662593",
  "text" : "RT @WHLive: \"Because of you, we\u2019ve blunted their momentum and put them on the defensive.\" \u2014President Obama to our troops on ISIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544583699291836416",
    "text" : "\"Because of you, we\u2019ve blunted their momentum and put them on the defensive.\" \u2014President Obama to our troops on ISIL",
    "id" : 544583699291836416,
    "created_at" : "2014-12-15 20:04:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 544583724759662593,
  "created_at" : "2014-12-15 20:04:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544583168771096577",
  "text" : "\"To all our troops far from home and their families for the holidays\u2014you\u2019re in our thoughts, you\u2019re in our prayers.\" \u2014Obama #JoiningForces",
  "id" : 544583168771096577,
  "created_at" : "2014-12-15 20:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544582775785791490",
  "text" : "RT @WHLive: \"You helped decimate the core of al Qaeda's leadership and deliver justice to Osama bin Laden.\" \u2014President Obama to our troops",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544582742021640192",
    "text" : "\"You helped decimate the core of al Qaeda's leadership and deliver justice to Osama bin Laden.\" \u2014President Obama to our troops",
    "id" : 544582742021640192,
    "created_at" : "2014-12-15 20:00:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 544582775785791490,
  "created_at" : "2014-12-15 20:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544582511708237824",
  "text" : "\"This month, America\u2019s war in Afghanistan will come to a responsible end.\" \u2014President Obama",
  "id" : 544582511708237824,
  "created_at" : "2014-12-15 19:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544582276164513792",
  "text" : "\"Let me just say to all of you who\u2019ve returned from Afghanistan in recent weeks...welcome home.\" \u2014President Obama",
  "id" : 544582276164513792,
  "created_at" : "2014-12-15 19:58:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544581924048494592",
  "text" : "\"After more than a decade of war, our nation is marking an important milestone.\" \u2014President Obama",
  "id" : 544581924048494592,
  "created_at" : "2014-12-15 19:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544581628291342336",
  "text" : "\"We\u2019re proud of you. We support you. And we can never thank you enough.\" \u2014President Obama to our men and women in uniform #JoiningForces",
  "id" : 544581628291342336,
  "created_at" : "2014-12-15 19:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544581320194531328",
  "text" : "\"Thank you for your extraordinary service. I thank you as your President, because you inspire me.\" \u2014President Obama to our troops",
  "id" : 544581320194531328,
  "created_at" : "2014-12-15 19:54:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544580984608260096",
  "text" : "RT @WHLive: \"Like a friend of mine from New Jersey likes to say, 'wherever this flag is flown, we take care of our own.'\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544580936851935232",
    "text" : "\"Like a friend of mine from New Jersey likes to say, 'wherever this flag is flown, we take care of our own.'\" \u2014President Obama",
    "id" : 544580936851935232,
    "created_at" : "2014-12-15 19:53:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 544580984608260096,
  "created_at" : "2014-12-15 19:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544580476254441472",
  "text" : "\"Our military families are the heroes on the home front. Give it up for our remarkable military families.\" \u2014President Obama #JoiningForces",
  "id" : 544580476254441472,
  "created_at" : "2014-12-15 19:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/lKqTeoyWab",
      "expanded_url" : "http:\/\/go.wh.gov\/q5dTrD",
      "display_url" : "go.wh.gov\/q5dTrD"
    } ]
  },
  "geo" : { },
  "id_str" : "544579930051190784",
  "text" : "Watch live: President Obama speaks to troops at Joint Base McGuire-Dix-Lakehurst \u2192 http:\/\/t.co\/lKqTeoyWab",
  "id" : 544579930051190784,
  "created_at" : "2014-12-15 19:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Tennessean",
      "screen_name" : "Tennessean",
      "indices" : [ 43, 54 ],
      "id_str" : "16639736",
      "id" : 16639736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/1hrzcDqydM",
      "expanded_url" : "http:\/\/tnne.ws\/1DBZ6jr",
      "display_url" : "tnne.ws\/1DBZ6jr"
    } ]
  },
  "geo" : { },
  "id_str" : "544574677247471617",
  "text" : "\"'They' are 'us.'\" \u2014President Obama in the @Tennessean on how immigration benefits everyone: http:\/\/t.co\/1hrzcDqydM #ImmigrationAction",
  "id" : 544574677247471617,
  "created_at" : "2014-12-15 19:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spredfast",
      "screen_name" : "Spredfast",
      "indices" : [ 3, 13 ],
      "id_str" : "15823875",
      "id" : 15823875
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544565495563698176",
  "text" : "RT @Spredfast: We teamed up with @WhiteHouse to bring its holiday experience to life. Share in the magic and joy with #WHHolidays! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHolidays",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Lp3jSZmV4W",
        "expanded_url" : "http:\/\/sfa.st\/1wJJSWD",
        "display_url" : "sfa.st\/1wJJSWD"
      } ]
    },
    "geo" : { },
    "id_str" : "543505824967323648",
    "text" : "We teamed up with @WhiteHouse to bring its holiday experience to life. Share in the magic and joy with #WHHolidays! http:\/\/t.co\/Lp3jSZmV4W",
    "id" : 543505824967323648,
    "created_at" : "2014-12-12 20:41:01 +0000",
    "user" : {
      "name" : "Spredfast",
      "screen_name" : "Spredfast",
      "protected" : false,
      "id_str" : "15823875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709471919834157056\/Y6GYnJUu_normal.jpg",
      "id" : 15823875,
      "verified" : true
    }
  },
  "id" : 544565495563698176,
  "created_at" : "2014-12-15 18:51:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544560960296341505\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/s8F81NgtKf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B46rEn9CUAAXrnB.jpg",
      "id_str" : "544560700891222016",
      "id" : 544560700891222016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B46rEn9CUAAXrnB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/s8F81NgtKf"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredToday",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544560960296341505",
  "text" : "#GetCoveredToday for health coverage that starts on January 1st \u2192 http:\/\/t.co\/NSeLHFvc62 http:\/\/t.co\/s8F81NgtKf",
  "id" : 544560960296341505,
  "created_at" : "2014-12-15 18:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/UYgkxVyONY",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544547019604234240",
  "text" : "RT @NancyPelosi: Today is the last day to enroll for health insurance that starts Jan 1st. #GetCovered at http:\/\/t.co\/UYgkxVyONY! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/544544687366094850\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/CPAw73bDHl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B46cf8AIUAA5qxB.jpg",
        "id_str" : "544544677454958592",
        "id" : 544544677454958592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B46cf8AIUAA5qxB.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CPAw73bDHl"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 74, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/UYgkxVyONY",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "544544687366094850",
    "text" : "Today is the last day to enroll for health insurance that starts Jan 1st. #GetCovered at http:\/\/t.co\/UYgkxVyONY! http:\/\/t.co\/CPAw73bDHl",
    "id" : 544544687366094850,
    "created_at" : "2014-12-15 17:29:05 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 544547019604234240,
  "created_at" : "2014-12-15 17:38:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/544542086712659968\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/64ZEpokdnM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B46Z1CgCYAAm_se.jpg",
      "id_str" : "544541741441769472",
      "id" : 544541741441769472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B46Z1CgCYAAm_se.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/64ZEpokdnM"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredToday",
      "indices" : [ 73, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544542086712659968",
  "text" : "\u231A is running out to sign up for health coverage that starts January 1st. #GetCoveredToday: http:\/\/t.co\/NSeLHFvc62 http:\/\/t.co\/64ZEpokdnM",
  "id" : 544542086712659968,
  "created_at" : "2014-12-15 17:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredToday",
      "indices" : [ 8, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EO0WsRUooR",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544532466334056449",
  "text" : "RT @VP: #GetCoveredToday \u2192 It's your last chance to sign up for health coverage that starts Jan. 1st: http:\/\/t.co\/EO0WsRUooR http:\/\/t.co\/EN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/544529021116375040\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ENTCc7o6T9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B46OQZIIUAEXKGZ.jpg",
        "id_str" : "544529017232445441",
        "id" : 544529017232445441,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B46OQZIIUAEXKGZ.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ENTCc7o6T9"
      } ],
      "hashtags" : [ {
        "text" : "GetCoveredToday",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/EO0WsRUooR",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "544529021116375040",
    "text" : "#GetCoveredToday \u2192 It's your last chance to sign up for health coverage that starts Jan. 1st: http:\/\/t.co\/EO0WsRUooR http:\/\/t.co\/ENTCc7o6T9",
    "id" : 544529021116375040,
    "created_at" : "2014-12-15 16:26:50 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 544532466334056449,
  "created_at" : "2014-12-15 16:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "On Air\/Ryan Seacrest",
      "screen_name" : "OnAirWithRyan",
      "indices" : [ 3, 17 ],
      "id_str" : "325260518",
      "id" : 325260518
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IsOJm83NWN",
      "expanded_url" : "http:\/\/onair.rs\/1ITzJKi",
      "display_url" : "onair.rs\/1ITzJKi"
    } ]
  },
  "geo" : { },
  "id_str" : "544530005468790784",
  "text" : "RT @OnAirWithRyan: President Obama called from @WhiteHouse to talk health care coverage, buying Christmas gifts: http:\/\/t.co\/IsOJm83NWN htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 28, 39 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OnAirWithRyan\/status\/544520158723596289\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/d6EGkScoMi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B46GMuiCAAEUiDz.jpg",
        "id_str" : "544520158165729281",
        "id" : 544520158165729281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B46GMuiCAAEUiDz.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1026
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/d6EGkScoMi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/IsOJm83NWN",
        "expanded_url" : "http:\/\/onair.rs\/1ITzJKi",
        "display_url" : "onair.rs\/1ITzJKi"
      } ]
    },
    "geo" : { },
    "id_str" : "544520158723596289",
    "text" : "President Obama called from @WhiteHouse to talk health care coverage, buying Christmas gifts: http:\/\/t.co\/IsOJm83NWN http:\/\/t.co\/d6EGkScoMi",
    "id" : 544520158723596289,
    "created_at" : "2014-12-15 15:51:37 +0000",
    "user" : {
      "name" : "On Air\/Ryan Seacrest",
      "screen_name" : "OnAirWithRyan",
      "protected" : false,
      "id_str" : "325260518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796357463389835264\/ctu_Qbjw_normal.jpg",
      "id" : 325260518,
      "verified" : true
    }
  },
  "id" : 544530005468790784,
  "created_at" : "2014-12-15 16:30:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544524940762828801\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nZaLCjnbZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B46Kgm9CYAIRbe5.jpg",
      "id_str" : "544524897775411202",
      "id" : 544524897775411202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B46Kgm9CYAIRbe5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nZaLCjnbZK"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredToday",
      "indices" : [ 76, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544524940762828801",
  "text" : "Today's your last chance to sign up for a health plan that starts Jan. 1st. #GetCoveredToday: http:\/\/t.co\/NSeLHFvc62 http:\/\/t.co\/nZaLCjnbZK",
  "id" : 544524940762828801,
  "created_at" : "2014-12-15 16:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "On Air\/Ryan Seacrest",
      "screen_name" : "OnAirWithRyan",
      "indices" : [ 3, 17 ],
      "id_str" : "325260518",
      "id" : 325260518
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 93, 104 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544514401802260480",
  "text" : "RT @OnAirWithRyan: Good morning Mr. President! Talking with President Obama calling\nfrom the @WhiteHouse now. Listen LIVE: http:\/\/t.co\/4Ff0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 74, 85 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/4Ff0aodIrK",
        "expanded_url" : "http:\/\/bit.ly\/OnAirLive",
        "display_url" : "bit.ly\/OnAirLive"
      } ]
    },
    "geo" : { },
    "id_str" : "544508689520943106",
    "text" : "Good morning Mr. President! Talking with President Obama calling\nfrom the @WhiteHouse now. Listen LIVE: http:\/\/t.co\/4Ff0aodIrK",
    "id" : 544508689520943106,
    "created_at" : "2014-12-15 15:06:02 +0000",
    "user" : {
      "name" : "On Air\/Ryan Seacrest",
      "screen_name" : "OnAirWithRyan",
      "protected" : false,
      "id_str" : "325260518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796357463389835264\/ctu_Qbjw_normal.jpg",
      "id" : 325260518,
      "verified" : true
    }
  },
  "id" : 544514401802260480,
  "created_at" : "2014-12-15 15:28:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Ay5UCNSAHi",
      "expanded_url" : "http:\/\/go.wh.gov\/RjrhpL",
      "display_url" : "go.wh.gov\/RjrhpL"
    } ]
  },
  "geo" : { },
  "id_str" : "544265641285255168",
  "text" : "\"In times of crisis and challenge, the world turns to America for leadership.\" \u2014President Obama: http:\/\/t.co\/Ay5UCNSAHi",
  "id" : 544265641285255168,
  "created_at" : "2014-12-14 23:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544236648729296897\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/8Cf2fRFhl5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B41WX3rCUAApQqN.png",
      "id_str" : "544186098063134720",
      "id" : 544186098063134720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B41WX3rCUAApQqN.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8Cf2fRFhl5"
    } ],
    "hashtags" : [ {
      "text" : "1DayLeft",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544236648729296897",
  "text" : "Deadline Monday: #1DayLeft to sign up for a health plan that starts Jan. 1st \u2192 http:\/\/t.co\/NSeLHFvc62 #GetCovered http:\/\/t.co\/8Cf2fRFhl5",
  "id" : 544236648729296897,
  "created_at" : "2014-12-14 21:05:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/i3BJMMofoj",
      "expanded_url" : "http:\/\/JoiningForces.gov",
      "display_url" : "JoiningForces.gov"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Ay5UCNSAHi",
      "expanded_url" : "http:\/\/go.wh.gov\/RjrhpL",
      "display_url" : "go.wh.gov\/RjrhpL"
    } ]
  },
  "geo" : { },
  "id_str" : "544205242003238913",
  "text" : "\"There are so many ways we can express our gratitude to our troops\" \u2014President Obama: http:\/\/t.co\/i3BJMMofoj http:\/\/t.co\/Ay5UCNSAHi",
  "id" : 544205242003238913,
  "created_at" : "2014-12-14 19:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    }, {
      "text" : "1DayLeft",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/SWJYXEVVPv",
      "expanded_url" : "http:\/\/bit.ly\/1yNHBVh",
      "display_url" : "bit.ly\/1yNHBVh"
    } ]
  },
  "geo" : { },
  "id_str" : "544187656146415616",
  "text" : "RT @HHSGov: \"I had health insurance coverage for the following year all in about 10 minutes.\" http:\/\/t.co\/SWJYXEVVPv #GetCovered #1DayLeft",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 105, 116 ]
      }, {
        "text" : "1DayLeft",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/SWJYXEVVPv",
        "expanded_url" : "http:\/\/bit.ly\/1yNHBVh",
        "display_url" : "bit.ly\/1yNHBVh"
      } ]
    },
    "geo" : { },
    "id_str" : "544178767493480448",
    "text" : "\"I had health insurance coverage for the following year all in about 10 minutes.\" http:\/\/t.co\/SWJYXEVVPv #GetCovered #1DayLeft",
    "id" : 544178767493480448,
    "created_at" : "2014-12-14 17:15:03 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 544187656146415616,
  "created_at" : "2014-12-14 17:50:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/544182603893329920\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/t6G5WXXiyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B41RQu8CYAEq-Jw.png",
      "id_str" : "544180477901299713",
      "id" : 544180477901299713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B41RQu8CYAEq-Jw.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t6G5WXXiyI"
    } ],
    "hashtags" : [ {
      "text" : "1DayLeft",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "544182603893329920",
  "text" : "#1DayLeft to sign up for health coverage that starts on January 1st. #GetCovered at http:\/\/t.co\/NSeLHFvc62. http:\/\/t.co\/t6G5WXXiyI",
  "id" : 544182603893329920,
  "created_at" : "2014-12-14 17:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543918352914063360\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sjuli0t0or",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4v_dhaCAAIIhoc.png",
      "id_str" : "543809062677118978",
      "id" : 543809062677118978,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4v_dhaCAAIIhoc.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sjuli0t0or"
    } ],
    "hashtags" : [ {
      "text" : "2DaysLeft",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543918352914063360",
  "text" : "Deadline Monday: #2DaysLeft to sign up for a health plan that starts Jan. 1st \u2192 http:\/\/t.co\/NSeLHFvc62 #GetCovered http:\/\/t.co\/sjuli0t0or",
  "id" : 543918352914063360,
  "created_at" : "2014-12-14 00:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Ay5UCNSAHi",
      "expanded_url" : "http:\/\/go.wh.gov\/RjrhpL",
      "display_url" : "go.wh.gov\/RjrhpL"
    } ]
  },
  "geo" : { },
  "id_str" : "543888166650798082",
  "text" : "\"It\u2019s the holidays\u2014a season to give thanks for our many blessings.\" \u2014President Obama: http:\/\/t.co\/Ay5UCNSAHi",
  "id" : 543888166650798082,
  "created_at" : "2014-12-13 22:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543860457426014209\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/xAGN19vp6D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4v_GGVCIAA5r0D.png",
      "id_str" : "543808660271407104",
      "id" : 543808660271407104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4v_GGVCIAA5r0D.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xAGN19vp6D"
    } ],
    "hashtags" : [ {
      "text" : "2DaysLeft",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543860457426014209",
  "text" : "#2DaysLeft to sign up for health coverage that starts on January 1st. #GetCovered at http:\/\/t.co\/NSeLHFvc62. http:\/\/t.co\/xAGN19vp6D",
  "id" : 543860457426014209,
  "created_at" : "2014-12-13 20:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ay5UCNSAHi",
      "expanded_url" : "http:\/\/go.wh.gov\/RjrhpL",
      "display_url" : "go.wh.gov\/RjrhpL"
    } ]
  },
  "geo" : { },
  "id_str" : "543846327130415105",
  "text" : "\"Let\u2019s always keep striving to serve them as well as they\u2019ve always served us.\" \u2014President Obama on our veterans: http:\/\/t.co\/Ay5UCNSAHi",
  "id" : 543846327130415105,
  "created_at" : "2014-12-13 19:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Ay5UCNSAHi",
      "expanded_url" : "http:\/\/go.wh.gov\/RjrhpL",
      "display_url" : "go.wh.gov\/RjrhpL"
    } ]
  },
  "geo" : { },
  "id_str" : "543800081468489728",
  "text" : "\"No one sacrifices more to preserve our blessings than our extraordinary men and women in uniform.\" \u2014President Obama: http:\/\/t.co\/Ay5UCNSAHi",
  "id" : 543800081468489728,
  "created_at" : "2014-12-13 16:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 10, 18 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/hx9fiEIhU1",
      "expanded_url" : "http:\/\/go.wh.gov\/oXvpdw#section-rachel-carson",
      "display_url" : "go.wh.gov\/oXvpdw#section\u2026"
    }, {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/wGWcflTLMV",
      "expanded_url" : "http:\/\/go.wh.gov\/2B4t5g",
      "display_url" : "go.wh.gov\/2B4t5g"
    } ]
  },
  "geo" : { },
  "id_str" : "543508321144406016",
  "text" : "Listen to @GinaEPA discuss the legacy and impact of Rachel Carson \u2192 http:\/\/t.co\/hx9fiEIhU1 http:\/\/t.co\/wGWcflTLMV #WomenInSTEM",
  "id" : 543508321144406016,
  "created_at" : "2014-12-12 20:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543505831724351488",
  "text" : "RT @FLOTUS: \"Girls across the globe are counting on us to be bold and creative and to give them the opportunities they deserve.\" \u2014FLOTUS #G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GirlsEdu",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543473042853076993",
    "text" : "\"Girls across the globe are counting on us to be bold and creative and to give them the opportunities they deserve.\" \u2014FLOTUS #GirlsEdu",
    "id" : 543473042853076993,
    "created_at" : "2014-12-12 18:30:45 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 543505831724351488,
  "created_at" : "2014-12-12 20:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543496693044768769\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/7Bk84mi803",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4rjXK-CEAAZl-T.jpg",
      "id_str" : "543496692272599040",
      "id" : 543496692272599040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4rjXK-CEAAZl-T.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 5000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7Bk84mi803"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Gl1LZDz2f6",
      "expanded_url" : "http:\/\/go.wh.gov\/uLm1bN",
      "display_url" : "go.wh.gov\/uLm1bN"
    } ]
  },
  "geo" : { },
  "id_str" : "543496693044768769",
  "text" : "#WomenInSTEM unveiled the structure of DNA and their work led to the discovery of new genes: http:\/\/t.co\/Gl1LZDz2f6 http:\/\/t.co\/7Bk84mi803",
  "id" : 543496693044768769,
  "created_at" : "2014-12-12 20:04:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543472601415569408\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5BRYQN2exg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4rNc2OCIAAugpQ.jpg",
      "id_str" : "543472600525971456",
      "id" : 543472600525971456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4rNc2OCIAAugpQ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 5000
      } ],
      "display_url" : "pic.twitter.com\/5BRYQN2exg"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Gl1LZDz2f6",
      "expanded_url" : "http:\/\/go.wh.gov\/uLm1bN",
      "display_url" : "go.wh.gov\/uLm1bN"
    } ]
  },
  "geo" : { },
  "id_str" : "543472601415569408",
  "text" : "\"We can change the way history reports about women.\"\nHear the untold stories of #WomenInSTEM:  http:\/\/t.co\/Gl1LZDz2f6 http:\/\/t.co\/5BRYQN2exg",
  "id" : 543472601415569408,
  "created_at" : "2014-12-12 18:29:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHWeb\/status\/543449890828066816\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/rtiS0GINMh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4q4pApCQAAnUNg.jpg",
      "id_str" : "543449719737827328",
      "id" : 543449719737827328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4q4pApCQAAnUNg.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 958
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 958
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rtiS0GINMh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/V5q3kJmyml",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/women-in-stem",
      "display_url" : "whitehouse.gov\/women-in-stem"
    } ]
  },
  "geo" : { },
  "id_str" : "543451825291419650",
  "text" : "RT @WHWeb: The Untold History of Women in Science and Technology: http:\/\/t.co\/V5q3kJmyml http:\/\/t.co\/rtiS0GINMh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHWeb\/status\/543449890828066816\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/rtiS0GINMh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4q4pApCQAAnUNg.jpg",
        "id_str" : "543449719737827328",
        "id" : 543449719737827328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4q4pApCQAAnUNg.jpg",
        "sizes" : [ {
          "h" : 460,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rtiS0GINMh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/V5q3kJmyml",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/women-in-stem",
        "display_url" : "whitehouse.gov\/women-in-stem"
      } ]
    },
    "geo" : { },
    "id_str" : "543449890828066816",
    "text" : "The Untold History of Women in Science and Technology: http:\/\/t.co\/V5q3kJmyml http:\/\/t.co\/rtiS0GINMh",
    "id" : 543449890828066816,
    "created_at" : "2014-12-12 16:58:45 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 543451825291419650,
  "created_at" : "2014-12-12 17:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JointBaseMDL",
      "screen_name" : "jointbasemdl",
      "indices" : [ 3, 16 ],
      "id_str" : "170793861",
      "id" : 170793861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543443101025861632",
  "text" : "RT @jointbasemdl: POTUS is set to visit JB MDL and meet with military and DOD civilians Monday to express his gratitude for serving their n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543442779486314497",
    "text" : "POTUS is set to visit JB MDL and meet with military and DOD civilians Monday to express his gratitude for serving their nation on Monday.",
    "id" : 543442779486314497,
    "created_at" : "2014-12-12 16:30:29 +0000",
    "user" : {
      "name" : "JointBaseMDL",
      "screen_name" : "jointbasemdl",
      "protected" : false,
      "id_str" : "170793861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414128245252960256\/DpMoQ0V7_normal.png",
      "id" : 170793861,
      "verified" : false
    }
  },
  "id" : 543443101025861632,
  "created_at" : "2014-12-12 16:31:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543427875807191040\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/YF3vCdpkcS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4qksemCcAA9LFY.jpg",
      "id_str" : "543427789085372416",
      "id" : 543427789085372416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4qksemCcAA9LFY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YF3vCdpkcS"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JxkdfixJNs",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543427875807191040",
  "text" : "Need health coverage? Make sure your holiday to-do list includes \u270D for a plan at http:\/\/t.co\/JxkdfixJNs #GetCovered http:\/\/t.co\/YF3vCdpkcS",
  "id" : 543427875807191040,
  "created_at" : "2014-12-12 15:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543404449587552256\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/g7tYeDhrmb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4qPbohCMAADQxW.jpg",
      "id_str" : "543404409946779648",
      "id" : 543404409946779648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4qPbohCMAADQxW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g7tYeDhrmb"
    } ],
    "hashtags" : [ {
      "text" : "3DaysLeft",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/JxkdfixJNs",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543404449587552256",
  "text" : "#3DaysLeft to sign up for health coverage that starts on January 1st. #GetCovered at http:\/\/t.co\/JxkdfixJNs. http:\/\/t.co\/g7tYeDhrmb",
  "id" : 543404449587552256,
  "created_at" : "2014-12-12 13:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543186243702362114\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7AVXbKcIob",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4nI7o3CcAAawse.jpg",
      "id_str" : "543186156980957184",
      "id" : 543186156980957184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4nI7o3CcAAawse.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 5000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7AVXbKcIob"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/QGnsgvBvWS",
      "expanded_url" : "http:\/\/go.wh.gov\/hntrAs",
      "display_url" : "go.wh.gov\/hntrAs"
    } ]
  },
  "geo" : { },
  "id_str" : "543186243702362114",
  "text" : "Worth sharing: Women from across the Administration tell the untold history of #WomenInSTEM \u2192 http:\/\/t.co\/QGnsgvBvWS http:\/\/t.co\/7AVXbKcIob",
  "id" : 543186243702362114,
  "created_at" : "2014-12-11 23:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StudyAbroadBecause",
      "indices" : [ 12, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543154296120832000",
  "text" : "RT @FLOTUS: #StudyAbroadBecause you\u2019re not just changing your own life, you are changing the lives of everyone you meet. http:\/\/t.co\/hqIq3p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/543154173848453120\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/hqIq3pqTpZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4mrzbsCQAAas_0.jpg",
        "id_str" : "543154130168987648",
        "id" : 543154130168987648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4mrzbsCQAAas_0.jpg",
        "sizes" : [ {
          "h" : 734,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hqIq3pqTpZ"
      } ],
      "hashtags" : [ {
        "text" : "StudyAbroadBecause",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543154173848453120",
    "text" : "#StudyAbroadBecause you\u2019re not just changing your own life, you are changing the lives of everyone you meet. http:\/\/t.co\/hqIq3pqTpZ",
    "id" : 543154173848453120,
    "created_at" : "2014-12-11 21:23:41 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 543154296120832000,
  "created_at" : "2014-12-11 21:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "indices" : [ 3, 12 ],
      "id_str" : "262388975",
      "id" : 262388975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 80, 90 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/6y2Jurt2et",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543134428407410689",
  "text" : "RT @DuleHill: 14 days left until Christmas, 20 days left until the New Year and #4DaysLeft to #GetCovered http:\/\/t.co\/6y2Jurt2et",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4DaysLeft",
        "indices" : [ 66, 76 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/6y2Jurt2et",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "543106631442378754",
    "text" : "14 days left until Christmas, 20 days left until the New Year and #4DaysLeft to #GetCovered http:\/\/t.co\/6y2Jurt2et",
    "id" : 543106631442378754,
    "created_at" : "2014-12-11 18:14:46 +0000",
    "user" : {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "protected" : false,
      "id_str" : "262388975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780784540390264832\/k8smqjX2_normal.jpg",
      "id" : 262388975,
      "verified" : true
    }
  },
  "id" : 543134428407410689,
  "created_at" : "2014-12-11 20:05:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4DdaysLeft",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543125367825776640",
  "text" : "RT @UncleRUSH: Do you have health care? You have #4DdaysLeft to sign up for coverage that begins January 1. #GetCovered at http:\/\/t.co\/KTvR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4DdaysLeft",
        "indices" : [ 34, 45 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/KTvRvOTID6",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "543118498927771648",
    "text" : "Do you have health care? You have #4DdaysLeft to sign up for coverage that begins January 1. #GetCovered at http:\/\/t.co\/KTvRvOTID6",
    "id" : 543118498927771648,
    "created_at" : "2014-12-11 19:01:55 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 543125367825776640,
  "created_at" : "2014-12-11 19:29:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/wAc4kyNHRI",
      "expanded_url" : "http:\/\/bit.ly\/1DcsCMx",
      "display_url" : "bit.ly\/1DcsCMx"
    } ]
  },
  "geo" : { },
  "id_str" : "543121879955804160",
  "text" : "RT @HHSGov: #4DaysLeft: Join Rusk and millions others - explore your options and #GetCovered for 2015! http:\/\/t.co\/wAc4kyNHRI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4DaysLeft",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 69, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/wAc4kyNHRI",
        "expanded_url" : "http:\/\/bit.ly\/1DcsCMx",
        "display_url" : "bit.ly\/1DcsCMx"
      } ]
    },
    "geo" : { },
    "id_str" : "543104267033124864",
    "text" : "#4DaysLeft: Join Rusk and millions others - explore your options and #GetCovered for 2015! http:\/\/t.co\/wAc4kyNHRI",
    "id" : 543104267033124864,
    "created_at" : "2014-12-11 18:05:22 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 543121879955804160,
  "created_at" : "2014-12-11 19:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lance Bass",
      "screen_name" : "LanceBass",
      "indices" : [ 3, 13 ],
      "id_str" : "78693749",
      "id" : 78693749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "4DaysLeft",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/i2CamougUF",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543119137975709696",
  "text" : "RT @LanceBass: Have a 2014 plan? Take action \u2013 keep or change your plan by December 15 at http:\/\/t.co\/i2CamougUF #GetCovered #4DaysLeft",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "4DaysLeft",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/i2CamougUF",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "543077089004380161",
    "text" : "Have a 2014 plan? Take action \u2013 keep or change your plan by December 15 at http:\/\/t.co\/i2CamougUF #GetCovered #4DaysLeft",
    "id" : 543077089004380161,
    "created_at" : "2014-12-11 16:17:22 +0000",
    "user" : {
      "name" : "Lance Bass",
      "screen_name" : "LanceBass",
      "protected" : false,
      "id_str" : "78693749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796450038679412736\/U_oDvNzD_normal.jpg",
      "id" : 78693749,
      "verified" : true
    }
  },
  "id" : 543119137975709696,
  "created_at" : "2014-12-11 19:04:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "indices" : [ 3, 18 ],
      "id_str" : "20196258",
      "id" : 20196258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/JULo8qayFm",
      "expanded_url" : "http:\/\/Heathcare.gov",
      "display_url" : "Heathcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543112642156445696",
  "text" : "RT @ElizabethBanks: Just a reminder, RE: Heathcare, I'm a big fan. #4DaysLeft to #GetCovered at http:\/\/t.co\/JULo8qayFm -- your body will th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4DaysLeft",
        "indices" : [ 47, 57 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/JULo8qayFm",
        "expanded_url" : "http:\/\/Heathcare.gov",
        "display_url" : "Heathcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "543110845559877633",
    "text" : "Just a reminder, RE: Heathcare, I'm a big fan. #4DaysLeft to #GetCovered at http:\/\/t.co\/JULo8qayFm -- your body will thank you.",
    "id" : 543110845559877633,
    "created_at" : "2014-12-11 18:31:30 +0000",
    "user" : {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "protected" : false,
      "id_str" : "20196258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791454824306880512\/YiAb44jE_normal.jpg",
      "id" : 20196258,
      "verified" : true
    }
  },
  "id" : 543112642156445696,
  "created_at" : "2014-12-11 18:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543089751859789824\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MZKFxlyFOJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4lw3AaCAAEO64Q.jpg",
      "id_str" : "543089320379154433",
      "id" : 543089320379154433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4lw3AaCAAEO64Q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MZKFxlyFOJ"
    } ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "543089751859789824",
  "text" : "Need health coverage that starts on Jan. 1st? You've got #4DaysLeft to sign up \u2192 http:\/\/t.co\/NSeLHFvc62 #GetCovered http:\/\/t.co\/MZKFxlyFOJ",
  "id" : 543089751859789824,
  "created_at" : "2014-12-11 17:07:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543082526294552577",
  "text" : "RT @WHLive: \"Today, my Secretary of Labor is announcing a $100 million competition to help expand apprenticeship programs across our countr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543082491762839553",
    "text" : "\"Today, my Secretary of Labor is announcing a $100 million competition to help expand apprenticeship programs across our country.\" \u2014Obama",
    "id" : 543082491762839553,
    "created_at" : "2014-12-11 16:38:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 543082526294552577,
  "created_at" : "2014-12-11 16:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543082445910712320",
  "text" : "RT @WHLive: \"We\u2019re announcing today more than $290 million in new investments to launch two additional high-tech manufacturing hubs.\" \u2014Pres\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "543082368840392705",
    "text" : "\"We\u2019re announcing today more than $290 million in new investments to launch two additional high-tech manufacturing hubs.\" \u2014President Obama",
    "id" : 543082368840392705,
    "created_at" : "2014-12-11 16:38:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 543082445910712320,
  "created_at" : "2014-12-11 16:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543082134160687104\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NzebcVivkI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4lqUWoCIAIkCjp.jpg",
      "id_str" : "543082127978274818",
      "id" : 543082127978274818,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4lqUWoCIAIkCjp.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/NzebcVivkI"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543082134160687104",
  "text" : "\"Exports support more than 11 million American jobs, typically\u2026jobs that pay higher wages.\" \u2014Obama #MadeInAmerica http:\/\/t.co\/NzebcVivkI",
  "id" : 543082134160687104,
  "created_at" : "2014-12-11 16:37:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543081892614905856\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/wCc1NKn7mL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4lqEcyCcAAh2CW.jpg",
      "id_str" : "543081854752944128",
      "id" : 543081854752944128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4lqEcyCcAAh2CW.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wCc1NKn7mL"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543081892614905856",
  "text" : "\"Last year, our businesses sold a record $2.3 trillion of #MadeInAmerica goods and services.\" \u2014President Obama http:\/\/t.co\/wCc1NKn7mL",
  "id" : 543081892614905856,
  "created_at" : "2014-12-11 16:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543081569687056384",
  "text" : "\"This year, our economy has already created more jobs than any year since the 1990s\u2014with still a month to go.\" \u2014Obama #MadeInAmerica",
  "id" : 543081569687056384,
  "created_at" : "2014-12-11 16:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/543081382667227137\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/MxkegmjKUt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4lpKtMCcAAWWgp.jpg",
      "id_str" : "543080862724550656",
      "id" : 543080862724550656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4lpKtMCcAAWWgp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MxkegmjKUt"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543081382667227137",
  "text" : "\"Our businesses have added almost 11 million jobs over the past 57 months.\" \u2014President Obama #MadeInAmerica http:\/\/t.co\/MxkegmjKUt",
  "id" : 543081382667227137,
  "created_at" : "2014-12-11 16:34:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/qhdLP6CWcv",
      "expanded_url" : "http:\/\/go.wh.gov\/FrayD9",
      "display_url" : "go.wh.gov\/FrayD9"
    } ]
  },
  "geo" : { },
  "id_str" : "543080719778463744",
  "text" : "Watch live: President Obama announces new steps to boost American manufacturing and apprenticeships \u2192 http:\/\/t.co\/qhdLP6CWcv #MadeInAmerica",
  "id" : 543080719778463744,
  "created_at" : "2014-12-11 16:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 15, 20 ],
      "id_str" : "14293310",
      "id" : 14293310
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 32, 41 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/542719054738251776\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/cFEFQe3Cmx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ggGqfCAAEl0_4.jpg",
      "id_str" : "542719053953892353",
      "id" : 542719053953892353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ggGqfCAAEl0_4.jpg",
      "sizes" : [ {
        "h" : 1281,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 641,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cFEFQe3Cmx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/B7yy4z1Fa9",
      "expanded_url" : "http:\/\/on.doi.gov\/1zvsIL4",
      "display_url" : "on.doi.gov\/1zvsIL4"
    } ]
  },
  "geo" : { },
  "id_str" : "543077920290267137",
  "text" : "RT @Interior: .@TIME highlights @Interior's most popular Instagram photos in 2014  http:\/\/t.co\/B7yy4z1Fa9 http:\/\/t.co\/cFEFQe3Cmx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TIME",
        "screen_name" : "TIME",
        "indices" : [ 1, 6 ],
        "id_str" : "14293310",
        "id" : 14293310
      }, {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 18, 27 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/542719054738251776\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/cFEFQe3Cmx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ggGqfCAAEl0_4.jpg",
        "id_str" : "542719053953892353",
        "id" : 542719053953892353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ggGqfCAAEl0_4.jpg",
        "sizes" : [ {
          "h" : 1281,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 641,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cFEFQe3Cmx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/B7yy4z1Fa9",
        "expanded_url" : "http:\/\/on.doi.gov\/1zvsIL4",
        "display_url" : "on.doi.gov\/1zvsIL4"
      } ]
    },
    "geo" : { },
    "id_str" : "542719054738251776",
    "text" : ".@TIME highlights @Interior's most popular Instagram photos in 2014  http:\/\/t.co\/B7yy4z1Fa9 http:\/\/t.co\/cFEFQe3Cmx",
    "id" : 542719054738251776,
    "created_at" : "2014-12-10 16:34:40 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 543077920290267137,
  "created_at" : "2014-12-11 16:20:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BjA3JMe91G",
      "expanded_url" : "http:\/\/go.wh.gov\/2FtXHo",
      "display_url" : "go.wh.gov\/2FtXHo"
    } ]
  },
  "geo" : { },
  "id_str" : "543069965440405505",
  "text" : "Find out how President Obama's working with the private sector to boost American manufacturing and apprenticeships: http:\/\/t.co\/BjA3JMe91G",
  "id" : 543069965440405505,
  "created_at" : "2014-12-11 15:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542895555987656704",
  "text" : "RT @vj44: When we invest in kids like Alajah, we're investing in our future. Today's Summit on Early Ed is just the beginning! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/542856210358476800\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/X5gs4W3Nd5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ic1zICIAAlFRK.jpg",
        "id_str" : "542856203169046528",
        "id" : 542856203169046528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ic1zICIAAlFRK.jpg",
        "sizes" : [ {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/X5gs4W3Nd5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542856210358476800",
    "text" : "When we invest in kids like Alajah, we're investing in our future. Today's Summit on Early Ed is just the beginning! http:\/\/t.co\/X5gs4W3Nd5",
    "id" : 542856210358476800,
    "created_at" : "2014-12-11 01:39:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 542895555987656704,
  "created_at" : "2014-12-11 04:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NobelPeacePrize",
      "indices" : [ 105, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542850269956947969",
  "text" : "RT @FLOTUS: Today, we celebrate Malala and Kailash's courage. We are so proud of them as they accept the #NobelPeacePrize. http:\/\/t.co\/XgR4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/542848488535379968\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/XgR41omkwp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4iVqXvCEAAsMwj.jpg",
        "id_str" : "542848310256472064",
        "id" : 542848310256472064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4iVqXvCEAAsMwj.jpg",
        "sizes" : [ {
          "h" : 673,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/XgR41omkwp"
      } ],
      "hashtags" : [ {
        "text" : "NobelPeacePrize",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542848488535379968",
    "text" : "Today, we celebrate Malala and Kailash's courage. We are so proud of them as they accept the #NobelPeacePrize. http:\/\/t.co\/XgR41omkwp",
    "id" : 542848488535379968,
    "created_at" : "2014-12-11 01:08:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 542850269956947969,
  "created_at" : "2014-12-11 01:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542842355556962304\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/W3SKKFSwqo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4iQMqVCEAAor6t.jpg",
      "id_str" : "542842302293479424",
      "id" : 542842302293479424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4iQMqVCEAAor6t.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/W3SKKFSwqo"
    } ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/R0m89QoG9C",
      "expanded_url" : "http:\/\/go.wh.gov\/AaYC9E",
      "display_url" : "go.wh.gov\/AaYC9E"
    } ]
  },
  "geo" : { },
  "id_str" : "542842355556962304",
  "text" : "\"Early education is one of the best investments we can make.\" \u2014President Obama: http:\/\/t.co\/R0m89QoG9C #InvestInUs http:\/\/t.co\/W3SKKFSwqo",
  "id" : 542842355556962304,
  "created_at" : "2014-12-11 00:44:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/i0A7qYm2rx",
      "expanded_url" : "http:\/\/wh.gov\/i1GWU",
      "display_url" : "wh.gov\/i1GWU"
    } ]
  },
  "geo" : { },
  "id_str" : "542836512224587777",
  "text" : "RT @FLOTUS: Bo\u2019s burrrry excited for the @WhiteHouse Holiday Social. Apply to attend \u2192 http:\/\/t.co\/i0A7qYm2rx #WHHolidays http:\/\/t.co\/S5mPK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 29, 40 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/542836221576093696\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/S5mPKEe1Ll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4hvUYOCEAAtRhg.jpg",
        "id_str" : "542806150987517952",
        "id" : 542806150987517952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4hvUYOCEAAtRhg.jpg",
        "sizes" : [ {
          "h" : 381,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/S5mPKEe1Ll"
      } ],
      "hashtags" : [ {
        "text" : "WHHolidays",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/i0A7qYm2rx",
        "expanded_url" : "http:\/\/wh.gov\/i1GWU",
        "display_url" : "wh.gov\/i1GWU"
      } ]
    },
    "geo" : { },
    "id_str" : "542836221576093696",
    "text" : "Bo\u2019s burrrry excited for the @WhiteHouse Holiday Social. Apply to attend \u2192 http:\/\/t.co\/i0A7qYm2rx #WHHolidays http:\/\/t.co\/S5mPKEe1Ll",
    "id" : 542836221576093696,
    "created_at" : "2014-12-11 00:20:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 542836512224587777,
  "created_at" : "2014-12-11 00:21:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "PreK4All",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/NnkdN3a5U1",
      "expanded_url" : "http:\/\/youtu.be\/ey8lmvtu9Qg",
      "display_url" : "youtu.be\/ey8lmvtu9Qg"
    } ]
  },
  "geo" : { },
  "id_str" : "542811876422205440",
  "text" : "\"Every child should be given the chance at a strong start in life.\" \u2014Jennifer Garner: http:\/\/t.co\/NnkdN3a5U1 #InvestInUs #PreK4All",
  "id" : 542811876422205440,
  "created_at" : "2014-12-10 22:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542797220358017025\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/svTAfjwGmd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4hm--PCEAAUoaj.jpg",
      "id_str" : "542796987142115328",
      "id" : 542796987142115328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4hm--PCEAAUoaj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/svTAfjwGmd"
    } ],
    "hashtags" : [ {
      "text" : "5DaysLeft",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "542797220358017025",
  "text" : "#5DaysLeft to sign up for health coverage that starts on January 1st.\n#GetCovered at http:\/\/t.co\/NSeLHFvc62. http:\/\/t.co\/svTAfjwGmd",
  "id" : 542797220358017025,
  "created_at" : "2014-12-10 21:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Legend",
      "screen_name" : "johnlegend",
      "indices" : [ 61, 72 ],
      "id_str" : "18228898",
      "id" : 18228898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/eySZ5JkjCw",
      "expanded_url" : "http:\/\/youtu.be\/ZDtYDu9vROQ",
      "display_url" : "youtu.be\/ZDtYDu9vROQ"
    } ]
  },
  "geo" : { },
  "id_str" : "542789251616620548",
  "text" : "\"I want to help our children achieve their full potential.\" \u2014@JohnLegend on early childhood education: http:\/\/t.co\/eySZ5JkjCw #InvestInUs",
  "id" : 542789251616620548,
  "created_at" : "2014-12-10 21:13:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/zYecrl2jcf",
      "expanded_url" : "http:\/\/InvestInUs.org",
      "display_url" : "InvestInUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "542781599884906497",
  "text" : "Check out today's new commitments to expand access to early childhood education \u2192 http:\/\/t.co\/zYecrl2jcf #InvestInUs",
  "id" : 542781599884906497,
  "created_at" : "2014-12-10 20:43:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542775928053448704",
  "text" : "RT @VP: \"We should continue pushing Congress to pass the President\u2019s Preschool for All proposal.\" -VP Biden #InvestInUs http:\/\/t.co\/F9ZqAjX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/542770931878617088\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/F9ZqAjXCzb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4hPSQ4CMAEN9-e.png",
        "id_str" : "542770930284376065",
        "id" : 542770930284376065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4hPSQ4CMAEN9-e.png",
        "sizes" : [ {
          "h" : 509,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/F9ZqAjXCzb"
      } ],
      "hashtags" : [ {
        "text" : "InvestInUs",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542770931878617088",
    "text" : "\"We should continue pushing Congress to pass the President\u2019s Preschool for All proposal.\" -VP Biden #InvestInUs http:\/\/t.co\/F9ZqAjXCzb",
    "id" : 542770931878617088,
    "created_at" : "2014-12-10 20:00:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 542775928053448704,
  "created_at" : "2014-12-10 20:20:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 32, 39 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 40, 47 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USPHS",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "Ebola",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "TimePersonOfTheYear",
      "indices" : [ 123, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542765478955868160",
  "text" : "RT @SecBurwell: Proud of #USPHS @HHSgov @CDCgov &amp; health care workers around the world, courageously combating #Ebola. #TimePersonOfTheYear\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 16, 23 ],
        "id_str" : "44783853",
        "id" : 44783853
      }, {
        "name" : "CDC",
        "screen_name" : "CDCgov",
        "indices" : [ 24, 31 ],
        "id_str" : "146569971",
        "id" : 146569971
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USPHS",
        "indices" : [ 9, 15 ]
      }, {
        "text" : "Ebola",
        "indices" : [ 99, 105 ]
      }, {
        "text" : "TimePersonOfTheYear",
        "indices" : [ 107, 127 ]
      }, {
        "text" : "WellDeserved",
        "indices" : [ 128, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542759765336928256",
    "text" : "Proud of #USPHS @HHSgov @CDCgov &amp; health care workers around the world, courageously combating #Ebola. #TimePersonOfTheYear #WellDeserved",
    "id" : 542759765336928256,
    "created_at" : "2014-12-10 19:16:26 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 542765478955868160,
  "created_at" : "2014-12-10 19:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542752542661148673",
  "text" : "\"Since it started in the 1940s, Toys for Tots has distributed more than 469 million toys to more than 216 million children\" \u2014President Obama",
  "id" : 542752542661148673,
  "created_at" : "2014-12-10 18:47:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 60, 65 ],
      "id_str" : "10126672",
      "id" : 10126672
    }, {
      "name" : "Toys for Tots",
      "screen_name" : "ToysForTots_USA",
      "indices" : [ 68, 84 ],
      "id_str" : "1704989844",
      "id" : 1704989844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/yYIhkvReXr",
      "expanded_url" : "http:\/\/go.wh.gov\/bnHJE8",
      "display_url" : "go.wh.gov\/bnHJE8"
    } ]
  },
  "geo" : { },
  "id_str" : "542751435058737152",
  "text" : "Watch live: President Obama and @FLOTUS deliver toys to the @USMC's @ToysForTots_USA campaign \u2192 http:\/\/t.co\/yYIhkvReXr",
  "id" : 542751435058737152,
  "created_at" : "2014-12-10 18:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/a3ExXmG6IG",
      "expanded_url" : "http:\/\/snpy.tv\/1ByQCrq",
      "display_url" : "snpy.tv\/1ByQCrq"
    } ]
  },
  "geo" : { },
  "id_str" : "542736012326100992",
  "text" : "\"When I grow up, I want to be the First Lady.\" \u20143rd-grader Alajah before introducing President Obama #InvestInUs http:\/\/t.co\/a3ExXmG6IG",
  "id" : 542736012326100992,
  "created_at" : "2014-12-10 17:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/zYecrl2jcf",
      "expanded_url" : "http:\/\/InvestInUs.org",
      "display_url" : "InvestInUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "542728858806403073",
  "text" : "\"All told, the organizations here today are making more than $330 million in new commitments.\" \u2014Obama: http:\/\/t.co\/zYecrl2jcf #InvestInUs",
  "id" : 542728858806403073,
  "created_at" : "2014-12-10 17:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disney",
      "screen_name" : "Disney",
      "indices" : [ 1, 8 ],
      "id_str" : "67418441",
      "id" : 67418441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/zYecrl2jcf",
      "expanded_url" : "http:\/\/InvestInUs.org",
      "display_url" : "InvestInUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "542728625183682560",
  "text" : "\"@Disney is giving away $55 million worth of books and apps for young learners.\" \u2014President Obama: http:\/\/t.co\/zYecrl2jcf #InvestInUs",
  "id" : 542728625183682560,
  "created_at" : "2014-12-10 17:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542727484962136065",
  "text" : "RT @WHLive: \"I\u2019m pleased to announce that my Administration will award $750 million of new investments in our youngest Americans.\" \u2014Obama #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvestInUs",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542727458479288320",
    "text" : "\"I\u2019m pleased to announce that my Administration will award $750 million of new investments in our youngest Americans.\" \u2014Obama #InvestInUs",
    "id" : 542727458479288320,
    "created_at" : "2014-12-10 17:08:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 542727484962136065,
  "created_at" : "2014-12-10 17:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542727089938382848",
  "text" : "\"Early education is a win for everybody. It saves taxpayer dollars. It gives our kids a better chance.\" \u2014President Obama #InvestInUs",
  "id" : 542727089938382848,
  "created_at" : "2014-12-10 17:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542726883423449088\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/DH5zfBI5jQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4gnOCBCcAAV3Kd.jpg",
      "id_str" : "542726877111021568",
      "id" : 542726877111021568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4gnOCBCcAAV3Kd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DH5zfBI5jQ"
    } ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542726883423449088",
  "text" : "\"For every $1 we invest now, we can save more than $8 later on\" \u2014Obama on investing in early education #InvestInUs http:\/\/t.co\/DH5zfBI5jQ",
  "id" : 542726883423449088,
  "created_at" : "2014-12-10 17:05:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542726413799792640",
  "text" : "\"Early education is one of the best investments we can make\u2014not just in our child\u2019s future\u2014but in our country\" \u2014President Obama #InvestInUs",
  "id" : 542726413799792640,
  "created_at" : "2014-12-10 17:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542726110329311232",
  "text" : "\"Children who get a high-quality early education earn more over their lifetimes than their peers who don\u2019t.\" \u2014President Obama #InvestInUs",
  "id" : 542726110329311232,
  "created_at" : "2014-12-10 17:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542726004515422211",
  "text" : "\"This is the essential promise of America\u2014that where you start should not determine how far you go.\" \u2014President Obama #InvestInUs",
  "id" : 542726004515422211,
  "created_at" : "2014-12-10 17:02:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542725752509059072",
  "text" : "RT @WHLive: \"Over the last four years, America has put more people back to work than Europe, Japan, and every other advanced economy combin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542725660800606208",
    "text" : "\"Over the last four years, America has put more people back to work than Europe, Japan, and every other advanced economy combined.\" \u2014Obama",
    "id" : 542725660800606208,
    "created_at" : "2014-12-10 17:00:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 542725752509059072,
  "created_at" : "2014-12-10 17:01:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542725602361356288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/YppT4Q2X7q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4gmCqBCQAA6k4D.jpg",
      "id_str" : "542725582178369536",
      "id" : 542725582178369536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4gmCqBCQAA6k4D.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YppT4Q2X7q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542725602361356288",
  "text" : "\"Over the first 11 months of 2014, our economy has created more jobs than in any full year since the 1990s.\" \u2014Obama http:\/\/t.co\/YppT4Q2X7q",
  "id" : 542725602361356288,
  "created_at" : "2014-12-10 17:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/LVA3rpd84i",
      "expanded_url" : "http:\/\/go.wh.gov\/aamw2R",
      "display_url" : "go.wh.gov\/aamw2R"
    } ]
  },
  "geo" : { },
  "id_str" : "542725083366584321",
  "text" : "Watch live: President Obama speaks at the White House Summit on Early Childhood Education \u2192 http:\/\/t.co\/LVA3rpd84i #InvestInUs",
  "id" : 542725083366584321,
  "created_at" : "2014-12-10 16:58:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 6, 14 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/gclAgYzZaA",
      "expanded_url" : "http:\/\/youtu.be\/kdL25NNM0Xk",
      "display_url" : "youtu.be\/kdL25NNM0Xk"
    } ]
  },
  "geo" : { },
  "id_str" : "542720374035591168",
  "text" : "Watch @Shakira's video on the importance of investing in early childhood education \u2192 http:\/\/t.co\/gclAgYzZaA #InvestInUs",
  "id" : 542720374035591168,
  "created_at" : "2014-12-10 16:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 67, 75 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 80, 91 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInUs",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/LVA3rpd84i",
      "expanded_url" : "http:\/\/go.wh.gov\/aamw2R",
      "display_url" : "go.wh.gov\/aamw2R"
    } ]
  },
  "geo" : { },
  "id_str" : "542716928259665920",
  "text" : "Before President Obama speaks at today's #InvestInUs Summit, recap @Shakira and @ArneDuncan's early education Q&amp;A: http:\/\/t.co\/LVA3rpd84i",
  "id" : 542716928259665920,
  "created_at" : "2014-12-10 16:26:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542704490277634049",
  "text" : "RT @shakira: Thanks to everyone for participating and your thoughtful questions and input. -Shak #ShakiraEdChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 84, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542704193354862592",
    "text" : "Thanks to everyone for participating and your thoughtful questions and input. -Shak #ShakiraEdChat",
    "id" : 542704193354862592,
    "created_at" : "2014-12-10 15:35:37 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542704490277634049,
  "created_at" : "2014-12-10 15:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542703838088552448",
  "text" : "RT @shakira: Preschool costs ~ $8k per year per child. Juvenile detention costs ~ $90k per year per child. Again-numbers don\u2019t lie. #Shakir\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 119, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542703509012250626",
    "text" : "Preschool costs ~ $8k per year per child. Juvenile detention costs ~ $90k per year per child. Again-numbers don\u2019t lie. #ShakiraEdChat",
    "id" : 542703509012250626,
    "created_at" : "2014-12-10 15:32:54 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542703838088552448,
  "created_at" : "2014-12-10 15:34:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 88, 96 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ECE",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542703075954139136",
  "text" : "RT @arneduncan: Thank you everyone for the great questions today &amp; a huge thanks to @Shakira for her leadership &amp; passion for #ECE. #Shakir\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shakira",
        "screen_name" : "shakira",
        "indices" : [ 72, 80 ],
        "id_str" : "44409004",
        "id" : 44409004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ECE",
        "indices" : [ 118, 122 ]
      }, {
        "text" : "ShakiraEdChat",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542703012657909760",
    "text" : "Thank you everyone for the great questions today &amp; a huge thanks to @Shakira for her leadership &amp; passion for #ECE. #ShakiraEdChat",
    "id" : 542703012657909760,
    "created_at" : "2014-12-10 15:30:55 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 542703075954139136,
  "created_at" : "2014-12-10 15:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Pema DL",
      "screen_name" : "Its_Pema",
      "indices" : [ 14, 23 ],
      "id_str" : "315116451",
      "id" : 315116451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542702201613733888",
  "text" : "RT @shakira: .@Its_Pema poverty is perpetuated by the lack of opportunities like universal access to quality ed. Education is a birthright-\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pema DL",
        "screen_name" : "Its_Pema",
        "indices" : [ 1, 10 ],
        "id_str" : "315116451",
        "id" : 315116451
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542699679440326656",
    "geo" : { },
    "id_str" : "542701611081289729",
    "in_reply_to_user_id" : 315116451,
    "text" : ".@Its_Pema poverty is perpetuated by the lack of opportunities like universal access to quality ed. Education is a birthright-not a luxury",
    "id" : 542701611081289729,
    "in_reply_to_status_id" : 542699679440326656,
    "created_at" : "2014-12-10 15:25:21 +0000",
    "in_reply_to_screen_name" : "Its_Pema",
    "in_reply_to_user_id_str" : "315116451",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542702201613733888,
  "created_at" : "2014-12-10 15:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Keith Daniel Hardy",
      "screen_name" : "keithdhardy",
      "indices" : [ 14, 26 ],
      "id_str" : "2492493601",
      "id" : 2492493601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542702092008189952",
  "text" : "RT @shakira: .@keithdhardy spending time with their kids, sending them to school early, giving them nutrition, stimulation and love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Daniel Hardy",
        "screen_name" : "keithdhardy",
        "indices" : [ 1, 13 ],
        "id_str" : "2492493601",
        "id" : 2492493601
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542551041376415745",
    "geo" : { },
    "id_str" : "542701365508976641",
    "in_reply_to_user_id" : 2492493601,
    "text" : ".@keithdhardy spending time with their kids, sending them to school early, giving them nutrition, stimulation and love",
    "id" : 542701365508976641,
    "in_reply_to_status_id" : 542551041376415745,
    "created_at" : "2014-12-10 15:24:23 +0000",
    "in_reply_to_screen_name" : "keithdhardy",
    "in_reply_to_user_id_str" : "2492493601",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542702092008189952,
  "created_at" : "2014-12-10 15:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542700450122698752",
  "text" : "RT @shakira: .@saleosol education turns kids into productive citizens, is proven to boost GDPs of nations, and promotes global security and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542700268438450176",
    "text" : ".@saleosol education turns kids into productive citizens, is proven to boost GDPs of nations, and promotes global security and stability.",
    "id" : 542700268438450176,
    "created_at" : "2014-12-10 15:20:01 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542700450122698752,
  "created_at" : "2014-12-10 15:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542699892829741057",
  "text" : "RT @arneduncan: .@LaurenEBarwick Zip code &amp; family background should never determine ed quality. Education must be the great equalizer #Sha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542699266922123264",
    "text" : ".@LaurenEBarwick Zip code &amp; family background should never determine ed quality. Education must be the great equalizer #ShakiraEdChat",
    "id" : 542699266922123264,
    "created_at" : "2014-12-10 15:16:02 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 542699892829741057,
  "created_at" : "2014-12-10 15:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Jay Darcy | JaMaaL",
      "screen_name" : "theonlywayisjam",
      "indices" : [ 14, 30 ],
      "id_str" : "341098850",
      "id" : 341098850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542699442822868992",
  "text" : "RT @shakira: .@theonlywayisjam growing up surrounded by inequality made me intolerant to it, &amp; research showed me that education was the so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jay Darcy | JaMaaL",
        "screen_name" : "theonlywayisjam",
        "indices" : [ 1, 17 ],
        "id_str" : "341098850",
        "id" : 341098850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542589357799243776",
    "geo" : { },
    "id_str" : "542699158243930112",
    "in_reply_to_user_id" : 341098850,
    "text" : ".@theonlywayisjam growing up surrounded by inequality made me intolerant to it, &amp; research showed me that education was the solution to it",
    "id" : 542699158243930112,
    "in_reply_to_status_id" : 542589357799243776,
    "created_at" : "2014-12-10 15:15:36 +0000",
    "in_reply_to_screen_name" : "theonlywayisjam",
    "in_reply_to_user_id_str" : "341098850",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542699442822868992,
  "created_at" : "2014-12-10 15:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Josh Stumpenhorst",
      "screen_name" : "stumpteacher",
      "indices" : [ 14, 27 ],
      "id_str" : "160354526",
      "id" : 160354526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542698771654533120",
  "text" : "RT @shakira: .@stumpteacher babies have an innate thirst for knowledge and enjoy learning-making it fun through focused play is another way\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Stumpenhorst",
        "screen_name" : "stumpteacher",
        "indices" : [ 1, 14 ],
        "id_str" : "160354526",
        "id" : 160354526
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542383394282156032",
    "geo" : { },
    "id_str" : "542698520118321152",
    "in_reply_to_user_id" : 160354526,
    "text" : ".@stumpteacher babies have an innate thirst for knowledge and enjoy learning-making it fun through focused play is another way of bonding.",
    "id" : 542698520118321152,
    "in_reply_to_status_id" : 542383394282156032,
    "created_at" : "2014-12-10 15:13:04 +0000",
    "in_reply_to_screen_name" : "stumpteacher",
    "in_reply_to_user_id_str" : "160354526",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542698771654533120,
  "created_at" : "2014-12-10 15:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Chris",
      "screen_name" : "CO7649",
      "indices" : [ 14, 21 ],
      "id_str" : "2328100400",
      "id" : 2328100400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542698421136527361",
  "text" : "RT @shakira: .@CO7649 Every $1 invested in early ed for disadvantaged kids has a return of at least 10% &amp; reduces social spending. Numbers \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris",
        "screen_name" : "CO7649",
        "indices" : [ 1, 8 ],
        "id_str" : "2328100400",
        "id" : 2328100400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542391927996293120",
    "geo" : { },
    "id_str" : "542698298038296576",
    "in_reply_to_user_id" : 2328100400,
    "text" : ".@CO7649 Every $1 invested in early ed for disadvantaged kids has a return of at least 10% &amp; reduces social spending. Numbers don\u2019t lie!",
    "id" : 542698298038296576,
    "in_reply_to_status_id" : 542391927996293120,
    "created_at" : "2014-12-10 15:12:11 +0000",
    "in_reply_to_screen_name" : "CO7649",
    "in_reply_to_user_id_str" : "2328100400",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542698421136527361,
  "created_at" : "2014-12-10 15:12:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Jennifer McCann",
      "screen_name" : "JenniferGianola",
      "indices" : [ 17, 33 ],
      "id_str" : "87323080",
      "id" : 87323080
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ECE",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542697658238775297",
  "text" : "RT @arneduncan: .@JenniferGianola 100s of biz leaders &amp; CEOs across the country are stepping up to support #ECE. Their voice is critical. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer McCann",
        "screen_name" : "JenniferGianola",
        "indices" : [ 1, 17 ],
        "id_str" : "87323080",
        "id" : 87323080
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ECE",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "ShakiraEdChat",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542675998123106305",
    "geo" : { },
    "id_str" : "542697525137117184",
    "in_reply_to_user_id" : 87323080,
    "text" : ".@JenniferGianola 100s of biz leaders &amp; CEOs across the country are stepping up to support #ECE. Their voice is critical. #ShakiraEdChat",
    "id" : 542697525137117184,
    "in_reply_to_status_id" : 542675998123106305,
    "created_at" : "2014-12-10 15:09:07 +0000",
    "in_reply_to_screen_name" : "JenniferGianola",
    "in_reply_to_user_id_str" : "87323080",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 542697658238775297,
  "created_at" : "2014-12-10 15:09:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Keith Daniel Hardy",
      "screen_name" : "keithdhardy",
      "indices" : [ 14, 26 ],
      "id_str" : "2492493601",
      "id" : 2492493601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542697386586304512",
  "text" : "RT @shakira: .@keithdhardy unequal access to ed. affects nations rich &amp; poor, but in the US school dropouts will be reduced by increasing E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Daniel Hardy",
        "screen_name" : "keithdhardy",
        "indices" : [ 1, 13 ],
        "id_str" : "2492493601",
        "id" : 2492493601
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542547261570306049",
    "geo" : { },
    "id_str" : "542696928145072128",
    "in_reply_to_user_id" : 2492493601,
    "text" : ".@keithdhardy unequal access to ed. affects nations rich &amp; poor, but in the US school dropouts will be reduced by increasing ECD programs",
    "id" : 542696928145072128,
    "in_reply_to_status_id" : 542547261570306049,
    "created_at" : "2014-12-10 15:06:45 +0000",
    "in_reply_to_screen_name" : "keithdhardy",
    "in_reply_to_user_id_str" : "2492493601",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542697386586304512,
  "created_at" : "2014-12-10 15:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 14, 25 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542696381731729408",
  "text" : "RT @shakira: .@arneduncan Thank you for having me and taking the time to chat about an issue that\u2019s close to both your heart &amp; mine. Shak #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 1, 12 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 129, 143 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "542695344740794368",
    "geo" : { },
    "id_str" : "542695607908192256",
    "in_reply_to_user_id" : 44873497,
    "text" : ".@arneduncan Thank you for having me and taking the time to chat about an issue that\u2019s close to both your heart &amp; mine. Shak #ShakiraEdChat",
    "id" : 542695607908192256,
    "in_reply_to_status_id" : 542695344740794368,
    "created_at" : "2014-12-10 15:01:30 +0000",
    "in_reply_to_screen_name" : "JohnKingatED",
    "in_reply_to_user_id_str" : "44873497",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542696381731729408,
  "created_at" : "2014-12-10 15:04:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 17, 25 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542695685917650945",
  "text" : "RT @arneduncan: .@Shakira is a strong advocate for education &amp; serves on the President\u2019s Advisory Commission on Ed Excellence for Hispanics\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shakira",
        "screen_name" : "shakira",
        "indices" : [ 1, 9 ],
        "id_str" : "44409004",
        "id" : 44409004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 128, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542695468204306432",
    "text" : ".@Shakira is a strong advocate for education &amp; serves on the President\u2019s Advisory Commission on Ed Excellence for Hispanics #ShakiraEdChat",
    "id" : 542695468204306432,
    "created_at" : "2014-12-10 15:00:57 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 542695685917650945,
  "created_at" : "2014-12-10 15:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 76, 87 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542694121685540864",
  "text" : "RT @shakira: Getting ready to answer your questions on early education with @ArneDuncan! Ask yours using #ShakiraEdChat Shak http:\/\/t.co\/eT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 63, 74 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/shakira\/status\/542693256644276224\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/eTDuFZhJOI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4gIpAiCMAEMWyQ.jpg",
        "id_str" : "542693255708553217",
        "id" : 542693255708553217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4gIpAiCMAEMWyQ.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1292,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 757,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1488,
          "resize" : "fit",
          "w" : 1179
        } ],
        "display_url" : "pic.twitter.com\/eTDuFZhJOI"
      } ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542693256644276224",
    "text" : "Getting ready to answer your questions on early education with @ArneDuncan! Ask yours using #ShakiraEdChat Shak http:\/\/t.co\/eTDuFZhJOI",
    "id" : 542693256644276224,
    "created_at" : "2014-12-10 14:52:09 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542694121685540864,
  "created_at" : "2014-12-10 14:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 21, 29 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 99, 113 ]
    }, {
      "text" : "InvestInUs",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542693114889007105",
  "text" : "RT @arneduncan: Join @Shakira &amp; me in 15 minutes to discuss the importance of early education. #ShakiraEdChat #InvestInUs http:\/\/t.co\/bRB81\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shakira",
        "screen_name" : "shakira",
        "indices" : [ 5, 13 ],
        "id_str" : "44409004",
        "id" : 44409004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 83, 97 ]
      }, {
        "text" : "InvestInUs",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/bRB81RvJv8",
        "expanded_url" : "http:\/\/youtu.be\/kdL25NNM0Xk",
        "display_url" : "youtu.be\/kdL25NNM0Xk"
      } ]
    },
    "geo" : { },
    "id_str" : "542691988236414976",
    "text" : "Join @Shakira &amp; me in 15 minutes to discuss the importance of early education. #ShakiraEdChat #InvestInUs http:\/\/t.co\/bRB81RvJv8",
    "id" : 542691988236414976,
    "created_at" : "2014-12-10 14:47:07 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 542693114889007105,
  "created_at" : "2014-12-10 14:51:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 83, 94 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542691954274758656",
  "text" : "RT @shakira: Just 30 mins until Shak's answering questions on early education with @arneduncan. Ask your question using #ShakiraEdChat. Sha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 70, 81 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 107, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542687723044474880",
    "text" : "Just 30 mins until Shak's answering questions on early education with @arneduncan. Ask your question using #ShakiraEdChat. ShakHQ",
    "id" : 542687723044474880,
    "created_at" : "2014-12-10 14:30:10 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542691954274758656,
  "created_at" : "2014-12-10 14:46:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 17, 25 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 30, 41 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/spw3qiWMqv",
      "expanded_url" : "http:\/\/go.wh.gov\/RdueXj",
      "display_url" : "go.wh.gov\/RdueXj"
    } ]
  },
  "geo" : { },
  "id_str" : "542690051411292161",
  "text" : "At 10am ET, join @Shakira and @ArneDuncan for an early education Twitter Q&amp;A. Ask your Q's with #ShakiraEdChat: http:\/\/t.co\/spw3qiWMqv",
  "id" : 542690051411292161,
  "created_at" : "2014-12-10 14:39:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 4, 12 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 19, 30 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542460577113579522\/photo\/1",
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/wHCkULXIWa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4czdS-CIAEAAxC.jpg",
      "id_str" : "542458858522681345",
      "id" : 542458858522681345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4czdS-CIAEAAxC.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/wHCkULXIWa"
    } ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DsDAJyRRWi",
      "expanded_url" : "http:\/\/go.wh.gov\/cHftY8",
      "display_url" : "go.wh.gov\/cHftY8"
    } ]
  },
  "geo" : { },
  "id_str" : "542460577113579522",
  "text" : "Ask @Shakira &amp; @ArneDuncan your early education Q's with #ShakiraEdChat before tomorrow's Q&amp;A: http:\/\/t.co\/DsDAJyRRWi http:\/\/t.co\/wHCkULXIWa",
  "id" : 542460577113579522,
  "created_at" : "2014-12-09 23:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noticias Telemundo",
      "screen_name" : "TelemundoNews",
      "indices" : [ 3, 17 ],
      "id_str" : "152142811",
      "id" : 152142811
    }, {
      "name" : "jose diaz-balart",
      "screen_name" : "jdbalart",
      "indices" : [ 66, 75 ],
      "id_str" : "49733381",
      "id" : 49733381
    }, {
      "name" : "Telemundo",
      "screen_name" : "Telemundo",
      "indices" : [ 101, 111 ],
      "id_str" : "22952132",
      "id" : 22952132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BarackObama",
      "indices" : [ 30, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542458053262467074",
  "text" : "RT @TelemundoNews: Presidente #BarackObama durante entrevista con @JdBalart que se transmite hoy por @Telemundo a las 6:30pm\/5:30C http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jose diaz-balart",
        "screen_name" : "jdbalart",
        "indices" : [ 47, 56 ],
        "id_str" : "49733381",
        "id" : 49733381
      }, {
        "name" : "Telemundo",
        "screen_name" : "Telemundo",
        "indices" : [ 82, 92 ],
        "id_str" : "22952132",
        "id" : 22952132
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TelemundoNews\/status\/542443575854649344\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/vm79N2mfJx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cljsqCcAAObEH.jpg",
        "id_str" : "542443575334563840",
        "id" : 542443575334563840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cljsqCcAAObEH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 745
        } ],
        "display_url" : "pic.twitter.com\/vm79N2mfJx"
      } ],
      "hashtags" : [ {
        "text" : "BarackObama",
        "indices" : [ 11, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542443575854649344",
    "text" : "Presidente #BarackObama durante entrevista con @JdBalart que se transmite hoy por @Telemundo a las 6:30pm\/5:30C http:\/\/t.co\/vm79N2mfJx",
    "id" : 542443575854649344,
    "created_at" : "2014-12-09 22:20:01 +0000",
    "user" : {
      "name" : "Noticias Telemundo",
      "screen_name" : "TelemundoNews",
      "protected" : false,
      "id_str" : "152142811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459739891203457024\/eG5vDx1T_normal.jpeg",
      "id" : 152142811,
      "verified" : true
    }
  },
  "id" : 542458053262467074,
  "created_at" : "2014-12-09 23:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 82, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/xKmddMAhsN",
      "expanded_url" : "http:\/\/snpy.tv\/1qr6Jn0",
      "display_url" : "snpy.tv\/1qr6Jn0"
    } ]
  },
  "geo" : { },
  "id_str" : "542439916064362497",
  "text" : "Watch President Obama reflect on letters he gets from Republicans who support his #ImmigrationAction. http:\/\/t.co\/xKmddMAhsN",
  "id" : 542439916064362497,
  "created_at" : "2014-12-09 22:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542431005303255041\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/5ZMzWz94Rj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cZ9iICUAEIdFg.png",
      "id_str" : "542430825044660225",
      "id" : 542430825044660225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cZ9iICUAEIdFg.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 907
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 907
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5ZMzWz94Rj"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542431005303255041",
  "text" : "\u201CWe were once strangers, too.\u201D \u2014Obama on how America has always been a nation of immigrants #ImmigrationAction http:\/\/t.co\/5ZMzWz94Rj",
  "id" : 542431005303255041,
  "created_at" : "2014-12-09 21:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542428123237588992",
  "text" : "RT @WHLive: \u201CEconomies with younger workforces grow faster than economies with older workforces.\u201D \u2014President Obama on the importance of imm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542428025728409601",
    "text" : "\u201CEconomies with younger workforces grow faster than economies with older workforces.\u201D \u2014President Obama on the importance of immigration",
    "id" : 542428025728409601,
    "created_at" : "2014-12-09 21:18:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 542428123237588992,
  "created_at" : "2014-12-09 21:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542427556746510336\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/D1xf6ZMamd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cW1z0CAAA5HT4.jpg",
      "id_str" : "542427393818755072",
      "id" : 542427393818755072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cW1z0CAAA5HT4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/D1xf6ZMamd"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542427556746510336",
  "text" : "\u201CPeople who are here, let\u2019s give them a shot, let\u2019s get them out of the shadows.\u201D \u2014President Obama #ImmigrationAction http:\/\/t.co\/D1xf6ZMamd",
  "id" : 542427556746510336,
  "created_at" : "2014-12-09 21:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542425286080339968\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6LecB23Go2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cU4X4CEAATs_C.png",
      "id_str" : "542425238835695616",
      "id" : 542425238835695616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cU4X4CEAATs_C.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 905
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 905
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6LecB23Go2"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542425286080339968",
  "text" : "\u201COver time, immigrants\u2026are boosting wages and jobs for everyone.\u201D \u2014President Obama #ImmigrationAction http:\/\/t.co\/6LecB23Go2",
  "id" : 542425286080339968,
  "created_at" : "2014-12-09 21:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542421655134273536\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KjBC3F3Qzv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cRh9ACMAAuHt5.jpg",
      "id_str" : "542421555129495552",
      "id" : 542421555129495552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cRh9ACMAAuHt5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KjBC3F3Qzv"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542421655134273536",
  "text" : "\u201CLet\u2019s focus on criminals, let\u2019s focus on felons, not families.\u201D \u2014President Obama on his #ImmigrationAction http:\/\/t.co\/KjBC3F3Qzv",
  "id" : 542421655134273536,
  "created_at" : "2014-12-09 20:52:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542420362072322048",
  "text" : "RT @WHLive: \u201CIt still is important for us to\u2026keep pushing for comprehensive immigration reform.\u201D \u2014Obama #ImmigrationAction http:\/\/t.co\/7qB6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/542420308209057793\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/7qB6kUJ5qF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cQYyPCQAM7K-8.png",
        "id_str" : "542420298109173763",
        "id" : 542420298109173763,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cQYyPCQAM7K-8.png",
        "sizes" : [ {
          "h" : 509,
          "resize" : "fit",
          "w" : 909
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 909
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7qB6kUJ5qF"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 92, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542420308209057793",
    "text" : "\u201CIt still is important for us to\u2026keep pushing for comprehensive immigration reform.\u201D \u2014Obama #ImmigrationAction http:\/\/t.co\/7qB6kUJ5qF",
    "id" : 542420308209057793,
    "created_at" : "2014-12-09 20:47:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 542420362072322048,
  "created_at" : "2014-12-09 20:47:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542419512805437442\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZuKL0f9CPs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cPpZZCMAAoJti.png",
      "id_str" : "542419483986374656",
      "id" : 542419483986374656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cPpZZCMAAoJti.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 909
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 909
      } ],
      "display_url" : "pic.twitter.com\/ZuKL0f9CPs"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 46, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/BrtS84QF70",
      "expanded_url" : "http:\/\/go.wh.gov\/e7cV8U",
      "display_url" : "go.wh.gov\/e7cV8U"
    } ]
  },
  "geo" : { },
  "id_str" : "542419512805437442",
  "text" : "Watch President Obama answer questions on his #ImmigrationAction at a town hall in Nashville: http:\/\/t.co\/BrtS84QF70 http:\/\/t.co\/ZuKL0f9CPs",
  "id" : 542419512805437442,
  "created_at" : "2014-12-09 20:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542418522853224449\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wWVcmgKULZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cOuBlCEAEs8Gt.jpg",
      "id_str" : "542418463981965313",
      "id" : 542418463981965313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cOuBlCEAEs8Gt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wWVcmgKULZ"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542418522853224449",
  "text" : "\"If we keep harnessing that potential, there\u2019s no limit to what this country can achieve.\" \u2014Obama #ImmigrationAction http:\/\/t.co\/wWVcmgKULZ",
  "id" : 542418522853224449,
  "created_at" : "2014-12-09 20:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542418082132529152\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/NYH5EE88ya",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cOXg8CIAAjaio.jpg",
      "id_str" : "542418077262946304",
      "id" : 542418077262946304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cOXg8CIAAjaio.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NYH5EE88ya"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542418082132529152",
  "text" : "\"This is what makes America exceptional\u2014that we welcome strivers and...dreamers from all around the world.\" \u2014Obama http:\/\/t.co\/NYH5EE88ya",
  "id" : 542418082132529152,
  "created_at" : "2014-12-09 20:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542417382078042113",
  "text" : "\"Pass a bill.\" \u2014President Obama to Congressional Republicans on how to help fix our broken immigration system",
  "id" : 542417382078042113,
  "created_at" : "2014-12-09 20:35:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542416957908082688\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/LbctGEpbAx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cNWNzCAAAzTRy.jpg",
      "id_str" : "542416955433418752",
      "id" : 542416955433418752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cNWNzCAAAzTRy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LbctGEpbAx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542416957908082688",
  "text" : "We're bringing \"more undocumented immigrants out of the shadows so they can play by the rules\" \u2014President Obama http:\/\/t.co\/LbctGEpbAx",
  "id" : 542416957908082688,
  "created_at" : "2014-12-09 20:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542416570790596608\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HwBOWsF9d2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cM_oZCEAECy1k.jpg",
      "id_str" : "542416567435137025",
      "id" : 542416567435137025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cM_oZCEAECy1k.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HwBOWsF9d2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542416570790596608",
  "text" : "\"We\u2019re providing more resources at the border to help law enforcement personnel stop illegal crossings\" \u2014Obama http:\/\/t.co\/HwBOWsF9d2",
  "id" : 542416570790596608,
  "created_at" : "2014-12-09 20:32:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542416343455125505",
  "text" : "RT @WHLive: \"If the House of Representatives allowed a simple up-or-down vote on that kind of bill, it would have passed.\" \u2014Obama on immigr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542416315877580801",
    "text" : "\"If the House of Representatives allowed a simple up-or-down vote on that kind of bill, it would have passed.\" \u2014Obama on immigration reform",
    "id" : 542416315877580801,
    "created_at" : "2014-12-09 20:31:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 542416343455125505,
  "created_at" : "2014-12-09 20:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542416182200905728",
  "text" : "\"It would have given millions of people the chance to earn their citizenship the right way\" \u2014Obama on the bipartisan Senate immigration bill",
  "id" : 542416182200905728,
  "created_at" : "2014-12-09 20:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 82, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542415969562275840",
  "text" : "\"Welcoming immigrants into your communities benefits all of us.\" \u2014President Obama #ImmigrationAction",
  "id" : 542415969562275840,
  "created_at" : "2014-12-09 20:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542415676338475010",
  "text" : "\"'They' are 'us.' They work as teachers in our schools, doctors in our hospitals, police...in our neighborhoods.\" \u2014Obama #ImmigrationAction",
  "id" : 542415676338475010,
  "created_at" : "2014-12-09 20:29:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/BrtS84QF70",
      "expanded_url" : "http:\/\/go.wh.gov\/e7cV8U",
      "display_url" : "go.wh.gov\/e7cV8U"
    } ]
  },
  "geo" : { },
  "id_str" : "542415055862525956",
  "text" : "Watch live: President Obama speaks at an immigration town hall in Nashville \u2192 http:\/\/t.co\/BrtS84QF70 #ImmigrationAction",
  "id" : 542415055862525956,
  "created_at" : "2014-12-09 20:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 33, 40 ],
      "id_str" : "49153854",
      "id" : 49153854
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 62, 73 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/V8RGnd6w10",
      "expanded_url" : "http:\/\/news.yahoo.com\/white-house-rolls-tire-safety-efficiency-program-160410704.html",
      "display_url" : "news.yahoo.com\/white-house-ro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542403910993203200",
  "text" : "RT @Podesta44: Why are there two @NASCAR vehicles outside the @WhiteHouse West Wing? Find out here: http:\/\/t.co\/V8RGnd6w10 http:\/\/t.co\/zIT7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASCAR",
        "screen_name" : "NASCAR",
        "indices" : [ 18, 25 ],
        "id_str" : "49153854",
        "id" : 49153854
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 47, 58 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Podesta44\/status\/542403274444255232\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/zIT7nwGyyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4cAr6NCYAE5d3M.jpg",
        "id_str" : "542403034479747073",
        "id" : 542403034479747073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4cAr6NCYAE5d3M.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zIT7nwGyyu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/V8RGnd6w10",
        "expanded_url" : "http:\/\/news.yahoo.com\/white-house-rolls-tire-safety-efficiency-program-160410704.html",
        "display_url" : "news.yahoo.com\/white-house-ro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542403274444255232",
    "text" : "Why are there two @NASCAR vehicles outside the @WhiteHouse West Wing? Find out here: http:\/\/t.co\/V8RGnd6w10 http:\/\/t.co\/zIT7nwGyyu",
    "id" : 542403274444255232,
    "created_at" : "2014-12-09 19:39:52 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 542403910993203200,
  "created_at" : "2014-12-09 19:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542392235208499200\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VHCnTD2e30",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4b08I0CEAAdZ3C.jpg",
      "id_str" : "542390119139774464",
      "id" : 542390119139774464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4b08I0CEAAdZ3C.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VHCnTD2e30"
    } ],
    "hashtags" : [ {
      "text" : "6DaysLeft",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/JxkdfixJNs",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "542392235208499200",
  "text" : "Need health coverage? You've got #6DaysLeft to sign up for a plan that starts on January 1st: http:\/\/t.co\/JxkdfixJNs http:\/\/t.co\/VHCnTD2e30",
  "id" : 542392235208499200,
  "created_at" : "2014-12-09 18:56:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 74, 82 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542380534220201985",
  "text" : "RT @arneduncan: Excited to answer your questions tomorrow at 10am ET with @shakira on early education. Ask away using #ShakiraEdChat: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shakira",
        "screen_name" : "shakira",
        "indices" : [ 58, 66 ],
        "id_str" : "44409004",
        "id" : 44409004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hOl2OXsbvv",
        "expanded_url" : "http:\/\/1.usa.gov\/1yyHpcu",
        "display_url" : "1.usa.gov\/1yyHpcu"
      } ]
    },
    "geo" : { },
    "id_str" : "542353517483016193",
    "text" : "Excited to answer your questions tomorrow at 10am ET with @shakira on early education. Ask away using #ShakiraEdChat: http:\/\/t.co\/hOl2OXsbvv",
    "id" : 542353517483016193,
    "created_at" : "2014-12-09 16:22:09 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 542380534220201985,
  "created_at" : "2014-12-09 18:09:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/K8Drze8b4u",
      "expanded_url" : "http:\/\/www.ed.gov\/blog\/2014\/12\/join-shakira-and-secretary-duncan-for-a-twitter-qa-on-early-education\/",
      "display_url" : "ed.gov\/blog\/2014\/12\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542376760793653248",
  "text" : "RT @shakira: Ask your questions about early education now and during the event using #ShakiraEdChat. More info: http:\/\/t.co\/K8Drze8b4u Shak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShakiraEdChat",
        "indices" : [ 72, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/K8Drze8b4u",
        "expanded_url" : "http:\/\/www.ed.gov\/blog\/2014\/12\/join-shakira-and-secretary-duncan-for-a-twitter-qa-on-early-education\/",
        "display_url" : "ed.gov\/blog\/2014\/12\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542366576977395712",
    "text" : "Ask your questions about early education now and during the event using #ShakiraEdChat. More info: http:\/\/t.co\/K8Drze8b4u ShakHQ 2\/2",
    "id" : 542366576977395712,
    "created_at" : "2014-12-09 17:14:03 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 542376760793653248,
  "created_at" : "2014-12-09 17:54:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AFI",
      "screen_name" : "AmericanFilm",
      "indices" : [ 3, 16 ],
      "id_str" : "24254832",
      "id" : 24254832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whfilmfest",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542371396634935296",
  "text" : "RT @AmericanFilm: AFI's filmmaker friends want YOU to submit your film to The White House Student Film Festival. #whfilmfest http:\/\/t.co\/Zt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whfilmfest",
        "indices" : [ 95, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Ztm0wVVmzx",
        "expanded_url" : "http:\/\/bit.ly\/1CVb6w4",
        "display_url" : "bit.ly\/1CVb6w4"
      } ]
    },
    "geo" : { },
    "id_str" : "541746229391020032",
    "text" : "AFI's filmmaker friends want YOU to submit your film to The White House Student Film Festival. #whfilmfest http:\/\/t.co\/Ztm0wVVmzx",
    "id" : 541746229391020032,
    "created_at" : "2014-12-08 00:09:00 +0000",
    "user" : {
      "name" : "AFI",
      "screen_name" : "AmericanFilm",
      "protected" : false,
      "id_str" : "24254832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540945210235031552\/fBxxwEiy_normal.png",
      "id" : 24254832,
      "verified" : true
    }
  },
  "id" : 542371396634935296,
  "created_at" : "2014-12-09 17:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UnlockTalent",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JNukd91vu7",
      "expanded_url" : "http:\/\/go.wh.gov\/4d3WFe",
      "display_url" : "go.wh.gov\/4d3WFe"
    } ]
  },
  "geo" : { },
  "id_str" : "542361534370836481",
  "text" : "RT @WHLive: Watch live: President Obama speaks to the Senior Executive Service \u2192 http:\/\/t.co\/JNukd91vu7 #UnlockTalent",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UnlockTalent",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/JNukd91vu7",
        "expanded_url" : "http:\/\/go.wh.gov\/4d3WFe",
        "display_url" : "go.wh.gov\/4d3WFe"
      } ]
    },
    "geo" : { },
    "id_str" : "542361504956170240",
    "text" : "Watch live: President Obama speaks to the Senior Executive Service \u2192 http:\/\/t.co\/JNukd91vu7 #UnlockTalent",
    "id" : 542361504956170240,
    "created_at" : "2014-12-09 16:53:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 542361534370836481,
  "created_at" : "2014-12-09 16:54:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542356454150119424\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/65qBgZ5T9m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4bWMXrCQAEGGeC.png",
      "id_str" : "542356313146015745",
      "id" : 542356313146015745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4bWMXrCQAEGGeC.png",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1088
      } ],
      "display_url" : "pic.twitter.com\/65qBgZ5T9m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/p7OON3WIb1",
      "expanded_url" : "http:\/\/go.wh.gov\/KNVQFD",
      "display_url" : "go.wh.gov\/KNVQFD"
    } ]
  },
  "geo" : { },
  "id_str" : "542356454150119424",
  "text" : "President Obama's statement on the Report of the Senate Select Committee on Intelligence: http:\/\/t.co\/p7OON3WIb1 http:\/\/t.co\/65qBgZ5T9m",
  "id" : 542356454150119424,
  "created_at" : "2014-12-09 16:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 21, 29 ],
      "id_str" : "44409004",
      "id" : 44409004
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 34, 45 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShakiraEdChat",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DsDAJyRRWi",
      "expanded_url" : "http:\/\/go.wh.gov\/cHftY8",
      "display_url" : "go.wh.gov\/cHftY8"
    } ]
  },
  "geo" : { },
  "id_str" : "542347548363464706",
  "text" : "Tomorrow at 10am ET, @Shakira and @ArneDuncan will answer your Q's on early education. Ask away using #ShakiraEdChat: http:\/\/t.co\/DsDAJyRRWi",
  "id" : 542347548363464706,
  "created_at" : "2014-12-09 15:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 3, 17 ],
      "id_str" : "16303106",
      "id" : 16303106
    }, {
      "name" : "Comedy Central",
      "screen_name" : "ComedyCentral",
      "indices" : [ 52, 66 ],
      "id_str" : "23827692",
      "id" : 23827692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542160657991614464",
  "text" : "RT @StephenAtHome: TONIGHT: President Barack Obama. @ComedyCentral. 11:30\/10:30c.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Comedy Central",
        "screen_name" : "ComedyCentral",
        "indices" : [ 33, 47 ],
        "id_str" : "23827692",
        "id" : 23827692
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "542135609083830272",
    "text" : "TONIGHT: President Barack Obama. @ComedyCentral. 11:30\/10:30c.",
    "id" : 542135609083830272,
    "created_at" : "2014-12-09 01:56:16 +0000",
    "user" : {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "protected" : false,
      "id_str" : "16303106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627669832549441536\/hv1AMpO0_normal.jpg",
      "id" : 16303106,
      "verified" : true
    }
  },
  "id" : 542160657991614464,
  "created_at" : "2014-12-09 03:35:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/0sPrfk1jAC",
      "expanded_url" : "http:\/\/wrd.cm\/1yu5Qg9",
      "display_url" : "wrd.cm\/1yu5Qg9"
    } ]
  },
  "geo" : { },
  "id_str" : "542105504966012928",
  "text" : "RT @WIRED: Obama becomes the first president to write a computer program http:\/\/t.co\/0sPrfk1jAC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/0sPrfk1jAC",
        "expanded_url" : "http:\/\/wrd.cm\/1yu5Qg9",
        "display_url" : "wrd.cm\/1yu5Qg9"
      } ]
    },
    "geo" : { },
    "id_str" : "542087089253543936",
    "text" : "Obama becomes the first president to write a computer program http:\/\/t.co\/0sPrfk1jAC",
    "id" : 542087089253543936,
    "created_at" : "2014-12-08 22:43:28 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 542105504966012928,
  "created_at" : "2014-12-08 23:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HourOfCode",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "CSEdWeek",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/SmaovaJXqZ",
      "expanded_url" : "http:\/\/youtu.be\/EJEBGf_uS_M",
      "display_url" : "youtu.be\/EJEBGf_uS_M"
    } ]
  },
  "geo" : { },
  "id_str" : "542100299566297088",
  "text" : "Watch President Obama become the first president to write a computer program \u2192 http:\/\/t.co\/SmaovaJXqZ #HourOfCode #CSEdWeek",
  "id" : 542100299566297088,
  "created_at" : "2014-12-08 23:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Y1TXXnWdem",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/12\/08\/celebrating-computer-science-education-week-kids-code-white-house",
      "display_url" : "whitehouse.gov\/blog\/2014\/12\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "542085028248035328",
  "text" : "RT @VP: Coding is the language of the future. See how we're connecting students to computer science \u2192 http:\/\/t.co\/Y1TXXnWdem http:\/\/t.co\/TZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/542067697060950017\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/TZAtU0ziGJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XPsaACMAA5K1-.jpg",
        "id_str" : "542067691968671744",
        "id" : 542067691968671744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XPsaACMAA5K1-.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/TZAtU0ziGJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/Y1TXXnWdem",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/12\/08\/celebrating-computer-science-education-week-kids-code-white-house",
        "display_url" : "whitehouse.gov\/blog\/2014\/12\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "542067697060950017",
    "text" : "Coding is the language of the future. See how we're connecting students to computer science \u2192 http:\/\/t.co\/Y1TXXnWdem http:\/\/t.co\/TZAtU0ziGJ",
    "id" : 542067697060950017,
    "created_at" : "2014-12-08 21:26:24 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 542085028248035328,
  "created_at" : "2014-12-08 22:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BET",
      "screen_name" : "BET",
      "indices" : [ 3, 7 ],
      "id_str" : "16560657",
      "id" : 16560657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "106andPark",
      "indices" : [ 20, 31 ]
    }, {
      "text" : "EricGarner",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/HJv550fjSv",
      "expanded_url" : "http:\/\/bet.us\/1Gaof0w",
      "display_url" : "bet.us\/1Gaof0w"
    } ]
  },
  "geo" : { },
  "id_str" : "542074623362609153",
  "text" : "RT @BET: TUNE IN to #106andPark to see Pres. Obama address #EricGarner + more starting at 5P\/4c! http:\/\/t.co\/HJv550fjSv http:\/\/t.co\/S0aXqc4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BET\/status\/542052280510337025\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/S0aXqc4kxJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4XBrVjCIAA1SFR.png",
        "id_str" : "542052280430632960",
        "id" : 542052280430632960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4XBrVjCIAA1SFR.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 603
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 603
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/S0aXqc4kxJ"
      } ],
      "hashtags" : [ {
        "text" : "106andPark",
        "indices" : [ 11, 22 ]
      }, {
        "text" : "EricGarner",
        "indices" : [ 50, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/HJv550fjSv",
        "expanded_url" : "http:\/\/bet.us\/1Gaof0w",
        "display_url" : "bet.us\/1Gaof0w"
      } ]
    },
    "geo" : { },
    "id_str" : "542052280510337025",
    "text" : "TUNE IN to #106andPark to see Pres. Obama address #EricGarner + more starting at 5P\/4c! http:\/\/t.co\/HJv550fjSv http:\/\/t.co\/S0aXqc4kxJ",
    "id" : 542052280510337025,
    "created_at" : "2014-12-08 20:25:09 +0000",
    "user" : {
      "name" : "BET",
      "screen_name" : "BET",
      "protected" : false,
      "id_str" : "16560657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798866886561845248\/YBNIp--5_normal.jpg",
      "id" : 16560657,
      "verified" : true
    }
  },
  "id" : 542074623362609153,
  "created_at" : "2014-12-08 21:53:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSEdWeek",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/KoZXyKJFks",
      "expanded_url" : "http:\/\/go.wh.gov\/7EfwvQ",
      "display_url" : "go.wh.gov\/7EfwvQ"
    } ]
  },
  "geo" : { },
  "id_str" : "542051282169896960",
  "text" : "We're announcing new commitments to help millions of students gain access to computer science education \u2192 http:\/\/t.co\/KoZXyKJFks #CSEdWeek",
  "id" : 542051282169896960,
  "created_at" : "2014-12-08 20:21:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/MuvI7BzaX3",
      "expanded_url" : "http:\/\/go.wh.gov\/DNdSqa",
      "display_url" : "go.wh.gov\/DNdSqa"
    } ]
  },
  "geo" : { },
  "id_str" : "542030242232008704",
  "text" : "RT @FLOTUS: \"That\u2019s a big deal.\" \u2014FLOTUS to students mailing their college applications: http:\/\/t.co\/MuvI7BzaX3 #ReachHigher http:\/\/t.co\/Nm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/542026000326881280\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Nm4NktS9Xn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4WpRHmCcAADbTE.jpg",
        "id_str" : "542025441729474560",
        "id" : 542025441729474560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4WpRHmCcAADbTE.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/Nm4NktS9Xn"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/MuvI7BzaX3",
        "expanded_url" : "http:\/\/go.wh.gov\/DNdSqa",
        "display_url" : "go.wh.gov\/DNdSqa"
      } ]
    },
    "geo" : { },
    "id_str" : "542026000326881280",
    "text" : "\"That\u2019s a big deal.\" \u2014FLOTUS to students mailing their college applications: http:\/\/t.co\/MuvI7BzaX3 #ReachHigher http:\/\/t.co\/Nm4NktS9Xn",
    "id" : 542026000326881280,
    "created_at" : "2014-12-08 18:40:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 542030242232008704,
  "created_at" : "2014-12-08 18:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HourOfCode",
      "indices" : [ 112, 123 ]
    }, {
      "text" : "CSEdWeek",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/BgehYr25Ts",
      "expanded_url" : "http:\/\/youtu.be\/JDw1ii7aKwg",
      "display_url" : "youtu.be\/JDw1ii7aKwg"
    } ]
  },
  "geo" : { },
  "id_str" : "542015685476352000",
  "text" : "\"We're counting on you, America's young people, to keep us on the cutting edge.\" \u2014Obama: http:\/\/t.co\/BgehYr25Ts #HourOfCode #CSEdWeek",
  "id" : 542015685476352000,
  "created_at" : "2014-12-08 17:59:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/542003246781308928\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/r0gSzMJKxe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4WU-pvCUAAtRTt.jpg",
      "id_str" : "542003134243950592",
      "id" : 542003134243950592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4WU-pvCUAAtRTt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r0gSzMJKxe"
    } ],
    "hashtags" : [ {
      "text" : "7DaysLeft",
      "indices" : [ 11, 21 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "542003246781308928",
  "text" : "You've got #7DaysLeft to sign up for health coverage that starts on Jan. 1st \u2192 http:\/\/t.co\/NSeLHFvc62 #GetCovered http:\/\/t.co\/r0gSzMJKxe",
  "id" : 542003246781308928,
  "created_at" : "2014-12-08 17:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 3, 9 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    }, {
      "name" : "Code.org",
      "screen_name" : "codeorg",
      "indices" : [ 94, 102 ],
      "id_str" : "850107536",
      "id" : 850107536
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSEdWeek",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541995582970003456",
  "text" : "RT @USCTO: Hello, Twitter! Excited to start tweeting for Team CTO and kick off #CSEdWeek with @CodeOrg here at the @WhiteHouse: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Code.org",
        "screen_name" : "codeorg",
        "indices" : [ 83, 91 ],
        "id_str" : "850107536",
        "id" : 850107536
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 104, 115 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CSEdWeek",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Q0Mo69Wkvk",
        "expanded_url" : "http:\/\/go.wh.gov\/GPwwPJ",
        "display_url" : "go.wh.gov\/GPwwPJ"
      } ]
    },
    "geo" : { },
    "id_str" : "541995267873325057",
    "text" : "Hello, Twitter! Excited to start tweeting for Team CTO and kick off #CSEdWeek with @CodeOrg here at the @WhiteHouse: http:\/\/t.co\/Q0Mo69Wkvk",
    "id" : 541995267873325057,
    "created_at" : "2014-12-08 16:38:36 +0000",
    "user" : {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "protected" : false,
      "id_str" : "2888895350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534373591228219392\/Ewzw--q6_normal.jpeg",
      "id" : 2888895350,
      "verified" : true
    }
  },
  "id" : 541995582970003456,
  "created_at" : "2014-12-08 16:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4mBblUSfra",
      "expanded_url" : "http:\/\/bit.ly\/1ziwibz",
      "display_url" : "bit.ly\/1ziwibz"
    } ]
  },
  "geo" : { },
  "id_str" : "541988127875678208",
  "text" : "Thanks to the Affordable Care Act, insurers are spending more of people's premium dollars on real care \u2192 http:\/\/t.co\/4mBblUSfra #ACAWorks",
  "id" : 541988127875678208,
  "created_at" : "2014-12-08 16:10:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 3, 7 ],
      "id_str" : "2367911",
      "id" : 2367911
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 111, 122 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541980264595869696",
  "text" : "RT @MTV: Meet the indigenous youth who made such a difference in their communities that it brought them to the @WhiteHouse: http:\/\/t.co\/Kjw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 102, 113 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/KjwNruScbz",
        "expanded_url" : "http:\/\/on.mtv.com\/1yy6acG",
        "display_url" : "on.mtv.com\/1yy6acG"
      } ]
    },
    "geo" : { },
    "id_str" : "541038083471585280",
    "text" : "Meet the indigenous youth who made such a difference in their communities that it brought them to the @WhiteHouse: http:\/\/t.co\/KjwNruScbz",
    "id" : 541038083471585280,
    "created_at" : "2014-12-06 01:15:05 +0000",
    "user" : {
      "name" : "MTV",
      "screen_name" : "MTV",
      "protected" : false,
      "id_str" : "2367911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796753394778144768\/IUKITJH1_normal.jpg",
      "id" : 2367911,
      "verified" : true
    }
  },
  "id" : 541980264595869696,
  "created_at" : "2014-12-08 15:38:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7DaysLeft",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "541977283670470656",
  "text" : "If you need health coverage, there are just #7DaysLeft to sign up for a plan that kicks in Jan. 1st. #GetCovered at http:\/\/t.co\/NSeLHFvc62.",
  "id" : 541977283670470656,
  "created_at" : "2014-12-08 15:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/541774218283585536\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/7VGbBqPT30",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4RtSy0CEAAdlJk.jpg",
      "id_str" : "541678024836386816",
      "id" : 541678024836386816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4RtSy0CEAAdlJk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7VGbBqPT30"
    } ],
    "hashtags" : [ {
      "text" : "8DaysLeft",
      "indices" : [ 5, 15 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "541774218283585536",
  "text" : "Just #8DaysLeft to get health coverage that starts on January 1st. #GetCovered at http:\/\/t.co\/NSeLHFvc62. http:\/\/t.co\/7VGbBqPT30",
  "id" : 541774218283585536,
  "created_at" : "2014-12-08 02:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/541683659221127168\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Eez8Nqy6mg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4Rs2g2CQAACqfW.jpg",
      "id_str" : "541677538976612352",
      "id" : 541677538976612352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4Rs2g2CQAACqfW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Eez8Nqy6mg"
    } ],
    "hashtags" : [ {
      "text" : "8DaysLeft",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "541683659221127168",
  "text" : "Need health coverage that starts on Jan. 1st? You've got #8DaysLeft to sign up \u2192 http:\/\/t.co\/NSeLHFvc62 #GetCovered http:\/\/t.co\/Eez8Nqy6mg",
  "id" : 541683659221127168,
  "created_at" : "2014-12-07 20:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/3cCSTwNOcm",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv2ahn",
      "display_url" : "go.wh.gov\/Rv2ahn"
    } ]
  },
  "geo" : { },
  "id_str" : "541676050778828800",
  "text" : "\"We are going to keep it up until every American feels the gains of a growing economy.\" \u2014President Obama: http:\/\/t.co\/3cCSTwNOcm",
  "id" : 541676050778828800,
  "created_at" : "2014-12-07 19:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BET",
      "screen_name" : "BET",
      "indices" : [ 59, 63 ],
      "id_str" : "16560657",
      "id" : 16560657
    }, {
      "name" : "#106andPark",
      "screen_name" : "106andpark",
      "indices" : [ 66, 77 ],
      "id_str" : "30309979",
      "id" : 30309979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GdhNB4Ubky",
      "expanded_url" : "http:\/\/youtu.be\/cuQYQCEd5X4",
      "display_url" : "youtu.be\/cuQYQCEd5X4"
    } ]
  },
  "geo" : { },
  "id_str" : "541664217305452545",
  "text" : "Watch President Obama discuss #Ferguson and Eric Garner on @BET's @106andPark tomorrow at 5pm ET. Here's a preview: http:\/\/t.co\/GdhNB4Ubky",
  "id" : 541664217305452545,
  "created_at" : "2014-12-07 18:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BET",
      "screen_name" : "BET",
      "indices" : [ 33, 37 ],
      "id_str" : "16560657",
      "id" : 16560657
    }, {
      "name" : "#106andPark",
      "screen_name" : "106andpark",
      "indices" : [ 40, 51 ],
      "id_str" : "30309979",
      "id" : 30309979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GdhNB4Ubky",
      "expanded_url" : "http:\/\/youtu.be\/cuQYQCEd5X4",
      "display_url" : "youtu.be\/cuQYQCEd5X4"
    } ]
  },
  "geo" : { },
  "id_str" : "541655012922126336",
  "text" : "President Obama's interview with @BET's @106andPark on #Ferguson and Eric Garner airs Mon at 4pm ET. Watch a preview: http:\/\/t.co\/GdhNB4Ubky",
  "id" : 541655012922126336,
  "created_at" : "2014-12-07 18:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/3cCSTwNOcm",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv2ahn",
      "display_url" : "go.wh.gov\/Rv2ahn"
    } ]
  },
  "geo" : { },
  "id_str" : "541638317544964096",
  "text" : "\"Raising the minimum wage would benefit nearly 28 million American workers.\" \u2014President Obama: http:\/\/t.co\/3cCSTwNOcm #RaiseTheWage",
  "id" : 541638317544964096,
  "created_at" : "2014-12-07 17:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/540894290616922115\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yTmnPF1Znt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "id_str" : "540894253044355072",
      "id" : 540894253044355072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yTmnPF1Znt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/3cCSTwNOcm",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv2ahn",
      "display_url" : "go.wh.gov\/Rv2ahn"
    } ]
  },
  "geo" : { },
  "id_str" : "541615656408322051",
  "text" : "\"Our businesses have created 10.9 million new jobs over the past 57 months.\" \u2014President Obama: http:\/\/t.co\/3cCSTwNOcm http:\/\/t.co\/yTmnPF1Znt",
  "id" : 541615656408322051,
  "created_at" : "2014-12-07 15:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3cCSTwNOcm",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv2ahn",
      "display_url" : "go.wh.gov\/Rv2ahn"
    } ]
  },
  "geo" : { },
  "id_str" : "541321242263842817",
  "text" : "\"The upswing in job growth this year has come in industries with higher wages. Overall wages are on the rise\" \u2014Obama: http:\/\/t.co\/3cCSTwNOcm",
  "id" : 541321242263842817,
  "created_at" : "2014-12-06 20:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/3cCSTwNOcm",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv2ahn",
      "display_url" : "go.wh.gov\/Rv2ahn"
    } ]
  },
  "geo" : { },
  "id_str" : "541294782077628418",
  "text" : "\"This year, our economy has created 2.65 million new jobs. That\u2019s the most of any year since the 1990s.\" \u2014Obama: http:\/\/t.co\/3cCSTwNOcm",
  "id" : 541294782077628418,
  "created_at" : "2014-12-06 18:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/541271180360310784\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/XXpGADAlRE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4L7QaSCIAAHdkS.png",
      "id_str" : "541271164589318144",
      "id" : 541271164589318144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4L7QaSCIAAHdkS.png",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1063
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XXpGADAlRE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541271180360310784",
  "text" : "\"The United States strongly condemns the barbaric murder of Luke Somers at the hands of Al-Qa\u2019ida terrorists\" \u2014Obama http:\/\/t.co\/XXpGADAlRE",
  "id" : 541271180360310784,
  "created_at" : "2014-12-06 16:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540894290616922115\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yTmnPF1Znt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "id_str" : "540894253044355072",
      "id" : 540894253044355072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yTmnPF1Znt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/CHe2Nixod0",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv2ahn",
      "display_url" : "go.wh.gov\/Rv2ahn"
    } ]
  },
  "geo" : { },
  "id_str" : "541260570608304128",
  "text" : "\"Last month, our businesses created 314,000 new jobs.\" \u2014President Obama in his weekly address: http:\/\/t.co\/CHe2Nixod0 http:\/\/t.co\/yTmnPF1Znt",
  "id" : 541260570608304128,
  "created_at" : "2014-12-06 15:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The National Tree",
      "screen_name" : "TheNationalTree",
      "indices" : [ 55, 71 ],
      "id_str" : "2168471155",
      "id" : 2168471155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/541027232295038976\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/38kkUlyAcn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4Ic4ZuCQAEgxG3.jpg",
      "id_str" : "541026660540104705",
      "id" : 541026660540104705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4Ic4ZuCQAEgxG3.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/38kkUlyAcn"
    } ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/PYpn5fTFN6",
      "expanded_url" : "http:\/\/go.wh.gov\/KKxihj",
      "display_url" : "go.wh.gov\/KKxihj"
    } ]
  },
  "geo" : { },
  "id_str" : "541027232295038976",
  "text" : "The First Family kicked off the holidays last night at @TheNationalTree lighting: http:\/\/t.co\/PYpn5fTFN6 #WHHolidays http:\/\/t.co\/38kkUlyAcn",
  "id" : 541027232295038976,
  "created_at" : "2014-12-06 00:31:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540982561216806912\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/560VZuQClo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4H0uz0CQAAD9by.jpg",
      "id_str" : "540982515280789504",
      "id" : 540982515280789504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4H0uz0CQAAD9by.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/560VZuQClo"
    } ],
    "hashtags" : [ {
      "text" : "10DaysLeft",
      "indices" : [ 5, 16 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "540982561216806912",
  "text" : "Just #10DaysLeft to get health coverage that starts on January 1st. #GetCovered at http:\/\/t.co\/NSeLHFvc62. http:\/\/t.co\/560VZuQClo",
  "id" : 540982561216806912,
  "created_at" : "2014-12-05 21:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540894290616922115\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yTmnPF1Znt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "id_str" : "540894253044355072",
      "id" : 540894253044355072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yTmnPF1Znt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540962868296835072",
  "text" : "Our businesses have added:\n10.9 million jobs over 57 months \u2713\n2.6 million so far this year \u2713\n314,000 last month \u2713\nhttp:\/\/t.co\/yTmnPF1Znt",
  "id" : 540962868296835072,
  "created_at" : "2014-12-05 20:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/540947744865529856\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yi9YEnPgWa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4HVEtDCIAAU6mc.jpg",
      "id_str" : "540947707049680896",
      "id" : 540947707049680896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4HVEtDCIAAU6mc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yi9YEnPgWa"
    } ],
    "hashtags" : [ {
      "text" : "10DaysLeft",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "540947744865529856",
  "text" : "Need health coverage? You've got #10DaysLeft to sign up for a plan that starts on Jan. 1st: http:\/\/t.co\/NSeLHFvc62 http:\/\/t.co\/yi9YEnPgWa",
  "id" : 540947744865529856,
  "created_at" : "2014-12-05 19:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540945689283289088",
  "text" : "RT @NSCPress: President Obama will host Prince William, The Duke of Cambridge, for a meeting in the Oval Office on Monday, December 8 @UKin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "British Embassy",
        "screen_name" : "UKinUSA",
        "indices" : [ 120, 128 ],
        "id_str" : "22120359",
        "id" : 22120359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540931170804830208",
    "text" : "President Obama will host Prince William, The Duke of Cambridge, for a meeting in the Oval Office on Monday, December 8 @UKinUSA",
    "id" : 540931170804830208,
    "created_at" : "2014-12-05 18:10:15 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 540945689283289088,
  "created_at" : "2014-12-05 19:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 90, 97 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540927866213367810\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AAvOYmhaxI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4HC9kNCcAA8QMC.png",
      "id_str" : "540927793207341056",
      "id" : 540927793207341056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4HC9kNCcAA8QMC.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AAvOYmhaxI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540927866213367810",
  "text" : "\"On this day, and on every day, we honor his spirit and his memory.\" \u2014President Obama and @FLOTUS on Nelson Mandela http:\/\/t.co\/AAvOYmhaxI",
  "id" : 540927866213367810,
  "created_at" : "2014-12-05 17:57:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#106andPark",
      "screen_name" : "106andpark",
      "indices" : [ 3, 14 ],
      "id_str" : "30309979",
      "id" : 30309979
    }, {
      "name" : "#106andPark",
      "screen_name" : "106andpark",
      "indices" : [ 130, 141 ],
      "id_str" : "30309979",
      "id" : 30309979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540921399712305152",
  "text" : "RT @106andpark: Honored to speak with President Obama today about #Ferguson, Eric Garner &amp; the impact on OUR community. WATCH @106andPark M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#106andPark",
        "screen_name" : "106andpark",
        "indices" : [ 114, 125 ],
        "id_str" : "30309979",
        "id" : 30309979
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 50, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540921003933581313",
    "text" : "Honored to speak with President Obama today about #Ferguson, Eric Garner &amp; the impact on OUR community. WATCH @106andPark Monday 4 intrvw",
    "id" : 540921003933581313,
    "created_at" : "2014-12-05 17:29:51 +0000",
    "user" : {
      "name" : "#106andPark",
      "screen_name" : "106andpark",
      "protected" : false,
      "id_str" : "30309979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747086084299849729\/PAqisIqS_normal.jpg",
      "id" : 30309979,
      "verified" : true
    }
  },
  "id" : 540921399712305152,
  "created_at" : "2014-12-05 17:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 23, 28 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540920160857518080\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Kyv8DDROmH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4G7u1YCYAAckMq.jpg",
      "id_str" : "540919843537444864",
      "id" : 540919843537444864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4G7u1YCYAAckMq.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Kyv8DDROmH"
    } ],
    "hashtags" : [ {
      "text" : "OrionLaunch",
      "indices" : [ 31, 43 ]
    }, {
      "text" : "JourneyToMars",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/13LSCOAhJs",
      "expanded_url" : "http:\/\/go.wh.gov\/rnzxt2",
      "display_url" : "go.wh.gov\/rnzxt2"
    } ]
  },
  "geo" : { },
  "id_str" : "540920160857518080",
  "text" : "\"It's time to go fly.\"\n@NASA's #OrionLaunch marks our first step on the #JourneyToMars: http:\/\/t.co\/13LSCOAhJs http:\/\/t.co\/Kyv8DDROmH",
  "id" : 540920160857518080,
  "created_at" : "2014-12-05 17:26:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/JtgOpLFuL3",
      "expanded_url" : "http:\/\/snpy.tv\/1A0b5RT",
      "display_url" : "snpy.tv\/1A0b5RT"
    } ]
  },
  "geo" : { },
  "id_str" : "540903443234168832",
  "text" : "\"Last month, America's businesses created more than 300,000 jobs.\" \u2014President Obama: http:\/\/t.co\/JtgOpLFuL3",
  "id" : 540903443234168832,
  "created_at" : "2014-12-05 16:20:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540894290616922115\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yTmnPF1Znt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "id_str" : "540894253044355072",
      "id" : 540894253044355072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yTmnPF1Znt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/QFYr9v1qNn",
      "expanded_url" : "http:\/\/go.wh.gov\/KSMZSo",
      "display_url" : "go.wh.gov\/KSMZSo"
    } ]
  },
  "geo" : { },
  "id_str" : "540898226409185280",
  "text" : "FACT: Our businesses are on pace for the strongest year of job growth since the late 1990s. http:\/\/t.co\/QFYr9v1qNn http:\/\/t.co\/yTmnPF1Znt",
  "id" : 540898226409185280,
  "created_at" : "2014-12-05 15:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540894290616922115\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yTmnPF1Znt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "id_str" : "540894253044355072",
      "id" : 540894253044355072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4GkdRXCUAAjP0i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1406
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yTmnPF1Znt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/QFYr9v1qNn",
      "expanded_url" : "http:\/\/go.wh.gov\/KSMZSo",
      "display_url" : "go.wh.gov\/KSMZSo"
    } ]
  },
  "geo" : { },
  "id_str" : "540894290616922115",
  "text" : "Good news: Our businesses added 314,000 jobs last month and 2.6 million so far in 2014 \u2192 http:\/\/t.co\/QFYr9v1qNn http:\/\/t.co\/yTmnPF1Znt",
  "id" : 540894290616922115,
  "created_at" : "2014-12-05 15:43:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540892420934602752",
  "text" : "RT @WHLive: \"You have been there for our troops, for their families, for our nation\" \u2014President Obama on his Secretary of Defense nominee A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540892389544452097",
    "text" : "\"You have been there for our troops, for their families, for our nation\" \u2014President Obama on his Secretary of Defense nominee Ash Carter",
    "id" : 540892389544452097,
    "created_at" : "2014-12-05 15:36:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 540892420934602752,
  "created_at" : "2014-12-05 15:36:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540890583246450690",
  "text" : "\"Ash is rightly regarded as one of our nation\u2019s foremost national security leaders.\" \u2014Obama on his Secretary of Defense nominee Ash Carter",
  "id" : 540890583246450690,
  "created_at" : "2014-12-05 15:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540890503093297153",
  "text" : "\"Today, I\u2019m pleased to announce my nominee to be our next Secretary of Defense\u2014Mr. Ash Carter.\" \u2014President Obama",
  "id" : 540890503093297153,
  "created_at" : "2014-12-05 15:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540890165749616640",
  "text" : "\"Over the last four years, we\u2019ve put more people back to work than Europe, Japan, and all other advanced economies combined.\" \u2014Obama",
  "id" : 540890165749616640,
  "created_at" : "2014-12-05 15:27:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540889803768610816",
  "text" : "\"The pickup in the pace of job growth this year has been in industries with higher wages. And overall wages are rising.\" \u2014President Obama",
  "id" : 540889803768610816,
  "created_at" : "2014-12-05 15:25:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540889743441928192",
  "text" : "\"Our businesses have now created 10.9 million jobs over the past 57 months in a row...the longest streak...on record.\" \u2014President Obama",
  "id" : 540889743441928192,
  "created_at" : "2014-12-05 15:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540889641721679872",
  "text" : "\"Over the first 11 months of 2014, our economy has created 2.65 million jobs. That\u2019s more than in any entire year since the 1990s.\" \u2014Obama",
  "id" : 540889641721679872,
  "created_at" : "2014-12-05 15:25:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540889578031153152\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/xgQKjnP9BV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4GgMA7CQAAk_9N.jpg",
      "id_str" : "540889558527655936",
      "id" : 540889558527655936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4GgMA7CQAAk_9N.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/xgQKjnP9BV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540889578031153152",
  "text" : "\"Last month, America's businesses created more than 300,000 jobs.\" \u2014President Obama http:\/\/t.co\/xgQKjnP9BV",
  "id" : 540889578031153152,
  "created_at" : "2014-12-05 15:24:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/DaQPDocxzV",
      "expanded_url" : "http:\/\/go.wh.gov\/GwSXZe",
      "display_url" : "go.wh.gov\/GwSXZe"
    } ]
  },
  "geo" : { },
  "id_str" : "540880942059880448",
  "text" : "At 10:10am ET, President Obama makes a personnel announcement. Watch \u2192 http:\/\/t.co\/DaQPDocxzV",
  "id" : 540880942059880448,
  "created_at" : "2014-12-05 14:50:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540646456735301632",
  "text" : "\"On behalf of Michelle, Malia, Sasha, mom-in-law, and our reindeer Bo and Sunny, I wish\u2026all of you a very Merry Christmas\" \u2014President Obama",
  "id" : 540646456735301632,
  "created_at" : "2014-12-04 23:18:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540646200475910144",
  "text" : "\"As we hold our loved ones tight, let\u2019s remember the military families whose loved ones are far from home. They are our heroes.\" \u2014Obama",
  "id" : 540646200475910144,
  "created_at" : "2014-12-04 23:17:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The National Tree",
      "screen_name" : "TheNationalTree",
      "indices" : [ 92, 108 ],
      "id_str" : "2168471155",
      "id" : 2168471155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeWithCode",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540645868106690560",
  "text" : "\"Young women from all 50 states used...their coding skills to control\u2026the lights\" \u2014Obama at @TheNationalTree lighting #MadeWithCode",
  "id" : 540645868106690560,
  "created_at" : "2014-12-04 23:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The National Tree",
      "screen_name" : "TheNationalTree",
      "indices" : [ 50, 66 ],
      "id_str" : "2168471155",
      "id" : 2168471155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/YGWioTu61s",
      "expanded_url" : "http:\/\/go.wh.gov\/weaK8v",
      "display_url" : "go.wh.gov\/weaK8v"
    } ]
  },
  "geo" : { },
  "id_str" : "540645002784026624",
  "text" : "\"Merry Christmas, everybody!\" \u2014President Obama at @TheNationalTree lighting: http:\/\/t.co\/YGWioTu61s #WHHolidays",
  "id" : 540645002784026624,
  "created_at" : "2014-12-04 23:13:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YGWioTu61s",
      "expanded_url" : "http:\/\/go.wh.gov\/weaK8v",
      "display_url" : "go.wh.gov\/weaK8v"
    } ]
  },
  "geo" : { },
  "id_str" : "540632869333630976",
  "text" : "Watch live: The First Family attends the 2014 National Christmas Tree Lighting \u2192 http:\/\/t.co\/YGWioTu61s #WHHolidays",
  "id" : 540632869333630976,
  "created_at" : "2014-12-04 22:24:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540616474201980930",
  "text" : "RT @VP: \"What we need to continue leading the world...is not only the best educated population, but also the most skilled workforce.\" -VP B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540608053021016064",
    "text" : "\"What we need to continue leading the world...is not only the best educated population, but also the most skilled workforce.\" -VP Biden",
    "id" : 540608053021016064,
    "created_at" : "2014-12-04 20:46:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 540616474201980930,
  "created_at" : "2014-12-04 21:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 91, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/yzgO5ZxAP7",
      "expanded_url" : "http:\/\/go.wh.gov\/juyoh2",
      "display_url" : "go.wh.gov\/juyoh2"
    } ]
  },
  "geo" : { },
  "id_str" : "540611774941511680",
  "text" : "President Obama is taking new steps to help more students graduate from college and expand #CollegeOpportunity \u2192 http:\/\/t.co\/yzgO5ZxAP7",
  "id" : 540611774941511680,
  "created_at" : "2014-12-04 21:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 3, 10 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madewithcode",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/RTWR6J70r7",
      "expanded_url" : "http:\/\/goo.gl\/clLgTr",
      "display_url" : "goo.gl\/clLgTr"
    } ]
  },
  "geo" : { },
  "id_str" : "540603767562186752",
  "text" : "RT @google: What\u2019s #madewithcode? The lights at this year\u2019s National Christmas Tree Lighting ceremony \u2192 http:\/\/t.co\/RTWR6J70r7 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/google\/status\/539890208569708544\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/WR0zAFVEyS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B34TSJqCYAADukS.jpg",
        "id_str" : "539890207881846784",
        "id" : 539890207881846784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34TSJqCYAADukS.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 133,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WR0zAFVEyS"
      } ],
      "hashtags" : [ {
        "text" : "madewithcode",
        "indices" : [ 7, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/RTWR6J70r7",
        "expanded_url" : "http:\/\/goo.gl\/clLgTr",
        "display_url" : "goo.gl\/clLgTr"
      } ]
    },
    "geo" : { },
    "id_str" : "539890208569708544",
    "text" : "What\u2019s #madewithcode? The lights at this year\u2019s National Christmas Tree Lighting ceremony \u2192 http:\/\/t.co\/RTWR6J70r7 http:\/\/t.co\/WR0zAFVEyS",
    "id" : 539890208569708544,
    "created_at" : "2014-12-02 21:13:51 +0000",
    "user" : {
      "name" : "Google",
      "screen_name" : "google",
      "protected" : false,
      "id_str" : "20536157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762369348300251136\/5Obhonwa_normal.jpg",
      "id" : 20536157,
      "verified" : true
    }
  },
  "id" : 540603767562186752,
  "created_at" : "2014-12-04 20:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 96, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/31KW4sarnk",
      "expanded_url" : "http:\/\/go.wh.gov\/juyoh2",
      "display_url" : "go.wh.gov\/juyoh2"
    } ]
  },
  "geo" : { },
  "id_str" : "540594651468922881",
  "text" : "RT @FLOTUS: \"This is really a collective effort, and everyone can benefit\" \u2014FLOTUS on expanding #CollegeOpportunity: http:\/\/t.co\/31KW4sarnk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 84, 103 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/31KW4sarnk",
        "expanded_url" : "http:\/\/go.wh.gov\/juyoh2",
        "display_url" : "go.wh.gov\/juyoh2"
      } ]
    },
    "geo" : { },
    "id_str" : "540594574813822976",
    "text" : "\"This is really a collective effort, and everyone can benefit\" \u2014FLOTUS on expanding #CollegeOpportunity: http:\/\/t.co\/31KW4sarnk #ReachHigher",
    "id" : 540594574813822976,
    "created_at" : "2014-12-04 19:52:45 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 540594651468922881,
  "created_at" : "2014-12-04 19:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540593689090068481",
  "text" : "RT @FLOTUS: \"Higher education is no longer just for kids in the top quarter or the top half of the class\u2014it has to be for everyone\" \u2014FLOTUS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540593656533884928",
    "text" : "\"Higher education is no longer just for kids in the top quarter or the top half of the class\u2014it has to be for everyone\" \u2014FLOTUS #ReachHigher",
    "id" : 540593656533884928,
    "created_at" : "2014-12-04 19:49:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 540593689090068481,
  "created_at" : "2014-12-04 19:49:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540592609283301376",
  "text" : "RT @FLOTUS: \"Too many of our kids go through high school with little, if any, real guidance on how to get into college.\" \u2014The First Lady #R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540592549912915968",
    "text" : "\"Too many of our kids go through high school with little, if any, real guidance on how to get into college.\" \u2014The First Lady #ReachHigher",
    "id" : 540592549912915968,
    "created_at" : "2014-12-04 19:44:42 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 540592609283301376,
  "created_at" : "2014-12-04 19:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 62, 81 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EPYw9Vs36q",
      "expanded_url" : "http:\/\/go.wh.gov\/tDF566",
      "display_url" : "go.wh.gov\/tDF566"
    } ]
  },
  "geo" : { },
  "id_str" : "540591966606864384",
  "text" : "RT @FLOTUS: Happening now: The First Lady speaks on expanding #CollegeOpportunity for more students \u2192 http:\/\/t.co\/EPYw9Vs36q #ReachHigher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 50, 69 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 113, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/EPYw9Vs36q",
        "expanded_url" : "http:\/\/go.wh.gov\/tDF566",
        "display_url" : "go.wh.gov\/tDF566"
      } ]
    },
    "geo" : { },
    "id_str" : "540591936449818624",
    "text" : "Happening now: The First Lady speaks on expanding #CollegeOpportunity for more students \u2192 http:\/\/t.co\/EPYw9Vs36q #ReachHigher",
    "id" : 540591936449818624,
    "created_at" : "2014-12-04 19:42:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 540591966606864384,
  "created_at" : "2014-12-04 19:42:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 80, 93 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540588876558245888",
  "text" : "RT @VP: I applaud Justice Dept for its work to build community trust, and thank @BilldeBlasio\u2019s team for leadership in the face of this out\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill de Blasio",
        "screen_name" : "BilldeBlasio",
        "indices" : [ 72, 85 ],
        "id_str" : "476193064",
        "id" : 476193064
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540586826331746304",
    "text" : "I applaud Justice Dept for its work to build community trust, and thank @BilldeBlasio\u2019s team for leadership in the face of this outrage. -vp",
    "id" : 540586826331746304,
    "created_at" : "2014-12-04 19:21:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 540588876558245888,
  "created_at" : "2014-12-04 19:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 17, 24 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 54, 73 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/xV8lMbJf9y",
      "expanded_url" : "http:\/\/wh.gov\/college-opportunity",
      "display_url" : "wh.gov\/college-opport\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540588036544028672",
  "text" : "RT @arneduncan: .@FLOTUS will be speaking next at the #CollegeOpportunity Day of Action. Watch live at http:\/\/t.co\/xV8lMbJf9y. #ReachHigher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 1, 8 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 38, 57 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/xV8lMbJf9y",
        "expanded_url" : "http:\/\/wh.gov\/college-opportunity",
        "display_url" : "wh.gov\/college-opport\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "540587488172314624",
    "text" : ".@FLOTUS will be speaking next at the #CollegeOpportunity Day of Action. Watch live at http:\/\/t.co\/xV8lMbJf9y. #ReachHigher",
    "id" : 540587488172314624,
    "created_at" : "2014-12-04 19:24:35 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 540588036544028672,
  "created_at" : "2014-12-04 19:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Tom Kruse",
      "screen_name" : "TtomKruse",
      "indices" : [ 16, 26 ],
      "id_str" : "67724670",
      "id" : 67724670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/S1F79i40b5",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/06\/09\/factsheet-making-student-loans-more-affordable",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540583395336921088",
  "text" : "RT @arneduncan: @TtomKruse More info on the President's action to cap student loan repayments. http:\/\/t.co\/S1F79i40b5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Kruse",
        "screen_name" : "TtomKruse",
        "indices" : [ 0, 10 ],
        "id_str" : "67724670",
        "id" : 67724670
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/S1F79i40b5",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/06\/09\/factsheet-making-student-loans-more-affordable",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "540582253190184960",
    "geo" : { },
    "id_str" : "540583092269105152",
    "in_reply_to_user_id" : 67724670,
    "text" : "@TtomKruse More info on the President's action to cap student loan repayments. http:\/\/t.co\/S1F79i40b5",
    "id" : 540583092269105152,
    "in_reply_to_status_id" : 540582253190184960,
    "created_at" : "2014-12-04 19:07:07 +0000",
    "in_reply_to_screen_name" : "TtomKruse",
    "in_reply_to_user_id_str" : "67724670",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 540583395336921088,
  "created_at" : "2014-12-04 19:08:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 34, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540581780496347136",
  "text" : "RT @arneduncan: We're here at the #CollegeOpportunity Day of Action. I've got a few minutes, if you've got questions, send them using #AskA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 18, 37 ]
      }, {
        "text" : "AskArne",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540580575380529153",
    "text" : "We're here at the #CollegeOpportunity Day of Action. I've got a few minutes, if you've got questions, send them using #AskArne.",
    "id" : 540580575380529153,
    "created_at" : "2014-12-04 18:57:07 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 540581780496347136,
  "created_at" : "2014-12-04 19:01:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540578161269170177\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ubIiVEZLFD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4CE-NyCcAAP9cp.jpg",
      "id_str" : "540578159670751232",
      "id" : 540578159670751232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4CE-NyCcAAP9cp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ubIiVEZLFD"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 92, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/nBOcSNrpwF",
      "expanded_url" : "http:\/\/go.wh.gov\/ALWR3V",
      "display_url" : "go.wh.gov\/ALWR3V"
    } ]
  },
  "geo" : { },
  "id_str" : "540578161269170177",
  "text" : "Here's how President Obama has helped make college more affordable \u2192 http:\/\/t.co\/nBOcSNrpwF #CollegeOpportunity http:\/\/t.co\/ubIiVEZLFD",
  "id" : 540578161269170177,
  "created_at" : "2014-12-04 18:47:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "igorvolsky",
      "screen_name" : "igorvolsky",
      "indices" : [ 3, 14 ],
      "id_str" : "16002085",
      "id" : 16002085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540574497414602752",
  "text" : "RT @igorvolsky: Average Obamacare premiums DECREASED in at least 14 states in 2015:\n \nAR \nAZ\nGA\nIN \nKS \nME \nMO \nMS \nMT \nNH \nNJ \nNM \nPA \nSD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540570779801645056",
    "text" : "Average Obamacare premiums DECREASED in at least 14 states in 2015:\n \nAR \nAZ\nGA\nIN \nKS \nME \nMO \nMS \nMT \nNH \nNJ \nNM \nPA \nSD",
    "id" : 540570779801645056,
    "created_at" : "2014-12-04 18:18:11 +0000",
    "user" : {
      "name" : "igorvolsky",
      "screen_name" : "igorvolsky",
      "protected" : false,
      "id_str" : "16002085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796358847527026688\/tD8NKJli_normal.jpg",
      "id" : 16002085,
      "verified" : true
    }
  },
  "id" : 540574497414602752,
  "created_at" : "2014-12-04 18:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 87, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540565201020813312",
  "text" : "RT @vj44: \"Where you start in life shouldn't determine where you end up.\" - Pres Obama #CollegeOpportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 77, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540561093031362560",
    "text" : "\"Where you start in life shouldn't determine where you end up.\" - Pres Obama #CollegeOpportunity",
    "id" : 540561093031362560,
    "created_at" : "2014-12-04 17:39:42 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 540565201020813312,
  "created_at" : "2014-12-04 17:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 105, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540562314383351809",
  "text" : "\"If all of us work together...then there is no limit to what this country can achieve.\" \u2014President Obama #CollegeOpportunity",
  "id" : 540562314383351809,
  "created_at" : "2014-12-04 17:44:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 89, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yzgO5ZxAP7",
      "expanded_url" : "http:\/\/go.wh.gov\/juyoh2",
      "display_url" : "go.wh.gov\/juyoh2"
    } ]
  },
  "geo" : { },
  "id_str" : "540561148396195840",
  "text" : "\"Today we\u2019re announcing a handful of executive actions we can take immediately to expand #CollegeOpportunity\" \u2014Obama: http:\/\/t.co\/yzgO5ZxAP7",
  "id" : 540561148396195840,
  "created_at" : "2014-12-04 17:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540560501735182336",
  "text" : "RT @WHLive: \"This is something that Michelle is passionate about...she knows firsthand the difference a good counselor can make\" \u2014Obama #Re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540560477643104256",
    "text" : "\"This is something that Michelle is passionate about...she knows firsthand the difference a good counselor can make\" \u2014Obama #ReachHigher",
    "id" : 540560477643104256,
    "created_at" : "2014-12-04 17:37:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 540560501735182336,
  "created_at" : "2014-12-04 17:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540559350381940736",
  "text" : "RT @WHLive: \"More than 2,000 colleges are waiving application fees for low-income students.\" \u2014President Obama #CollegeOpportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 98, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540559324687654912",
    "text" : "\"More than 2,000 colleges are waiving application fees for low-income students.\" \u2014President Obama #CollegeOpportunity",
    "id" : 540559324687654912,
    "created_at" : "2014-12-04 17:32:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 540559350381940736,
  "created_at" : "2014-12-04 17:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540559185566793728\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/G44eFz2dF1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4BznZ0CEAALoui.jpg",
      "id_str" : "540559076065677312",
      "id" : 540559076065677312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4BznZ0CEAALoui.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G44eFz2dF1"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 98, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540559185566793728",
  "text" : "\"I took executive action to give Americans the chance to cap their student loan payments.\" \u2014Obama #CollegeOpportunity http:\/\/t.co\/G44eFz2dF1",
  "id" : 540559185566793728,
  "created_at" : "2014-12-04 17:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540558853633769473",
  "text" : "\"No matter who you are...or where you come from, you can make it. That\u2019s the essential promise of America.\" \u2014Obama #CollegeOpportunity",
  "id" : 540558853633769473,
  "created_at" : "2014-12-04 17:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540558737745121281",
  "text" : "\"We were founded on the idea that everybody should have an equal opportunity to succeed.\" \u2014President Obama on expanding #CollegeOpportunity",
  "id" : 540558737745121281,
  "created_at" : "2014-12-04 17:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/540557923886596096\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/OfPEx9V6RC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4ByjGZCUAAYFZF.jpg",
      "id_str" : "540557902621069312",
      "id" : 540557902621069312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4ByjGZCUAAYFZF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OfPEx9V6RC"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 82, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540557923886596096",
  "text" : "\"I want to make sure we lead the world in education once again.\" \u2014President Obama #CollegeOpportunity http:\/\/t.co\/OfPEx9V6RC",
  "id" : 540557923886596096,
  "created_at" : "2014-12-04 17:27:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 112, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540557637499486209",
  "text" : "RT @WHLive: \"Our higher education system is one of the things that makes America exceptional.\" \u2014President Obama #CollegeOpportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 100, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540557613617123329",
    "text" : "\"Our higher education system is one of the things that makes America exceptional.\" \u2014President Obama #CollegeOpportunity",
    "id" : 540557613617123329,
    "created_at" : "2014-12-04 17:25:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 540557637499486209,
  "created_at" : "2014-12-04 17:25:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540557548114681856",
  "text" : "\"Big challenges like these should unite us around an opportunity agenda that brings us together, rather than pulling us apart.\" \u2014Obama",
  "id" : 540557548114681856,
  "created_at" : "2014-12-04 17:25:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540557459749093376",
  "text" : "\u201CAt some level everybody is our kid, everybody is our responsibility. We are going to give back to everybody.\u201D \u2014Obama #OpportunityForAll",
  "id" : 540557459749093376,
  "created_at" : "2014-12-04 17:25:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540556289202733056",
  "text" : "\"Making sure more of our young people have access to higher education\u2026that has to be an American issue\" \u2014President Obama #CollegeOpportunity",
  "id" : 540556289202733056,
  "created_at" : "2014-12-04 17:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 51, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/f29bkzf0YF",
      "expanded_url" : "http:\/\/go.wh.gov\/SDTf4q",
      "display_url" : "go.wh.gov\/SDTf4q"
    } ]
  },
  "geo" : { },
  "id_str" : "540555499394334720",
  "text" : "Happening now: President Obama speaks on expanding #CollegeOpportunity for more students \u2192 http:\/\/t.co\/f29bkzf0YF",
  "id" : 540555499394334720,
  "created_at" : "2014-12-04 17:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 70, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/yzgO5ZxAP7",
      "expanded_url" : "http:\/\/go.wh.gov\/juyoh2",
      "display_url" : "go.wh.gov\/juyoh2"
    } ]
  },
  "geo" : { },
  "id_str" : "540550063316287489",
  "text" : "Organizations are announcing more than 600 new actions to help expand #CollegeOpportunity for more students \u2192 http:\/\/t.co\/yzgO5ZxAP7",
  "id" : 540550063316287489,
  "created_at" : "2014-12-04 16:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540540950247112707\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/7gJBx6nfIP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4BisnlCIAAxdGx.jpg",
      "id_str" : "540540473962536960",
      "id" : 540540473962536960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4BisnlCIAAxdGx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7gJBx6nfIP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540540950247112707",
  "text" : "President Obama's action on student loans will help millions of Americans lower their monthly loan payments. http:\/\/t.co\/7gJBx6nfIP",
  "id" : 540540950247112707,
  "created_at" : "2014-12-04 16:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/540534241541754880\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/vNnspjjPlQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4Bc_KRCYAEN9Kt.jpg",
      "id_str" : "540534195441786881",
      "id" : 540534195441786881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4Bc_KRCYAEN9Kt.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vNnspjjPlQ"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 35, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/f29bkzf0YF",
      "expanded_url" : "http:\/\/go.wh.gov\/SDTf4q",
      "display_url" : "go.wh.gov\/SDTf4q"
    } ]
  },
  "geo" : { },
  "id_str" : "540534241541754880",
  "text" : "Watch President Obama speak at the #CollegeOpportunity Day of Action at 11:50am ET \u2192 http:\/\/t.co\/f29bkzf0YF http:\/\/t.co\/vNnspjjPlQ",
  "id" : 540534241541754880,
  "created_at" : "2014-12-04 15:53:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EricGarner",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/BwzL009O7K",
      "expanded_url" : "http:\/\/youtu.be\/ZQtIhQ9zpEQ",
      "display_url" : "youtu.be\/ZQtIhQ9zpEQ"
    } ]
  },
  "geo" : { },
  "id_str" : "540295500696547329",
  "text" : "\"When anybody in this country is not being treated equally under the law, that's a problem.\" \u2014Obama: http:\/\/t.co\/BwzL009O7K #EricGarner",
  "id" : 540295500696547329,
  "created_at" : "2014-12-04 00:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EricGarner",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/BwzL009O7K",
      "expanded_url" : "http:\/\/youtu.be\/ZQtIhQ9zpEQ",
      "display_url" : "youtu.be\/ZQtIhQ9zpEQ"
    } ]
  },
  "geo" : { },
  "id_str" : "540284081544511489",
  "text" : "This is not a black problem or a white problem, this is an American problem: http:\/\/t.co\/BwzL009O7K #EricGarner",
  "id" : 540284081544511489,
  "created_at" : "2014-12-03 23:18:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EricGarner",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/BwzL009O7K",
      "expanded_url" : "http:\/\/youtu.be\/ZQtIhQ9zpEQ",
      "display_url" : "youtu.be\/ZQtIhQ9zpEQ"
    } ]
  },
  "geo" : { },
  "id_str" : "540280240023416832",
  "text" : "Watch President Obama's statement on the #EricGarner decision \u2192 http:\/\/t.co\/BwzL009O7K",
  "id" : 540280240023416832,
  "created_at" : "2014-12-03 23:03:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540265093108215810",
  "text" : "\"Together, we can make sure that every Native young person is treated like a valuable member\u2026of the American family.\" \u2014Obama #TribalNations",
  "id" : 540265093108215810,
  "created_at" : "2014-12-03 22:03:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540264863658823682",
  "text" : "\"We\u2019re all one family. Your nations have made extraordinary contributions to this country\" \u2014President Obama at the #TribalNations Conference",
  "id" : 540264863658823682,
  "created_at" : "2014-12-03 22:02:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540263828009656320",
  "text" : "\"We\u2019re going to keep working with your communities to deal with the very real impacts of climate change.\" \u2014President Obama #TribalNations",
  "id" : 540263828009656320,
  "created_at" : "2014-12-03 21:58:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540263471321841664",
  "text" : "\"They are our children and they deserve the chance to achieve their dreams.\" \u2014President Obama on the kids of #TribalNations",
  "id" : 540263471321841664,
  "created_at" : "2014-12-03 21:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540261127502843904",
  "text" : "\"When anybody in this country is not being treated equally under the law, that\u2019s a problem. And it\u2019s my job...to help solve it.\u201D \u2014Obama",
  "id" : 540261127502843904,
  "created_at" : "2014-12-03 21:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/8mUQ1l5r72",
      "expanded_url" : "http:\/\/go.wh.gov\/9TMR41",
      "display_url" : "go.wh.gov\/9TMR41"
    } ]
  },
  "geo" : { },
  "id_str" : "540260128075681792",
  "text" : "Watch live: President Obama speaks at the #TribalNations Conference \u2192 http:\/\/t.co\/8mUQ1l5r72",
  "id" : 540260128075681792,
  "created_at" : "2014-12-03 21:43:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/b27Zw9SpZS",
      "expanded_url" : "http:\/\/usat.ly\/1yckH9Y",
      "display_url" : "usat.ly\/1yckH9Y"
    } ]
  },
  "geo" : { },
  "id_str" : "540240735358840832",
  "text" : "More than 200 companies, including major brand names, support President Obama's Clean Power Plan \u2192 http:\/\/t.co\/b27Zw9SpZS #ActOnClimate",
  "id" : 540240735358840832,
  "created_at" : "2014-12-03 20:26:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540220281596297216",
  "text" : "RT @FLOTUS: \"No matter what you all are going through\u2026you guys always, always, always step up.\" \u2014The First Lady to military families #WHHol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHolidays",
        "indices" : [ 121, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540216599009980416",
    "text" : "\"No matter what you all are going through\u2026you guys always, always, always step up.\" \u2014The First Lady to military families #WHHolidays",
    "id" : 540216599009980416,
    "created_at" : "2014-12-03 18:50:48 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 540220281596297216,
  "created_at" : "2014-12-03 19:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/540197533927350272\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/talCNlah4a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B38qs7zCAAALy8Y.jpg",
      "id_str" : "540197431762092032",
      "id" : 540197431762092032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B38qs7zCAAALy8Y.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/talCNlah4a"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540197533927350272",
  "text" : "\"It doesn't make sense for us to have a first-class economy and second-class infrastructure.\" \u2014Obama #RebuildAmerica http:\/\/t.co\/talCNlah4a",
  "id" : 540197533927350272,
  "created_at" : "2014-12-03 17:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/hgkbKO5jUn",
      "expanded_url" : "http:\/\/go.wh.gov\/E7ZkyE",
      "display_url" : "go.wh.gov\/E7ZkyE"
    } ]
  },
  "geo" : { },
  "id_str" : "540182342514782208",
  "text" : "Listen live: President Obama speaks to the Business Roundtable on how we can keep growing our economy \u2192 http:\/\/t.co\/hgkbKO5jUn",
  "id" : 540182342514782208,
  "created_at" : "2014-12-03 16:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540162753932324864",
  "text" : "RT @VP: Progress since #VAWA first passed:\n\u2022 64% drop in violence\n\u2022 Billions of dollars averted in social costs\n\u2022 National Domestic Violenc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 15, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "540153644868718592",
    "text" : "Progress since #VAWA first passed:\n\u2022 64% drop in violence\n\u2022 Billions of dollars averted in social costs\n\u2022 National Domestic Violence Hotline",
    "id" : 540153644868718592,
    "created_at" : "2014-12-03 14:40:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 540162753932324864,
  "created_at" : "2014-12-03 15:16:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/VzM8BLYXQD",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/2014-white-house-tribal-nations-conference",
      "display_url" : "whitehouse.gov\/live\/2014-whit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540152542089723904",
  "text" : "RT @VP: Happening now: VP Biden speaks at the White House Tribal Nations Conference http:\/\/t.co\/VzM8BLYXQD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/VzM8BLYXQD",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/2014-white-house-tribal-nations-conference",
        "display_url" : "whitehouse.gov\/live\/2014-whit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "540150796784918528",
    "text" : "Happening now: VP Biden speaks at the White House Tribal Nations Conference http:\/\/t.co\/VzM8BLYXQD",
    "id" : 540150796784918528,
    "created_at" : "2014-12-03 14:29:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 540152542089723904,
  "created_at" : "2014-12-03 14:36:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/539949469857361920\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/19zPEXScSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B35I4ivCAAEdy5q.jpg",
      "id_str" : "539949141564981249",
      "id" : 539949141564981249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B35I4ivCAAEdy5q.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 1122
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/19zPEXScSe"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/QWiOyJaBjx",
      "expanded_url" : "http:\/\/go.wh.gov\/NsDdPm",
      "display_url" : "go.wh.gov\/NsDdPm"
    } ]
  },
  "geo" : { },
  "id_str" : "539949469857361920",
  "text" : "\"We can\u2019t just fight this epidemic, we have to extinguish it.\" \u2014President Obama on #Ebola: http:\/\/t.co\/QWiOyJaBjx http:\/\/t.co\/19zPEXScSe",
  "id" : 539949469857361920,
  "created_at" : "2014-12-03 01:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539906119175397376\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/OX9by4vS9O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B34hqYzCMAA-fTw.jpg",
      "id_str" : "539906017425764352",
      "id" : 539906017425764352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34hqYzCMAA-fTw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OX9by4vS9O"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539906119175397376",
  "text" : "\u201CLet\u2019s get it done\u2026we need to protect the American people.\u201D \u2014President Obama on funding our fight against #Ebola http:\/\/t.co\/OX9by4vS9O",
  "id" : 539906119175397376,
  "created_at" : "2014-12-02 22:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539905201251942400",
  "text" : "\"The American people have sent Washington a pretty clear message: Find areas where you agree\u2026work together and get the job done.\" \u2014Obama",
  "id" : 539905201251942400,
  "created_at" : "2014-12-02 22:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539904460298780672\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/waIFFNyACz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B34gPfVCUAErlw8.jpg",
      "id_str" : "539904455810895873",
      "id" : 539904455810895873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34gPfVCUAErlw8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/waIFFNyACz"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539904460298780672",
  "text" : "\"I\u2019m calling on Congress to approve our emergency funding request to fight this disease.\" \u2014President Obama #Ebola http:\/\/t.co\/waIFFNyACz",
  "id" : 539904460298780672,
  "created_at" : "2014-12-02 22:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539904241255456768",
  "text" : "\"We cannot beat #Ebola without more funding. And if we want other countries to keep stepping up, we have to keep leading the way.\" \u2014Obama",
  "id" : 539904241255456768,
  "created_at" : "2014-12-02 22:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/kICO4RYtO9",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "539903706854981632",
  "text" : "\"The best way to fight this disease...is to stop it at its source.\" \u2014President Obama on our response to #Ebola: http:\/\/t.co\/kICO4RYtO9",
  "id" : 539903706854981632,
  "created_at" : "2014-12-02 22:07:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539903334711181313",
  "text" : "RT @WHLive: \"Because we\u2019ve stepped up our efforts in recent months\u2014we\u2019re more prepared when it comes to protecting Americans here at home\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539903310535204865",
    "text" : "\"Because we\u2019ve stepped up our efforts in recent months\u2014we\u2019re more prepared when it comes to protecting Americans here at home\" \u2014Obama #Ebola",
    "id" : 539903310535204865,
    "created_at" : "2014-12-02 22:05:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 539903334711181313,
  "created_at" : "2014-12-02 22:06:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 104, 108 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539902730144190464",
  "text" : "\"No potential Ebola vaccine has ever made it this far. So this is exciting news.\" \u2014Obama on progress at @NIH to develop an #Ebola vaccine",
  "id" : 539902730144190464,
  "created_at" : "2014-12-02 22:03:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 79, 83 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539901839328563200",
  "text" : "RT @WHLive: \"Every day, we\u2019re focused on keeping the American people safe. And @NIH is at the forefront\" \u2014President Obama #Ebola",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NIH",
        "screen_name" : "NIH",
        "indices" : [ 67, 71 ],
        "id_str" : "15134240",
        "id" : 15134240
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539901812656992256",
    "text" : "\"Every day, we\u2019re focused on keeping the American people safe. And @NIH is at the forefront\" \u2014President Obama #Ebola",
    "id" : 539901812656992256,
    "created_at" : "2014-12-02 21:59:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 539901839328563200,
  "created_at" : "2014-12-02 22:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/MYAfUNCbHt",
      "expanded_url" : "http:\/\/go.wh.gov\/bymZ7k",
      "display_url" : "go.wh.gov\/bymZ7k"
    } ]
  },
  "geo" : { },
  "id_str" : "539900983099133953",
  "text" : "Watch live: President Obama gives an update on our fight against #Ebola \u2192 http:\/\/t.co\/MYAfUNCbHt",
  "id" : 539900983099133953,
  "created_at" : "2014-12-02 21:56:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "reddit AMA",
      "screen_name" : "reddit_AMA",
      "indices" : [ 105, 116 ],
      "id_str" : "524487620",
      "id" : 524487620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JourneyToMars",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539899351871410178",
  "text" : "RT @NASA: We're prepping humans to go to Mars. Ask the managers helming our #JourneyToMars anything in a @Reddit_AMA at 5pm ET http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "reddit AMA",
        "screen_name" : "reddit_AMA",
        "indices" : [ 95, 106 ],
        "id_str" : "524487620",
        "id" : 524487620
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/539887102339858434\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tfUiu7a6dh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B34QdUDIEAAz3vh.jpg",
        "id_str" : "539887101115109376",
        "id" : 539887101115109376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34QdUDIEAAz3vh.jpg",
        "sizes" : [ {
          "h" : 1125,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tfUiu7a6dh"
      } ],
      "hashtags" : [ {
        "text" : "JourneyToMars",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539887102339858434",
    "text" : "We're prepping humans to go to Mars. Ask the managers helming our #JourneyToMars anything in a @Reddit_AMA at 5pm ET http:\/\/t.co\/tfUiu7a6dh",
    "id" : 539887102339858434,
    "created_at" : "2014-12-02 21:01:30 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 539899351871410178,
  "created_at" : "2014-12-02 21:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539893479917101056\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/i9oV9jZlsq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B34WMaRCEAADQhw.jpg",
      "id_str" : "539893407796039680",
      "id" : 539893407796039680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B34WMaRCEAADQhw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i9oV9jZlsq"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/MYAfUNCbHt",
      "expanded_url" : "http:\/\/go.wh.gov\/bymZ7k",
      "display_url" : "go.wh.gov\/bymZ7k"
    } ]
  },
  "geo" : { },
  "id_str" : "539893479917101056",
  "text" : "President Obama will give an update on our fight against #Ebola at 5pm ET. Watch \u2192 http:\/\/t.co\/MYAfUNCbHt http:\/\/t.co\/i9oV9jZlsq",
  "id" : 539893479917101056,
  "created_at" : "2014-12-02 21:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GivingTuesday",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vCj1D7v78I",
      "expanded_url" : "http:\/\/go.wh.gov\/BLSQhi",
      "display_url" : "go.wh.gov\/BLSQhi"
    } ]
  },
  "geo" : { },
  "id_str" : "539883599051620354",
  "text" : "\"Everyday acts of kindness build a momentum for change that drives our nation forward.\" \u2014Obama on #GivingTuesday: http:\/\/t.co\/vCj1D7v78I",
  "id" : 539883599051620354,
  "created_at" : "2014-12-02 20:47:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smithsonian",
      "screen_name" : "smithsonian",
      "indices" : [ 75, 87 ],
      "id_str" : "14199378",
      "id" : 14199378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hUYt0FOeHE",
      "expanded_url" : "http:\/\/youtu.be\/4GiLAOtjHNo",
      "display_url" : "youtu.be\/4GiLAOtjHNo"
    } ]
  },
  "geo" : { },
  "id_str" : "539862504675872768",
  "text" : "Introducing the first-ever 3D-printed presidential portrait. Watch how the @Smithsonian made it \u2192 http:\/\/t.co\/hUYt0FOeHE",
  "id" : 539862504675872768,
  "created_at" : "2014-12-02 19:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/hUYt0FOeHE",
      "expanded_url" : "http:\/\/youtu.be\/4GiLAOtjHNo",
      "display_url" : "youtu.be\/4GiLAOtjHNo"
    } ]
  },
  "geo" : { },
  "id_str" : "539853129085247488",
  "text" : "A presidential portrait.\nOf President Obama.\nIn 3D.\nWatch \u2192 http:\/\/t.co\/hUYt0FOeHE",
  "id" : 539853129085247488,
  "created_at" : "2014-12-02 18:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/539843047631384576\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3bVVwnGaYm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B33oMoQCMAAoBZx.jpg",
      "id_str" : "539842834015072256",
      "id" : 539842834015072256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B33oMoQCMAAoBZx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3bVVwnGaYm"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/u5nKoqJlPB",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "539843047631384576",
  "text" : "We're making progress in the fight against #Ebola, but Congress needs to fund our efforts \u2192 http:\/\/t.co\/u5nKoqJlPB http:\/\/t.co\/3bVVwnGaYm",
  "id" : 539843047631384576,
  "created_at" : "2014-12-02 18:06:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539833199091019776\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/UCdI3wsYRD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B33fNm_CIAAHCH7.jpg",
      "id_str" : "539832955250548736",
      "id" : 539832955250548736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B33fNm_CIAAHCH7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UCdI3wsYRD"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/u5nKoqJlPB",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "539833199091019776",
  "text" : "It's time for Congress to help fight #Ebola at home and abroad \u2192 http:\/\/t.co\/u5nKoqJlPB http:\/\/t.co\/UCdI3wsYRD",
  "id" : 539833199091019776,
  "created_at" : "2014-12-02 17:27:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/QWrBNxjRbl",
      "expanded_url" : "http:\/\/abcn.ws\/1HVcPSd",
      "display_url" : "abcn.ws\/1HVcPSd"
    } ]
  },
  "geo" : { },
  "id_str" : "539816040382083072",
  "text" : "Good news. Efforts to improve patient safety saved about:\n50,000 lives \u2713\n$12 billion in health spending \u2713\nhttp:\/\/t.co\/QWrBNxjRbl #ACAWorks",
  "id" : 539816040382083072,
  "created_at" : "2014-12-02 16:19:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GivingTuesday",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539809633465282561",
  "text" : "RT @Cecilia44: Inspiring to see so many people taking part in #GivingTuesday and creating positive impact in their communities http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GivingTuesday",
        "indices" : [ 47, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/ypY4XeljGA",
        "expanded_url" : "http:\/\/go.wh.gov\/okQ5Dt",
        "display_url" : "go.wh.gov\/okQ5Dt"
      } ]
    },
    "geo" : { },
    "id_str" : "539793901532372994",
    "text" : "Inspiring to see so many people taking part in #GivingTuesday and creating positive impact in their communities http:\/\/t.co\/ypY4XeljGA",
    "id" : 539793901532372994,
    "created_at" : "2014-12-02 14:51:09 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 539809633465282561,
  "created_at" : "2014-12-02 15:53:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/539769722313928704\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/i7gxrdeDRh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B32ls9SIUAEMqAI.png",
      "id_str" : "539769722137759745",
      "id" : 539769722137759745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B32ls9SIUAEMqAI.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1035,
        "resize" : "fit",
        "w" : 2012
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/i7gxrdeDRh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/CJlToir1cx",
      "expanded_url" : "http:\/\/vox.com\/e\/7081940?utm_campaign=vox&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "vox.com\/e\/7081940?utm_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539802032929263616",
  "text" : "RT @voxdotcom: Obama's plan to reduce hospital errors is working \u2014 and it's saved 50,000 lives http:\/\/t.co\/CJlToir1cx http:\/\/t.co\/i7gxrdeDRh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sbnation.com\" rel=\"nofollow\"\u003ESB Nation\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/539769722313928704\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/i7gxrdeDRh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B32ls9SIUAEMqAI.png",
        "id_str" : "539769722137759745",
        "id" : 539769722137759745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B32ls9SIUAEMqAI.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1035,
          "resize" : "fit",
          "w" : 2012
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/i7gxrdeDRh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/CJlToir1cx",
        "expanded_url" : "http:\/\/vox.com\/e\/7081940?utm_campaign=vox&utm_content=chorus&utm_medium=social&utm_source=twitter",
        "display_url" : "vox.com\/e\/7081940?utm_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "539769722313928704",
    "text" : "Obama's plan to reduce hospital errors is working \u2014 and it's saved 50,000 lives http:\/\/t.co\/CJlToir1cx http:\/\/t.co\/i7gxrdeDRh",
    "id" : 539769722313928704,
    "created_at" : "2014-12-02 13:15:04 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 539802032929263616,
  "created_at" : "2014-12-02 15:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "indices" : [ 3, 18 ],
      "id_str" : "20196258",
      "id" : 20196258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539629076487880704",
  "text" : "RT @ElizabethBanks: Are you in search of a good #CyberMonday deal? Sign up for quality, affordable health coverage at http:\/\/t.co\/cI9IG7vPc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberMonday",
        "indices" : [ 28, 40 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 122, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/cI9IG7vPc1",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "539566852603527168",
    "text" : "Are you in search of a good #CyberMonday deal? Sign up for quality, affordable health coverage at http:\/\/t.co\/cI9IG7vPc1. #GetCovered",
    "id" : 539566852603527168,
    "created_at" : "2014-12-01 23:48:56 +0000",
    "user" : {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "protected" : false,
      "id_str" : "20196258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791454824306880512\/YiAb44jE_normal.jpg",
      "id" : 20196258,
      "verified" : true
    }
  },
  "id" : 539629076487880704,
  "created_at" : "2014-12-02 03:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 6, 18 ]
    }, {
      "text" : "CyberMonday",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "GivingTuesday",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/YXtBRqno8b",
      "expanded_url" : "http:\/\/go.wh.gov\/okQ5Dt",
      "display_url" : "go.wh.gov\/okQ5Dt"
    } ]
  },
  "geo" : { },
  "id_str" : "539592373513113600",
  "text" : "After #BlackFriday and #CyberMonday comes #GivingTuesday\u2014a day for all Americans to give back to their communities: http:\/\/t.co\/YXtBRqno8b",
  "id" : 539592373513113600,
  "created_at" : "2014-12-02 01:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539580158273802240\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WHmAPBq3II",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3z5PvuCIAAWnBV.jpg",
      "id_str" : "539580104280514560",
      "id" : 539580104280514560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3z5PvuCIAAWnBV.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/WHmAPBq3II"
    } ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539580158273802240",
  "text" : "\"We're closer than we've ever been to achieving the extraordinary: An AIDS-free generation.\" \u2014Obama #WorldAIDSDay http:\/\/t.co\/WHmAPBq3II",
  "id" : 539580158273802240,
  "created_at" : "2014-12-02 00:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539539274849595392\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/m988wvzNfF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3zUDwICMAApGN4.jpg",
      "id_str" : "539539216300912640",
      "id" : 539539216300912640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3zUDwICMAApGN4.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/m988wvzNfF"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "CyberMonday",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/JxkdfixJNs",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539539274849595392",
  "text" : "If you or someone you know needs health coverage, #GetCovered today at http:\/\/t.co\/JxkdfixJNs #CyberMonday http:\/\/t.co\/m988wvzNfF",
  "id" : 539539274849595392,
  "created_at" : "2014-12-01 21:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kerrywashington\/status\/539518399391744000\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/IYQh5i7VVh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3zBH7SIgAACWY6.jpg",
      "id_str" : "539518397294608384",
      "id" : 539518397294608384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3zBH7SIgAACWY6.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 338
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 338
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 338
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 338
      } ],
      "display_url" : "pic.twitter.com\/IYQh5i7VVh"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/msWlOTRPQM",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539522529531281408",
  "text" : "RT @kerrywashington: #GetCovered Sign up for quality health coverage TODAY! http:\/\/t.co\/msWlOTRPQM http:\/\/t.co\/IYQh5i7VVh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kerrywashington\/status\/539518399391744000\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/IYQh5i7VVh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3zBH7SIgAACWY6.jpg",
        "id_str" : "539518397294608384",
        "id" : 539518397294608384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3zBH7SIgAACWY6.jpg",
        "sizes" : [ {
          "h" : 336,
          "resize" : "fit",
          "w" : 338
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 338
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 338
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 338
        } ],
        "display_url" : "pic.twitter.com\/IYQh5i7VVh"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/msWlOTRPQM",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "539518399391744000",
    "text" : "#GetCovered Sign up for quality health coverage TODAY! http:\/\/t.co\/msWlOTRPQM http:\/\/t.co\/IYQh5i7VVh",
    "id" : 539518399391744000,
    "created_at" : "2014-12-01 20:36:24 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 539522529531281408,
  "created_at" : "2014-12-01 20:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/1zaEmKG9eT",
      "expanded_url" : "http:\/\/youtu.be\/xUlqoc4G1T4",
      "display_url" : "youtu.be\/xUlqoc4G1T4"
    } ]
  },
  "geo" : { },
  "id_str" : "539517305345277952",
  "text" : "\"Let's recommit ourselves to achieving an AIDS-free generation.\" \u2014President Obama: http:\/\/t.co\/1zaEmKG9eT #WorldAIDSDay",
  "id" : 539517305345277952,
  "created_at" : "2014-12-01 20:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "indices" : [ 3, 12 ],
      "id_str" : "262388975",
      "id" : 262388975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/CbQVG55cJ5",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/K8wLUFNaBB",
      "expanded_url" : "http:\/\/www.whosay.com\/l\/PlD9KKC",
      "display_url" : "whosay.com\/l\/PlD9KKC"
    } ]
  },
  "geo" : { },
  "id_str" : "539514661922955264",
  "text" : "RT @DuleHill: Already online for #CyberMonday? Don't forget to #GetCovered at http:\/\/t.co\/CbQVG55cJ5 http:\/\/t.co\/K8wLUFNaBB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberMonday",
        "indices" : [ 19, 31 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/CbQVG55cJ5",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/K8wLUFNaBB",
        "expanded_url" : "http:\/\/www.whosay.com\/l\/PlD9KKC",
        "display_url" : "whosay.com\/l\/PlD9KKC"
      } ]
    },
    "geo" : { },
    "id_str" : "539485942181294082",
    "text" : "Already online for #CyberMonday? Don't forget to #GetCovered at http:\/\/t.co\/CbQVG55cJ5 http:\/\/t.co\/K8wLUFNaBB",
    "id" : 539485942181294082,
    "created_at" : "2014-12-01 18:27:26 +0000",
    "user" : {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "protected" : false,
      "id_str" : "262388975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780784540390264832\/k8smqjX2_normal.jpg",
      "id" : 262388975,
      "verified" : true
    }
  },
  "id" : 539514661922955264,
  "created_at" : "2014-12-01 20:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shonda rhimes",
      "screen_name" : "shondarhimes",
      "indices" : [ 3, 16 ],
      "id_str" : "17565514",
      "id" : 17565514
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/534783594758021122\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sxN9R31G1n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "id_str" : "534783568182923264",
      "id" : 534783568182923264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sxN9R31G1n"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GSGaG8fC3q",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539512433698955264",
  "text" : "RT @shondarhimes: Spread the word: If you need health coverage, you can #GetCovered today at http:\/\/t.co\/GSGaG8fC3q.  http:\/\/t.co\/sxN9R31G1n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/534783594758021122\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/sxN9R31G1n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
        "id_str" : "534783568182923264",
        "id" : 534783568182923264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/sxN9R31G1n"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/GSGaG8fC3q",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "539510674192203776",
    "text" : "Spread the word: If you need health coverage, you can #GetCovered today at http:\/\/t.co\/GSGaG8fC3q.  http:\/\/t.co\/sxN9R31G1n",
    "id" : 539510674192203776,
    "created_at" : "2014-12-01 20:05:43 +0000",
    "user" : {
      "name" : "shonda rhimes",
      "screen_name" : "shondarhimes",
      "protected" : false,
      "id_str" : "17565514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770768752858107904\/6gV0N9j9_normal.jpg",
      "id" : 17565514,
      "verified" : true
    }
  },
  "id" : 539512433698955264,
  "created_at" : "2014-12-01 20:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539501754333679616\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KnAjjmptRc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3yv1sRCcAAXwJ1.jpg",
      "id_str" : "539499392328167424",
      "id" : 539499392328167424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3yv1sRCcAAXwJ1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KnAjjmptRc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Ks4pBirLQ5",
      "expanded_url" : "http:\/\/go.wh.gov\/PR65LJ",
      "display_url" : "go.wh.gov\/PR65LJ"
    } ]
  },
  "geo" : { },
  "id_str" : "539501754333679616",
  "text" : "Strengthening community policing isn't just a Ferguson issue.\nIt's an American issue \u2192 http:\/\/t.co\/Ks4pBirLQ5 http:\/\/t.co\/KnAjjmptRc",
  "id" : 539501754333679616,
  "created_at" : "2014-12-01 19:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539493090483253248\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/EfIKqCk6PD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ypxzaCAAAxyJd.jpg",
      "id_str" : "539492728455692288",
      "id" : 539492728455692288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ypxzaCAAAxyJd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EfIKqCk6PD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/vROSsVOA2Q",
      "expanded_url" : "http:\/\/go.wh.gov\/PR65LJ",
      "display_url" : "go.wh.gov\/PR65LJ"
    } ]
  },
  "geo" : { },
  "id_str" : "539493090483253248",
  "text" : "President Obama is announcing new steps to build trust between communities and local police \u2192 http:\/\/t.co\/vROSsVOA2Q http:\/\/t.co\/EfIKqCk6PD",
  "id" : 539493090483253248,
  "created_at" : "2014-12-01 18:55:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/lRAKWKDiIy",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539481029766283265",
  "text" : "RT @PAniskoff44: This Holiday season, don\u2019t you deserve peace on earth AND peace of mind? #GetCovered at http:\/\/t.co\/lRAKWKDiIy this #Cyber\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 73, 84 ]
      }, {
        "text" : "CyberMonday",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/lRAKWKDiIy",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "539451320588333056",
    "text" : "This Holiday season, don\u2019t you deserve peace on earth AND peace of mind? #GetCovered at http:\/\/t.co\/lRAKWKDiIy this #CyberMonday",
    "id" : 539451320588333056,
    "created_at" : "2014-12-01 16:09:52 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 539481029766283265,
  "created_at" : "2014-12-01 18:07:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/539462448898899968\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NdFmTSS7X6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3yOPQrIYAEqb7m.jpg",
      "id_str" : "539462448202670081",
      "id" : 539462448202670081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3yOPQrIYAEqb7m.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NdFmTSS7X6"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "CyberMonday",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/EO0WsRUooR",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539465717481885696",
  "text" : "RT @VP: Affordable health care won't break the bank. Shop to #GetCovered on #CyberMonday at http:\/\/t.co\/EO0WsRUooR \u2192 http:\/\/t.co\/NdFmTSS7X6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/539462448898899968\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/NdFmTSS7X6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3yOPQrIYAEqb7m.jpg",
        "id_str" : "539462448202670081",
        "id" : 539462448202670081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3yOPQrIYAEqb7m.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NdFmTSS7X6"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "CyberMonday",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/EO0WsRUooR",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "539462448898899968",
    "text" : "Affordable health care won't break the bank. Shop to #GetCovered on #CyberMonday at http:\/\/t.co\/EO0WsRUooR \u2192 http:\/\/t.co\/NdFmTSS7X6",
    "id" : 539462448898899968,
    "created_at" : "2014-12-01 16:54:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 539465717481885696,
  "created_at" : "2014-12-01 17:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539459705718857729\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/yYFnJGExHS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3yLDGTCYAEKpXM.jpg",
      "id_str" : "539458940723945473",
      "id" : 539458940723945473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3yLDGTCYAEKpXM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yYFnJGExHS"
    } ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539459705718857729",
  "text" : "#CyberMonday shopping?\nProtect your personal info:\n1\u20E3 Avoid suspicious links\n2\u20E3 Look for https:\/\/\n3\u20E3 Know your Wi-Fi http:\/\/t.co\/yYFnJGExHS",
  "id" : 539459705718857729,
  "created_at" : "2014-12-01 16:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 19, 31 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539450596474908672",
  "text" : "Looking for a good #CyberMonday deal? Shop for health coverage and #GetCovered from the comfort of your couch at http:\/\/t.co\/NSeLHFvc62.",
  "id" : 539450596474908672,
  "created_at" : "2014-12-01 16:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/539434604185141248\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/WHqfYQigbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3x02DnCUAAH2QE.jpg",
      "id_str" : "539434527408410624",
      "id" : 539434527408410624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3x02DnCUAAH2QE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WHqfYQigbK"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "CyberMonday",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/2S7CGldNyn",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "539434604185141248",
  "text" : "Need affordable health coverage? Pick a plan and #GetCovered at http:\/\/t.co\/2S7CGldNyn. #CyberMonday http:\/\/t.co\/WHqfYQigbK",
  "id" : 539434604185141248,
  "created_at" : "2014-12-01 15:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "London Removals Comp",
      "screen_name" : "Monedavis11",
      "indices" : [ 24, 36 ],
      "id_str" : "2451673879",
      "id" : 2451673879
    }, {
      "name" : "SI KIDS",
      "screen_name" : "SIKids",
      "indices" : [ 53, 60 ],
      "id_str" : "329896130",
      "id" : 329896130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SportsKid",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539404778603032576",
  "text" : "RT @FLOTUS: Congrats to @MoneDavis11 on becoming the @SIKids' 2014 #SportsKid of the Year! You knocked it out of the park for girls everywh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "London Removals Comp",
        "screen_name" : "Monedavis11",
        "indices" : [ 12, 24 ],
        "id_str" : "2451673879",
        "id" : 2451673879
      }, {
        "name" : "SI KIDS",
        "screen_name" : "SIKids",
        "indices" : [ 41, 48 ],
        "id_str" : "329896130",
        "id" : 329896130
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SportsKid",
        "indices" : [ 55, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539403567225126913",
    "text" : "Congrats to @MoneDavis11 on becoming the @SIKids' 2014 #SportsKid of the Year! You knocked it out of the park for girls everywhere. \u2013mo",
    "id" : 539403567225126913,
    "created_at" : "2014-12-01 13:00:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 539404778603032576,
  "created_at" : "2014-12-01 13:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]