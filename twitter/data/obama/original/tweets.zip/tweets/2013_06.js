Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/351505474446823424\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6cRlSah1Ng",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BODMXd2CEAELZnc.jpg",
      "id_str" : "351505474455212033",
      "id" : 351505474455212033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BODMXd2CEAELZnc.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6cRlSah1Ng"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351505474446823424",
  "text" : "President Obama looks out the window of former President Nelson Mandela's cell at Robben Island Prison in Cape Town: http:\/\/t.co\/6cRlSah1Ng",
  "id" : 351505474446823424,
  "created_at" : "2013-07-01 01:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/U2t1PC8raw",
      "expanded_url" : "http:\/\/wh.gov\/lc8wH",
      "display_url" : "wh.gov\/lc8wH"
    } ]
  },
  "geo" : { },
  "id_str" : "351499709250154498",
  "text" : "RT @FLOTUS: \"Today, our family visited Robben Island for an experience we will never forget.\" \u2014The First Lady. http:\/\/t.co\/U2t1PC8raw #FLOT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/U2t1PC8raw",
        "expanded_url" : "http:\/\/wh.gov\/lc8wH",
        "display_url" : "wh.gov\/lc8wH"
      } ]
    },
    "geo" : { },
    "id_str" : "351443629312712705",
    "text" : "\"Today, our family visited Robben Island for an experience we will never forget.\" \u2014The First Lady. http:\/\/t.co\/U2t1PC8raw #FLOTUSinAfrica",
    "id" : 351443629312712705,
    "created_at" : "2013-06-30 20:54:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 351499709250154498,
  "created_at" : "2013-07-01 00:37:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/351005622080253952\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ytMf4tfaDF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN8FwOrCMAAZl2e.jpg",
      "id_str" : "351005622088642560",
      "id" : 351005622088642560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN8FwOrCMAAZl2e.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ytMf4tfaDF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351109362007289856",
  "text" : "President Obama &amp; First Lady talk to Nelson Mandela's wife, Graca Machel, on the phone in South Africa http:\/\/t.co\/ytMf4tfaDF",
  "id" : 351109362007289856,
  "created_at" : "2013-06-29 22:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 46, 53 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 106, 121 ]
    }, {
      "text" : "ObamainAfrica",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/41gQL9COVU",
      "expanded_url" : "http:\/\/at.wh.gov\/mvnJc",
      "display_url" : "at.wh.gov\/mvnJc"
    } ]
  },
  "geo" : { },
  "id_str" : "351060457282482176",
  "text" : "Go behind the scenes with President Obama and @FLOTUS at Gor\u00E9e Island in Senegal:  http:\/\/t.co\/41gQL9COVU #FLOTUSinAfrica #ObamainAfrica",
  "id" : 351060457282482176,
  "created_at" : "2013-06-29 19:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7Nr9oViUeN",
      "expanded_url" : "http:\/\/at.wh.gov\/muula",
      "display_url" : "at.wh.gov\/muula"
    } ]
  },
  "geo" : { },
  "id_str" : "351007787452600321",
  "text" : "\"There is no contradiction between a sound environment and a strong economy.\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/7Nr9oViUeN",
  "id" : 351007787452600321,
  "created_at" : "2013-06-29 16:02:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/351002254024790016\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mTWtBQMJyJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN8CsLrCUAAZK4h.jpg",
      "id_str" : "351002254028984320",
      "id" : 351002254028984320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN8CsLrCUAAZK4h.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mTWtBQMJyJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351002569197355009",
  "text" : "RT @FLOTUS: These young people are amazing! With their commitment to education, I know they'll change the world. -mo http:\/\/t.co\/mTWtBQMJyJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/351002254024790016\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/mTWtBQMJyJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BN8CsLrCUAAZK4h.jpg",
        "id_str" : "351002254028984320",
        "id" : 351002254028984320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN8CsLrCUAAZK4h.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mTWtBQMJyJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351002254024790016",
    "text" : "These young people are amazing! With their commitment to education, I know they'll change the world. -mo http:\/\/t.co\/mTWtBQMJyJ",
    "id" : 351002254024790016,
    "created_at" : "2013-06-29 15:40:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 351002569197355009,
  "created_at" : "2013-06-29 15:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350984563159343104\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/aC3UIJrSj6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN7ymcECIAE69gy.jpg",
      "id_str" : "350984563163537409",
      "id" : 350984563163537409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN7ymcECIAE69gy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/aC3UIJrSj6"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/7JnQou1ANO",
      "expanded_url" : "http:\/\/on.wh.gov\/5hjFbVF",
      "display_url" : "on.wh.gov\/5hjFbVF"
    } ]
  },
  "geo" : { },
  "id_str" : "350984563159343104",
  "text" : "President Obama on his plan to reduce carbon pollution and #ActOnClimate change: http:\/\/t.co\/7JnQou1ANO, http:\/\/t.co\/aC3UIJrSj6",
  "id" : 350984563159343104,
  "created_at" : "2013-06-29 14:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350981474360627201",
  "text" : "RT @FLOTUS: Now: The First Lady joins students from South Africa &amp; the US in a Google+ Hangout on education. #FLOTUSinAfrica http:\/\/t.co\/0T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/350981281972097024\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/0TV3xIpIrd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BN7vnctCEAATIew.jpg",
        "id_str" : "350981281980485632",
        "id" : 350981281980485632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN7vnctCEAATIew.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0TV3xIpIrd"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350981281972097024",
    "text" : "Now: The First Lady joins students from South Africa &amp; the US in a Google+ Hangout on education. #FLOTUSinAfrica http:\/\/t.co\/0TV3xIpIrd",
    "id" : 350981281972097024,
    "created_at" : "2013-06-29 14:17:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 350981474360627201,
  "created_at" : "2013-06-29 14:17:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "350974722202275841",
  "text" : "Starting at 9:50ET: President Obama speaks at the Young African Leaders Initiative Town Hall in Johannesburg. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 350974722202275841,
  "created_at" : "2013-06-29 13:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "John Legend",
      "screen_name" : "johnlegend",
      "indices" : [ 45, 56 ],
      "id_str" : "18228898",
      "id" : 18228898
    }, {
      "name" : "Victoria Justice",
      "screen_name" : "VictoriaJustice",
      "indices" : [ 58, 74 ],
      "id_str" : "50037051",
      "id" : 50037051
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 117, 124 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350963372507934721",
  "text" : "RT @FLOTUS: Watch at 9:30ET: The First Lady, @johnlegend, @victoriajustice &amp; youth in Africa &amp; the US join a @Google+ Hangout. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Legend",
        "screen_name" : "johnlegend",
        "indices" : [ 33, 44 ],
        "id_str" : "18228898",
        "id" : 18228898
      }, {
        "name" : "Victoria Justice",
        "screen_name" : "VictoriaJustice",
        "indices" : [ 46, 62 ],
        "id_str" : "50037051",
        "id" : 50037051
      }, {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 105, 112 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 145 ],
        "url" : "http:\/\/t.co\/rtRpcBMV6j",
        "expanded_url" : "http:\/\/wh.gov\/flotusinafrica",
        "display_url" : "wh.gov\/flotusinafrica"
      } ]
    },
    "geo" : { },
    "id_str" : "350960471010058240",
    "text" : "Watch at 9:30ET: The First Lady, @johnlegend, @victoriajustice &amp; youth in Africa &amp; the US join a @Google+ Hangout. http:\/\/t.co\/rtRpcBMV6j",
    "id" : 350960471010058240,
    "created_at" : "2013-06-29 12:54:31 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 350963372507934721,
  "created_at" : "2013-06-29 13:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350939274369171456",
  "text" : "RT @FLOTUS: Today, I'm talking with young people in South Africa &amp; the US about the power of education. I hope you'll join. -mo #flotusinaf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "flotusinafrica",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350917718901407745",
    "text" : "Today, I'm talking with young people in South Africa &amp; the US about the power of education. I hope you'll join. -mo #flotusinafrica",
    "id" : 350917718901407745,
    "created_at" : "2013-06-29 10:04:38 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 350939274369171456,
  "created_at" : "2013-06-29 11:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/rGaV9Rz7rw",
      "expanded_url" : "http:\/\/at.wh.gov\/muCCf",
      "display_url" : "at.wh.gov\/muCCf"
    } ]
  },
  "geo" : { },
  "id_str" : "350740602788397057",
  "text" : "Great news: Eligible gay and lesbian couples will be able to receive federal employee benefits. http:\/\/t.co\/rGaV9Rz7rw #Equality",
  "id" : 350740602788397057,
  "created_at" : "2013-06-28 22:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350702679502233601\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/pJ5r36xQC0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN3yOpnCIAEfLCV.jpg",
      "id_str" : "350702679506427905",
      "id" : 350702679506427905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN3yOpnCIAEfLCV.jpg",
      "sizes" : [ {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1494
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pJ5r36xQC0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350702679502233601",
  "text" : "AdoraBulls: http:\/\/t.co\/pJ5r36xQC0",
  "id" : 350702679502233601,
  "created_at" : "2013-06-28 19:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350696382371344386\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/RqnUhV4YJy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN3sgG_CMAAVPvy.jpg",
      "id_str" : "350696382379732992",
      "id" : 350696382379732992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN3sgG_CMAAVPvy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/RqnUhV4YJy"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/spNzPK134v",
      "expanded_url" : "http:\/\/at.wh.gov\/mujAv",
      "display_url" : "at.wh.gov\/mujAv"
    } ]
  },
  "geo" : { },
  "id_str" : "350696382371344386",
  "text" : "It's time to #ActOnClimate change. Share President Obama's plan to make it happen: http:\/\/t.co\/spNzPK134v, http:\/\/t.co\/RqnUhV4YJy",
  "id" : 350696382371344386,
  "created_at" : "2013-06-28 19:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350668673100423171",
  "text" : "RT @FLOTUS: \"When girls are educated, their countries become stronger &amp; more prosperous.\"\n\u2014The First Lady #FLOTUSinAfrica http:\/\/t.co\/CTNq0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/350367511155441665\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/CTNq0manFG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNzBZSOCAAErcnb.jpg",
        "id_str" : "350367511159635969",
        "id" : 350367511159635969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNzBZSOCAAErcnb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CTNq0manFG"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350367511155441665",
    "text" : "\"When girls are educated, their countries become stronger &amp; more prosperous.\"\n\u2014The First Lady #FLOTUSinAfrica http:\/\/t.co\/CTNq0manFG",
    "id" : 350367511155441665,
    "created_at" : "2013-06-27 21:38:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 350668673100423171,
  "created_at" : "2013-06-28 17:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 81, 88 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350662238757081088\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/B4Wn3V6ejM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN3NcsHCUAAZBMK.png",
      "id_str" : "350662238765469696",
      "id" : 350662238765469696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN3NcsHCUAAZBMK.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/B4Wn3V6ejM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350662238757081088",
  "text" : "\"By investing in your education, you are doing the very best thing you can do.\" \u2014@FLOTUS to students in Senegal: http:\/\/t.co\/B4Wn3V6ejM",
  "id" : 350662238757081088,
  "created_at" : "2013-06-28 17:09:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350638573290143745\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/gT7cuPhWcz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN237LXCQAI_P4U.jpg",
      "id_str" : "350638573294338050",
      "id" : 350638573294338050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN237LXCQAI_P4U.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/gT7cuPhWcz"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/QuKM5lb4nz",
      "expanded_url" : "http:\/\/at.wh.gov\/mtNqR",
      "display_url" : "at.wh.gov\/mtNqR"
    } ]
  },
  "geo" : { },
  "id_str" : "350638573290143745",
  "text" : "RT so your friends see Obama's plan to reduce carbon pollution and #ActOnClimate change: http:\/\/t.co\/QuKM5lb4nz, http:\/\/t.co\/gT7cuPhWcz",
  "id" : 350638573290143745,
  "created_at" : "2013-06-28 15:35:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 35, 40 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350625332199555073",
  "text" : "RT @JoiningForces: Worth sharing:  @CFPB has ordered 2 deceptive lenders that targeted active-duty military to refund $6.5M: http:\/\/t.co\/g0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 16, 21 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/g01Brn5Kny",
        "expanded_url" : "http:\/\/1.usa.gov\/1aiGmWO",
        "display_url" : "1.usa.gov\/1aiGmWO"
      } ]
    },
    "geo" : { },
    "id_str" : "350622506119479297",
    "text" : "Worth sharing:  @CFPB has ordered 2 deceptive lenders that targeted active-duty military to refund $6.5M: http:\/\/t.co\/g01Brn5Kny",
    "id" : 350622506119479297,
    "created_at" : "2013-06-28 14:31:34 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 350625332199555073,
  "created_at" : "2013-06-28 14:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350611795658022913",
  "text" : "RT @pfeiffer44: A yr ago this week wouldn't have seemed possible. Major progress on Immigration, Same Sex Marriage, and Climate change. Pro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350577647883005952",
    "text" : "A yr ago this week wouldn't have seemed possible. Major progress on Immigration, Same Sex Marriage, and Climate change. Promises into Action",
    "id" : 350577647883005952,
    "created_at" : "2013-06-28 11:33:19 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 350611795658022913,
  "created_at" : "2013-06-28 13:49:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/RgoWXO4Bdj",
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350394259259662337\/photo\/1",
      "display_url" : "pic.twitter.com\/RgoWXO4Bdj"
    } ]
  },
  "geo" : { },
  "id_str" : "350403877532737536",
  "text" : "RT to spread the word: Immigration reform is one step closer to becoming law. http:\/\/t.co\/RgoWXO4Bdj",
  "id" : 350403877532737536,
  "created_at" : "2013-06-28 00:02:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350384478432137216",
  "text" : "\"If you\u2019re among the clear majority of Americans who support [immigration] reform...reach out to your Member of Congress.\" \u2014President Obama",
  "id" : 350384478432137216,
  "created_at" : "2013-06-27 22:45:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/zbp6gehSSj",
      "expanded_url" : "http:\/\/at.wh.gov\/mskQJ",
      "display_url" : "at.wh.gov\/mskQJ"
    } ]
  },
  "geo" : { },
  "id_str" : "350373320048381952",
  "text" : "RT @lacasablanca: Declaraciones del Presidente Obama sobre la aprobaci\u00F3n de la reforma migratoria por el Senado: http:\/\/t.co\/zbp6gehSSj #ci\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cirfloor",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/zbp6gehSSj",
        "expanded_url" : "http:\/\/at.wh.gov\/mskQJ",
        "display_url" : "at.wh.gov\/mskQJ"
      } ]
    },
    "geo" : { },
    "id_str" : "350373266449383427",
    "text" : "Declaraciones del Presidente Obama sobre la aprobaci\u00F3n de la reforma migratoria por el Senado: http:\/\/t.co\/zbp6gehSSj #cirfloor",
    "id" : 350373266449383427,
    "created_at" : "2013-06-27 22:01:11 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 350373320048381952,
  "created_at" : "2013-06-27 22:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 50, 62 ]
    }, {
      "text" : "cirfloor",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/CVUpWdBcz9",
      "expanded_url" : "http:\/\/at.wh.gov\/msffo",
      "display_url" : "at.wh.gov\/msffo"
    } ]
  },
  "geo" : { },
  "id_str" : "350373081728024576",
  "text" : "Statement by President Obama on Senate Passage of #Immigration Reform: http:\/\/t.co\/CVUpWdBcz9 #cirfloor",
  "id" : 350373081728024576,
  "created_at" : "2013-06-27 22:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350367389797453825",
  "text" : "\"We have a unique opportunity to fix our broken system...We just need Congress to finish the job.\" \u2014President Obama on #immigration reform",
  "id" : 350367389797453825,
  "created_at" : "2013-06-27 21:37:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/CVUpWdBcz9",
      "expanded_url" : "http:\/\/at.wh.gov\/msffo",
      "display_url" : "at.wh.gov\/msffo"
    } ]
  },
  "geo" : { },
  "id_str" : "350359954890293250",
  "text" : "\"Today, the Senate did its job. It\u2019s now up to the House to do the same.\" \u2014President Obama on #immigration reform: http:\/\/t.co\/CVUpWdBcz9",
  "id" : 350359954890293250,
  "created_at" : "2013-06-27 21:08:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "JulianCastro",
      "indices" : [ 70, 83 ],
      "id_str" : "19682187",
      "id" : 19682187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GYyQa5GHoM",
      "expanded_url" : "http:\/\/at.wh.gov\/ms62r",
      "display_url" : "at.wh.gov\/ms62r"
    } ]
  },
  "geo" : { },
  "id_str" : "350341582312054786",
  "text" : "\u201CIt truly is both common sense and comprehensive.\" \u2014San Antonio Mayor @JulianCastro on the Senate #immigration bill: http:\/\/t.co\/GYyQa5GHoM",
  "id" : 350341582312054786,
  "created_at" : "2013-06-27 19:55:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/s3WdJ7vtco",
      "expanded_url" : "http:\/\/at.wh.gov\/ms5K4",
      "display_url" : "at.wh.gov\/ms5K4"
    } ]
  },
  "geo" : { },
  "id_str" : "350339148755894275",
  "text" : "\u201C\u201CI\u2019m a DREAMer. I\u2019ve lived in the U.S. for the past 18 years. This is my home\u201D - Tolu Olubunmi http:\/\/t.co\/s3WdJ7vtco #immigration",
  "id" : 350339148755894275,
  "created_at" : "2013-06-27 19:45:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InstaVideo",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "ObamainAfrica",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/GBLYRDDoVb",
      "expanded_url" : "http:\/\/instagram.com\/p\/bEcpdXQiuz\/",
      "display_url" : "instagram.com\/p\/bEcpdXQiuz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "350326185902874626",
  "text" : "#InstaVideo: President Obama greets the people of Gor\u00E9e Island in Senegal: http:\/\/t.co\/GBLYRDDoVb #ObamainAfrica",
  "id" : 350326185902874626,
  "created_at" : "2013-06-27 18:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/350319881687814144\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Vx7NevnMnA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNyWE4oCUAAjWMS.jpg",
      "id_str" : "350319881692008448",
      "id" : 350319881692008448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNyWE4oCUAAjWMS.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Vx7NevnMnA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350320577304727553",
  "text" : "President Obama greets kids on Gor\u00E9e Island in Senegal: http:\/\/t.co\/Vx7NevnMnA",
  "id" : 350320577304727553,
  "created_at" : "2013-06-27 18:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 20, 27 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 57, 67 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/350301451811160065\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/kpKRKghgrh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNyFUIACAAA4U2A.jpg",
      "id_str" : "350301451819548672",
      "id" : 350301451819548672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNyFUIACAAA4U2A.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kpKRKghgrh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/3NUHnOH2y4",
      "expanded_url" : "http:\/\/instagram.com\/michelleobama\/",
      "display_url" : "instagram.com\/michelleobama\/"
    } ]
  },
  "geo" : { },
  "id_str" : "350301451811160065",
  "text" : "Can't get enough of @FLOTUS Michelle Obama? She's now on @Instagram: http:\/\/t.co\/3NUHnOH2y4 http:\/\/t.co\/kpKRKghgrh",
  "id" : 350301451811160065,
  "created_at" : "2013-06-27 17:15:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/P1moDeHqvc",
      "expanded_url" : "http:\/\/at.wh.gov\/mrDKu",
      "display_url" : "at.wh.gov\/mrDKu"
    } ]
  },
  "geo" : { },
  "id_str" : "350298417504849920",
  "text" : "Starting soon: Join the latest White House #WeTheGeeks Google+ Hangout on innovation for global good. Watch: http:\/\/t.co\/P1moDeHqvc",
  "id" : 350298417504849920,
  "created_at" : "2013-06-27 17:03:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/cHpXpiwmbc",
      "expanded_url" : "http:\/\/at.wh.gov\/mrvhv",
      "display_url" : "at.wh.gov\/mrvhv"
    } ]
  },
  "geo" : { },
  "id_str" : "350277163246821377",
  "text" : "Calling all geeks: Join us at 1:00 pm ET for a Google+ Hangout on innovation for global good. http:\/\/t.co\/cHpXpiwmbc Ask a Q w\/ #WeTheGeeks",
  "id" : 350277163246821377,
  "created_at" : "2013-06-27 15:39:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350267061529886721",
  "text" : "RT @Simas44: Worth a RT on more good Obamacare news for consumers. Oregon slashes '14 health insurance premiums by as much as 35%. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ce10KfXVaB",
        "expanded_url" : "http:\/\/www.oregonlive.com\/health\/index.ssf\/2013\/06\/oregon_slashes_2014_health_ins.html",
        "display_url" : "oregonlive.com\/health\/index.s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350265768191082501",
    "text" : "Worth a RT on more good Obamacare news for consumers. Oregon slashes '14 health insurance premiums by as much as 35%. http:\/\/t.co\/ce10KfXVaB",
    "id" : 350265768191082501,
    "created_at" : "2013-06-27 14:54:01 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 350267061529886721,
  "created_at" : "2013-06-27 14:59:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/MLf0E2sXu1",
      "expanded_url" : "http:\/\/instagram.com\/p\/bD8tjjPZPm\/",
      "display_url" : "instagram.com\/p\/bD8tjjPZPm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "350227082783113218",
  "text" : "RT @FLOTUS: My first instagram! So inspired and so impressed by these extraordinary young women. -mo #FLOTUSinAfrica http:\/\/t.co\/MLf0E2sXu1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 89, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/MLf0E2sXu1",
        "expanded_url" : "http:\/\/instagram.com\/p\/bD8tjjPZPm\/",
        "display_url" : "instagram.com\/p\/bD8tjjPZPm\/"
      } ]
    },
    "geo" : { },
    "id_str" : "350223820453449728",
    "text" : "My first instagram! So inspired and so impressed by these extraordinary young women. -mo #FLOTUSinAfrica http:\/\/t.co\/MLf0E2sXu1",
    "id" : 350223820453449728,
    "created_at" : "2013-06-27 12:07:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 350227082783113218,
  "created_at" : "2013-06-27 12:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "350033109196095488",
  "text" : "Starting Oct. 1st, the new http:\/\/t.co\/GNfbftrfo3 will help you choose a plan that fits your budget and meets your needs. #ObamacareInAction",
  "id" : 350033109196095488,
  "created_at" : "2013-06-26 23:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/350009453250236416\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/aqlnO0udOh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNt7vkmCUAATqzK.jpg",
      "id_str" : "350009453258625024",
      "id" : 350009453258625024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNt7vkmCUAATqzK.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aqlnO0udOh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350028849716797440",
  "text" : "RT @petesouza: Photo of the First Family being welcomed at Senegal airport this evening http:\/\/t.co\/aqlnO0udOh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/350009453250236416\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/aqlnO0udOh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNt7vkmCUAATqzK.jpg",
        "id_str" : "350009453258625024",
        "id" : 350009453258625024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNt7vkmCUAATqzK.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/aqlnO0udOh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350009453250236416",
    "text" : "Photo of the First Family being welcomed at Senegal airport this evening http:\/\/t.co\/aqlnO0udOh",
    "id" : 350009453250236416,
    "created_at" : "2013-06-26 21:55:31 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 350028849716797440,
  "created_at" : "2013-06-26 23:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/uMnhRkiOOR",
      "expanded_url" : "http:\/\/at.wh.gov\/mq5IC",
      "display_url" : "at.wh.gov\/mq5IC"
    } ]
  },
  "geo" : { },
  "id_str" : "350021858717995009",
  "text" : "RT @FLOTUS: The First Lady just landed in Senegal. Take a look back at her 2011 trip to Africa ---&gt; http:\/\/t.co\/uMnhRkiOOR, http:\/\/t.co\/MoL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/350021112324820993\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/MoLLVIzQdQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNuGWOBCEAEVeot.jpg",
        "id_str" : "350021112329015297",
        "id" : 350021112329015297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNuGWOBCEAEVeot.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MoLLVIzQdQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/uMnhRkiOOR",
        "expanded_url" : "http:\/\/at.wh.gov\/mq5IC",
        "display_url" : "at.wh.gov\/mq5IC"
      } ]
    },
    "geo" : { },
    "id_str" : "350021112324820993",
    "text" : "The First Lady just landed in Senegal. Take a look back at her 2011 trip to Africa ---&gt; http:\/\/t.co\/uMnhRkiOOR, http:\/\/t.co\/MoLLVIzQdQ",
    "id" : 350021112324820993,
    "created_at" : "2013-06-26 22:41:51 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 350021858717995009,
  "created_at" : "2013-06-26 22:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInAfrica",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/3vDCX75fY1",
      "expanded_url" : "http:\/\/wh.gov\/ScF9",
      "display_url" : "wh.gov\/ScF9"
    } ]
  },
  "geo" : { },
  "id_str" : "350015795969011712",
  "text" : "Here's the latest on President Obama's trip to Senegal, South Africa, and Tanzania: http:\/\/t.co\/3vDCX75fY1 #ObamaInAfrica",
  "id" : 350015795969011712,
  "created_at" : "2013-06-26 22:20:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/349876718032531456\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/KRkw5dBCtt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNsDBXXCMAEx1Ky.jpg",
      "id_str" : "349876718036725761",
      "id" : 349876718036725761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNsDBXXCMAEx1Ky.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KRkw5dBCtt"
    } ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/gHXE1kig0U",
      "expanded_url" : "http:\/\/wh.gov\/lOHf6",
      "display_url" : "wh.gov\/lOHf6"
    } ]
  },
  "geo" : { },
  "id_str" : "349987372739477504",
  "text" : "RT @FLOTUS: The First Lady kicks off her trip to Africa: http:\/\/t.co\/gHXE1kig0U, http:\/\/t.co\/KRkw5dBCtt #FLOTUSinAfrica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/349876718032531456\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/KRkw5dBCtt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNsDBXXCMAEx1Ky.jpg",
        "id_str" : "349876718036725761",
        "id" : 349876718036725761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNsDBXXCMAEx1Ky.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KRkw5dBCtt"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/gHXE1kig0U",
        "expanded_url" : "http:\/\/wh.gov\/lOHf6",
        "display_url" : "wh.gov\/lOHf6"
      } ]
    },
    "geo" : { },
    "id_str" : "349954322752212992",
    "text" : "The First Lady kicks off her trip to Africa: http:\/\/t.co\/gHXE1kig0U, http:\/\/t.co\/KRkw5dBCtt #FLOTUSinAfrica",
    "id" : 349954322752212992,
    "created_at" : "2013-06-26 18:16:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 349987372739477504,
  "created_at" : "2013-06-26 20:27:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/zNx6vMfmQc",
      "expanded_url" : "http:\/\/wh.gov\/lOFnh",
      "display_url" : "wh.gov\/lOFnh"
    } ]
  },
  "geo" : { },
  "id_str" : "349975319580655616",
  "text" : "\"I applaud the Supreme Court\u2019s decision to strike down the Defense of Marriage Act.\" \u2014Obama: http:\/\/t.co\/zNx6vMfmQc #MarriageEquality",
  "id" : 349975319580655616,
  "created_at" : "2013-06-26 19:39:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 3, 13 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/SJ6AcXdnDq",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "349965678696087552",
  "text" : "RT @instagram: Welcome to Instagram, @whitehouse! --&gt; http:\/\/t.co\/SJ6AcXdnDq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 22, 33 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/SJ6AcXdnDq",
        "expanded_url" : "http:\/\/instagram.com\/whitehouse",
        "display_url" : "instagram.com\/whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "349952457603948544",
    "text" : "Welcome to Instagram, @whitehouse! --&gt; http:\/\/t.co\/SJ6AcXdnDq",
    "id" : 349952457603948544,
    "created_at" : "2013-06-26 18:09:02 +0000",
    "user" : {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "protected" : false,
      "id_str" : "180505807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786681705981673472\/T5OKNZ1-_normal.jpg",
      "id" : 180505807,
      "verified" : true
    }
  },
  "id" : 349965678696087552,
  "created_at" : "2013-06-26 19:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "DOMA",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349957933058101249",
  "text" : "RT @vj44: Cheering on Air Force One when we heard #SCOTUS decision! Striking down #DOMA = victory for equal rights for all Americans.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 40, 47 ]
      }, {
        "text" : "DOMA",
        "indices" : [ 72, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349945716799569921",
    "text" : "Cheering on Air Force One when we heard #SCOTUS decision! Striking down #DOMA = victory for equal rights for all Americans.",
    "id" : 349945716799569921,
    "created_at" : "2013-06-26 17:42:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 349957933058101249,
  "created_at" : "2013-06-26 18:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349945703151304704\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/L7U1l9zyP8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNtBw0-CAAEkw_A.png",
      "id_str" : "349945703159693313",
      "id" : 349945703159693313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNtBw0-CAAEkw_A.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/L7U1l9zyP8"
    } ],
    "hashtags" : [ {
      "text" : "nofilter",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/y5bWZhkoxp",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "349945703151304704",
  "text" : "A new way to see unfiltered moments at the White House (we won't always go #nofilter) --&gt; http:\/\/t.co\/y5bWZhkoxp, http:\/\/t.co\/L7U1l9zyP8",
  "id" : 349945703151304704,
  "created_at" : "2013-06-26 17:42:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349934750720487424\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9jcweL6vNi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNs3zT_CcAAqY6r.jpg",
      "id_str" : "349934750728876032",
      "id" : 349934750728876032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNs3zT_CcAAqY6r.jpg",
      "sizes" : [ {
        "h" : 697,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9jcweL6vNi"
    } ],
    "hashtags" : [ {
      "text" : "DOMA",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349934750720487424",
  "text" : "President Obama called Edie Windsor\u2014the plaintiff in the #DOMA case\u2014from AF1 to congratulate her on today's ruling: http:\/\/t.co\/9jcweL6vNi",
  "id" : 349934750720487424,
  "created_at" : "2013-06-26 16:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349925320935223296\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/MYrCnEPiFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNsvObTCMAA_0zI.jpg",
      "id_str" : "349925320943611904",
      "id" : 349925320943611904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNsvObTCMAA_0zI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/MYrCnEPiFI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349925320935223296",
  "text" : "RT if you agree: We're all created equal\u2014and the love we commit to one another must be equal as well. http:\/\/t.co\/MYrCnEPiFI",
  "id" : 349925320935223296,
  "created_at" : "2013-06-26 16:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349915356980195331",
  "text" : "President Obama: \"When all Americans are treated as equal\u2014no matter who they are or whom they love\u2014we are all more free.\" #MarriageEquality",
  "id" : 349915356980195331,
  "created_at" : "2013-06-26 15:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/349677936745512961\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/t09EghpXvJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNpOOxXCAAICtOC.jpg",
      "id_str" : "349677936749707266",
      "id" : 349677936749707266,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNpOOxXCAAICtOC.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/t09EghpXvJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/NWQXcxRrb0",
      "expanded_url" : "http:\/\/at.wh.gov\/mnZGB",
      "display_url" : "at.wh.gov\/mnZGB"
    } ]
  },
  "geo" : { },
  "id_str" : "349677936745512961",
  "text" : "RT so your friends know about President Obama's plan to act on climate change --&gt; http:\/\/t.co\/NWQXcxRrb0, http:\/\/t.co\/t09EghpXvJ",
  "id" : 349677936745512961,
  "created_at" : "2013-06-25 23:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zWWC8O0nqF",
      "expanded_url" : "http:\/\/wjcf.co\/11YVCPt",
      "display_url" : "wjcf.co\/11YVCPt"
    } ]
  },
  "geo" : { },
  "id_str" : "349664679280386049",
  "text" : "RT @billclinton: President Obama's plan for cutting carbon pollution is good news for our planet and good economics. http:\/\/t.co\/zWWC8O0nqF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/zWWC8O0nqF",
        "expanded_url" : "http:\/\/wjcf.co\/11YVCPt",
        "display_url" : "wjcf.co\/11YVCPt"
      } ]
    },
    "geo" : { },
    "id_str" : "349661456251371520",
    "text" : "President Obama's plan for cutting carbon pollution is good news for our planet and good economics. http:\/\/t.co\/zWWC8O0nqF",
    "id" : 349661456251371520,
    "created_at" : "2013-06-25 22:52:42 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 349664679280386049,
  "created_at" : "2013-06-25 23:05:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349625211924135936\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/W7WqkiaMzL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNoeRyHCQAAJvfJ.jpg",
      "id_str" : "349625211932524544",
      "id" : 349625211932524544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNoeRyHCQAAJvfJ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/W7WqkiaMzL"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Fi8pLRt3Re",
      "expanded_url" : "http:\/\/at.wh.gov\/mnE7C",
      "display_url" : "at.wh.gov\/mnE7C"
    } ]
  },
  "geo" : { },
  "id_str" : "349625211924135936",
  "text" : "Worth sharing: President Obama lays out his plan to #ActOnClimate change. http:\/\/t.co\/Fi8pLRt3Re, http:\/\/t.co\/W7WqkiaMzL",
  "id" : 349625211924135936,
  "created_at" : "2013-06-25 20:28:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349618918773624832",
  "text" : "Use #ActOnClimate to share why you agree it's time to do something about climate change.",
  "id" : 349618918773624832,
  "created_at" : "2013-06-25 20:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349601532938948610",
  "text" : "As a President, as a father, and as an American, I choose to #ActOnClimate. Speak up if you do, too. -bo",
  "id" : 349601532938948610,
  "created_at" : "2013-06-25 18:54:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349596264901517312",
  "text" : "President Obama: \"There is no contradiction between a sound environment and strong economic growth.\" #ActOnClimate",
  "id" : 349596264901517312,
  "created_at" : "2013-06-25 18:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349595627149209600",
  "text" : "President Obama on climate deniers: \"We don\u2019t have time for a meeting of the Flat Earth Society.\" #ActOnClimate",
  "id" : 349595627149209600,
  "created_at" : "2013-06-25 18:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349595245891174401",
  "text" : "Obama: \"I am willing to work with anybody\u2014Republicans, Democrats, independents...to combat this threat on behalf of our kids.\" #ActOnClimate",
  "id" : 349595245891174401,
  "created_at" : "2013-06-25 18:29:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349594122698498048",
  "text" : "President Obama: \"If we can come together and get this right, we can define a sustainable future for your generation.\" #ActOnClimate",
  "id" : 349594122698498048,
  "created_at" : "2013-06-25 18:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349592386764148740",
  "text" : "President Obama: \"Using less dirty energy. Transitioning to cleaner sources of energy. Wasting less energy...this is where we need to go.\"",
  "id" : 349592386764148740,
  "created_at" : "2013-06-25 18:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349591844532928512",
  "text" : "Obama on building more fuel efficient cars and trucks: \"You\u2019ll fill up half as often, and we\u2019ll all reduce carbon pollution.\" #ActOnClimate",
  "id" : 349591844532928512,
  "created_at" : "2013-06-25 18:16:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349591124811317248",
  "text" : "President Obama: \"The plan I\u2019m announcing today will help us double again our energy from the wind and the sun.\" #ActOnClimate",
  "id" : 349591124811317248,
  "created_at" : "2013-06-25 18:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349590775882973184",
  "text" : "President Obama: \"We\u2019ve doubled the electricity we generate from zero-carbon wind and solar power\u2014and that means jobs.\" #ActOnClimate",
  "id" : 349590775882973184,
  "created_at" : "2013-06-25 18:11:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349589778213249024",
  "text" : "President Obama: \"A low-carbon, clean energy economy can be an engine of growth for decades to come...I want America to build that future.\"",
  "id" : 349589778213249024,
  "created_at" : "2013-06-25 18:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349589088980058112",
  "text" : "President Obama: We don't have to \"choose between the health of our children and the health of our economy.\" #ActOnClimate",
  "id" : 349589088980058112,
  "created_at" : "2013-06-25 18:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349588329425141761",
  "text" : "President Obama: \"I\u2019m directing the EPA to put an end to the limitless dumping of carbon pollution from our power plants.\" #ActOnClimate",
  "id" : 349588329425141761,
  "created_at" : "2013-06-25 18:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349587862649442304",
  "text" : "Obama: \"Power plants can still dump unlimited amounts of carbon pollution into the air for free. That\u2019s not right...and it needs to stop.\"",
  "id" : 349587862649442304,
  "created_at" : "2013-06-25 18:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6kFLDfiRdI",
      "expanded_url" : "http:\/\/at.wh.gov\/mnjP8",
      "display_url" : "at.wh.gov\/mnjP8"
    } ]
  },
  "geo" : { },
  "id_str" : "349587232321052672",
  "text" : "President Obama: \"I\u2019m announcing a new national Climate Action Plan, and I\u2019m here to enlist your generation\u2019s help.\" http:\/\/t.co\/6kFLDfiRdI",
  "id" : 349587232321052672,
  "created_at" : "2013-06-25 17:57:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349586586385653760",
  "text" : "President Obama: \"I refuse to condemn your generation, and future generations, to a planet that\u2019s beyond fixing.\" #ActOnClimate",
  "id" : 349586586385653760,
  "created_at" : "2013-06-25 17:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349586362086862849",
  "text" : "RT @WHLive: President Obama: \"Farmers see crops wilted one year, washed away the next, and the higher food prices get passed to you.\" #ActO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349586315517505536",
    "text" : "President Obama: \"Farmers see crops wilted one year, washed away the next, and the higher food prices get passed to you.\" #ActOnClimate",
    "id" : 349586315517505536,
    "created_at" : "2013-06-25 17:54:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 349586362086862849,
  "created_at" : "2013-06-25 17:54:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349585861098225664",
  "text" : "President Obama: \"Those who already feel the effects of climate change don\u2019t have the time to deny it\u2014they\u2019re busy dealing with it.\"",
  "id" : 349585861098225664,
  "created_at" : "2013-06-25 17:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349585507983966209",
  "text" : "President Obama: \"The 12 warmest years in recorded history have all come in the last 15.\" #ActOnClimate",
  "id" : 349585507983966209,
  "created_at" : "2013-06-25 17:50:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349585232829227009",
  "text" : "President Obama: \"Our planet is changing in ways that will impact all of humankind.\" #ActOnClimate",
  "id" : 349585232829227009,
  "created_at" : "2013-06-25 17:49:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "349584196483813376",
  "text" : "Happening now: President Obama speaks about his plan to cut carbon pollution and #ActOnClimate change. http:\/\/t.co\/KvadYk9atb",
  "id" : 349584196483813376,
  "created_at" : "2013-06-25 17:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349583706681393152",
  "text" : "RT @WHLive: At 1:55pm ET, President Obama speaks about his plan to cut carbon pollution and #ActOnClimate change. Watch: http:\/\/t.co\/oPflTk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 80, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/oPflTkkHep",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "349581973938905089",
    "text" : "At 1:55pm ET, President Obama speaks about his plan to cut carbon pollution and #ActOnClimate change. Watch: http:\/\/t.co\/oPflTkkHep",
    "id" : 349581973938905089,
    "created_at" : "2013-06-25 17:36:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 349583706681393152,
  "created_at" : "2013-06-25 17:43:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349580132110966786\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/LVuPV3AfCO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNn1RyvCIAAOQ7Q.jpg",
      "id_str" : "349580132123549696",
      "id" : 349580132123549696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNn1RyvCIAAOQ7Q.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/LVuPV3AfCO"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/PvnynViqk5",
      "expanded_url" : "http:\/\/at.wh.gov\/mneQN",
      "display_url" : "at.wh.gov\/mneQN"
    } ]
  },
  "geo" : { },
  "id_str" : "349580132110966786",
  "text" : "RT to share President Obama's plan to cut carbon pollution and #ActOnClimate change: http:\/\/t.co\/PvnynViqk5, http:\/\/t.co\/LVuPV3AfCO",
  "id" : 349580132110966786,
  "created_at" : "2013-06-25 17:29:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349573752473923585\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/HmwddpSJyM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNnvecuCMAEc9bP.jpg",
      "id_str" : "349573752482312193",
      "id" : 349573752482312193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNnvecuCMAEc9bP.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/HmwddpSJyM"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349573752473923585",
  "text" : "RT if you agree: It's time to #ActOnClimate change. http:\/\/t.co\/HmwddpSJyM",
  "id" : 349573752473923585,
  "created_at" : "2013-06-25 17:04:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/WV6w97gJ9I",
      "expanded_url" : "http:\/\/at.wh.gov\/mn72u",
      "display_url" : "at.wh.gov\/mn72u"
    } ]
  },
  "geo" : { },
  "id_str" : "349567817835757569",
  "text" : "\"I am deeply disappointed with the Supreme Court\u2019s decision today.\" \u2014President Obama on today's #VRA ruling: http:\/\/t.co\/WV6w97gJ9I",
  "id" : 349567817835757569,
  "created_at" : "2013-06-25 16:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349555203839762432",
  "text" : "FACT: Under President Obama, America has more than doubled clean energy generation from wind and solar sources. #ActOnClimate",
  "id" : 349555203839762432,
  "created_at" : "2013-06-25 15:50:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349550358579777536",
  "text" : "FACT: In 2012, extreme weather disasters cost Americans more than $100 billion. #ActOnClimate",
  "id" : 349550358579777536,
  "created_at" : "2013-06-25 15:31:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349543374916816898",
  "text" : "FACT: 12 of the hottest years on record have all come in the last 15 years. #ActOnClimate",
  "id" : 349543374916816898,
  "created_at" : "2013-06-25 15:03:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/TnyqnDSYNA",
      "expanded_url" : "http:\/\/at.wh.gov\/mmJPg",
      "display_url" : "at.wh.gov\/mmJPg"
    } ]
  },
  "geo" : { },
  "id_str" : "349537839425388544",
  "text" : "Due to climate change, temperatures are rising, weather is getting more extreme\u2014and it's time to act: http:\/\/t.co\/TnyqnDSYNA #ActOnClimate",
  "id" : 349537839425388544,
  "created_at" : "2013-06-25 14:41:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349530474084974592",
  "text" : "RT @Simas44: Today the President announces action plan to cut carbon pollution that harms our health and the planet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349496540194279425",
    "text" : "Today the President announces action plan to cut carbon pollution that harms our health and the planet.",
    "id" : 349496540194279425,
    "created_at" : "2013-06-25 11:57:23 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 349530474084974592,
  "created_at" : "2013-06-25 14:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349520219926048768",
  "text" : "RT @pfeiffer44: When I was at Georgetown in the 90s, folks were talking abt addressing climate, today POTUS goes to Georgetown to take acti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349472764840771584",
    "text" : "When I was at Georgetown in the 90s, folks were talking abt addressing climate, today POTUS goes to Georgetown to take action",
    "id" : 349472764840771584,
    "created_at" : "2013-06-25 10:22:54 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 349520219926048768,
  "created_at" : "2013-06-25 13:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA HQ PHOTO",
      "screen_name" : "nasahqphoto",
      "indices" : [ 3, 15 ],
      "id_str" : "18164420",
      "id" : 18164420
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349338691300380672\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/mf1QzjBPq3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNkZsFnCUAAF255.jpg",
      "id_str" : "349338691308769280",
      "id" : 349338691308769280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNkZsFnCUAAF255.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 696
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 696
      } ],
      "display_url" : "pic.twitter.com\/mf1QzjBPq3"
    } ],
    "hashtags" : [ {
      "text" : "Supermoon",
      "indices" : [ 54, 64 ]
    }, {
      "text" : "moon",
      "indices" : [ 98, 103 ]
    }, {
      "text" : "nasa",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349338691300380672",
  "text" : "MT @NASAHQPhoto: But wait! There's more! Another 2013 #Supermoon pic from yesterday in DC. Enjoy! #moon #nasa http:\/\/t.co\/mf1QzjBPq3",
  "id" : 349338691300380672,
  "created_at" : "2013-06-25 01:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349315585932419072\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6GHtQMFPsh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNkErLaCYAAbYpk.jpg",
      "id_str" : "349315585940807680",
      "id" : 349315585940807680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNkErLaCYAAbYpk.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/6GHtQMFPsh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349315585932419072",
  "text" : "RT to spread the word: You can now text PREZ to 38383 to ask President Obama your questions about student loans. http:\/\/t.co\/6GHtQMFPsh",
  "id" : 349315585932419072,
  "created_at" : "2013-06-24 23:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DoSomething.org",
      "screen_name" : "dosomething",
      "indices" : [ 3, 15 ],
      "id_str" : "14165865",
      "id" : 14165865
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349280997491216386",
  "text" : "RT @dosomething: We've teamed up with the @whitehouse to let YOU text President Obama. Text PREZ to 38383 and he could answer your question\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 25, 36 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349228313950162944",
    "text" : "We've teamed up with the @whitehouse to let YOU text President Obama. Text PREZ to 38383 and he could answer your questions!",
    "id" : 349228313950162944,
    "created_at" : "2013-06-24 18:11:33 +0000",
    "user" : {
      "name" : "DoSomething.org",
      "screen_name" : "dosomething",
      "protected" : false,
      "id_str" : "14165865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789476203837128704\/tm1cQJi2_normal.jpg",
      "id" : 14165865,
      "verified" : true
    }
  },
  "id" : 349280997491216386,
  "created_at" : "2013-06-24 21:40:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DoSomething.org",
      "screen_name" : "dosomething",
      "indices" : [ 86, 98 ],
      "id_str" : "14165865",
      "id" : 14165865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/UffMdJb4X5",
      "expanded_url" : "http:\/\/at.wh.gov\/mloAr",
      "display_url" : "at.wh.gov\/mloAr"
    } ]
  },
  "geo" : { },
  "id_str" : "349275551002923009",
  "text" : "Starting now, you can text with President Obama about student loans. Find out how via @DoSomething: http:\/\/t.co\/UffMdJb4X5 #DontDoubleMyRate",
  "id" : 349275551002923009,
  "created_at" : "2013-06-24 21:19:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 28, 35 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/5fPxAtKOcU",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "349267020111556609",
  "text" : "RT @PAniskoff44: FirstLook: @HHSGov just launched http:\/\/t.co\/5fPxAtKOcU. Enrollment starts Oct 1! Great, helpful site.  See what the buzz \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 11, 18 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/5fPxAtKOcU",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "349223881762013184",
    "text" : "FirstLook: @HHSGov just launched http:\/\/t.co\/5fPxAtKOcU. Enrollment starts Oct 1! Great, helpful site.  See what the buzz is about!",
    "id" : 349223881762013184,
    "created_at" : "2013-06-24 17:53:56 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 349267020111556609,
  "created_at" : "2013-06-24 20:45:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "349234503153225728",
  "text" : "Go to http:\/\/t.co\/GNfbftrfo3 for info on how to compare plans and sign up for health insurance on the new Marketplace starting Oct 1st. #ACA",
  "id" : 349234503153225728,
  "created_at" : "2013-06-24 18:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/349210349330915328\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/A3nco44EuD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNik9mhCYAADArk.jpg",
      "id_str" : "349210349339303936",
      "id" : 349210349339303936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNik9mhCYAADArk.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/A3nco44EuD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349210349330915328",
  "text" : "RT if you agree with President Obama: We owe it to our kids to do something about climate change. http:\/\/t.co\/A3nco44EuD",
  "id" : 349210349330915328,
  "created_at" : "2013-06-24 17:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/4oABgTDX4s",
      "expanded_url" : "http:\/\/at.wh.gov\/mkxCT",
      "display_url" : "at.wh.gov\/mkxCT"
    } ]
  },
  "geo" : { },
  "id_str" : "349196565128290304",
  "text" : "If these 4th graders can do something about climate change, there's no reason why we all can't: http:\/\/t.co\/4oABgTDX4s",
  "id" : 349196565128290304,
  "created_at" : "2013-06-24 16:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/wMpgpJJ4rO",
      "expanded_url" : "http:\/\/at.wh.gov\/mkwUu",
      "display_url" : "at.wh.gov\/mkwUu"
    } ]
  },
  "geo" : { },
  "id_str" : "349184812038385665",
  "text" : "We have an obligation to future generations to act on climate change: http:\/\/t.co\/wMpgpJJ4rO",
  "id" : 349184812038385665,
  "created_at" : "2013-06-24 15:18:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/QpQCyCr30t",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "349167495359381504",
  "text" : "RT @Sebelius: New tools, website and call centers, ensure anyone who needs insurance can make the best choice http:\/\/t.co\/QpQCyCr30t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/QpQCyCr30t",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "349131630381772801",
    "text" : "New tools, website and call centers, ensure anyone who needs insurance can make the best choice http:\/\/t.co\/QpQCyCr30t",
    "id" : 349131630381772801,
    "created_at" : "2013-06-24 11:47:21 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 349167495359381504,
  "created_at" : "2013-06-24 14:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/348954774722465792\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/RiShwCQdW6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNe8hM6CUAE-Cq2.jpg",
      "id_str" : "348954774730854401",
      "id" : 348954774730854401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNe8hM6CUAE-Cq2.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/RiShwCQdW6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/DANEuUFiOh",
      "expanded_url" : "http:\/\/at.wh.gov\/mjdyj",
      "display_url" : "at.wh.gov\/mjdyj"
    } ]
  },
  "geo" : { },
  "id_str" : "348954774722465792",
  "text" : "RT if you agree: We owe it to our kids to address climate change before it's too late. http:\/\/t.co\/DANEuUFiOh, http:\/\/t.co\/RiShwCQdW6",
  "id" : 348954774722465792,
  "created_at" : "2013-06-24 00:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348615859436138497",
  "text" : "RT @WhiteHouseCEQ: \"When it comes to the world we leave our children, we owe it to them to do what we can.\" Watch this and tune in Tues. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2I7wB3zTQD",
        "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
        "display_url" : "youtu.be\/gcL3_zzgWeU"
      } ]
    },
    "geo" : { },
    "id_str" : "348612933879754752",
    "text" : "\"When it comes to the world we leave our children, we owe it to them to do what we can.\" Watch this and tune in Tues. http:\/\/t.co\/2I7wB3zTQD",
    "id" : 348612933879754752,
    "created_at" : "2013-06-23 01:26:15 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 348615859436138497,
  "created_at" : "2013-06-23 01:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeke Miller",
      "screen_name" : "ZekeJMiller",
      "indices" : [ 3, 15 ],
      "id_str" : "21316253",
      "id" : 21316253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/S85jLkAdsy",
      "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
      "display_url" : "youtu.be\/gcL3_zzgWeU"
    } ]
  },
  "geo" : { },
  "id_str" : "348610817043857409",
  "text" : "RT @ZekeJMiller: New White House video previewing Obama's climate change announcement http:\/\/t.co\/S85jLkAdsy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/S85jLkAdsy",
        "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
        "display_url" : "youtu.be\/gcL3_zzgWeU"
      } ]
    },
    "geo" : { },
    "id_str" : "348523629522333696",
    "text" : "New White House video previewing Obama's climate change announcement http:\/\/t.co\/S85jLkAdsy",
    "id" : 348523629522333696,
    "created_at" : "2013-06-22 19:31:23 +0000",
    "user" : {
      "name" : "Zeke Miller",
      "screen_name" : "ZekeJMiller",
      "protected" : false,
      "id_str" : "21316253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595261015731740673\/uvXc_cII_normal.jpg",
      "id" : 21316253,
      "verified" : true
    }
  },
  "id" : 348610817043857409,
  "created_at" : "2013-06-23 01:17:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not David Roberts",
      "screen_name" : "drgrist",
      "indices" : [ 3, 11 ],
      "id_str" : "3148356377",
      "id" : 3148356377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/iVblJuTcYk",
      "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
      "display_url" : "youtu.be\/gcL3_zzgWeU"
    } ]
  },
  "geo" : { },
  "id_str" : "348600718514589697",
  "text" : "RT @drgrist: Obama to make \u201Cmajor climate change speech\u201D in Georgetown on Tuesday. A preview: http:\/\/t.co\/iVblJuTcYk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/iVblJuTcYk",
        "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
        "display_url" : "youtu.be\/gcL3_zzgWeU"
      } ]
    },
    "geo" : { },
    "id_str" : "348546180025810944",
    "text" : "Obama to make \u201Cmajor climate change speech\u201D in Georgetown on Tuesday. A preview: http:\/\/t.co\/iVblJuTcYk",
    "id" : 348546180025810944,
    "created_at" : "2013-06-22 21:00:59 +0000",
    "user" : {
      "name" : "David Roberts",
      "screen_name" : "drvox",
      "protected" : false,
      "id_str" : "22737278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551076081051004929\/2i4QEfn-_normal.jpeg",
      "id" : 22737278,
      "verified" : true
    }
  },
  "id" : 348600718514589697,
  "created_at" : "2013-06-23 00:37:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348571485583052800",
  "text" : "RT @Simas44: While no single step can reverse climate change, we have an obligation to future generations to leave them a planet that's not\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348522005915631617",
    "text" : "While no single step can reverse climate change, we have an obligation to future generations to leave them a planet that's not damaged.",
    "id" : 348522005915631617,
    "created_at" : "2013-06-22 19:24:56 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 348571485583052800,
  "created_at" : "2013-06-22 22:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/ifWvlB6qCL",
      "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
      "display_url" : "youtu.be\/gcL3_zzgWeU"
    } ]
  },
  "geo" : { },
  "id_str" : "348535652188565504",
  "text" : "Climate change is one of the most serious challenges we face &amp; it's time to act. Watch this video &amp; tune in Tuesday: http:\/\/t.co\/ifWvlB6qCL",
  "id" : 348535652188565504,
  "created_at" : "2013-06-22 20:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ifWvlB6qCL",
      "expanded_url" : "http:\/\/youtu.be\/gcL3_zzgWeU",
      "display_url" : "youtu.be\/gcL3_zzgWeU"
    } ]
  },
  "geo" : { },
  "id_str" : "348519235472998400",
  "text" : "We owe it to our kids to do something about climate change. Share this video and join me Tuesday: http:\/\/t.co\/ifWvlB6qCL  -bo",
  "id" : 348519235472998400,
  "created_at" : "2013-06-22 19:13:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/RA1RmXlKFd",
      "expanded_url" : "http:\/\/at.wh.gov\/mhKiE",
      "display_url" : "at.wh.gov\/mhKiE"
    } ]
  },
  "geo" : { },
  "id_str" : "348440615530397698",
  "text" : "\"It\u2019s time to fix our broken immigration system once and for all.\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/RA1RmXlKFd",
  "id" : 348440615530397698,
  "created_at" : "2013-06-22 14:01:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/348202018235629568\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/X8HLsG5pT5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNUP5AdCQAERJQb.jpg",
      "id_str" : "348202018239823873",
      "id" : 348202018239823873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNUP5AdCQAERJQb.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X8HLsG5pT5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348202018235629568",
  "text" : "Enjoy your weekend. http:\/\/t.co\/X8HLsG5pT5",
  "id" : 348202018235629568,
  "created_at" : "2013-06-21 22:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "indices" : [ 49, 58 ],
      "id_str" : "15012352",
      "id" : 15012352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uscm2013",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348166866033836034",
  "text" : "RT @VP: Happening soon: the VP will speak at the @USMayors annual meeting in Las Vegas #uscm2013. Listen to his remarks here: http:\/\/t.co\/R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Mayors",
        "screen_name" : "usmayors",
        "indices" : [ 41, 50 ],
        "id_str" : "15012352",
        "id" : 15012352
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uscm2013",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/R4gj9lPica",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "348161970681307137",
    "text" : "Happening soon: the VP will speak at the @USMayors annual meeting in Las Vegas #uscm2013. Listen to his remarks here: http:\/\/t.co\/R4gj9lPica",
    "id" : 348161970681307137,
    "created_at" : "2013-06-21 19:34:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 348166866033836034,
  "created_at" : "2013-06-21 19:53:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348143470893989888",
  "text" : "\"We have the perfect person to carry on this work in Jim Comey\u2014a man who stands very tall for justice\"\u2014Obama on his nominee for FBI Director",
  "id" : 348143470893989888,
  "created_at" : "2013-06-21 18:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/M4jT8dWmOl",
      "expanded_url" : "http:\/\/at.wh.gov\/mgELK",
      "display_url" : "at.wh.gov\/mgELK"
    } ]
  },
  "geo" : { },
  "id_str" : "348140770953400320",
  "text" : "Happening now: President Obama makes a personnel announcement. Watch: http:\/\/t.co\/M4jT8dWmOl",
  "id" : 348140770953400320,
  "created_at" : "2013-06-21 18:10:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/348120464083787776\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/BvFq5l0i7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNTFt7kCIAESLyI.jpg",
      "id_str" : "348120464087982081",
      "id" : 348120464087982081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNTFt7kCIAESLyI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/BvFq5l0i7y"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 86, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348120464083787776",
  "text" : "Just 10 days left to act: RT to say we can't afford to let student loan rates double. #DontDoubleMyRate, http:\/\/t.co\/BvFq5l0i7y",
  "id" : 348120464083787776,
  "created_at" : "2013-06-21 16:49:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/348090817329647616\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/HwEE9KJYaq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNSqwQzCUAAsqAM.jpg",
      "id_str" : "348090817333841920",
      "id" : 348090817333841920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNSqwQzCUAAsqAM.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/HwEE9KJYaq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348090817329647616",
  "text" : "Happy First Day of Summer! http:\/\/t.co\/HwEE9KJYaq",
  "id" : 348090817329647616,
  "created_at" : "2013-06-21 14:51:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/347859174404792320\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/8VTjmrAotW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNPYE3qCIAMgHbI.jpg",
      "id_str" : "347859174408986627",
      "id" : 347859174408986627,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNPYE3qCIAMgHbI.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/8VTjmrAotW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347859174404792320",
  "text" : "Where's POTUS? http:\/\/t.co\/8VTjmrAotW",
  "id" : 347859174404792320,
  "created_at" : "2013-06-20 23:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/347843802796544000\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/8NDgVcdOn4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNPKGH9CUAESmBV.jpg",
      "id_str" : "347843802800738305",
      "id" : 347843802800738305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNPKGH9CUAESmBV.jpg",
      "sizes" : [ {
        "h" : 649,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8NDgVcdOn4"
    } ],
    "hashtags" : [ {
      "text" : "reformamigratoria",
      "indices" : [ 32, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/pOHMgfjtEk",
      "expanded_url" : "http:\/\/at.wh.gov\/meSrT",
      "display_url" : "at.wh.gov\/meSrT"
    } ]
  },
  "geo" : { },
  "id_str" : "347850640581595136",
  "text" : "RT @lacasablanca: CB...O, beb\u00E9! #reformamigratoria http:\/\/t.co\/pOHMgfjtEk http:\/\/t.co\/8NDgVcdOn4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/347843802796544000\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/8NDgVcdOn4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNPKGH9CUAESmBV.jpg",
        "id_str" : "347843802800738305",
        "id" : 347843802800738305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNPKGH9CUAESmBV.jpg",
        "sizes" : [ {
          "h" : 649,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 649,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8NDgVcdOn4"
      } ],
      "hashtags" : [ {
        "text" : "reformamigratoria",
        "indices" : [ 14, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/pOHMgfjtEk",
        "expanded_url" : "http:\/\/at.wh.gov\/meSrT",
        "display_url" : "at.wh.gov\/meSrT"
      } ]
    },
    "geo" : { },
    "id_str" : "347843802796544000",
    "text" : "CB...O, beb\u00E9! #reformamigratoria http:\/\/t.co\/pOHMgfjtEk http:\/\/t.co\/8NDgVcdOn4",
    "id" : 347843802796544000,
    "created_at" : "2013-06-20 22:29:59 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 347850640581595136,
  "created_at" : "2013-06-20 22:57:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/347813640331735040\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/RU49Xb5zJQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNOuqcCCMAA-2Bw.jpg",
      "id_str" : "347813640340123648",
      "id" : 347813640340123648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNOuqcCCMAA-2Bw.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/RU49Xb5zJQ"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 78, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347813640331735040",
  "text" : "RT if you agree: We can't afford to let student loan rates double in 11 days. #DontDoubleMyRate, http:\/\/t.co\/RU49Xb5zJQ",
  "id" : 347813640331735040,
  "created_at" : "2013-06-20 20:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/bLrfwFy98e",
      "expanded_url" : "http:\/\/at.wh.gov\/mez6I",
      "display_url" : "at.wh.gov\/mez6I"
    } ]
  },
  "geo" : { },
  "id_str" : "347799846004092928",
  "text" : "FACT: Health care reform saved consumers nearly $4 billion on their insurance premiums last year. http:\/\/t.co\/bLrfwFy98e #ObamacareInAction",
  "id" : 347799846004092928,
  "created_at" : "2013-06-20 19:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/fktOJbApY1",
      "expanded_url" : "http:\/\/at.wh.gov\/memDD",
      "display_url" : "at.wh.gov\/memDD"
    } ]
  },
  "geo" : { },
  "id_str" : "347777167452667904",
  "text" : "RT @WHLive: Watch #WeTheGeeks to find out how digital badges can help students build their careers: http:\/\/t.co\/fktOJbApY1 (Ask Q's using #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 6, 17 ]
      }, {
        "text" : "WeTheGeeks",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/fktOJbApY1",
        "expanded_url" : "http:\/\/at.wh.gov\/memDD",
        "display_url" : "at.wh.gov\/memDD"
      } ]
    },
    "geo" : { },
    "id_str" : "347776706003730432",
    "text" : "Watch #WeTheGeeks to find out how digital badges can help students build their careers: http:\/\/t.co\/fktOJbApY1 (Ask Q's using #WeTheGeeks)",
    "id" : 347776706003730432,
    "created_at" : "2013-06-20 18:03:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 347777167452667904,
  "created_at" : "2013-06-20 18:05:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 6, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/pGjsGcavKg",
      "expanded_url" : "http:\/\/at.wh.gov\/meiSo",
      "display_url" : "at.wh.gov\/meiSo"
    } ]
  },
  "geo" : { },
  "id_str" : "347772394984861696",
  "text" : "Watch #WeTheGeeks at 2pm ET to find out how digital badges can help students build resumes and showcase their skills: http:\/\/t.co\/pGjsGcavKg",
  "id" : 347772394984861696,
  "created_at" : "2013-06-20 17:46:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/347760001114316800\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uqswTfrOlH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNN94OYCIAAeRW6.jpg",
      "id_str" : "347760001122705408",
      "id" : 347760001122705408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNN94OYCIAAeRW6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/uqswTfrOlH"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347760001114316800",
  "text" : "RT if you support saving taxpayers nearly $1 trillion by fixing our broken immigration system. #ImmigrationReform, http:\/\/t.co\/uqswTfrOlH",
  "id" : 347760001114316800,
  "created_at" : "2013-06-20 16:57:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 99, 110 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347752231816282113",
  "text" : "RT @FLOTUS: Congrats to the 54 budding young chefs whose recipes earned them a trip to this year's @WhiteHouse #KidsStateDinner! http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 87, 98 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/9UwGWnriDa",
        "expanded_url" : "http:\/\/at.wh.gov\/me6Nq",
        "display_url" : "at.wh.gov\/me6Nq"
      } ]
    },
    "geo" : { },
    "id_str" : "347751374466981888",
    "text" : "Congrats to the 54 budding young chefs whose recipes earned them a trip to this year's @WhiteHouse #KidsStateDinner! http:\/\/t.co\/9UwGWnriDa",
    "id" : 347751374466981888,
    "created_at" : "2013-06-20 16:22:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 347752231816282113,
  "created_at" : "2013-06-20 16:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347731407864463362",
  "text" : "RT @Simas44: Check out the 15 year old who created a sensor that detects three types of cancer and costs as little as 3 cents! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/CMRhbqPg92",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/champions\/open-science\/jack-andraka",
        "display_url" : "whitehouse.gov\/champions\/open\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347725576875958272",
    "text" : "Check out the 15 year old who created a sensor that detects three types of cancer and costs as little as 3 cents! http:\/\/t.co\/CMRhbqPg92",
    "id" : 347725576875958272,
    "created_at" : "2013-06-20 14:40:12 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 347731407864463362,
  "created_at" : "2013-06-20 15:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 3, 14 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/347466674015985664\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/znsDBerMQn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNJzGVyCYAIo0LV.jpg",
      "id_str" : "347466674024374274",
      "id" : 347466674024374274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNJzGVyCYAIo0LV.jpg",
      "sizes" : [ {
        "h" : 844,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/znsDBerMQn"
    } ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347719342160478208",
  "text" : "RT @USTreasury: CHART: The economic benefits of fixing our broken #immigration system http:\/\/t.co\/znsDBerMQn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/347466674015985664\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/znsDBerMQn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNJzGVyCYAIo0LV.jpg",
        "id_str" : "347466674024374274",
        "id" : 347466674024374274,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNJzGVyCYAIo0LV.jpg",
        "sizes" : [ {
          "h" : 844,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 844,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/znsDBerMQn"
      } ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 50, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347466674015985664",
    "text" : "CHART: The economic benefits of fixing our broken #immigration system http:\/\/t.co\/znsDBerMQn",
    "id" : 347466674015985664,
    "created_at" : "2013-06-19 21:31:25 +0000",
    "user" : {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "protected" : false,
      "id_str" : "120176950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461250108441370624\/-9PNMlfp_normal.jpeg",
      "id" : 120176950,
      "verified" : true
    }
  },
  "id" : 347719342160478208,
  "created_at" : "2013-06-20 14:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/347500283233988609\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/kK1wjL2xfp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNKRqp4CcAA-k_G.jpg",
      "id_str" : "347500283242377216",
      "id" : 347500283242377216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNKRqp4CcAA-k_G.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/kK1wjL2xfp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/jUXR0i7iTu",
      "expanded_url" : "http:\/\/at.wh.gov\/mcDU7",
      "display_url" : "at.wh.gov\/mcDU7"
    } ]
  },
  "geo" : { },
  "id_str" : "347500283233988609",
  "text" : "We are stronger when all our people are granted opportunity: http:\/\/t.co\/jUXR0i7iTu, http:\/\/t.co\/kK1wjL2xfp",
  "id" : 347500283233988609,
  "created_at" : "2013-06-19 23:44:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouthJobs",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/MKfQDmeito",
      "expanded_url" : "http:\/\/at.wh.gov\/mcx0m",
      "display_url" : "at.wh.gov\/mcx0m"
    } ]
  },
  "geo" : { },
  "id_str" : "347480301301293056",
  "text" : "RT to spread the word: If you're a young person looking for a job, or know someone who is, check out #YouthJobs+ --&gt; http:\/\/t.co\/MKfQDmeito",
  "id" : 347480301301293056,
  "created_at" : "2013-06-19 22:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/jBio2On6mw",
      "expanded_url" : "http:\/\/at.wh.gov\/mcoW6",
      "display_url" : "at.wh.gov\/mcoW6"
    } ]
  },
  "geo" : { },
  "id_str" : "347462138840887296",
  "text" : "RT if you agree with President Obama: We can't let federal student loan rates double in 12 days. http:\/\/t.co\/jBio2On6mw #DontDoubleMyRate",
  "id" : 347462138840887296,
  "created_at" : "2013-06-19 21:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Capitol",
      "screen_name" : "uscapitol",
      "indices" : [ 94, 104 ],
      "id_str" : "17539497",
      "id" : 17539497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347454326278598656",
  "text" : "RT @VP: PHOTO: VP Biden speaks at a ceremony dedicating a statue of Frederick Douglass at the @uscapitol today. (WH Photo) http:\/\/t.co\/aovc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Capitol",
        "screen_name" : "uscapitol",
        "indices" : [ 86, 96 ],
        "id_str" : "17539497",
        "id" : 17539497
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/347432503839162369\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/aovcBudPWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNJUBX9CAAAoTWB.jpg",
        "id_str" : "347432503847550976",
        "id" : 347432503847550976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNJUBX9CAAAoTWB.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/aovcBudPWP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347432503839162369",
    "text" : "PHOTO: VP Biden speaks at a ceremony dedicating a statue of Frederick Douglass at the @uscapitol today. (WH Photo) http:\/\/t.co\/aovcBudPWP",
    "id" : 347432503839162369,
    "created_at" : "2013-06-19 19:15:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 347454326278598656,
  "created_at" : "2013-06-19 20:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 87, 90 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zQUUfdbFwK",
      "expanded_url" : "http:\/\/at.wh.gov\/mcfdl",
      "display_url" : "at.wh.gov\/mcfdl"
    } ]
  },
  "geo" : { },
  "id_str" : "347437499527868418",
  "text" : "\"We need to make sure that everyone in the country knows that this fight isn\u2019t over.\" \u2014@VP on reducing gun violence: http:\/\/t.co\/zQUUfdbFwK",
  "id" : 347437499527868418,
  "created_at" : "2013-06-19 19:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/347409749312155648\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/CBz1rvK7tQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNI_U4uCMAMJWnq.jpg",
      "id_str" : "347409749316349955",
      "id" : 347409749316349955,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNI_U4uCMAMJWnq.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/CBz1rvK7tQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347410127239909378",
  "text" : "RT @FLOTUS: Say cheese! http:\/\/t.co\/CBz1rvK7tQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/347409749312155648\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/CBz1rvK7tQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNI_U4uCMAMJWnq.jpg",
        "id_str" : "347409749316349955",
        "id" : 347409749316349955,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNI_U4uCMAMJWnq.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1023
        } ],
        "display_url" : "pic.twitter.com\/CBz1rvK7tQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347409749312155648",
    "text" : "Say cheese! http:\/\/t.co\/CBz1rvK7tQ",
    "id" : 347409749312155648,
    "created_at" : "2013-06-19 17:45:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 347410127239909378,
  "created_at" : "2013-06-19 17:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/347386897582141441\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Ip13Ox88W1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNIqivaCMAAZow7.jpg",
      "id_str" : "347386897590530048",
      "id" : 347386897590530048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNIqivaCMAAZow7.jpg",
      "sizes" : [ {
        "h" : 649,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ip13Ox88W1"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 38, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/mXHzro9Zty",
      "expanded_url" : "http:\/\/at.wh.gov\/mbyRI",
      "display_url" : "at.wh.gov\/mbyRI"
    } ]
  },
  "geo" : { },
  "id_str" : "347386897582141441",
  "text" : "CB...Oh, baby! http:\/\/t.co\/mXHzro9Zty #ImmigrationReform, http:\/\/t.co\/Ip13Ox88W1",
  "id" : 347386897582141441,
  "created_at" : "2013-06-19 16:14:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/0By7n9FuZ4",
      "expanded_url" : "http:\/\/wh.gov\/l3JEJ",
      "display_url" : "wh.gov\/l3JEJ"
    } ]
  },
  "geo" : { },
  "id_str" : "347375000682131456",
  "text" : "Get the facts on President Obama's plan to align U.S. nuclear policies to the 21st century security environment: http:\/\/t.co\/0By7n9FuZ4",
  "id" : 347375000682131456,
  "created_at" : "2013-06-19 15:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347352707994103808",
  "text" : "President Obama: \"The greatest tribute that we can pay to those who came before is by carrying on their work to pursue peace and justice.\"",
  "id" : 347352707994103808,
  "created_at" : "2013-06-19 13:58:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347351868000849920",
  "text" : "President Obama: \"Even as we remain vigilant about the threat of terrorism, we must move beyond a mindset of perpetual war.\"",
  "id" : 347351868000849920,
  "created_at" : "2013-06-19 13:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347350965009121282",
  "text" : "President Obama: \"Our generation must move toward a global compact to confront a changing climate before it is too late.\"",
  "id" : 347350965009121282,
  "created_at" : "2013-06-19 13:51:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347350000348577793",
  "text" : "RT @WHLive: Obama: \"Real prosperity comes from our most precious resource\u2014our people. That is why we choose to invest in education, science\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347349947215130625",
    "text" : "Obama: \"Real prosperity comes from our most precious resource\u2014our people. That is why we choose to invest in education, science &amp; research.\"",
    "id" : 347349947215130625,
    "created_at" : "2013-06-19 13:47:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 347350000348577793,
  "created_at" : "2013-06-19 13:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347349773998772224",
  "text" : "President Obama: \"When we stand up for our gay and lesbian brothers and sisters...we defend our own liberty as well.\"",
  "id" : 347349773998772224,
  "created_at" : "2013-06-19 13:46:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347349576728051713",
  "text" : "President Obama: \u201CWhen we respect the faiths practiced in our churches and synagogues, our mosques and temples\u2014we\u2019re more secure.\u201D",
  "id" : 347349576728051713,
  "created_at" : "2013-06-19 13:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347349286922620928",
  "text" : "President Obama: \"We are stronger when all our people, no matter who they are or what they look like, are granted opportunity.\"",
  "id" : 347349286922620928,
  "created_at" : "2013-06-19 13:44:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347348947028803584",
  "text" : "RT @WHLive: Obama on the U.S. &amp; Germany: \"Our alliance is the foundation of global security. Our trade &amp; commerce is the engine of the glob\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347348781244760064",
    "text" : "Obama on the U.S. &amp; Germany: \"Our alliance is the foundation of global security. Our trade &amp; commerce is the engine of the global economy.\"",
    "id" : 347348781244760064,
    "created_at" : "2013-06-19 13:42:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 347348947028803584,
  "created_at" : "2013-06-19 13:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347348296962027522",
  "text" : "Obama: \"We are not only citizens of America or Germany\u2014we are also citizens of the world. Our fates &amp; fortunes are linked like never before\"",
  "id" : 347348296962027522,
  "created_at" : "2013-06-19 13:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347347907055341569",
  "text" : "President Obama: \"Complacency is not the character of great nations...the struggle for freedom, and security, and human dignity...goes on.\"",
  "id" : 347347907055341569,
  "created_at" : "2013-06-19 13:39:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347346537061425152",
  "text" : "President Obama in Berlin: \"No wall can stand against the yearning for freedom, the yearning for peace that burns in human hearts.\"",
  "id" : 347346537061425152,
  "created_at" : "2013-06-19 13:34:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/LHG2iGdv9o",
      "expanded_url" : "http:\/\/at.wh.gov\/mbhLp",
      "display_url" : "at.wh.gov\/mbhLp"
    } ]
  },
  "geo" : { },
  "id_str" : "347345381757157379",
  "text" : "Happening now: President Obama speaks at the Brandenburg Gate in Berlin, Germany. Watch: http:\/\/t.co\/LHG2iGdv9o",
  "id" : 347345381757157379,
  "created_at" : "2013-06-19 13:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/3CLLyGRCwU",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "347335986663014400",
  "text" : "Tune in at 9am ET for President Obama's speech at the Brandenburg Gate in Berlin, Germany: http:\/\/t.co\/3CLLyGRCwU",
  "id" : 347335986663014400,
  "created_at" : "2013-06-19 12:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/okkgdGFHx2",
      "expanded_url" : "http:\/\/at.wh.gov\/ma4ij",
      "display_url" : "at.wh.gov\/ma4ij"
    } ]
  },
  "geo" : { },
  "id_str" : "347127052316581888",
  "text" : "Great news: U.S. health care costs declined in May for the first time since the 1970s. http:\/\/t.co\/okkgdGFHx2 #ObamacareInAction",
  "id" : 347127052316581888,
  "created_at" : "2013-06-18 23:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 19, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/xqt0i0M3uW",
      "expanded_url" : "http:\/\/at.wh.gov\/mabwj",
      "display_url" : "at.wh.gov\/mabwj"
    } ]
  },
  "geo" : { },
  "id_str" : "347121484193476608",
  "text" : "FACT from the CBO: #ImmigrationReform would reduce the deficit by nearly $1 trillion over two decades. http:\/\/t.co\/xqt0i0M3uW",
  "id" : 347121484193476608,
  "created_at" : "2013-06-18 22:39:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347115760965005312",
  "text" : "RT @pfeiffer44: CBO score is a huge boost for common sense Immigration Reform. Good for the economy, good for the middle class",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347111324548997121",
    "text" : "CBO score is a huge boost for common sense Immigration Reform. Good for the economy, good for the middle class",
    "id" : 347111324548997121,
    "created_at" : "2013-06-18 21:59:23 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 347115760965005312,
  "created_at" : "2013-06-18 22:17:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347104287534485504",
  "text" : "RT if you agree: We owe it to our kids to keep fighting to reduce gun violence in our communities.",
  "id" : 347104287534485504,
  "created_at" : "2013-06-18 21:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347099020277207040",
  "text" : "FACT: 21 of the 23 executive actions President Obama laid out in January to help reduce gun violence are completed or near completion.",
  "id" : 347099020277207040,
  "created_at" : "2013-06-18 21:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347093979227111425",
  "text" : "FACT: President Obama ended the freeze on gun violence research\u2014which will aid the development of strong gun violence prevention strategies.",
  "id" : 347093979227111425,
  "created_at" : "2013-06-18 20:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DkAEsZON3y",
      "expanded_url" : "http:\/\/at.wh.gov\/m9Yvu",
      "display_url" : "at.wh.gov\/m9Yvu"
    } ]
  },
  "geo" : { },
  "id_str" : "347087304571117568",
  "text" : "Even without Congress' help, President Obama is doing everything he can to protect our kids by reducing gun violence: http:\/\/t.co\/DkAEsZON3y",
  "id" : 347087304571117568,
  "created_at" : "2013-06-18 20:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/aInSw71p54",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/omb\/legislative\/sap\/113\/saphr1797r_20130617.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347076312650883074",
  "text" : "RT @Simas44: Government should not get involved in decisions best made between a woman and her doctor. http:\/\/t.co\/aInSw71p54",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/aInSw71p54",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/omb\/legislative\/sap\/113\/saphr1797r_20130617.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347030361773076480",
    "text" : "Government should not get involved in decisions best made between a woman and her doctor. http:\/\/t.co\/aInSw71p54",
    "id" : 347030361773076480,
    "created_at" : "2013-06-18 16:37:40 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 347076312650883074,
  "created_at" : "2013-06-18 19:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBiz",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/yN57XaR0dM",
      "expanded_url" : "http:\/\/at.wh.gov\/m9MLM",
      "display_url" : "at.wh.gov\/m9MLM"
    } ]
  },
  "geo" : { },
  "id_str" : "347064807796662273",
  "text" : "\"We're committed to making it possible for more small businesses to thrive.\" \u2014President Obama on #SmallBiz Week: http:\/\/t.co\/yN57XaR0dM",
  "id" : 347064807796662273,
  "created_at" : "2013-06-18 18:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 3, 14 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "signature",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347056110299127808",
  "text" : "RT @USTreasury: Here it is. Secretary Jack Lew\u2019s official #signature as it will appear on U.S. currency starting this fall http:\/\/t.co\/Jvid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USTreasury\/status\/347052319302619138\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Jvid5uOgBA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BND6PuMCEAAHhUT.jpg",
        "id_str" : "347052319311007744",
        "id" : 347052319311007744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BND6PuMCEAAHhUT.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 1700
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 123,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Jvid5uOgBA"
      } ],
      "hashtags" : [ {
        "text" : "signature",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347052319302619138",
    "text" : "Here it is. Secretary Jack Lew\u2019s official #signature as it will appear on U.S. currency starting this fall http:\/\/t.co\/Jvid5uOgBA",
    "id" : 347052319302619138,
    "created_at" : "2013-06-18 18:04:55 +0000",
    "user" : {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "protected" : false,
      "id_str" : "120176950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461250108441370624\/-9PNMlfp_normal.jpeg",
      "id" : 120176950,
      "verified" : true
    }
  },
  "id" : 347056110299127808,
  "created_at" : "2013-06-18 18:19:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "347042208429518848",
  "text" : "Happening now: @VP Biden speaks about the steps we're taking to reduce gun violence. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 347042208429518848,
  "created_at" : "2013-06-18 17:24:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/347028466039922688\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/1OMytXPs6V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNDkjR2CIAAUlP_.jpg",
      "id_str" : "347028466044116992",
      "id" : 347028466044116992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNDkjR2CIAAUlP_.jpg",
      "sizes" : [ {
        "h" : 637,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 955,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/1OMytXPs6V"
    } ],
    "hashtags" : [ {
      "text" : "G8",
      "indices" : [ 58, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XqcRIDoWk2",
      "expanded_url" : "http:\/\/on.wh.gov\/bC9YmqZ",
      "display_url" : "on.wh.gov\/bC9YmqZ"
    } ]
  },
  "geo" : { },
  "id_str" : "347028466039922688",
  "text" : "Check out the latest updates, photos, and videos from the #G8 in Northern Ireland: http:\/\/t.co\/XqcRIDoWk2, http:\/\/t.co\/1OMytXPs6V",
  "id" : 347028466039922688,
  "created_at" : "2013-06-18 16:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizWeek",
      "indices" : [ 47, 60 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347018449165365249",
  "text" : "RT @vj44: This week is the 50th anniversary of #SmallBizWeek. Retweet to show your love for 28M #smallbiz in US.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizWeek",
        "indices" : [ 37, 50 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347005521909411841",
    "text" : "This week is the 50th anniversary of #SmallBizWeek. Retweet to show your love for 28M #smallbiz in US.",
    "id" : 347005521909411841,
    "created_at" : "2013-06-18 14:58:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 347018449165365249,
  "created_at" : "2013-06-18 15:50:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/347007182585331714\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/vG6LOYNAaW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNDRMa0CAAMdoSJ.jpg",
      "id_str" : "347007182593720323",
      "id" : 347007182593720323,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNDRMa0CAAMdoSJ.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/vG6LOYNAaW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347007182585331714",
  "text" : "Staring contest: http:\/\/t.co\/vG6LOYNAaW",
  "id" : 347007182585331714,
  "created_at" : "2013-06-18 15:05:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Rose",
      "screen_name" : "charlierose",
      "indices" : [ 62, 74 ],
      "id_str" : "58550415",
      "id" : 58550415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/a2XyQonvFv",
      "expanded_url" : "http:\/\/at.wh.gov\/m93vn",
      "display_url" : "at.wh.gov\/m93vn"
    } ]
  },
  "geo" : { },
  "id_str" : "346996168766660608",
  "text" : "In case you missed it, watch President Obama's interview with @CharlieRose on the NSA, Syria, Iran, and more: http:\/\/t.co\/a2XyQonvFv",
  "id" : 346996168766660608,
  "created_at" : "2013-06-18 14:21:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346834385716248576",
  "text" : "Obama on NSA: \"I've asked the intelligence community to...see how much of this we can declassify without further compromising the program.\"",
  "id" : 346834385716248576,
  "created_at" : "2013-06-18 03:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346832502805110785",
  "text" : "President Obama: \"If you are a U.S. person, the NSA cannot listen to your telephone calls and the NSA cannot target your emails.\"",
  "id" : 346832502805110785,
  "created_at" : "2013-06-18 03:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346829505110867968",
  "text" : "Pres. Obama on Syria: \"I will preserve every option available to me &amp; continually make assessments about what's in the interest of the U.S.\"",
  "id" : 346829505110867968,
  "created_at" : "2013-06-18 03:19:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346828780901367809",
  "text" : "President Obama on Syria: \"We have a legitimate need to be engaged and to be involved\u2014but for us to do it in a careful, calibrated way.\"",
  "id" : 346828780901367809,
  "created_at" : "2013-06-18 03:16:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346828241140609025",
  "text" : "Obama: \"The Middle East is going to succeed...when you have governments that meet the aspirations of their people\u2014that are tolerant.\"",
  "id" : 346828241140609025,
  "created_at" : "2013-06-18 03:14:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Rose",
      "screen_name" : "charlierose",
      "indices" : [ 19, 31 ],
      "id_str" : "58550415",
      "id" : 58550415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346825256209637377",
  "text" : "President Obama to @CharlieRose: \"Clearly, you have a hunger within Iran to engage with the international community in a more positive way.\"",
  "id" : 346825256209637377,
  "created_at" : "2013-06-18 03:02:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 16, 20 ],
      "id_str" : "12133382",
      "id" : 12133382
    }, {
      "name" : "Charlie Rose",
      "screen_name" : "charlierose",
      "indices" : [ 61, 73 ],
      "id_str" : "58550415",
      "id" : 58550415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/FfWaVZxhZw",
      "expanded_url" : "http:\/\/at.wh.gov\/m82IW",
      "display_url" : "at.wh.gov\/m82IW"
    } ]
  },
  "geo" : { },
  "id_str" : "346824494402387968",
  "text" : "Starting now on @PBS: Watch President Obama's interview with @CharlieRose on NSA, Syria, and more. http:\/\/t.co\/FfWaVZxhZw",
  "id" : 346824494402387968,
  "created_at" : "2013-06-18 02:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Rose Show",
      "screen_name" : "CharlieRoseShow",
      "indices" : [ 15, 31 ],
      "id_str" : "19079396",
      "id" : 19079396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/V9ktO5CZyN",
      "expanded_url" : "http:\/\/at.wh.gov\/m7ets",
      "display_url" : "at.wh.gov\/m7ets"
    } ]
  },
  "geo" : { },
  "id_str" : "346781271617323008",
  "text" : "Tune in to the @CharlieRoseShow tonight at 11pm ET for President Obama's interview on NSA, Syria, and more: http:\/\/t.co\/V9ktO5CZyN",
  "id" : 346781271617323008,
  "created_at" : "2013-06-18 00:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/346767886456606721\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/cQACVrhsbl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM_3jjRCUAEvR6E.jpg",
      "id_str" : "346767886464995329",
      "id" : 346767886464995329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM_3jjRCUAEvR6E.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/cQACVrhsbl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/9HifGuKadf",
      "expanded_url" : "http:\/\/at.wh.gov\/m7P3z",
      "display_url" : "at.wh.gov\/m7P3z"
    } ]
  },
  "geo" : { },
  "id_str" : "346767886456606721",
  "text" : "America will support those on the path of peace every step of the way: http:\/\/t.co\/9HifGuKadf, http:\/\/t.co\/cQACVrhsbl",
  "id" : 346767886456606721,
  "created_at" : "2013-06-17 23:14:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Charlie Rose",
      "screen_name" : "charlierose",
      "indices" : [ 86, 98 ],
      "id_str" : "58550415",
      "id" : 58550415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346743305314373632",
  "text" : "RT @Simas44: Worth a RT. Must watch TV tonight. President Obama's full interview with @charlierose on NSA and other topics.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Rose",
        "screen_name" : "charlierose",
        "indices" : [ 73, 85 ],
        "id_str" : "58550415",
        "id" : 58550415
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346672697020915712",
    "text" : "Worth a RT. Must watch TV tonight. President Obama's full interview with @charlierose on NSA and other topics.",
    "id" : 346672697020915712,
    "created_at" : "2013-06-17 16:56:26 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 346743305314373632,
  "created_at" : "2013-06-17 21:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/346730233073909761\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/4INhSNvm5G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM_VT1fCQAAq6jl.jpg",
      "id_str" : "346730233082298368",
      "id" : 346730233082298368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM_VT1fCQAAq6jl.jpg",
      "sizes" : [ {
        "h" : 698,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/4INhSNvm5G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346730233073909761",
  "text" : "Presidential painting lesson in Northern Ireland today: http:\/\/t.co\/4INhSNvm5G",
  "id" : 346730233073909761,
  "created_at" : "2013-06-17 20:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 35, 42 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskNASA",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/I8Rn2nrucB",
      "expanded_url" : "http:\/\/go.nasa.gov\/126mOLK",
      "display_url" : "go.nasa.gov\/126mOLK"
    } ]
  },
  "geo" : { },
  "id_str" : "346717411858325504",
  "text" : "Astronauts! Watch today's #AskNASA @Google+ Hangout at 4pm ET on how astronauts are trained and selected: http:\/\/t.co\/I8Rn2nrucB",
  "id" : 346717411858325504,
  "created_at" : "2013-06-17 19:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 37, 42 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346713983622975488",
  "text" : "RT @vj44: 1st time ever new class of @nasa astronauts is 50% women. Now that's what I'm talking about! RT to show your support",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 27, 32 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346708816542441477",
    "text" : "1st time ever new class of @nasa astronauts is 50% women. Now that's what I'm talking about! RT to show your support",
    "id" : 346708816542441477,
    "created_at" : "2013-06-17 19:19:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 346713983622975488,
  "created_at" : "2013-06-17 19:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/346710514233118720\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0Gbt8QMLnz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM_DYDFCEAAY4mQ.jpg",
      "id_str" : "346710514241507328",
      "id" : 346710514241507328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM_DYDFCEAAY4mQ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/0Gbt8QMLnz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/SIo5zYseP4",
      "expanded_url" : "http:\/\/at.wh.gov\/m7ow8",
      "display_url" : "at.wh.gov\/m7ow8"
    } ]
  },
  "geo" : { },
  "id_str" : "346710514233118720",
  "text" : "Worth a RT: The latest on President Obama's trip to the G-8 in Northern Ireland and Germany. http:\/\/t.co\/SIo5zYseP4, http:\/\/t.co\/0Gbt8QMLnz",
  "id" : 346710514233118720,
  "created_at" : "2013-06-17 19:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Rose Show",
      "screen_name" : "CharlieRoseShow",
      "indices" : [ 15, 31 ],
      "id_str" : "19079396",
      "id" : 19079396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/EdBtRW6ooI",
      "expanded_url" : "http:\/\/at.wh.gov\/m7dSP",
      "display_url" : "at.wh.gov\/m7dSP"
    } ]
  },
  "geo" : { },
  "id_str" : "346692555565568000",
  "text" : "Don't miss the @CharlieRoseShow tonight. Watch President Obama's 45-minute interview on NSA, Syria &amp; more at 11pm ET: http:\/\/t.co\/EdBtRW6ooI",
  "id" : 346692555565568000,
  "created_at" : "2013-06-17 18:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Rose Show",
      "screen_name" : "CharlieRoseShow",
      "indices" : [ 3, 19 ],
      "id_str" : "19079396",
      "id" : 19079396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346666700135084032",
  "text" : "RT @CharlieRoseShow: Charlie sat down for an exclusive, 45 minute interview with President Obama on Sunday. Airs tonight on PBS at 11pm. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CharlieRoseShow\/status\/346564801771753473\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/fov47MvVoG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BM8-2d3CUAAflUm.jpg",
        "id_str" : "346564801780142080",
        "id" : 346564801780142080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM8-2d3CUAAflUm.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/fov47MvVoG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346564801771753473",
    "text" : "Charlie sat down for an exclusive, 45 minute interview with President Obama on Sunday. Airs tonight on PBS at 11pm. http:\/\/t.co\/fov47MvVoG",
    "id" : 346564801771753473,
    "created_at" : "2013-06-17 09:47:42 +0000",
    "user" : {
      "name" : "Charlie Rose Show",
      "screen_name" : "CharlieRoseShow",
      "protected" : false,
      "id_str" : "19079396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719566234543644672\/M5QOdJyL_normal.jpg",
      "id" : 19079396,
      "verified" : true
    }
  },
  "id" : 346666700135084032,
  "created_at" : "2013-06-17 16:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StrikeForce",
      "indices" : [ 18, 30 ]
    }, {
      "text" : "rural",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346651096795721728",
  "text" : "RT @USDA: Discuss #StrikeForce Initiative to incr opportunities in #rural communities at 12pm ET in a G+ Hangout w\/ Sec Vilsack http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StrikeForce",
        "indices" : [ 8, 20 ]
      }, {
        "text" : "rural",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Z5d1VOHbDe",
        "expanded_url" : "http:\/\/ow.ly\/m6dCj",
        "display_url" : "ow.ly\/m6dCj"
      } ]
    },
    "geo" : { },
    "id_str" : "346606483502424065",
    "text" : "Discuss #StrikeForce Initiative to incr opportunities in #rural communities at 12pm ET in a G+ Hangout w\/ Sec Vilsack http:\/\/t.co\/Z5d1VOHbDe",
    "id" : 346606483502424065,
    "created_at" : "2013-06-17 12:33:19 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 346651096795721728,
  "created_at" : "2013-06-17 15:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/14hnHHXu2A",
      "expanded_url" : "http:\/\/at.wh.gov\/m6EEe",
      "display_url" : "at.wh.gov\/m6EEe"
    } ]
  },
  "geo" : { },
  "id_str" : "346644161631494144",
  "text" : "RT to spread the word: 14 days left for Congress to act before student loan rates double. http:\/\/t.co\/14hnHHXu2A #DontDoubleMyRate",
  "id" : 346644161631494144,
  "created_at" : "2013-06-17 15:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 45, 52 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeroesHangout",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/UPtnEofq5E",
      "expanded_url" : "http:\/\/bit.ly\/13UaEZd",
      "display_url" : "bit.ly\/13UaEZd"
    } ]
  },
  "geo" : { },
  "id_str" : "346633969330167812",
  "text" : "RT @USArmy: Happening Now: #HeroesHangout on @Google+ as Coach K &amp; Soldiers chat. Watch: http:\/\/t.co\/UPtnEofq5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 33, 40 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HeroesHangout",
        "indices" : [ 15, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/UPtnEofq5E",
        "expanded_url" : "http:\/\/bit.ly\/13UaEZd",
        "display_url" : "bit.ly\/13UaEZd"
      } ]
    },
    "geo" : { },
    "id_str" : "346633071791075329",
    "text" : "Happening Now: #HeroesHangout on @Google+ as Coach K &amp; Soldiers chat. Watch: http:\/\/t.co\/UPtnEofq5E",
    "id" : 346633071791075329,
    "created_at" : "2013-06-17 14:18:59 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 346633969330167812,
  "created_at" : "2013-06-17 14:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Charlie Rose",
      "screen_name" : "charlierose",
      "indices" : [ 95, 107 ],
      "id_str" : "58550415",
      "id" : 58550415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346588822617858048",
  "text" : "RT @pfeiffer44: On Sunday before leaving for Ireland, President Obama sat for a 45m intvw with @charlierose on NSA etc. Def worth a watch t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Rose",
        "screen_name" : "charlierose",
        "indices" : [ 79, 91 ],
        "id_str" : "58550415",
        "id" : 58550415
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346576418215448577",
    "text" : "On Sunday before leaving for Ireland, President Obama sat for a 45m intvw with @charlierose on NSA etc. Def worth a watch tonight",
    "id" : 346576418215448577,
    "created_at" : "2013-06-17 10:33:51 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 346588822617858048,
  "created_at" : "2013-06-17 11:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346294553164263424",
  "text" : "RT @FLOTUS: Happy Father's Day to all the dads out there \u2014 especially you, POTUS! -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346294465603985408",
    "text" : "Happy Father's Day to all the dads out there \u2014 especially you, POTUS! -mo",
    "id" : 346294465603985408,
    "created_at" : "2013-06-16 15:53:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 346294553164263424,
  "created_at" : "2013-06-16 15:53:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/346278730836086785\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/3EO6HDeJFv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM46q8kCEAU8OLL.png",
      "id_str" : "346278730840281093",
      "id" : 346278730840281093,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM46q8kCEAU8OLL.png",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/3EO6HDeJFv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346278730836086785",
  "text" : "Happy Father's Day! http:\/\/t.co\/3EO6HDeJFv",
  "id" : 346278730836086785,
  "created_at" : "2013-06-16 14:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/346032124979195906\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/2UvcSk1VYk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM1aYmLCMAAnpg2.jpg",
      "id_str" : "346032124987584512",
      "id" : 346032124987584512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM1aYmLCMAAnpg2.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2UvcSk1VYk"
    } ],
    "hashtags" : [ {
      "text" : "QualityTime",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/JFD34sfklp",
      "expanded_url" : "http:\/\/on.wh.gov\/AU2jyQq",
      "display_url" : "on.wh.gov\/AU2jyQq"
    } ]
  },
  "geo" : { },
  "id_str" : "346032124979195906",
  "text" : "Hope all the dads out there have a great Father's Day weekend: http:\/\/t.co\/JFD34sfklp  #QualityTime http:\/\/t.co\/2UvcSk1VYk",
  "id" : 346032124979195906,
  "created_at" : "2013-06-15 22:31:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/x6UTSSW7bi",
      "expanded_url" : "http:\/\/at.wh.gov\/m3Xg1",
      "display_url" : "at.wh.gov\/m3Xg1"
    } ]
  },
  "geo" : { },
  "id_str" : "345964499804758017",
  "text" : "Obama: \"I wanted to take a moment to talk about the most important job many of us will ever have...being a dad.\" http:\/\/t.co\/x6UTSSW7bi",
  "id" : 345964499804758017,
  "created_at" : "2013-06-15 18:02:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/FezfeFp9I7",
      "expanded_url" : "http:\/\/at.wh.gov\/m3X8a",
      "display_url" : "at.wh.gov\/m3X8a"
    } ]
  },
  "geo" : { },
  "id_str" : "345899000630738945",
  "text" : "In this week\u2019s address, President Obama reflects on Father\u2019s Day: http:\/\/t.co\/FezfeFp9I7",
  "id" : 345899000630738945,
  "created_at" : "2013-06-15 13:42:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/345707497664966656\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/7TV2Kd2R87",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMwzIzLCcAAnin-.jpg",
      "id_str" : "345707497669160960",
      "id" : 345707497669160960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMwzIzLCcAAnin-.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7TV2Kd2R87"
    } ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345707497664966656",
  "text" : "With their moms looking on, 9 year-old twins Zea &amp; Luna introduced the President at reception for #LGBT Pride Month: http:\/\/t.co\/7TV2Kd2R87",
  "id" : 345707497664966656,
  "created_at" : "2013-06-15 01:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/345676498373603328\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/inGRRhU65u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMwW8Z0CcAAmXut.jpg",
      "id_str" : "345676498377797632",
      "id" : 345676498377797632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMwW8Z0CcAAmXut.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/inGRRhU65u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345676498373603328",
  "text" : "Happy Flag Day! http:\/\/t.co\/inGRRhU65u",
  "id" : 345676498373603328,
  "created_at" : "2013-06-14 22:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 22, 29 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/345669626140712960\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Q2rXx6zb6K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMwQsYxCYAAjeQn.jpg",
      "id_str" : "345669626149101568",
      "id" : 345669626149101568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMwQsYxCYAAjeQn.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Q2rXx6zb6K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345669626140712960",
  "text" : "Happy 238th Birthday, @USArmy! http:\/\/t.co\/Q2rXx6zb6K",
  "id" : 345669626140712960,
  "created_at" : "2013-06-14 22:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 76, 91 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    }, {
      "name" : "Too Small to Fail",
      "screen_name" : "2SmallToFail",
      "indices" : [ 102, 115 ],
      "id_str" : "871991101",
      "id" : 871991101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uoDGzI7JjF",
      "expanded_url" : "http:\/\/at.wh.gov\/m3cgb",
      "display_url" : "at.wh.gov\/m3cgb"
    } ]
  },
  "geo" : { },
  "id_str" : "345649966494146562",
  "text" : "Let's make sure none of our children start the race of life already behind. @HillaryClinton announces @2SmallToFail: http:\/\/t.co\/uoDGzI7JjF",
  "id" : 345649966494146562,
  "created_at" : "2013-06-14 21:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 34, 49 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345647472628072448",
  "text" : "RT @FLOTUS: FLOTUS #FollowFriday: @HillaryClinton announces a new effort to improve the health &amp; well-being of America's kids --&gt; http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 22, 37 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowFriday",
        "indices" : [ 7, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/wKyZOhJwRC",
        "expanded_url" : "http:\/\/toosmall.org",
        "display_url" : "toosmall.org"
      } ]
    },
    "geo" : { },
    "id_str" : "345642070318399488",
    "text" : "FLOTUS #FollowFriday: @HillaryClinton announces a new effort to improve the health &amp; well-being of America's kids --&gt; http:\/\/t.co\/wKyZOhJwRC",
    "id" : 345642070318399488,
    "created_at" : "2013-06-14 20:41:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 345647472628072448,
  "created_at" : "2013-06-14 21:02:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345637187062218753",
  "text" : "\"If we truly are created equal, then surely the love we commit to one another must be equal as well.\" \u2014President Obama on #LGBT Pride Month",
  "id" : 345637187062218753,
  "created_at" : "2013-06-14 20:21:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 44, 49 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Indiana Fever",
      "screen_name" : "IndianaFever",
      "indices" : [ 59, 72 ],
      "id_str" : "28672101",
      "id" : 28672101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/iKvF9zgyHo",
      "expanded_url" : "http:\/\/at.wh.gov\/m2VUy",
      "display_url" : "at.wh.gov\/m2VUy"
    } ]
  },
  "geo" : { },
  "id_str" : "345614247474122753",
  "text" : "Happening now: President Obama welcomes the @WNBA Champion @IndianaFever to the White House: http:\/\/t.co\/iKvF9zgyHo",
  "id" : 345614247474122753,
  "created_at" : "2013-06-14 18:50:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345596326161039361",
  "text" : "RT @rhodes44: What do you want to know about POTUS' trips to N Ireland for the G8 &amp; Germany, then Africa? Reply with ?s &amp; I'll answer some \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345571012546555904",
    "text" : "What do you want to know about POTUS' trips to N Ireland for the G8 &amp; Germany, then Africa? Reply with ?s &amp; I'll answer some in a video.",
    "id" : 345571012546555904,
    "created_at" : "2013-06-14 15:58:44 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 345596326161039361,
  "created_at" : "2013-06-14 17:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/AlMORg2qqW",
      "expanded_url" : "http:\/\/at.wh.gov\/m2IbV",
      "display_url" : "at.wh.gov\/m2IbV"
    } ]
  },
  "geo" : { },
  "id_str" : "345590421482766336",
  "text" : "Worth a RT: President Obama is taking steps to bring America's classrooms into the digital age --&gt; http:\/\/t.co\/AlMORg2qqW",
  "id" : 345590421482766336,
  "created_at" : "2013-06-14 17:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KXXr3EdpZt",
      "expanded_url" : "http:\/\/at.wh.gov\/m2EhN",
      "display_url" : "at.wh.gov\/m2EhN"
    } ]
  },
  "geo" : { },
  "id_str" : "345585605490638848",
  "text" : "Today, President Obama made a major announcement on spectrum sharing. What does that mean? Find out: http:\/\/t.co\/KXXr3EdpZt",
  "id" : 345585605490638848,
  "created_at" : "2013-06-14 16:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Nn7vhzE6mk",
      "expanded_url" : "http:\/\/at.wh.gov\/m2AfR",
      "display_url" : "at.wh.gov\/m2AfR"
    } ]
  },
  "geo" : { },
  "id_str" : "345577169029836801",
  "text" : "FACT: Cutting-edge 4G wireless broadband service is on track to be available to 98% of Americans by 2016: http:\/\/t.co\/Nn7vhzE6mk",
  "id" : 345577169029836801,
  "created_at" : "2013-06-14 16:23:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 46, 51 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Indiana Fever",
      "screen_name" : "IndianaFever",
      "indices" : [ 61, 74 ],
      "id_str" : "28672101",
      "id" : 28672101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/4ZPwX0Wk8K",
      "expanded_url" : "http:\/\/at.wh.gov\/m2vzV",
      "display_url" : "at.wh.gov\/m2vzV"
    } ]
  },
  "geo" : { },
  "id_str" : "345569840234389504",
  "text" : "Today at 2:40ET: President Obama welcomes the @WNBA Champion @IndianaFever to the White House. Watch: http:\/\/t.co\/4ZPwX0Wk8K",
  "id" : 345569840234389504,
  "created_at" : "2013-06-14 15:54:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/345311966035836929\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bA8yMF9Yjt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMrLZ1DCAAEkStE.jpg",
      "id_str" : "345311966044225537",
      "id" : 345311966044225537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMrLZ1DCAAEkStE.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/bA8yMF9Yjt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345311966035836929",
  "text" : "Higher education should be a right for all Americans\u2014and that's why we can't let student loan rates double July 1st: http:\/\/t.co\/bA8yMF9Yjt",
  "id" : 345311966035836929,
  "created_at" : "2013-06-13 22:49:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 56, 63 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345239786551918592",
  "text" : "RT @WHLive: Join WH Policy Advisor Roberto Rodriquez on @WHLive at 3pm ET for a Twitter Q&amp;A on student loans. Ask questions now using #Dont\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 44, 51 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 126, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345230960335400960",
    "text" : "Join WH Policy Advisor Roberto Rodriquez on @WHLive at 3pm ET for a Twitter Q&amp;A on student loans. Ask questions now using #DontDoubleMyRate.",
    "id" : 345230960335400960,
    "created_at" : "2013-06-13 17:27:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 345239786551918592,
  "created_at" : "2013-06-13 18:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345232036652531712",
  "text" : "RT if you agree: We should keep making college more affordable\u2014not force students to pay more for college loans. #DontDoubleMyRate",
  "id" : 345232036652531712,
  "created_at" : "2013-06-13 17:31:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/345220290848124928\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IdflDySkE1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMp4BoWCcAEkFFj.jpg",
      "id_str" : "345220290852319233",
      "id" : 345220290852319233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMp4BoWCcAEkFFj.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/IdflDySkE1"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345220290848124928",
  "text" : "We can't make higher education a luxury. Every American family should be able to afford it. #DontDoubleMyRate, http:\/\/t.co\/IdflDySkE1",
  "id" : 345220290848124928,
  "created_at" : "2013-06-13 16:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345209467241123840",
  "text" : "FACT: President Obama's plan would keep interest rates low on student loans for more than 7 million borrowers. #DontDoubleMyRate",
  "id" : 345209467241123840,
  "created_at" : "2013-06-13 16:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345197811786190848",
  "text" : "FACT: If Congress doesn't act, more than 7 million students will pay about $1,000 more in interest on next year's loans. #DontDoubleMyRate",
  "id" : 345197811786190848,
  "created_at" : "2013-06-13 15:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/bR8r5TeDus",
      "expanded_url" : "http:\/\/at.wh.gov\/lYyTn",
      "display_url" : "at.wh.gov\/lYyTn"
    } ]
  },
  "geo" : { },
  "id_str" : "345186431351803904",
  "text" : "Only 18 days left to act: Student loan rates will double on July 1st if Congress doesn't stop it. http:\/\/t.co\/bR8r5TeDus #DontDoubleMyRate",
  "id" : 345186431351803904,
  "created_at" : "2013-06-13 14:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/344971165288255489\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/esMrntQmRS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMmVcnUCUAAtHkq.jpg",
      "id_str" : "344971165292449792",
      "id" : 344971165292449792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMmVcnUCUAAtHkq.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/esMrntQmRS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344971165288255489",
  "text" : "Best buds. http:\/\/t.co\/esMrntQmRS",
  "id" : 344971165288255489,
  "created_at" : "2013-06-13 00:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 17, 31 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StanleyCup",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344958979639738369",
  "text" : "Good luck to the @NHLBlackhawks tonight \u2013 hope to welcome you back to the White House again as #StanleyCup champs. -bo",
  "id" : 344958979639738369,
  "created_at" : "2013-06-12 23:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacares",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/0xlKqswYVY",
      "expanded_url" : "http:\/\/at.wh.gov\/lYptF",
      "display_url" : "at.wh.gov\/lYptF"
    } ]
  },
  "geo" : { },
  "id_str" : "344909028708712448",
  "text" : "Bloomberg News: Thanks to Obamacare, \"hospitals are improving care and saving millions of dollars.\" http:\/\/t.co\/0xlKqswYVY #Obamacares",
  "id" : 344909028708712448,
  "created_at" : "2013-06-12 20:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/344878647561302016\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/fZz3xnVT31",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMlBTX8CMAAHai4.jpg",
      "id_str" : "344878647569690624",
      "id" : 344878647569690624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMlBTX8CMAAHai4.jpg",
      "sizes" : [ {
        "h" : 719,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fZz3xnVT31"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344878647561302016",
  "text" : "Happy 89th birthday to President George H. W. Bush! http:\/\/t.co\/fZz3xnVT31",
  "id" : 344878647561302016,
  "created_at" : "2013-06-12 18:07:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BA88bczjd6",
      "expanded_url" : "http:\/\/www.bloomberg.com\/news\/2013-06-12\/obamacare-shows-hospital-savings-as-patients-make-gains.html",
      "display_url" : "bloomberg.com\/news\/2013-06-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344874474316906496",
  "text" : "RT @Sebelius: #Obamacare at work: Hospitals providing better care, keeping you out of the hospital thanks to the law: http:\/\/t.co\/BA88bczjd6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/BA88bczjd6",
        "expanded_url" : "http:\/\/www.bloomberg.com\/news\/2013-06-12\/obamacare-shows-hospital-savings-as-patients-make-gains.html",
        "display_url" : "bloomberg.com\/news\/2013-06-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344867096775254016",
    "text" : "#Obamacare at work: Hospitals providing better care, keeping you out of the hospital thanks to the law: http:\/\/t.co\/BA88bczjd6",
    "id" : 344867096775254016,
    "created_at" : "2013-06-12 17:21:37 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 344874474316906496,
  "created_at" : "2013-06-12 17:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sesame Street",
      "screen_name" : "sesamestreet",
      "indices" : [ 86, 99 ],
      "id_str" : "86330674",
      "id" : 86330674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CIsForCookie",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/V9crEzD3Sq",
      "expanded_url" : "http:\/\/vine.co\/v\/blrLOh1UjaM",
      "display_url" : "vine.co\/v\/blrLOh1UjaM"
    } ]
  },
  "geo" : { },
  "id_str" : "344858306973687808",
  "text" : "Spotted: Cookie Monster at the White House. http:\/\/t.co\/V9crEzD3Sq #CIsForCookie (cc: @SesameStreet)",
  "id" : 344858306973687808,
  "created_at" : "2013-06-12 16:46:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 124, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ev9Tq59Pzd",
      "expanded_url" : "http:\/\/at.wh.gov\/lXCkH",
      "display_url" : "at.wh.gov\/lXCkH"
    } ]
  },
  "geo" : { },
  "id_str" : "344847745426812928",
  "text" : "These are the stories that remind us why fixing our broken immigration system is so important --&gt; http:\/\/t.co\/ev9Tq59Pzd #ImmigrationNation",
  "id" : 344847745426812928,
  "created_at" : "2013-06-12 16:04:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ev9Tq59Pzd",
      "expanded_url" : "http:\/\/at.wh.gov\/lXCkH",
      "display_url" : "at.wh.gov\/lXCkH"
    } ]
  },
  "geo" : { },
  "id_str" : "344829863498227712",
  "text" : "Worth a watch and a RT: White House staffers share their immigration stories. http:\/\/t.co\/ev9Tq59Pzd #ImmigrationNation",
  "id" : 344829863498227712,
  "created_at" : "2013-06-12 14:53:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Senator Tim Kaine",
      "screen_name" : "timkaine",
      "indices" : [ 34, 43 ],
      "id_str" : "172858784",
      "id" : 172858784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344819167251283968",
  "text" : "RT @lacasablanca: Congrats to Sen @TimKaine for giving the first-ever Senate speech all in Spanish in support of #ImmigrationReform http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Tim Kaine",
        "screen_name" : "timkaine",
        "indices" : [ 16, 25 ],
        "id_str" : "172858784",
        "id" : 172858784
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 95, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/y3Y4MM9Jly",
        "expanded_url" : "http:\/\/at.wh.gov\/lXumR",
        "display_url" : "at.wh.gov\/lXumR"
      } ]
    },
    "geo" : { },
    "id_str" : "344818329611018241",
    "text" : "Congrats to Sen @TimKaine for giving the first-ever Senate speech all in Spanish in support of #ImmigrationReform http:\/\/t.co\/y3Y4MM9Jly",
    "id" : 344818329611018241,
    "created_at" : "2013-06-12 14:07:50 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 344819167251283968,
  "created_at" : "2013-06-12 14:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Senator Tim Kaine",
      "screen_name" : "timkaine",
      "indices" : [ 40, 49 ],
      "id_str" : "172858784",
      "id" : 172858784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reformamigratoria",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344818688865746944",
  "text" : "RT @lacasablanca: Felicitaciones al Sen @TimKaine por su hist\u00F3rico discurso en espa\u00F1ol en el Senado a favor de la #reformamigratoria http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Tim Kaine",
        "screen_name" : "timkaine",
        "indices" : [ 22, 31 ],
        "id_str" : "172858784",
        "id" : 172858784
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "reformamigratoria",
        "indices" : [ 96, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/36z7Sdvat0",
        "expanded_url" : "http:\/\/at.wh.gov\/lXto6",
        "display_url" : "at.wh.gov\/lXto6"
      } ]
    },
    "geo" : { },
    "id_str" : "344817618370314243",
    "text" : "Felicitaciones al Sen @TimKaine por su hist\u00F3rico discurso en espa\u00F1ol en el Senado a favor de la #reformamigratoria http:\/\/t.co\/36z7Sdvat0",
    "id" : 344817618370314243,
    "created_at" : "2013-06-12 14:05:01 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 344818688865746944,
  "created_at" : "2013-06-12 14:09:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/344594984869179392\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mhCrbC87Rq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMg_UCDCMAAHHmd.jpg",
      "id_str" : "344594984873373696",
      "id" : 344594984873373696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMg_UCDCMAAHHmd.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/mhCrbC87Rq"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 8, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344594984869179392",
  "text" : "Passing #ImmigrationReform will strengthen our economy-and there's no reason Congress can't get it done this summer: http:\/\/t.co\/mhCrbC87Rq",
  "id" : 344594984869179392,
  "created_at" : "2013-06-11 23:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheGreatGatsby",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/xDfiSxlMZC",
      "expanded_url" : "http:\/\/at.wh.gov\/lW2eY",
      "display_url" : "at.wh.gov\/lW2eY"
    } ]
  },
  "geo" : { },
  "id_str" : "344553523557580800",
  "text" : "You've probably heard of #TheGreatGatsby. But what about The Great Gatsby Curve? http:\/\/t.co\/xDfiSxlMZC",
  "id" : 344553523557580800,
  "created_at" : "2013-06-11 20:35:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344530024495472641",
  "text" : "RT if you agree: Let's fix our broken immigration system so students from around the world create jobs and start businesses here in America.",
  "id" : 344530024495472641,
  "created_at" : "2013-06-11 19:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 95, 102 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 104, 109 ],
      "id_str" : "19709040",
      "id" : 19709040
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 111, 117 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 123, 129 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344522247010136064",
  "text" : "FACT: Immigrants have started 25% of public U.S. companies backed by venture capital\u2014including @Google, @eBay, @Yahoo, and @Intel.",
  "id" : 344522247010136064,
  "created_at" : "2013-06-11 18:31:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344517088389505024",
  "text" : "FACT: U.S. immigrants represent 50% of PhDs working in math and computer science and 57% of PhDs working in engineering. #ImmigrationNation",
  "id" : 344517088389505024,
  "created_at" : "2013-06-11 18:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344511980155052034",
  "text" : "FACT: More than 40% of Fortune 500 companies were founded by immigrants or a child of immigrants. #ImmigrationNation",
  "id" : 344511980155052034,
  "created_at" : "2013-06-11 17:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/344506840341676032\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lZDcsXWvGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMfvJWGCAAI9izg.jpg",
      "id_str" : "344506840345870338",
      "id" : 344506840345870338,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMfvJWGCAAI9izg.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/lZDcsXWvGu"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344506840341676032",
  "text" : "FACT: In 2011, immigrants started more than one-fourth of all new businesses in the U.S. #ImmigrationNation, http:\/\/t.co\/lZDcsXWvGu",
  "id" : 344506840341676032,
  "created_at" : "2013-06-11 17:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/344501419648356352\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HeIpcQlUFz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMfqN0cCEAEjiRg.jpg",
      "id_str" : "344501419652550657",
      "id" : 344501419652550657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMfqN0cCEAEjiRg.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/HeIpcQlUFz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Z8eYXAZ6Yb",
      "expanded_url" : "http:\/\/at.wh.gov\/lVAf0",
      "display_url" : "at.wh.gov\/lVAf0"
    } ]
  },
  "geo" : { },
  "id_str" : "344501419648356352",
  "text" : "Worth a RT: Here's how President Obama's plan would fix our broken immigration system. http:\/\/t.co\/Z8eYXAZ6Yb, http:\/\/t.co\/HeIpcQlUFz",
  "id" : 344501419648356352,
  "created_at" : "2013-06-11 17:08:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344487748771647488",
  "text" : "RT @Simas44: Fixing the broken immigration system: Strengthened borders. Employer accountability. A pathway to earned citizenship.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344485832813592576",
    "text" : "Fixing the broken immigration system: Strengthened borders. Employer accountability. A pathway to earned citizenship.",
    "id" : 344485832813592576,
    "created_at" : "2013-06-11 16:06:37 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 344487748771647488,
  "created_at" : "2013-06-11 16:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344469038426120193",
  "text" : "\"Now is the time to make your voice heard. You need to call or email or tweet your Senator.\" \u2014Obama on how we pass #ImmigrationReform",
  "id" : 344469038426120193,
  "created_at" : "2013-06-11 14:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344467931096309760",
  "text" : "\"If you genuinely believe we need to fix our broken immigration system, there is no good reason to stand in the way.\" \u2014President Obama",
  "id" : 344467931096309760,
  "created_at" : "2013-06-11 14:55:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344467341159047170",
  "text" : "\"Smarter enforcement. A pathway to earned citizenship. Improvements to the legal system.\" \u2014Obama on what #ImmigrationReform looks like",
  "id" : 344467341159047170,
  "created_at" : "2013-06-11 14:53:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344465796375932928",
  "text" : "\"To truly deal with this issue, Congress needs to act. And that moment is now.\" \u2014President Obama on fixing our broken immigration system",
  "id" : 344465796375932928,
  "created_at" : "2013-06-11 14:47:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344465321895276545",
  "text" : "Obama: \"Right now, our immigration system has no credible way of dealing with the 11 million men &amp; women who are in this country illegally.\"",
  "id" : 344465321895276545,
  "created_at" : "2013-06-11 14:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344465079858782208",
  "text" : "President Obama: Immigration is \"a driving force in our economy, creating jobs and prosperity for all our citizens.\" #ImmigrationNation",
  "id" : 344465079858782208,
  "created_at" : "2013-06-11 14:44:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344464554077589504",
  "text" : "President Obama on immigration in America: \"It\u2019s kept our workforce vibrant and dynamic. It\u2019s kept our businesses on the cutting edge.\"",
  "id" : 344464554077589504,
  "created_at" : "2013-06-11 14:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344464199759568896",
  "text" : "President Obama: \"The promise we\u2019ve found in those who come from every corner of the globe has always been one of our greatest strengths.\"",
  "id" : 344464199759568896,
  "created_at" : "2013-06-11 14:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "344462858207232000",
  "text" : "Happening now: President Obama speaks on fixing our broken immigration system. Watch: http:\/\/t.co\/KvadYk9atb #ImmigrationNation",
  "id" : 344462858207232000,
  "created_at" : "2013-06-11 14:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "344454653754372097",
  "text" : "Tune in at 10:20am ET for President Obama's remarks on fixing our broken immigration system: http:\/\/t.co\/KvadYk9atb #ImmigrationNation",
  "id" : 344454653754372097,
  "created_at" : "2013-06-11 14:02:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/344174673900228608\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/H9l1VUTrFO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMbBCtsCUAATDwY.jpg",
      "id_str" : "344174673908617216",
      "id" : 344174673908617216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMbBCtsCUAATDwY.jpg",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 793
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 793
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/H9l1VUTrFO"
    } ],
    "hashtags" : [ {
      "text" : "WhereTheWildThingsAre",
      "indices" : [ 58, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344174673900228608",
  "text" : "Here's to Maurice Sendak, who would have turned 85 today. #WhereTheWildThingsAre, http:\/\/t.co\/H9l1VUTrFO",
  "id" : 344174673900228608,
  "created_at" : "2013-06-10 19:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344158134274764801",
  "text" : "RT @WHLive: \"Jason never forgets who it is we\u2019re fighting for\u2014middle-class families.\" \u2014President Obama on his CEA Chair nominee, Jason Furm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344158057904881664",
    "text" : "\"Jason never forgets who it is we\u2019re fighting for\u2014middle-class families.\" \u2014President Obama on his CEA Chair nominee, Jason Furman",
    "id" : 344158057904881664,
    "created_at" : "2013-06-10 18:24:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 344158134274764801,
  "created_at" : "2013-06-10 18:24:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/f6DLS8MpgG",
      "expanded_url" : "http:\/\/at.wh.gov\/lTe4a",
      "display_url" : "at.wh.gov\/lTe4a"
    } ]
  },
  "geo" : { },
  "id_str" : "344155536087973888",
  "text" : "RT @WHLive: Happening now: President Obama makes a personnel announcement. Watch: http:\/\/t.co\/f6DLS8MpgG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/f6DLS8MpgG",
        "expanded_url" : "http:\/\/at.wh.gov\/lTe4a",
        "display_url" : "at.wh.gov\/lTe4a"
      } ]
    },
    "geo" : { },
    "id_str" : "344155429615570944",
    "text" : "Happening now: President Obama makes a personnel announcement. Watch: http:\/\/t.co\/f6DLS8MpgG",
    "id" : 344155429615570944,
    "created_at" : "2013-06-10 18:13:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 344155536087973888,
  "created_at" : "2013-06-10 18:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/344144458079666177\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4Q0CZ1iwNU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMalj6_CAAAvw5L.jpg",
      "id_str" : "344144458088054784",
      "id" : 344144458088054784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMalj6_CAAAvw5L.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/4Q0CZ1iwNU"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344144458079666177",
  "text" : "RT if you agree: We can't stop fighting for #EqualPay until all women are paid equally to men for the same work. http:\/\/t.co\/4Q0CZ1iwNU",
  "id" : 344144458079666177,
  "created_at" : "2013-06-10 17:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344139600131936257",
  "text" : "FACT: Despite progress, women are still only paid an average of 77 cents for every dollar a man makes for the same work. #EqualPay",
  "id" : 344139600131936257,
  "created_at" : "2013-06-10 17:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344134736412819457",
  "text" : "FACT: President Obama's Lilly Ledbetter Fair Pay Act made it easier for women to effectively challenge unequal pay. #EqualPay",
  "id" : 344134736412819457,
  "created_at" : "2013-06-10 16:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/lkQLz1kghV",
      "expanded_url" : "http:\/\/at.wh.gov\/lSyrU",
      "display_url" : "at.wh.gov\/lSyrU"
    } ]
  },
  "geo" : { },
  "id_str" : "344129481323204609",
  "text" : "FACT: The #EqualPay Act requires employers to pay women the same as men for the same work. http:\/\/t.co\/lkQLz1kghV",
  "id" : 344129481323204609,
  "created_at" : "2013-06-10 16:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344123034728296448",
  "text" : "Obama: \"Now\u2019s the time to make the minimum wage a wage you can live on, because 60% of those making the minimum wage are women.\" #EqualPay",
  "id" : 344123034728296448,
  "created_at" : "2013-06-10 16:04:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344122292390993921",
  "text" : "Obama: \"Now\u2019s the time for Congress to step up and pass the Paycheck Fairness Act, so women have better tools to fight for #EqualPay.\"",
  "id" : 344122292390993921,
  "created_at" : "2013-06-10 16:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344121870762782720",
  "text" : "President Obama: \u201CThat\u2019s why the first bill I signed into law was the Lilly Ledbetter Fair Pay Act.\u201D #EqualPay",
  "id" : 344121870762782720,
  "created_at" : "2013-06-10 16:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344121399742459904",
  "text" : "President Obama on fighting for #EqualPay: \"This is the 21st century. It\u2019s time to close that gap.\"",
  "id" : 344121399742459904,
  "created_at" : "2013-06-10 15:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344121181739311104",
  "text" : "\"I don\u2019t want that for Malia and Sasha. I don\u2019t want that for your daughters.\" \u2014Obama on women getting paid less than men for the same work",
  "id" : 344121181739311104,
  "created_at" : "2013-06-10 15:57:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344120772547198976",
  "text" : "Obama: \u201COur journey to equality is not complete until our wives, our mothers, and daughters can earn a living equal to their efforts.\u201D",
  "id" : 344120772547198976,
  "created_at" : "2013-06-10 15:56:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344120413825142784",
  "text" : "President Obama on #EqualPay for equal work: \"It\u2019s the idea that all of us are created equal.\"",
  "id" : 344120413825142784,
  "created_at" : "2013-06-10 15:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "344119769005424641",
  "text" : "Happening now: President Obama speaks on the 50th anniversary of the #EqualPay Act. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 344119769005424641,
  "created_at" : "2013-06-10 15:52:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nppPmvhI9B",
      "expanded_url" : "http:\/\/at.wh.gov\/lSxHV",
      "display_url" : "at.wh.gov\/lSxHV"
    } ]
  },
  "geo" : { },
  "id_str" : "344107099560767488",
  "text" : "The #EqualPay Act turns 50 today. We've made progress\u2014but there's more work to do to ensure equal pay for equal work: http:\/\/t.co\/nppPmvhI9B",
  "id" : 344107099560767488,
  "created_at" : "2013-06-10 15:01:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "344099298176290817",
  "text" : "At 11:30am ET, President Obama delivers remarks on the 50th anniversary of the #EqualPay Act. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 344099298176290817,
  "created_at" : "2013-06-10 14:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/G6UdNPNRJc",
      "expanded_url" : "http:\/\/at.wh.gov\/lPxCb",
      "display_url" : "at.wh.gov\/lPxCb"
    } ]
  },
  "geo" : { },
  "id_str" : "343737178574163968",
  "text" : "\"We have to get this done so that everyone is playing by the same rules.\" \u2014President Obama on #ImmigrationReform: http:\/\/t.co\/G6UdNPNRJc",
  "id" : 343737178574163968,
  "created_at" : "2013-06-09 14:31:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/49hJb6St2P",
      "expanded_url" : "http:\/\/at.wh.gov\/lPxy6",
      "display_url" : "at.wh.gov\/lPxy6"
    } ]
  },
  "geo" : { },
  "id_str" : "343404965362012160",
  "text" : "\"We define ourselves as a nation of immigrants.\" \u2014Obama on why we need to fix our broken immigration system: http:\/\/t.co\/49hJb6St2P",
  "id" : 343404965362012160,
  "created_at" : "2013-06-08 16:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/343374375514406913\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WFRFJvJLUh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMPpLN4CAAAn24e.jpg",
      "id_str" : "343374375522795520",
      "id" : 343374375522795520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMPpLN4CAAAn24e.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/WFRFJvJLUh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/GuDC73dgxk",
      "expanded_url" : "http:\/\/on.wh.gov\/9wFsswf",
      "display_url" : "on.wh.gov\/9wFsswf"
    } ]
  },
  "geo" : { },
  "id_str" : "343374375514406913",
  "text" : "Worth a RT: President Obama on why it's time to fix our broken immigration system: http:\/\/t.co\/GuDC73dgxk, http:\/\/t.co\/WFRFJvJLUh",
  "id" : 343374375514406913,
  "created_at" : "2013-06-08 14:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/343125289569767425\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ti9WWKGmY2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMMGogaCUAAt7B7.jpg",
      "id_str" : "343125289573961728",
      "id" : 343125289573961728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMMGogaCUAAt7B7.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ti9WWKGmY2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343125289569767425",
  "text" : "Hope you can spend some time outside this weekend. http:\/\/t.co\/ti9WWKGmY2",
  "id" : 343125289569767425,
  "created_at" : "2013-06-07 22:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 125, 139 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 91, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343075014960095232",
  "text" : "RT @Sebelius: Millions of Americans will get access to health care through the Marketplace #WhatHasObamaCareDoneForMeLately  @HealthCareGov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 111, 125 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatHasObamaCareDoneForMeLately",
        "indices" : [ 77, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343065754360496128",
    "text" : "Millions of Americans will get access to health care through the Marketplace #WhatHasObamaCareDoneForMeLately  @HealthCareGov",
    "id" : 343065754360496128,
    "created_at" : "2013-06-07 18:03:44 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 343075014960095232,
  "created_at" : "2013-06-07 18:40:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 102, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343068042500141056",
  "text" : "FACT: 17 million children with pre-existing conditions are no longer denied coverage or charged more. #WhatHasObamaCareDoneForMeLately",
  "id" : 343068042500141056,
  "created_at" : "2013-06-07 18:12:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/343055654958821376\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/f7mzxFjTya",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMLHTPSCcAAIf2_.png",
      "id_str" : "343055654967209984",
      "id" : 343055654967209984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMLHTPSCcAAIf2_.png",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/f7mzxFjTya"
    } ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 46, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/4Pa3FOmtRs",
      "expanded_url" : "http:\/\/at.wh.gov\/lOH0Q",
      "display_url" : "at.wh.gov\/lOH0Q"
    } ]
  },
  "geo" : { },
  "id_str" : "343055654958821376",
  "text" : "Saves consumers money. http:\/\/t.co\/4Pa3FOmtRs #WhatHasObamaCareDoneForMeLately, http:\/\/t.co\/f7mzxFjTya",
  "id" : 343055654958821376,
  "created_at" : "2013-06-07 17:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 63, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343053670579056640",
  "text" : "RT @kjanes741: Made preventative care affordable for millions. #WhatHasObamaCareDoneForMeLately",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatHasObamaCareDoneForMeLately",
        "indices" : [ 48, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343053237894672384",
    "text" : "Made preventative care affordable for millions. #WhatHasObamaCareDoneForMeLately",
    "id" : 343053237894672384,
    "created_at" : "2013-06-07 17:14:00 +0000",
    "user" : {
      "name" : "k741",
      "screen_name" : "k74111",
      "protected" : false,
      "id_str" : "22371697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744712707602014208\/XgxVb5gA_normal.jpg",
      "id" : 22371697,
      "verified" : false
    }
  },
  "id" : 343053670579056640,
  "created_at" : "2013-06-07 17:15:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruth Schubert",
      "screen_name" : "ruthschubert",
      "indices" : [ 3, 16 ],
      "id_str" : "102458340",
      "id" : 102458340
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 18, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343052429467721728",
  "text" : "RT @ruthschubert: #WhatHasObamaCareDoneForMeLately um. no pre-existing condition exclusion for my kids, mammograms covered. Can't wait for \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatHasObamaCareDoneForMeLately",
        "indices" : [ 0, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343049225459879937",
    "text" : "#WhatHasObamaCareDoneForMeLately um. no pre-existing condition exclusion for my kids, mammograms covered. Can't wait for Oct.1 enrollment!",
    "id" : 343049225459879937,
    "created_at" : "2013-06-07 16:58:03 +0000",
    "user" : {
      "name" : "Ruth Schubert",
      "screen_name" : "ruthschubert",
      "protected" : false,
      "id_str" : "102458340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2678696660\/f8a6537ef63fcfaf338e9116156c9373_normal.jpeg",
      "id" : 102458340,
      "verified" : false
    }
  },
  "id" : 343052429467721728,
  "created_at" : "2013-06-07 17:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 12, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343050891550666752",
  "text" : "RT @KCB642: #WhatHasObamaCareDoneForMeLately I still have health insurance because they aren't allowed to call childhood cancer a preexisti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatHasObamaCareDoneForMeLately",
        "indices" : [ 0, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343050085644521472",
    "text" : "#WhatHasObamaCareDoneForMeLately I still have health insurance because they aren't allowed to call childhood cancer a preexisting condition",
    "id" : 343050085644521472,
    "created_at" : "2013-06-07 17:01:28 +0000",
    "user" : {
      "name" : "Kathryn Carolina B",
      "screen_name" : "kcb_42",
      "protected" : false,
      "id_str" : "22548154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766832443651399680\/zuKgYYp-_normal.jpg",
      "id" : 22548154,
      "verified" : false
    }
  },
  "id" : 343050891550666752,
  "created_at" : "2013-06-07 17:04:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 77, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343046581727158273",
  "text" : "FACT: 3.1 million young adults gained coverage through their parents' plans. #WhatHasObamaCareDoneForMeLately",
  "id" : 343046581727158273,
  "created_at" : "2013-06-07 16:47:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/343042147987111936\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/C0TEakqu0o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMK7BB4CQAE4SeP.png",
      "id_str" : "343042147991306241",
      "id" : 343042147991306241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMK7BB4CQAE4SeP.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 979
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 979
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/C0TEakqu0o"
    } ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 52, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/iycgxb0DmL",
      "expanded_url" : "http:\/\/at.wh.gov\/lOyOe",
      "display_url" : "at.wh.gov\/lOyOe"
    } ]
  },
  "geo" : { },
  "id_str" : "343042147987111936",
  "text" : "Birth control with no copay. http:\/\/t.co\/iycgxb0DmL #WhatHasObamaCareDoneForMeLately, http:\/\/t.co\/C0TEakqu0o",
  "id" : 343042147987111936,
  "created_at" : "2013-06-07 16:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 4, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/VHX3PNOdnI",
      "expanded_url" : "http:\/\/at.wh.gov\/lOxmL",
      "display_url" : "at.wh.gov\/lOxmL"
    } ]
  },
  "geo" : { },
  "id_str" : "343039511166611456",
  "text" : "Use #WhatHasObamaCareDoneForMeLately to share how health care reform has helped you or your family. http:\/\/t.co\/VHX3PNOdnI",
  "id" : 343039511166611456,
  "created_at" : "2013-06-07 16:19:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 88, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343037918077657088",
  "text" : "President Obama: \"Quality, affordable care is not some earned privilege. It's a right.\" #WhatHasObamaCareDoneForMeLately",
  "id" : 343037918077657088,
  "created_at" : "2013-06-07 16:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 91, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343037122783109121",
  "text" : "President Obama: \"Competition and choice are pushing costs down in the individual market.\" #WhatHasObamaCareDoneForMeLately",
  "id" : 343037122783109121,
  "created_at" : "2013-06-07 16:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 102, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/pRsrLF5zIm",
      "expanded_url" : "http:\/\/at.wh.gov\/lOvdL",
      "display_url" : "at.wh.gov\/lOvdL"
    } ]
  },
  "geo" : { },
  "id_str" : "343035780832305153",
  "text" : "Watch live: President Obama speaks on the benefits of the Affordable Care Act. http:\/\/t.co\/pRsrLF5zIm #WhatHasObamaCareDoneForMeLately",
  "id" : 343035780832305153,
  "created_at" : "2013-06-07 16:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 76, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343034363132391424",
  "text" : "FACT: 12 million Americans received rebates from their insurance companies. #WhatHasObamaCareDoneForMeLately",
  "id" : 343034363132391424,
  "created_at" : "2013-06-07 15:59:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/343030755548610561\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/lTx1agHCet",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMKwp5wCQAA1rGj.png",
      "id_str" : "343030755556999168",
      "id" : 343030755556999168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMKwp5wCQAA1rGj.png",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 157,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/lTx1agHCet"
    } ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 24, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343030755548610561",
  "text" : "Mammograms are covered. #WhatHasObamaCareDoneForMeLately, http:\/\/t.co\/lTx1agHCet",
  "id" : 343030755548610561,
  "created_at" : "2013-06-07 15:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 65, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343028559981469696",
  "text" : "FACT: 105 million Americans are paying less for preventive care. #WhatHasObamaCareDoneForMeLately",
  "id" : 343028559981469696,
  "created_at" : "2013-06-07 15:35:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/343027773134225409\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/8xBfYXwOod",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMKt8TZCQAAeNO5.png",
      "id_str" : "343027773142614016",
      "id" : 343027773142614016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMKt8TZCQAAeNO5.png",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 979
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 979
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8xBfYXwOod"
    } ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 26, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343027773134225409",
  "text" : "Young adults are covered. #WhatHasObamaCareDoneForMeLately, http:\/\/t.co\/8xBfYXwOod",
  "id" : 343027773134225409,
  "created_at" : "2013-06-07 15:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHasObamaCareDoneForMeLately",
      "indices" : [ 0, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/smDTyxWAPz",
      "expanded_url" : "http:\/\/at.wh.gov\/lObS0",
      "display_url" : "at.wh.gov\/lObS0"
    } ]
  },
  "geo" : { },
  "id_str" : "343026713715941376",
  "text" : "#WhatHasObamaCareDoneForMeLately --&gt; It's helping millions of Americans afford health insurance: http:\/\/t.co\/smDTyxWAPz",
  "id" : 343026713715941376,
  "created_at" : "2013-06-07 15:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/343022395189239810\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/cbeOikv231",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMKpDQ_CIAAIDvt.jpg",
      "id_str" : "343022395197628416",
      "id" : 343022395197628416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMKpDQ_CIAAIDvt.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/cbeOikv231"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/n40NTaxPdS",
      "expanded_url" : "http:\/\/at.wh.gov\/lO9BE",
      "display_url" : "at.wh.gov\/lO9BE"
    } ]
  },
  "geo" : { },
  "id_str" : "343022395189239810",
  "text" : "Our economy added 178,000 private-sector jobs in May\u2014and there's more work to do: http:\/\/t.co\/n40NTaxPdS, http:\/\/t.co\/cbeOikv231",
  "id" : 343022395189239810,
  "created_at" : "2013-06-07 15:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/342795660975828993\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FIPE9xnVYi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMHa1mOCcAAak7O.jpg",
      "id_str" : "342795660984217600",
      "id" : 342795660984217600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMHa1mOCcAAak7O.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FIPE9xnVYi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/roPeyZ54LM",
      "expanded_url" : "http:\/\/at.wh.gov\/lN576",
      "display_url" : "at.wh.gov\/lN576"
    } ]
  },
  "geo" : { },
  "id_str" : "342795660975828993",
  "text" : "RT if you agree: Every student in America deserves access to high-speed internet at school: http:\/\/t.co\/roPeyZ54LM, http:\/\/t.co\/FIPE9xnVYi",
  "id" : 342795660975828993,
  "created_at" : "2013-06-07 00:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 64, 73 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lSM5bWKtLO",
      "expanded_url" : "http:\/\/at.wh.gov\/lMLZt",
      "display_url" : "at.wh.gov\/lMLZt"
    } ]
  },
  "geo" : { },
  "id_str" : "342742728003698688",
  "text" : "\"It\u2019s wrong. It\u2019s not who we are. And it will not become law.\" \u2014@PressSec on the House GOP's anti-Dreamer amendment: http:\/\/t.co\/lSM5bWKtLO",
  "id" : 342742728003698688,
  "created_at" : "2013-06-06 20:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342723583702859776",
  "text" : "President Obama: \"I\u2019m going to keep fighting with everything I\u2019ve got to build a better future for our young people.\" #ConnectED",
  "id" : 342723583702859776,
  "created_at" : "2013-06-06 19:24:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342722306109480961",
  "text" : "Obama: \"Imagine educators spending fewer hours teaching to a test, and more time helping kids learn in new and innovative ways.\" #ConnectED",
  "id" : 342722306109480961,
  "created_at" : "2013-06-06 19:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342721938218696705",
  "text" : "Obama: \"Imagine a young boy with a chronic illness that confines him to his home able to join his classmates for every lesson.\" #ConnectED",
  "id" : 342721938218696705,
  "created_at" : "2013-06-06 19:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342721422965227521",
  "text" : "President Obama: \u201CIn a country where we expect free Wi-Fi with our coffee, shouldn\u2019t we have it in our schools?\" #ConnectED",
  "id" : 342721422965227521,
  "created_at" : "2013-06-06 19:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342720617952460801",
  "text" : "President Obama on his #ConnectED initiative: It \"will connect 99% of America\u2019s students to high-speed broadband internet within 5 years.\"",
  "id" : 342720617952460801,
  "created_at" : "2013-06-06 19:12:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342720206638022656",
  "text" : "Obama: \"We're going to take a new step to make sure that virtually every child in America\u2019s classrooms has access to the fastest internet.\"",
  "id" : 342720206638022656,
  "created_at" : "2013-06-06 19:10:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342719709768200192",
  "text" : "President Obama: \"No matter who you are, or what you look like, or where you come from, every child can learn. Every child can succeed.\"",
  "id" : 342719709768200192,
  "created_at" : "2013-06-06 19:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "342718225932496896",
  "text" : "Watch live: President Obama speaks in NC about the importance of high-speed internet in our schools. http:\/\/t.co\/KvadYk9atb #ConnectED",
  "id" : 342718225932496896,
  "created_at" : "2013-06-06 19:02:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EdSurge",
      "screen_name" : "EdSurge",
      "indices" : [ 51, 59 ],
      "id_str" : "274793711",
      "id" : 274793711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/IqArv6V9J5",
      "expanded_url" : "http:\/\/at.wh.gov\/lMtcb",
      "display_url" : "at.wh.gov\/lMtcb"
    } ]
  },
  "geo" : { },
  "id_str" : "342714567241125888",
  "text" : "Tune in at 3:30pm ET for a WH \"Show and Tell\" with @EdSurge and high tech schools on technology and digital learning: http:\/\/t.co\/IqArv6V9J5",
  "id" : 342714567241125888,
  "created_at" : "2013-06-06 18:48:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/342694927379070977\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/FxKEKEx0Fs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMF_OIUCAAA278t.jpg",
      "id_str" : "342694927383265280",
      "id" : 342694927383265280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMF_OIUCAAA278t.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FxKEKEx0Fs"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342694927379070977",
  "text" : "RT if you agree: All of our students deserve access to high-speed internet at school. #ConnectED, http:\/\/t.co\/FxKEKEx0Fs",
  "id" : 342694927379070977,
  "created_at" : "2013-06-06 17:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342683683473477634",
  "text" : "FACT: Obama's #ConnectED initiative will help educators receive the support and technology training they need to improve student outcomes.",
  "id" : 342683683473477634,
  "created_at" : "2013-06-06 16:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/342676054529417217\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/C9z60VY8wD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMFuDlfCIAApz-D.jpg",
      "id_str" : "342676054537805824",
      "id" : 342676054537805824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMFuDlfCIAApz-D.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/C9z60VY8wD"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342676054529417217",
  "text" : "FACT: Obama's #ConnectED initiative will give 99% of America's students access to high-speed internet. http:\/\/t.co\/C9z60VY8wD",
  "id" : 342676054529417217,
  "created_at" : "2013-06-06 16:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 132, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/jrj2reG5Rp",
      "expanded_url" : "http:\/\/at.wh.gov\/lM5Jr",
      "display_url" : "at.wh.gov\/lM5Jr"
    } ]
  },
  "geo" : { },
  "id_str" : "342669804970319872",
  "text" : "Worth a RT: President Obama released his plan to bring all of America's students into the digital age --&gt; http:\/\/t.co\/jrj2reG5Rp #ConnectED",
  "id" : 342669804970319872,
  "created_at" : "2013-06-06 15:50:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Uxac7jLrqy",
      "expanded_url" : "http:\/\/at.wh.gov\/lKN5x",
      "display_url" : "at.wh.gov\/lKN5x"
    } ]
  },
  "geo" : { },
  "id_str" : "342435255589953536",
  "text" : "Raise your hand for high-quality early childhood education --&gt; http:\/\/t.co\/Uxac7jLrqy #PreKForAll",
  "id" : 342435255589953536,
  "created_at" : "2013-06-06 00:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 59, 66 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/342419464157032448\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GefZPiynN2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMCEsD3CcAAg7c7.jpg",
      "id_str" : "342419464165421056",
      "id" : 342419464165421056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMCEsD3CcAAg7c7.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GefZPiynN2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/yfCxd9gAbt",
      "expanded_url" : "http:\/\/at.wh.gov\/lKI8t",
      "display_url" : "at.wh.gov\/lKI8t"
    } ]
  },
  "geo" : { },
  "id_str" : "342419464157032448",
  "text" : "President Obama welcomed the Super Bowl champion Baltimore @Ravens to the White House today: http:\/\/t.co\/yfCxd9gAbt, http:\/\/t.co\/GefZPiynN2",
  "id" : 342419464157032448,
  "created_at" : "2013-06-05 23:15:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 99, 108 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/CKb12n33w9",
      "expanded_url" : "http:\/\/wh.gov\/llmwe",
      "display_url" : "wh.gov\/llmwe"
    } ]
  },
  "geo" : { },
  "id_str" : "342407895293497344",
  "text" : "\"The United States condemns in the strongest possible terms the Assad regime\u2019s assault on Qusayr\" \u2014@PressSec: http:\/\/t.co\/CKb12n33w9",
  "id" : 342407895293497344,
  "created_at" : "2013-06-05 22:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342394306084089856",
  "text" : "RT @Simas44: Because of Obamacare, insurance companies in CA are sending premium rebates to thousands of small businesses. http:\/\/t.co\/PFYL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/PFYLN3Tp55",
        "expanded_url" : "http:\/\/www.latimes.com\/business\/la-fi-health-insure-rebates-20130604,0,3390682.story",
        "display_url" : "latimes.com\/business\/la-fi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342393460751491072",
    "text" : "Because of Obamacare, insurance companies in CA are sending premium rebates to thousands of small businesses. http:\/\/t.co\/PFYLN3Tp55",
    "id" : 342393460751491072,
    "created_at" : "2013-06-05 21:32:17 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 342394306084089856,
  "created_at" : "2013-06-05 21:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "indices" : [ 76, 81 ],
      "id_str" : "249677516",
      "id" : 249677516
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 88, 98 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342381730314977280",
  "text" : "RT @AmbassadorRice: Honored to be named the President's next NSA. To all my @USUN &amp; @StateDept colleagues, we've accomplished a ton. Thanks\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Mission to the UN",
        "screen_name" : "USUN",
        "indices" : [ 56, 61 ],
        "id_str" : "249677516",
        "id" : 249677516
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 68, 78 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342375427731488769",
    "text" : "Honored to be named the President's next NSA. To all my @USUN &amp; @StateDept colleagues, we've accomplished a ton. Thanks for 4.5 great years.",
    "id" : 342375427731488769,
    "created_at" : "2013-06-05 20:20:37 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 342381730314977280,
  "created_at" : "2013-06-05 20:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/342368208998772737\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/RSdNmnzbTu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBWEngCMAE-W9X.jpg",
      "id_str" : "342368209002967041",
      "id" : 342368209002967041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBWEngCMAE-W9X.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/RSdNmnzbTu"
    } ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342368208998772737",
  "text" : "RT if you agree that every child in America should have access to a high-quality early education. #PreKForAll, http:\/\/t.co\/RSdNmnzbTu",
  "id" : 342368208998772737,
  "created_at" : "2013-06-05 19:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342360302534422528",
  "text" : "FACT: Fewer than 3 in 10 four-year-olds are enrolled in a high-quality preschool program. #PreKForAll",
  "id" : 342360302534422528,
  "created_at" : "2013-06-05 19:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342355531446513664",
  "text" : "FACT: Every $1 we invest in early education can save more than $7 later on\u2014boosting graduation rates and reducing violent crime. #PreKForAll",
  "id" : 342355531446513664,
  "created_at" : "2013-06-05 19:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 98, 109 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKforALL",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342352627817906176",
  "text" : "RT @PAniskoff44: Early learning advocates across the country are speaking out for #PreKforALL and @arneduncan is about to take q&amp;a!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 81, 92 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PreKforALL",
        "indices" : [ 65, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342352383344517120",
    "text" : "Early learning advocates across the country are speaking out for #PreKforALL and @arneduncan is about to take q&amp;a!",
    "id" : 342352383344517120,
    "created_at" : "2013-06-05 18:49:03 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 342352627817906176,
  "created_at" : "2013-06-05 18:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342347370945712129",
  "text" : "RT @WHLive: \u201CShe\u2019s been a relentless advocate for American interests and values.\" \u2014Obama on his nominee for our next U.N. Ambassador, Saman\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342347239664001025",
    "text" : "\u201CShe\u2019s been a relentless advocate for American interests and values.\" \u2014Obama on his nominee for our next U.N. Ambassador, Samantha Power",
    "id" : 342347239664001025,
    "created_at" : "2013-06-05 18:28:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 342347370945712129,
  "created_at" : "2013-06-05 18:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342345078775365633",
  "text" : "RT @WHLive: Obama: \"I\u2019m extraordinarily proud to announce my new National Security Advisor\u2014our outstanding ambassador to the U.N., Susan Ri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342344850810740736",
    "text" : "Obama: \"I\u2019m extraordinarily proud to announce my new National Security Advisor\u2014our outstanding ambassador to the U.N., Susan Rice.\"",
    "id" : 342344850810740736,
    "created_at" : "2013-06-05 18:19:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 342345078775365633,
  "created_at" : "2013-06-05 18:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "342344214027333632",
  "text" : "Happening now: President Obama makes a national security personnel announcement. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 342344214027333632,
  "created_at" : "2013-06-05 18:16:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/342337555930431488\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/0cWWJWa2wY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMA6MX7CQAMs6W-.jpg",
      "id_str" : "342337555934625795",
      "id" : 342337555934625795,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMA6MX7CQAMs6W-.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0cWWJWa2wY"
    } ],
    "hashtags" : [ {
      "text" : "NationalRunningDay",
      "indices" : [ 6, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342337555930431488",
  "text" : "Happy #NationalRunningDay! http:\/\/t.co\/0cWWJWa2wY",
  "id" : 342337555930431488,
  "created_at" : "2013-06-05 17:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KlaHNsbcZl",
      "expanded_url" : "http:\/\/at.wh.gov\/lK0ve",
      "display_url" : "at.wh.gov\/lK0ve"
    } ]
  },
  "geo" : { },
  "id_str" : "342330927264956416",
  "text" : "Spread the word about President Obama's plan to provide high-quality preschool for every kid in America: http:\/\/t.co\/KlaHNsbcZl #PreKForAll",
  "id" : 342330927264956416,
  "created_at" : "2013-06-05 17:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342315560299790337",
  "text" : "Obama to the Ravens: \"Best of luck next season. You\u2019re going to need it in Week 11 when you go to my hometown to take on the Chicago Bears.\"",
  "id" : 342315560299790337,
  "created_at" : "2013-06-05 16:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 13, 20 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RavensAtTheWH",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342314913244532736",
  "text" : "Obama to the @Ravens: \"Thank you for all the good work you\u2019re doing. Congratulations again on your Super Bowl Championship.\" #RavensAtTheWH",
  "id" : 342314913244532736,
  "created_at" : "2013-06-05 16:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 23, 30 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342314476357435392",
  "text" : "President Obama on the @Ravens: \"That\u2019s the spirit of this entire team. Last year, they donated more than $1 million to charitable causes.\"",
  "id" : 342314476357435392,
  "created_at" : "2013-06-05 16:18:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 74, 81 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RavensAtTheWH",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/lLMgBtlgGj",
      "expanded_url" : "http:\/\/at.wh.gov\/lJPcC",
      "display_url" : "at.wh.gov\/lJPcC"
    } ]
  },
  "geo" : { },
  "id_str" : "342312315594625024",
  "text" : "Happening now: President Obama welcomes the Super Bowl Champion Baltimore @Ravens to the White House. http:\/\/t.co\/lLMgBtlgGj #RavensAtTheWH",
  "id" : 342312315594625024,
  "created_at" : "2013-06-05 16:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 41, 45 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/bndTmMWNpW",
      "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424127887324063304578525010759124472.html?mod=WSJ_Opinion_LEADTop",
      "display_url" : "online.wsj.com\/article\/SB1000\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342299117957033984",
  "text" : "RT @VP: Read VP Biden\u2019s op-ed in today\u2019s @WSJ about free trade &amp; democracy in the Americas: http:\/\/t.co\/bndTmMWNpW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 33, 37 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/bndTmMWNpW",
        "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424127887324063304578525010759124472.html?mod=WSJ_Opinion_LEADTop",
        "display_url" : "online.wsj.com\/article\/SB1000\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342294057327931392",
    "text" : "Read VP Biden\u2019s op-ed in today\u2019s @WSJ about free trade &amp; democracy in the Americas: http:\/\/t.co\/bndTmMWNpW",
    "id" : 342294057327931392,
    "created_at" : "2013-06-05 14:57:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 342299117957033984,
  "created_at" : "2013-06-05 15:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 72, 79 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RavensAtTheWH",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "342289517165830144",
  "text" : "At 12:10pm ET, President Obama honors the Super Bowl Champion Baltimore @Ravens. Watch: http:\/\/t.co\/KvadYk9atb #RavensAtTheWH",
  "id" : 342289517165830144,
  "created_at" : "2013-06-05 14:39:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/P6Cq5DcB8h",
      "expanded_url" : "http:\/\/at.wh.gov\/lIgSM",
      "display_url" : "at.wh.gov\/lIgSM"
    } ]
  },
  "geo" : { },
  "id_str" : "342053068566827008",
  "text" : "Patent trolls hurt everyone\u2014and they need to stop trolling American innovators --&gt; http:\/\/t.co\/P6Cq5DcB8h",
  "id" : 342053068566827008,
  "created_at" : "2013-06-04 22:59:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342037046543654912",
  "text" : "RT @NSCPress: US is deeply concerned by verdicts issued today by an Egyptian court against NGO representatives. See our statement: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/l2jDP6KL6H",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/06\/04\/statement-national-security-council-spokesperson-caitlin-hayden-egypt-ng",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342031552559054849",
    "text" : "US is deeply concerned by verdicts issued today by an Egyptian court against NGO representatives. See our statement: http:\/\/t.co\/l2jDP6KL6H",
    "id" : 342031552559054849,
    "created_at" : "2013-06-04 21:34:11 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 342037046543654912,
  "created_at" : "2013-06-04 21:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/342025526694780928\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Mkn1utExkA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL8eZ4cCIAAVUia.jpg",
      "id_str" : "342025526698975232",
      "id" : 342025526698975232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL8eZ4cCIAAVUia.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Mkn1utExkA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/rCmkZVy9lt",
      "expanded_url" : "http:\/\/at.wh.gov\/lI6dw",
      "display_url" : "at.wh.gov\/lI6dw"
    } ]
  },
  "geo" : { },
  "id_str" : "342025526694780928",
  "text" : "RT to share how President Obama is taking on patent trolls to protect American innovation: http:\/\/t.co\/rCmkZVy9lt, http:\/\/t.co\/Mkn1utExkA",
  "id" : 342025526694780928,
  "created_at" : "2013-06-04 21:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8y0xiUUJmS",
      "expanded_url" : "http:\/\/at.wh.gov\/lI1U2",
      "display_url" : "at.wh.gov\/lI1U2"
    } ]
  },
  "geo" : { },
  "id_str" : "342017048907497473",
  "text" : "Abuse of the patent system is stifling innovation\u2014and that's why President Obama is cracking down on patent trolls: http:\/\/t.co\/8y0xiUUJmS",
  "id" : 342017048907497473,
  "created_at" : "2013-06-04 20:36:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/341992798830067713\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/sLYPBsCpdB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL8Ao3pCAAEeM5N.jpg",
      "id_str" : "341992798834262017",
      "id" : 341992798834262017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL8Ao3pCAAEeM5N.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sLYPBsCpdB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341992798830067713",
  "text" : "Sharing a moment on the rope line. http:\/\/t.co\/sLYPBsCpdB",
  "id" : 341992798830067713,
  "created_at" : "2013-06-04 19:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LptAiWXbvt",
      "expanded_url" : "http:\/\/at.wh.gov\/lHstu",
      "display_url" : "at.wh.gov\/lHstu"
    } ]
  },
  "geo" : { },
  "id_str" : "341982921541955584",
  "text" : "Today's actions to strengthen patent reform build on our progress to protect new ideas and encourage innovation: http:\/\/t.co\/LptAiWXbvt",
  "id" : 341982921541955584,
  "created_at" : "2013-06-04 18:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341972872715182080",
  "text" : "FACT: Obama's patent reform plan would protect innovators from frivolous lawsuits and ensure the highest-quality patents. #MadeInAmerica",
  "id" : 341972872715182080,
  "created_at" : "2013-06-04 17:41:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/4mJNNmf3tP",
      "expanded_url" : "http:\/\/at.wh.gov\/lHrCH",
      "display_url" : "at.wh.gov\/lHrCH"
    } ]
  },
  "geo" : { },
  "id_str" : "341962946567602177",
  "text" : "WSJ: President Obama announces major steps to encourage innovation by cracking down on patent trolls: http:\/\/t.co\/4mJNNmf3tP #MadeInAmerica",
  "id" : 341962946567602177,
  "created_at" : "2013-06-04 17:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/O0udYj78P0",
      "expanded_url" : "http:\/\/at.wh.gov\/lHfHA",
      "display_url" : "at.wh.gov\/lHfHA"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HEkIp1ESQM",
      "expanded_url" : "http:\/\/at.wh.gov\/lHg0X",
      "display_url" : "at.wh.gov\/lHg0X"
    } ]
  },
  "geo" : { },
  "id_str" : "341952040781623296",
  "text" : "In February, President Obama promised further action on patent reform: http:\/\/t.co\/O0udYj78P0. Today, he delivered: http:\/\/t.co\/HEkIp1ESQM",
  "id" : 341952040781623296,
  "created_at" : "2013-06-04 16:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341927331163680768",
  "text" : "\"There's no reason\u2014aside from politics\u2014for Republicans to block these individuals from getting an up or down vote.\" \u2014President Obama",
  "id" : 341927331163680768,
  "created_at" : "2013-06-04 14:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341926471805313024",
  "text" : "President Obama on the D.C. Circuit Court of Appeals: \"I\u2019m nominating three highly qualified individuals to fill those remaining seats.\"",
  "id" : 341926471805313024,
  "created_at" : "2013-06-04 14:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341925588682018816",
  "text" : "President Obama: \"If we want to ensure a fair and functioning judiciary, our courts cannot be short-staffed.\"",
  "id" : 341925588682018816,
  "created_at" : "2013-06-04 14:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "341924895552327680",
  "text" : "Happening now: President Obama delivers a statement from the White House. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 341924895552327680,
  "created_at" : "2013-06-04 14:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "341912353606094848",
  "text" : "Tune in at 10:30am ET for a statement from President Obama: http:\/\/t.co\/KvadYk9atb",
  "id" : 341912353606094848,
  "created_at" : "2013-06-04 13:40:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 61, 64 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/PXBTnYk1eD",
      "expanded_url" : "http:\/\/snd.sc\/11zPo83",
      "display_url" : "snd.sc\/11zPo83"
    } ]
  },
  "geo" : { },
  "id_str" : "341723686610550784",
  "text" : "\"Everything about Frank was what makes this country great.\" \u2014@VP Biden on Sen. Lautenberg: http:\/\/t.co\/PXBTnYk1eD #BeingBiden",
  "id" : 341723686610550784,
  "created_at" : "2013-06-04 01:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/341696910798770176\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/VyNfjZztup",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL3zh61CUAEbZLZ.jpg",
      "id_str" : "341696910802964481",
      "id" : 341696910802964481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL3zh61CUAEbZLZ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VyNfjZztup"
    } ],
    "hashtags" : [ {
      "text" : "equality",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341696910798770176",
  "text" : "Happy LGBT Pride Month! RT if you believe in #equality for all Americans. http:\/\/t.co\/VyNfjZztup",
  "id" : 341696910798770176,
  "created_at" : "2013-06-03 23:24:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/NngQu8jJ3f",
      "expanded_url" : "http:\/\/snd.sc\/11zPo83",
      "display_url" : "snd.sc\/11zPo83"
    } ]
  },
  "geo" : { },
  "id_str" : "341666755392970752",
  "text" : "RT @VP: In Vol. 8 of #BeingBiden, VP talks about his friend the late Senator Frank Lautenberg. Listen here: http:\/\/t.co\/NngQu8jJ3f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 13, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/NngQu8jJ3f",
        "expanded_url" : "http:\/\/snd.sc\/11zPo83",
        "display_url" : "snd.sc\/11zPo83"
      } ]
    },
    "geo" : { },
    "id_str" : "341637624060055552",
    "text" : "In Vol. 8 of #BeingBiden, VP talks about his friend the late Senator Frank Lautenberg. Listen here: http:\/\/t.co\/NngQu8jJ3f",
    "id" : 341637624060055552,
    "created_at" : "2013-06-03 19:28:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 341666755392970752,
  "created_at" : "2013-06-03 21:24:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 16, 24 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341637324221845504",
  "text" : "Happy birthday, @DrBiden!",
  "id" : 341637324221845504,
  "created_at" : "2013-06-03 19:27:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not John Green",
      "screen_name" : "realjohngreen",
      "indices" : [ 49, 63 ],
      "id_str" : "2796445679",
      "id" : 2796445679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/KD2NegHIAU",
      "expanded_url" : "http:\/\/at.wh.gov\/lF2cd",
      "display_url" : "at.wh.gov\/lF2cd"
    } ]
  },
  "geo" : { },
  "id_str" : "341613204067217409",
  "text" : "Congrats! Great name: http:\/\/t.co\/KD2NegHIAU. MT @realjohngreen: Alice was born today. I told her not to forget to be awesome.",
  "id" : 341613204067217409,
  "created_at" : "2013-06-03 17:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/341600210725773312\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/hcbbu9jzzb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL2blO_CIAAi_V6.jpg",
      "id_str" : "341600210729967616",
      "id" : 341600210729967616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL2blO_CIAAi_V6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/hcbbu9jzzb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/9m8CWZWjer",
      "expanded_url" : "http:\/\/on.wh.gov\/3nXhCJY",
      "display_url" : "on.wh.gov\/3nXhCJY"
    } ]
  },
  "geo" : { },
  "id_str" : "341600210725773312",
  "text" : "Here's where you or someone you know can find info about mental illness and seek help: http:\/\/t.co\/9m8CWZWjer, http:\/\/t.co\/hcbbu9jzzb",
  "id" : 341600210725773312,
  "created_at" : "2013-06-03 17:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BWAHBesFX0",
      "expanded_url" : "http:\/\/at.wh.gov\/lETSu",
      "display_url" : "at.wh.gov\/lETSu"
    } ]
  },
  "geo" : { },
  "id_str" : "341589885938987008",
  "text" : "Senator Lautenberg \"lived America\u2019s promise as a citizen and fought to keep that promise alive as a senator.\" \u2014Obama: http:\/\/t.co\/BWAHBesFX0",
  "id" : 341589885938987008,
  "created_at" : "2013-06-03 16:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 104, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/WvCbxIpdwo",
      "expanded_url" : "http:\/\/MentalHealth.gov",
      "display_url" : "MentalHealth.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "341575614001717249",
  "text" : "RT to share where to find information about mental illness and how to seek help: http:\/\/t.co\/WvCbxIpdwo #MentalHealthMatters",
  "id" : 341575614001717249,
  "created_at" : "2013-06-03 15:22:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341569258876178432",
  "text" : "RT @arneduncan: Together we must keep schools safe &amp; ensure they're a place where children aren't bullied or afraid to walk in the door #Me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MentalHealthMatters",
        "indices" : [ 124, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341566661666676737",
    "text" : "Together we must keep schools safe &amp; ensure they're a place where children aren't bullied or afraid to walk in the door #MentalHealthMatters",
    "id" : 341566661666676737,
    "created_at" : "2013-06-03 14:46:52 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 341569258876178432,
  "created_at" : "2013-06-03 14:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341566040016306177",
  "text" : "RT @Simas44: FACT: Next year, insurance companies will no longer be able to deny anyone coverage because of a pre-existing mental health co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341565149011910656",
    "text" : "FACT: Next year, insurance companies will no longer be able to deny anyone coverage because of a pre-existing mental health condition.",
    "id" : 341565149011910656,
    "created_at" : "2013-06-03 14:40:52 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 341566040016306177,
  "created_at" : "2013-06-03 14:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 101, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341559758354006016",
  "text" : "President Obama: \"If you\u2019re struggling, seek help. If you know someone who is, help them reach out.\" #MentalHealthMatters",
  "id" : 341559758354006016,
  "created_at" : "2013-06-03 14:19:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341558842506764288",
  "text" : "Obama: \"What helps more than anything\u2014what gives so many of our friends and loved ones strength\u2014is the knowledge that you are not alone.\"",
  "id" : 341558842506764288,
  "created_at" : "2013-06-03 14:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341558253966200834",
  "text" : "Obama: \"Next year, insurance companies will no longer be able to deny anyone coverage because of a pre-existing mental health condition.\"",
  "id" : 341558253966200834,
  "created_at" : "2013-06-03 14:13:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 109, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341557768169345025",
  "text" : "Obama: \"It\u2019s not enough to help more Americans seek treatment\u2014we also need to make sure treatment is there.\" #MentalHealthMatters",
  "id" : 341557768169345025,
  "created_at" : "2013-06-03 14:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341556981359853568",
  "text" : "Obama: \"We can help people who suffer from a mental illness continue to be the great colleagues and friends and parents we know.\"",
  "id" : 341556981359853568,
  "created_at" : "2013-06-03 14:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 112, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341556622604267520",
  "text" : "President Obama: \"Too many Americans who struggle with mental illness suffer in silence rather than seek help.\" #MentalHealthMatters",
  "id" : 341556622604267520,
  "created_at" : "2013-06-03 14:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341556256890314753",
  "text" : "President Obama: \"We all know someone\u2014a family member, a friend, a neighbor\u2014who has struggled or will struggle with mental health issues.\"",
  "id" : 341556256890314753,
  "created_at" : "2013-06-03 14:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341555836444880898",
  "text" : "President Obama: \"Forty five million Americans suffer from things like depression or anxiety; schizophrenia or PTSD.\" #MentalHealthMatters",
  "id" : 341555836444880898,
  "created_at" : "2013-06-03 14:03:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 103, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341555438451556352",
  "text" : "President Obama: \"We want to let people living with mental health challenges know they are not alone.\" #MentalHealthMatters",
  "id" : 341555438451556352,
  "created_at" : "2013-06-03 14:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentalHealthMatters",
      "indices" : [ 106, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "341554896941768704",
  "text" : "Happening now: President Obama speaks at the National Conference on Mental Health. http:\/\/t.co\/KvadYk9atb #MentalHealthMatters",
  "id" : 341554896941768704,
  "created_at" : "2013-06-03 14:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "341546273234644992",
  "text" : "Starting soon: President Obama speaks at the National Conference on Mental Health at 9:40am ET. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 341546273234644992,
  "created_at" : "2013-06-03 13:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/341215663790108673\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/TLke2u0tcY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLw91qBCMAEW7qp.jpg",
      "id_str" : "341215663794302977",
      "id" : 341215663794302977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLw91qBCMAEW7qp.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TLke2u0tcY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341215663790108673",
  "text" : "Oh hey there. http:\/\/t.co\/TLke2u0tcY",
  "id" : 341215663790108673,
  "created_at" : "2013-06-02 15:32:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/OpcihuCQpO",
      "expanded_url" : "http:\/\/at.wh.gov\/lBSa3",
      "display_url" : "at.wh.gov\/lBSa3"
    } ]
  },
  "geo" : { },
  "id_str" : "341200512923877377",
  "text" : "Obama in his Weekly Address: \"Congress should fix our broken immigration system by passing commonsense reform.\" http:\/\/t.co\/OpcihuCQpO",
  "id" : 341200512923877377,
  "created_at" : "2013-06-02 14:31:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JxlYvpDBrw",
      "expanded_url" : "http:\/\/at.wh.gov\/lBRPx",
      "display_url" : "at.wh.gov\/lBRPx"
    } ]
  },
  "geo" : { },
  "id_str" : "340898568548253696",
  "text" : "Read Obama's plan to help responsible homeowners save money by refinancing at today's low interest rates --&gt; http:\/\/t.co\/JxlYvpDBrw",
  "id" : 340898568548253696,
  "created_at" : "2013-06-01 18:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WCPzPmMqlZ",
      "expanded_url" : "http:\/\/at.wh.gov\/lBRwx",
      "display_url" : "at.wh.gov\/lBRwx"
    } ]
  },
  "geo" : { },
  "id_str" : "340883513907740673",
  "text" : "President Obama on our housing market: \"Sales are rising. Foreclosures are declining. Construction is expanding.\" http:\/\/t.co\/WCPzPmMqlZ",
  "id" : 340883513907740673,
  "created_at" : "2013-06-01 17:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340867997864456192",
  "text" : "FACT: If Congress passed Obama's plan, every responsible homeowner could save an average of $3,000 a year on their mortgages by refinancing.",
  "id" : 340867997864456192,
  "created_at" : "2013-06-01 16:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/UTyzy6jukr",
      "expanded_url" : "http:\/\/at.wh.gov\/lBR3q",
      "display_url" : "at.wh.gov\/lBR3q"
    } ]
  },
  "geo" : { },
  "id_str" : "340851035532824578",
  "text" : "Share this so your friends know President Obama's plan to help responsible homeowners save money by refinancing: http:\/\/t.co\/UTyzy6jukr",
  "id" : 340851035532824578,
  "created_at" : "2013-06-01 15:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JfU19qgWwb",
      "expanded_url" : "http:\/\/at.wh.gov\/lBBH4",
      "display_url" : "at.wh.gov\/lBBH4"
    } ]
  },
  "geo" : { },
  "id_str" : "340830796938104835",
  "text" : "President Obama on helping responsible homeowners save money by refinancing at historically low interest rates: http:\/\/t.co\/JfU19qgWwb",
  "id" : 340830796938104835,
  "created_at" : "2013-06-01 14:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]