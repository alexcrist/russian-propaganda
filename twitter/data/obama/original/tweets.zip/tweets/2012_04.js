Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197099450328551425",
  "text" : "RT @JoiningForces: Dr. Jill Biden \u2013 military mom, teacher &amp; Second Lady \u2013 encourages us to support our nation\u2019s military kids http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/QZvtnLrO",
        "expanded_url" : "http:\/\/wh.gov\/EIE",
        "display_url" : "wh.gov\/EIE"
      } ]
    },
    "geo" : { },
    "id_str" : "197098973633318913",
    "text" : "Dr. Jill Biden \u2013 military mom, teacher &amp; Second Lady \u2013 encourages us to support our nation\u2019s military kids http:\/\/t.co\/QZvtnLrO",
    "id" : 197098973633318913,
    "created_at" : "2012-04-30 23:03:51 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 197099450328551425,
  "created_at" : "2012-04-30 23:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "warriorgames",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/k720J03i",
      "expanded_url" : "http:\/\/www.dvidshub.net\/webcast\/2352",
      "display_url" : "dvidshub.net\/webcast\/2352"
    } ]
  },
  "geo" : { },
  "id_str" : "197081431762153472",
  "text" : "RT @JoiningForces: Happening now: First Lady Michelle Obama speaks at the #warriorgames Opening Ceremonies. Watch live: http:\/\/t.co\/k720J03i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "warriorgames",
        "indices" : [ 55, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/k720J03i",
        "expanded_url" : "http:\/\/www.dvidshub.net\/webcast\/2352",
        "display_url" : "dvidshub.net\/webcast\/2352"
      } ]
    },
    "geo" : { },
    "id_str" : "197081248521396224",
    "text" : "Happening now: First Lady Michelle Obama speaks at the #warriorgames Opening Ceremonies. Watch live: http:\/\/t.co\/k720J03i",
    "id" : 197081248521396224,
    "created_at" : "2012-04-30 21:53:25 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 197081431762153472,
  "created_at" : "2012-04-30 21:54:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PM's Office of Japan",
      "screen_name" : "JPN_PMO",
      "indices" : [ 64, 72 ],
      "id_str" : "266991549",
      "id" : 266991549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "197026396260925440",
  "text" : "Happening now: President Obama &amp; PM Yoshihiko Noda of Japan @JPN_PMO hold a Joint Press Conference. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 197026396260925440,
  "created_at" : "2012-04-30 18:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The Wilson Center",
      "screen_name" : "TheWilsonCenter",
      "indices" : [ 95, 111 ],
      "id_str" : "382129509",
      "id" : 382129509
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "counterterrorism",
      "indices" : [ 68, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/6LnIECS5",
      "expanded_url" : "http:\/\/ow.ly\/aBGrh",
      "display_url" : "ow.ly\/aBGrh"
    } ]
  },
  "geo" : { },
  "id_str" : "196994060479762432",
  "text" : "RT @WHLive: Happening now: John Brennan speaks on President Obama\u2019s #counterterrorism strategy @TheWilsonCenter: Watch: http:\/\/t.co\/6LnIECS5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Wilson Center",
        "screen_name" : "TheWilsonCenter",
        "indices" : [ 83, 99 ],
        "id_str" : "382129509",
        "id" : 382129509
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "counterterrorism",
        "indices" : [ 56, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/6LnIECS5",
        "expanded_url" : "http:\/\/ow.ly\/aBGrh",
        "display_url" : "ow.ly\/aBGrh"
      } ]
    },
    "geo" : { },
    "id_str" : "196993896973213697",
    "text" : "Happening now: John Brennan speaks on President Obama\u2019s #counterterrorism strategy @TheWilsonCenter: Watch: http:\/\/t.co\/6LnIECS5",
    "id" : 196993896973213697,
    "created_at" : "2012-04-30 16:06:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 196994060479762432,
  "created_at" : "2012-04-30 16:06:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Wilson Center",
      "screen_name" : "TheWilsonCenter",
      "indices" : [ 89, 105 ],
      "id_str" : "382129509",
      "id" : 382129509
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "counterterrorism",
      "indices" : [ 62, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/dKgFtLtB",
      "expanded_url" : "http:\/\/ow.ly\/aBBiE",
      "display_url" : "ow.ly\/aBBiE"
    } ]
  },
  "geo" : { },
  "id_str" : "196984793437716481",
  "text" : "Watch live: Sr Advisor John Brennan speaks on the President\u2019s #counterterrorism strategy @TheWilsonCenter @ 12ET: http:\/\/t.co\/dKgFtLtB",
  "id" : 196984793437716481,
  "created_at" : "2012-04-30 15:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/dbONzHBt",
      "expanded_url" : "http:\/\/wh.gov\/\/live",
      "display_url" : "wh.gov\/\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "196974438439333888",
  "text" : "Happening now: President Obama speaks at the Building &amp; Construction Trades Department Legislative Conf. Watch: http:\/\/t.co\/dbONzHBt",
  "id" : 196974438439333888,
  "created_at" : "2012-04-30 14:49:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/wbv7YyPe",
      "expanded_url" : "http:\/\/youtu.be\/fVCsb7r1-vY",
      "display_url" : "youtu.be\/fVCsb7r1-vY"
    } ]
  },
  "geo" : { },
  "id_str" : "196763816539860993",
  "text" : "\"When our men &amp; women in uniform succeed, our country succeeds\" -President Obama in this week's address: http:\/\/t.co\/wbv7YyPe",
  "id" : 196763816539860993,
  "created_at" : "2012-04-30 00:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/tkwcAavs",
      "expanded_url" : "http:\/\/ow.ly\/aAttO",
      "display_url" : "ow.ly\/aAttO"
    } ]
  },
  "geo" : { },
  "id_str" : "196638686526451712",
  "text" : "Watch: President Obama at the 2012 White House Correspondents\u2019 Dinner: http:\/\/t.co\/tkwcAavs #WHCD",
  "id" : 196638686526451712,
  "created_at" : "2012-04-29 16:34:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196418752135442432",
  "text" : "RT @WHLive: Happening now: President Obama Speaks at the 2012 White House Correspondents' Association Dinner. Watch live: http:\/\/t.co\/g5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHCD",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "196418534530756608",
    "text" : "Happening now: President Obama Speaks at the 2012 White House Correspondents' Association Dinner. Watch live: http:\/\/t.co\/g5ih2w0F #WHCD",
    "id" : 196418534530756608,
    "created_at" : "2012-04-29 02:00:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 196418752135442432,
  "created_at" : "2012-04-29 02:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCA",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "196412265489121281",
  "text" : "Happening @ 9:40ET: Watch President Obama speak at the 2012 White House Correspondents' Association Dinner: http:\/\/t.co\/u95y7hhB #WHCA",
  "id" : 196412265489121281,
  "created_at" : "2012-04-29 01:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "196388513724383233",
  "text" : "Watch live: President Obama speaks at the 2012 White House Correspondents' Association Dinner: http:\/\/t.co\/u95y7hhB #WHCD",
  "id" : 196388513724383233,
  "created_at" : "2012-04-29 00:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/b7f0QbaP",
      "expanded_url" : "http:\/\/ow.ly\/azXBY",
      "display_url" : "ow.ly\/azXBY"
    } ]
  },
  "geo" : { },
  "id_str" : "196308558369927168",
  "text" : "Weekly Address: Helping our #Veterans &amp; Servicemembers Make Informed Decisions about Higher Education: http:\/\/t.co\/b7f0QbaP",
  "id" : 196308558369927168,
  "created_at" : "2012-04-28 18:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/AFhCXiRN",
      "expanded_url" : "http:\/\/youtu.be\/fDo2vhMA24k",
      "display_url" : "youtu.be\/fDo2vhMA24k"
    } ]
  },
  "geo" : { },
  "id_str" : "196006427008045056",
  "text" : "Go behind-the-scenes: President Obama hosts a screening of To Kill a Mockingbird to celebrate its 50th anniversary: http:\/\/t.co\/AFhCXiRN",
  "id" : 196006427008045056,
  "created_at" : "2012-04-27 22:42:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vets",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Tt1MV8YS",
      "expanded_url" : "http:\/\/wh.gov\/ETo",
      "display_url" : "wh.gov\/ETo"
    } ]
  },
  "geo" : { },
  "id_str" : "195972474574356480",
  "text" : "President Obama signs executive order to protect education benefits for troops, #vets &amp; their families: http:\/\/t.co\/Tt1MV8YS",
  "id" : 195972474574356480,
  "created_at" : "2012-04-27 20:27:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/195942567572017152\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/zeWP7oM6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArgguiECEAACT9Q.jpg",
      "id_str" : "195942567580405760",
      "id" : 195942567580405760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArgguiECEAACT9Q.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zeWP7oM6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195942567572017152",
  "text" : "Photo of the Day: President Obama speaks with the 2012 Spring White House intern class in the East Room of the WH http:\/\/t.co\/zeWP7oM6",
  "id" : 195942567572017152,
  "created_at" : "2012-04-27 18:28:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "195919484584857601",
  "text" : "RT @WHLive: Happening now:  President Obama Speaks to Troops, Veterans and Military Families http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "195919070766444544",
    "text" : "Happening now:  President Obama Speaks to Troops, Veterans and Military Families http:\/\/t.co\/g5ih2w0F",
    "id" : 195919070766444544,
    "created_at" : "2012-04-27 16:55:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 195919484584857601,
  "created_at" : "2012-04-27 16:56:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/xcORI2QM",
      "expanded_url" : "http:\/\/youtu.be\/5v3kmn1F1Ss",
      "display_url" : "youtu.be\/5v3kmn1F1Ss"
    } ]
  },
  "geo" : { },
  "id_str" : "195888239104634881",
  "text" : "What happened at the White House this week? Find out in our weekly video recap: http:\/\/t.co\/xcORI2QM #DontDoubleMyRate",
  "id" : 195888239104634881,
  "created_at" : "2012-04-27 14:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeCantWait",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/WNR1dtdc",
      "expanded_url" : "http:\/\/www.stripes.com\/news\/veterans\/presidential-order-to-protect-vets-from-colleges-shady-practices-1.175676",
      "display_url" : "stripes.com\/news\/veterans\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195709137282273280",
  "text" : "Stars &amp; Stripes: \"Presidential order to protect vets from colleges' shady practices\" http:\/\/t.co\/WNR1dtdc #WeCantWait",
  "id" : 195709137282273280,
  "created_at" : "2012-04-27 03:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/1Q6yv6O9",
      "expanded_url" : "http:\/\/on.doi.gov\/zLGeEp",
      "display_url" : "on.doi.gov\/zLGeEp"
    } ]
  },
  "geo" : { },
  "id_str" : "195645221621596160",
  "text" : "RT @Interior: Did u know it's National Park week April 21-29? Free admission all week. Plz RT 2 spread the word! http:\/\/t.co\/1Q6yv6O9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/1Q6yv6O9",
        "expanded_url" : "http:\/\/on.doi.gov\/zLGeEp",
        "display_url" : "on.doi.gov\/zLGeEp"
      } ]
    },
    "geo" : { },
    "id_str" : "193376018252316672",
    "text" : "Did u know it's National Park week April 21-29? Free admission all week. Plz RT 2 spread the word! http:\/\/t.co\/1Q6yv6O9",
    "id" : 193376018252316672,
    "created_at" : "2012-04-20 16:30:10 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 195645221621596160,
  "created_at" : "2012-04-26 22:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 86, 97 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/4pQHsXOS",
      "expanded_url" : "http:\/\/wh.gov\/E1T",
      "display_url" : "wh.gov\/E1T"
    } ]
  },
  "geo" : { },
  "id_str" : "195616165551280128",
  "text" : "Keeping rates low is not only good for students, it\u2019s good for the economy. More from @JEarnest44: http:\/\/t.co\/4pQHsXOS #DontDoubleMyRate",
  "id" : 195616165551280128,
  "created_at" : "2012-04-26 20:51:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195551214165966849",
  "text" : "RT @jesseclee44: Wonder if #hcr measure requiring insurers spend 80% of premiums on health is real? 15.8M folks getting $1.3B in rebates ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 10, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/3HuDVtvb",
        "expanded_url" : "http:\/\/wapo.st\/Ir8JAd",
        "display_url" : "wapo.st\/Ir8JAd"
      } ]
    },
    "geo" : { },
    "id_str" : "195534143810043904",
    "text" : "Wonder if #hcr measure requiring insurers spend 80% of premiums on health is real? 15.8M folks getting $1.3B in rebates http:\/\/t.co\/3HuDVtvb",
    "id" : 195534143810043904,
    "created_at" : "2012-04-26 15:25:47 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 195551214165966849,
  "created_at" : "2012-04-26 16:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/195536646039543810\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/4AhEPPXb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AraviyhCIAIQUE3.jpg",
      "id_str" : "195536646047932418",
      "id" : 195536646047932418,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AraviyhCIAIQUE3.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4AhEPPXb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195536646039543810",
  "text" : "Photo of the Day: President Obama stops to view the moon and Venus before boarding Marine One in Boulder, Colo. http:\/\/t.co\/4AhEPPXb",
  "id" : 195536646039543810,
  "created_at" : "2012-04-26 15:35:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matilda A. Hudson",
      "screen_name" : "MatildaEmily",
      "indices" : [ 3, 16 ],
      "id_str" : "22784009",
      "id" : 22784009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 64, 81 ]
    }, {
      "text" : "awesome",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195267383009624066",
  "text" : "RT @MatildaEmily: Pres Obama is pushing college students to use #DontDoubleMyRate to voice their concern about student loan rates! #awesome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 46, 63 ]
      }, {
        "text" : "awesome",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195265636564344833",
    "text" : "Pres Obama is pushing college students to use #DontDoubleMyRate to voice their concern about student loan rates! #awesome",
    "id" : 195265636564344833,
    "created_at" : "2012-04-25 21:38:50 +0000",
    "user" : {
      "name" : "Matilda A. Hudson",
      "screen_name" : "MatildaEmily",
      "protected" : false,
      "id_str" : "22784009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439151399444574208\/HD7AD2eY_normal.jpeg",
      "id" : 22784009,
      "verified" : false
    }
  },
  "id" : 195267383009624066,
  "created_at" : "2012-04-25 21:45:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sahil",
      "screen_name" : "sahil_m",
      "indices" : [ 3, 11 ],
      "id_str" : "37774518",
      "id" : 37774518
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 94, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195232740487081986",
  "text" : "RT @Sahil_m: @whitehouse As a sophomore in high school, my parents can't afford a rate double #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/extensions\/detail\/encaiiljifbdbjlphpgpiimidegddhic\" rel=\"nofollow\"\u003ESilver Bird\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 81, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195231275483799552",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse As a sophomore in high school, my parents can't afford a rate double #DontDoubleMyRate",
    "id" : 195231275483799552,
    "created_at" : "2012-04-25 19:22:17 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "sahil",
      "screen_name" : "sahil_m",
      "protected" : false,
      "id_str" : "37774518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796219151400521728\/idToozoh_normal.jpg",
      "id" : 37774518,
      "verified" : false
    }
  },
  "id" : 195232740487081986,
  "created_at" : "2012-04-25 19:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 20, 37 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 38, 55 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 56, 73 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 76, 93 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 94, 111 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 112, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195232459720359936",
  "text" : "RT @D_bout_datlyfe: #DontDoubleMyRate #DontDoubleMyRate #DontDoubleMyRate \n #DontDoubleMyRate #DontDoubleMyRate #DontDoubleMyRate http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/D_bout_datlyfe\/status\/195231676627038208\/photo\/1",
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/TCD106xV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ArWaLO6CMAER1PC.jpg",
        "id_str" : "195231676631232513",
        "id" : 195231676631232513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArWaLO6CMAER1PC.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TCD106xV"
      } ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 0, 17 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 18, 35 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 36, 53 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 56, 73 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 74, 91 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195231676627038208",
    "text" : "#DontDoubleMyRate #DontDoubleMyRate #DontDoubleMyRate \n #DontDoubleMyRate #DontDoubleMyRate #DontDoubleMyRate http:\/\/t.co\/TCD106xV",
    "id" : 195231676627038208,
    "created_at" : "2012-04-25 19:23:54 +0000",
    "user" : {
      "name" : "Denise",
      "screen_name" : "IM_THAT_PISCES",
      "protected" : false,
      "id_str" : "243305981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428415509072068610\/19gyD695_normal.jpeg",
      "id" : 243305981,
      "verified" : false
    }
  },
  "id" : 195232459720359936,
  "created_at" : "2012-04-25 19:27:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kam S. Phillips",
      "screen_name" : "kampossible",
      "indices" : [ 3, 15 ],
      "id_str" : "19246993",
      "id" : 19246993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195232396893892609",
  "text" : "RT @kampossible: I stand with the Preezy of the United Steezy when I say, #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 57, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195229037235404800",
    "text" : "I stand with the Preezy of the United Steezy when I say, #DontDoubleMyRate",
    "id" : 195229037235404800,
    "created_at" : "2012-04-25 19:13:24 +0000",
    "user" : {
      "name" : "Kam S. Phillips",
      "screen_name" : "kampossible",
      "protected" : false,
      "id_str" : "19246993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790324131518558208\/S1_Js5ls_normal.jpg",
      "id" : 19246993,
      "verified" : false
    }
  },
  "id" : 195232396893892609,
  "created_at" : "2012-04-25 19:26:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori Livingston",
      "screen_name" : "lorialivingston",
      "indices" : [ 3, 19 ],
      "id_str" : "242748561",
      "id" : 242748561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 47, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/NfRtsSN1",
      "expanded_url" : "http:\/\/yfrog.com\/nxdc4klj",
      "display_url" : "yfrog.com\/nxdc4klj"
    } ]
  },
  "geo" : { },
  "id_str" : "195231014098976768",
  "text" : "RT @lorialivingston: Four kids who Dream Big!  #DontDoubleMyRate http:\/\/t.co\/NfRtsSN1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 26, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/NfRtsSN1",
        "expanded_url" : "http:\/\/yfrog.com\/nxdc4klj",
        "display_url" : "yfrog.com\/nxdc4klj"
      } ]
    },
    "geo" : { },
    "id_str" : "195229861500026881",
    "text" : "Four kids who Dream Big!  #DontDoubleMyRate http:\/\/t.co\/NfRtsSN1",
    "id" : 195229861500026881,
    "created_at" : "2012-04-25 19:16:40 +0000",
    "user" : {
      "name" : "Lori Livingston",
      "screen_name" : "lorialivingston",
      "protected" : false,
      "id_str" : "242748561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765257412341329920\/TbW2LHgB_normal.jpg",
      "id" : 242748561,
      "verified" : false
    }
  },
  "id" : 195231014098976768,
  "created_at" : "2012-04-25 19:21:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kam Earnest",
      "screen_name" : "Kamshafted",
      "indices" : [ 3, 14 ],
      "id_str" : "45930377",
      "id" : 45930377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195229242198458368",
  "text" : "RT @Kamshafted: My wife is going back to school for her masters in social work, we will soon be in a financial crunch. #dontdoublemyrate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 103, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195228726814969856",
    "text" : "My wife is going back to school for her masters in social work, we will soon be in a financial crunch. #dontdoublemyrate",
    "id" : 195228726814969856,
    "created_at" : "2012-04-25 19:12:10 +0000",
    "user" : {
      "name" : "Kam Earnest",
      "screen_name" : "Kamshafted",
      "protected" : false,
      "id_str" : "45930377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000868047289\/5m_E62K-_normal.jpeg",
      "id" : 45930377,
      "verified" : false
    }
  },
  "id" : 195229242198458368,
  "created_at" : "2012-04-25 19:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dawn",
      "screen_name" : "dawnbreeden",
      "indices" : [ 3, 15 ],
      "id_str" : "73460805",
      "id" : 73460805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195229141451276288",
  "text" : "RT @dawnbreeden: Getting my master's in social work to serve those in hospitals with case mgmt to lower the cost of healthcare. #Dontdou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dontdoublemyrate",
        "indices" : [ 111, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195228639376314368",
    "text" : "Getting my master's in social work to serve those in hospitals with case mgmt to lower the cost of healthcare. #Dontdoublemyrate",
    "id" : 195228639376314368,
    "created_at" : "2012-04-25 19:11:49 +0000",
    "user" : {
      "name" : "dawn",
      "screen_name" : "dawnbreeden",
      "protected" : false,
      "id_str" : "73460805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2289954857\/image_normal.jpg",
      "id" : 73460805,
      "verified" : false
    }
  },
  "id" : 195229141451276288,
  "created_at" : "2012-04-25 19:13:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncommon Renee",
      "screen_name" : "hollywood_ace",
      "indices" : [ 3, 17 ],
      "id_str" : "38103965",
      "id" : 38103965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195227743162601472",
  "text" : "RT @hollywood_ace: Obama is completely right on student loans and higher education. This should not be a partisan issue #dontdoublemyrate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 101, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195227110909018113",
    "text" : "Obama is completely right on student loans and higher education. This should not be a partisan issue #dontdoublemyrate",
    "id" : 195227110909018113,
    "created_at" : "2012-04-25 19:05:45 +0000",
    "user" : {
      "name" : "Uncommon Renee",
      "screen_name" : "hollywood_ace",
      "protected" : false,
      "id_str" : "38103965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000398926989\/22eca97cfbb04a31da0e2061bee0ba28_normal.jpeg",
      "id" : 38103965,
      "verified" : false
    }
  },
  "id" : 195227743162601472,
  "created_at" : "2012-04-25 19:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dontdoublemyrate",
      "indices" : [ 104, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195226254255996928",
  "text" : "RT @arneduncan: No, but we can't let Stafford loan interest rates double. Congress must act by Jul 1st. #Dontdoublemyrate http:\/\/t.co\/9F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dontdoublemyrate",
        "indices" : [ 88, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/9FVpq4nh",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/dont-double-my-rates",
        "display_url" : "whitehouse.gov\/dont-double-my\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "195219521143963651",
    "text" : "No, but we can't let Stafford loan interest rates double. Congress must act by Jul 1st. #Dontdoublemyrate http:\/\/t.co\/9FVpq4nh",
    "id" : 195219521143963651,
    "created_at" : "2012-04-25 18:35:35 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 195226254255996928,
  "created_at" : "2012-04-25 19:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195225862268928001",
  "text" : "RT @FHSUBudd: I'm a hard working student, pursuing my dream and hope to never ask the government for welfare, so congress, #dontdoublemyrate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 109, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195222101823733760",
    "text" : "I'm a hard working student, pursuing my dream and hope to never ask the government for welfare, so congress, #dontdoublemyrate",
    "id" : 195222101823733760,
    "created_at" : "2012-04-25 18:45:50 +0000",
    "user" : {
      "name" : "Nick Budd",
      "screen_name" : "KWCHBudd",
      "protected" : false,
      "id_str" : "308932610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609187617972748288\/C2WBK272_normal.jpg",
      "id" : 308932610,
      "verified" : false
    }
  },
  "id" : 195225862268928001,
  "created_at" : "2012-04-25 19:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Seidler",
      "screen_name" : "eeseidler",
      "indices" : [ 3, 13 ],
      "id_str" : "17900051",
      "id" : 17900051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 103, 120 ]
    }, {
      "text" : "ObamaatUI",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195224970262089730",
  "text" : "RT @eeseidler: 255,000 Iowans would be affected if Congress doesn't act on student loan interest rates #DontDoubleMyRate #ObamaatUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 88, 105 ]
      }, {
        "text" : "ObamaatUI",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195224091303755776",
    "text" : "255,000 Iowans would be affected if Congress doesn't act on student loan interest rates #DontDoubleMyRate #ObamaatUI",
    "id" : 195224091303755776,
    "created_at" : "2012-04-25 18:53:45 +0000",
    "user" : {
      "name" : "Erin Seidler",
      "screen_name" : "eeseidler",
      "protected" : false,
      "id_str" : "17900051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623293035489591296\/Dme3BJuF_normal.jpg",
      "id" : 17900051,
      "verified" : false
    }
  },
  "id" : 195224970262089730,
  "created_at" : "2012-04-25 18:57:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edith Gaitho",
      "screen_name" : "MonroeG5",
      "indices" : [ 3, 12 ],
      "id_str" : "407357774",
      "id" : 407357774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195224856143474688",
  "text" : "RT @MonroeG5: President Obama: \"America is not about a few people doing well. America is about giving everybody the chance to do well. # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 121, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195224271281332224",
    "text" : "President Obama: \"America is not about a few people doing well. America is about giving everybody the chance to do well. #DontDoubleMyRate",
    "id" : 195224271281332224,
    "created_at" : "2012-04-25 18:54:28 +0000",
    "user" : {
      "name" : "Edith Gaitho",
      "screen_name" : "MonroeG5",
      "protected" : false,
      "id_str" : "407357774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757146017632362496\/nB8aL6yc_normal.jpg",
      "id" : 407357774,
      "verified" : false
    }
  },
  "id" : 195224856143474688,
  "created_at" : "2012-04-25 18:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 17, 24 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 52, 63 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "GradStartup",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195198296900374528",
  "text" : "Today @ 2pm EDT: @SBAGov Admin Karen Mills & Sec Ed @ArneDuncan hold a Twitter Q&A on #smallbiz opps & recent grads. Ask ? w\/ #GradStartup",
  "id" : 195198296900374528,
  "created_at" : "2012-04-25 17:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/IRq8m78D",
      "expanded_url" : "http:\/\/wh.gov\/PHO",
      "display_url" : "wh.gov\/PHO"
    } ]
  },
  "geo" : { },
  "id_str" : "195172995168346114",
  "text" : "For the victims of today & to protect future generations: Why we must strengthen the Violence Against Women Act: http:\/\/t.co\/IRq8m78D #VAWA",
  "id" : 195172995168346114,
  "created_at" : "2012-04-25 15:30:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 74, 86 ],
      "id_str" : "15485441",
      "id" : 15485441
    }, {
      "name" : "The Roots",
      "screen_name" : "theroots",
      "indices" : [ 89, 98 ],
      "id_str" : "158777509",
      "id" : 158777509
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 12, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/H3NFkpF6",
      "expanded_url" : "http:\/\/ow.ly\/avBOJ",
      "display_url" : "ow.ly\/avBOJ"
    } ]
  },
  "geo" : { },
  "id_str" : "195161746523176960",
  "text" : "Awwww yeah! #DontDoubleMyRate slow-jammed by the \"POTUS with the Mostest\" @JimmyFallon & @TheRoots WATCH: http:\/\/t.co\/H3NFkpF6",
  "id" : 195161746523176960,
  "created_at" : "2012-04-25 14:46:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRates",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/Cvszd1Y5",
      "expanded_url" : "http:\/\/wh.gov\/double",
      "display_url" : "wh.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "195022522838814720",
  "text" : "If Congress doesn't act by July 1, more than 7.4M students will see their interest rates double: http:\/\/t.co\/Cvszd1Y5 #DontDoubleMyRates",
  "id" : 195022522838814720,
  "created_at" : "2012-04-25 05:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krista F.",
      "screen_name" : "kristafir",
      "indices" : [ 3, 13 ],
      "id_str" : "21551382",
      "id" : 21551382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrates",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195020599054176257",
  "text" : "RT @kristafir: Congress, I'm about to graduate college. The job market is already rough. Don't make things worse and #dontdoublemyrates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrates",
        "indices" : [ 102, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "195020302877597696",
    "text" : "Congress, I'm about to graduate college. The job market is already rough. Don't make things worse and #dontdoublemyrates",
    "id" : 195020302877597696,
    "created_at" : "2012-04-25 05:23:58 +0000",
    "user" : {
      "name" : "Krista F.",
      "screen_name" : "kristafir",
      "protected" : false,
      "id_str" : "21551382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769995201523884032\/WAOnI6bC_normal.jpg",
      "id" : 21551382,
      "verified" : false
    }
  },
  "id" : 195020599054176257,
  "created_at" : "2012-04-25 05:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/Cvszd1Y5",
      "expanded_url" : "http:\/\/wh.gov\/double",
      "display_url" : "wh.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "195014772167688193",
  "text" : "President Obama: \"Tell [Congress] now is not the time to double interest rates on your student loans\" http:\/\/t.co\/Cvszd1Y5 #DontDoubleMyRate",
  "id" : 195014772167688193,
  "created_at" : "2012-04-25 05:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaonFallon",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 83, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195012523827793920",
  "text" : "#ObamaonFallon now: \"I'm President Barack Obama & I too want to Slow Jam the News\" #DontDoubleMyRate",
  "id" : 195012523827793920,
  "created_at" : "2012-04-25 04:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 37, 49 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 101, 118 ]
    }, {
      "text" : "ObamaonFallon",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "195011640918409218",
  "text" : "Happening now: President Obama is on @jimmyfallon from UNC. Watch the President Slow Jam the News on #DontDoubleMyRate. #ObamaonFallon",
  "id" : 195011640918409218,
  "created_at" : "2012-04-25 04:49:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/DZsAtSqS",
      "expanded_url" : "http:\/\/youtu.be\/Azn5Aq_7d9s",
      "display_url" : "youtu.be\/Azn5Aq_7d9s"
    } ]
  },
  "geo" : { },
  "id_str" : "194984622352891904",
  "text" : "WATCH: President Obama calls on students to tell Congress #DontDoubleMyRate: http:\/\/t.co\/DZsAtSqS [RT if you agree]",
  "id" : 194984622352891904,
  "created_at" : "2012-04-25 03:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Carroll",
      "screen_name" : "algal03",
      "indices" : [ 3, 11 ],
      "id_str" : "240449707",
      "id" : 240449707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 13, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194978213812899840",
  "text" : "RT @algal03: #dontdoublemyrate but get me a sink burger ASAP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194977896987758593",
    "text" : "#dontdoublemyrate but get me a sink burger ASAP",
    "id" : 194977896987758593,
    "created_at" : "2012-04-25 02:35:27 +0000",
    "user" : {
      "name" : "Alex Carroll",
      "screen_name" : "algal03",
      "protected" : false,
      "id_str" : "240449707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2656256772\/797801a21d485822c5aec192d56a6e0f_normal.png",
      "id" : 240449707,
      "verified" : false
    }
  },
  "id" : 194978213812899840,
  "created_at" : "2012-04-25 02:36:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Chaney",
      "screen_name" : "JDonChaney",
      "indices" : [ 3, 14 ],
      "id_str" : "461431987",
      "id" : 461431987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dontdoublemyrate",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194977276880883712",
  "text" : "RT @JDonChaney: Students need to let their voices be heard and stand up for this incredibly important issue #Dontdoublemyrate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dontdoublemyrate",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194976909317255168",
    "text" : "Students need to let their voices be heard and stand up for this incredibly important issue #Dontdoublemyrate",
    "id" : 194976909317255168,
    "created_at" : "2012-04-25 02:31:32 +0000",
    "user" : {
      "name" : "Don Chaney",
      "screen_name" : "JDonChaney",
      "protected" : false,
      "id_str" : "461431987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460788024092008448\/X-Uscuar_normal.jpeg",
      "id" : 461431987,
      "verified" : false
    }
  },
  "id" : 194977276880883712,
  "created_at" : "2012-04-25 02:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard A. Fowler",
      "screen_name" : "Richardafowler",
      "indices" : [ 3, 18 ],
      "id_str" : "52751069",
      "id" : 52751069
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 93, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194971853482246144",
  "text" : "RT @Richardafowler: If we are supposed to be the future, why are we drowning in student debt #dontdoublemyrate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 73, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194971680039383041",
    "text" : "If we are supposed to be the future, why are we drowning in student debt #dontdoublemyrate",
    "id" : 194971680039383041,
    "created_at" : "2012-04-25 02:10:45 +0000",
    "user" : {
      "name" : "Richard A. Fowler",
      "screen_name" : "Richardafowler",
      "protected" : false,
      "id_str" : "52751069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529717462938312704\/sx_GB9Sq_normal.jpeg",
      "id" : 52751069,
      "verified" : false
    }
  },
  "id" : 194971853482246144,
  "created_at" : "2012-04-25 02:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Jermaine",
      "screen_name" : "SaintJermaine",
      "indices" : [ 3, 17 ],
      "id_str" : "198690973",
      "id" : 198690973
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194969960647372800",
  "text" : "RT @SaintJermaine: @whitehouse I'm a Junior at NYU. I want to work in public service but I already have debt over 100k. Thank you 4 cari ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 121, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194969618010480640",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I'm a Junior at NYU. I want to work in public service but I already have debt over 100k. Thank you 4 caring. #DontDoubleMyRate",
    "id" : 194969618010480640,
    "created_at" : "2012-04-25 02:02:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Saint Jermaine",
      "screen_name" : "SaintJermaine",
      "protected" : false,
      "id_str" : "198690973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2157840171\/jigga_normal",
      "id" : 198690973,
      "verified" : false
    }
  },
  "id" : 194969960647372800,
  "created_at" : "2012-04-25 02:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David LaRose",
      "screen_name" : "David_LaRose",
      "indices" : [ 3, 16 ],
      "id_str" : "30979533",
      "id" : 30979533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194969704702558208",
  "text" : "RT @David_LaRose: Obama asks CU to let their voice be heard and to stand up for themselves, especially the students #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 98, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194969384349999104",
    "text" : "Obama asks CU to let their voice be heard and to stand up for themselves, especially the students #DontDoubleMyRate",
    "id" : 194969384349999104,
    "created_at" : "2012-04-25 02:01:38 +0000",
    "user" : {
      "name" : "David LaRose",
      "screen_name" : "David_LaRose",
      "protected" : false,
      "id_str" : "30979533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761419794583216132\/XE_PzjKp_normal.jpg",
      "id" : 30979533,
      "verified" : false
    }
  },
  "id" : 194969704702558208,
  "created_at" : "2012-04-25 02:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Jared Polis)))",
      "screen_name" : "jaredpolis",
      "indices" : [ 3, 14 ],
      "id_str" : "15361570",
      "id" : 15361570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 92, 109 ]
    }, {
      "text" : "ObamaCU",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/kAnTkADW",
      "expanded_url" : "http:\/\/polis.house.gov\/News\/DocumentSingle.aspx?DocumentID=292286",
      "display_url" : "polis.house.gov\/News\/DocumentS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194968237207851010",
  "text" : "RT @jaredpolis: I support Obama's plan to make college more affordable http:\/\/t.co\/kAnTkADW\n#DontDoubleMyRate #ObamaCU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 76, 93 ]
      }, {
        "text" : "ObamaCU",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/kAnTkADW",
        "expanded_url" : "http:\/\/polis.house.gov\/News\/DocumentSingle.aspx?DocumentID=292286",
        "display_url" : "polis.house.gov\/News\/DocumentS\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "194967947939295232",
    "text" : "I support Obama's plan to make college more affordable http:\/\/t.co\/kAnTkADW\n#DontDoubleMyRate #ObamaCU",
    "id" : 194967947939295232,
    "created_at" : "2012-04-25 01:55:55 +0000",
    "user" : {
      "name" : "(((Jared Polis)))",
      "screen_name" : "jaredpolis",
      "protected" : false,
      "id_str" : "15361570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752314449206341633\/SoUVQR8U_normal.jpg",
      "id" : 15361570,
      "verified" : true
    }
  },
  "id" : 194968237207851010,
  "created_at" : "2012-04-25 01:57:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 60, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194966996767604736",
  "text" : "\"Send your Member of Congress of message... use the hashtag #DontDoubleMyRate\" -President Obama",
  "id" : 194966996767604736,
  "created_at" : "2012-04-25 01:52:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/DRupoYVd",
      "expanded_url" : "http:\/\/bit.ly\/IDSWQ2",
      "display_url" : "bit.ly\/IDSWQ2"
    } ]
  },
  "geo" : { },
  "id_str" : "194966866077290499",
  "text" : "RT @UncleRUSH: Check it out! Why Obama's push on student loans is critical for college students &gt;&gt; http:\/\/t.co\/DRupoYVd -- #DontDo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 114, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/DRupoYVd",
        "expanded_url" : "http:\/\/bit.ly\/IDSWQ2",
        "display_url" : "bit.ly\/IDSWQ2"
      } ]
    },
    "geo" : { },
    "id_str" : "194944045552898048",
    "text" : "Check it out! Why Obama's push on student loans is critical for college students &gt;&gt; http:\/\/t.co\/DRupoYVd -- #DontDoubleMyRate",
    "id" : 194944045552898048,
    "created_at" : "2012-04-25 00:20:57 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 194966866077290499,
  "created_at" : "2012-04-25 01:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194966431333490688",
  "text" : "President Obama: \u201C'Set your sights lower' is not an education plan. 'You\u2019re on your own' is not an economic plan\" #DontDoubleMyRate",
  "id" : 194966431333490688,
  "created_at" : "2012-04-25 01:49:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194964457372393474",
  "text" : "Obama: \"For each year Congress doesn\u2019t act, the average student w\/ these loans will rack up an additional $1,000 in debt\" #DontDoubleMyRate",
  "id" : 194964457372393474,
  "created_at" : "2012-04-25 01:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194964222952747009",
  "text" : "Obama: Congress needs to \"prevent the interest rates on federal student loans from shooting up &amp; shaking you down\" #DontDoubleMyRate",
  "id" : 194964222952747009,
  "created_at" : "2012-04-25 01:41:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 86, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194963788716445697",
  "text" : "President Obama: \"Colleges and universities need to do their part to keep costs down\" #DontDoubleMyRate Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 194963788716445697,
  "created_at" : "2012-04-25 01:39:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194962889050820609",
  "text" : "RT @WHLive: President Obama: \"We cannot price the middle class out of a college education\" #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 79, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194962769748037632",
    "text" : "President Obama: \"We cannot price the middle class out of a college education\" #DontDoubleMyRate",
    "id" : 194962769748037632,
    "created_at" : "2012-04-25 01:35:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194962889050820609,
  "created_at" : "2012-04-25 01:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 93, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194962616005832705",
  "text" : "\"So we have to make college more affordable for you\" -President Obama to CU-Boulder students #DontDoubleMyRate",
  "id" : 194962616005832705,
  "created_at" : "2012-04-25 01:34:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194962109921116161",
  "text" : "President Obama: \"Americans now owe more on their student loans than they do on their credit cards\" #DontDoubleMyRate",
  "id" : 194962109921116161,
  "created_at" : "2012-04-25 01:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 108, 115 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 40, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194958971398922241",
  "text" : "Starting now: President Obama speaks on #DontDoubleMyRate @ CU-Boulder. Watch: http:\/\/t.co\/hhNoX4fh Follow: @WHLive",
  "id" : 194958971398922241,
  "created_at" : "2012-04-25 01:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ASCSU President",
      "screen_name" : "ASCSUPresident",
      "indices" : [ 3, 18 ],
      "id_str" : "336784054",
      "id" : 336784054
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamaatcu",
      "indices" : [ 76, 86 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 87, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194953444870729728",
  "text" : "RT @ASCSUPresident: Press motorcade just arrived in the Coors Event Center. #obamaatcu #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "obamaatcu",
        "indices" : [ 56, 66 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 67, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194953048039239680",
    "text" : "Press motorcade just arrived in the Coors Event Center. #obamaatcu #DontDoubleMyRate",
    "id" : 194953048039239680,
    "created_at" : "2012-04-25 00:56:43 +0000",
    "user" : {
      "name" : "ASCSU President",
      "screen_name" : "ASCSUPresident",
      "protected" : false,
      "id_str" : "336784054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416413204760113153\/JBBaO2_1_normal.jpeg",
      "id" : 336784054,
      "verified" : false
    }
  },
  "id" : 194953444870729728,
  "created_at" : "2012-04-25 00:58:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 106, 113 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 37, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194950032955412480",
  "text" : "Starting soon: President Obama talks #DontDoubleMyRate at CU-Boulder. Watch: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 194950032955412480,
  "created_at" : "2012-04-25 00:44:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colorado Buffaloes",
      "screen_name" : "cubuffs",
      "indices" : [ 3, 11 ],
      "id_str" : "10828932",
      "id" : 10828932
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 81, 93 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194947940874321920",
  "text" : "RT @cubuffs: A special welcome from the University of Colorado to our President, @BarackObama, who is coming to speak later this afterno ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 68, 80 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USA",
        "indices" : [ 126, 130 ]
      }, {
        "text" : "GOBUFFS",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194803041633968128",
    "text" : "A special welcome from the University of Colorado to our President, @BarackObama, who is coming to speak later this afternoon #USA #GOBUFFS",
    "id" : 194803041633968128,
    "created_at" : "2012-04-24 15:00:39 +0000",
    "user" : {
      "name" : "Colorado Buffaloes",
      "screen_name" : "cubuffs",
      "protected" : false,
      "id_str" : "10828932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647826170059198464\/YbQYeyKQ_normal.jpg",
      "id" : 10828932,
      "verified" : true
    }
  },
  "id" : 194947940874321920,
  "created_at" : "2012-04-25 00:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 97, 109 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/194923348428455936\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/om0dnn2E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArSBwK4CAAAvEgI.jpg",
      "id_str" : "194923348436844544",
      "id" : 194923348436844544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArSBwK4CAAAvEgI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/om0dnn2E"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 68, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194923348428455936",
  "text" : "Don't miss President Obama Slow Jam the News on student loans &amp; #DontDoubleMyRate tonight on @jimmyfallon: http:\/\/t.co\/om0dnn2E",
  "id" : 194923348428455936,
  "created_at" : "2012-04-24 22:58:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/DZsAtSqS",
      "expanded_url" : "http:\/\/youtu.be\/Azn5Aq_7d9s",
      "display_url" : "youtu.be\/Azn5Aq_7d9s"
    } ]
  },
  "geo" : { },
  "id_str" : "194887998976958464",
  "text" : "\"Tell [Congress] now is not the time to double interest rates on your student loans\" -President Obama http:\/\/t.co\/DZsAtSqS #DontDoubleMyRate",
  "id" : 194887998976958464,
  "created_at" : "2012-04-24 20:38:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 26, 38 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194878981793787906",
  "text" : "RT @pfeiffer44: Tune into @jimmyfallon tonight to watch President Obama Slow Jam the News on student loan interest rates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jimmy fallon",
        "screen_name" : "jimmyfallon",
        "indices" : [ 10, 22 ],
        "id_str" : "15485441",
        "id" : 15485441
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194877041605214208",
    "text" : "Tune into @jimmyfallon tonight to watch President Obama Slow Jam the News on student loan interest rates",
    "id" : 194877041605214208,
    "created_at" : "2012-04-24 19:54:42 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 194878981793787906,
  "created_at" : "2012-04-24 20:02:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/LpfTaLlR",
      "expanded_url" : "http:\/\/youtu.be\/_TcVs9wnZlo",
      "display_url" : "youtu.be\/_TcVs9wnZlo"
    } ]
  },
  "geo" : { },
  "id_str" : "194876739443359744",
  "text" : "VIDEO: President Obama calls on students to tell Congress #DontDoubleMyRate: http:\/\/t.co\/LpfTaLlR",
  "id" : 194876739443359744,
  "created_at" : "2012-04-24 19:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 3, 15 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaOnFallon",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194873694219284482",
  "text" : "RT @jimmyfallon: The President has left the building. This has been one of the most exciting things I've ever done. #ObamaOnFallon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaOnFallon",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194867084231049216",
    "text" : "The President has left the building. This has been one of the most exciting things I've ever done. #ObamaOnFallon",
    "id" : 194867084231049216,
    "created_at" : "2012-04-24 19:15:07 +0000",
    "user" : {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "protected" : false,
      "id_str" : "15485441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1194467116\/new-resize-square_normal.jpg",
      "id" : 15485441,
      "verified" : true
    }
  },
  "id" : 194873694219284482,
  "created_at" : "2012-04-24 19:41:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mabrey",
      "screen_name" : "Maybrad",
      "indices" : [ 0, 8 ],
      "id_str" : "179305845",
      "id" : 179305845
    }, {
      "name" : "Laurie CarlCyborg",
      "screen_name" : "DrcyborgL",
      "indices" : [ 9, 19 ],
      "id_str" : "465249142",
      "id" : 465249142
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 98, 106 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 53, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/fmZfZ1oZ",
      "expanded_url" : "http:\/\/sfy.co\/qTH",
      "display_url" : "sfy.co\/qTH"
    } ]
  },
  "geo" : { },
  "id_str" : "194864017485991936",
  "in_reply_to_user_id" : 179305845,
  "text" : "@Maybrad @DrcyborgL Thanks for raising your voice on #DontDoubleMyRate. You've been quoted in our @Storify story: http:\/\/t.co\/fmZfZ1oZ",
  "id" : 194864017485991936,
  "created_at" : "2012-04-24 19:02:56 +0000",
  "in_reply_to_screen_name" : "Maybrad",
  "in_reply_to_user_id_str" : "179305845",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fehmann",
      "screen_name" : "fehmann",
      "indices" : [ 0, 8 ],
      "id_str" : "11763482",
      "id" : 11763482
    }, {
      "name" : "Kristen Olmi",
      "screen_name" : "KristenOlmi",
      "indices" : [ 9, 21 ],
      "id_str" : "62610569",
      "id" : 62610569
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 100, 108 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 55, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/fmZfZ1oZ",
      "expanded_url" : "http:\/\/sfy.co\/qTH",
      "display_url" : "sfy.co\/qTH"
    } ]
  },
  "geo" : { },
  "id_str" : "194863752896720896",
  "in_reply_to_user_id" : 11763482,
  "text" : "@fehmann @KristenOlmi Thanks for raising your voice on #DontDoubleMyRate. You've been quoted in our @Storify story: http:\/\/t.co\/fmZfZ1oZ",
  "id" : 194863752896720896,
  "created_at" : "2012-04-24 19:01:53 +0000",
  "in_reply_to_screen_name" : "fehmann",
  "in_reply_to_user_id_str" : "11763482",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Fitt",
      "screen_name" : "mattfittipaldi",
      "indices" : [ 3, 18 ],
      "id_str" : "227127646",
      "id" : 227127646
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 20, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194855108176130048",
  "text" : "RT @mattfittipaldi: #DontDoubleMyRate every single young person in America should care about this",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194854754902482944",
    "text" : "#DontDoubleMyRate every single young person in America should care about this",
    "id" : 194854754902482944,
    "created_at" : "2012-04-24 18:26:08 +0000",
    "user" : {
      "name" : "Matt Fitt",
      "screen_name" : "mattfittipaldi",
      "protected" : false,
      "id_str" : "227127646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795132124462510080\/Bn_ZB1KY_normal.jpg",
      "id" : 227127646,
      "verified" : false
    }
  },
  "id" : 194855108176130048,
  "created_at" : "2012-04-24 18:27:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellie Bennett",
      "screen_name" : "Kellie_Bennett",
      "indices" : [ 3, 18 ],
      "id_str" : "284634406",
      "id" : 284634406
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 20, 32 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kellie_Bennett\/status\/194847702339690496\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/AOMG1jWh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArQ88_OCIAAKf03.jpg",
      "id_str" : "194847702343884800",
      "id" : 194847702343884800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArQ88_OCIAAKf03.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/AOMG1jWh"
    } ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 55, 72 ]
    }, {
      "text" : "obamaUNC",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194853145606762496",
  "text" : "RT @Kellie_Bennett: @barackobama it's already trending #dontdoublemyrate #obamaUNC!! http:\/\/t.co\/AOMG1jWh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kellie_Bennett\/status\/194847702339690496\/photo\/1",
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/AOMG1jWh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ArQ88_OCIAAKf03.jpg",
        "id_str" : "194847702343884800",
        "id" : 194847702343884800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArQ88_OCIAAKf03.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/AOMG1jWh"
      } ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 35, 52 ]
      }, {
        "text" : "obamaUNC",
        "indices" : [ 53, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194847702339690496",
    "in_reply_to_user_id" : 813286,
    "text" : "@barackobama it's already trending #dontdoublemyrate #obamaUNC!! http:\/\/t.co\/AOMG1jWh",
    "id" : 194847702339690496,
    "created_at" : "2012-04-24 17:58:07 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Kellie Bennett",
      "screen_name" : "Kellie_Bennett",
      "protected" : false,
      "id_str" : "284634406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2951262739\/8e8128cf6662e2d504db85d8d15ac264_normal.jpeg",
      "id" : 284634406,
      "verified" : false
    }
  },
  "id" : 194853145606762496,
  "created_at" : "2012-04-24 18:19:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "indices" : [ 3, 13 ],
      "id_str" : "22012091",
      "id" : 22012091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 98, 115 ]
    }, {
      "text" : "ObamaUNC",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194850327504228352",
  "text" : "RT @WhipHoyer: We can\u2019t saddle our students with more debt if we want to keep America competitive #DontDoubleMyRate #ObamaUNC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 83, 100 ]
      }, {
        "text" : "ObamaUNC",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194848083077644288",
    "text" : "We can\u2019t saddle our students with more debt if we want to keep America competitive #DontDoubleMyRate #ObamaUNC",
    "id" : 194848083077644288,
    "created_at" : "2012-04-24 17:59:37 +0000",
    "user" : {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "protected" : false,
      "id_str" : "22012091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742490369347203072\/WLvGn-ia_normal.jpg",
      "id" : 22012091,
      "verified" : true
    }
  },
  "id" : 194850327504228352,
  "created_at" : "2012-04-24 18:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/194849310838489088\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/ZlmRcsFC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArQ-anWCAAAUWsJ.jpg",
      "id_str" : "194849310842683392",
      "id" : 194849310842683392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArQ-anWCAAAUWsJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/ZlmRcsFC"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 7, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/Cvszd1Y5",
      "expanded_url" : "http:\/\/wh.gov\/double",
      "display_url" : "wh.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "194849310838489088",
  "text" : "Why is #DontDoubleMyRate trending? http:\/\/t.co\/Cvszd1Y5 http:\/\/t.co\/ZlmRcsFC",
  "id" : 194849310838489088,
  "created_at" : "2012-04-24 18:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pema Levy",
      "screen_name" : "pemalevy",
      "indices" : [ 3, 12 ],
      "id_str" : "61127668",
      "id" : 61127668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 73, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194848956260433920",
  "text" : "RT @pemalevy: Obama just got thousands of students to repeat the hashtag #dontdoublemyrate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 59, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194844744755585025",
    "text" : "Obama just got thousands of students to repeat the hashtag #dontdoublemyrate",
    "id" : 194844744755585025,
    "created_at" : "2012-04-24 17:46:21 +0000",
    "user" : {
      "name" : "Pema Levy",
      "screen_name" : "pemalevy",
      "protected" : false,
      "id_str" : "61127668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587029223186903040\/bVK3wDfa_normal.jpg",
      "id" : 61127668,
      "verified" : true
    }
  },
  "id" : 194848956260433920,
  "created_at" : "2012-04-24 18:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Cheek",
      "screen_name" : "Bruce_Cheek",
      "indices" : [ 3, 15 ],
      "id_str" : "210566282",
      "id" : 210566282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 106, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194848869253779457",
  "text" : "RT @Bruce_Cheek: If Congress doesn\u2019t act, interest rates on Stafford student loans will double on July 1. #DontDoubleMyRate http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 89, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/StD8xSNZ",
        "expanded_url" : "http:\/\/wh.gov\/double",
        "display_url" : "wh.gov\/double"
      } ]
    },
    "geo" : { },
    "id_str" : "194848492429115392",
    "text" : "If Congress doesn\u2019t act, interest rates on Stafford student loans will double on July 1. #DontDoubleMyRate http:\/\/t.co\/StD8xSNZ",
    "id" : 194848492429115392,
    "created_at" : "2012-04-24 18:01:15 +0000",
    "user" : {
      "name" : "Bruce Cheek",
      "screen_name" : "Bruce_Cheek",
      "protected" : false,
      "id_str" : "210566282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2657522220\/467177fb36676aa2ec2366277d2845d5_normal.png",
      "id" : 210566282,
      "verified" : false
    }
  },
  "id" : 194848869253779457,
  "created_at" : "2012-04-24 18:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruben Gallego",
      "screen_name" : "RubenGallego",
      "indices" : [ 3, 16 ],
      "id_str" : "49217025",
      "id" : 49217025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 60, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194848752769572864",
  "text" : "RT @RubenGallego: I graduated eight years ago. Still paying #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 42, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194848447302615040",
    "text" : "I graduated eight years ago. Still paying #DontDoubleMyRate",
    "id" : 194848447302615040,
    "created_at" : "2012-04-24 18:01:04 +0000",
    "user" : {
      "name" : "Ruben Gallego",
      "screen_name" : "RubenGallego",
      "protected" : false,
      "id_str" : "49217025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/274085344\/picture2_normal.jpg",
      "id" : 49217025,
      "verified" : false
    }
  },
  "id" : 194848752769572864,
  "created_at" : "2012-04-24 18:02:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randall Tinkess",
      "screen_name" : "tinkess",
      "indices" : [ 3, 11 ],
      "id_str" : "23632690",
      "id" : 23632690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 13, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194847434302685184",
  "text" : "RT @tinkess: #DontDoubleMyRate Where does your member of Congress stand? Let everyone know.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194847118643568642",
    "text" : "#DontDoubleMyRate Where does your member of Congress stand? Let everyone know.",
    "id" : 194847118643568642,
    "created_at" : "2012-04-24 17:55:47 +0000",
    "user" : {
      "name" : "Randall Tinkess",
      "screen_name" : "tinkess",
      "protected" : false,
      "id_str" : "23632690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586187705232465920\/Umfb40uL_normal.jpg",
      "id" : 23632690,
      "verified" : false
    }
  },
  "id" : 194847434302685184,
  "created_at" : "2012-04-24 17:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/J9ASgm3s",
      "expanded_url" : "http:\/\/whitehouse.gov\/double",
      "display_url" : "whitehouse.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "194846556321615873",
  "text" : "#DontDoubleMyRate is now trending worldwide. Keep it up. http:\/\/t.co\/J9ASgm3s",
  "id" : 194846556321615873,
  "created_at" : "2012-04-24 17:53:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jndtech",
      "screen_name" : "jndtech",
      "indices" : [ 3, 11 ],
      "id_str" : "134162905",
      "id" : 134162905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 102, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/sWWfDObu",
      "expanded_url" : "http:\/\/wh.gov\/double",
      "display_url" : "wh.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "194845603077955585",
  "text" : "RT @jndtech: If Congress doesn\u2019t act, interest rates on Stafford student loans will double on July 1. #DontDoubleMyRate http:\/\/t.co\/sWWfDObu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 89, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/sWWfDObu",
        "expanded_url" : "http:\/\/wh.gov\/double",
        "display_url" : "wh.gov\/double"
      } ]
    },
    "geo" : { },
    "id_str" : "194844990424350720",
    "text" : "If Congress doesn\u2019t act, interest rates on Stafford student loans will double on July 1. #DontDoubleMyRate http:\/\/t.co\/sWWfDObu",
    "id" : 194844990424350720,
    "created_at" : "2012-04-24 17:47:20 +0000",
    "user" : {
      "name" : "jndtech",
      "screen_name" : "jndtech",
      "protected" : false,
      "id_str" : "134162905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791490105068363776\/79pRl_CF_normal.jpg",
      "id" : 134162905,
      "verified" : false
    }
  },
  "id" : 194845603077955585,
  "created_at" : "2012-04-24 17:49:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Byrd",
      "screen_name" : "stevendbyrd",
      "indices" : [ 3, 15 ],
      "id_str" : "56884841",
      "id" : 56884841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/KJOLrkTb",
      "expanded_url" : "http:\/\/wh.gov\/double",
      "display_url" : "wh.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "194845221048172546",
  "text" : "RT @stevendbyrd: WH website on Stafford loan issue: #DontDoubleMyRate http:\/\/t.co\/KJOLrkTb Great interactive map",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 35, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/KJOLrkTb",
        "expanded_url" : "http:\/\/wh.gov\/double",
        "display_url" : "wh.gov\/double"
      } ]
    },
    "geo" : { },
    "id_str" : "194844724375457792",
    "text" : "WH website on Stafford loan issue: #DontDoubleMyRate http:\/\/t.co\/KJOLrkTb Great interactive map",
    "id" : 194844724375457792,
    "created_at" : "2012-04-24 17:46:16 +0000",
    "user" : {
      "name" : "Steven Byrd",
      "screen_name" : "stevendbyrd",
      "protected" : false,
      "id_str" : "56884841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759919458206875648\/kekCSQHo_normal.jpg",
      "id" : 56884841,
      "verified" : false
    }
  },
  "id" : 194845221048172546,
  "created_at" : "2012-04-24 17:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeanette Cordova",
      "screen_name" : "CordovaJeanette",
      "indices" : [ 3, 19 ],
      "id_str" : "306824452",
      "id" : 306824452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 110, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194844744646541312",
  "text" : "RT @CordovaJeanette: If Congress doesn\u2019t act, interest rates on Stafford student loans will double on July 1. #DontDoubleMyRate http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 89, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/6zo6IKyE",
        "expanded_url" : "http:\/\/wh.gov\/double",
        "display_url" : "wh.gov\/double"
      } ]
    },
    "geo" : { },
    "id_str" : "194844078679142401",
    "text" : "If Congress doesn\u2019t act, interest rates on Stafford student loans will double on July 1. #DontDoubleMyRate http:\/\/t.co\/6zo6IKyE",
    "id" : 194844078679142401,
    "created_at" : "2012-04-24 17:43:43 +0000",
    "user" : {
      "name" : "Jeanette Cordova",
      "screen_name" : "CordovaJeanette",
      "protected" : false,
      "id_str" : "306824452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791435049224724480\/oYirONvp_normal.jpg",
      "id" : 306824452,
      "verified" : false
    }
  },
  "id" : 194844744646541312,
  "created_at" : "2012-04-24 17:46:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 105, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194844637805031424",
  "text" : "President Obama: \"I need you to tell your Member of Congress...Here's the hashtag for you to tweet them: #DontDoubleMyRate\"",
  "id" : 194844637805031424,
  "created_at" : "2012-04-24 17:45:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194842778868514817",
  "text" : "President Obama: \"Republicans who run Congress have yet to say whether or not they\u2019ll stop your rates from doubling\" #DontDoubleMyRate",
  "id" : 194842778868514817,
  "created_at" : "2012-04-24 17:38:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194842588682006529",
  "text" : "President Obama: \"Helping more of our young people afford college should be at the forefront of America\u2019s agenda\" #DontDoubleMyRate",
  "id" : 194842588682006529,
  "created_at" : "2012-04-24 17:37:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194841809422266368",
  "text" : "RT @WHLive: President Obama: \"Now Congress has to do their part...They need to extend the tuition tax credit we put in place\" #DontDoubl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 114, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194841773925875713",
    "text" : "President Obama: \"Now Congress has to do their part...They need to extend the tuition tax credit we put in place\" #DontDoubleMyRate",
    "id" : 194841773925875713,
    "created_at" : "2012-04-24 17:34:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194841809422266368,
  "created_at" : "2012-04-24 17:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaUNC",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194837420565475328",
  "text" : "RT @WHLive: President Obama: \"In today\u2019s economy, there is no greater predictor of individual success than a good education\" #ObamaUNC # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaUNC",
        "indices" : [ 113, 122 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194837373794791424",
    "text" : "President Obama: \"In today\u2019s economy, there is no greater predictor of individual success than a good education\" #ObamaUNC #DontDoubleMyRate",
    "id" : 194837373794791424,
    "created_at" : "2012-04-24 17:17:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194837420565475328,
  "created_at" : "2012-04-24 17:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 54, 61 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 36, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194836364649447425",
  "text" : "Follow President Obama's remarks on #DontDoubleMyRate @WHLive & listen live: http:\/\/t.co\/u95y7hhB",
  "id" : 194836364649447425,
  "created_at" : "2012-04-24 17:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/W44UaNDg",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/president-obama-speaks-interest-rates-student-loans",
      "display_url" : "whitehouse.gov\/live\/president\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194835941569990656",
  "text" : "Live: President Obama calls on Congress to stop interest rates on student loans from doubling @ UNC:\nhttp:\/\/t.co\/W44UaNDg #DontDoubleMyRate",
  "id" : 194835941569990656,
  "created_at" : "2012-04-24 17:11:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MinorityHealth",
      "indices" : [ 37, 52 ]
    }, {
      "text" : "MinorityHealth",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/LX0JAUIw",
      "expanded_url" : "http:\/\/Whitehouse.gov\/live",
      "display_url" : "Whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194825585258807296",
  "text" : "RT @HHSGov: Today, 12:30pm, join the #MinorityHealth townhall at online http:\/\/t.co\/LX0JAUIw -- Q's to #MinorityHealth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MinorityHealth",
        "indices" : [ 25, 40 ]
      }, {
        "text" : "MinorityHealth",
        "indices" : [ 91, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/LX0JAUIw",
        "expanded_url" : "http:\/\/Whitehouse.gov\/live",
        "display_url" : "Whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "194800483649593346",
    "text" : "Today, 12:30pm, join the #MinorityHealth townhall at online http:\/\/t.co\/LX0JAUIw -- Q's to #MinorityHealth",
    "id" : 194800483649593346,
    "created_at" : "2012-04-24 14:50:29 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 194825585258807296,
  "created_at" : "2012-04-24 16:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 27, 39 ],
      "id_str" : "67378554",
      "id" : 67378554
    }, {
      "name" : "NOAA Live",
      "screen_name" : "NOAALive",
      "indices" : [ 42, 51 ],
      "id_str" : "386631799",
      "id" : 386631799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194813781216473089",
  "text" : "RT @WHLive: Happening now: @CraigatFEMA & @NOAALive's Dr. Kathryn Sullivan answer your Qs on severe weather during #WHChat http:\/\/t.co\/G ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Craig Fugate",
        "screen_name" : "CraigatFEMA",
        "indices" : [ 15, 27 ],
        "id_str" : "67378554",
        "id" : 67378554
      }, {
        "name" : "NOAA Live",
        "screen_name" : "NOAALive",
        "indices" : [ 30, 39 ],
        "id_str" : "386631799",
        "id" : 386631799
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/194813605848432641\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/GsQmBagd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ArQd8T6CQAA_srY.jpg",
        "id_str" : "194813605856821248",
        "id" : 194813605856821248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArQd8T6CQAA_srY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/GsQmBagd"
      } ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194813605848432641",
    "text" : "Happening now: @CraigatFEMA & @NOAALive's Dr. Kathryn Sullivan answer your Qs on severe weather during #WHChat http:\/\/t.co\/GsQmBagd",
    "id" : 194813605848432641,
    "created_at" : "2012-04-24 15:42:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194813781216473089,
  "created_at" : "2012-04-24 15:43:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 21, 33 ],
      "id_str" : "67378554",
      "id" : 67378554
    }, {
      "name" : "NOAA Live",
      "screen_name" : "NOAALive",
      "indices" : [ 36, 45 ],
      "id_str" : "386631799",
      "id" : 386631799
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 132, 139 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194803801700577280",
  "text" : "Starting now: Q&A w\/ @CraigatFEMA & @NOAALive's Dr. Kathryn Sullivan on severe weather & preparedness. Ask ? now w\/ #WHChat. Follow @WHLive",
  "id" : 194803801700577280,
  "created_at" : "2012-04-24 15:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194789348267397121",
  "text" : "President Obama honors the 2012 National Teacher of the Year & finalists, thanks them for their hard work. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 194789348267397121,
  "created_at" : "2012-04-24 14:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 37, 49 ],
      "id_str" : "67378554",
      "id" : 67378554
    }, {
      "name" : "NOAA Live",
      "screen_name" : "NOAALive",
      "indices" : [ 52, 61 ],
      "id_str" : "386631799",
      "id" : 386631799
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 133, 140 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194785695003459585",
  "text" : "Today at 11 ET: Join Office Hours w\/ @CraigatFEMA & @NOAALive's Dr. Kathryn Sullivan on Severe Weather. Ask ? now w\/ #WHChat. Follow @WHLive",
  "id" : 194785695003459585,
  "created_at" : "2012-04-24 13:51:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Holocaust Museum",
      "screen_name" : "HolocaustMuseum",
      "indices" : [ 44, 60 ],
      "id_str" : "8487622",
      "id" : 8487622
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/194578699037843456\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/Izjk6g2U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArNIS71CIAIaix1.jpg",
      "id_str" : "194578699042037762",
      "id" : 194578699042037762,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArNIS71CIAIaix1.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Izjk6g2U"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/3UM96msO",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/04\/23\/president-obama-speaks-us-holocaust-memorial-musuem",
      "display_url" : "whitehouse.gov\/blog\/2012\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194578699037843456",
  "text" : "Photo of the Day: President Obama tours the @HolocaustMuseum with Elie Wiesel. Remarks: http:\/\/t.co\/3UM96msO http:\/\/t.co\/Izjk6g2U",
  "id" : 194578699037843456,
  "created_at" : "2012-04-24 00:09:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/194541377680449537\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/7wqlA1d5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ArMmWi8CIAAsCws.jpg",
      "id_str" : "194541377684643840",
      "id" : 194541377684643840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ArMmWi8CIAAsCws.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/7wqlA1d5"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 97, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194541377680449537",
  "text" : "If Congress doesn\u2019t act, interest rates will double on July 1 for more than 7.4 million students #DontDoubleMyRate http:\/\/t.co\/7wqlA1d5",
  "id" : 194541377680449537,
  "created_at" : "2012-04-23 21:40:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CitizensMedal",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/oLgebEZt",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/citizensmedal\/submit-a-nomination",
      "display_url" : "whitehouse.gov\/citizensmedal\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "194511130285187072",
  "text" : "Deadline Tomorrow: Nominate a hero for the Presidential #CitizensMedal: http:\/\/t.co\/oLgebEZt",
  "id" : 194511130285187072,
  "created_at" : "2012-04-23 19:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Alec Ross",
      "screen_name" : "AlecJRoss",
      "indices" : [ 27, 37 ],
      "id_str" : "82282572",
      "id" : 82282572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/epsosHBy",
      "expanded_url" : "http:\/\/ow.ly\/asRjk",
      "display_url" : "ow.ly\/asRjk"
    } ]
  },
  "geo" : { },
  "id_str" : "194505439281553408",
  "text" : "RT @WHLive: Happening now: @AlecJRoss moderates panel on modern tools for preventing & responding to atrocities: http:\/\/t.co\/epsosHBy #W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alec Ross",
        "screen_name" : "AlecJRoss",
        "indices" : [ 15, 25 ],
        "id_str" : "82282572",
        "id" : 82282572
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/epsosHBy",
        "expanded_url" : "http:\/\/ow.ly\/asRjk",
        "display_url" : "ow.ly\/asRjk"
      } ]
    },
    "geo" : { },
    "id_str" : "194505365784764416",
    "text" : "Happening now: @AlecJRoss moderates panel on modern tools for preventing & responding to atrocities: http:\/\/t.co\/epsosHBy #WHchat",
    "id" : 194505365784764416,
    "created_at" : "2012-04-23 19:17:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194505439281553408,
  "created_at" : "2012-04-23 19:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverAgain",
      "indices" : [ 27, 38 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/mrbi1jXR",
      "expanded_url" : "http:\/\/ow.ly\/asJIe",
      "display_url" : "ow.ly\/asJIe"
    } ]
  },
  "geo" : { },
  "id_str" : "194487743563313153",
  "text" : "RT @WHLive: Happening now: #NeverAgain Panel Discussion -- Ask questions with #WHChat & watch live: http:\/\/t.co\/mrbi1jXR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverAgain",
        "indices" : [ 15, 26 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/mrbi1jXR",
        "expanded_url" : "http:\/\/ow.ly\/asJIe",
        "display_url" : "ow.ly\/asJIe"
      } ]
    },
    "geo" : { },
    "id_str" : "194487646154788866",
    "text" : "Happening now: #NeverAgain Panel Discussion -- Ask questions with #WHChat & watch live: http:\/\/t.co\/mrbi1jXR",
    "id" : 194487646154788866,
    "created_at" : "2012-04-23 18:07:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194487743563313153,
  "created_at" : "2012-04-23 18:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194454285923258368",
  "text" : "RT @AmbassadorRice: Today, Pres. Obama ordered sweeping initiatives for a stronger, better-organized global response to mass atrocities  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194454179903836160",
    "text" : "Today, Pres. Obama ordered sweeping initiatives for a stronger, better-organized global response to mass atrocities & genocide.",
    "id" : 194454179903836160,
    "created_at" : "2012-04-23 15:54:23 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 194454285923258368,
  "created_at" : "2012-04-23 15:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/86fxYPqN",
      "expanded_url" : "http:\/\/ow.ly\/asuIi",
      "display_url" : "ow.ly\/asuIi"
    } ]
  },
  "geo" : { },
  "id_str" : "194454259620777984",
  "text" : "Fact Sheet: Comprehensive strategy & new tools to prevent & respond to atrocities: http:\/\/t.co\/86fxYPqN",
  "id" : 194454259620777984,
  "created_at" : "2012-04-23 15:54:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 3, 15 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaonFallon",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194449066850127872",
  "text" : "RT @jimmyfallon: Send in your questions for the president! Hashtag #ObamaonFallon. Yours could be on the show Tuesday night.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaonFallon",
        "indices" : [ 50, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194428371659272195",
    "text" : "Send in your questions for the president! Hashtag #ObamaonFallon. Yours could be on the show Tuesday night.",
    "id" : 194428371659272195,
    "created_at" : "2012-04-23 14:11:50 +0000",
    "user" : {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "protected" : false,
      "id_str" : "15485441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1194467116\/new-resize-square_normal.jpg",
      "id" : 15485441,
      "verified" : true
    }
  },
  "id" : 194449066850127872,
  "created_at" : "2012-04-23 15:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194439905642942465",
  "text" : "RT @WHLive: .@tbraycove2010 We'll wrap up so you can get back to English class! Thx for questions. Keep sending q's for 1pm discussion - ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194439807999549440",
    "text" : ".@tbraycove2010 We'll wrap up so you can get back to English class! Thx for questions. Keep sending q's for 1pm discussion - Ben #whchat",
    "id" : 194439807999549440,
    "created_at" : "2012-04-23 14:57:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194439905642942465,
  "created_at" : "2012-04-23 14:57:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194438984364077056",
  "text" : "RT @WHLive: US welcomes new EU sanctions on Syrian regime. #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194438606373400576",
    "text" : "US welcomes new EU sanctions on Syrian regime. #whchat",
    "id" : 194438606373400576,
    "created_at" : "2012-04-23 14:52:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194438984364077056,
  "created_at" : "2012-04-23 14:54:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Holocaust Museum",
      "screen_name" : "HolocaustMuseum",
      "indices" : [ 3, 19 ],
      "id_str" : "8487622",
      "id" : 8487622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "genprev",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194437086143709184",
  "text" : "RT @HolocaustMuseum: Today President #Obama announced 1st mtg of Atrocities Prev Board. Watch live stream of #genprev panels at WH 1-3pm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "genprev",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/S8S7JCbj",
        "expanded_url" : "http:\/\/ow.ly\/aslI2",
        "display_url" : "ow.ly\/aslI2"
      } ]
    },
    "geo" : { },
    "id_str" : "194436840944705536",
    "text" : "Today President #Obama announced 1st mtg of Atrocities Prev Board. Watch live stream of #genprev panels at WH 1-3pm ET. http:\/\/t.co\/S8S7JCbj",
    "id" : 194436840944705536,
    "created_at" : "2012-04-23 14:45:29 +0000",
    "user" : {
      "name" : "US Holocaust Museum",
      "screen_name" : "HolocaustMuseum",
      "protected" : false,
      "id_str" : "8487622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417773761396371456\/yEWBiZJx_normal.jpeg",
      "id" : 8487622,
      "verified" : true
    }
  },
  "id" : 194437086143709184,
  "created_at" : "2012-04-23 14:46:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Dcz6A4Vt",
      "expanded_url" : "http:\/\/youtu.be\/qxtydXN3f1U",
      "display_url" : "youtu.be\/qxtydXN3f1U"
    } ]
  },
  "geo" : { },
  "id_str" : "194434869521162240",
  "text" : "RT @WHLive: Here is recent POTUS message on Sudan. http:\/\/t.co\/Dcz6A4Vt\n#whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/Dcz6A4Vt",
        "expanded_url" : "http:\/\/youtu.be\/qxtydXN3f1U",
        "display_url" : "youtu.be\/qxtydXN3f1U"
      } ]
    },
    "geo" : { },
    "id_str" : "194434724029136900",
    "text" : "Here is recent POTUS message on Sudan. http:\/\/t.co\/Dcz6A4Vt\n#whchat",
    "id" : 194434724029136900,
    "created_at" : "2012-04-23 14:37:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194434869521162240,
  "created_at" : "2012-04-23 14:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "paul",
      "screen_name" : "seedsown",
      "indices" : [ 13, 22 ],
      "id_str" : "22490662",
      "id" : 22490662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194434191302209536",
  "text" : "RT @WHLive: .@seedsown We will coordinate with UN and other partners to train peacekeepers, apply sanctions, hold rights abusers account ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "paul",
        "screen_name" : "seedsown",
        "indices" : [ 1, 10 ],
        "id_str" : "22490662",
        "id" : 22490662
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194434139208957952",
    "text" : ".@seedsown We will coordinate with UN and other partners to train peacekeepers, apply sanctions, hold rights abusers accountable. #whchat",
    "id" : 194434139208957952,
    "created_at" : "2012-04-23 14:34:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194434191302209536,
  "created_at" : "2012-04-23 14:34:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Naama Haviv",
      "screen_name" : "NaamaHaviv",
      "indices" : [ 13, 24 ],
      "id_str" : "23449011",
      "id" : 23449011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194433836808024065",
  "text" : "RT @WHLive: .@NaamaHaviv POTUS released message to Sudanese people and leaders this weekend. Pressing both parties to negotiate, not fig ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Naama Haviv",
        "screen_name" : "NaamaHaviv",
        "indices" : [ 1, 12 ],
        "id_str" : "23449011",
        "id" : 23449011
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194433576786341889",
    "text" : ".@NaamaHaviv POTUS released message to Sudanese people and leaders this weekend. Pressing both parties to negotiate, not fight. #whchat",
    "id" : 194433576786341889,
    "created_at" : "2012-04-23 14:32:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194433836808024065,
  "created_at" : "2012-04-23 14:33:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "End Genocide",
      "screen_name" : "endgenocide",
      "indices" : [ 3, 15 ],
      "id_str" : "377826053",
      "id" : 377826053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverAgain",
      "indices" : [ 106, 117 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194433447853424641",
  "text" : "RT @endgenocide: Ben Rhodes, Dep Nat Security Advisor is answering your questions on the Atrocities Board #NeverAgain #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/socialcast.localvox.com\" rel=\"nofollow\"\u003ESocialCastLV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverAgain",
        "indices" : [ 89, 100 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194433241363648514",
    "text" : "Ben Rhodes, Dep Nat Security Advisor is answering your questions on the Atrocities Board #NeverAgain #WHchat",
    "id" : 194433241363648514,
    "created_at" : "2012-04-23 14:31:11 +0000",
    "user" : {
      "name" : "End Genocide",
      "screen_name" : "endgenocide",
      "protected" : false,
      "id_str" : "377826053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474276126429163520\/f75HpZL9_normal.jpeg",
      "id" : 377826053,
      "verified" : false
    }
  },
  "id" : 194433447853424641,
  "created_at" : "2012-04-23 14:32:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194432984290557957",
  "text" : "President Obama just concluded his remarks. Have questions about the speech? Ask now with #WHChat",
  "id" : 194432984290557957,
  "created_at" : "2012-04-23 14:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194432744661581824",
  "text" : "RT @WHLive: Hi - I'm Ben Rhodes, Dep Nat Security Advisor. POTUS just finished his remarks. Look forward to answering your questions #Ne ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverAgain",
        "indices" : [ 121, 132 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "194432713686646784",
    "text" : "Hi - I'm Ben Rhodes, Dep Nat Security Advisor. POTUS just finished his remarks. Look forward to answering your questions #NeverAgain #WHchat",
    "id" : 194432713686646784,
    "created_at" : "2012-04-23 14:29:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 194432744661581824,
  "created_at" : "2012-04-23 14:29:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Holocaust Museum",
      "screen_name" : "HolocaustMuseum",
      "indices" : [ 50, 66 ],
      "id_str" : "8487622",
      "id" : 8487622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverAgain",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "194418485932208129",
  "text" : "Happening @ 9:45ET: President Obama speaks at the @HolocaustMuseum. Watch live: http:\/\/t.co\/u95y7hhB #NeverAgain",
  "id" : 194418485932208129,
  "created_at" : "2012-04-23 13:32:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/nPr69yIL",
      "expanded_url" : "http:\/\/ow.ly\/1L0V2S",
      "display_url" : "ow.ly\/1L0V2S"
    } ]
  },
  "geo" : { },
  "id_str" : "194068241419735042",
  "text" : "\"Let us embrace our commitment to the generations yet to come by leaving them a safe, clean world\" -Obama on #EarthDay http:\/\/t.co\/nPr69yIL",
  "id" : 194068241419735042,
  "created_at" : "2012-04-22 14:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/LpfTaLlR",
      "expanded_url" : "http:\/\/youtu.be\/_TcVs9wnZlo",
      "display_url" : "youtu.be\/_TcVs9wnZlo"
    } ]
  },
  "geo" : { },
  "id_str" : "193751670629470209",
  "text" : "President Obama: \"If Congress doesn\u2019t act, on 7\/1 interest rates on some student loans will double\" http:\/\/t.co\/LpfTaLlR #DontDoubleMyRate",
  "id" : 193751670629470209,
  "created_at" : "2012-04-21 17:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHPhotowalk",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 123 ],
      "url" : "https:\/\/t.co\/JomMM2MU",
      "expanded_url" : "https:\/\/plus.google.com\/s\/%23WHPhotowalk",
      "display_url" : "plus.google.com\/s\/%23WHPhotowa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193674575576432641",
  "text" : "Today we're hosting our 1st ever Google+ #WHPhotowalk for @whitehouse garden tours. Follow in photos: https:\/\/t.co\/JomMM2MU",
  "id" : 193674575576432641,
  "created_at" : "2012-04-21 12:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193454956999745536",
  "text" : "RT @arneduncan: It's not every day I take Qs from the @whitehouse press corp. But #DontDoubleMyRate is an important issue VIDEO http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 38, 49 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 66, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/dHbb8KaH",
        "expanded_url" : "http:\/\/bit.ly\/ItCMsx",
        "display_url" : "bit.ly\/ItCMsx"
      } ]
    },
    "geo" : { },
    "id_str" : "193453536242176000",
    "text" : "It's not every day I take Qs from the @whitehouse press corp. But #DontDoubleMyRate is an important issue VIDEO http:\/\/t.co\/dHbb8KaH",
    "id" : 193453536242176000,
    "created_at" : "2012-04-20 21:38:11 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 193454956999745536,
  "created_at" : "2012-04-20 21:43:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193422454524354561",
  "text" : "RT @WHLive: Hi, Todd Park here, ready to take your questions on #JOBSAct #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JOBSAct",
        "indices" : [ 52, 60 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 61, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "193421615722283008",
    "text" : "Hi, Todd Park here, ready to take your questions on #JOBSAct #WHChat",
    "id" : 193421615722283008,
    "created_at" : "2012-04-20 19:31:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 193422454524354561,
  "created_at" : "2012-04-20 19:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 62, 69 ],
      "id_str" : "49153854",
      "id" : 49153854
    }, {
      "name" : "Alabama Athletics",
      "screen_name" : "UA_Athletics",
      "indices" : [ 70, 83 ],
      "id_str" : "27082579",
      "id" : 27082579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RollTide",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/2W5AvTbF",
      "expanded_url" : "http:\/\/youtu.be\/BhEiTEOTBQg",
      "display_url" : "youtu.be\/BhEiTEOTBQg"
    } ]
  },
  "geo" : { },
  "id_str" : "193414012346695680",
  "text" : "Check out the latest West Wing Week: http:\/\/t.co\/2W5AvTbF cc: @NASCAR @UA_Athletics #RollTide",
  "id" : 193414012346695680,
  "created_at" : "2012-04-20 19:01:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193410751493447681",
  "text" : "RT @startupamerica: Questions about the #JOBSAct? Join the Twitter Office Hours TODAY at 3:30p ET. Ask your questions using #WHChat & be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 132, 139 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JOBSAct",
        "indices" : [ 20, 28 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "193394554551017476",
    "text" : "Questions about the #JOBSAct? Join the Twitter Office Hours TODAY at 3:30p ET. Ask your questions using #WHChat & be sure to follow @WHLive",
    "id" : 193394554551017476,
    "created_at" : "2012-04-20 17:43:49 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 193410751493447681,
  "created_at" : "2012-04-20 18:48:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/GbZcca7x",
      "expanded_url" : "http:\/\/on.doi.gov\/HYmZpJ",
      "display_url" : "on.doi.gov\/HYmZpJ"
    } ]
  },
  "geo" : { },
  "id_str" : "193409871511699456",
  "text" : "RT @Interior: President Obama to sign proclamation designating Fort Ord National Monument: http:\/\/t.co\/GbZcca7x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/GbZcca7x",
        "expanded_url" : "http:\/\/on.doi.gov\/HYmZpJ",
        "display_url" : "on.doi.gov\/HYmZpJ"
      } ]
    },
    "geo" : { },
    "id_str" : "193403983505788928",
    "text" : "President Obama to sign proclamation designating Fort Ord National Monument: http:\/\/t.co\/GbZcca7x",
    "id" : 193403983505788928,
    "created_at" : "2012-04-20 18:21:17 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 193409871511699456,
  "created_at" : "2012-04-20 18:44:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "U.S. EEOC",
      "screen_name" : "EEOCNews",
      "indices" : [ 80, 89 ],
      "id_str" : "34682633",
      "id" : 34682633
    }, {
      "name" : "DOJ Civil Rights",
      "screen_name" : "CivilRights",
      "indices" : [ 91, 103 ],
      "id_str" : "221135570",
      "id" : 221135570
    }, {
      "name" : "Lisa M. Maatz",
      "screen_name" : "LisaMaatz",
      "indices" : [ 121, 131 ],
      "id_str" : "35013862",
      "id" : 35013862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayChat",
      "indices" : [ 57, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/8jSPcmhh",
      "expanded_url" : "http:\/\/bit.ly\/IWBkBB",
      "display_url" : "bit.ly\/IWBkBB"
    } ]
  },
  "geo" : { },
  "id_str" : "193344534900506624",
  "text" : "RT @USDOL: TODAY @ 12pmET: http:\/\/t.co\/8jSPcmhh Join our #EqualPayChat along w\/ @EEOCNews, @CivilRights & special guests @LisaMaatz & @e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EEOC",
        "screen_name" : "EEOCNews",
        "indices" : [ 69, 78 ],
        "id_str" : "34682633",
        "id" : 34682633
      }, {
        "name" : "DOJ Civil Rights",
        "screen_name" : "CivilRights",
        "indices" : [ 80, 92 ],
        "id_str" : "221135570",
        "id" : 221135570
      }, {
        "name" : "Lisa M. Maatz",
        "screen_name" : "LisaMaatz",
        "indices" : [ 110, 120 ],
        "id_str" : "35013862",
        "id" : 35013862
      }, {
        "name" : "Elianne Ramos",
        "screen_name" : "ergeekgoddess",
        "indices" : [ 123, 137 ],
        "id_str" : "16462209",
        "id" : 16462209
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayChat",
        "indices" : [ 46, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/8jSPcmhh",
        "expanded_url" : "http:\/\/bit.ly\/IWBkBB",
        "display_url" : "bit.ly\/IWBkBB"
      } ]
    },
    "geo" : { },
    "id_str" : "193344390037651456",
    "text" : "TODAY @ 12pmET: http:\/\/t.co\/8jSPcmhh Join our #EqualPayChat along w\/ @EEOCNews, @CivilRights & special guests @LisaMaatz & @ergeekgoddess.",
    "id" : 193344390037651456,
    "created_at" : "2012-04-20 14:24:29 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 193344534900506624,
  "created_at" : "2012-04-20 14:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/9zCfac1j",
      "expanded_url" : "http:\/\/www.mercurynews.com\/science\/ci_20438035\/obama-designate-fort-ord-new-national-monument",
      "display_url" : "mercurynews.com\/science\/ci_204\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193343979926978563",
  "text" : "RT @jearnest44: Earth Day is Sunday, but today POTUS will designate California's Fort Ord a national monument: http:\/\/t.co\/9zCfac1j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/9zCfac1j",
        "expanded_url" : "http:\/\/www.mercurynews.com\/science\/ci_20438035\/obama-designate-fort-ord-new-national-monument",
        "display_url" : "mercurynews.com\/science\/ci_204\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "193333014707716097",
    "text" : "Earth Day is Sunday, but today POTUS will designate California's Fort Ord a national monument: http:\/\/t.co\/9zCfac1j",
    "id" : 193333014707716097,
    "created_at" : "2012-04-20 13:39:17 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 193343979926978563,
  "created_at" : "2012-04-20 14:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/193090289165025281\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/sUKGA9TK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aq3-mE_CQAAxah5.jpg",
      "id_str" : "193090289173413888",
      "id" : 193090289173413888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aq3-mE_CQAAxah5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sUKGA9TK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193090289165025281",
  "text" : "Photo of the Day: President Obama sits for a moment inside the bus where Rosa Parks refused to give up her seat: http:\/\/t.co\/sUKGA9TK",
  "id" : 193090289165025281,
  "created_at" : "2012-04-19 21:34:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/i4ugExmL",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/6948113926\/in\/photostream",
      "display_url" : "flickr.com\/photos\/whiteho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "193086578988564480",
  "text" : "President Obama in the Rosa Parks bus http:\/\/t.co\/i4ugExmL",
  "id" : 193086578988564480,
  "created_at" : "2012-04-19 21:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "193043508507066368",
  "text" : "Happening now: President Obama welcomes BCS National Champion Alabama Crimson Tide to the White House: http:\/\/t.co\/u95y7hhB",
  "id" : 193043508507066368,
  "created_at" : "2012-04-19 18:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchamps",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193015383660306432",
  "text" : "RT @JonCarson44: heading over now to kick off the Champions of Change celebrating renewable energy!\n#whchamps \nWatch it here at 12:30EST ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchamps",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/OLPwx9o8",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "193011634501992449",
    "text" : "heading over now to kick off the Champions of Change celebrating renewable energy!\n#whchamps \nWatch it here at 12:30EST http:\/\/t.co\/OLPwx9o8",
    "id" : 193011634501992449,
    "created_at" : "2012-04-19 16:22:14 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 193015383660306432,
  "created_at" : "2012-04-19 16:37:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193007327379595265",
  "text" : "RT @JoiningForces: On Board with the First Lady: Go behind the scenes as Michelle Obama celebrates one year of #JoiningForces: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/eTu0735N",
        "expanded_url" : "http:\/\/ow.ly\/aoark",
        "display_url" : "ow.ly\/aoark"
      } ]
    },
    "geo" : { },
    "id_str" : "193007220366127104",
    "text" : "On Board with the First Lady: Go behind the scenes as Michelle Obama celebrates one year of #JoiningForces: http:\/\/t.co\/eTu0735N",
    "id" : 193007220366127104,
    "created_at" : "2012-04-19 16:04:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 193007327379595265,
  "created_at" : "2012-04-19 16:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192985277764087808",
  "text" : "RT @PressSec: It's a good day for First Question. Ask your ?s with #1q & I'll answer some later today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 53, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192983392290226176",
    "text" : "It's a good day for First Question. Ask your ?s with #1q & I'll answer some later today.",
    "id" : 192983392290226176,
    "created_at" : "2012-04-19 14:30:00 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 192985277764087808,
  "created_at" : "2012-04-19 14:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 89, 100 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinancing",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/hYngBwgc",
      "expanded_url" : "http:\/\/youtu.be\/BhpUiMp6Nlw",
      "display_url" : "youtu.be\/BhpUiMp6Nlw"
    } ]
  },
  "geo" : { },
  "id_str" : "192728691330138112",
  "text" : "Learn why #refinancing is good for homeowners, neighborhoods & our economy in our latest @WhiteHouse White Board: http:\/\/t.co\/hYngBwgc",
  "id" : 192728691330138112,
  "created_at" : "2012-04-18 21:37:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/nHGBx55U",
      "expanded_url" : "http:\/\/bit.ly\/JiB3az",
      "display_url" : "bit.ly\/JiB3az"
    } ]
  },
  "geo" : { },
  "id_str" : "192721880237608960",
  "text" : "RT @jesseclee44: Biden at his best, most passionate on the Violence Against Women Act. You should watch http:\/\/t.co\/nHGBx55U #Reauthoriz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReauthorizeVAWA",
        "indices" : [ 108, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/nHGBx55U",
        "expanded_url" : "http:\/\/bit.ly\/JiB3az",
        "display_url" : "bit.ly\/JiB3az"
      } ]
    },
    "geo" : { },
    "id_str" : "192718227699273729",
    "text" : "Biden at his best, most passionate on the Violence Against Women Act. You should watch http:\/\/t.co\/nHGBx55U #ReauthorizeVAWA",
    "id" : 192718227699273729,
    "created_at" : "2012-04-18 20:56:20 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 192721880237608960,
  "created_at" : "2012-04-18 21:10:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/192641561199255552\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/5NQZgR6r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqxmerCCIAABZpV.jpg",
      "id_str" : "192641561203449856",
      "id" : 192641561203449856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqxmerCCIAABZpV.jpg",
      "sizes" : [ {
        "h" : 968,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 968
      } ],
      "display_url" : "pic.twitter.com\/5NQZgR6r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192641831044005889",
  "text" : "RT @petesouza: The view from Marine One just now http:\/\/t.co\/5NQZgR6r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/192641561199255552\/photo\/1",
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/5NQZgR6r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AqxmerCCIAABZpV.jpg",
        "id_str" : "192641561203449856",
        "id" : 192641561203449856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqxmerCCIAABZpV.jpg",
        "sizes" : [ {
          "h" : 968,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 968
        } ],
        "display_url" : "pic.twitter.com\/5NQZgR6r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192641561199255552",
    "text" : "The view from Marine One just now http:\/\/t.co\/5NQZgR6r",
    "id" : 192641561199255552,
    "created_at" : "2012-04-18 15:51:42 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 192641831044005889,
  "created_at" : "2012-04-18 15:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 81, 84 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "192630724350844929",
  "text" : "RT @WHLive: Happening now: The Importance of the Violence Against Women Act with @VP watch live: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 69, 72 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "192629757878349824",
    "text" : "Happening now: The Importance of the Violence Against Women Act with @VP watch live: http:\/\/t.co\/g5ih2w0F",
    "id" : 192629757878349824,
    "created_at" : "2012-04-18 15:04:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 192630724350844929,
  "created_at" : "2012-04-18 15:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/41sUCq2b",
      "expanded_url" : "http:\/\/wh.gov\/taxreceipt",
      "display_url" : "wh.gov\/taxreceipt"
    } ]
  },
  "geo" : { },
  "id_str" : "192382113436282881",
  "text" : "Want to understand how & where your federal tax dollars are being spent? Get your 2011 taxpayer receipt now: http:\/\/t.co\/41sUCq2b",
  "id" : 192382113436282881,
  "created_at" : "2012-04-17 22:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 35, 49 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/E57Buthk",
      "expanded_url" : "http:\/\/wh.gov\/UP3",
      "display_url" : "wh.gov\/UP3"
    } ]
  },
  "geo" : { },
  "id_str" : "192358312422014976",
  "text" : "Winning Apps to Close the Pay Gap: @HildaSolisDOL announces the winners of the #EqualPay App Challenge: http:\/\/t.co\/E57Buthk",
  "id" : 192358312422014976,
  "created_at" : "2012-04-17 21:06:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/xEkCm6qE",
      "expanded_url" : "http:\/\/wh.gov\/URn",
      "display_url" : "wh.gov\/URn"
    } ]
  },
  "geo" : { },
  "id_str" : "192329741058060288",
  "text" : "President Obama on #EqualPay Day: \"Working women are at the heart of an America built to last\" http:\/\/t.co\/xEkCm6qE",
  "id" : 192329741058060288,
  "created_at" : "2012-04-17 19:12:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHPhotowalk",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ENWvl5VX",
      "expanded_url" : "http:\/\/wh.gov\/UPO",
      "display_url" : "wh.gov\/UPO"
    } ]
  },
  "geo" : { },
  "id_str" : "192319878030565377",
  "text" : "RT @ks44: Announcing our first Google+ #WHPhotowalk: @whitehouse Spring Garden Tour. Interested in joining? Here's how: http:\/\/t.co\/ENWvl5VX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHPhotowalk",
        "indices" : [ 29, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/ENWvl5VX",
        "expanded_url" : "http:\/\/wh.gov\/UPO",
        "display_url" : "wh.gov\/UPO"
      } ]
    },
    "geo" : { },
    "id_str" : "192319779577663489",
    "text" : "Announcing our first Google+ #WHPhotowalk: @whitehouse Spring Garden Tour. Interested in joining? Here's how: http:\/\/t.co\/ENWvl5VX",
    "id" : 192319779577663489,
    "created_at" : "2012-04-17 18:33:03 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 192319878030565377,
  "created_at" : "2012-04-17 18:33:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "appsforenergy",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192307034174140417",
  "text" : "RT @ENERGY: Join today\u2019s twitter Q&A at 2 PM EDT: Answering Q\u2019s on how #appsforenergy & other gov challenges spur innovation: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "appsforenergy",
        "indices" : [ 59, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/USfQMPDA",
        "expanded_url" : "http:\/\/go.usa.gov\/yis",
        "display_url" : "go.usa.gov\/yis"
      } ]
    },
    "geo" : { },
    "id_str" : "192271082156326912",
    "text" : "Join today\u2019s twitter Q&A at 2 PM EDT: Answering Q\u2019s on how #appsforenergy & other gov challenges spur innovation: http:\/\/t.co\/USfQMPDA",
    "id" : 192271082156326912,
    "created_at" : "2012-04-17 15:19:32 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 192307034174140417,
  "created_at" : "2012-04-17 17:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/41sUCq2b",
      "expanded_url" : "http:\/\/wh.gov\/taxreceipt",
      "display_url" : "wh.gov\/taxreceipt"
    } ]
  },
  "geo" : { },
  "id_str" : "192275792057741312",
  "text" : "Happy Tax Day: Calculate your tax receipt to find out how & where your tax dollars are being spent: http:\/\/t.co\/41sUCq2b",
  "id" : 192275792057741312,
  "created_at" : "2012-04-17 15:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192274603404570624",
  "text" : "RT @WHLive: Happening now: President Obama announces plan to increase oversight & crack down on manipulation in oil markets. Watch: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "192274558663925762",
    "text" : "Happening now: President Obama announces plan to increase oversight & crack down on manipulation in oil markets. Watch: http:\/\/t.co\/g5ih2w0F",
    "id" : 192274558663925762,
    "created_at" : "2012-04-17 15:33:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 192274603404570624,
  "created_at" : "2012-04-17 15:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192273987026436097",
  "text" : "RT @JonCarson44: Know a hero in your community? Nominate them today for the 2012 Presidential Citizens Medal. Find out more: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/EECvuOHE",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/citizensmedal\/submit-a-nomination",
        "display_url" : "whitehouse.gov\/citizensmedal\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "192272039548170240",
    "text" : "Know a hero in your community? Nominate them today for the 2012 Presidential Citizens Medal. Find out more: http:\/\/t.co\/EECvuOHE #WHChamps",
    "id" : 192272039548170240,
    "created_at" : "2012-04-17 15:23:21 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 192273987026436097,
  "created_at" : "2012-04-17 15:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192049014605225984",
  "text" : "RT @jesseclee44: #hcr strikes again... \"FL health insurers to rebate estimated $113M-Consumers w\/ individual policies may get $143-$949\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/Acujnewj",
        "expanded_url" : "http:\/\/articles.sun-sentinel.com\/2012-04-13\/news\/fl-health-insurance-rebates-20120406_1_health-insurers-individual-policies-insurance-commissioners",
        "display_url" : "articles.sun-sentinel.com\/2012-04-13\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "191874406975410176",
    "text" : "#hcr strikes again... \"FL health insurers to rebate estimated $113M-Consumers w\/ individual policies may get $143-$949\"\nhttp:\/\/t.co\/Acujnewj",
    "id" : 191874406975410176,
    "created_at" : "2012-04-16 13:03:18 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 192049014605225984,
  "created_at" : "2012-04-17 00:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/59NBxUZe",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/\/the-press-office\/2012\/04\/16\/statement-president-buffett-rule",
      "display_url" : "whitehouse.gov\/\/the-press-off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "192048617979265024",
  "text" : "Statement by President Obama on the #BuffettRule: http:\/\/t.co\/59NBxUZe",
  "id" : 192048617979265024,
  "created_at" : "2012-04-17 00:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "192030575870226432",
  "text" : "President Obama: \"Senate Republicans voted to block the #BuffettRule, choosing once again to protect tax breaks for the wealthiest few\"",
  "id" : 192030575870226432,
  "created_at" : "2012-04-16 23:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/u8bIzpFC",
      "expanded_url" : "http:\/\/youtu.be\/PLl7Of0cwnY",
      "display_url" : "youtu.be\/PLl7Of0cwnY"
    } ]
  },
  "geo" : { },
  "id_str" : "192012627663265793",
  "text" : "Today's topic is the #BuffettRule. Brian Deese of the Natl Economic Council explains on the white board. Watch: http:\/\/t.co\/u8bIzpFC",
  "id" : 192012627663265793,
  "created_at" : "2012-04-16 22:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/41sUCq2b",
      "expanded_url" : "http:\/\/wh.gov\/taxreceipt",
      "display_url" : "wh.gov\/taxreceipt"
    } ]
  },
  "geo" : { },
  "id_str" : "191982671017156608",
  "text" : "Rushing to file your taxes? Understand how & where your dollars are being spent with our taxpayer receipt: http:\/\/t.co\/41sUCq2b",
  "id" : 191982671017156608,
  "created_at" : "2012-04-16 20:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Rick Larsen",
      "screen_name" : "RepRickLarsen",
      "indices" : [ 3, 17 ],
      "id_str" : "404132211",
      "id" : 404132211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191974030092414977",
  "text" : "RT @RepRickLarsen: I support the #BuffettRule. Hard-working middle class should not pay higher rate than those who make $1M+ a year. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffettRule",
        "indices" : [ 14, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 135 ],
        "url" : "https:\/\/t.co\/utCoK1yS",
        "expanded_url" : "https:\/\/www.facebook.com\/RepRickLarsen\/posts\/406223912735065",
        "display_url" : "facebook.com\/RepRickLarsen\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "191973867156279296",
    "text" : "I support the #BuffettRule. Hard-working middle class should not pay higher rate than those who make $1M+ a year. https:\/\/t.co\/utCoK1yS",
    "id" : 191973867156279296,
    "created_at" : "2012-04-16 19:38:31 +0000",
    "user" : {
      "name" : "Rep. Rick Larsen",
      "screen_name" : "RepRickLarsen",
      "protected" : false,
      "id_str" : "404132211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000053920474\/f062c789d4bb0d812a48107cce97c6d5_normal.jpeg",
      "id" : 404132211,
      "verified" : true
    }
  },
  "id" : 191974030092414977,
  "created_at" : "2012-04-16 19:39:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/191973854929891329\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/tRDD2vGj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqoHNDXCMAAf3mb.jpg",
      "id_str" : "191973854938279936",
      "id" : 191973854938279936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqoHNDXCMAAf3mb.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/tRDD2vGj"
    } ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/Rl70xbOt",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/04\/16\/buffett-rule-would-make-sure-everyone-plays-same-rules",
      "display_url" : "whitehouse.gov\/blog\/2012\/04\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191973854929891329",
  "text" : "#BuffettRule would make sure everyone plays by the same rules: http:\/\/t.co\/Rl70xbOt Chart: http:\/\/t.co\/tRDD2vGj",
  "id" : 191973854929891329,
  "created_at" : "2012-04-16 19:38:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CitizensMedal",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/cgLJDZt9",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/04\/16\/2012-citizens-medal-open-nominations",
      "display_url" : "whitehouse.gov\/blog\/2012\/04\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "191939870913081344",
  "text" : "Announcing the 2012 Presidential #CitizensMedal: Nominate a hero in your community today: http:\/\/t.co\/cgLJDZt9",
  "id" : 191939870913081344,
  "created_at" : "2012-04-16 17:23:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 77, 87 ],
      "id_str" : "200176600",
      "id" : 200176600
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 113, 128 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "appsforenergy",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/NRc8waTR",
      "expanded_url" : "http:\/\/go.usa.gov\/mhL",
      "display_url" : "go.usa.gov\/mhL"
    } ]
  },
  "geo" : { },
  "id_str" : "191935387495698433",
  "text" : "RT @ENERGY: Ask Away: #appsforenergy twitter Q&A 4\/17 at 2PM EDT w\/ U.S. CTO @todd_park, http:\/\/t.co\/NRc8waTR cc @whitehouseostp @macon4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 65, 75 ],
        "id_str" : "200176600",
        "id" : 200176600
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 101, 116 ],
        "id_str" : "33998183",
        "id" : 33998183
      }, {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 117, 125 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      }, {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 126, 139 ],
        "id_str" : "121539516",
        "id" : 121539516
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "appsforenergy",
        "indices" : [ 10, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/NRc8waTR",
        "expanded_url" : "http:\/\/go.usa.gov\/mhL",
        "display_url" : "go.usa.gov\/mhL"
      } ]
    },
    "geo" : { },
    "id_str" : "191923539497062401",
    "text" : "Ask Away: #appsforenergy twitter Q&A 4\/17 at 2PM EDT w\/ U.S. CTO @todd_park, http:\/\/t.co\/NRc8waTR cc @whitehouseostp @macon44 @aneeshchopra",
    "id" : 191923539497062401,
    "created_at" : "2012-04-16 16:18:32 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 191935387495698433,
  "created_at" : "2012-04-16 17:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank R. Lautenberg",
      "screen_name" : "FrankLautenberg",
      "indices" : [ 3, 19 ],
      "id_str" : "135297032",
      "id" : 135297032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191903037860749313",
  "text" : "RT @FrankLautenberg: The #BuffettRule would restore fairness to the tax code; millionaires shouldn't pay lower tax rates than the middle ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffettRule",
        "indices" : [ 4, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "191902898781831170",
    "text" : "The #BuffettRule would restore fairness to the tax code; millionaires shouldn't pay lower tax rates than the middle class.",
    "id" : 191902898781831170,
    "created_at" : "2012-04-16 14:56:31 +0000",
    "user" : {
      "name" : "Frank R. Lautenberg",
      "screen_name" : "FrankLautenberg",
      "protected" : false,
      "id_str" : "135297032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3442371929\/a0428d6979a0fd95a2043c91339dd634_normal.jpeg",
      "id" : 135297032,
      "verified" : true
    }
  },
  "id" : 191903037860749313,
  "created_at" : "2012-04-16 14:57:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "FairShare",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/zAEijgzg",
      "expanded_url" : "http:\/\/youtu.be\/9yiay9qgqPU",
      "display_url" : "youtu.be\/9yiay9qgqPU"
    } ]
  },
  "geo" : { },
  "id_str" : "191898167816622080",
  "text" : "It\u2019s time for Congress to pass the #BuffettRule. RT if you agree that everyone should pay their #FairShare: http:\/\/t.co\/zAEijgzg",
  "id" : 191898167816622080,
  "created_at" : "2012-04-16 14:37:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/191890668023595009\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/IJRTa0lv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aqm7i7-CQAE8Q0Z.jpg",
      "id_str" : "191890668027789313",
      "id" : 191890668027789313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aqm7i7-CQAE8Q0Z.jpg",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/IJRTa0lv"
    } ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/3AICfsCK",
      "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
      "display_url" : "wh.gov\/buffett-rule"
    } ]
  },
  "geo" : { },
  "id_str" : "191890668023595009",
  "text" : "Today Senate votes on the #BuffettRule. How many millionaires pay a lower tax rate than you? http:\/\/t.co\/3AICfsCK http:\/\/t.co\/IJRTa0lv",
  "id" : 191890668023595009,
  "created_at" : "2012-04-16 14:07:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "DIV at USAID",
      "screen_name" : "DIVatUSAID",
      "indices" : [ 69, 80 ],
      "id_str" : "355550021",
      "id" : 355550021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CumbreAm\u00E9ricas",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/lZX7oatK",
      "expanded_url" : "http:\/\/1.usa.gov\/IR71fI",
      "display_url" : "1.usa.gov\/IR71fI"
    } ]
  },
  "geo" : { },
  "id_str" : "191626229202427904",
  "text" : "RT @USAID: Learn more about our new Innovation Fund for the Americas @DIVatUSAID #CumbreAm\u00E9ricas http:\/\/t.co\/lZX7oatK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DIV at USAID",
        "screen_name" : "DIVatUSAID",
        "indices" : [ 58, 69 ],
        "id_str" : "355550021",
        "id" : 355550021
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CumbreAm\u00E9ricas",
        "indices" : [ 70, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/lZX7oatK",
        "expanded_url" : "http:\/\/1.usa.gov\/IR71fI",
        "display_url" : "1.usa.gov\/IR71fI"
      } ]
    },
    "geo" : { },
    "id_str" : "191323728183959553",
    "text" : "Learn more about our new Innovation Fund for the Americas @DIVatUSAID #CumbreAm\u00E9ricas http:\/\/t.co\/lZX7oatK",
    "id" : 191323728183959553,
    "created_at" : "2012-04-15 00:35:06 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 191626229202427904,
  "created_at" : "2012-04-15 20:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CumbreAm\u00E9ricas",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/lZX7oatK",
      "expanded_url" : "http:\/\/1.usa.gov\/IR71fI",
      "display_url" : "1.usa.gov\/IR71fI"
    } ]
  },
  "geo" : { },
  "id_str" : "191626189994065921",
  "text" : "RT @USAID: Learn more about how we are improving access to broadband & Internet in the Americas http:\/\/t.co\/lZX7oatK #CumbreAm\u00E9ricas @mS ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CumbreAm\u00E9ricas",
        "indices" : [ 106, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/lZX7oatK",
        "expanded_url" : "http:\/\/1.usa.gov\/IR71fI",
        "display_url" : "1.usa.gov\/IR71fI"
      } ]
    },
    "geo" : { },
    "id_str" : "191323096303681537",
    "text" : "Learn more about how we are improving access to broadband & Internet in the Americas http:\/\/t.co\/lZX7oatK #CumbreAm\u00E9ricas @mSolutionsUSAID",
    "id" : 191323096303681537,
    "created_at" : "2012-04-15 00:32:35 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 191626189994065921,
  "created_at" : "2012-04-15 20:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/sTBDPijR",
      "expanded_url" : "http:\/\/ow.ly\/aicqX",
      "display_url" : "ow.ly\/aicqX"
    } ]
  },
  "geo" : { },
  "id_str" : "191619135120220161",
  "text" : "Weekly Address: It\u2019s Time for Congress to Pass the #BuffettRule: http:\/\/t.co\/sTBDPijR",
  "id" : 191619135120220161,
  "created_at" : "2012-04-15 20:08:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/190961659819470848\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/Dor6h5ls",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqZunivCMAAhd2L.jpg",
      "id_str" : "190961659827859456",
      "id" : 190961659827859456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqZunivCMAAhd2L.jpg",
      "sizes" : [ {
        "h" : 379,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1148,
        "resize" : "fit",
        "w" : 1818
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Dor6h5ls"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190961659819470848",
  "text" : "Photo of the Day: After a speech in Tampa, President Obama embraces audience members: http:\/\/t.co\/Dor6h5ls",
  "id" : 190961659819470848,
  "created_at" : "2012-04-14 00:36:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Gail Simmons",
      "screen_name" : "gailsimmons",
      "indices" : [ 72, 84 ],
      "id_str" : "21915666",
      "id" : 21915666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/DK7JRlxH",
      "expanded_url" : "http:\/\/ow.ly\/agWX5",
      "display_url" : "ow.ly\/agWX5"
    } ]
  },
  "geo" : { },
  "id_str" : "190952921557504000",
  "text" : "RT @letsmove: In case you missed it, watch today's Google+ Hangout with @gailsimmons & Chef Cris Comerford: http:\/\/t.co\/DK7JRlxH #AskLet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gail Simmons",
        "screen_name" : "gailsimmons",
        "indices" : [ 58, 70 ],
        "id_str" : "21915666",
        "id" : 21915666
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskLetsMove",
        "indices" : [ 115, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/DK7JRlxH",
        "expanded_url" : "http:\/\/ow.ly\/agWX5",
        "display_url" : "ow.ly\/agWX5"
      } ]
    },
    "geo" : { },
    "id_str" : "190952530858090496",
    "text" : "In case you missed it, watch today's Google+ Hangout with @gailsimmons & Chef Cris Comerford: http:\/\/t.co\/DK7JRlxH #AskLetsMove",
    "id" : 190952530858090496,
    "created_at" : "2012-04-14 00:00:05 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 190952921557504000,
  "created_at" : "2012-04-14 00:01:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "EasterEggRoll",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/Oy38vmKR",
      "expanded_url" : "http:\/\/ow.ly\/agUGm",
      "display_url" : "ow.ly\/agUGm"
    } ]
  },
  "geo" : { },
  "id_str" : "190939092744290304",
  "text" : "Watch West Wing Week: President Obama talks #BuffettRule in Florida, hosts the #EasterEggRoll at the WH & more: http:\/\/t.co\/Oy38vmKR",
  "id" : 190939092744290304,
  "created_at" : "2012-04-13 23:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Gail Simmons",
      "screen_name" : "gailsimmons",
      "indices" : [ 70, 82 ],
      "id_str" : "21915666",
      "id" : 21915666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "190849155818729473",
  "text" : "RT @letsmove: Happening Now: We're hanging out in the WH Kitchen with @gailsimmons & Cris Comerford. Watch: http:\/\/t.co\/QDIpMRKE",
  "id" : 190849155818729473,
  "created_at" : "2012-04-13 17:09:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Simmons",
      "screen_name" : "gailsimmons",
      "indices" : [ 3, 15 ],
      "id_str" : "21915666",
      "id" : 21915666
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 96, 105 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 131, 139 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/L7g7KYfm",
      "expanded_url" : "http:\/\/youtu.be\/kRcxQUt1qmI",
      "display_url" : "youtu.be\/kRcxQUt1qmI"
    } ]
  },
  "geo" : { },
  "id_str" : "190848072572612608",
  "text" : "RT @gailsimmons: Check out the live link to my White House Google+ Hangout with Cris Comerford. @letsmove http:\/\/t.co\/L7g7KYfm via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 79, 88 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 114, 122 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/L7g7KYfm",
        "expanded_url" : "http:\/\/youtu.be\/kRcxQUt1qmI",
        "display_url" : "youtu.be\/kRcxQUt1qmI"
      } ]
    },
    "geo" : { },
    "id_str" : "190843831950901249",
    "text" : "Check out the live link to my White House Google+ Hangout with Cris Comerford. @letsmove http:\/\/t.co\/L7g7KYfm via @youtube",
    "id" : 190843831950901249,
    "created_at" : "2012-04-13 16:48:09 +0000",
    "user" : {
      "name" : "Gail Simmons",
      "screen_name" : "gailsimmons",
      "protected" : false,
      "id_str" : "21915666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660435334631587843\/152EUqrX_normal.jpg",
      "id" : 21915666,
      "verified" : true
    }
  },
  "id" : 190848072572612608,
  "created_at" : "2012-04-13 17:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/x0WW8Z40",
      "expanded_url" : "http:\/\/1.usa.gov\/HCTIzH",
      "display_url" : "1.usa.gov\/HCTIzH"
    } ]
  },
  "geo" : { },
  "id_str" : "190812599233937408",
  "text" : "RT @pfeiffer44: President Obama and Vice President Biden's tax returns for this year can be found here: http:\/\/t.co\/x0WW8Z40",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/x0WW8Z40",
        "expanded_url" : "http:\/\/1.usa.gov\/HCTIzH",
        "display_url" : "1.usa.gov\/HCTIzH"
      } ]
    },
    "geo" : { },
    "id_str" : "190811925121208320",
    "text" : "President Obama and Vice President Biden's tax returns for this year can be found here: http:\/\/t.co\/x0WW8Z40",
    "id" : 190811925121208320,
    "created_at" : "2012-04-13 14:41:22 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 190812599233937408,
  "created_at" : "2012-04-13 14:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Gail Simmons",
      "screen_name" : "gailsimmons",
      "indices" : [ 82, 94 ],
      "id_str" : "21915666",
      "id" : 21915666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190798618398171136",
  "text" : "RT @letsmove: Join our Google+ Hangout today live from the @WhiteHouse kitchen w\/ @gailsimmons & WH Chef Cris Comerford: http:\/\/t.co\/e1O ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 45, 56 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Gail Simmons",
        "screen_name" : "gailsimmons",
        "indices" : [ 68, 80 ],
        "id_str" : "21915666",
        "id" : 21915666
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskLetsMove",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/e1OTbOqA",
        "expanded_url" : "http:\/\/ow.ly\/ag6fD",
        "display_url" : "ow.ly\/ag6fD"
      } ]
    },
    "geo" : { },
    "id_str" : "190798548701425664",
    "text" : "Join our Google+ Hangout today live from the @WhiteHouse kitchen w\/ @gailsimmons & WH Chef Cris Comerford: http:\/\/t.co\/e1OTbOqA #AskLetsMove",
    "id" : 190798548701425664,
    "created_at" : "2012-04-13 13:48:13 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 190798618398171136,
  "created_at" : "2012-04-13 13:48:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Moore",
      "screen_name" : "CMPraysmilin",
      "indices" : [ 3, 16 ],
      "id_str" : "164841512",
      "id" : 164841512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190590752076742661",
  "text" : "RT @CMPraysmilin: SHAME over 16,000 millionaires pay a lower tax rate than ME! I'm with President Obama on the #BuffettRule: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffettRule",
        "indices" : [ 93, 105 ]
      }, {
        "text" : "FairShare",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/KeznrO5k",
        "expanded_url" : "http:\/\/wh.gov\/QcP",
        "display_url" : "wh.gov\/QcP"
      } ]
    },
    "geo" : { },
    "id_str" : "190590395279880193",
    "text" : "SHAME over 16,000 millionaires pay a lower tax rate than ME! I'm with President Obama on the #BuffettRule: http:\/\/t.co\/KeznrO5k #FairShare",
    "id" : 190590395279880193,
    "created_at" : "2012-04-13 00:01:05 +0000",
    "user" : {
      "name" : "Michele Moore",
      "screen_name" : "CMPraysmilin",
      "protected" : false,
      "id_str" : "164841512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1065851091\/me_normal.jpg",
      "id" : 164841512,
      "verified" : false
    }
  },
  "id" : 190590752076742661,
  "created_at" : "2012-04-13 00:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 36, 48 ]
    }, {
      "text" : "fairshare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/GC8R7uvP",
      "expanded_url" : "http:\/\/youtu.be\/Nsl_RL_dxX0",
      "display_url" : "youtu.be\/Nsl_RL_dxX0"
    } ]
  },
  "geo" : { },
  "id_str" : "190585866924736512",
  "text" : "Watch: President Obama explains the #BuffettRule in 1-min: http:\/\/t.co\/GC8R7uvP RT if you agree wealthiest Americans should pay #fairshare",
  "id" : 190585866924736512,
  "created_at" : "2012-04-12 23:43:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190578849883488257",
  "text" : "RT @Jamesnewsintern: 37,600 millionaires pay a lower tax rate than I do. I'm with President Obama on the #BuffettRule: http:\/\/t.co\/EV2k6 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffettRule",
        "indices" : [ 84, 96 ]
      }, {
        "text" : "FairShare",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/EV2k6ZSk",
        "expanded_url" : "http:\/\/wh.gov\/QcP",
        "display_url" : "wh.gov\/QcP"
      } ]
    },
    "geo" : { },
    "id_str" : "190577193292808193",
    "text" : "37,600 millionaires pay a lower tax rate than I do. I'm with President Obama on the #BuffettRule: http:\/\/t.co\/EV2k6ZSk #FairShare",
    "id" : 190577193292808193,
    "created_at" : "2012-04-12 23:08:38 +0000",
    "user" : {
      "name" : "James Williams",
      "screen_name" : "JamesfromUtah",
      "protected" : false,
      "id_str" : "139853621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711378572426870785\/HSMUuhe7_normal.jpg",
      "id" : 139853621,
      "verified" : false
    }
  },
  "id" : 190578849883488257,
  "created_at" : "2012-04-12 23:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/190578262324412417\/photo\/1",
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/yJFR6kcY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqUR63wCAAIW4vQ.jpg",
      "id_str" : "190578262328606722",
      "id" : 190578262328606722,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqUR63wCAAIW4vQ.jpg",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/yJFR6kcY"
    } ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/DNYeimZi",
      "expanded_url" : "http:\/\/wh.gov\/Uit",
      "display_url" : "wh.gov\/Uit"
    } ]
  },
  "geo" : { },
  "id_str" : "190578262324412417",
  "text" : "What's your Buffett number? http:\/\/t.co\/DNYeimZi #BuffettRule http:\/\/t.co\/yJFR6kcY",
  "id" : 190578262324412417,
  "created_at" : "2012-04-12 23:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Davidson",
      "screen_name" : "RunnerSD27",
      "indices" : [ 3, 14 ],
      "id_str" : "22330964",
      "id" : 22330964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190567498993770497",
  "text" : "RT @RunnerSD27: Did calculator thingy. I paid 12% effective tax rate. 11,800 millionaires smaller rate than me. #BuffettRule http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffettRule",
        "indices" : [ 96, 108 ]
      }, {
        "text" : "FairShare",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/19oSTTHO",
        "expanded_url" : "http:\/\/wh.gov\/QcP",
        "display_url" : "wh.gov\/QcP"
      } ]
    },
    "geo" : { },
    "id_str" : "190561865825402880",
    "text" : "Did calculator thingy. I paid 12% effective tax rate. 11,800 millionaires smaller rate than me. #BuffettRule http:\/\/t.co\/19oSTTHO #FairShare",
    "id" : 190561865825402880,
    "created_at" : "2012-04-12 22:07:43 +0000",
    "user" : {
      "name" : "Sarah Davidson",
      "screen_name" : "RunnerSD27",
      "protected" : false,
      "id_str" : "22330964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3212246126\/7945c4973a44fe4249c404ea10a92703_normal.jpeg",
      "id" : 22330964,
      "verified" : false
    }
  },
  "id" : 190567498993770497,
  "created_at" : "2012-04-12 22:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/pXn56o47",
      "expanded_url" : "http:\/\/bit.ly\/HB00Qk",
      "display_url" : "bit.ly\/HB00Qk"
    } ]
  },
  "geo" : { },
  "id_str" : "190567106910228480",
  "text" : "RT @arneduncan: Caine is an amazing kid. Brought tears to my eyes. Kids like this are why I'm hopeful for the future. http:\/\/t.co\/pXn56o47",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/pXn56o47",
        "expanded_url" : "http:\/\/bit.ly\/HB00Qk",
        "display_url" : "bit.ly\/HB00Qk"
      } ]
    },
    "geo" : { },
    "id_str" : "190562926183190528",
    "text" : "Caine is an amazing kid. Brought tears to my eyes. Kids like this are why I'm hopeful for the future. http:\/\/t.co\/pXn56o47",
    "id" : 190562926183190528,
    "created_at" : "2012-04-12 22:11:56 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 190567106910228480,
  "created_at" : "2012-04-12 22:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOOD",
      "screen_name" : "good",
      "indices" : [ 3, 8 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/bQIe5nPE",
      "expanded_url" : "http:\/\/bit.ly\/IzcELL",
      "display_url" : "bit.ly\/IzcELL"
    } ]
  },
  "geo" : { },
  "id_str" : "190536586637746177",
  "text" : "RT @GOOD: Watch our livestream Google hang out with White House economic wonk Jason Furman http:\/\/t.co\/bQIe5nPE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.good.is\" rel=\"nofollow\"\u003EGOOD\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/bQIe5nPE",
        "expanded_url" : "http:\/\/bit.ly\/IzcELL",
        "display_url" : "bit.ly\/IzcELL"
      } ]
    },
    "geo" : { },
    "id_str" : "190529305443442688",
    "text" : "Watch our livestream Google hang out with White House economic wonk Jason Furman http:\/\/t.co\/bQIe5nPE",
    "id" : 190529305443442688,
    "created_at" : "2012-04-12 19:58:20 +0000",
    "user" : {
      "name" : "GOOD",
      "screen_name" : "good",
      "protected" : false,
      "id_str" : "19621110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788475811498110976\/oKQWUsAP_normal.jpg",
      "id" : 19621110,
      "verified" : true
    }
  },
  "id" : 190536586637746177,
  "created_at" : "2012-04-12 20:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "190533058087239680",
  "text" : "Happening now: White House Google+ Hangout on the Buffett Rule with Jason Furman http:\/\/t.co\/u95y7hhB",
  "id" : 190533058087239680,
  "created_at" : "2012-04-12 20:13:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gleason",
      "screen_name" : "bgdeuce13",
      "indices" : [ 3, 13 ],
      "id_str" : "377349803",
      "id" : 377349803
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 84, 96 ]
    }, {
      "text" : "fairshare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190480824737607680",
  "text" : "RT @bgdeuce13: 1000s of millionaires pay a lower rate than I do. I'm w\/ Prez on the #BuffettRule everyone should pay their #fairshare: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuffettRule",
        "indices" : [ 69, 81 ]
      }, {
        "text" : "fairshare",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/tcmLF1CF",
        "expanded_url" : "http:\/\/wh.gov\/QcP",
        "display_url" : "wh.gov\/QcP"
      } ]
    },
    "geo" : { },
    "id_str" : "190480031087202304",
    "text" : "1000s of millionaires pay a lower rate than I do. I'm w\/ Prez on the #BuffettRule everyone should pay their #fairshare: http:\/\/t.co\/tcmLF1CF",
    "id" : 190480031087202304,
    "created_at" : "2012-04-12 16:42:33 +0000",
    "user" : {
      "name" : "Bill Gleason",
      "screen_name" : "bgdeuce13",
      "protected" : false,
      "id_str" : "377349803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771110061020250112\/opeqYfOf_normal.jpg",
      "id" : 377349803,
      "verified" : false
    }
  },
  "id" : 190480824737607680,
  "created_at" : "2012-04-12 16:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/3AICfsCK",
      "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
      "display_url" : "wh.gov\/buffett-rule"
    } ]
  },
  "geo" : { },
  "id_str" : "190477539385417729",
  "text" : "Guess how many millionaires pay a lower tax rate than you [HINT: It's at least 5,000] Try our #BuffettRule calculator: http:\/\/t.co\/3AICfsCK",
  "id" : 190477539385417729,
  "created_at" : "2012-04-12 16:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Livia Enomoto",
      "screen_name" : "liviaenomoto",
      "indices" : [ 13, 26 ],
      "id_str" : "344863671",
      "id" : 344863671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190470659497922560",
  "text" : "RT @WHLive: .@liviaenomoto Economic ties to support job creation\/growth in US & region, reduce crime\/violence, defend shared democratic  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Livia Enomoto",
        "screen_name" : "liviaenomoto",
        "indices" : [ 1, 14 ],
        "id_str" : "344863671",
        "id" : 344863671
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190468060115767296",
    "text" : ".@liviaenomoto Economic ties to support job creation\/growth in US & region, reduce crime\/violence, defend shared democratic values #WHChat",
    "id" : 190468060115767296,
    "created_at" : "2012-04-12 15:54:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 190470659497922560,
  "created_at" : "2012-04-12 16:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 117, 124 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 127, 140 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190461463780007936",
  "text" : "Starting soon: Dan Restrepo answers questions about the upcoming Summit of the Americas. Ask now w\/ #WHChat. Follow: @WHLive & @LaCasaBlanca",
  "id" : 190461463780007936,
  "created_at" : "2012-04-12 15:28:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettNumber",
      "indices" : [ 12, 26 ]
    }, {
      "text" : "BuffettRule",
      "indices" : [ 73, 85 ]
    }, {
      "text" : "fairness",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/LYadubRe",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/economy\/buffett-rule",
      "display_url" : "whitehouse.gov\/economy\/buffet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190447350936907776",
  "text" : "What's your #BuffettNumber? http:\/\/t.co\/LYadubRe It may surprise you ... #BuffettRule Buffett Rule #fairness",
  "id" : 190447350936907776,
  "created_at" : "2012-04-12 14:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 96, 103 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 106, 119 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericasConf",
      "indices" : [ 58, 71 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/vOhp7seX",
      "expanded_url" : "http:\/\/ow.ly\/aeuwA",
      "display_url" : "ow.ly\/aeuwA"
    } ]
  },
  "geo" : { },
  "id_str" : "190434579386089472",
  "text" : "Office Hours today @ 11:30am: Dan Restrepo answers Q's on #AmericasConf. Ask w\/ #WHChat. Follow @WHLive & @LaCasaBlanca http:\/\/t.co\/vOhp7seX",
  "id" : 190434579386089472,
  "created_at" : "2012-04-12 13:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/190264396109451265\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/orYrYtda",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqP0dc_CEAAx9Pw.jpg",
      "id_str" : "190264396113645568",
      "id" : 190264396113645568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqP0dc_CEAAx9Pw.jpg",
      "sizes" : [ {
        "h" : 723,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1932
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/orYrYtda"
    } ],
    "hashtags" : [ {
      "text" : "HighFive",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190264396109451265",
  "text" : "Photo of the Day: President Obama gets a #HighFive outside an event in Palm Beach Garden, Florida: http:\/\/t.co\/orYrYtda",
  "id" : 190264396109451265,
  "created_at" : "2012-04-12 02:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190263029571661827",
  "text" : "RT @JoiningForces: Tonight First Lady Michelle Obama stops by the @ColbertReport to talk about #JoiningForces & supporting our military  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 76, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190262801816752128",
    "text" : "Tonight First Lady Michelle Obama stops by the @ColbertReport to talk about #JoiningForces & supporting our military families.",
    "id" : 190262801816752128,
    "created_at" : "2012-04-12 02:19:21 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 190263029571661827,
  "created_at" : "2012-04-12 02:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 27, 35 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/4PHTkp3U",
      "expanded_url" : "http:\/\/youtu.be\/HDTVFCTQLCo",
      "display_url" : "youtu.be\/HDTVFCTQLCo"
    } ]
  },
  "geo" : { },
  "id_str" : "190251836157075456",
  "text" : "Watch: MO Air Guard band & @YouTube hit Sidewinder performs at #JoiningForces 1 yr anniv at the @WhiteHouse: http:\/\/t.co\/4PHTkp3U",
  "id" : 190251836157075456,
  "created_at" : "2012-04-12 01:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/190184256226598915\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/6HrZAsoI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqOrksrCIAE9RH0.jpg",
      "id_str" : "190184256234987521",
      "id" : 190184256234987521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqOrksrCIAE9RH0.jpg",
      "sizes" : [ {
        "h" : 596,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6HrZAsoI"
    } ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190184256226598915",
  "text" : "Nearly one-quarter of all millionaires pay a lower tax rate than millions of middle-class families #BuffettRule http:\/\/t.co\/6HrZAsoI",
  "id" : 190184256226598915,
  "created_at" : "2012-04-11 21:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Gail Simmons",
      "screen_name" : "gailsimmons",
      "indices" : [ 35, 47 ],
      "id_str" : "21915666",
      "id" : 21915666
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskLetsMove",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190182280080277505",
  "text" : "RT @letsmove: Want to Hangout with @gailsimmons & the @WhiteHouse Chef? Join our Google+ Hangout on 4\/13 & ask Qs with #AskLetsMove http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gail Simmons",
        "screen_name" : "gailsimmons",
        "indices" : [ 21, 33 ],
        "id_str" : "21915666",
        "id" : 21915666
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskLetsMove",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/GwMxwRWO",
        "expanded_url" : "http:\/\/ow.ly\/admv9",
        "display_url" : "ow.ly\/admv9"
      } ]
    },
    "geo" : { },
    "id_str" : "190129781700964352",
    "text" : "Want to Hangout with @gailsimmons & the @WhiteHouse Chef? Join our Google+ Hangout on 4\/13 & ask Qs with #AskLetsMove http:\/\/t.co\/GwMxwRWO",
    "id" : 190129781700964352,
    "created_at" : "2012-04-11 17:30:47 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 190182280080277505,
  "created_at" : "2012-04-11 20:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 31, 40 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/OuijS8y3",
      "expanded_url" : "http:\/\/wh.gov\/QzE",
      "display_url" : "wh.gov\/QzE"
    } ]
  },
  "geo" : { },
  "id_str" : "190171509120172032",
  "text" : "RT @jesseclee44: New post from @PressSec fleshes it out: \"The Buffett Rule (aka The Reagan Rule)\" http:\/\/t.co\/OuijS8y3 #fairshare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 14, 23 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/OuijS8y3",
        "expanded_url" : "http:\/\/wh.gov\/QzE",
        "display_url" : "wh.gov\/QzE"
      } ]
    },
    "geo" : { },
    "id_str" : "190170780791877633",
    "text" : "New post from @PressSec fleshes it out: \"The Buffett Rule (aka The Reagan Rule)\" http:\/\/t.co\/OuijS8y3 #fairshare",
    "id" : 190170780791877633,
    "created_at" : "2012-04-11 20:13:42 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 190171509120172032,
  "created_at" : "2012-04-11 20:16:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReaganRule",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "BuffettRule",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190171448759943168",
  "text" : "Obama: \"If it will help convince folks in Congress to make the right choice, we could call it the #ReaganRule instead of the #BuffettRule\"",
  "id" : 190171448759943168,
  "created_at" : "2012-04-11 20:16:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 133, 140 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190152410163986434",
  "text" : "Starting soon: The National Economic Council's Brian Deese answers your questions on the #BuffettRule. Ask now using #WHChat. Follow @WHLive",
  "id" : 190152410163986434,
  "created_at" : "2012-04-11 19:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "indices" : [ 3, 15 ],
      "id_str" : "31127446",
      "id" : 31127446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190108211511177216",
  "text" : "RT @markknoller: On June 6, 1985, Pres Reagan called for change in tax code \"that have allowed some of the truly wealthy to avoid paying ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "190107244690538498",
    "text" : "On June 6, 1985, Pres Reagan called for change in tax code \"that have allowed some of the truly wealthy to avoid paying their fair share.\"",
    "id" : 190107244690538498,
    "created_at" : "2012-04-11 16:01:13 +0000",
    "user" : {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "protected" : false,
      "id_str" : "31127446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/137394623\/knoller_normal.jpg",
      "id" : 31127446,
      "verified" : true
    }
  },
  "id" : 190108211511177216,
  "created_at" : "2012-04-11 16:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190102526287282176",
  "text" : "RT @jearnest44: NEW VIDEO: Brian Deese rolls out the White Board to explain why Buffett Rule matters #fairshare  Check it out: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/eE11AGPG",
        "expanded_url" : "http:\/\/youtu.be\/PLl7Of0cwnY",
        "display_url" : "youtu.be\/PLl7Of0cwnY"
      } ]
    },
    "geo" : { },
    "id_str" : "190071568716668928",
    "text" : "NEW VIDEO: Brian Deese rolls out the White Board to explain why Buffett Rule matters #fairshare  Check it out: http:\/\/t.co\/eE11AGPG",
    "id" : 190071568716668928,
    "created_at" : "2012-04-11 13:39:27 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 190102526287282176,
  "created_at" : "2012-04-11 15:42:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 127, 134 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 25, 37 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190092744562180097",
  "text" : "Have questions about the #BuffettRule? Join NEC\u2019s Brian Deese for Office Hours today at 3pm EDT. Ask your Q w\/ #WHChat. Follow @WHLive",
  "id" : 190092744562180097,
  "created_at" : "2012-04-11 15:03:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 112, 123 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sidewinder",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190088716491038721",
  "text" : "RT @JoiningForces: Happening Now: Air Force Band & YouTube sensation #Sidewinder performing from the South Lawn @whitehouse watch live:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 93, 104 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sidewinder",
        "indices" : [ 50, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/TnHxhX8v",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "190088564271362049",
    "text" : "Happening Now: Air Force Band & YouTube sensation #Sidewinder performing from the South Lawn @whitehouse watch live: http:\/\/t.co\/TnHxhX8v",
    "id" : 190088564271362049,
    "created_at" : "2012-04-11 14:47:00 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 190088716491038721,
  "created_at" : "2012-04-11 14:47:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 105, 117 ]
    }, {
      "text" : "ReaganRule",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190086040965496832",
  "text" : "President Obama: If it\u2019ll help convince folks in Congress to make the right choice, we can even call the #BuffettRule the #ReaganRule.",
  "id" : 190086040965496832,
  "created_at" : "2012-04-11 14:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 106, 113 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "fairshare",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "190077986479931393",
  "text" : "Starting at 10:15 am EDT: President Obama speaks on the #BuffettRule. Watch: http:\/\/t.co\/u95y7hhB follow: @WHLive #fairshare",
  "id" : 190077986479931393,
  "created_at" : "2012-04-11 14:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim de Jong",
      "screen_name" : "TimdeJ86",
      "indices" : [ 0, 9 ],
      "id_str" : "491427110",
      "id" : 491427110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 66, 78 ]
    }, {
      "text" : "fairshare",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/vUwkhBmA",
      "expanded_url" : "http:\/\/youtu.be\/nRuWMoEWE1E",
      "display_url" : "youtu.be\/nRuWMoEWE1E"
    } ]
  },
  "in_reply_to_status_id_str" : "190074140798107651",
  "geo" : { },
  "id_str" : "190076090419642369",
  "in_reply_to_user_id" : 491427110,
  "text" : "@TimdeJ86 Check out President Reagan's take: http:\/\/t.co\/vUwkhBmA #BuffettRule #fairshare",
  "id" : 190076090419642369,
  "in_reply_to_status_id" : 190074140798107651,
  "created_at" : "2012-04-11 13:57:26 +0000",
  "in_reply_to_screen_name" : "TimdeJ86",
  "in_reply_to_user_id_str" : "491427110",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 42, 52 ]
    }, {
      "text" : "BuffettRule",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/u8bIzpFC",
      "expanded_url" : "http:\/\/youtu.be\/PLl7Of0cwnY",
      "display_url" : "youtu.be\/PLl7Of0cwnY"
    } ]
  },
  "geo" : { },
  "id_str" : "190069456632954880",
  "text" : "What's Buffett Rule? Means wealthiest pay #fairshare, not \u2193 tax rate than middle class. Video: http:\/\/t.co\/u8bIzpFC #BuffettRule",
  "id" : 190069456632954880,
  "created_at" : "2012-04-11 13:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 40, 51 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/TnHxhX8v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "190059883347972096",
  "text" : "RT @JoiningForces: Sidewinder is at the @whitehouse! Watch live performance @ 10:40ET at http:\/\/t.co\/TnHxhX8v Sound check happening now: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/190059033980444672\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/eIE31qN2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AqM5rzdCIAEV3xH.jpg",
        "id_str" : "190059033988833281",
        "id" : 190059033988833281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqM5rzdCIAEV3xH.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/eIE31qN2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/TnHxhX8v",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "190059033980444672",
    "text" : "Sidewinder is at the @whitehouse! Watch live performance @ 10:40ET at http:\/\/t.co\/TnHxhX8v Sound check happening now: http:\/\/t.co\/eIE31qN2",
    "id" : 190059033980444672,
    "created_at" : "2012-04-11 12:49:40 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 190059883347972096,
  "created_at" : "2012-04-11 12:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 78, 89 ],
      "id_str" : "19611483",
      "id" : 19611483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189880887712817154",
  "text" : "RT @JoiningForces: First Lady kicks off #JoiningForces 1yr anniv at the WH w\/ @usairforce band Sidewinder. Don't miss it on 4\/11 @ 10:40 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Air Force",
        "screen_name" : "usairforce",
        "indices" : [ 59, 70 ],
        "id_str" : "19611483",
        "id" : 19611483
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 21, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/TnHxhX8v",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "189880823653203969",
    "text" : "First Lady kicks off #JoiningForces 1yr anniv at the WH w\/ @usairforce band Sidewinder. Don't miss it on 4\/11 @ 10:40ET http:\/\/t.co\/TnHxhX8v",
    "id" : 189880823653203969,
    "created_at" : "2012-04-11 01:01:30 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 189880887712817154,
  "created_at" : "2012-04-11 01:01:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/Gg770i0K",
      "expanded_url" : "http:\/\/youtu.be\/jeWBKAl437w",
      "display_url" : "youtu.be\/jeWBKAl437w"
    } ]
  },
  "geo" : { },
  "id_str" : "189870214681337856",
  "text" : "\"Don\u2019t give tax breaks to folks like me who don\u2019t need them\" -President Obama on why we need the #BuffettRule: http:\/\/t.co\/Gg770i0K",
  "id" : 189870214681337856,
  "created_at" : "2012-04-11 00:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BiggestLoser",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189864874753523714",
  "text" : "RT @letsmove: First Lady Michelle Obama challenges #BiggestLoser contestants to help America get fit! Don't miss tonight's episode @ 8\/7 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBC",
        "screen_name" : "nbc",
        "indices" : [ 127, 131 ],
        "id_str" : "26585095",
        "id" : 26585095
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BiggestLoser",
        "indices" : [ 37, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189864768205627394",
    "text" : "First Lady Michelle Obama challenges #BiggestLoser contestants to help America get fit! Don't miss tonight's episode @ 8\/7c on @NBC",
    "id" : 189864768205627394,
    "created_at" : "2012-04-10 23:57:42 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 189864874753523714,
  "created_at" : "2012-04-10 23:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189842525455003650",
  "text" : "RT @jearnest44: TMRW: POTUS talks Buffett Rule @whitehouse w millionaires & their secretaries who back principle of fairness. Will GOP S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 31, 42 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189842392919179264",
    "text" : "TMRW: POTUS talks Buffett Rule @whitehouse w millionaires & their secretaries who back principle of fairness. Will GOP Senators? #fairshare",
    "id" : 189842392919179264,
    "created_at" : "2012-04-10 22:28:48 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 189842525455003650,
  "created_at" : "2012-04-10 22:29:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "indices" : [ 3, 13 ],
      "id_str" : "22012091",
      "id" : 22012091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189816724206534656",
  "text" : "RT @WhipHoyer: Agree w POTUS, we need to make investments in our future, reduce deficit in a balanced way that asks all Americans to pay ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189809158692941825",
    "text" : "Agree w POTUS, we need to make investments in our future, reduce deficit in a balanced way that asks all Americans to pay their #fairshare",
    "id" : 189809158692941825,
    "created_at" : "2012-04-10 20:16:44 +0000",
    "user" : {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "protected" : false,
      "id_str" : "22012091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742490369347203072\/WLvGn-ia_normal.jpg",
      "id" : 22012091,
      "verified" : true
    }
  },
  "id" : 189816724206534656,
  "created_at" : "2012-04-10 20:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/19X9QUrB",
      "expanded_url" : "http:\/\/youtu.be\/yObsfSgeTsY",
      "display_url" : "youtu.be\/yObsfSgeTsY"
    } ]
  },
  "geo" : { },
  "id_str" : "189814357662777345",
  "text" : "RT @letsmove: Time-Lapse Video: The 2012 @WhiteHouse #EasterEggRoll in less than 2 minutes. Enjoy! http:\/\/t.co\/19X9QUrB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 27, 38 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 39, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/19X9QUrB",
        "expanded_url" : "http:\/\/youtu.be\/yObsfSgeTsY",
        "display_url" : "youtu.be\/yObsfSgeTsY"
      } ]
    },
    "geo" : { },
    "id_str" : "189807252935409664",
    "text" : "Time-Lapse Video: The 2012 @WhiteHouse #EasterEggRoll in less than 2 minutes. Enjoy! http:\/\/t.co\/19X9QUrB",
    "id" : 189807252935409664,
    "created_at" : "2012-04-10 20:09:10 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 189814357662777345,
  "created_at" : "2012-04-10 20:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189798398457688065",
  "text" : "RT @WHLive: President Obama: \"You might have heard this, but Warren Buffett is paying a lower tax rate than his secretary. It isn\u2019t fair ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189798358276243456",
    "text" : "President Obama: \"You might have heard this, but Warren Buffett is paying a lower tax rate than his secretary. It isn\u2019t fair.\" #fairshare",
    "id" : 189798358276243456,
    "created_at" : "2012-04-10 19:33:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 189798398457688065,
  "created_at" : "2012-04-10 19:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189795090242342912",
  "text" : "RT @WHLive: President Obama: \"America isn\u2019t about a few people doing well. It\u2019s about giving everyone the chance to do well\" #fairshare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189795052434890752",
    "text" : "President Obama: \"America isn\u2019t about a few people doing well. It\u2019s about giving everyone the chance to do well\" #fairshare",
    "id" : 189795052434890752,
    "created_at" : "2012-04-10 19:20:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 189795090242342912,
  "created_at" : "2012-04-10 19:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dealscow",
      "screen_name" : "FlaAtlanticU",
      "indices" : [ 58, 71 ],
      "id_str" : "2759318817",
      "id" : 2759318817
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 108, 115 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 45, 57 ]
    }, {
      "text" : "fairshare",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "189790107438551040",
  "text" : "Happening now: President Obama speaks on the #BuffettRule @FlaAtlanticU Watch: http:\/\/t.co\/u95y7hhB Follow: @WHLive #fairshare",
  "id" : 189790107438551040,
  "created_at" : "2012-04-10 19:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam",
      "screen_name" : "ChiProg",
      "indices" : [ 3, 11 ],
      "id_str" : "31860167",
      "id" : 31860167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189779811680530432",
  "text" : "RT @ChiProg: I pay my #fairshare in taxes and the wealthy should too. We need the Buffett rule.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 9, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189771387655819264",
    "text" : "I pay my #fairshare in taxes and the wealthy should too. We need the Buffett rule.",
    "id" : 189771387655819264,
    "created_at" : "2012-04-10 17:46:39 +0000",
    "user" : {
      "name" : "Adam",
      "screen_name" : "ChiProg",
      "protected" : false,
      "id_str" : "31860167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454654070469320704\/DmufjwPR_normal.jpeg",
      "id" : 31860167,
      "verified" : false
    }
  },
  "id" : 189779811680530432,
  "created_at" : "2012-04-10 18:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "HHSLatino",
      "screen_name" : "HHSLatino",
      "indices" : [ 33, 43 ],
      "id_str" : "380530330",
      "id" : 380530330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaSaludLatina",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/qmGhd01E",
      "expanded_url" : "http:\/\/1.usa.gov\/IgO7Jy",
      "display_url" : "1.usa.gov\/IgO7Jy"
    } ]
  },
  "geo" : { },
  "id_str" : "189766473600872450",
  "text" : "RT @HHSGov: TODAY! 2pm EST, join @HHSLatino for a Twitter chat IN SPANISH abt  Latino health http:\/\/t.co\/qmGhd01E Q's to #LaSaludLatina",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHSLatino",
        "screen_name" : "HHSLatino",
        "indices" : [ 21, 31 ],
        "id_str" : "380530330",
        "id" : 380530330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LaSaludLatina",
        "indices" : [ 109, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/qmGhd01E",
        "expanded_url" : "http:\/\/1.usa.gov\/IgO7Jy",
        "display_url" : "1.usa.gov\/IgO7Jy"
      } ]
    },
    "geo" : { },
    "id_str" : "189736960984743936",
    "text" : "TODAY! 2pm EST, join @HHSLatino for a Twitter chat IN SPANISH abt  Latino health http:\/\/t.co\/qmGhd01E Q's to #LaSaludLatina",
    "id" : 189736960984743936,
    "created_at" : "2012-04-10 15:29:51 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 189766473600872450,
  "created_at" : "2012-04-10 17:27:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam Goldrick",
      "screen_name" : "lgoldrick25",
      "indices" : [ 3, 15 ],
      "id_str" : "36101852",
      "id" : 36101852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189751447510978562",
  "text" : "RT @lgoldrick25: 1470 people paid no federal income tax on $1 million incomes in 2009. The Buffett Rule will change that: http:\/\/t.co\/BQ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/BQ9mFVsy",
        "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
        "display_url" : "wh.gov\/buffett-rule"
      } ]
    },
    "geo" : { },
    "id_str" : "189750862611095552",
    "text" : "1470 people paid no federal income tax on $1 million incomes in 2009. The Buffett Rule will change that: http:\/\/t.co\/BQ9mFVsy #fairshare",
    "id" : 189750862611095552,
    "created_at" : "2012-04-10 16:25:05 +0000",
    "user" : {
      "name" : "Liam Goldrick",
      "screen_name" : "lgoldrick25",
      "protected" : false,
      "id_str" : "36101852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674464039339094016\/6Ms-bCmL_normal.jpg",
      "id" : 36101852,
      "verified" : false
    }
  },
  "id" : 189751447510978562,
  "created_at" : "2012-04-10 16:27:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YaVon Best",
      "screen_name" : "Yavon",
      "indices" : [ 3, 9 ],
      "id_str" : "18536921",
      "id" : 18536921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/Kwtrri6H",
      "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
      "display_url" : "wh.gov\/buffett-rule"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Z1en2I8Y",
      "expanded_url" : "http:\/\/fb.me\/1duUNsDDl",
      "display_url" : "fb.me\/1duUNsDDl"
    } ]
  },
  "geo" : { },
  "id_str" : "189748074397184001",
  "text" : "RT @Yavon: You pay your #fairshare in taxes & the wealthiest Americans should, too: http:\/\/t.co\/Kwtrri6H... http:\/\/t.co\/Z1en2I8Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/Kwtrri6H",
        "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
        "display_url" : "wh.gov\/buffett-rule"
      }, {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/Z1en2I8Y",
        "expanded_url" : "http:\/\/fb.me\/1duUNsDDl",
        "display_url" : "fb.me\/1duUNsDDl"
      } ]
    },
    "geo" : { },
    "id_str" : "189716005356969985",
    "text" : "You pay your #fairshare in taxes & the wealthiest Americans should, too: http:\/\/t.co\/Kwtrri6H... http:\/\/t.co\/Z1en2I8Y",
    "id" : 189716005356969985,
    "created_at" : "2012-04-10 14:06:35 +0000",
    "user" : {
      "name" : "YaVon Best",
      "screen_name" : "Yavon",
      "protected" : false,
      "id_str" : "18536921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2110126812\/profile_normal.jpg",
      "id" : 18536921,
      "verified" : false
    }
  },
  "id" : 189748074397184001,
  "created_at" : "2012-04-10 16:14:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 4, 15 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/sIpDaYJi",
      "expanded_url" : "http:\/\/ow.ly\/abze3",
      "display_url" : "ow.ly\/abze3"
    } ]
  },
  "geo" : { },
  "id_str" : "189747664110366720",
  "text" : "New @WhiteHouse Report: The Buffett Rule: A Basic Principal of Tax Fairness: http:\/\/t.co\/sIpDaYJi #fairshare",
  "id" : 189747664110366720,
  "created_at" : "2012-04-10 16:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 52, 67 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189728435692773379",
  "text" : "RT @pfeiffer44: Fmr. Bush Admin official bamboozles @washingtonpost with \"new math\". Get the facts: health reform reduces the deficit ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 36, 51 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/eKInoC8Y",
        "expanded_url" : "http:\/\/goo.gl\/Fs8xe",
        "display_url" : "goo.gl\/Fs8xe"
      } ]
    },
    "geo" : { },
    "id_str" : "189728025590509570",
    "text" : "Fmr. Bush Admin official bamboozles @washingtonpost with \"new math\". Get the facts: health reform reduces the deficit http:\/\/t.co\/eKInoC8Y",
    "id" : 189728025590509570,
    "created_at" : "2012-04-10 14:54:20 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 189728435692773379,
  "created_at" : "2012-04-10 14:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189704588222410752",
  "text" : "President Obama heads to Florida today to talk about the Buffett Rule & ensuring that everyone gets a fair shot & pays their #fairshare",
  "id" : 189704588222410752,
  "created_at" : "2012-04-10 13:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/189528141457399808\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/9uG6tRms",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqFW1yrCIAAVZpQ.jpg",
      "id_str" : "189528141461594112",
      "id" : 189528141461594112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqFW1yrCIAAVZpQ.jpg",
      "sizes" : [ {
        "h" : 1187,
        "resize" : "fit",
        "w" : 1782
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9uG6tRms"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/8GkNKFNa",
      "expanded_url" : "http:\/\/wh.gov\/QVD",
      "display_url" : "wh.gov\/QVD"
    } ]
  },
  "geo" : { },
  "id_str" : "189528141457399808",
  "text" : "Photo of the Day: President Obama does push ups on WH b-ball court. More #EasterEggRoll pics: http:\/\/t.co\/8GkNKFNa http:\/\/t.co\/9uG6tRms",
  "id" : 189528141457399808,
  "created_at" : "2012-04-10 01:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 25, 37 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/H8s91xX1",
      "expanded_url" : "http:\/\/ow.ly\/aax2G",
      "display_url" : "ow.ly\/aax2G"
    } ]
  },
  "geo" : { },
  "id_str" : "189475878126895104",
  "text" : "Have questions about the #BuffettRule? NEC's Brian Deese will answer during Office Hours on 4\/11. Ask away w\/ #WHChat http:\/\/t.co\/H8s91xX1",
  "id" : 189475878126895104,
  "created_at" : "2012-04-09 22:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Janelle Mon\u00E1e, Cindi",
      "screen_name" : "JanelleMonae",
      "indices" : [ 29, 42 ],
      "id_str" : "12266442",
      "id" : 12266442
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Do631pPw",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "189428723060191232",
  "text" : "RT @letsmove: Happening now: @JanelleMonae performs at the @WhiteHouse #EasterEggRoll. Watch live: http:\/\/t.co\/Do631pPw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Janelle Mon\u00E1e, Cindi",
        "screen_name" : "JanelleMonae",
        "indices" : [ 15, 28 ],
        "id_str" : "12266442",
        "id" : 12266442
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 45, 56 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 57, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/Do631pPw",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "189428567959011328",
    "text" : "Happening now: @JanelleMonae performs at the @WhiteHouse #EasterEggRoll. Watch live: http:\/\/t.co\/Do631pPw",
    "id" : 189428567959011328,
    "created_at" : "2012-04-09 19:04:24 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 189428723060191232,
  "created_at" : "2012-04-09 19:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Krieger",
      "screen_name" : "mikeyk",
      "indices" : [ 52, 59 ],
      "id_str" : "12831",
      "id" : 12831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/5saeMxLq",
      "expanded_url" : "http:\/\/youtu.be\/4-zCiATLbhg",
      "display_url" : "youtu.be\/4-zCiATLbhg"
    } ]
  },
  "geo" : { },
  "id_str" : "189419855303282689",
  "text" : "From the Archives: In January, Instagram co-founder @mikeyk joined the First Lady in her box at #SOTU & took a pic: http:\/\/t.co\/5saeMxLq",
  "id" : 189419855303282689,
  "created_at" : "2012-04-09 18:29:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Myy4syo7",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nRuWMoEWE1E&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=nRuWMo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "189410723275870208",
  "text" : "RT @jesseclee44: Video: Reagan on how \"wrong\" it is when CEOs pay lower tax rates than their secretaries: http:\/\/t.co\/Myy4syo7 #fairshare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/Myy4syo7",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nRuWMoEWE1E&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=nRuWMo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "189398398783340544",
    "text" : "Video: Reagan on how \"wrong\" it is when CEOs pay lower tax rates than their secretaries: http:\/\/t.co\/Myy4syo7 #fairshare",
    "id" : 189398398783340544,
    "created_at" : "2012-04-09 17:04:31 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 189410723275870208,
  "created_at" : "2012-04-09 17:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/189410280642576384\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/7S3W6pB2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AqDrpY7CAAAeSzh.jpg",
      "id_str" : "189410280646770688",
      "id" : 189410280646770688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqDrpY7CAAAeSzh.jpg",
      "sizes" : [ {
        "h" : 289,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 514
      } ],
      "display_url" : "pic.twitter.com\/7S3W6pB2"
    } ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/3AICfsCK",
      "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
      "display_url" : "wh.gov\/buffett-rule"
    } ]
  },
  "geo" : { },
  "id_str" : "189410280642576384",
  "text" : "You pay your #fairshare in taxes & the wealthiest Americans should, too: http:\/\/t.co\/3AICfsCK http:\/\/t.co\/7S3W6pB2",
  "id" : 189410280642576384,
  "created_at" : "2012-04-09 17:51:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joi-Marie",
      "screen_name" : "dcfab",
      "indices" : [ 3, 9 ],
      "id_str" : "16490235",
      "id" : 16490235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/vA9UEIr0",
      "expanded_url" : "http:\/\/instagr.am\/p\/JNGHJjyHB9\/",
      "display_url" : "instagr.am\/p\/JNGHJjyHB9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "189389406933762050",
  "text" : "RT @dcfab: Obama helps a young kiddie finish the #EasterEggRoll. Precious!  http:\/\/t.co\/vA9UEIr0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 38, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/vA9UEIr0",
        "expanded_url" : "http:\/\/instagr.am\/p\/JNGHJjyHB9\/",
        "display_url" : "instagr.am\/p\/JNGHJjyHB9\/"
      } ]
    },
    "geo" : { },
    "id_str" : "189380510357794816",
    "text" : "Obama helps a young kiddie finish the #EasterEggRoll. Precious!  http:\/\/t.co\/vA9UEIr0",
    "id" : 189380510357794816,
    "created_at" : "2012-04-09 15:53:26 +0000",
    "user" : {
      "name" : "Joi-Marie",
      "screen_name" : "dcfab",
      "protected" : false,
      "id_str" : "16490235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757406978981433344\/eTR8gWa3_normal.jpg",
      "id" : 16490235,
      "verified" : true
    }
  },
  "id" : 189389406933762050,
  "created_at" : "2012-04-09 16:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Marcus Samuelsson",
      "screen_name" : "MarcusCooks",
      "indices" : [ 46, 58 ],
      "id_str" : "65733755",
      "id" : 65733755
    }, {
      "name" : "Al Roker",
      "screen_name" : "alroker",
      "indices" : [ 61, 69 ],
      "id_str" : "16379018",
      "id" : 16379018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189376500473143296",
  "text" : "RT @letsmove: Happening now: Mrs. Obama joins @MarcusCooks & @alroker for a healthy cooking demo @ the WH #EasterEggRoll. Watch: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcus Samuelsson",
        "screen_name" : "MarcusCooks",
        "indices" : [ 32, 44 ],
        "id_str" : "65733755",
        "id" : 65733755
      }, {
        "name" : "Al Roker",
        "screen_name" : "alroker",
        "indices" : [ 47, 55 ],
        "id_str" : "16379018",
        "id" : 16379018
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/Do631pPw",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "189376430260502529",
    "text" : "Happening now: Mrs. Obama joins @MarcusCooks & @alroker for a healthy cooking demo @ the WH #EasterEggRoll. Watch: http:\/\/t.co\/Do631pPw",
    "id" : 189376430260502529,
    "created_at" : "2012-04-09 15:37:14 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 189376500473143296,
  "created_at" : "2012-04-09 15:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "189362922307325952",
  "text" : "Happening now: The President & First Lady speak at the 2012 White House #EasterEggRoll. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 189362922307325952,
  "created_at" : "2012-04-09 14:43:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "indices" : [ 3, 14 ],
      "id_str" : "374019904",
      "id" : 374019904
    }, {
      "name" : "Dominique Dawes",
      "screen_name" : "dominiquedawes",
      "indices" : [ 16, 31 ],
      "id_str" : "27815994",
      "id" : 27815994
    }, {
      "name" : "Al Roker",
      "screen_name" : "alroker",
      "indices" : [ 100, 108 ],
      "id_str" : "16379018",
      "id" : 16379018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189361376869888000",
  "text" : "RT @FitnessGov: @dominiquedawes and Michelle Kwan talking about the importance of being active with @alroker #EasterEggRoll http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dominique Dawes",
        "screen_name" : "dominiquedawes",
        "indices" : [ 0, 15 ],
        "id_str" : "27815994",
        "id" : 27815994
      }, {
        "name" : "Al Roker",
        "screen_name" : "alroker",
        "indices" : [ 84, 92 ],
        "id_str" : "16379018",
        "id" : 16379018
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FitnessGov\/status\/189327414831226880\/photo\/1",
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/flkziGLh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AqCgR9uCIAIgWD6.jpg",
        "id_str" : "189327414835421186",
        "id" : 189327414835421186,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AqCgR9uCIAIgWD6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/flkziGLh"
      } ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "189327414831226880",
    "in_reply_to_user_id" : 27815994,
    "text" : "@dominiquedawes and Michelle Kwan talking about the importance of being active with @alroker #EasterEggRoll http:\/\/t.co\/flkziGLh",
    "id" : 189327414831226880,
    "created_at" : "2012-04-09 12:22:28 +0000",
    "in_reply_to_screen_name" : "dominiquedawes",
    "in_reply_to_user_id_str" : "27815994",
    "user" : {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "protected" : false,
      "id_str" : "374019904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1544099616\/President_s_Council_Fitness_Sports_Nutrition_3Color_Logo_V2_normal.png",
      "id" : 374019904,
      "verified" : true
    }
  },
  "id" : 189361376869888000,
  "created_at" : "2012-04-09 14:37:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/Do631pPw",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "189344872770191360",
  "text" : "RT @letsmove: Happening now: @whitehouse #EasterEggRoll. Watch it all live: http:\/\/t.co\/Do631pPw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 27, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/Do631pPw",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "189344771507105792",
    "text" : "Happening now: @whitehouse #EasterEggRoll. Watch it all live: http:\/\/t.co\/Do631pPw",
    "id" : 189344771507105792,
    "created_at" : "2012-04-09 13:31:26 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 189344872770191360,
  "created_at" : "2012-04-09 13:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/68DvTwXn",
      "expanded_url" : "http:\/\/youtu.be\/Qig0DYKJo3U",
      "display_url" : "youtu.be\/Qig0DYKJo3U"
    } ]
  },
  "geo" : { },
  "id_str" : "189071493664219136",
  "text" : "President Obama: \"Michelle & I want to wish you a blessed & Happy Easter.\"  http:\/\/t.co\/68DvTwXn",
  "id" : 189071493664219136,
  "created_at" : "2012-04-08 19:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/68DvTwXn",
      "expanded_url" : "http:\/\/youtu.be\/Qig0DYKJo3U",
      "display_url" : "youtu.be\/Qig0DYKJo3U"
    } ]
  },
  "geo" : { },
  "id_str" : "188726897625141248",
  "text" : "\"Easter weekend is a time to reflect & rejoice\" -President Obama http:\/\/t.co\/68DvTwXn",
  "id" : 188726897625141248,
  "created_at" : "2012-04-07 20:36:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/188630083328675840\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/xJ9rryyq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ap4mD7cCEAEogjG.jpg",
      "id_str" : "188630083332870145",
      "id" : 188630083332870145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ap4mD7cCEAEogjG.jpg",
      "sizes" : [ {
        "h" : 1359,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xJ9rryyq"
    } ],
    "hashtags" : [ {
      "text" : "Passover",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188630083328675840",
  "text" : "Photo: The President & First Lady host #Passover Seder for family, staff & friends in the Old Family Dining Room: http:\/\/t.co\/xJ9rryyq",
  "id" : 188630083328675840,
  "created_at" : "2012-04-07 14:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/68DvTwXn",
      "expanded_url" : "http:\/\/youtu.be\/Qig0DYKJo3U",
      "display_url" : "youtu.be\/Qig0DYKJo3U"
    } ]
  },
  "geo" : { },
  "id_str" : "188626542245576705",
  "text" : "President Obama offers his warmest greetings to all who are celebrating Easter & Passover this weekend: http:\/\/t.co\/68DvTwXn",
  "id" : 188626542245576705,
  "created_at" : "2012-04-07 13:57:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/3B1UTr2K",
      "expanded_url" : "http:\/\/youtu.be\/M5Vt0NcZG2o",
      "display_url" : "youtu.be\/M5Vt0NcZG2o"
    } ]
  },
  "geo" : { },
  "id_str" : "188385442364796928",
  "text" : "\"Chag Sameach\" -President Obama wishes a happy holiday to all those celebrating Passover: http:\/\/t.co\/3B1UTr2K",
  "id" : 188385442364796928,
  "created_at" : "2012-04-06 21:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 22, 31 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/188338666958102528\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/MJUi5qCZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ap0dBQ3CIAAWZ4K.png",
      "id_str" : "188338666962296832",
      "id" : 188338666962296832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ap0dBQ3CIAAWZ4K.png",
      "sizes" : [ {
        "h" : 1259,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1259,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MJUi5qCZ"
    } ],
    "hashtags" : [ {
      "text" : "Budget",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/dxugoLqz",
      "expanded_url" : "http:\/\/wh.gov\/QXo",
      "display_url" : "wh.gov\/QXo"
    } ]
  },
  "geo" : { },
  "id_str" : "188338666958102528",
  "text" : "Getting at the Facts: @PressSec on the Ryan Republican #Budget: http:\/\/t.co\/dxugoLqz Infographic: http:\/\/t.co\/MJUi5qCZ",
  "id" : 188338666958102528,
  "created_at" : "2012-04-06 18:53:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/WhxT7xZ1",
      "expanded_url" : "http:\/\/goo.gl\/xv5mo",
      "display_url" : "goo.gl\/xv5mo"
    } ]
  },
  "geo" : { },
  "id_str" : "188325330170290176",
  "text" : "RT @StateDept: The people of #Iran are behind an electronic curtain; everyone should have freedom to connect. http:\/\/t.co\/WhxT7xZ1 #Conn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 14, 19 ]
      }, {
        "text" : "ConnectIran",
        "indices" : [ 116, 128 ]
      }, {
        "text" : "NetFreedom",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/WhxT7xZ1",
        "expanded_url" : "http:\/\/goo.gl\/xv5mo",
        "display_url" : "goo.gl\/xv5mo"
      } ]
    },
    "geo" : { },
    "id_str" : "188297701883002881",
    "text" : "The people of #Iran are behind an electronic curtain; everyone should have freedom to connect. http:\/\/t.co\/WhxT7xZ1 #ConnectIran #NetFreedom",
    "id" : 188297701883002881,
    "created_at" : "2012-04-06 16:10:45 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 188325330170290176,
  "created_at" : "2012-04-06 18:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/188307211972390912\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/WuTMLt5x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ap0AaV6CMAEMA_U.jpg",
      "id_str" : "188307211976585217",
      "id" : 188307211976585217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ap0AaV6CMAEMA_U.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/WuTMLt5x"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188307211972390912",
  "text" : "The economy has added #jobs for 25 straight months. Encouraging, but more work to be done. New jobs chart: http:\/\/t.co\/WuTMLt5x",
  "id" : 188307211972390912,
  "created_at" : "2012-04-06 16:48:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 87, 96 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188287151253897217",
  "text" : "RT @letsmove: Today we're announcing 2012 #EasterEggRoll main stage performers! Follow @LetsMove for breaking talent updates http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 73, 82 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 28, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/Guek31PT",
        "expanded_url" : "http:\/\/storify.com\/letsmove\/2012-easter-egg-roll-talent-lineup",
        "display_url" : "storify.com\/letsmove\/2012-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "188286987936071681",
    "text" : "Today we're announcing 2012 #EasterEggRoll main stage performers! Follow @LetsMove for breaking talent updates http:\/\/t.co\/Guek31PT",
    "id" : 188286987936071681,
    "created_at" : "2012-04-06 15:28:10 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 188287151253897217,
  "created_at" : "2012-04-06 15:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188273013194629120",
  "text" : "RT @WHLive: President Obama: We welcome today\u2019s news that our businesses created another 120,000 jobs last month...the unemployment rate ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "188272957787877376",
    "text" : "President Obama: We welcome today\u2019s news that our businesses created another 120,000 jobs last month...the unemployment rate ticked down",
    "id" : 188272957787877376,
    "created_at" : "2012-04-06 14:32:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 188273013194629120,
  "created_at" : "2012-04-06 14:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenEconForum",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "188272263425044480",
  "text" : "Happening now: President Obama speaks at the #WomenEconForum. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 188272263425044480,
  "created_at" : "2012-04-06 14:29:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188254691472322560",
  "text" : "RT @JonCarson44: @WhiteHouse 2day releases \"Keeping America\u2019s Women Moving Forward: The Key to an Economy Built to Last\" http:\/\/t.co\/7HQ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenEconForum",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/7HQ13zoQ",
        "expanded_url" : "http:\/\/1.usa.gov\/Hleh47",
        "display_url" : "1.usa.gov\/Hleh47"
      } ]
    },
    "geo" : { },
    "id_str" : "188252063900246016",
    "in_reply_to_user_id" : 30313925,
    "text" : "@WhiteHouse 2day releases \"Keeping America\u2019s Women Moving Forward: The Key to an Economy Built to Last\" http:\/\/t.co\/7HQ13zoQ #WomenEconForum",
    "id" : 188252063900246016,
    "created_at" : "2012-04-06 13:09:24 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 188254691472322560,
  "created_at" : "2012-04-06 13:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenEconForum",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/A3rU30St",
      "expanded_url" : "http:\/\/ow.ly\/a7mQ2",
      "display_url" : "ow.ly\/a7mQ2"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "188254335661125633",
  "text" : "Happening now: White House #WomenEconForum. See full schedule & learn more: http:\/\/t.co\/A3rU30St  Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 188254335661125633,
  "created_at" : "2012-04-06 13:18:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/188038109890486272\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/IwG56RDK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApwLqiiCIAAQ3ix.jpg",
      "id_str" : "188038109894680576",
      "id" : 188038109894680576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApwLqiiCIAAQ3ix.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IwG56RDK"
    } ],
    "hashtags" : [ {
      "text" : "WoundedWarrior",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "Bethesda",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188038367299121154",
  "text" : "RT @JoiningForces: Photo of the Day: First Lady Michelle Obama greets a #WoundedWarrior @ Walter Reed in #Bethesda: http:\/\/t.co\/IwG56RDK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/188038109890486272\/photo\/1",
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/IwG56RDK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ApwLqiiCIAAQ3ix.jpg",
        "id_str" : "188038109894680576",
        "id" : 188038109894680576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApwLqiiCIAAQ3ix.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IwG56RDK"
      } ],
      "hashtags" : [ {
        "text" : "WoundedWarrior",
        "indices" : [ 53, 68 ]
      }, {
        "text" : "Bethesda",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "188038109890486272",
    "text" : "Photo of the Day: First Lady Michelle Obama greets a #WoundedWarrior @ Walter Reed in #Bethesda: http:\/\/t.co\/IwG56RDK",
    "id" : 188038109890486272,
    "created_at" : "2012-04-05 22:59:14 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 188038367299121154,
  "created_at" : "2012-04-05 23:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "JOBSAct",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188010566487515136",
  "text" : "RT @SteveCase: Lots of confusion about #JOBSAct. Here's my take: \"Why The #JOBSAct Is Good for Startups - & for America\" http:\/\/t.co\/jc8 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JOBSAct",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "JOBSAct",
        "indices" : [ 59, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/jc8DAqiY",
        "expanded_url" : "http:\/\/bit.ly\/I9jOrJ",
        "display_url" : "bit.ly\/I9jOrJ"
      } ]
    },
    "geo" : { },
    "id_str" : "188005613752696832",
    "text" : "Lots of confusion about #JOBSAct. Here's my take: \"Why The #JOBSAct Is Good for Startups - & for America\" http:\/\/t.co\/jc8DAqiY Please RT",
    "id" : 188005613752696832,
    "created_at" : "2012-04-05 20:50:05 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 188010566487515136,
  "created_at" : "2012-04-05 21:09:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/YyeRYmHT",
      "expanded_url" : "http:\/\/wh.gov\/Qks",
      "display_url" : "wh.gov\/Qks"
    } ]
  },
  "geo" : { },
  "id_str" : "188010053008240640",
  "text" : "Today President Obama signed the #JOBSAct - encourages startups, supports #smallbiz: http:\/\/t.co\/YyeRYmHT",
  "id" : 188010053008240640,
  "created_at" : "2012-04-05 21:07:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "bipartisan",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187973118369865728",
  "text" : "President Obama: #JOBSAct \"represents exactly the kind of #bipartisan action we should be taking in Washington to help our economy\"",
  "id" : 187973118369865728,
  "created_at" : "2012-04-05 18:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 124, 131 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "187971882925035520",
  "text" : "Happening now: President Obama signs the Jumpstart our Business Startups #JOBSAct. Watch live: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 187971882925035520,
  "created_at" : "2012-04-05 18:36:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairshare",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/3AICfsCK",
      "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
      "display_url" : "wh.gov\/buffett-rule"
    } ]
  },
  "geo" : { },
  "id_str" : "187961815144210432",
  "text" : "How many millionaires paid $0 in taxes? Find out for yourself: http:\/\/t.co\/3AICfsCK #fairshare",
  "id" : 187961815144210432,
  "created_at" : "2012-04-05 17:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JOBSAct",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187943798565908481",
  "text" : "RT @startupamerica: The #JOBSAct to be signed TODAY at the @whitehouse legalizing crowdfunding so \"anyone and their mother can invest\"   ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 39, 50 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JOBSAct",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/CXQchaNU",
        "expanded_url" : "http:\/\/ar.gy\/0c_4",
        "display_url" : "ar.gy\/0c_4"
      } ]
    },
    "geo" : { },
    "id_str" : "187935408888356866",
    "text" : "The #JOBSAct to be signed TODAY at the @whitehouse legalizing crowdfunding so \"anyone and their mother can invest\"  http:\/\/t.co\/CXQchaNU",
    "id" : 187935408888356866,
    "created_at" : "2012-04-05 16:11:07 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 187943798565908481,
  "created_at" : "2012-04-05 16:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott \uD83D\uDD17",
      "screen_name" : "slfootball11",
      "indices" : [ 3, 16 ],
      "id_str" : "137193175",
      "id" : 137193175
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 109, 120 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FairShare",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187918281007575041",
  "text" : "RT @slfootball11: 1,470 people who made more than $1 million in 2009 paid $0 in federal income tax. (Source: @WhiteHouse) #FairShare htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 91, 102 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FairShare",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/RHVC7UMW",
        "expanded_url" : "http:\/\/p.twimg.com\/ApuGsrPCIAAeQGo.jpg",
        "display_url" : "p.twimg.com\/ApuGsrPCIAAeQG\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187900430179762176",
    "text" : "1,470 people who made more than $1 million in 2009 paid $0 in federal income tax. (Source: @WhiteHouse) #FairShare http:\/\/t.co\/RHVC7UMW\u201D",
    "id" : 187900430179762176,
    "created_at" : "2012-04-05 13:52:08 +0000",
    "user" : {
      "name" : "Scott \uD83D\uDD17",
      "screen_name" : "slfootball11",
      "protected" : false,
      "id_str" : "137193175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668632258543157248\/reA3DTKn_normal.jpg",
      "id" : 137193175,
      "verified" : false
    }
  },
  "id" : 187918281007575041,
  "created_at" : "2012-04-05 15:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Bihm",
      "screen_name" : "ernestbihm",
      "indices" : [ 3, 14 ],
      "id_str" : "339111013",
      "id" : 339111013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187918078120701952",
  "text" : "RT @ernestbihm: 1470 people paid no federal income tax on $1 million  incomes in 2009. The Buffett Rule will change that: http:\/\/t.co\/8C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairshare",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/8CbeQaAm",
        "expanded_url" : "http:\/\/wh.gov\/buffett-rule",
        "display_url" : "wh.gov\/buffett-rule"
      } ]
    },
    "geo" : { },
    "id_str" : "187583979485003776",
    "text" : "1470 people paid no federal income tax on $1 million  incomes in 2009. The Buffett Rule will change that: http:\/\/t.co\/8CbeQaAm #fairshare",
    "id" : 187583979485003776,
    "created_at" : "2012-04-04 16:54:40 +0000",
    "user" : {
      "name" : "Ernest Bihm",
      "screen_name" : "ernestbihm",
      "protected" : false,
      "id_str" : "339111013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751123990991822848\/4mqj430d_normal.jpg",
      "id" : 339111013,
      "verified" : false
    }
  },
  "id" : 187918078120701952,
  "created_at" : "2012-04-05 15:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 36, 39 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/187692150933295104\/photo\/1",
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/q8XHb3SF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AprRBE_CEAAl6c5.jpg",
      "id_str" : "187692150937489408",
      "id" : 187692150937489408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AprRBE_CEAAl6c5.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1277,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/q8XHb3SF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187692150933295104",
  "text" : "Photo of the Day: President Obama & @VP Biden talk & walk up the stairs in the West Wing: http:\/\/t.co\/q8XHb3SF",
  "id" : 187692150933295104,
  "created_at" : "2012-04-05 00:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "joiningforces",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/UckfIDrl",
      "expanded_url" : "http:\/\/ow.ly\/a5vvJ",
      "display_url" : "ow.ly\/a5vvJ"
    } ]
  },
  "geo" : { },
  "id_str" : "187687207706963968",
  "text" : "RT @JoiningForces: Today First Lady Michelle Obama announced 15,000 #jobs for military spouses: http:\/\/t.co\/UckfIDrl #joiningforces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 49, 54 ]
      }, {
        "text" : "joiningforces",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/UckfIDrl",
        "expanded_url" : "http:\/\/ow.ly\/a5vvJ",
        "display_url" : "ow.ly\/a5vvJ"
      } ]
    },
    "geo" : { },
    "id_str" : "187687118846431232",
    "text" : "Today First Lady Michelle Obama announced 15,000 #jobs for military spouses: http:\/\/t.co\/UckfIDrl #joiningforces",
    "id" : 187687118846431232,
    "created_at" : "2012-04-04 23:44:30 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 187687207706963968,
  "created_at" : "2012-04-04 23:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 130, 137 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "AIDS",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "WHCAT",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187599803721584640",
  "text" : "Starting soon: We\u2019re answering your Q's on combatting the spread of #HIV #AIDS among women & girls. Ask now w\/ #WHCAT & follow at @WHLive.",
  "id" : 187599803721584640,
  "created_at" : "2012-04-04 17:57:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "187568984084840449",
  "text" : "Happening at 12ET: President Obama signs the Stop Trading on Congressional Knowledge (STOCK) Act. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 187568984084840449,
  "created_at" : "2012-04-04 15:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 129, 136 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "AIDS",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187566110269374464",
  "text" : "Today @ 2 pm ET: WH Office Hours on combatting the spread of #HIV #AIDS among women & girls. Ask your Q\u2019s now w\/ #WHChat. Follow @WHLive.",
  "id" : 187566110269374464,
  "created_at" : "2012-04-04 15:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/mqYXyeVO",
      "expanded_url" : "http:\/\/wh.gov\/tax-receipt",
      "display_url" : "wh.gov\/tax-receipt"
    } ]
  },
  "geo" : { },
  "id_str" : "187557318706216961",
  "text" : "Understand where your federal tax dollars are being spent with the new @WhiteHouse tax receipt tool: http:\/\/t.co\/mqYXyeVO",
  "id" : 187557318706216961,
  "created_at" : "2012-04-04 15:08:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187556374534823937",
  "text" : "RT @pfeiffer44: Today, President Obama signs the bipartisan STOCK Act, which the President called for in 2012 State of the Union address",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187505615587905536",
    "text" : "Today, President Obama signs the bipartisan STOCK Act, which the President called for in 2012 State of the Union address",
    "id" : 187505615587905536,
    "created_at" : "2012-04-04 11:43:17 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 187556374534823937,
  "created_at" : "2012-04-04 15:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/ojW3Kenz",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/photos-and-video\/video\/2012\/04\/03\/president-obama-speaks-associated-press-luncheon",
      "display_url" : "whitehouse.gov\/photos-and-vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187355749867995136",
  "text" : "RT @jesseclee44: Full video: Obama on the GOP Ryan budget vs a fair shot, fair share & fair shake http:\/\/t.co\/ojW3Kenz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/ojW3Kenz",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/photos-and-video\/video\/2012\/04\/03\/president-obama-speaks-associated-press-luncheon",
        "display_url" : "whitehouse.gov\/photos-and-vid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187354605439561730",
    "text" : "Full video: Obama on the GOP Ryan budget vs a fair shot, fair share & fair shake http:\/\/t.co\/ojW3Kenz",
    "id" : 187354605439561730,
    "created_at" : "2012-04-04 01:43:13 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 187355749867995136,
  "created_at" : "2012-04-04 01:47:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felipe Calder\u00F3n",
      "screen_name" : "FelipeCalderon",
      "indices" : [ 65, 80 ],
      "id_str" : "144376833",
      "id" : 144376833
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/187337386005504000\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/KvgzQvjL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApmOXCpCIAAWWVi.jpg",
      "id_str" : "187337386009698304",
      "id" : 187337386009698304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApmOXCpCIAAWWVi.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KvgzQvjL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187337386005504000",
  "text" : "Photo of the Day: President Obama walks w\/ @pmharper of Canada & @FelipeCalderon of Mexico after a joint press conf: http:\/\/t.co\/KvgzQvjL",
  "id" : 187337386005504000,
  "created_at" : "2012-04-04 00:34:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/HdoaYfZe",
      "expanded_url" : "http:\/\/storify.com\/vp\/askvp-college-affordability",
      "display_url" : "storify.com\/vp\/askvp-colle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "187294058941644800",
  "text" : "RT @VP: VP Biden just wrapped up #AskVP chat on college affordability. Missed it? See full Q&A: http:\/\/t.co\/HdoaYfZe Pic: http:\/\/t.co\/fx ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/187293784856469504\/photo\/1",
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/fxaBoIIh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AplmtHtCIAECNXU.jpg",
        "id_str" : "187293784860663809",
        "id" : 187293784860663809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AplmtHtCIAECNXU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/fxaBoIIh"
      } ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 25, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/HdoaYfZe",
        "expanded_url" : "http:\/\/storify.com\/vp\/askvp-college-affordability",
        "display_url" : "storify.com\/vp\/askvp-colle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "187293784856469504",
    "text" : "VP Biden just wrapped up #AskVP chat on college affordability. Missed it? See full Q&A: http:\/\/t.co\/HdoaYfZe Pic: http:\/\/t.co\/fxaBoIIh",
    "id" : 187293784856469504,
    "created_at" : "2012-04-03 21:41:33 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187294058941644800,
  "created_at" : "2012-04-03 21:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187282044919889921",
  "text" : "RT @PressSec: \"Disappointing\" is another GOP budget that gives tax cuts to millionaires while sticking the middle class & seniors with t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187272456128561153",
    "text" : "\"Disappointing\" is another GOP budget that gives tax cuts to millionaires while sticking the middle class & seniors with the bill",
    "id" : 187272456128561153,
    "created_at" : "2012-04-03 20:16:47 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 187282044919889921,
  "created_at" : "2012-04-03 20:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187272617617657858",
  "text" : "RT @VP: Thanks for questions. Must be best educated country in the world. That's the goal. You're the talent. We will help. Thank you. - ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187272584843374592",
    "text" : "Thanks for questions. Must be best educated country in the world. That's the goal. You're the talent. We will help. Thank you. -vp #askvp",
    "id" : 187272584843374592,
    "created_at" : "2012-04-03 20:17:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187272617617657858,
  "created_at" : "2012-04-03 20:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "CLASP",
      "screen_name" : "CLASP_DC",
      "indices" : [ 9, 18 ],
      "id_str" : "164759805",
      "id" : 164759805
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187272335483600896",
  "text" : "RT @VP: .@CLASP_DC Thanks, agree. In national interest. -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CLASP",
        "screen_name" : "CLASP_DC",
        "indices" : [ 1, 10 ],
        "id_str" : "164759805",
        "id" : 164759805
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 52, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187272207171461120",
    "text" : ".@CLASP_DC Thanks, agree. In national interest. -vp #askvp",
    "id" : 187272207171461120,
    "created_at" : "2012-04-03 20:15:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187272335483600896,
  "created_at" : "2012-04-03 20:16:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLASP",
      "screen_name" : "CLASP_DC",
      "indices" : [ 3, 12 ],
      "id_str" : "164759805",
      "id" : 164759805
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187272237634686976",
  "text" : "RT @CLASP_DC: TY @WhiteHouse for preserving Pell for ALL students in your budget proposal. Others that wld cut Pell are anti-affordabili ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 3, 14 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187271430210207744",
    "text" : "TY @WhiteHouse for preserving Pell for ALL students in your budget proposal. Others that wld cut Pell are anti-affordability strategy #AskVP",
    "id" : 187271430210207744,
    "created_at" : "2012-04-03 20:12:42 +0000",
    "user" : {
      "name" : "CLASP",
      "screen_name" : "CLASP_DC",
      "protected" : false,
      "id_str" : "164759805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412657744877862912\/JQvpo9EU_normal.jpeg",
      "id" : 164759805,
      "verified" : false
    }
  },
  "id" : 187272237634686976,
  "created_at" : "2012-04-03 20:15:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "David Hahn",
      "screen_name" : "davhahn",
      "indices" : [ 9, 17 ],
      "id_str" : "19340819",
      "id" : 19340819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187272025285468160",
  "text" : "RT @VP: .@davhahn Yes. Good parent. -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Hahn",
        "screen_name" : "davhahn",
        "indices" : [ 1, 9 ],
        "id_str" : "19340819",
        "id" : 19340819
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 32, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187271967789948928",
    "text" : ".@davhahn Yes. Good parent. -vp #askvp",
    "id" : 187271967789948928,
    "created_at" : "2012-04-03 20:14:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187272025285468160,
  "created_at" : "2012-04-03 20:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hahn",
      "screen_name" : "davhahn",
      "indices" : [ 3, 11 ],
      "id_str" : "19340819",
      "id" : 19340819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187272015571460098",
  "text" : "RT @davhahn: Is the money I'm saving for my 2 daughters going to get them anything when they head to school in 10 and 16 years? #AskVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187271444793794560",
    "text" : "Is the money I'm saving for my 2 daughters going to get them anything when they head to school in 10 and 16 years? #AskVP",
    "id" : 187271444793794560,
    "created_at" : "2012-04-03 20:12:46 +0000",
    "user" : {
      "name" : "David Hahn",
      "screen_name" : "davhahn",
      "protected" : false,
      "id_str" : "19340819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/148182573\/DMH_ScannerDark_normal.jpg",
      "id" : 19340819,
      "verified" : false
    }
  },
  "id" : 187272015571460098,
  "created_at" : "2012-04-03 20:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Sophia",
      "screen_name" : "MoonFairy4",
      "indices" : [ 9, 20 ],
      "id_str" : "15322761",
      "id" : 15322761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187271798407168001",
  "text" : "RT @VP: .@MoonFairy4 admirable. We suspend undergraduate repayment while in school. Better job - 10% limit - tax credit -brighter horizo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sophia",
        "screen_name" : "MoonFairy4",
        "indices" : [ 1, 12 ],
        "id_str" : "15322761",
        "id" : 15322761
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187271740257349633",
    "text" : ".@MoonFairy4 admirable. We suspend undergraduate repayment while in school. Better job - 10% limit - tax credit -brighter horizon -vp #askvp",
    "id" : 187271740257349633,
    "created_at" : "2012-04-03 20:13:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187271798407168001,
  "created_at" : "2012-04-03 20:14:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia",
      "screen_name" : "MoonFairy4",
      "indices" : [ 3, 14 ],
      "id_str" : "15322761",
      "id" : 15322761
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187271785182527490",
  "text" : "RT @MoonFairy4: @vp 1\/2 I'm a mom who's gone back to school for engineering. Still have student loan debt from prev BA (that career led  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 0, 3 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187270381609025537",
    "in_reply_to_user_id" : 325830217,
    "text" : "@vp 1\/2 I'm a mom who's gone back to school for engineering. Still have student loan debt from prev BA (that career led to low pay). #AskVP",
    "id" : 187270381609025537,
    "created_at" : "2012-04-03 20:08:32 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Sophia",
      "screen_name" : "MoonFairy4",
      "protected" : false,
      "id_str" : "15322761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510477106938011649\/iozcq073_normal.jpeg",
      "id" : 15322761,
      "verified" : false
    }
  },
  "id" : 187271785182527490,
  "created_at" : "2012-04-03 20:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Jonathan Shaeffer",
      "screen_name" : "JonShaeffer",
      "indices" : [ 9, 21 ],
      "id_str" : "71100007",
      "id" : 71100007
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187271362954534913",
  "text" : "RT @VP: .@JonShaeffer Difficult. Options: Commute - community college; work study; tax credit; local scholarship . Good luck. -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Shaeffer",
        "screen_name" : "JonShaeffer",
        "indices" : [ 1, 13 ],
        "id_str" : "71100007",
        "id" : 71100007
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 122, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187271293081628672",
    "text" : ".@JonShaeffer Difficult. Options: Commute - community college; work study; tax credit; local scholarship . Good luck. -vp #askvp",
    "id" : 187271293081628672,
    "created_at" : "2012-04-03 20:12:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187271362954534913,
  "created_at" : "2012-04-03 20:12:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Shaeffer",
      "screen_name" : "JonShaeffer",
      "indices" : [ 3, 15 ],
      "id_str" : "71100007",
      "id" : 71100007
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187271352087093249",
  "text" : "RT @JonShaeffer: How can I stay out of debt when I go to school? #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 48, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187269570703273985",
    "text" : "How can I stay out of debt when I go to school? #askvp",
    "id" : 187269570703273985,
    "created_at" : "2012-04-03 20:05:19 +0000",
    "user" : {
      "name" : "Jonathan Shaeffer",
      "screen_name" : "JonShaeffer",
      "protected" : false,
      "id_str" : "71100007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723365823813832704\/Akl3_vLh_normal.jpg",
      "id" : 71100007,
      "verified" : false
    }
  },
  "id" : 187271352087093249,
  "created_at" : "2012-04-03 20:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "quirkless",
      "screen_name" : "jesseejamesMD",
      "indices" : [ 9, 23 ],
      "id_str" : "411203338",
      "id" : 411203338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187270514614616064",
  "text" : "RT @VP: .@jesseejamesMD  Alt community college to 4 yr college, work study, Perkins, tax credits, local scholarships. Explore. -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "quirkless",
        "screen_name" : "jesseejamesMD",
        "indices" : [ 1, 15 ],
        "id_str" : "411203338",
        "id" : 411203338
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187270458599686146",
    "text" : ".@jesseejamesMD  Alt community college to 4 yr college, work study, Perkins, tax credits, local scholarships. Explore. -vp #askvp",
    "id" : 187270458599686146,
    "created_at" : "2012-04-03 20:08:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187270514614616064,
  "created_at" : "2012-04-03 20:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "quirkless",
      "screen_name" : "jesseejamesMD",
      "indices" : [ 3, 17 ],
      "id_str" : "411203338",
      "id" : 411203338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 19, 25 ]
    }, {
      "text" : "Pell",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187270409673129985",
  "text" : "RT @jesseejamesMD: #AskVP What about the lower middle class students who do not qualify for #Pell and still can't afford to pay their wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "Pell",
        "indices" : [ 73, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187269767181242368",
    "text" : "#AskVP What about the lower middle class students who do not qualify for #Pell and still can't afford to pay their way through?",
    "id" : 187269767181242368,
    "created_at" : "2012-04-03 20:06:06 +0000",
    "user" : {
      "name" : "quirkless",
      "screen_name" : "jesseejamesMD",
      "protected" : false,
      "id_str" : "411203338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757418566266216449\/XyIOIZY4_normal.jpg",
      "id" : 411203338,
      "verified" : false
    }
  },
  "id" : 187270409673129985,
  "created_at" : "2012-04-03 20:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 9, 22 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187270136372281344",
  "text" : "RT @VP: .@tressiemcphd Regrettable decline of state support. Profits plowed back into student opportunities -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tressie Mc",
        "screen_name" : "tressiemcphd",
        "indices" : [ 1, 14 ],
        "id_str" : "148593548",
        "id" : 148593548
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187270102805262337",
    "text" : ".@tressiemcphd Regrettable decline of state support. Profits plowed back into student opportunities -vp #askvp",
    "id" : 187270102805262337,
    "created_at" : "2012-04-03 20:07:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187270136372281344,
  "created_at" : "2012-04-03 20:07:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 3, 16 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4profits",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187269944810024960",
  "text" : "RT @tressiemcphd: thoughts on role of fed student loans generating profit for #4profits while state subsidies to public unis decline? @v ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 116, 119 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4profits",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "askvp",
        "indices" : [ 120, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187268606772510720",
    "text" : "thoughts on role of fed student loans generating profit for #4profits while state subsidies to public unis decline? @vp\n#askvp",
    "id" : 187268606772510720,
    "created_at" : "2012-04-03 20:01:29 +0000",
    "user" : {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "protected" : false,
      "id_str" : "148593548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608377192331005952\/-4qqbOp2_normal.jpg",
      "id" : 148593548,
      "verified" : true
    }
  },
  "id" : 187269944810024960,
  "created_at" : "2012-04-03 20:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "August Zeidman",
      "screen_name" : "AZeidman",
      "indices" : [ 9, 18 ],
      "id_str" : "1400585288",
      "id" : 1400585288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askvp",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187269666199179265",
  "text" : "RT @VP: .@azeidman reason dept of ED looking for report card, grad rates, costs, facilities -- enabling informed choice. -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "August Zeidman",
        "screen_name" : "AZeidman",
        "indices" : [ 1, 10 ],
        "id_str" : "1400585288",
        "id" : 1400585288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 117, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187269627041161216",
    "text" : ".@azeidman reason dept of ED looking for report card, grad rates, costs, facilities -- enabling informed choice. -vp #askvp",
    "id" : 187269627041161216,
    "created_at" : "2012-04-03 20:05:33 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187269666199179265,
  "created_at" : "2012-04-03 20:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "August Zeidman",
      "screen_name" : "AZeidman",
      "indices" : [ 3, 12 ],
      "id_str" : "1400585288",
      "id" : 1400585288
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 14, 17 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187269619831156738",
  "text" : "RT @azeidman: @VP Colleges continue to raise tuition without offering additional services or improvements. Where is the itemized receipt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 0, 3 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187268601282179072",
    "in_reply_to_user_id" : 325830217,
    "text" : "@VP Colleges continue to raise tuition without offering additional services or improvements. Where is the itemized receipt? #AskVP",
    "id" : 187268601282179072,
    "created_at" : "2012-04-03 20:01:28 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "madA Z",
      "screen_name" : "madazei",
      "protected" : false,
      "id_str" : "27531295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2862184804\/57967f732ba1e0291f6f25f57d5f5a41_normal.jpeg",
      "id" : 27531295,
      "verified" : false
    }
  },
  "id" : 187269619831156738,
  "created_at" : "2012-04-03 20:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Kevin",
      "screen_name" : "keder",
      "indices" : [ 9, 15 ],
      "id_str" : "17518344",
      "id" : 17518344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187269333154676736",
  "text" : "RT @VP: .@keder  Fascinating. Could reduce costs, but it would eliminate millions of students from college. Against natl interest. -vp # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin",
        "screen_name" : "keder",
        "indices" : [ 1, 7 ],
        "id_str" : "17518344",
        "id" : 17518344
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 127, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187269268868575233",
    "text" : ".@keder  Fascinating. Could reduce costs, but it would eliminate millions of students from college. Against natl interest. -vp #askvp",
    "id" : 187269268868575233,
    "created_at" : "2012-04-03 20:04:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187269333154676736,
  "created_at" : "2012-04-03 20:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "keder",
      "indices" : [ 3, 9 ],
      "id_str" : "17518344",
      "id" : 17518344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187269017294217217",
  "text" : "RT @keder: Have you ever thought about lowering education costs by decreasing the role of government intervention in the education busin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 130, 136 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187268575399124992",
    "text" : "Have you ever thought about lowering education costs by decreasing the role of government intervention in the education business? #AskVP #p2",
    "id" : 187268575399124992,
    "created_at" : "2012-04-03 20:01:22 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "keder",
      "protected" : false,
      "id_str" : "17518344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656215951415885824\/rCJ_f1Vm_normal.jpg",
      "id" : 17518344,
      "verified" : false
    }
  },
  "id" : 187269017294217217,
  "created_at" : "2012-04-03 20:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Chelsea Barker",
      "screen_name" : "chelseagirl",
      "indices" : [ 9, 21 ],
      "id_str" : "17796111",
      "id" : 17796111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pell",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "askvp",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187268066965594112",
  "text" : "RT @VP: .@chelseagirl may qualify #Pell, work study - community college? Contact financial aid office. Don't give up -- for dad -vp #askvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chelsea Barker",
        "screen_name" : "chelseagirl",
        "indices" : [ 1, 13 ],
        "id_str" : "17796111",
        "id" : 17796111
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pell",
        "indices" : [ 26, 31 ]
      }, {
        "text" : "askvp",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187267961508212736",
    "text" : ".@chelseagirl may qualify #Pell, work study - community college? Contact financial aid office. Don't give up -- for dad -vp #askvp",
    "id" : 187267961508212736,
    "created_at" : "2012-04-03 19:58:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187268066965594112,
  "created_at" : "2012-04-03 19:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Susan Trepkov",
      "screen_name" : "InspiringMasses",
      "indices" : [ 9, 25 ],
      "id_str" : "15633129",
      "id" : 15633129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267243174920193",
  "text" : "RT @VP: .@InspiringMasses: Eliminated $60B in bank fees. Added 3M Pell grants + 10k tax credit + 10% limitation on payback. More coming  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Trepkov",
        "screen_name" : "InspiringMasses",
        "indices" : [ 1, 17 ],
        "id_str" : "15633129",
        "id" : 15633129
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187267042871738369",
    "text" : ".@InspiringMasses: Eliminated $60B in bank fees. Added 3M Pell grants + 10k tax credit + 10% limitation on payback. More coming -vp #askvp",
    "id" : 187267042871738369,
    "created_at" : "2012-04-03 19:55:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187267243174920193,
  "created_at" : "2012-04-03 19:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Trepkov",
      "screen_name" : "InspiringMasses",
      "indices" : [ 3, 19 ],
      "id_str" : "15633129",
      "id" : 15633129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267230717849600",
  "text" : "RT @InspiringMasses: How are you working within the budget to make college costs and education more affordable and accessible to all? #AskVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185452728032571393",
    "text" : "How are you working within the budget to make college costs and education more affordable and accessible to all? #AskVP",
    "id" : 185452728032571393,
    "created_at" : "2012-03-29 19:45:50 +0000",
    "user" : {
      "name" : "Susan Trepkov",
      "screen_name" : "InspiringMasses",
      "protected" : false,
      "id_str" : "15633129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469912191433310208\/a4S1cBec_normal.jpeg",
      "id" : 15633129,
      "verified" : false
    }
  },
  "id" : 187267230717849600,
  "created_at" : "2012-04-03 19:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Debbie Nelson Woods",
      "screen_name" : "dlnw52",
      "indices" : [ 9, 16 ],
      "id_str" : "25692786",
      "id" : 25692786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267174992318464",
  "text" : "RT @VP: .@dlnw52 Big concern, why we're limiting payback 10% disposable income has impact on mothers returning to school. Meaningful -VP ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Debbie Nelson Woods",
        "screen_name" : "dlnw52",
        "indices" : [ 1, 8 ],
        "id_str" : "25692786",
        "id" : 25692786
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 129, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187266929537454081",
    "text" : ".@dlnw52 Big concern, why we're limiting payback 10% disposable income has impact on mothers returning to school. Meaningful -VP #askvp",
    "id" : 187266929537454081,
    "created_at" : "2012-04-03 19:54:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187267174992318464,
  "created_at" : "2012-04-03 19:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Nelson Woods",
      "screen_name" : "dlnw52",
      "indices" : [ 3, 10 ],
      "id_str" : "25692786",
      "id" : 25692786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267161524416512",
  "text" : "RT @dlnw52: Feelings on student loan debt? Not just for young people but for women back in the workforce due to divorce\/widowing? #AskVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185443399300694017",
    "text" : "Feelings on student loan debt? Not just for young people but for women back in the workforce due to divorce\/widowing? #AskVP",
    "id" : 185443399300694017,
    "created_at" : "2012-03-29 19:08:46 +0000",
    "user" : {
      "name" : "Debbie Nelson Woods",
      "screen_name" : "dlnw52",
      "protected" : false,
      "id_str" : "25692786",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
      "id" : 25692786,
      "verified" : false
    }
  },
  "id" : 187267161524416512,
  "created_at" : "2012-04-03 19:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Amanda Bardonner",
      "screen_name" : "AmandaEmilyB",
      "indices" : [ 9, 22 ],
      "id_str" : "25098556",
      "id" : 25098556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267135196774400",
  "text" : "RT @VP: .@AmandaEmilyB  can't & won't - pushing Congress to prevent interest on loans from 2x. Fighting to make tax credit perm. & more. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Bardonner",
        "screen_name" : "AmandaEmilyB",
        "indices" : [ 1, 14 ],
        "id_str" : "25098556",
        "id" : 25098556
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187266800063492097",
    "text" : ".@AmandaEmilyB  can't & won't - pushing Congress to prevent interest on loans from 2x. Fighting to make tax credit perm. & more. -vp #askvp",
    "id" : 187266800063492097,
    "created_at" : "2012-04-03 19:54:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187267135196774400,
  "created_at" : "2012-04-03 19:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Bardonner",
      "screen_name" : "AmandaEmilyB",
      "indices" : [ 3, 16 ],
      "id_str" : "25098556",
      "id" : 25098556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267116754419713",
  "text" : "RT @AmandaEmilyB: Americans now owe more in student loans than credit card debt. How can you justify cuts to pell & increases in loan in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187265479218429952",
    "text" : "Americans now owe more in student loans than credit card debt. How can you justify cuts to pell & increases in loan interest rates. #AskVP",
    "id" : 187265479218429952,
    "created_at" : "2012-04-03 19:49:04 +0000",
    "user" : {
      "name" : "Amanda Bardonner",
      "screen_name" : "AmandaEmilyB",
      "protected" : false,
      "id_str" : "25098556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741100050130997248\/PRnB79mK_normal.jpg",
      "id" : 25098556,
      "verified" : false
    }
  },
  "id" : 187267116754419713,
  "created_at" : "2012-04-03 19:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267086899351553",
  "text" : "RT @VP: .@JTyler5767 Difficult - many private U provide substantial need based aid. Work study programs, expand Perkins loans. Need more ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187266361767100416",
    "text" : ".@JTyler5767 Difficult - many private U provide substantial need based aid. Work study programs, expand Perkins loans. Need more -vp #askvp",
    "id" : 187266361767100416,
    "created_at" : "2012-04-03 19:52:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187267086899351553,
  "created_at" : "2012-04-03 19:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 16, 24 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleAmerican",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187267072005378049",
  "text" : "RT @JTyler5767: @usedgov Private college rates keep going up, what's the plan to help #MiddleAmerican students get a private education # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 0, 8 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MiddleAmerican",
        "indices" : [ 70, 85 ]
      }, {
        "text" : "AskVP",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "Biden",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "185437155991105536",
    "geo" : { },
    "id_str" : "185442648117612545",
    "in_reply_to_user_id" : 20437286,
    "text" : "@usedgov Private college rates keep going up, what's the plan to help #MiddleAmerican students get a private education #AskVP #Biden",
    "id" : 185442648117612545,
    "in_reply_to_status_id" : 185437155991105536,
    "created_at" : "2012-03-29 19:05:47 +0000",
    "in_reply_to_screen_name" : "usedgov",
    "in_reply_to_user_id_str" : "20437286",
    "user" : {
      "name" : "Jordan Tyler",
      "screen_name" : "JTyler_KA67",
      "protected" : false,
      "id_str" : "206293614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593109860159459328\/cHA75wuE_normal.jpg",
      "id" : 206293614,
      "verified" : false
    }
  },
  "id" : 187267072005378049,
  "created_at" : "2012-04-03 19:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Tommy Watson",
      "screen_name" : "Tommy_Watson",
      "indices" : [ 9, 22 ],
      "id_str" : "43704284",
      "id" : 43704284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187266330389516288",
  "text" : "RT @VP: .@Tommy_Watson must be. $5,500\/yr Pell grant; $2,500\/yr tax credit; work study program $1,700\/yr; Perkins $1800\/yr. Still tough  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tommy Watson",
        "screen_name" : "Tommy_Watson",
        "indices" : [ 1, 14 ],
        "id_str" : "43704284",
        "id" : 43704284
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187266233824063488",
    "text" : ".@Tommy_Watson must be. $5,500\/yr Pell grant; $2,500\/yr tax credit; work study program $1,700\/yr; Perkins $1800\/yr. Still tough -vp #askvp",
    "id" : 187266233824063488,
    "created_at" : "2012-04-03 19:52:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187266330389516288,
  "created_at" : "2012-04-03 19:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187266214882578434",
  "text" : "RT @VP: .@jiggityj22 Now, payback limitation 10%, additional Pell & tax relief - but states must do more, colleges must limit increases  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187266072477569025",
    "text" : ".@jiggityj22 Now, payback limitation 10%, additional Pell & tax relief - but states must do more, colleges must limit increases -vp #askvp",
    "id" : 187266072477569025,
    "created_at" : "2012-04-03 19:51:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187266214882578434,
  "created_at" : "2012-04-03 19:51:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timeforchange",
      "indices" : [ 115, 129 ]
    }, {
      "text" : "AskVP",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187266197836935169",
  "text" : "RT @jiggityj22: When will we finally see results of college affordability? As a senior we have only seen increases #timeforchange #AskVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "timeforchange",
        "indices" : [ 99, 113 ]
      }, {
        "text" : "AskVP",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185473084852150273",
    "text" : "When will we finally see results of college affordability? As a senior we have only seen increases #timeforchange #AskVP",
    "id" : 185473084852150273,
    "created_at" : "2012-03-29 21:06:44 +0000",
    "user" : {
      "name" : "#5",
      "screen_name" : "liberallion22",
      "protected" : false,
      "id_str" : "56229463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2753248082\/d33250701739d9f3ff1e681a8c8ac051_normal.png",
      "id" : 56229463,
      "verified" : false
    }
  },
  "id" : 187266197836935169,
  "created_at" : "2012-04-03 19:51:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Blue Politics Girl",
      "screen_name" : "BluePoliticsGrl",
      "indices" : [ 9, 25 ],
      "id_str" : "535677912",
      "id" : 535677912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187265993431724032",
  "text" : "RT @VP: .@BluePoliticsGrl # of reasons, not least of which states significantly reducing commitment to state run higher institutions -vp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blue Politics Girl",
        "screen_name" : "BluePoliticsGrl",
        "indices" : [ 1, 17 ],
        "id_str" : "535677912",
        "id" : 535677912
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askvp",
        "indices" : [ 129, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187265750237581314",
    "text" : ".@BluePoliticsGrl # of reasons, not least of which states significantly reducing commitment to state run higher institutions -vp #askvp",
    "id" : 187265750237581314,
    "created_at" : "2012-04-03 19:50:08 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187265993431724032,
  "created_at" : "2012-04-03 19:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blue Politics Girl",
      "screen_name" : "BluePoliticsGrl",
      "indices" : [ 3, 19 ],
      "id_str" : "535677912",
      "id" : 535677912
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 25, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187265963333394434",
  "text" : "RT @BluePoliticsGrl: @VP #AskVP: Why is tuition increasing so much? 498.31% inflation since 1985 (compared to overall inflation of 115.0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 0, 3 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 4, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185451103180177408",
    "in_reply_to_user_id" : 325830217,
    "text" : "@VP #AskVP: Why is tuition increasing so much? 498.31% inflation since 1985 (compared to overall inflation of 115.06%) Paying more for less.",
    "id" : 185451103180177408,
    "created_at" : "2012-03-29 19:39:23 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Blue Politics Girl",
      "screen_name" : "BluePoliticsGrl",
      "protected" : false,
      "id_str" : "535677912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1947346788\/6a010535f28201970c013488ae5c7a970c-320wi_normal.jpg",
      "id" : 535677912,
      "verified" : false
    }
  },
  "id" : 187265963333394434,
  "created_at" : "2012-04-03 19:50:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187265454824366080",
  "text" : "RT @VP: College costs high. Debt burdensome. Help needed. That's why I'm here. Fire away. Use #AskVP -vp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 86, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "187265332308746240",
    "text" : "College costs high. Debt burdensome. Help needed. That's why I'm here. Fire away. Use #AskVP -vp",
    "id" : 187265332308746240,
    "created_at" : "2012-04-03 19:48:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 187265454824366080,
  "created_at" : "2012-04-03 19:48:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 73, 81 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 114, 117 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collegeaffordability",
      "indices" : [ 48, 69 ]
    }, {
      "text" : "AskVP",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/V4RALpiS",
      "expanded_url" : "http:\/\/wh.gov\/askvp",
      "display_url" : "wh.gov\/askvp"
    } ]
  },
  "geo" : { },
  "id_str" : "187244942379323392",
  "text" : "Today @ 3:45ET @VP Biden will answer your ?s on #collegeaffordability on @Twitter. Ask now: #AskVP & follow live: @VP http:\/\/t.co\/V4RALpiS",
  "id" : 187244942379323392,
  "created_at" : "2012-04-03 18:27:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 35, 38 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/p1S38n6p",
      "expanded_url" : "http:\/\/go.usa.gov\/Ez6",
      "display_url" : "go.usa.gov\/Ez6"
    } ]
  },
  "geo" : { },
  "id_str" : "187213590611230723",
  "text" : "RT @arneduncan: Great town hall w\/ @VP Biden. Keep the convo going #AskVP your college affordability Qs today @ 3:45 ET http:\/\/t.co\/p1S38n6p",
  "id" : 187213590611230723,
  "created_at" : "2012-04-03 16:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "187203555436933120",
  "text" : "Happening at 12:30ET: President Obama speaks & answers ?s at the AP lunch @ the ASNE Convention. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 187203555436933120,
  "created_at" : "2012-04-03 15:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 19, 26 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/49SC4d61",
      "expanded_url" : "http:\/\/youtu.be\/SIOUhjL5fKI",
      "display_url" : "youtu.be\/SIOUhjL5fKI"
    } ]
  },
  "geo" : { },
  "id_str" : "187186960647995392",
  "text" : "Behind the Scenes: @Google Art Project at the White House: http:\/\/t.co\/49SC4d61",
  "id" : 187186960647995392,
  "created_at" : "2012-04-03 14:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 38, 49 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobs",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/SV2SpCYy",
      "expanded_url" : "http:\/\/ow.ly\/a2eeg",
      "display_url" : "ow.ly\/a2eeg"
    } ]
  },
  "geo" : { },
  "id_str" : "186917615602647040",
  "text" : "Today we\u2019re announcing the first ever @WhiteHouse Code Sprint. Learn more: http:\/\/t.co\/SV2SpCYy #SummerJobs+",
  "id" : 186917615602647040,
  "created_at" : "2012-04-02 20:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Census Bureau",
      "screen_name" : "uscensusbureau",
      "indices" : [ 3, 18 ],
      "id_str" : "23092890",
      "id" : 23092890
    }, {
      "name" : "National Archives",
      "screen_name" : "archivesnews",
      "indices" : [ 120, 133 ],
      "id_str" : "81121879",
      "id" : 81121879
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1940Census",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186913859288825856",
  "text" : "RT @uscensusbureau: New White House blog post from Director Groves looks at today\u2019s release of #1940Census records from @archivesnews. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Archives",
        "screen_name" : "archivesnews",
        "indices" : [ 100, 113 ],
        "id_str" : "81121879",
        "id" : 81121879
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1940Census",
        "indices" : [ 75, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/SjRauak4",
        "expanded_url" : "http:\/\/goo.gl\/uEzLV",
        "display_url" : "goo.gl\/uEzLV"
      } ]
    },
    "geo" : { },
    "id_str" : "186897289154011136",
    "text" : "New White House blog post from Director Groves looks at today\u2019s release of #1940Census records from @archivesnews. http:\/\/t.co\/SjRauak4",
    "id" : 186897289154011136,
    "created_at" : "2012-04-02 19:26:00 +0000",
    "user" : {
      "name" : "U.S. Census Bureau",
      "screen_name" : "uscensusbureau",
      "protected" : false,
      "id_str" : "23092890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687724707056095232\/SugZ1cgb_normal.jpg",
      "id" : 23092890,
      "verified" : true
    }
  },
  "id" : 186913859288825856,
  "created_at" : "2012-04-02 20:31:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 10, 13 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collegeaffordability",
      "indices" : [ 40, 61 ]
    }, {
      "text" : "AskVP",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/V4RALpiS",
      "expanded_url" : "http:\/\/wh.gov\/askvp",
      "display_url" : "wh.gov\/askvp"
    } ]
  },
  "geo" : { },
  "id_str" : "186835181984944128",
  "text" : "Tomorrow, @VP will answer your ?s about #collegeaffordability on twitter. Ask now w\/ #AskVP & join live @ 3:45ET http:\/\/t.co\/V4RALpiS",
  "id" : 186835181984944128,
  "created_at" : "2012-04-02 15:19:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/6jT1oEKV",
      "expanded_url" : "http:\/\/blog.dhs.gov\/2012\/04\/uscg-first-lady-welcomes-newest-cutter.html",
      "display_url" : "blog.dhs.gov\/2012\/04\/uscg-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "186831495569223680",
  "text" : "RT @DHSgov: USCG: First Lady Welcomes Newest Cutter http:\/\/t.co\/6jT1oEKV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/6jT1oEKV",
        "expanded_url" : "http:\/\/blog.dhs.gov\/2012\/04\/uscg-first-lady-welcomes-newest-cutter.html",
        "display_url" : "blog.dhs.gov\/2012\/04\/uscg-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "186829152018636800",
    "text" : "USCG: First Lady Welcomes Newest Cutter http:\/\/t.co\/6jT1oEKV",
    "id" : 186829152018636800,
    "created_at" : "2012-04-02 14:55:15 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 186831495569223680,
  "created_at" : "2012-04-02 15:04:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]