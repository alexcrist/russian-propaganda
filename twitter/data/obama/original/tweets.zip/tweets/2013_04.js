Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Collins",
      "screen_name" : "jasoncollins34",
      "indices" : [ 128, 143 ],
      "id_str" : "1278613015",
      "id" : 1278613015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329360776731185152",
  "text" : "\"We judge people on the basis of their character and their performance &amp; not their sexual orientation.\" \u2014President Obama on @jasoncollins34",
  "id" : 329360776731185152,
  "created_at" : "2013-04-30 22:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 109, 116 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/xjPv3vB6ef",
      "expanded_url" : "http:\/\/at.wh.gov\/kzGYB",
      "display_url" : "at.wh.gov\/kzGYB"
    } ]
  },
  "geo" : { },
  "id_str" : "329329830594228224",
  "text" : "\"We're not going to stop until we find a way to serve and support every single military family in America.\" \u2014@FLOTUS: http:\/\/t.co\/xjPv3vB6ef",
  "id" : 329329830594228224,
  "created_at" : "2013-04-30 20:22:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 10, 24 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xjPv3vB6ef",
      "expanded_url" : "http:\/\/at.wh.gov\/kzGYB",
      "display_url" : "at.wh.gov\/kzGYB"
    } ]
  },
  "geo" : { },
  "id_str" : "329307997434155009",
  "text" : "Watch how @JoiningForces is helping veterans and military spouses find jobs: http:\/\/t.co\/xjPv3vB6ef",
  "id" : 329307997434155009,
  "created_at" : "2013-04-30 18:55:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329294110143946752",
  "text" : "RT @Sebelius: Wish applying for #health coverage was as easy as filling out a single 3-page form? It will be starting this fall: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/qi5S4sscZp",
        "expanded_url" : "http:\/\/go.cms.gov\/ZQbVSZ",
        "display_url" : "go.cms.gov\/ZQbVSZ"
      } ]
    },
    "geo" : { },
    "id_str" : "329253841377832961",
    "text" : "Wish applying for #health coverage was as easy as filling out a single 3-page form? It will be starting this fall: http:\/\/t.co\/qi5S4sscZp",
    "id" : 329253841377832961,
    "created_at" : "2013-04-30 15:20:07 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 329294110143946752,
  "created_at" : "2013-04-30 18:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 14, 21 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 41, 49 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/g5XqIKCQHP",
      "expanded_url" : "http:\/\/at.wh.gov\/kzeb4",
      "display_url" : "at.wh.gov\/kzeb4"
    } ]
  },
  "geo" : { },
  "id_str" : "329285542405607424",
  "text" : "Worth a read: @FLOTUS Michelle Obama and @DrBiden on why businesses should hire more veterans. http:\/\/t.co\/g5XqIKCQHP",
  "id" : 329285542405607424,
  "created_at" : "2013-04-30 17:26:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 116, 123 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329271822275207169",
  "text" : "\"We\u2019re not going to stop until every single veteran or military spouse that is searching for a job has found one.\" \u2014@FLOTUS Michelle Obama",
  "id" : 329271822275207169,
  "created_at" : "2013-04-30 16:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329270069861429248",
  "text" : "RT @JoiningForces: Big news: US companies have hired or trained 290,000+ vets or military spouses &amp; just announced a new commitment of \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329269453537828865",
    "text" : "Big news: US companies have hired or trained 290,000+ vets or military spouses &amp; just announced a new commitment of 435,000 jobs by 2018.",
    "id" : 329269453537828865,
    "created_at" : "2013-04-30 16:22:09 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 329270069861429248,
  "created_at" : "2013-04-30 16:24:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 117, 124 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329269560748412928",
  "text" : "RT @FLOTUS: \"These men &amp; women are some of the most talented, accomplished, dedicated people you'll ever meet.\" \u2014@FLOTUS on veterans &a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 105, 112 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329269489592066048",
    "text" : "\"These men &amp; women are some of the most talented, accomplished, dedicated people you'll ever meet.\" \u2014@FLOTUS on veterans &amp; military spouses",
    "id" : 329269489592066048,
    "created_at" : "2013-04-30 16:22:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 329269560748412928,
  "created_at" : "2013-04-30 16:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329266785922715649",
  "text" : "\"Hiring our veterans and military spouses is not just the patriotic thing to do\u2014it\u2019s the smart thing to do.\" \u2014President Obama",
  "id" : 329266785922715649,
  "created_at" : "2013-04-30 16:11:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 114, 117 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329264682563158016",
  "text" : "RT @VP: \"No one who fights for this country overseas should have to fight for a job when they come back home.\" -- @VP Biden: http:\/\/t.co\/Ps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 106, 109 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/PsVfqivqpQ",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "329264429017468928",
    "text" : "\"No one who fights for this country overseas should have to fight for a job when they come back home.\" -- @VP Biden: http:\/\/t.co\/PsVfqivqpQ",
    "id" : 329264429017468928,
    "created_at" : "2013-04-30 16:02:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 329264682563158016,
  "created_at" : "2013-04-30 16:03:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 17, 20 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 22, 29 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 37, 45 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329260402791821312",
  "text" : "Pres. Obama, the @VP, @FLOTUS, &amp; @DrBiden make a significant employment announcement for veterans &amp; military spouses: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 329260402791821312,
  "created_at" : "2013-04-30 15:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329257078352916481",
  "text" : "\"In a country as wealthy as ours, nobody should go bankrupt because they get sick.\" \u2014Obama on the need to fully implement health care reform",
  "id" : 329257078352916481,
  "created_at" : "2013-04-30 15:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329245395697934336",
  "text" : "Happening now: President Obama holds a press conference in the White House briefing room. http:\/\/t.co\/b4tqL3nPDV",
  "id" : 329245395697934336,
  "created_at" : "2013-04-30 14:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329231436366348289",
  "text" : "President Obama will take questions from reporters in the White House briefing room at 10:15am ET. Watch here: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 329231436366348289,
  "created_at" : "2013-04-30 13:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329224169306853378",
  "text" : "RT @PressSec: POTUS brought down the house on Sat night at #WHCD - but he didn't take questions. So, today he will. 10:15am in Brady Briefi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHCD",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329212106329165824",
    "text" : "POTUS brought down the house on Sat night at #WHCD - but he didn't take questions. So, today he will. 10:15am in Brady Briefing Room.",
    "id" : 329212106329165824,
    "created_at" : "2013-04-30 12:34:17 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 329224169306853378,
  "created_at" : "2013-04-30 13:22:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/329022319186022400\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/D9xDgdCfhZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJDsDlqCEAA9g8-.jpg",
      "id_str" : "329022319190216704",
      "id" : 329022319190216704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJDsDlqCEAA9g8-.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/D9xDgdCfhZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329022319186022400",
  "text" : "RT if you agree: We can't afford to cut job-creating investments in science and education. http:\/\/t.co\/D9xDgdCfhZ",
  "id" : 329022319186022400,
  "created_at" : "2013-04-30 00:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329007117543555074",
  "text" : "President Obama called Jason Collins this afternoon to express his support and said he was impressed by his courage. #Equality",
  "id" : 329007117543555074,
  "created_at" : "2013-04-29 22:59:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328979612338102272",
  "text" : "RT @FLOTUS: So proud of you, Jason Collins! This is a huge step forward for our country. We\u2019ve got your back! -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328978522578251776",
    "text" : "So proud of you, Jason Collins! This is a huge step forward for our country. We\u2019ve got your back! -mo",
    "id" : 328978522578251776,
    "created_at" : "2013-04-29 21:06:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 328979612338102272,
  "created_at" : "2013-04-29 21:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/328961962023206912\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/6lkVBnQDsS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJC1KVuCQAA4UOF.jpg",
      "id_str" : "328961962031595520",
      "id" : 328961962031595520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJC1KVuCQAA4UOF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/6lkVBnQDsS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8wayE9yyyp",
      "expanded_url" : "http:\/\/at.wh.gov\/kxDvj",
      "display_url" : "at.wh.gov\/kxDvj"
    } ]
  },
  "geo" : { },
  "id_str" : "328961962023206912",
  "text" : "Jack, 7, is battling cancer and did this at a football game: http:\/\/t.co\/8wayE9yyyp. Today, he met the President. http:\/\/t.co\/6lkVBnQDsS",
  "id" : 328961962023206912,
  "created_at" : "2013-04-29 20:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 105, 111 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328948857104920577",
  "text" : "\"I know Anthony\u2019s experience will make him an outstanding Transportation Secretary.\" \u2014President Obama on @USDOT nominee Mayor Anthony Foxx",
  "id" : 328948857104920577,
  "created_at" : "2013-04-29 19:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "328934289460826113",
  "text" : "Happening now: President Obama makes a personnel announcement. http:\/\/t.co\/b4tqL3nPDV",
  "id" : 328934289460826113,
  "created_at" : "2013-04-29 18:10:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "328931536764297216",
  "text" : "Tune in at 2:10pm ET for a personnel announcement from President Obama: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 328931536764297216,
  "created_at" : "2013-04-29 17:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAS150",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328899217357668352",
  "text" : "President Obama: \"We've got to make sure that we're supporting the next generation of dreamers and risk-takers.\" #NAS150",
  "id" : 328899217357668352,
  "created_at" : "2013-04-29 15:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAS150",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328897828795609090",
  "text" : "\"We can\u2019t afford to gut these investments in science and technology.\" \u2014Obama on the importance of investing in science #NAS150",
  "id" : 328897828795609090,
  "created_at" : "2013-04-29 15:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAS150",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328896249937948673",
  "text" : "President Obama: \u201CThe investments we make today are bound to pay off many times over in the years to come.\u201D #NAS150",
  "id" : 328896249937948673,
  "created_at" : "2013-04-29 15:39:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAS150",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328895798790217728",
  "text" : "\u201CThe essence of America is its hunger to innovate. This restlessness. This quest for the next big thing.\u201D \u2014President Obama at #NAS150",
  "id" : 328895798790217728,
  "created_at" : "2013-04-29 15:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAS150",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/PXEC6JRNB4",
      "expanded_url" : "http:\/\/at.wh.gov\/kwNIs",
      "display_url" : "at.wh.gov\/kwNIs"
    } ]
  },
  "geo" : { },
  "id_str" : "328894166052511745",
  "text" : "Happening now: President Obama speaks at the National Academy of Sciences' 150th anniversary event. http:\/\/t.co\/PXEC6JRNB4 #NAS150",
  "id" : 328894166052511745,
  "created_at" : "2013-04-29 15:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/328878137335222273\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/aKP41OvTco",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJBo7GbCEAEF3CH.jpg",
      "id_str" : "328878137343610881",
      "id" : 328878137343610881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJBo7GbCEAEF3CH.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/aKP41OvTco"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/IiYu7dZSeo",
      "expanded_url" : "http:\/\/at.wh.gov\/kwJkF",
      "display_url" : "at.wh.gov\/kwJkF"
    } ]
  },
  "geo" : { },
  "id_str" : "328878137335222273",
  "text" : "Watch: President Obama at the 2013 White House Correspondents' Dinner. http:\/\/t.co\/IiYu7dZSeo, http:\/\/t.co\/aKP41OvTco",
  "id" : 328878137335222273,
  "created_at" : "2013-04-29 14:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dO8LQos8b1",
      "expanded_url" : "http:\/\/youtu.be\/SVtQ6i1jbsk",
      "display_url" : "youtu.be\/SVtQ6i1jbsk"
    } ]
  },
  "geo" : { },
  "id_str" : "328648703474810880",
  "text" : "ICYMI, President Obama tried the First Lady\u2019s bangs on for size at last night\u2019s White House Correspondents\u2019 Dinner: http:\/\/t.co\/dO8LQos8b1",
  "id" : 328648703474810880,
  "created_at" : "2013-04-28 23:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/zqflXxO4cc",
      "expanded_url" : "http:\/\/at.wh.gov\/kuzGH",
      "display_url" : "at.wh.gov\/kuzGH"
    } ]
  },
  "geo" : { },
  "id_str" : "328335645481238529",
  "text" : "Steven Spielberg's \"Obama.\" http:\/\/t.co\/zqflXxO4cc #WHCD",
  "id" : 328335645481238529,
  "created_at" : "2013-04-28 02:31:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "328328059080019968",
  "text" : "Starting soon: President Obama speaks at the White House Correspondents' Dinner. http:\/\/t.co\/b4tqL3nPDV #WHCD",
  "id" : 328328059080019968,
  "created_at" : "2013-04-28 02:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/wVDuNuirHd",
      "expanded_url" : "http:\/\/at.wh.gov\/kuvsS",
      "display_url" : "at.wh.gov\/kuvsS"
    } ]
  },
  "geo" : { },
  "id_str" : "328300677656883202",
  "text" : "Getting ready for the Correspondents' Dinner: http:\/\/t.co\/wVDuNuirHd #WHCD",
  "id" : 328300677656883202,
  "created_at" : "2013-04-28 00:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WxRLDIMITQ",
      "expanded_url" : "http:\/\/at.wh.gov\/ku03Y",
      "display_url" : "at.wh.gov\/ku03Y"
    } ]
  },
  "geo" : { },
  "id_str" : "328193356863791105",
  "text" : "President Obama: \"There is only one way to truly fix the sequester: By replacing it before it causes further damage.\" http:\/\/t.co\/WxRLDIMITQ",
  "id" : 328193356863791105,
  "created_at" : "2013-04-27 17:06:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/665uaJQCdv",
      "expanded_url" : "http:\/\/youtu.be\/mox4InKEwgU",
      "display_url" : "youtu.be\/mox4InKEwgU"
    } ]
  },
  "geo" : { },
  "id_str" : "328133915325911040",
  "text" : "Weekly Address: President Obama on why we need to stop severe cuts to vital services. http:\/\/t.co\/665uaJQCdv",
  "id" : 328133915325911040,
  "created_at" : "2013-04-27 13:09:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/327861889012989953\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/67KazZryHq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIzMpqZCAAEoMOx.jpg",
      "id_str" : "327861889017184257",
      "id" : 327861889017184257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIzMpqZCAAEoMOx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/67KazZryHq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327861889012989953",
  "text" : "Five Presidents. http:\/\/t.co\/67KazZryHq",
  "id" : 327861889012989953,
  "created_at" : "2013-04-26 19:09:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 36, 43 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/327835499492409347\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/AX1rYqaaAx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIy0plyCAAAbrvV.jpg",
      "id_str" : "327835499500797952",
      "id" : 327835499500797952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIy0plyCAAAbrvV.jpg",
      "sizes" : [ {
        "h" : 1118,
        "resize" : "fit",
        "w" : 874
      }, {
        "h" : 1118,
        "resize" : "fit",
        "w" : 874
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AX1rYqaaAx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/CX40lRs1jv",
      "expanded_url" : "http:\/\/at.wh.gov\/ksJHi",
      "display_url" : "at.wh.gov\/ksJHi"
    } ]
  },
  "geo" : { },
  "id_str" : "327835499492409347",
  "text" : "Breaking: The White House is now on @Tumblr (and there will be GIFs). http:\/\/t.co\/CX40lRs1jv, http:\/\/t.co\/AX1rYqaaAx",
  "id" : 327835499492409347,
  "created_at" : "2013-04-26 17:24:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327809405913542656",
  "text" : "\"You\u2019ve got a President who\u2019s going to be right there with you in that fight every step of the way.\" \u2014Obama on access to quality health care",
  "id" : 327809405913542656,
  "created_at" : "2013-04-26 15:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327805809054601218",
  "text" : "President Obama: \"The only person who should get to make decisions about your health is you.\"",
  "id" : 327805809054601218,
  "created_at" : "2013-04-26 15:26:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327805254773125120",
  "text" : "\"When it comes to a woman\u2019s health, no politician should get to decide what\u2019s best for you.\" \u2014President Obama",
  "id" : 327805254773125120,
  "created_at" : "2013-04-26 15:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327804661895680002",
  "text" : "\"There are still those who want to turn back the clock to policies more suited to the '50s than the 21st century.\" \u2014Obama on women's health",
  "id" : 327804661895680002,
  "created_at" : "2013-04-26 15:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "327803385623482370",
  "text" : "Happening now: President Obama speaks at the Planned Parenthood conference. http:\/\/t.co\/b4tqL3nPDV",
  "id" : 327803385623482370,
  "created_at" : "2013-04-26 15:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestTX",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/8o27bF3iRS",
      "expanded_url" : "http:\/\/at.wh.gov\/kslX2",
      "display_url" : "at.wh.gov\/kslX2"
    } ]
  },
  "geo" : { },
  "id_str" : "327799386832793601",
  "text" : "\"These hard days have shown your ability to stand tall in times of unimaginable adversity.\u201D \u2014President Obama: http:\/\/t.co\/8o27bF3iRS #WestTX",
  "id" : 327799386832793601,
  "created_at" : "2013-04-26 15:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/327567160979374080\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/5C40t7nCZl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIvAmO8CQAAqi-N.jpg",
      "id_str" : "327567160991956992",
      "id" : 327567160991956992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIvAmO8CQAAqi-N.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/5C40t7nCZl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327567160979374080",
  "text" : "RT this to let the people of West, Texas know that we will stand with them as they rebuild and recover. http:\/\/t.co\/5C40t7nCZl",
  "id" : 327567160979374080,
  "created_at" : "2013-04-25 23:37:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327530021436661761",
  "text" : "\"You are, and always will be, surrounded by an abundance of love.\" \u2014President Obama to the people of West, Texas",
  "id" : 327530021436661761,
  "created_at" : "2013-04-25 21:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327529732402982913",
  "text" : "President Obama: \"We need people who so love their neighbors as themselves that they\u2019re willing to lay down their lives for them.\"",
  "id" : 327529732402982913,
  "created_at" : "2013-04-25 21:09:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327529477452201986",
  "text" : "President Obama: \"Going forward, it\u2019s not just your town that needs your courage and your love and your faith. America does, too.\"",
  "id" : 327529477452201986,
  "created_at" : "2013-04-25 21:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327529158324387840",
  "text" : "Obama: \"What makes West special is what makes it familiar, &amp; instead of changing who you are, this tragedy revealed who you\u2019ve always been.\"",
  "id" : 327529158324387840,
  "created_at" : "2013-04-25 21:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327528265529040896",
  "text" : "Obama: \u201CTogether, you answered the call. You dropped your schoolwork, left your families, jumped in fire trucks and rushed to the flames.\u201D",
  "id" : 327528265529040896,
  "created_at" : "2013-04-25 21:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327528007734542336",
  "text" : "President Obama: \"When someone\u2019s in need, you reach out to them. You support them. And you do what it takes to help them carry on.\"",
  "id" : 327528007734542336,
  "created_at" : "2013-04-25 21:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327527735155105793",
  "text" : "President Obama to the people of West, TX: \"Your country will remain ever ready to help you recover and rebuild and reclaim your community.\"",
  "id" : 327527735155105793,
  "created_at" : "2013-04-25 21:01:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327527423077928961",
  "text" : "President Obama: \u201CTo the families and neighbors grappling with unbearable loss\u2014you are not alone. You are not forgotten.\u201D",
  "id" : 327527423077928961,
  "created_at" : "2013-04-25 20:59:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327527216890130433",
  "text" : "\u201CWe give thanks for the courage and compassion and incredible grace of the people of West, Texas.\u201D \u2014President Obama",
  "id" : 327527216890130433,
  "created_at" : "2013-04-25 20:59:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327526914405326851",
  "text" : "President Obama: \"We gather here in Texas to mourn brave men who went through fire and all those who\u2019ve been taken from us.\"",
  "id" : 327526914405326851,
  "created_at" : "2013-04-25 20:57:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327526682539995139",
  "text" : "President Obama in Waco, Texas: \u201CFor this state\u2014for our country\u2014these have been trying and difficult days.\u201D",
  "id" : 327526682539995139,
  "created_at" : "2013-04-25 20:57:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "327526121988050944",
  "text" : "Happening now: President Obama speaks at the memorial service honoring victims of the West, TX explosions. http:\/\/t.co\/b4tqL3nPDV",
  "id" : 327526121988050944,
  "created_at" : "2013-04-25 20:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327501898213101569",
  "text" : "RT @FLOTUS: My prayers are with the people of West, TX as we honor the victims of this tragedy. They've shown tremendous courage and resolv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327501632914980865",
    "text" : "My prayers are with the people of West, TX as we honor the victims of this tragedy. They've shown tremendous courage and resolve. -mo",
    "id" : 327501632914980865,
    "created_at" : "2013-04-25 19:17:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 327501898213101569,
  "created_at" : "2013-04-25 19:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 46, 54 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 65, 77 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/gYNonszHXd",
      "expanded_url" : "http:\/\/at.wh.gov\/kqf1v",
      "display_url" : "at.wh.gov\/kqf1v"
    } ]
  },
  "geo" : { },
  "id_str" : "327486263617789953",
  "text" : "From all of us at the White House, welcome to @Twitter President @BillClinton! http:\/\/t.co\/gYNonszHXd",
  "id" : 327486263617789953,
  "created_at" : "2013-04-25 18:16:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/327472846672650240\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/I3fjbwD2bE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BItq0avCYAARmCy.jpg",
      "id_str" : "327472846676844544",
      "id" : 327472846676844544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BItq0avCYAARmCy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/I3fjbwD2bE"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 79, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327472846672650240",
  "text" : "RT if you support President Obama's plan to fix our broken immigration system. #ImmigrationNation, http:\/\/t.co\/I3fjbwD2bE",
  "id" : 327472846672650240,
  "created_at" : "2013-04-25 17:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 7, 15 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/V8xtPPg3Zx",
      "expanded_url" : "http:\/\/at.wh.gov\/kqiOH",
      "display_url" : "at.wh.gov\/kqiOH"
    } ]
  },
  "geo" : { },
  "id_str" : "327469913545506819",
  "text" : "VIDEO: @DrBiden places flowers and a signed pair of running shoes at the Boston Marathon Memorial Site. http:\/\/t.co\/V8xtPPg3Zx #BostonStrong",
  "id" : 327469913545506819,
  "created_at" : "2013-04-25 17:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327458405746876419",
  "text" : "President Obama on President Bush: \"We share a profound respect and reverence for the men and women of our military and their families.\"",
  "id" : 327458405746876419,
  "created_at" : "2013-04-25 16:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBushCenter",
      "screen_name" : "TheBushCenter",
      "indices" : [ 3, 17 ],
      "id_str" : "148376661",
      "id" : 148376661
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheBushCenter\/status\/327438057391398912\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/o9QeOnfSVT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BItLLakCIAEoBmR.jpg",
      "id_str" : "327438057395593217",
      "id" : 327438057395593217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BItLLakCIAEoBmR.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/o9QeOnfSVT"
    } ],
    "hashtags" : [ {
      "text" : "BushCenter",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327451295130722304",
  "text" : "RT @TheBushCenter: A great American moment #BushCenter http:\/\/t.co\/o9QeOnfSVT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheBushCenter\/status\/327438057391398912\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/o9QeOnfSVT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BItLLakCIAEoBmR.jpg",
        "id_str" : "327438057395593217",
        "id" : 327438057395593217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BItLLakCIAEoBmR.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/o9QeOnfSVT"
      } ],
      "hashtags" : [ {
        "text" : "BushCenter",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327438057391398912",
    "text" : "A great American moment #BushCenter http:\/\/t.co\/o9QeOnfSVT",
    "id" : 327438057391398912,
    "created_at" : "2013-04-25 15:04:51 +0000",
    "user" : {
      "name" : "TheBushCenter",
      "screen_name" : "TheBushCenter",
      "protected" : false,
      "id_str" : "148376661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458989737458429952\/F-dCa91s_normal.jpeg",
      "id" : 148376661,
      "verified" : true
    }
  },
  "id" : 327451295130722304,
  "created_at" : "2013-04-25 15:57:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327449034602201091",
  "text" : "\"We remember his commitment to reaching across the aisle\" \u2014President Obama at the dedication of the George W. Bush Presidential Library",
  "id" : 327449034602201091,
  "created_at" : "2013-04-25 15:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "327447315164061697",
  "text" : "Happening now: President Obama speaks in Dallas at the dedication of the George W. Bush Presidential Library. http:\/\/t.co\/b4tqL3nPDV",
  "id" : 327447315164061697,
  "created_at" : "2013-04-25 15:41:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "327431538818039808",
  "text" : "At 11:00ET: President Obama speaks at the George W. Bush Presidential Center Dedication Ceremony. http:\/\/t.co\/b4tqL3nPDV",
  "id" : 327431538818039808,
  "created_at" : "2013-04-25 14:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 18, 26 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/327203511823659011\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Y3WYQX6EhH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIp13EPCcAEm_-L.jpg",
      "id_str" : "327203511827853313",
      "id" : 327203511827853313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIp13EPCcAEm_-L.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/Y3WYQX6EhH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327223761440997377",
  "text" : "Photo of the Day: @DrBiden signs her running shoes before placing them at a memorial honoring the victims in Boston: http:\/\/t.co\/Y3WYQX6EhH",
  "id" : 327223761440997377,
  "created_at" : "2013-04-25 00:53:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327205333778968577",
  "text" : "RT @DrBiden: Today, Dr. Biden left flowers &amp; a pair of her running shoes at a memorial in Copley Square. #BostonStrong http:\/\/t.co\/Bn9z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Bn9zXb6eUk",
        "expanded_url" : "http:\/\/youtu.be\/CioO32hV7gs",
        "display_url" : "youtu.be\/CioO32hV7gs"
      } ]
    },
    "geo" : { },
    "id_str" : "327203124987166721",
    "text" : "Today, Dr. Biden left flowers &amp; a pair of her running shoes at a memorial in Copley Square. #BostonStrong http:\/\/t.co\/Bn9zXb6eUk",
    "id" : 327203124987166721,
    "created_at" : "2013-04-24 23:31:18 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 327205333778968577,
  "created_at" : "2013-04-24 23:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/BqEXDF8Ouz",
      "expanded_url" : "http:\/\/at.wh.gov\/koyem",
      "display_url" : "at.wh.gov\/koyem"
    } ]
  },
  "geo" : { },
  "id_str" : "327190163199520768",
  "text" : "A robotic arm, water filtration bike, and the Watercolor Bot\u2014all at this year's #WHScienceFair: http:\/\/t.co\/BqEXDF8Ouz",
  "id" : 327190163199520768,
  "created_at" : "2013-04-24 22:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Lcm1yLYHBB",
      "expanded_url" : "http:\/\/at.wh.gov\/kow0m",
      "display_url" : "at.wh.gov\/kow0m"
    } ]
  },
  "geo" : { },
  "id_str" : "327177334186713088",
  "text" : "President Obama orders US flags to be flown at half-staff tomorrow to honor the victims of the explosion in West, TX: http:\/\/t.co\/Lcm1yLYHBB",
  "id" : 327177334186713088,
  "created_at" : "2013-04-24 21:48:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/AjuOqmmcVh",
      "expanded_url" : "http:\/\/at.wh.gov\/kofzV",
      "display_url" : "at.wh.gov\/kofzV"
    }, {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/iSUs8sOXEx",
      "expanded_url" : "http:\/\/flic.kr\/p\/dUt1ir",
      "display_url" : "flic.kr\/p\/dUt1ir"
    } ]
  },
  "geo" : { },
  "id_str" : "327153401521639424",
  "text" : "Happy birthday to the Library of Congress\u2014established on this day in 1800: http:\/\/t.co\/AjuOqmmcVh, http:\/\/t.co\/iSUs8sOXEx",
  "id" : 327153401521639424,
  "created_at" : "2013-04-24 20:13:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Miranda",
      "screen_name" : "MiraLuisDC",
      "indices" : [ 90, 101 ],
      "id_str" : "724670505832321024",
      "id" : 724670505832321024
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 126, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/KJIlggKZrM",
      "expanded_url" : "http:\/\/at.wh.gov\/koe9q",
      "display_url" : "at.wh.gov\/koe9q"
    } ]
  },
  "geo" : { },
  "id_str" : "327139612491403264",
  "text" : "\"They're not looking for a handout\u2014just a chance to work hard &amp; do the right thing.\" \u2014@MiraLuisDC: http:\/\/t.co\/KJIlggKZrM #ImmigrationReform",
  "id" : 327139612491403264,
  "created_at" : "2013-04-24 19:18:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wYVAiCVsiW",
      "expanded_url" : "http:\/\/at.wh.gov\/ko4hZ",
      "display_url" : "at.wh.gov\/ko4hZ"
    } ]
  },
  "geo" : { },
  "id_str" : "327121471069618177",
  "text" : "\"Sylvia has spent a career fighting for working families.\" \u2014Obama on Senate confirmation of the next budget director: http:\/\/t.co\/wYVAiCVsiW",
  "id" : 327121471069618177,
  "created_at" : "2013-04-24 18:06:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/327112432952672258\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/0UyhtJ9yM0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIojBlBCAAECy_e.jpg",
      "id_str" : "327112432961060865",
      "id" : 327112432961060865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIojBlBCAAECy_e.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0UyhtJ9yM0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/C28Ro2uJI1",
      "expanded_url" : "http:\/\/at.wh.gov\/knZqX",
      "display_url" : "at.wh.gov\/knZqX"
    } ]
  },
  "geo" : { },
  "id_str" : "327112432952672258",
  "text" : "Happy National Park Week! Visit some of our country's most beautiful places for free: http:\/\/t.co\/C28Ro2uJI1, http:\/\/t.co\/0UyhtJ9yM0",
  "id" : 327112432952672258,
  "created_at" : "2013-04-24 17:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/327073681299873792\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/DAv7lIBo46",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIn_x72CIAEFQq_.jpg",
      "id_str" : "327073681304068097",
      "id" : 327073681304068097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIn_x72CIAEFQq_.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DAv7lIBo46"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327073681299873792",
  "text" : "Thank you. http:\/\/t.co\/DAv7lIBo46",
  "id" : 327073681299873792,
  "created_at" : "2013-04-24 14:56:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 74, 83 ],
      "id_str" : "15754281",
      "id" : 15754281
    }, {
      "name" : "Luis Miranda",
      "screen_name" : "MiraLuisDC",
      "indices" : [ 116, 127 ],
      "id_str" : "724670505832321024",
      "id" : 724670505832321024
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327069505794752513",
  "text" : "RT @pfeiffer44: Moving story and powerful case for #immigration reform in @usatoday from former White House staffer @MiraLuisDC http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA TODAY",
        "screen_name" : "USATODAY",
        "indices" : [ 58, 67 ],
        "id_str" : "15754281",
        "id" : 15754281
      }, {
        "name" : "Luis Miranda",
        "screen_name" : "MiraLuisDC",
        "indices" : [ 100, 111 ],
        "id_str" : "724670505832321024",
        "id" : 724670505832321024
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 35, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/VORxRLfsNs",
        "expanded_url" : "http:\/\/usat.ly\/XUQY7q",
        "display_url" : "usat.ly\/XUQY7q"
      } ]
    },
    "geo" : { },
    "id_str" : "327062262995103745",
    "text" : "Moving story and powerful case for #immigration reform in @usatoday from former White House staffer @MiraLuisDC http:\/\/t.co\/VORxRLfsNs",
    "id" : 327062262995103745,
    "created_at" : "2013-04-24 14:11:34 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 327069505794752513,
  "created_at" : "2013-04-24 14:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Super-Awesome Sylvia",
      "screen_name" : "MakerSylvia",
      "indices" : [ 35, 47 ],
      "id_str" : "564157285",
      "id" : 564157285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/xGL1Ny9pxt",
      "expanded_url" : "http:\/\/nyti.ms\/YLLEk4",
      "display_url" : "nyti.ms\/YLLEk4"
    } ]
  },
  "geo" : { },
  "id_str" : "327056302754889728",
  "text" : "RT @ks44: Super awesome profile of @MakerSylvia who joined the #WHScienceFair: http:\/\/t.co\/xGL1Ny9pxt See her Watercolor Bot: http:\/\/t.co\/q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Super-Awesome Sylvia",
        "screen_name" : "MakerSylvia",
        "indices" : [ 25, 37 ],
        "id_str" : "564157285",
        "id" : 564157285
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 53, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/xGL1Ny9pxt",
        "expanded_url" : "http:\/\/nyti.ms\/YLLEk4",
        "display_url" : "nyti.ms\/YLLEk4"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/qEfVTkdSC3",
        "expanded_url" : "http:\/\/vine.co\/v\/bPZWQBtj6t7",
        "display_url" : "vine.co\/v\/bPZWQBtj6t7"
      } ]
    },
    "geo" : { },
    "id_str" : "327050446021746688",
    "text" : "Super awesome profile of @MakerSylvia who joined the #WHScienceFair: http:\/\/t.co\/xGL1Ny9pxt See her Watercolor Bot: http:\/\/t.co\/qEfVTkdSC3",
    "id" : 327050446021746688,
    "created_at" : "2013-04-24 13:24:37 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 327056302754889728,
  "created_at" : "2013-04-24 13:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/326841608064598017\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/NBdZ7NGrWt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIkstfsCAAAvHXI.jpg",
      "id_str" : "326841608072986624",
      "id" : 326841608072986624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIkstfsCAAAvHXI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/NBdZ7NGrWt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326841608064598017",
  "text" : "RT this to say thanks to the teachers that made a difference in your life. http:\/\/t.co\/NBdZ7NGrWt",
  "id" : 326841608064598017,
  "created_at" : "2013-04-23 23:34:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326766353539289089",
  "text" : "President Obama: \u201CWe need a better way to recruit, prepare, and reward our next generation of great educators.\u201D",
  "id" : 326766353539289089,
  "created_at" : "2013-04-23 18:35:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326763340179337219",
  "text" : "\u201CThey do more than educate children. They embrace and nurture and truly love them.\u201D \u2014Obama on the critical role of teachers #ThankATeacher",
  "id" : 326763340179337219,
  "created_at" : "2013-04-23 18:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Charbonneau",
      "screen_name" : "JeffCharbonneau",
      "indices" : [ 62, 78 ],
      "id_str" : "1177666310",
      "id" : 1177666310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326761963713601536",
  "text" : "President Obama: \"This year\u2019s national teacher of the year is @JeffCharbonneau from Zillah, Washington.\" #ThankATeacher",
  "id" : 326761963713601536,
  "created_at" : "2013-04-23 18:18:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326760080282357760",
  "text" : "President Obama: \u201CIf there is one thing we can\u2019t say enough to our nation\u2019s educators, it is \u2018thank you.\u2019\u201D #ThankATeacher",
  "id" : 326760080282357760,
  "created_at" : "2013-04-23 18:10:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/1SM8Ngwxri",
      "expanded_url" : "http:\/\/at.wh.gov\/klDZi",
      "display_url" : "at.wh.gov\/klDZi"
    } ]
  },
  "geo" : { },
  "id_str" : "326759656099831808",
  "text" : "Happening now: President Obama honors the 2013 National Teacher of the Year. http:\/\/t.co\/1SM8Ngwxri #ThankATeacher",
  "id" : 326759656099831808,
  "created_at" : "2013-04-23 18:09:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/aNhZYQdinP",
      "expanded_url" : "http:\/\/at.wh.gov\/klBcq",
      "display_url" : "at.wh.gov\/klBcq"
    } ]
  },
  "geo" : { },
  "id_str" : "326751797270179841",
  "text" : "Worth a RT: Some pretty amazing young scientists (plus President Obama riding a water filtration bike). http:\/\/t.co\/aNhZYQdinP",
  "id" : 326751797270179841,
  "created_at" : "2013-04-23 17:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/326738789223518208\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/sMMHxGvX9Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIjPMppCUAAZdhv.jpg",
      "id_str" : "326738789227712512",
      "id" : 326738789227712512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIjPMppCUAAZdhv.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/sMMHxGvX9Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326738789223518208",
  "text" : "When our kids succeed in math and science, we all succeed: http:\/\/t.co\/sMMHxGvX9Z",
  "id" : 326738789223518208,
  "created_at" : "2013-04-23 16:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/X3NHufS5L1",
      "expanded_url" : "http:\/\/at.wh.gov\/klkPp",
      "display_url" : "at.wh.gov\/klkPp"
    } ]
  },
  "geo" : { },
  "id_str" : "326726874413805568",
  "text" : "Obama on the Equal Futures Challenge: \"I want our daughters to imagine themselves as the next generation of leaders.\" http:\/\/t.co\/X3NHufS5L1",
  "id" : 326726874413805568,
  "created_at" : "2013-04-23 15:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 136, 150 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/W6CgCE6lMp",
      "expanded_url" : "http:\/\/at.wh.gov\/kl7u5",
      "display_url" : "at.wh.gov\/kl7u5"
    } ]
  },
  "geo" : { },
  "id_str" : "326708534320431105",
  "text" : "Obama: \"We\u2019re here to celebrate these young scientists &amp; visionaries who dream &amp; create &amp; innovate.\" http:\/\/t.co\/W6CgCE6lMp #WHScienceFair",
  "id" : 326708534320431105,
  "created_at" : "2013-04-23 14:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 9, 23 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 28, 40 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/0gdnaVNX6Z",
      "expanded_url" : "http:\/\/at.wh.gov\/kkX3F",
      "display_url" : "at.wh.gov\/kkX3F"
    } ]
  },
  "geo" : { },
  "id_str" : "326694514779643904",
  "text" : "Bill Nye @TheScienceGuy and @LeVarBurton take you inside yesterday's #WHScienceFair: http:\/\/t.co\/0gdnaVNX6Z",
  "id" : 326694514779643904,
  "created_at" : "2013-04-23 13:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/326474161478328321\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/j3JiyFPIXk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIfehSfCYAA2FaI.jpg",
      "id_str" : "326474161486716928",
      "id" : 326474161486716928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIfehSfCYAA2FaI.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/j3JiyFPIXk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326474161478328321",
  "text" : "RT if you agree we need to keep making investments in science and innovation. http:\/\/t.co\/j3JiyFPIXk",
  "id" : 326474161478328321,
  "created_at" : "2013-04-22 23:14:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 99, 107 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326458034362658816",
  "text" : "RT @VP: I want to welcome my incredible wife and your Second Lady, Jill, to Twitter. Follow her at @DrBiden. \u2013VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 91, 99 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326451197705846784",
    "text" : "I want to welcome my incredible wife and your Second Lady, Jill, to Twitter. Follow her at @DrBiden. \u2013VP",
    "id" : 326451197705846784,
    "created_at" : "2013-04-22 21:43:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 326458034362658816,
  "created_at" : "2013-04-22 22:10:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/rdZFikiSWB",
      "expanded_url" : "https:\/\/vine.co\/v\/bPZWQBtj6t7",
      "display_url" : "vine.co\/v\/bPZWQBtj6t7"
    } ]
  },
  "geo" : { },
  "id_str" : "326450121887862784",
  "text" : "Meet Super Awesome Sylvia and her Watercolor Bot. #WHScienceFair https:\/\/t.co\/rdZFikiSWB",
  "id" : 326450121887862784,
  "created_at" : "2013-04-22 21:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seventeen Magazine",
      "screen_name" : "seventeenmag",
      "indices" : [ 19, 32 ],
      "id_str" : "3130791519",
      "id" : 3130791519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/m2E6175WQX",
      "expanded_url" : "http:\/\/svn.tn\/president",
      "display_url" : "svn.tn\/president"
    } ]
  },
  "geo" : { },
  "id_str" : "326443840401731584",
  "text" : "President Obama in @seventeenmag on a new app challenge that encourages girls to become leaders in their fields: http:\/\/t.co\/m2E6175WQX",
  "id" : 326443840401731584,
  "created_at" : "2013-04-22 21:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 1, 9 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/326430102827180032\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/YLQ2rGSMAM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIe2cvNCIAE9KIi.jpg",
      "id_str" : "326430102831374337",
      "id" : 326430102831374337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIe2cvNCIAE9KIi.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YLQ2rGSMAM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326430102827180032",
  "text" : ".@DrBiden sends her first tweet to congratulate the 2013 National Teacher of the Year: http:\/\/t.co\/YLQ2rGSMAM",
  "id" : 326430102827180032,
  "created_at" : "2013-04-22 20:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/326411641040281600\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/yjQQ1oOG0T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIelqHsCIAAePEm.jpg",
      "id_str" : "326411641044475904",
      "id" : 326411641044475904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIelqHsCIAAePEm.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/yjQQ1oOG0T"
    } ],
    "hashtags" : [ {
      "text" : "HappyEarthDay",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326411641040281600",
  "text" : "#HappyEarthDay. http:\/\/t.co\/yjQQ1oOG0T",
  "id" : 326411641040281600,
  "created_at" : "2013-04-22 19:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326406327066828802",
  "text" : "Please join the White House in observing a moment of silence in honor of the victims of the Boston Marathon bombings at 2:50pm ET.",
  "id" : 326406327066828802,
  "created_at" : "2013-04-22 18:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHsciencefair",
      "indices" : [ 59, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/1Yeh6vOxY2",
      "expanded_url" : "https:\/\/vine.co\/v\/bPZtKjjO0qu",
      "display_url" : "vine.co\/v\/bPZtKjjO0qu"
    } ]
  },
  "geo" : { },
  "id_str" : "326404438619209730",
  "text" : "President Obama checks out Vator the Space Elevator at the #WHsciencefair: https:\/\/t.co\/1Yeh6vOxY2",
  "id" : 326404438619209730,
  "created_at" : "2013-04-22 18:37:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326404186935803904",
  "text" : "President Obama: \"I want to thank all of our science fair winners\u2014not just for the work you\u2019re doing, but for the example you\u2019re setting.\"",
  "id" : 326404186935803904,
  "created_at" : "2013-04-22 18:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326403384754200577",
  "text" : "\"Young people like these have to make you hopeful about the future of our country.\" \u2014President Obama on the students at the #WHScienceFair",
  "id" : 326403384754200577,
  "created_at" : "2013-04-22 18:33:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326402030069481472",
  "text" : "President Obama: \"The science fair projects of today could become the products or businesses of tomorrow.\" #WHScienceFair",
  "id" : 326402030069481472,
  "created_at" : "2013-04-22 18:28:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/VvsNcJLSom",
      "expanded_url" : "http:\/\/at.wh.gov\/kihIK",
      "display_url" : "at.wh.gov\/kihIK"
    } ]
  },
  "geo" : { },
  "id_str" : "326401471182688257",
  "text" : "Happening now: President Obama speaks at the #WHScienceFair. http:\/\/t.co\/VvsNcJLSom",
  "id" : 326401471182688257,
  "created_at" : "2013-04-22 18:25:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whsciencefair",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/S9ATE5bXt6",
      "expanded_url" : "https:\/\/vine.co\/v\/bPZJTgQPjjP",
      "display_url" : "vine.co\/v\/bPZJTgQPjjP"
    } ]
  },
  "geo" : { },
  "id_str" : "326393931099160577",
  "text" : "The President rides a bike-powered water filtration system at the #whsciencefair: https:\/\/t.co\/S9ATE5bXt6",
  "id" : 326393931099160577,
  "created_at" : "2013-04-22 17:55:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/6MC6BDJKMx",
      "expanded_url" : "https:\/\/vine.co\/v\/bPZArE1LLYF",
      "display_url" : "vine.co\/v\/bPZArE1LLYF"
    } ]
  },
  "geo" : { },
  "id_str" : "326387679996547072",
  "text" : "17-year-old Easton introduces his 3D printed robotic arm. #WHScienceFair https:\/\/t.co\/6MC6BDJKMx",
  "id" : 326387679996547072,
  "created_at" : "2013-04-22 17:31:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/326369224635330562\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/j6bk5Ieswv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BId_FKSCMAA3iuK.jpg",
      "id_str" : "326369224643719168",
      "id" : 326369224643719168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BId_FKSCMAA3iuK.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1400
      } ],
      "display_url" : "pic.twitter.com\/j6bk5Ieswv"
    } ],
    "hashtags" : [ {
      "text" : "Whsciencefair",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326377454342115328",
  "text" : "RT @whitehouseostp: This girl can code! App-builder Shaquiesha demos her original app. #Whsciencefair http:\/\/t.co\/j6bk5Ieswv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/326369224635330562\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/j6bk5Ieswv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BId_FKSCMAA3iuK.jpg",
        "id_str" : "326369224643719168",
        "id" : 326369224643719168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BId_FKSCMAA3iuK.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1050,
          "resize" : "fit",
          "w" : 1400
        } ],
        "display_url" : "pic.twitter.com\/j6bk5Ieswv"
      } ],
      "hashtags" : [ {
        "text" : "Whsciencefair",
        "indices" : [ 67, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326369224635330562",
    "text" : "This girl can code! App-builder Shaquiesha demos her original app. #Whsciencefair http:\/\/t.co\/j6bk5Ieswv",
    "id" : 326369224635330562,
    "created_at" : "2013-04-22 16:17:41 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 326377454342115328,
  "created_at" : "2013-04-22 16:50:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reading Rainbow",
      "screen_name" : "readingrainbow",
      "indices" : [ 3, 18 ],
      "id_str" : "480120122",
      "id" : 480120122
    }, {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 29, 41 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326372203086090240",
  "text" : "RT @readingrainbow: Watching @levarburton at the #WHScienceFair interviewing students: These students and their projects are inspiring! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LeVar Burton",
        "screen_name" : "levarburton",
        "indices" : [ 9, 21 ],
        "id_str" : "18396070",
        "id" : 18396070
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 29, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/MHb71zvvWi",
        "expanded_url" : "http:\/\/1.usa.gov\/ZeEkRz",
        "display_url" : "1.usa.gov\/ZeEkRz"
      } ]
    },
    "geo" : { },
    "id_str" : "326363646202634240",
    "text" : "Watching @levarburton at the #WHScienceFair interviewing students: These students and their projects are inspiring! http:\/\/t.co\/MHb71zvvWi",
    "id" : 326363646202634240,
    "created_at" : "2013-04-22 15:55:31 +0000",
    "user" : {
      "name" : "Reading Rainbow",
      "screen_name" : "readingrainbow",
      "protected" : false,
      "id_str" : "480120122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738089393605349377\/I95mwaIv_normal.jpg",
      "id" : 480120122,
      "verified" : true
    }
  },
  "id" : 326372203086090240,
  "created_at" : "2013-04-22 16:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/326351457181904896\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/YLYiBquIpy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIdu69XCMAE72sK.jpg",
      "id_str" : "326351457190293505",
      "id" : 326351457190293505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIdu69XCMAE72sK.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1400
      } ],
      "display_url" : "pic.twitter.com\/YLYiBquIpy"
    } ],
    "hashtags" : [ {
      "text" : "whsciencefair",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326369355321450496",
  "text" : "RT @whitehouseostp: Evan, Alec, and Caleb - kid inventors, get interviewed before the main event! #whsciencefair http:\/\/t.co\/YLYiBquIpy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/326351457181904896\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/YLYiBquIpy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BIdu69XCMAE72sK.jpg",
        "id_str" : "326351457190293505",
        "id" : 326351457190293505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIdu69XCMAE72sK.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1050,
          "resize" : "fit",
          "w" : 1400
        } ],
        "display_url" : "pic.twitter.com\/YLYiBquIpy"
      } ],
      "hashtags" : [ {
        "text" : "whsciencefair",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326351457181904896",
    "text" : "Evan, Alec, and Caleb - kid inventors, get interviewed before the main event! #whsciencefair http:\/\/t.co\/YLYiBquIpy",
    "id" : 326351457181904896,
    "created_at" : "2013-04-22 15:07:05 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 326369355321450496,
  "created_at" : "2013-04-22 16:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 3, 15 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326365902356488194",
  "text" : "RT @levarburton: I love that POTUS has invited these scholars here and treating them like NCAA Champs!!! #WHScienceFair",
  "id" : 326365902356488194,
  "created_at" : "2013-04-22 16:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 9, 23 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 30, 42 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/wKoIjJqklh",
      "expanded_url" : "https:\/\/vine.co\/v\/bP7JIZtYxrK",
      "display_url" : "vine.co\/v\/bP7JIZtYxrK"
    } ]
  },
  "geo" : { },
  "id_str" : "326359719151300609",
  "text" : "Bill Nye @TheScienceGuy &amp; @LevarBurton welcome you to the #WHScienceFair! https:\/\/t.co\/wKoIjJqklh",
  "id" : 326359719151300609,
  "created_at" : "2013-04-22 15:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 15, 27 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/326356996368523264\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9ZXmNRPmJh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIdz9YcCYAAhTIA.jpg",
      "id_str" : "326356996376911872",
      "id" : 326356996376911872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIdz9YcCYAAhTIA.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/9ZXmNRPmJh"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/BWcHxjsvyE",
      "expanded_url" : "http:\/\/on.wh.gov\/kf1oACH",
      "display_url" : "on.wh.gov\/kf1oACH"
    } ]
  },
  "geo" : { },
  "id_str" : "326356996368523264",
  "text" : "Happening now: @LeVarBurton hosts live coverage of the 3rd annual #WHScienceFair http:\/\/t.co\/BWcHxjsvyE http:\/\/t.co\/9ZXmNRPmJh",
  "id" : 326356996368523264,
  "created_at" : "2013-04-22 15:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/RbWO249DnL",
      "expanded_url" : "http:\/\/at.wh.gov\/keAzN",
      "display_url" : "at.wh.gov\/keAzN"
    } ]
  },
  "geo" : { },
  "id_str" : "326351319751335936",
  "text" : "\"We belong on the cutting edge of innovation.\" \u2014President Obama at last year's #WHScienceFair: http:\/\/t.co\/RbWO249DnL",
  "id" : 326351319751335936,
  "created_at" : "2013-04-22 15:06:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/yTAyH61TIA",
      "expanded_url" : "http:\/\/at.wh.gov\/kep0d",
      "display_url" : "at.wh.gov\/kep0d"
    } ]
  },
  "geo" : { },
  "id_str" : "326340073387872256",
  "text" : "In case you missed it: President Obama, a brilliant 8th grader, &amp; a marshmallow cannon at last year's #WHScienceFair. http:\/\/t.co\/yTAyH61TIA",
  "id" : 326340073387872256,
  "created_at" : "2013-04-22 14:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/326329137725837312\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/n9aHRzcKjp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIdany6CEAEYDfN.jpg",
      "id_str" : "326329137734225921",
      "id" : 326329137734225921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIdany6CEAEYDfN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n9aHRzcKjp"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/VvsNcJLSom",
      "expanded_url" : "http:\/\/at.wh.gov\/kihIK",
      "display_url" : "at.wh.gov\/kihIK"
    } ]
  },
  "geo" : { },
  "id_str" : "326329137725837312",
  "text" : "Watch live coverage of this year's #WHScienceFair starting at 11:30ET: http:\/\/t.co\/VvsNcJLSom, http:\/\/t.co\/n9aHRzcKjp",
  "id" : 326329137725837312,
  "created_at" : "2013-04-22 13:38:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/pqGOgPISUi",
      "expanded_url" : "http:\/\/youtu.be\/4H5ocEjhkYw",
      "display_url" : "youtu.be\/4H5ocEjhkYw"
    } ]
  },
  "geo" : { },
  "id_str" : "325699465048633345",
  "text" : "President Obama's Weekly Address: America Stands with the City of Boston: http:\/\/t.co\/pqGOgPISUi",
  "id" : 325699465048633345,
  "created_at" : "2013-04-20 19:56:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pqGOgPISUi",
      "expanded_url" : "http:\/\/youtu.be\/4H5ocEjhkYw",
      "display_url" : "youtu.be\/4H5ocEjhkYw"
    } ]
  },
  "geo" : { },
  "id_str" : "325590313047556097",
  "text" : "\"Through days that would test even the sturdiest of souls, Boston\u2019s spirit remains undaunted.\" \u2014President Obama: http:\/\/t.co\/pqGOgPISUi",
  "id" : 325590313047556097,
  "created_at" : "2013-04-20 12:42:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325456931194011648",
  "text" : "RT @FLOTUS: Grateful for the brave law enforcement officials &amp; the people of Boston. My prayers are with the victims &amp; their famili\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bostonstrong",
        "indices" : [ 130, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325456114214912000",
    "text" : "Grateful for the brave law enforcement officials &amp; the people of Boston. My prayers are with the victims &amp; their families #bostonstrong -mo",
    "id" : 325456114214912000,
    "created_at" : "2013-04-20 03:49:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 325456931194011648,
  "created_at" : "2013-04-20 03:52:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325454619939577856",
  "text" : "RT @petesouza: Photo of POTUS on the phone w FBI Director Robert Mueller shortly after second suspect was taken into custody http:\/\/t.co\/Qq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/325454128111300608\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/QqgVl1c6bn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BIQ-ziFCMAAY9rP.jpg",
        "id_str" : "325454128119689216",
        "id" : 325454128119689216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIQ-ziFCMAAY9rP.jpg",
        "sizes" : [ {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QqgVl1c6bn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325454128111300608",
    "text" : "Photo of POTUS on the phone w FBI Director Robert Mueller shortly after second suspect was taken into custody http:\/\/t.co\/QqgVl1c6bn",
    "id" : 325454128111300608,
    "created_at" : "2013-04-20 03:41:25 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 325454619939577856,
  "created_at" : "2013-04-20 03:43:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gY3HyBfKVL",
      "expanded_url" : "http:\/\/youtu.be\/bXchBWwxI_k",
      "display_url" : "youtu.be\/bXchBWwxI_k"
    } ]
  },
  "geo" : { },
  "id_str" : "325452226195759104",
  "text" : "\"All in all, this has been a tough week.\" POTUS on news in Boston, explosion in Texas &amp; our country's character: http:\/\/t.co\/gY3HyBfKVL",
  "id" : 325452226195759104,
  "created_at" : "2013-04-20 03:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325441912481914880",
  "text" : "RT @petesouza: New photo of POTUS receiving update from Lisa Monaco following capture of second suspect in Boston Marathon bombing: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/T0DD4HtRT7",
        "expanded_url" : "http:\/\/bit.ly\/ZyxEx6",
        "display_url" : "bit.ly\/ZyxEx6"
      } ]
    },
    "geo" : { },
    "id_str" : "325441524731101184",
    "text" : "New photo of POTUS receiving update from Lisa Monaco following capture of second suspect in Boston Marathon bombing: http:\/\/t.co\/T0DD4HtRT7",
    "id" : 325441524731101184,
    "created_at" : "2013-04-20 02:51:20 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 325441912481914880,
  "created_at" : "2013-04-20 02:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edgar Z\u00FA\u00F1iga Montoya",
      "screen_name" : "edgarzuniga",
      "indices" : [ 3, 15 ],
      "id_str" : "22999513",
      "id" : 22999513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325434421345923075",
  "text" : "RT @edgarzuniga: POTUS cautions not to rush on judgement... \"on entire groups of people...\" \"we welcome people from around the world\" #Amer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "America",
        "indices" : [ 117, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325431225911238657",
    "text" : "POTUS cautions not to rush on judgement... \"on entire groups of people...\" \"we welcome people from around the world\" #America",
    "id" : 325431225911238657,
    "created_at" : "2013-04-20 02:10:25 +0000",
    "user" : {
      "name" : "Edgar Z\u00FA\u00F1iga Montoya",
      "screen_name" : "edgarzuniga",
      "protected" : false,
      "id_str" : "22999513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797977253175066624\/KVcJ9fTO_normal.jpg",
      "id" : 22999513,
      "verified" : false
    }
  },
  "id" : 325434421345923075,
  "created_at" : "2013-04-20 02:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 3, 11 ],
      "id_str" : "232193350",
      "id" : 232193350
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325432178521554944",
  "text" : "RT @rajshah: POTUS: \"They failed because we refuse to be terrorized.\" @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 57, 68 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325431654841720832",
    "text" : "POTUS: \"They failed because we refuse to be terrorized.\" @whitehouse",
    "id" : 325431654841720832,
    "created_at" : "2013-04-20 02:12:07 +0000",
    "user" : {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "protected" : false,
      "id_str" : "232193350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486242763227152384\/vse4PX_j_normal.jpeg",
      "id" : 232193350,
      "verified" : true
    }
  },
  "id" : 325432178521554944,
  "created_at" : "2013-04-20 02:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325431953694289920",
  "text" : "POTUS: \"I am confident that we have the courage, and the resilience, and the spirit to overcome these challenges\"",
  "id" : 325431953694289920,
  "created_at" : "2013-04-20 02:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325431887277481987",
  "text" : "POTUS: \"This has been a tough week. But we have seen the character of our country once more.\"",
  "id" : 325431887277481987,
  "created_at" : "2013-04-20 02:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325431649150066688",
  "text" : "POTUS: We've also seen a tight-knit community in Texas devastated by a terrible explosion, &amp; I want them to know that they are not forgotten",
  "id" : 325431649150066688,
  "created_at" : "2013-04-20 02:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325431424603799553",
  "text" : "POTUS: \"Tonight we think of all the wounded, still struggling to recover.\"",
  "id" : 325431424603799553,
  "created_at" : "2013-04-20 02:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430798645858305",
  "text" : "POTUS: \"One thing we do know is that whatever hateful agenda drove these men to such heinous acts will not - cannot - prevail\"",
  "id" : 325430798645858305,
  "created_at" : "2013-04-20 02:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430683868725248",
  "text" : "POTUS: \"We will determine how this happened.  We will investigate any associations that these terrorists may have had\"",
  "id" : 325430683868725248,
  "created_at" : "2013-04-20 02:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430427370258433",
  "text" : "POTUS: \"We also send our prayers, especially, to the Collier family who grieve the loss of their son and brother Sean\"",
  "id" : 325430427370258433,
  "created_at" : "2013-04-20 02:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430365042921472",
  "text" : "POTUS: \"Our thoughts are with those who were wounded in pursuit of the suspects, and we pray for their full recovery\"",
  "id" : 325430365042921472,
  "created_at" : "2013-04-20 02:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430310974152705",
  "text" : "POTUS: We owe a tremendous debt of gratitude to all our outstanding law enforcement professionals",
  "id" : 325430310974152705,
  "created_at" : "2013-04-20 02:06:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430254317481984",
  "text" : "POTUS: \"Close coordination among federal, state, and local officials ... has been critical to this effort\"",
  "id" : 325430254317481984,
  "created_at" : "2013-04-20 02:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325430146125410305",
  "text" : "POTUS: \"Boston Police and State Police and local police across the Commonwealth of Massachusetts responded with professionalism and bravery\"",
  "id" : 325430146125410305,
  "created_at" : "2013-04-20 02:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325429928868859904",
  "text" : "POTUS: \"Tonight our nation is in debt to the people of Boston and of Massachusetts\"",
  "id" : 325429928868859904,
  "created_at" : "2013-04-20 02:05:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/0qcMEk3Ff6",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "325429871616610305",
  "text" : "President Obama is speaking now. Watch live here: http:\/\/t.co\/0qcMEk3Ff6",
  "id" : 325429871616610305,
  "created_at" : "2013-04-20 02:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0qcMEk3Ff6",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "325429385010216960",
  "text" : "President Obama speaks in 2 minutes. Watch live here:  http:\/\/t.co\/0qcMEk3Ff6",
  "id" : 325429385010216960,
  "created_at" : "2013-04-20 02:03:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "watertown",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/fkp4hP13as",
      "expanded_url" : "http:\/\/Wh.gov\/live",
      "display_url" : "Wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "325425293105971201",
  "text" : "Shortly after the Boston press conference concludes, President Obama will address the Nation. Watch at http:\/\/t.co\/fkp4hP13as #watertown",
  "id" : 325425293105971201,
  "created_at" : "2013-04-20 01:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325424991053168640",
  "text" : "RT @jearnest44: POTUS will speak in the White House briefing room shortly after the presser in Boston concludes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325423332491145216",
    "text" : "POTUS will speak in the White House briefing room shortly after the presser in Boston concludes",
    "id" : 325423332491145216,
    "created_at" : "2013-04-20 01:39:03 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 325424991053168640,
  "created_at" : "2013-04-20 01:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/325327411560468480\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/z6nh24ZGnM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIPLjqJCUAAI5AC.jpg",
      "id_str" : "325327411568857088",
      "id" : 325327411568857088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIPLjqJCUAAI5AC.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/z6nh24ZGnM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325327411560468480",
  "text" : "PHOTO: Pres. Obama met with his national security team today on developments in the Boston bombings investigation. http:\/\/t.co\/z6nh24ZGnM",
  "id" : 325327411560468480,
  "created_at" : "2013-04-19 19:17:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N9JZq20S9w",
      "expanded_url" : "http:\/\/at.wh.gov\/kd1RA",
      "display_url" : "at.wh.gov\/kd1RA"
    } ]
  },
  "geo" : { },
  "id_str" : "325066425901395969",
  "text" : "VIDEO: \"You have shown us, Boston, that in the face of evil, Americans will lift up what is good.\" \u2014President Obama: http:\/\/t.co\/N9JZq20S9w",
  "id" : 325066425901395969,
  "created_at" : "2013-04-19 02:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/bQKOx8WCta",
      "expanded_url" : "http:\/\/at.wh.gov\/kcQQd",
      "display_url" : "at.wh.gov\/kcQQd"
    } ]
  },
  "geo" : { },
  "id_str" : "325021570735165442",
  "text" : "\"All of you displayed the very best of the American spirit.\" \u2014President Obama to first responders in Boston: http:\/\/t.co\/bQKOx8WCta",
  "id" : 325021570735165442,
  "created_at" : "2013-04-18 23:02:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 1, 15 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/JYRExa6UtD",
      "expanded_url" : "http:\/\/nyti.ms\/Z4rdlU",
      "display_url" : "nyti.ms\/Z4rdlU"
    } ]
  },
  "geo" : { },
  "id_str" : "325000480658952192",
  "text" : ".@GabbyGiffords: \"Help me tell the truth about the cowardice these senators demonstrated.\" http:\/\/t.co\/JYRExa6UtD",
  "id" : 325000480658952192,
  "created_at" : "2013-04-18 21:38:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/324976166257713152\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/gPIocM1phu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIKMGfaCYAAR_z8.jpg",
      "id_str" : "324976166261907456",
      "id" : 324976166261907456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIKMGfaCYAAR_z8.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/gPIocM1phu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324976166257713152",
  "text" : "We carry on. http:\/\/t.co\/gPIocM1phu",
  "id" : 324976166257713152,
  "created_at" : "2013-04-18 20:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 60, 74 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/JYRExa6UtD",
      "expanded_url" : "http:\/\/nyti.ms\/Z4rdlU",
      "display_url" : "nyti.ms\/Z4rdlU"
    } ]
  },
  "geo" : { },
  "id_str" : "324942099017506816",
  "text" : "Worth a read and a RT: \"A Senate in the Gun Lobby's Grip.\" \u2014@GabbyGiffords on yesterday's vote: http:\/\/t.co\/JYRExa6UtD",
  "id" : 324942099017506816,
  "created_at" : "2013-04-18 17:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324921236213882880",
  "text" : "Obama: \"May God hold close those who have been taken from us too soon...and may He continue to watch over these United States of America.\"",
  "id" : 324921236213882880,
  "created_at" : "2013-04-18 16:23:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324921176042401792",
  "text" : "Obama: \"Tomorrow, the sun will rise over Boston...the sun will rise over this country we love. This special place. This state of grace\"",
  "id" : 324921176042401792,
  "created_at" : "2013-04-18 16:23:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324920840720355329",
  "text" : "Obama: \"This time next year, on the 3rd Monday in April, the world will return to this great American city...for the 118th Boston Marathon.\"",
  "id" : 324920840720355329,
  "created_at" : "2013-04-18 16:22:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324920776635604994",
  "text" : "Obama: \"When the Sox, Celtics, Patriots or Bruins are champions again...the crowds will gather &amp; watch a parade go down Boylston Street.\"",
  "id" : 324920776635604994,
  "created_at" : "2013-04-18 16:22:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324920697426165760",
  "text" : "President Obama: \"We carry on. We race. We strive. We build and we work and we love.\"",
  "id" : 324920697426165760,
  "created_at" : "2013-04-18 16:21:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324920166934781953",
  "text" : "President Obama: \"That\u2019s what you have taught us, Boston. That's what you've reminded us. To push on. To persevere.\"",
  "id" : 324920166934781953,
  "created_at" : "2013-04-18 16:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324919677753110528",
  "text" : "President Obama: \"In the face of those who would visit death upon innocents, we will choose to save and comfort and heal.\"",
  "id" : 324919677753110528,
  "created_at" : "2013-04-18 16:17:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324919140555030528",
  "text" : "President Obama: \"You have shown us, Boston, that in the face of evil, Americans will lift up what is good.\"",
  "id" : 324919140555030528,
  "created_at" : "2013-04-18 16:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918901240647680",
  "text" : "President Obama on the bombing in Boston: \"It should be pretty clear by now that they picked the wrong city.\"",
  "id" : 324918901240647680,
  "created_at" : "2013-04-18 16:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918832881889280",
  "text" : "President Obama to the people of Boston: \"Your resolve is the greatest rebuke to whoever committed this heinous act.\"",
  "id" : 324918832881889280,
  "created_at" : "2013-04-18 16:14:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918769384321028",
  "text" : "Obama in Boston: \"Your city is with you. Your country is with you. We will all be with you as you learn to stand &amp; walk &amp; yes, run again.\"",
  "id" : 324918769384321028,
  "created_at" : "2013-04-18 16:14:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918663394254848",
  "text" : "President Obama: \"Our hearts are broken for 8-year old Martin\u2014with his big smile and his bright eyes.\"",
  "id" : 324918663394254848,
  "created_at" : "2013-04-18 16:13:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918373093892096",
  "text" : "President Obama: \"Our prayers are with the Richard family of Dorchester\u2014to Denise &amp; their young daughter Jane\"",
  "id" : 324918373093892096,
  "created_at" : "2013-04-18 16:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918316730830852",
  "text" : "Obama: \"Our prayers are with the Lu family of China who sent their daughter Lingzi to BU so she could experience all this city has to offer\"",
  "id" : 324918316730830852,
  "created_at" : "2013-04-18 16:12:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324918221721440258",
  "text" : "President Obama: \"Today our prayers are with the Campbell family of Medford\u2014they're here today. Their daughter Krystle was always smiling.\"",
  "id" : 324918221721440258,
  "created_at" : "2013-04-18 16:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324917879545933826",
  "text" : "President Obama: \"In this moment of grief, we join you in saying\u2014'Boston, you\u2019re my home.'\"",
  "id" : 324917879545933826,
  "created_at" : "2013-04-18 16:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324917681616723968",
  "text" : "Obama: \"Whether folks come here for just a day or stay here for years they leave with a piece of this town tucked firmly into their hearts\"",
  "id" : 324917681616723968,
  "created_at" : "2013-04-18 16:09:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324917125208739840",
  "text" : "\"One of the reasons the world knows Boston so well is that Boston opens its heart to the world.\" \u2014President Obama",
  "id" : 324917125208739840,
  "created_at" : "2013-04-18 16:07:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324916962784329728",
  "text" : "President Obama: \"I am here today on behalf of the American people with a simple message...every one of us stands with you.\"",
  "id" : 324916962784329728,
  "created_at" : "2013-04-18 16:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324916737269182465",
  "text" : "Obama: \"We also come together...to reaffirm that the spirit of this city is undaunted &amp; the spirit of this country shall remain undimmed.\"",
  "id" : 324916737269182465,
  "created_at" : "2013-04-18 16:06:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "324916178298499072",
  "text" : "\"On Monday morning, the sun rose over Boston.\" -President Obama speaking at an Interfaith Service in Boston. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 324916178298499072,
  "created_at" : "2013-04-18 16:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "324915895027769344",
  "text" : "Happening now: President Obama speaks at an interfaith service dedicated to victims of the bombing in Boston: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 324915895027769344,
  "created_at" : "2013-04-18 16:02:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324895707649671168",
  "text" : "RT @WHLive: Happening at 11ET: President Obama speaks at an interfaith service dedicated to victims of the bombing in Boston. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/oPflTkkHep",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "324895521716174849",
    "text" : "Happening at 11ET: President Obama speaks at an interfaith service dedicated to victims of the bombing in Boston. http:\/\/t.co\/oPflTkkHep",
    "id" : 324895521716174849,
    "created_at" : "2013-04-18 14:41:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 324895707649671168,
  "created_at" : "2013-04-18 14:42:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestTX",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/jp6ZcS00Ep",
      "expanded_url" : "http:\/\/wh.gov\/eofx",
      "display_url" : "wh.gov\/eofx"
    } ]
  },
  "geo" : { },
  "id_str" : "324892423417380866",
  "text" : "President Obama: \"Today, our prayers go out to the people of West, Texas.\" http:\/\/t.co\/jp6ZcS00Ep #WestTX",
  "id" : 324892423417380866,
  "created_at" : "2013-04-18 14:29:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/324677140123623425\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/8xvyPFV4zF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIF8I4RCIAEVoB1.jpg",
      "id_str" : "324677140132012033",
      "id" : 324677140132012033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIF8I4RCIAEVoB1.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/8xvyPFV4zF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324677140123623425",
  "text" : "RT if you agree: It's shameful that Washington voted to protect special interests instead of our kids. http:\/\/t.co\/8xvyPFV4zF",
  "id" : 324677140123623425,
  "created_at" : "2013-04-18 00:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 12, 26 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/B5zxbZ1mOk",
      "expanded_url" : "http:\/\/at.wh.gov\/kazQu",
      "display_url" : "at.wh.gov\/kazQu"
    } ]
  },
  "geo" : { },
  "id_str" : "324667220993142784",
  "text" : "Standing w\/ @GabbyGiffords &amp; #Newtown parents, the President spoke on the Senate blocking steps to protect our kids: http:\/\/t.co\/B5zxbZ1mOk",
  "id" : 324667220993142784,
  "created_at" : "2013-04-17 23:34:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324642079663878144",
  "text" : "President Obama: \"Sooner or later, we are going to get this right. The memories of these children demand it. And so do the American people.\"",
  "id" : 324642079663878144,
  "created_at" : "2013-04-17 21:54:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324641057356775425",
  "text" : "President Obama: \"I want to make it clear to the American people that we can still bring about meaningful changes that reduce gun violence\"",
  "id" : 324641057356775425,
  "created_at" : "2013-04-17 21:50:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324640900674363392",
  "text" : "President Obama: \"This was a pretty shameful day for Washington. But this effort isn\u2019t over.\"",
  "id" : 324640900674363392,
  "created_at" : "2013-04-17 21:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324639820909522945",
  "text" : "\"Instead of supporting this compromise, the gun lobby and its allies willfully lied about the bill.\" \u2014President Obama",
  "id" : 324639820909522945,
  "created_at" : "2013-04-17 21:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324639119001124865",
  "text" : "President Obama: \"90% of the American people support universal background checks that make it harder for a dangerous person to buy a gun.\"",
  "id" : 324639119001124865,
  "created_at" : "2013-04-17 21:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324638748853809152",
  "text" : "President Obama: \"In response to too many tragedies\u2026this country took up the cause of protecting more of our people from gun violence\"",
  "id" : 324638748853809152,
  "created_at" : "2013-04-17 21:41:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "324637106121097216",
  "text" : "Happening now: President Obama delivers a statement on reducing gun violence in the Rose Garden. Watch: http:\/\/t.co\/b4tqL3nPDV #NowIsTheTime",
  "id" : 324637106121097216,
  "created_at" : "2013-04-17 21:34:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324631702150455296",
  "text" : "\"90% of Americans support universal background checks. Think about that. How often do 90% of Americans agree on anything?\" \u2014President Obama",
  "id" : 324631702150455296,
  "created_at" : "2013-04-17 21:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "324627584585461762",
  "text" : "The President will deliver a statement on commonsense measures to reduce gun violence at 5:30 ET. Watch http:\/\/t.co\/b4tqL3nPDV #NowIsTheTime",
  "id" : 324627584585461762,
  "created_at" : "2013-04-17 20:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/324621017949552640\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/oGarD8sD62",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIFJGI3CQAAK-ln.jpg",
      "id_str" : "324621017953746944",
      "id" : 324621017953746944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIFJGI3CQAAK-ln.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/oGarD8sD62"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324621017949552640",
  "text" : "Make your voice heard: Use #NowIsTheTime to share why we need to reduce gun violence and help protect our kids. http:\/\/t.co\/oGarD8sD62",
  "id" : 324621017949552640,
  "created_at" : "2013-04-17 20:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324614748022927360",
  "text" : "\"I hope to God that there are 60 people up there that have the courage to stand up.\" \u2014VP Biden on today's Senate vote to reduce gun violence",
  "id" : 324614748022927360,
  "created_at" : "2013-04-17 20:06:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324610673772486657",
  "text" : "RT if you agree: #NowIsTheTime to help protect our kids by closing background check loopholes for all gun sales.",
  "id" : 324610673772486657,
  "created_at" : "2013-04-17 19:49:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/fpzHUzGoQK",
      "expanded_url" : "http:\/\/thndr.it\/ZfKLAb",
      "display_url" : "thndr.it\/ZfKLAb"
    } ]
  },
  "geo" : { },
  "id_str" : "324604506497236992",
  "text" : "I support common-sense steps to reduce gun violence. #NowIsTheTime to act. Share this if you agree: http:\/\/t.co\/fpzHUzGoQK",
  "id" : 324604506497236992,
  "created_at" : "2013-04-17 19:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324600981293780993",
  "text" : "FACT: Background checks have already kept more than 2 million guns out of dangerous hands. #NowIsTheTime",
  "id" : 324600981293780993,
  "created_at" : "2013-04-17 19:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/f0LdIOuvko",
      "expanded_url" : "http:\/\/at.wh.gov\/k9Fb0",
      "display_url" : "at.wh.gov\/k9Fb0"
    } ]
  },
  "geo" : { },
  "id_str" : "324597637187780608",
  "text" : "Happening now: @VP Biden joins mayors around the country to discuss why we need to reduce gun violence. http:\/\/t.co\/f0LdIOuvko #NowIsTheTime",
  "id" : 324597637187780608,
  "created_at" : "2013-04-17 18:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ESBktw1EiK",
      "expanded_url" : "http:\/\/at.wh.gov\/k9ZQM",
      "display_url" : "at.wh.gov\/k9ZQM"
    } ]
  },
  "geo" : { },
  "id_str" : "324588049717682176",
  "text" : "Join a Google Hangout with @VP Biden &amp; mayors around the country at 2:45pm ET on reducing gun violence: http:\/\/t.co\/ESBktw1EiK #NowIsTheTime",
  "id" : 324588049717682176,
  "created_at" : "2013-04-17 18:19:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324582719550025728",
  "text" : "FACT: Nearly 40% of gun sales still don't require background checks under current law. #NowIsTheTime",
  "id" : 324582719550025728,
  "created_at" : "2013-04-17 17:58:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324577890593275906",
  "text" : "FACT: 92% of Americans support closing background check loopholes for all gun sales. #NowIsTheTime",
  "id" : 324577890593275906,
  "created_at" : "2013-04-17 17:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/f0LdIOuvko",
      "expanded_url" : "http:\/\/at.wh.gov\/k9Fb0",
      "display_url" : "at.wh.gov\/k9Fb0"
    } ]
  },
  "geo" : { },
  "id_str" : "324568889889529857",
  "text" : "Add your name and RT this link if you support common-sense steps to reduce gun violence: http:\/\/t.co\/f0LdIOuvko #NowIsTheTime",
  "id" : 324568889889529857,
  "created_at" : "2013-04-17 17:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324564914855350273",
  "text" : "RT @PAniskoff44: Our voices are louder when we speak together! #NowIsTheTime to take action on gun violence. Add your name here: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 46, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/auMneSrxbC",
        "expanded_url" : "http:\/\/at.wh.gov\/k9Fb0",
        "display_url" : "at.wh.gov\/k9Fb0"
      } ]
    },
    "geo" : { },
    "id_str" : "324564119275581440",
    "text" : "Our voices are louder when we speak together! #NowIsTheTime to take action on gun violence. Add your name here: http:\/\/t.co\/auMneSrxbC",
    "id" : 324564119275581440,
    "created_at" : "2013-04-17 16:44:50 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 324564914855350273,
  "created_at" : "2013-04-17 16:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki Gurley",
      "screen_name" : "NGurley",
      "indices" : [ 3, 11 ],
      "id_str" : "294243009",
      "id" : 294243009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324563584858353664",
  "text" : "RT @NGurley: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/RRmc1lwgNz",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324561073543999489",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/RRmc1lwgNz",
    "id" : 324561073543999489,
    "created_at" : "2013-04-17 16:32:44 +0000",
    "user" : {
      "name" : "Nikki Gurley",
      "screen_name" : "NGurley",
      "protected" : false,
      "id_str" : "294243009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3214842493\/f779cbeb586f73cbd738e393bd6c40f2_normal.jpeg",
      "id" : 294243009,
      "verified" : false
    }
  },
  "id" : 324563584858353664,
  "created_at" : "2013-04-17 16:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Applegate",
      "screen_name" : "capplegate5",
      "indices" : [ 3, 15 ],
      "id_str" : "21261836",
      "id" : 21261836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324562949853310978",
  "text" : "RT @capplegate5: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/GB6yYWcQ3J",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324562610538287105",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/GB6yYWcQ3J",
    "id" : 324562610538287105,
    "created_at" : "2013-04-17 16:38:51 +0000",
    "user" : {
      "name" : "Chris Applegate",
      "screen_name" : "capplegate5",
      "protected" : false,
      "id_str" : "21261836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798219567982137344\/08qnT5lZ_normal.jpg",
      "id" : 21261836,
      "verified" : false
    }
  },
  "id" : 324562949853310978,
  "created_at" : "2013-04-17 16:40:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecelia Prewett",
      "screen_name" : "CeceliaJP",
      "indices" : [ 3, 13 ],
      "id_str" : "146010573",
      "id" : 146010573
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324561933669896194",
  "text" : "RT @CeceliaJP: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/SysjoETLZy",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324561704266645505",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/SysjoETLZy",
    "id" : 324561704266645505,
    "created_at" : "2013-04-17 16:35:15 +0000",
    "user" : {
      "name" : "Cecelia Prewett",
      "screen_name" : "CeceliaJP",
      "protected" : false,
      "id_str" : "146010573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459769690957443072\/6igzUISg_normal.jpeg",
      "id" : 146010573,
      "verified" : false
    }
  },
  "id" : 324561933669896194,
  "created_at" : "2013-04-17 16:36:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TecHOUNDS",
      "screen_name" : "TECHOUNDS",
      "indices" : [ 3, 13 ],
      "id_str" : "14237740",
      "id" : 14237740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324559952842727424",
  "text" : "RT @TECHOUNDS: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PlgujlZf7a",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324558285166505984",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/PlgujlZf7a",
    "id" : 324558285166505984,
    "created_at" : "2013-04-17 16:21:39 +0000",
    "user" : {
      "name" : "TecHOUNDS",
      "screen_name" : "TECHOUNDS",
      "protected" : false,
      "id_str" : "14237740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489134622614097920\/WqkH1xz6_normal.jpeg",
      "id" : 14237740,
      "verified" : false
    }
  },
  "id" : 324559952842727424,
  "created_at" : "2013-04-17 16:28:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leslie casse",
      "screen_name" : "marygroovy",
      "indices" : [ 3, 14 ],
      "id_str" : "97264559",
      "id" : 97264559
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/mWQed7w9dm",
      "expanded_url" : "http:\/\/thndr.it\/ZfKLAb",
      "display_url" : "thndr.it\/ZfKLAb"
    } ]
  },
  "geo" : { },
  "id_str" : "324559285629640704",
  "text" : "RT @marygroovy: I support common-sense steps to reduce gun violence. #NowIsTheTime to act. Share this if you agree: http:\/\/t.co\/mWQed7w9dm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 53, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/mWQed7w9dm",
        "expanded_url" : "http:\/\/thndr.it\/ZfKLAb",
        "display_url" : "thndr.it\/ZfKLAb"
      } ]
    },
    "geo" : { },
    "id_str" : "324557964017033216",
    "text" : "I support common-sense steps to reduce gun violence. #NowIsTheTime to act. Share this if you agree: http:\/\/t.co\/mWQed7w9dm",
    "id" : 324557964017033216,
    "created_at" : "2013-04-17 16:20:23 +0000",
    "user" : {
      "name" : "leslie casse",
      "screen_name" : "marygroovy",
      "protected" : false,
      "id_str" : "97264559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482370222910107648\/j86tudJ3_normal.jpeg",
      "id" : 97264559,
      "verified" : false
    }
  },
  "id" : 324559285629640704,
  "created_at" : "2013-04-17 16:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne",
      "screen_name" : "iluvgs400",
      "indices" : [ 3, 13 ],
      "id_str" : "12167462",
      "id" : 12167462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324557874305048577",
  "text" : "RT @iluvgs400: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/dZHq4fSSH9",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324557624152555521",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/dZHq4fSSH9",
    "id" : 324557624152555521,
    "created_at" : "2013-04-17 16:19:02 +0000",
    "user" : {
      "name" : "Wayne",
      "screen_name" : "iluvgs400",
      "protected" : false,
      "id_str" : "12167462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000220199700\/51b7114a8e1f015cbd67dde8960c8d08_normal.jpeg",
      "id" : 12167462,
      "verified" : false
    }
  },
  "id" : 324557874305048577,
  "created_at" : "2013-04-17 16:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Luginbill",
      "screen_name" : "JoeLuginbill",
      "indices" : [ 3, 16 ],
      "id_str" : "523886156",
      "id" : 523886156
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324557599917879296",
  "text" : "RT @JoeLuginbill: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/foA9tjgz8K",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324556979760685057",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/foA9tjgz8K",
    "id" : 324556979760685057,
    "created_at" : "2013-04-17 16:16:28 +0000",
    "user" : {
      "name" : "Joe Luginbill",
      "screen_name" : "JoeLuginbill",
      "protected" : false,
      "id_str" : "523886156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784149100694417408\/ca5vklZz_normal.jpg",
      "id" : 523886156,
      "verified" : true
    }
  },
  "id" : 324557599917879296,
  "created_at" : "2013-04-17 16:18:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25D5\u203F\u25D5",
      "screen_name" : "GRinFlorida",
      "indices" : [ 3, 15 ],
      "id_str" : "975029622",
      "id" : 975029622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324556952329940992",
  "text" : "RT @GRinFlorida: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/4LNmLRdOwk",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324556701867061250",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/4LNmLRdOwk",
    "id" : 324556701867061250,
    "created_at" : "2013-04-17 16:15:22 +0000",
    "user" : {
      "name" : "\u25D5\u203F\u25D5",
      "screen_name" : "GRinFlorida",
      "protected" : false,
      "id_str" : "975029622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756195718293925893\/nRPaMW8w_normal.jpg",
      "id" : 975029622,
      "verified" : false
    }
  },
  "id" : 324556952329940992,
  "created_at" : "2013-04-17 16:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CallaLilly101",
      "screen_name" : "CallaLilly101",
      "indices" : [ 3, 17 ],
      "id_str" : "78959991",
      "id" : 78959991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324556805118238721",
  "text" : "RT @CallaLilly101: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/BMQmfUJeMP",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324556589233229825",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/BMQmfUJeMP",
    "id" : 324556589233229825,
    "created_at" : "2013-04-17 16:14:55 +0000",
    "user" : {
      "name" : "CallaLilly101",
      "screen_name" : "CallaLilly101",
      "protected" : false,
      "id_str" : "78959991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503206345135239168\/wgzm4OuD_normal.jpeg",
      "id" : 78959991,
      "verified" : false
    }
  },
  "id" : 324556805118238721,
  "created_at" : "2013-04-17 16:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TDHawkes, Ph.D.",
      "screen_name" : "TDunyati_Long",
      "indices" : [ 3, 17 ],
      "id_str" : "14875422",
      "id" : 14875422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324556449588068352",
  "text" : "RT @TDunyati_Long: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/VkV2eNS7bR",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324556232352489472",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/VkV2eNS7bR",
    "id" : 324556232352489472,
    "created_at" : "2013-04-17 16:13:30 +0000",
    "user" : {
      "name" : "TDHawkes, Ph.D.",
      "screen_name" : "TDunyati_Long",
      "protected" : false,
      "id_str" : "14875422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459107756717256704\/J3Bnwo4N_normal.jpeg",
      "id" : 14875422,
      "verified" : false
    }
  },
  "id" : 324556449588068352,
  "created_at" : "2013-04-17 16:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324556284986793984",
  "text" : "RT @StHelenaSteve: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/xrozOpeW3s",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "324555199752589312",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/xrozOpeW3s",
    "id" : 324555199752589312,
    "created_at" : "2013-04-17 16:09:24 +0000",
    "user" : {
      "name" : "steve nelson",
      "screen_name" : "Sacto_Steve",
      "protected" : false,
      "id_str" : "118128875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797246215976951808\/CB_2Zps-_normal.jpg",
      "id" : 118128875,
      "verified" : false
    }
  },
  "id" : 324556284986793984,
  "created_at" : "2013-04-17 16:13:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/324553045155397633\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/padZG8HyvQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIELRmfCQAEkBmE.jpg",
      "id_str" : "324553045163786241",
      "id" : 324553045163786241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIELRmfCQAEkBmE.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/padZG8HyvQ"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/SRhlrAFJLf",
      "expanded_url" : "http:\/\/at.wh.gov\/k9AoL",
      "display_url" : "at.wh.gov\/k9AoL"
    } ]
  },
  "geo" : { },
  "id_str" : "324553045155397633",
  "text" : "RT &amp; add your name if you support common-sense steps to reduce gun violence: http:\/\/t.co\/SRhlrAFJLf #NowIsTheTime, http:\/\/t.co\/padZG8HyvQ",
  "id" : 324553045155397633,
  "created_at" : "2013-04-17 16:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/324543956161527808\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/HG1kQX2dQj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIEDAjXCAAAQDBv.jpg",
      "id_str" : "324543956174110720",
      "id" : 324543956174110720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIEDAjXCAAAQDBv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/HG1kQX2dQj"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/iRa0zF7R5c",
      "expanded_url" : "http:\/\/www.wh.gov\/nowisthetime\/action",
      "display_url" : "wh.gov\/nowisthetime\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324543956161527808",
  "text" : "We all have to stand up to reduce gun violence. #NowIsTheTime to speak out: http:\/\/t.co\/iRa0zF7R5c http:\/\/t.co\/HG1kQX2dQj",
  "id" : 324543956161527808,
  "created_at" : "2013-04-17 15:24:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/UBhc5j6XuT",
      "expanded_url" : "http:\/\/wh.gov\/eVnB",
      "display_url" : "wh.gov\/eVnB"
    } ]
  },
  "geo" : { },
  "id_str" : "324519542850191360",
  "text" : "RT @VP: TODAY at 2:45 PM ET, VP Biden will join a conversation with mayors on reducing gun violence. http:\/\/t.co\/UBhc5j6XuT  #NowIsTheTime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 117, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/UBhc5j6XuT",
        "expanded_url" : "http:\/\/wh.gov\/eVnB",
        "display_url" : "wh.gov\/eVnB"
      } ]
    },
    "geo" : { },
    "id_str" : "324511880150405120",
    "text" : "TODAY at 2:45 PM ET, VP Biden will join a conversation with mayors on reducing gun violence. http:\/\/t.co\/UBhc5j6XuT  #NowIsTheTime",
    "id" : 324511880150405120,
    "created_at" : "2013-04-17 13:17:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 324519542850191360,
  "created_at" : "2013-04-17 13:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/324313519862476800\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mczjt7WrR5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIAxbZPCcAAlw2m.jpg",
      "id_str" : "324313519870865408",
      "id" : 324313519870865408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIAxbZPCcAAlw2m.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/mczjt7WrR5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324313519862476800",
  "text" : "RT to show your support for the families of victims and all Bostonians in the wake of this senseless attack: http:\/\/t.co\/mczjt7WrR5",
  "id" : 324313519862476800,
  "created_at" : "2013-04-17 00:09:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CFLia4tmCN",
      "expanded_url" : "http:\/\/wh.gov\/eVBF",
      "display_url" : "wh.gov\/eVBF"
    } ]
  },
  "geo" : { },
  "id_str" : "324290816686305280",
  "text" : "Obama: \"I stand willing to do whatever it takes to make sure that comprehensive #ImmigrationReform becomes a reality\" http:\/\/t.co\/CFLia4tmCN",
  "id" : 324290816686305280,
  "created_at" : "2013-04-16 22:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324272463049531392",
  "text" : "On Thursday, President Obama will travel to Boston to speak at a service dedicated to those who were wounded or killed in Monday's bombing.",
  "id" : 324272463049531392,
  "created_at" : "2013-04-16 21:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/E2pPZfDc9U",
      "expanded_url" : "http:\/\/youtu.be\/Exb6ShutZ18",
      "display_url" : "youtu.be\/Exb6ShutZ18"
    } ]
  },
  "geo" : { },
  "id_str" : "324243784542081024",
  "text" : "\"Any time bombs are used to target innocent civilians, it is an act of terror.\" \u2013President Obama: http:\/\/t.co\/E2pPZfDc9U",
  "id" : 324243784542081024,
  "created_at" : "2013-04-16 19:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/E2pPZfDc9U",
      "expanded_url" : "http:\/\/youtu.be\/Exb6ShutZ18",
      "display_url" : "youtu.be\/Exb6ShutZ18"
    } ]
  },
  "geo" : { },
  "id_str" : "324211862260563969",
  "text" : "Full video: President Obama speaks on the attacks in Boston. Watch: http:\/\/t.co\/E2pPZfDc9U",
  "id" : 324211862260563969,
  "created_at" : "2013-04-16 17:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Boston",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4rNBof1Z7h",
      "expanded_url" : "http:\/\/at.wh.gov\/k7o27",
      "display_url" : "at.wh.gov\/k7o27"
    } ]
  },
  "geo" : { },
  "id_str" : "324198700945653762",
  "text" : "President Obama orders U.S. flags to be flown at half-staff in honor of the victims of the tragedy in #Boston: http:\/\/t.co\/4rNBof1Z7h",
  "id" : 324198700945653762,
  "created_at" : "2013-04-16 16:32:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324192067960066048",
  "text" : "\"What the world saw yesterday in the aftermath of the explosions were stories of heroism &amp; kindness; generosity and love.\" \u2014President Obama",
  "id" : 324192067960066048,
  "created_at" : "2013-04-16 16:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324184156835807233",
  "text" : "Obama: \"\"If you want to know who we are, who America is, how we respond to evil -- that's it. Selflessly, compassionately, unafraid.\"",
  "id" : 324184156835807233,
  "created_at" : "2013-04-16 15:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324183916602871808",
  "text" : "President Obama: \"We will find whoever harmed our citizens and we will bring them to justice.\"",
  "id" : 324183916602871808,
  "created_at" : "2013-04-16 15:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324183604953497600",
  "text" : "President Obama: \"Given what we now know about the attacks, the FBI is investigating it as an act of terrorism.\"",
  "id" : 324183604953497600,
  "created_at" : "2013-04-16 15:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324183249150676992",
  "text" : "President Obama: \"Our first thoughts this morning are with the victims, their families and the city of Boston\"",
  "id" : 324183249150676992,
  "created_at" : "2013-04-16 15:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "324183041457143808",
  "text" : "Happening now: President Obama delivers a statement from the Briefing Room of the White House. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 324183041457143808,
  "created_at" : "2013-04-16 15:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "324177009532088320",
  "text" : "At 11:30 a.m. ET, President Obama will deliver a statement from the Briefing Room. Watch live on http:\/\/t.co\/b4tqL3nPDV.",
  "id" : 324177009532088320,
  "created_at" : "2013-04-16 15:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/miPVlVqyX2",
      "expanded_url" : "http:\/\/at.wh.gov\/k624z",
      "display_url" : "at.wh.gov\/k624z"
    } ]
  },
  "geo" : { },
  "id_str" : "323986346123341824",
  "text" : "President Obama on the explosions in Boston: \"We will find out who did this &amp; we will hold them accountable.\" Watch: http:\/\/t.co\/miPVlVqyX2",
  "id" : 323986346123341824,
  "created_at" : "2013-04-16 02:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/NgMf7mMSLp",
      "expanded_url" : "http:\/\/flic.kr\/p\/ebAhY8",
      "display_url" : "flic.kr\/p\/ebAhY8"
    } ]
  },
  "geo" : { },
  "id_str" : "323949919440367617",
  "text" : "Photo of the Day: President Obama recieves an updated on the incident in Boston from FBI Director Mueller: http:\/\/t.co\/NgMf7mMSLp",
  "id" : 323949919440367617,
  "created_at" : "2013-04-16 00:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/ezQFbYT7vY",
      "expanded_url" : "http:\/\/youtu.be\/4x-VKqe4cvA",
      "display_url" : "youtu.be\/4x-VKqe4cvA"
    } ]
  },
  "geo" : { },
  "id_str" : "323931482689265665",
  "text" : "Full video: President Obama speaks on the explosions in Boston. Watch: http:\/\/t.co\/ezQFbYT7vY",
  "id" : 323931482689265665,
  "created_at" : "2013-04-15 22:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prayforboston",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323925766058414081",
  "text" : "\"The American people will say a prayer for Boston tonight.\" \u2014President Obama #prayforboston",
  "id" : 323925766058414081,
  "created_at" : "2013-04-15 22:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323922032066715648",
  "text" : "President Obama: \"I am supremely confident that Bostonians will pull together, take care of each other &amp; move forward \u2013 as one proud city.\"",
  "id" : 323922032066715648,
  "created_at" : "2013-04-15 22:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323921953931014146",
  "text" : "President Obama: \"Boston is a tough and resilient town. So are its people.\"",
  "id" : 323921953931014146,
  "created_at" : "2013-04-15 22:13:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323921555333734401",
  "text" : "\"On days like this there are no Republicans or Democrats \u2013 we are Americans, united in concern for our fellow citizens.\" \u2014President Obama",
  "id" : 323921555333734401,
  "created_at" : "2013-04-15 22:11:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323921463759499264",
  "text" : "President Obama: \"Michelle &amp; I send our deepest thoughts and prayers to the families of the victims in the wake of this senseless loss.\"",
  "id" : 323921463759499264,
  "created_at" : "2013-04-15 22:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323921418138030080",
  "text" : "\"The American people will say a prayer for Boston tonight.\" \u2014President Obama",
  "id" : 323921418138030080,
  "created_at" : "2013-04-15 22:10:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "323921326727372800",
  "text" : "Happening Now: President Obama delivers a statement from the Briefing Room: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 323921326727372800,
  "created_at" : "2013-04-15 22:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "323916761529479169",
  "text" : "Happening at 6:10 p.m. ET: President Obama will deliver a statement from the Briefing Room of the White House. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 323916761529479169,
  "created_at" : "2013-04-15 21:52:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 96, 105 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323826518176452608",
  "text" : "RT @SecretaryJewell: Hello Twitter! I\u2019m honored &amp; humbled to serve as Pres. Obama\u2019s Sec. of @Interior &amp; ready to get to work on  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 75, 84 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323797637088280576",
    "text" : "Hello Twitter! I\u2019m honored &amp; humbled to serve as Pres. Obama\u2019s Sec. of @Interior &amp; ready to get to work on behalf of all Americans! SJ",
    "id" : 323797637088280576,
    "created_at" : "2013-04-15 13:59:07 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 323826518176452608,
  "created_at" : "2013-04-15 15:53:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/CNx57I5iyK",
      "expanded_url" : "http:\/\/wh.gov\/eTaP",
      "display_url" : "wh.gov\/eTaP"
    } ]
  },
  "geo" : { },
  "id_str" : "323794800405000192",
  "text" : "It's Tax Day. Check out the @WhiteHouse Taxpayer Receipt to see how your tax dollars are spent: http:\/\/t.co\/CNx57I5iyK",
  "id" : 323794800405000192,
  "created_at" : "2013-04-15 13:47:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "VEEP",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/xNx5Rm997U",
      "expanded_url" : "http:\/\/snd.sc\/16SQpO3",
      "display_url" : "snd.sc\/16SQpO3"
    } ]
  },
  "geo" : { },
  "id_str" : "323615105780686849",
  "text" : "In the latest #BeingBiden, @VP Biden meets #VEEP. Listen: http:\/\/t.co\/xNx5Rm997U",
  "id" : 323615105780686849,
  "created_at" : "2013-04-15 01:53:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/UM2109khn5",
      "expanded_url" : "http:\/\/youtu.be\/p6Mlqsp5BF8",
      "display_url" : "youtu.be\/p6Mlqsp5BF8"
    } ]
  },
  "geo" : { },
  "id_str" : "323220585759002624",
  "text" : "Each week, President Obama records an address to the nation. Today, he asked someone to take his place: http:\/\/t.co\/UM2109khn5 #NowIsTheTime",
  "id" : 323220585759002624,
  "created_at" : "2013-04-13 23:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michellelongo",
      "screen_name" : "michellelongo",
      "indices" : [ 3, 17 ],
      "id_str" : "14335675",
      "id" : 14335675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323220317847818240",
  "text" : "RT @michellelongo: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/K7JFSNDWQi",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "323204075627896832",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/K7JFSNDWQi",
    "id" : 323204075627896832,
    "created_at" : "2013-04-13 22:40:31 +0000",
    "user" : {
      "name" : "michellelongo",
      "screen_name" : "michellelongo",
      "protected" : false,
      "id_str" : "14335675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731582305605681153\/T73Ar7sH_normal.jpg",
      "id" : 14335675,
      "verified" : false
    }
  },
  "id" : 323220317847818240,
  "created_at" : "2013-04-13 23:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323136889538355200",
  "text" : "RT @Simas44: Powerful statement by Sandy Hook parents. This is a moment for real change. Please watch and send around. http:\/\/t.co\/k7uM1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/k7uM10pbAe",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/newtownaddress",
        "display_url" : "whitehouse.gov\/newtownaddress"
      } ]
    },
    "geo" : { },
    "id_str" : "323136530791153665",
    "text" : "Powerful statement by Sandy Hook parents. This is a moment for real change. Please watch and send around. http:\/\/t.co\/k7uM10pbAe",
    "id" : 323136530791153665,
    "created_at" : "2013-04-13 18:12:07 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 323136889538355200,
  "created_at" : "2013-04-13 18:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 1, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/UM2109khn5",
      "expanded_url" : "http:\/\/youtu.be\/p6Mlqsp5BF8",
      "display_url" : "youtu.be\/p6Mlqsp5BF8"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w5JcF96gyK",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/issues\/preventing-gun-violence\/action",
      "display_url" : "whitehouse.gov\/issues\/prevent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323136466706366464",
  "text" : "\"#Nowisthetime to act. Please join us.\" -Newtown mom Francine Wheeler in Weekly Address: http:\/\/t.co\/UM2109khn5 Join: http:\/\/t.co\/w5JcF96gyK",
  "id" : 323136466706366464,
  "created_at" : "2013-04-13 18:11:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/5EhtCrxoso",
      "expanded_url" : "http:\/\/at.wh.gov\/k1yDH",
      "display_url" : "at.wh.gov\/k1yDH"
    } ]
  },
  "geo" : { },
  "id_str" : "323014075619610624",
  "text" : "Francine Wheeler, a Newtown mom, delivers the Weekly Address. It's a message everyone should hear: http:\/\/t.co\/5EhtCrxoso #NowIsTheTime",
  "id" : 323014075619610624,
  "created_at" : "2013-04-13 10:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mariacip",
      "screen_name" : "mariacip",
      "indices" : [ 3, 12 ],
      "id_str" : "16807426",
      "id" : 16807426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322901143514669057",
  "text" : "RT @mariacip: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/IyAUSGPdmk",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322872505096359936",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/IyAUSGPdmk",
    "id" : 322872505096359936,
    "created_at" : "2013-04-13 00:42:58 +0000",
    "user" : {
      "name" : "mariacip",
      "screen_name" : "mariacip",
      "protected" : false,
      "id_str" : "16807426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1861634365\/5640_100166234841_514069841_2212520_4059838_n_normal.jpeg",
      "id" : 16807426,
      "verified" : false
    }
  },
  "id" : 322901143514669057,
  "created_at" : "2013-04-13 02:36:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 45, 56 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/322899709528272897\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/r13ZFuXsrK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHsrkzTCcAA5W8S.jpg",
      "id_str" : "322899709532467200",
      "id" : 322899709532467200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHsrkzTCcAA5W8S.jpg",
      "sizes" : [ {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1530
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/r13ZFuXsrK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322899709528272897",
  "text" : "Photo of the Day: President Obama talks with @americorps members in the Oval Office: http:\/\/t.co\/r13ZFuXsrK",
  "id" : 322899709528272897,
  "created_at" : "2013-04-13 02:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/322867266448404480\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/VZefvq7yTX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHsOEXbCMAAJ7u3.jpg",
      "id_str" : "322867266456793088",
      "id" : 322867266456793088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHsOEXbCMAAJ7u3.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VZefvq7yTX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/UEc95F9X3J",
      "expanded_url" : "http:\/\/on.wh.gov\/F3Zmn8w",
      "display_url" : "on.wh.gov\/F3Zmn8w"
    } ]
  },
  "geo" : { },
  "id_str" : "322867266448404480",
  "text" : "Photo Gallery: Behind the Scenes in March 2013: http:\/\/t.co\/UEc95F9X3J Marine One landing near Petra, Jordan: http:\/\/t.co\/VZefvq7yTX",
  "id" : 322867266448404480,
  "created_at" : "2013-04-13 00:22:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kerry Mackin",
      "screen_name" : "kerrymackin",
      "indices" : [ 3, 15 ],
      "id_str" : "155998467",
      "id" : 155998467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322852259018989568",
  "text" : "RT @kerrymackin: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/2Q23JZktJy",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322851895699963904",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/2Q23JZktJy",
    "id" : 322851895699963904,
    "created_at" : "2013-04-12 23:21:04 +0000",
    "user" : {
      "name" : "Kerry Mackin",
      "screen_name" : "kerrymackin",
      "protected" : false,
      "id_str" : "155998467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1300200546\/Photosoldcomputer-4_010_normal.jpg",
      "id" : 155998467,
      "verified" : false
    }
  },
  "id" : 322852259018989568,
  "created_at" : "2013-04-12 23:22:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/322842137404248064\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/i4rhWbn7Oj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHr3NqbCEAAQkya.jpg",
      "id_str" : "322842137408442368",
      "id" : 322842137408442368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHr3NqbCEAAQkya.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/i4rhWbn7Oj"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/UeLt6zA3Pg",
      "expanded_url" : "http:\/\/on.wh.gov\/iE5d35J",
      "display_url" : "on.wh.gov\/iE5d35J"
    } ]
  },
  "geo" : { },
  "id_str" : "322842137404248064",
  "text" : "If you support common-sense steps to reduce gun violence, #NowIsTheTime to stand up. Join us: http:\/\/t.co\/UeLt6zA3Pg http:\/\/t.co\/i4rhWbn7Oj",
  "id" : 322842137404248064,
  "created_at" : "2013-04-12 22:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322786974517837825",
  "text" : "Francine Wheeler, a Newtown mom, will take my place in tomorrow's Weekly Address. It's a message everyone should hear: #NowIsTheTime. -bo",
  "id" : 322786974517837825,
  "created_at" : "2013-04-12 19:03:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AndreaSauceda",
      "screen_name" : "AndreaSauceda",
      "indices" : [ 3, 17 ],
      "id_str" : "17489153",
      "id" : 17489153
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322764998424289280",
  "text" : "RT @AndreaSauceda: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/0MHxvXS586",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322763094117990400",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/0MHxvXS586",
    "id" : 322763094117990400,
    "created_at" : "2013-04-12 17:28:12 +0000",
    "user" : {
      "name" : "AndreaSauceda",
      "screen_name" : "AndreaSauceda",
      "protected" : false,
      "id_str" : "17489153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666728530378526720\/wNLimzUe_normal.jpg",
      "id" : 17489153,
      "verified" : false
    }
  },
  "id" : 322764998424289280,
  "created_at" : "2013-04-12 17:35:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meighan Stone",
      "screen_name" : "meighanstone",
      "indices" : [ 3, 16 ],
      "id_str" : "19864770",
      "id" : 19864770
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322760197330309120",
  "text" : "RT @meighanstone: I'm a mom &amp; support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name-- for your chil ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/vMalssRVTa",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322758088715284481",
    "text" : "I'm a mom &amp; support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name-- for your child: http:\/\/t.co\/vMalssRVTa",
    "id" : 322758088715284481,
    "created_at" : "2013-04-12 17:08:19 +0000",
    "user" : {
      "name" : "Meighan Stone",
      "screen_name" : "meighanstone",
      "protected" : false,
      "id_str" : "19864770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458736025313873923\/nwaHDVj9_normal.jpeg",
      "id" : 19864770,
      "verified" : false
    }
  },
  "id" : 322760197330309120,
  "created_at" : "2013-04-12 17:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322756513431166978",
  "text" : "RT @GovMalloyOffice: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/VLPGavVsW9",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322447025897603072",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/VLPGavVsW9",
    "id" : 322447025897603072,
    "created_at" : "2013-04-11 20:32:16 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 322756513431166978,
  "created_at" : "2013-04-12 17:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322744836174266369",
  "text" : "RT @AmieR2479: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/3OsdYkndoX",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322742409983320064",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/3OsdYkndoX",
    "id" : 322742409983320064,
    "created_at" : "2013-04-12 16:06:01 +0000",
    "user" : {
      "name" : "Amie",
      "screen_name" : "AmieNWonderland",
      "protected" : false,
      "id_str" : "266283088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763148383410384900\/QjYBo9yf_normal.jpg",
      "id" : 266283088,
      "verified" : false
    }
  },
  "id" : 322744836174266369,
  "created_at" : "2013-04-12 16:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Wolfe",
      "screen_name" : "GrahamWolfe",
      "indices" : [ 3, 15 ],
      "id_str" : "18665794",
      "id" : 18665794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322736990737022976",
  "text" : "RT @GrahamWolfe: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/wkGNFkXLnk",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322720666698776576",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/wkGNFkXLnk",
    "id" : 322720666698776576,
    "created_at" : "2013-04-12 14:39:37 +0000",
    "user" : {
      "name" : "Graham Wolfe",
      "screen_name" : "GrahamWolfe",
      "protected" : false,
      "id_str" : "18665794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704849480844075009\/rNj1p7vE_normal.jpg",
      "id" : 18665794,
      "verified" : false
    }
  },
  "id" : 322736990737022976,
  "created_at" : "2013-04-12 15:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naval Academy",
      "screen_name" : "NavalAcademy",
      "indices" : [ 87, 100 ],
      "id_str" : "18090660",
      "id" : 18090660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "322735597372452864",
  "text" : "Starting at 2:05ET: President Obama presents the Commander-in-Chief trophy to the U.S. @NavalAcademy football team: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 322735597372452864,
  "created_at" : "2013-04-12 15:38:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Ken Salazar",
      "screen_name" : "KenSalazar",
      "indices" : [ 27, 38 ],
      "id_str" : "1112972713",
      "id" : 1112972713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/322710443481264130\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/OWlnZyONX4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHp_cEWCcAEbdKX.jpg",
      "id_str" : "322710443489652737",
      "id" : 322710443489652737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHp_cEWCcAEbdKX.jpg",
      "sizes" : [ {
        "h" : 498,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OWlnZyONX4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322711246967283712",
  "text" : "RT @Interior: To Secretary @KenSalazar - the joy has truly been in the journey. Thank you. http:\/\/t.co\/OWlnZyONX4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ken Salazar",
        "screen_name" : "KenSalazar",
        "indices" : [ 13, 24 ],
        "id_str" : "1112972713",
        "id" : 1112972713
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/322710443481264130\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/OWlnZyONX4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHp_cEWCcAEbdKX.jpg",
        "id_str" : "322710443489652737",
        "id" : 322710443489652737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHp_cEWCcAEbdKX.jpg",
        "sizes" : [ {
          "h" : 498,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OWlnZyONX4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322710443481264130",
    "text" : "To Secretary @KenSalazar - the joy has truly been in the journey. Thank you. http:\/\/t.co\/OWlnZyONX4",
    "id" : 322710443481264130,
    "created_at" : "2013-04-12 13:59:00 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 322711246967283712,
  "created_at" : "2013-04-12 14:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/tZE0u0IJ4p",
      "expanded_url" : "http:\/\/wh.gov\/nowisthetime\/action",
      "display_url" : "wh.gov\/nowisthetime\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322706914993635328",
  "text" : "RT @PAniskoff44: Just signed on to support common-sense steps to reduce gun violence. #NowIsTheTime Add your name! http:\/\/t.co\/tZE0u0IJ4p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 69, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/tZE0u0IJ4p",
        "expanded_url" : "http:\/\/wh.gov\/nowisthetime\/action",
        "display_url" : "wh.gov\/nowisthetime\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "322494718082686976",
    "text" : "Just signed on to support common-sense steps to reduce gun violence. #NowIsTheTime Add your name! http:\/\/t.co\/tZE0u0IJ4p",
    "id" : 322494718082686976,
    "created_at" : "2013-04-11 23:41:47 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 322706914993635328,
  "created_at" : "2013-04-12 13:44:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carmen Barnes",
      "screen_name" : "CarmenBarnes",
      "indices" : [ 3, 16 ],
      "id_str" : "43959460",
      "id" : 43959460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322552539440627713",
  "text" : "RT @CarmenBarnes: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/MDR4534a3I",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322541113493815296",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/MDR4534a3I",
    "id" : 322541113493815296,
    "created_at" : "2013-04-12 02:46:08 +0000",
    "user" : {
      "name" : "Carmen Barnes",
      "screen_name" : "CarmenBarnes",
      "protected" : false,
      "id_str" : "43959460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726222028785721344\/NY_aZGdy_normal.jpg",
      "id" : 43959460,
      "verified" : false
    }
  },
  "id" : 322552539440627713,
  "created_at" : "2013-04-12 03:31:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "boblazaro",
      "screen_name" : "boblazaro",
      "indices" : [ 3, 13 ],
      "id_str" : "18317901",
      "id" : 18317901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322538689546817536",
  "text" : "RT @boblazaro: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/MSEbuoB3Mg",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322523283029360640",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/MSEbuoB3Mg",
    "id" : 322523283029360640,
    "created_at" : "2013-04-12 01:35:17 +0000",
    "user" : {
      "name" : "boblazaro",
      "screen_name" : "boblazaro",
      "protected" : false,
      "id_str" : "18317901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552606762520829954\/mKBlSv2X_normal.jpeg",
      "id" : 18317901,
      "verified" : false
    }
  },
  "id" : 322538689546817536,
  "created_at" : "2013-04-12 02:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsthetime",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rDrY8yue6c",
      "expanded_url" : "http:\/\/at.wh.gov\/jZjeu",
      "display_url" : "at.wh.gov\/jZjeu"
    } ]
  },
  "geo" : { },
  "id_str" : "322538367491391488",
  "text" : "Make your voice heard. #NowIsthetime to speak out in support of common-sense steps to reduce gun violence. Join us: http:\/\/t.co\/rDrY8yue6c",
  "id" : 322538367491391488,
  "created_at" : "2013-04-12 02:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 20, 27 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/322528628275560448\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/QybXZPpZaJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHnaFB6CQAMLZwk.jpg",
      "id_str" : "322528628279754755",
      "id" : 322528628279754755,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHnaFB6CQAMLZwk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/QybXZPpZaJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322528628275560448",
  "text" : "The President &amp; @FLOTUS meet Chaplain Kapaun's family before awarding him the Medal of Honor posthumously at the WH: http:\/\/t.co\/QybXZPpZaJ",
  "id" : 322528628275560448,
  "created_at" : "2013-04-12 01:56:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Deamer",
      "screen_name" : "ericdeamer",
      "indices" : [ 3, 14 ],
      "id_str" : "18814243",
      "id" : 18814243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322461758264594432",
  "text" : "RT @ericdeamer: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/xbxXY6qWXZ",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322460732493033472",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/xbxXY6qWXZ",
    "id" : 322460732493033472,
    "created_at" : "2013-04-11 21:26:44 +0000",
    "user" : {
      "name" : "Eric Deamer",
      "screen_name" : "ericdeamer",
      "protected" : false,
      "id_str" : "18814243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538439475299241984\/GNdbBuib_normal.jpeg",
      "id" : 18814243,
      "verified" : false
    }
  },
  "id" : 322461758264594432,
  "created_at" : "2013-04-11 21:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newtown Action",
      "screen_name" : "NewtownAction",
      "indices" : [ 3, 17 ],
      "id_str" : "1148468052",
      "id" : 1148468052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322460380968407040",
  "text" : "RT @NewtownAction: @NewtowonAction suppors common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/wpVPTGWk6T",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322339860025331712",
    "text" : "@NewtowonAction suppors common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/wpVPTGWk6T",
    "id" : 322339860025331712,
    "created_at" : "2013-04-11 13:26:26 +0000",
    "user" : {
      "name" : "Newtown Action",
      "screen_name" : "NewtownAction",
      "protected" : false,
      "id_str" : "1148468052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739806194592849920\/EmJcp_V4_normal.jpg",
      "id" : 1148468052,
      "verified" : false
    }
  },
  "id" : 322460380968407040,
  "created_at" : "2013-04-11 21:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Halverson",
      "screen_name" : "lisa_maren",
      "indices" : [ 3, 14 ],
      "id_str" : "78331842",
      "id" : 78331842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322455498647535616",
  "text" : "RT @lisa_maren: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/z4UgweUvWD",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322454309549785088",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/z4UgweUvWD",
    "id" : 322454309549785088,
    "created_at" : "2013-04-11 21:01:12 +0000",
    "user" : {
      "name" : "Lisa Halverson",
      "screen_name" : "lisa_maren",
      "protected" : false,
      "id_str" : "78331842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487337890792218625\/oAla9MHR_normal.jpeg",
      "id" : 78331842,
      "verified" : false
    }
  },
  "id" : 322455498647535616,
  "created_at" : "2013-04-11 21:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Partain",
      "screen_name" : "jeffpartain",
      "indices" : [ 3, 15 ],
      "id_str" : "48455749",
      "id" : 48455749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322455282666049536",
  "text" : "RT @jeffpartain: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/L8aI6skCI4",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322454418765275136",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/L8aI6skCI4",
    "id" : 322454418765275136,
    "created_at" : "2013-04-11 21:01:39 +0000",
    "user" : {
      "name" : "Jeff Partain",
      "screen_name" : "jeffpartain",
      "protected" : false,
      "id_str" : "48455749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658808463095545856\/V5gl2QeJ_normal.jpg",
      "id" : 48455749,
      "verified" : false
    }
  },
  "id" : 322455282666049536,
  "created_at" : "2013-04-11 21:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#NASTY kathykate",
      "screen_name" : "KLMcopy",
      "indices" : [ 3, 11 ],
      "id_str" : "17324875",
      "id" : 17324875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/i6BhFz309u",
      "expanded_url" : "http:\/\/thndr.it\/17pq37r",
      "display_url" : "thndr.it\/17pq37r"
    } ]
  },
  "geo" : { },
  "id_str" : "322454485731516418",
  "text" : "RT @klmcopy: Newtown for common-sense steps to reduce gun violence. #NowIsTheTime Add ur name: http:\/\/t.co\/i6BhFz309u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 55, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/i6BhFz309u",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322427028999659520",
    "text" : "Newtown for common-sense steps to reduce gun violence. #NowIsTheTime Add ur name: http:\/\/t.co\/i6BhFz309u",
    "id" : 322427028999659520,
    "created_at" : "2013-04-11 19:12:48 +0000",
    "user" : {
      "name" : "#NASTY kathykate",
      "screen_name" : "KLMcopy",
      "protected" : false,
      "id_str" : "17324875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785982427932028928\/Vr1WXiGV_normal.jpg",
      "id" : 17324875,
      "verified" : false
    }
  },
  "id" : 322454485731516418,
  "created_at" : "2013-04-11 21:01:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/QNmQ5LVcaO",
      "expanded_url" : "http:\/\/flic.kr\/p\/eazmgj",
      "display_url" : "flic.kr\/p\/eazmgj"
    } ]
  },
  "geo" : { },
  "id_str" : "322452465922482176",
  "text" : "After the Senate cloture vote, President Obama called Newtown families to discuss this important step: http:\/\/t.co\/QNmQ5LVcaO #NowIsTheTime",
  "id" : 322452465922482176,
  "created_at" : "2013-04-11 20:53:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare Dougherty",
      "screen_name" : "Claremdowling",
      "indices" : [ 3, 17 ],
      "id_str" : "304675775",
      "id" : 304675775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322435550697099264",
  "text" : "RT @Claremdowling: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/OJyB63SJVQ",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322433820311838720",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/OJyB63SJVQ",
    "id" : 322433820311838720,
    "created_at" : "2013-04-11 19:39:47 +0000",
    "user" : {
      "name" : "Clare Dougherty",
      "screen_name" : "Claremdowling",
      "protected" : false,
      "id_str" : "304675775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2144147631\/clare_headshot_normal.jpg",
      "id" : 304675775,
      "verified" : false
    }
  },
  "id" : 322435550697099264,
  "created_at" : "2013-04-11 19:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Vandegrift",
      "screen_name" : "ronvandegrift",
      "indices" : [ 3, 17 ],
      "id_str" : "378202162",
      "id" : 378202162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322431245877399553",
  "text" : "RT @ronvandegrift: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/g8HS4tgRiT",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322429409749512195",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/g8HS4tgRiT",
    "id" : 322429409749512195,
    "created_at" : "2013-04-11 19:22:16 +0000",
    "user" : {
      "name" : "Ron Vandegrift",
      "screen_name" : "ronvandegrift",
      "protected" : false,
      "id_str" : "378202162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3050439008\/fec7a2d9667364203c2e882ddabb5844_normal.jpeg",
      "id" : 378202162,
      "verified" : false
    }
  },
  "id" : 322431245877399553,
  "created_at" : "2013-04-11 19:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "micah bycel",
      "screen_name" : "mbycel",
      "indices" : [ 3, 10 ],
      "id_str" : "113252725",
      "id" : 113252725
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322431004516175872",
  "text" : "RT @mbycel: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/784VDKuxu4",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322429996499103745",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/784VDKuxu4",
    "id" : 322429996499103745,
    "created_at" : "2013-04-11 19:24:36 +0000",
    "user" : {
      "name" : "micah bycel",
      "screen_name" : "mbycel",
      "protected" : false,
      "id_str" : "113252725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1300458363\/IMG_0771_normal.JPG",
      "id" : 113252725,
      "verified" : false
    }
  },
  "id" : 322431004516175872,
  "created_at" : "2013-04-11 19:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Davis",
      "screen_name" : "vdrk",
      "indices" : [ 3, 8 ],
      "id_str" : "20884732",
      "id" : 20884732
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322430816133206016",
  "text" : "RT @vdrk: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/2 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/2spqw2VmrI",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322430167932874752",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/2spqw2VmrI",
    "id" : 322430167932874752,
    "created_at" : "2013-04-11 19:25:17 +0000",
    "user" : {
      "name" : "Aaron Davis",
      "screen_name" : "vdrk",
      "protected" : false,
      "id_str" : "20884732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1275916445\/eightbit-a0b944a6-cf73-468f-aa70-3d3edf7af251_normal.png",
      "id" : 20884732,
      "verified" : false
    }
  },
  "id" : 322430816133206016,
  "created_at" : "2013-04-11 19:27:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/hWAn4nBVwS",
      "expanded_url" : "http:\/\/wh.gov\/nowisthetime\/action",
      "display_url" : "wh.gov\/nowisthetime\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322427585978056704",
  "text" : "If you support common-sense steps to reduce gun violence, #NowIsTheTime to speak out: http:\/\/t.co\/hWAn4nBVwS",
  "id" : 322427585978056704,
  "created_at" : "2013-04-11 19:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/rx6wH9Y5Py",
      "expanded_url" : "http:\/\/at.wh.gov\/jYAR9",
      "display_url" : "at.wh.gov\/jYAR9"
    } ]
  },
  "geo" : { },
  "id_str" : "322414648219561984",
  "text" : "Happening now: President Obama Awards Chaplain Emil Kapaun the Medal of Honor: http:\/\/t.co\/rx6wH9Y5Py",
  "id" : 322414648219561984,
  "created_at" : "2013-04-11 18:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Stefanotti",
      "screen_name" : "developingjen",
      "indices" : [ 3, 17 ],
      "id_str" : "35214040",
      "id" : 35214040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322381897600733184",
  "text" : "RT @developingjen: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KCvLzZFoWt",
        "expanded_url" : "http:\/\/thndr.it\/Zp30SS",
        "display_url" : "thndr.it\/Zp30SS"
      } ]
    },
    "geo" : { },
    "id_str" : "322354547618115584",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/KCvLzZFoWt",
    "id" : 322354547618115584,
    "created_at" : "2013-04-11 14:24:47 +0000",
    "user" : {
      "name" : "Jenny Stefanotti",
      "screen_name" : "developingjen",
      "protected" : false,
      "id_str" : "35214040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1826551773\/edit_normal.jpg",
      "id" : 35214040,
      "verified" : false
    }
  },
  "id" : 322381897600733184,
  "created_at" : "2013-04-11 16:13:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/y5jZ9WzQ5e",
      "expanded_url" : "https:\/\/www.thunderclap.it\/projects\/1839-nowisthetime-to-act",
      "display_url" : "thunderclap.it\/projects\/1839-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322380701850800128",
  "text" : "RT @macon44: upping the goal to 10k ... https:\/\/t.co\/y5jZ9WzQ5e #NowIsTheTime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 51, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/y5jZ9WzQ5e",
        "expanded_url" : "https:\/\/www.thunderclap.it\/projects\/1839-nowisthetime-to-act",
        "display_url" : "thunderclap.it\/projects\/1839-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "322359229900009473",
    "text" : "upping the goal to 10k ... https:\/\/t.co\/y5jZ9WzQ5e #NowIsTheTime",
    "id" : 322359229900009473,
    "created_at" : "2013-04-11 14:43:24 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 322380701850800128,
  "created_at" : "2013-04-11 16:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Izzy",
      "screen_name" : "Izzy1970",
      "indices" : [ 3, 12 ],
      "id_str" : "92185174",
      "id" : 92185174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322380019731136512",
  "text" : "RT @Izzy1970: I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Gw28OvXd2J",
        "expanded_url" : "http:\/\/thndr.it\/17pq37r",
        "display_url" : "thndr.it\/17pq37r"
      } ]
    },
    "geo" : { },
    "id_str" : "322375330088243200",
    "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/Gw28OvXd2J",
    "id" : 322375330088243200,
    "created_at" : "2013-04-11 15:47:22 +0000",
    "user" : {
      "name" : "Izzy",
      "screen_name" : "Izzy1970",
      "protected" : false,
      "id_str" : "92185174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3325119751\/30c5391b9440b79e488bdabdbd8a0931_normal.jpeg",
      "id" : 92185174,
      "verified" : false
    }
  },
  "id" : 322380019731136512,
  "created_at" : "2013-04-11 16:06:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 14, 22 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 23, 28 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322379852441329666",
  "text" : "RT @anildash: @macon44 @ks44 yup!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 0, 8 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      }, {
        "name" : "Kori Schulman",
        "screen_name" : "ks44",
        "indices" : [ 9, 14 ],
        "id_str" : "369246180",
        "id" : 369246180
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "322379191683272704",
    "geo" : { },
    "id_str" : "322379310600171520",
    "in_reply_to_user_id" : 110823581,
    "text" : "@macon44 @ks44 yup!",
    "id" : 322379310600171520,
    "in_reply_to_status_id" : 322379191683272704,
    "created_at" : "2013-04-11 16:03:11 +0000",
    "in_reply_to_screen_name" : "IIPCoordinator",
    "in_reply_to_user_id_str" : "110823581",
    "user" : {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786179830266167296\/AmZpJJLv_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 322379852441329666,
  "created_at" : "2013-04-11 16:05:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/csX58P7K1B",
      "expanded_url" : "http:\/\/thndr.it\/12Ma2Zz",
      "display_url" : "thndr.it\/12Ma2Zz"
    } ]
  },
  "geo" : { },
  "id_str" : "322370957475995648",
  "text" : "I just spoke out to support common-sense steps to reduce gun violence. #NowIsTheTime to act. Add your name, too: http:\/\/t.co\/csX58P7K1B",
  "id" : 322370957475995648,
  "created_at" : "2013-04-11 15:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 28, 35 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/76fdQuxkVj",
      "expanded_url" : "http:\/\/at.wh.gov\/jY5B3",
      "display_url" : "at.wh.gov\/jY5B3"
    } ]
  },
  "geo" : { },
  "id_str" : "322361897703858176",
  "text" : "Don't miss this speech from @FLOTUS Michelle Obama on youth violence: http:\/\/t.co\/76fdQuxkVj #NowIsTheTime",
  "id" : 322361897703858176,
  "created_at" : "2013-04-11 14:54:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Sv7Q3AhVVj",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "322354410309160961",
  "text" : "RT @NSCPress: Tune in at 2:10pm ET today at http:\/\/t.co\/Sv7Q3AhVVj to see the President posthumously award the Medal of Honor to Capt. E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/Sv7Q3AhVVj",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "322354147909304321",
    "text" : "Tune in at 2:10pm ET today at http:\/\/t.co\/Sv7Q3AhVVj to see the President posthumously award the Medal of Honor to Capt. Emil Kapaun",
    "id" : 322354147909304321,
    "created_at" : "2013-04-11 14:23:12 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 322354410309160961,
  "created_at" : "2013-04-11 14:24:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/322170350936915971\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/f36V2a8i6Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHiUOi3CAAAGqMg.jpg",
      "id_str" : "322170350953693184",
      "id" : 322170350953693184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHiUOi3CAAAGqMg.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 257
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1378,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1378,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/f36V2a8i6Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/kwp5yhOpbT",
      "expanded_url" : "http:\/\/wh.gov\/MHnA",
      "display_url" : "wh.gov\/MHnA"
    } ]
  },
  "geo" : { },
  "id_str" : "322170350936915971",
  "text" : "Today, President Obama released his 2014 budget: http:\/\/t.co\/kwp5yhOpbT Top 10 things you need to know: http:\/\/t.co\/f36V2a8i6Q",
  "id" : 322170350936915971,
  "created_at" : "2013-04-11 02:12:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/RiAlqmMAuE",
      "expanded_url" : "http:\/\/wh.gov\/x2G",
      "display_url" : "wh.gov\/x2G"
    } ]
  },
  "geo" : { },
  "id_str" : "322093950905229312",
  "text" : "President Obama: \"We can grow our economy &amp; shrink our deficits.\" The President\u2019s Fiscal Year 2014 Budget: http:\/\/t.co\/RiAlqmMAuE",
  "id" : 322093950905229312,
  "created_at" : "2013-04-10 21:09:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/5Gg4l5ZRnU",
      "expanded_url" : "http:\/\/at.wh.gov\/jWoTI",
      "display_url" : "at.wh.gov\/jWoTI"
    } ]
  },
  "geo" : { },
  "id_str" : "322060159532806144",
  "text" : "RT @FLOTUS: Happening now: First Lady Michelle Obama speaks on Youth Empowerment in Chicago. Watch live: http:\/\/t.co\/5Gg4l5ZRnU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/5Gg4l5ZRnU",
        "expanded_url" : "http:\/\/at.wh.gov\/jWoTI",
        "display_url" : "at.wh.gov\/jWoTI"
      } ]
    },
    "geo" : { },
    "id_str" : "322060078511452160",
    "text" : "Happening now: First Lady Michelle Obama speaks on Youth Empowerment in Chicago. Watch live: http:\/\/t.co\/5Gg4l5ZRnU",
    "id" : 322060078511452160,
    "created_at" : "2013-04-10 18:54:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 322060159532806144,
  "created_at" : "2013-04-10 18:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/RiAlqmMAuE",
      "expanded_url" : "http:\/\/wh.gov\/x2G",
      "display_url" : "wh.gov\/x2G"
    }, {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/upclWnMMaJ",
      "expanded_url" : "http:\/\/at.wh.gov\/jVW1W",
      "display_url" : "at.wh.gov\/jVW1W"
    } ]
  },
  "geo" : { },
  "id_str" : "322018926408134656",
  "text" : "President Obama's Fiscal Year 2014 Budget: http:\/\/t.co\/RiAlqmMAuE Full PDF: http:\/\/t.co\/upclWnMMaJ",
  "id" : 322018926408134656,
  "created_at" : "2013-04-10 16:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322003771439853569",
  "text" : "President Obama: \"If we can come together around common sense and compromise, I\u2019m confident we will move this country forward.\"",
  "id" : 322003771439853569,
  "created_at" : "2013-04-10 15:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322002583810088960",
  "text" : "President Obama: \"Despite all the noise in Washington, here\u2019s a clear and unassailable fact: our deficits are already falling.\"",
  "id" : 322002583810088960,
  "created_at" : "2013-04-10 15:06:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322002396169531393",
  "text" : "Obama: \"My budget replaces these cuts with smarter ones, making long-term reforms &amp; eliminating actual waste and programs we don\u2019t need.\"",
  "id" : 322002396169531393,
  "created_at" : "2013-04-10 15:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322002127096524800",
  "text" : "President Obama: \"My budget also replaces the foolish across-the-board spending cuts that are already hurting our economy.\"",
  "id" : 322002127096524800,
  "created_at" : "2013-04-10 15:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "322000920894402560",
  "text" : "Happening now: President Obama delivers a statement on the budget in the Rose Garden. Watch live: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 322000920894402560,
  "created_at" : "2013-04-10 14:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "321995749485322240",
  "text" : "Today, the President will deliver a statement on the budget in the Rose Garden. Watch live at 11ET: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 321995749485322240,
  "created_at" : "2013-04-10 14:39:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/RiAlqmMAuE",
      "expanded_url" : "http:\/\/wh.gov\/x2G",
      "display_url" : "wh.gov\/x2G"
    } ]
  },
  "geo" : { },
  "id_str" : "321984861013409792",
  "text" : "The President\u2019s budget strengthens the middle class &amp; reduces the deficit in a balanced way. Fact sheet: http:\/\/t.co\/RiAlqmMAuE",
  "id" : 321984861013409792,
  "created_at" : "2013-04-10 13:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321782240231165952",
  "text" : "Obama on #EqualPayDay: \"Our journey will not be complete until our mothers, our wives, our sisters &amp; our daughters are treated equally\"",
  "id" : 321782240231165952,
  "created_at" : "2013-04-10 00:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/321777587695284224\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/CurfYeRU6b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHcvAtuCcAMAiuD.jpg",
      "id_str" : "321777587699478531",
      "id" : 321777587699478531,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHcvAtuCcAMAiuD.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CurfYeRU6b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321777587695284224",
  "text" : "Photo of the Day: President Obama &amp; Chief of Staff Denis McDonough walk along the South Lawn of the White House: http:\/\/t.co\/CurfYeRU6b",
  "id" : 321777587695284224,
  "created_at" : "2013-04-10 00:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 3, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Ma3CVTQYYe",
      "expanded_url" : "http:\/\/at.wh.gov\/jUdMq",
      "display_url" : "at.wh.gov\/jUdMq"
    } ]
  },
  "geo" : { },
  "id_str" : "321752110330937344",
  "text" : "On #EqualPayDay, President Obama continues to call on the Congress to pass the Paycheck Fairness Act: http:\/\/t.co\/Ma3CVTQYYe",
  "id" : 321752110330937344,
  "created_at" : "2013-04-09 22:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321712081147686912",
  "text" : "President Obama on #EqualPayDay: \"We need to address longstanding inequity that keeps women from earning a living equal to their efforts\"",
  "id" : 321712081147686912,
  "created_at" : "2013-04-09 19:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/R4gj9lPica",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "321667579137622017",
  "text" : "RT @VP: Today at 2 PM ET, VP and AG Holder will urge Congress to pass common-sense gun measures. Watch live: http:\/\/t.co\/R4gj9lPica #Now ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/R4gj9lPica",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "321661531689459712",
    "text" : "Today at 2 PM ET, VP and AG Holder will urge Congress to pass common-sense gun measures. Watch live: http:\/\/t.co\/R4gj9lPica #NowIsTheTime",
    "id" : 321661531689459712,
    "created_at" : "2013-04-09 16:30:59 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 321667579137622017,
  "created_at" : "2013-04-09 16:55:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jillian Soto",
      "screen_name" : "JillianLouise25",
      "indices" : [ 40, 56 ],
      "id_str" : "174685521",
      "id" : 174685521
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/321649733833740289\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/JmNv6fVYET",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHa6uo_CUAAFaC6.jpg",
      "id_str" : "321649733842128896",
      "id" : 321649733842128896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHa6uo_CUAAFaC6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/JmNv6fVYET"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321649733833740289",
  "text" : "Photo of the Day: President Obama &amp; @JillianLouise25, whose sister was a teacher killed in Newtown, on Air Force One: http:\/\/t.co\/JmNv6fVYET",
  "id" : 321649733833740289,
  "created_at" : "2013-04-09 15:44:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/fO1D8OY8t3",
      "expanded_url" : "http:\/\/at.wh.gov\/jSiT1",
      "display_url" : "at.wh.gov\/jSiT1"
    } ]
  },
  "geo" : { },
  "id_str" : "321439480047357952",
  "text" : "Watch: President Obama asks Americans to stand up &amp; call for action to reduce gun violence: http:\/\/t.co\/fO1D8OY8t3 #NowIsTheTime",
  "id" : 321439480047357952,
  "created_at" : "2013-04-09 01:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTIme",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321405573780348929",
  "text" : "\"We've got to believe that every once in a while, we set politics aside and we just do what's right.\" \u2014President Obama #NowIsTheTIme",
  "id" : 321405573780348929,
  "created_at" : "2013-04-08 23:33:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321387917039771648",
  "text" : "RT @Simas44: The American people deserve a yes or no vote from Congress on reducing gun violence. #NowIsTheTime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321386351255773184",
    "text" : "The American people deserve a yes or no vote from Congress on reducing gun violence. #NowIsTheTime",
    "id" : 321386351255773184,
    "created_at" : "2013-04-08 22:17:31 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 321387917039771648,
  "created_at" : "2013-04-08 22:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321385405016584195",
  "text" : "Pres. Obama: \"Let\u2019s do the right thing. Let\u2019s do right by our kids. Let's do right by these families. Let\u2019s get this done.\" #NowIsTheTime",
  "id" : 321385405016584195,
  "created_at" : "2013-04-08 22:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321384396059983874",
  "text" : "RT @WHLive: President Obama: \"Why wouldn\u2019t you want to make it harder for a dangerous person to get his or her hands on a gun?\" #NowIsTh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321384263683551234",
    "text" : "President Obama: \"Why wouldn\u2019t you want to make it harder for a dangerous person to get his or her hands on a gun?\" #NowIsTheTime",
    "id" : 321384263683551234,
    "created_at" : "2013-04-08 22:09:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 321384396059983874,
  "created_at" : "2013-04-08 22:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321384374908104704",
  "text" : "RT @WHLive: President Obama: \"#Nowisthetime to make your voice heard from every state house to the corridors of Congress.\" http:\/\/t.co\/K ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nowisthetime",
        "indices" : [ 18, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/K4rtItMtDb",
        "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
        "display_url" : "wh.gov\/nowisthetime"
      } ]
    },
    "geo" : { },
    "id_str" : "321384194196512768",
    "text" : "President Obama: \"#Nowisthetime to make your voice heard from every state house to the corridors of Congress.\" http:\/\/t.co\/K4rtItMtDb",
    "id" : 321384194196512768,
    "created_at" : "2013-04-08 22:08:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 321384374908104704,
  "created_at" : "2013-04-08 22:09:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowistheTime",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321383100225576960",
  "text" : "President Obama: \"It\u2019s up to all of us \u2013 the people \u2013 to stand up to those who say we can\u2019t &amp; stand up for the change we need\" #NowistheTime",
  "id" : 321383100225576960,
  "created_at" : "2013-04-08 22:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321383019766247424",
  "text" : "President Obama: \"If our history teaches us anything, it\u2019s that it\u2019s up to us \u2013 the people \u2013 to stand up to those who say we can\u2019t.\"",
  "id" : 321383019766247424,
  "created_at" : "2013-04-08 22:04:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321381849844834304",
  "text" : "President Obama: \"90% of Americans support universal background checks...How often do 90% of Americans agree on anything?\" #NowIsTheTime",
  "id" : 321381849844834304,
  "created_at" : "2013-04-08 21:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321381666499227648",
  "text" : "Obama: \"If you\u2019re a law-abiding citizen &amp; go through a background check to buy a gun, wouldn\u2019t you want others to play by the same rules?\"",
  "id" : 321381666499227648,
  "created_at" : "2013-04-08 21:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321381474458820609",
  "text" : "Pres. Obama: \"Over the past 20 years, background checks have kept more than 2 million dangerous people from getting their hands on a gun.\"",
  "id" : 321381474458820609,
  "created_at" : "2013-04-08 21:58:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321380882730610688",
  "text" : "President Obama: \"We have to tell Congress it\u2019s time to require a background check for anyone who wants to buy a gun.\"  #NowIsTheTime",
  "id" : 321380882730610688,
  "created_at" : "2013-04-08 21:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Eda4lTRrzZ",
      "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
      "display_url" : "wh.gov\/nowisthetime"
    } ]
  },
  "geo" : { },
  "id_str" : "321380791269617664",
  "text" : "President Obama: \"Congress is only going to act if they hear from you \u2013 the American people.\" http:\/\/t.co\/Eda4lTRrzZ #NowIsTheTime",
  "id" : 321380791269617664,
  "created_at" : "2013-04-08 21:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321380543377846273",
  "text" : "RT @WHLive: Pres. Obama: \"In January...I announced a series of executive actions to reduce gun violence &amp; keep our kids safe.\" http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/K4rtItMtDb",
        "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
        "display_url" : "wh.gov\/nowisthetime"
      } ]
    },
    "geo" : { },
    "id_str" : "321380481843200000",
    "text" : "Pres. Obama: \"In January...I announced a series of executive actions to reduce gun violence &amp; keep our kids safe.\" http:\/\/t.co\/K4rtItMtDb",
    "id" : 321380481843200000,
    "created_at" : "2013-04-08 21:54:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 321380543377846273,
  "created_at" : "2013-04-08 21:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321379478339190785",
  "text" : "President Obama: \"Newtown, we want you to know that we\u2019re here with you. We will not walk away from the promises we\u2019ve made\"  #NowIsTheTime",
  "id" : 321379478339190785,
  "created_at" : "2013-04-08 21:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/SmrbbD841o",
      "expanded_url" : "http:\/\/at.wh.gov\/jS1dx",
      "display_url" : "at.wh.gov\/jS1dx"
    } ]
  },
  "geo" : { },
  "id_str" : "321376962767642625",
  "text" : "Happening now: President Obama speaks on common-sense measures to reduce gun violence from Connecticut. Watch: http:\/\/t.co\/SmrbbD841o",
  "id" : 321376962767642625,
  "created_at" : "2013-04-08 21:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/mJ7wDrMLSX",
      "expanded_url" : "http:\/\/wh.gov\/MB4f",
      "display_url" : "wh.gov\/MB4f"
    } ]
  },
  "geo" : { },
  "id_str" : "321352877450878976",
  "text" : "Obama: \"I join people here in the United States, in Israel &amp; around the world in observing Holocaust Remembrance Day\" http:\/\/t.co\/mJ7wDrMLSX",
  "id" : 321352877450878976,
  "created_at" : "2013-04-08 20:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/NmnxzG794P",
      "expanded_url" : "http:\/\/at.wh.gov\/jRjLR",
      "display_url" : "at.wh.gov\/jRjLR"
    } ]
  },
  "geo" : { },
  "id_str" : "321300506305773569",
  "text" : "Watch live at 5:45 p.m. ET: President Obama speaks on common-sense measures to reduce gun violence: http:\/\/t.co\/NmnxzG794P #NowIsTheTime",
  "id" : 321300506305773569,
  "created_at" : "2013-04-08 16:36:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thatcher",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/nwAmHkWHIh",
      "expanded_url" : "http:\/\/at.wh.gov\/jQXx6",
      "display_url" : "at.wh.gov\/jQXx6"
    } ]
  },
  "geo" : { },
  "id_str" : "321274906652340224",
  "text" : "\"The world has lost one of the great champions of freedom &amp; liberty\" -President Obama on Baroness Margaret #Thatcher: http:\/\/t.co\/nwAmHkWHIh",
  "id" : 321274906652340224,
  "created_at" : "2013-04-08 14:54:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thatcher",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/T0BPAYLvvD",
      "expanded_url" : "http:\/\/at.wh.gov\/jQXjW",
      "display_url" : "at.wh.gov\/jQXjW"
    } ]
  },
  "geo" : { },
  "id_str" : "321271088350912512",
  "text" : "Statement from President Obama on the passing of Baroness Margaret #Thatcher: http:\/\/t.co\/T0BPAYLvvD",
  "id" : 321271088350912512,
  "created_at" : "2013-04-08 14:39:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/sZ9zZIyAzX",
      "expanded_url" : "http:\/\/youtu.be\/qfJd5jpVuls",
      "display_url" : "youtu.be\/qfJd5jpVuls"
    } ]
  },
  "geo" : { },
  "id_str" : "320896042109370368",
  "text" : "RT @PressSec: President Obama: \"To make America a magnet for good #jobs, we\u2019ll invest in high-tech manufacturing\" http:\/\/t.co\/sZ9zZIyAzX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 52, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/sZ9zZIyAzX",
        "expanded_url" : "http:\/\/youtu.be\/qfJd5jpVuls",
        "display_url" : "youtu.be\/qfJd5jpVuls"
      } ]
    },
    "geo" : { },
    "id_str" : "320596261751369728",
    "text" : "President Obama: \"To make America a magnet for good #jobs, we\u2019ll invest in high-tech manufacturing\" http:\/\/t.co\/sZ9zZIyAzX",
    "id" : 320596261751369728,
    "created_at" : "2013-04-06 17:57:59 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 320896042109370368,
  "created_at" : "2013-04-07 13:49:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KXkWBqwWZH",
      "expanded_url" : "http:\/\/at.wh.gov\/jO26R",
      "display_url" : "at.wh.gov\/jO26R"
    } ]
  },
  "geo" : { },
  "id_str" : "320630895377797120",
  "text" : "Obama: \"My top priority as President, must be doing everything we can to reignite the engine of America\u2019s growth\" http:\/\/t.co\/KXkWBqwWZH",
  "id" : 320630895377797120,
  "created_at" : "2013-04-06 20:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320605028056461312",
  "text" : "RT @Interior: The Vermilion Cliffs in #Arizona provide some of the most amazing photography on public lands. Here's proof. http:\/\/t.co\/v ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/320549587200909312\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/vaOQRdB3G5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHLSJraCIAAbJMU.jpg",
        "id_str" : "320549587209297920",
        "id" : 320549587209297920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHLSJraCIAAbJMU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/vaOQRdB3G5"
      } ],
      "hashtags" : [ {
        "text" : "Arizona",
        "indices" : [ 24, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "320549587200909312",
    "text" : "The Vermilion Cliffs in #Arizona provide some of the most amazing photography on public lands. Here's proof. http:\/\/t.co\/vaOQRdB3G5",
    "id" : 320549587200909312,
    "created_at" : "2013-04-06 14:52:31 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 320605028056461312,
  "created_at" : "2013-04-06 18:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/bB1BrVNkxx",
      "expanded_url" : "http:\/\/at.wh.gov\/jO22o",
      "display_url" : "at.wh.gov\/jO22o"
    } ]
  },
  "geo" : { },
  "id_str" : "320536803193012225",
  "text" : "Weekly Address: President Obama\u2019s Plan to Create Jobs and Cut the Deficit: http:\/\/t.co\/bB1BrVNkxx",
  "id" : 320536803193012225,
  "created_at" : "2013-04-06 14:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 92, 103 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320204539334643713",
  "text" : "RT @FLOTUS: Photo: First Lady Michelle Obama plants wheat seeds with students at the spring @WhiteHouse Kitchen Garden planting: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 80, 91 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/320191071718109184\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/4fki6mCysX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHGMFVKCcAAu6QN.jpg",
        "id_str" : "320191071726497792",
        "id" : 320191071726497792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHGMFVKCcAAu6QN.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/4fki6mCysX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "320191071718109184",
    "text" : "Photo: First Lady Michelle Obama plants wheat seeds with students at the spring @WhiteHouse Kitchen Garden planting: http:\/\/t.co\/4fki6mCysX",
    "id" : 320191071718109184,
    "created_at" : "2013-04-05 15:07:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 320204539334643713,
  "created_at" : "2013-04-05 16:01:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vital Voices",
      "screen_name" : "VitalVoices",
      "indices" : [ 47, 59 ],
      "id_str" : "35127952",
      "id" : 35127952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "VAWA",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/teB0DeUIiV",
      "expanded_url" : "http:\/\/at.wh.gov\/jLfmj",
      "display_url" : "at.wh.gov\/jLfmj"
    } ]
  },
  "geo" : { },
  "id_str" : "319953042374017024",
  "text" : "In the latest #BeingBiden, @VP talks about the @VitalVoices Awards &amp; reducing violence against women: http:\/\/t.co\/teB0DeUIiV #VAWA",
  "id" : 319953042374017024,
  "created_at" : "2013-04-04 23:22:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebert",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/59Pzfd6cge",
      "expanded_url" : "http:\/\/at.wh.gov\/jL8yQ",
      "display_url" : "at.wh.gov\/jL8yQ"
    } ]
  },
  "geo" : { },
  "id_str" : "319933102002688001",
  "text" : "Statement by President Obama on the Passing of Roger #Ebert: http:\/\/t.co\/59Pzfd6cge",
  "id" : 319933102002688001,
  "created_at" : "2013-04-04 22:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MYDS40CVgl",
      "expanded_url" : "http:\/\/at.wh.gov\/jL6cv",
      "display_url" : "at.wh.gov\/jL6cv"
    } ]
  },
  "geo" : { },
  "id_str" : "319928491678265345",
  "text" : "\"For a generation of Americans - and especially Chicagoans - Roger was the movies.\" Statement by President Obama: http:\/\/t.co\/MYDS40CVgl",
  "id" : 319928491678265345,
  "created_at" : "2013-04-04 21:44:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 3, 19 ],
      "id_str" : "627799297",
      "id" : 627799297
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 117, 128 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidPresident",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/fNfYvZShVb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TssZ9Uma1-w&feature=share&list=SPzvRx_johoA-YabI6FWcU-jL6nKA1Um-t",
      "display_url" : "youtube.com\/watch?v=TssZ9U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319846489755103232",
  "text" : "RT @iamkidpresident: Incredible. #KidPresident meets with the President of the United States: http:\/\/t.co\/fNfYvZShVb @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 96, 107 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidPresident",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/fNfYvZShVb",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TssZ9Uma1-w&feature=share&list=SPzvRx_johoA-YabI6FWcU-jL6nKA1Um-t",
        "display_url" : "youtube.com\/watch?v=TssZ9U\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "319842092757180416",
    "text" : "Incredible. #KidPresident meets with the President of the United States: http:\/\/t.co\/fNfYvZShVb @whitehouse",
    "id" : 319842092757180416,
    "created_at" : "2013-04-04 16:01:11 +0000",
    "user" : {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "protected" : false,
      "id_str" : "627799297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2373000215\/qkp8f7490xr28uznmnkq_normal.jpeg",
      "id" : 627799297,
      "verified" : false
    }
  },
  "id" : 319846489755103232,
  "created_at" : "2013-04-04 16:18:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/319832138474192896\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Qo4wUkksID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHBFoqpCAAEzJPy.jpg",
      "id_str" : "319832138486775809",
      "id" : 319832138486775809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHBFoqpCAAEzJPy.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1124,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/Qo4wUkksID"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/veRKBfumP3",
      "expanded_url" : "http:\/\/on.wh.gov\/jU1mfSD",
      "display_url" : "on.wh.gov\/jU1mfSD"
    } ]
  },
  "geo" : { },
  "id_str" : "319832138474192896",
  "text" : "Photo of the Day: President Obama hugs families after a speech on reducing gun violence in CO: http:\/\/t.co\/veRKBfumP3 http:\/\/t.co\/Qo4wUkksID",
  "id" : 319832138474192896,
  "created_at" : "2013-04-04 15:21:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/319584598898130945\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/xDXigXUTki",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
      "id_str" : "319584598906519553",
      "id" : 319584598906519553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
      "sizes" : [ {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xDXigXUTki"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319817390407954433",
  "text" : "RT @Simas44: 40% of guns are sold without a background check. Closing this loophole will reduce gun violence. http:\/\/t.co\/xDXigXUTki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/319584598898130945\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/xDXigXUTki",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
        "id_str" : "319584598906519553",
        "id" : 319584598906519553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
        "sizes" : [ {
          "h" : 749,
          "resize" : "fit",
          "w" : 567
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 567
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 567
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xDXigXUTki"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319799006224080896",
    "text" : "40% of guns are sold without a background check. Closing this loophole will reduce gun violence. http:\/\/t.co\/xDXigXUTki",
    "id" : 319799006224080896,
    "created_at" : "2013-04-04 13:09:59 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 319817390407954433,
  "created_at" : "2013-04-04 14:23:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/319584598898130945\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/8uQmQDvq39",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
      "id_str" : "319584598906519553",
      "id" : 319584598906519553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
      "sizes" : [ {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8uQmQDvq39"
    } ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/k7p1Qmq6SJ",
      "expanded_url" : "http:\/\/wh.gov\/Ltjz",
      "display_url" : "wh.gov\/Ltjz"
    } ]
  },
  "geo" : { },
  "id_str" : "319654347220844544",
  "text" : "FACT: 90% of Americans support background checks for all gun sales: http:\/\/t.co\/k7p1Qmq6SJ http:\/\/t.co\/8uQmQDvq39 #Nowisthetime",
  "id" : 319654347220844544,
  "created_at" : "2013-04-04 03:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gZCwd6wnJj",
      "expanded_url" : "http:\/\/at.wh.gov\/jJ392",
      "display_url" : "at.wh.gov\/jJ392"
    } ]
  },
  "geo" : { },
  "id_str" : "319639247818743808",
  "text" : "President Obama: \"I don\u2019t believe that weapons designed for theaters of war have a place in movie theaters.\" Watch: http:\/\/t.co\/gZCwd6wnJj",
  "id" : 319639247818743808,
  "created_at" : "2013-04-04 02:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/k7p1Qmq6SJ",
      "expanded_url" : "http:\/\/wh.gov\/Ltjz",
      "display_url" : "wh.gov\/Ltjz"
    } ]
  },
  "geo" : { },
  "id_str" : "319621721445519361",
  "text" : "President Obama: \"Get the facts. We\u2019re not proposing a gun registration system, we\u2019re proposing background checks.\" http:\/\/t.co\/k7p1Qmq6SJ",
  "id" : 319621721445519361,
  "created_at" : "2013-04-04 01:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/319584598898130945\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/8uQmQDvq39",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
      "id_str" : "319584598906519553",
      "id" : 319584598906519553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG9kf92CQAEaRaQ.jpg",
      "sizes" : [ {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8uQmQDvq39"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Eda4lTRrzZ",
      "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
      "display_url" : "wh.gov\/nowisthetime"
    } ]
  },
  "geo" : { },
  "id_str" : "319584598898130945",
  "text" : "RT if you agree: #NowIsTheTime to require background checks for all gun sales: http:\/\/t.co\/Eda4lTRrzZ http:\/\/t.co\/8uQmQDvq39",
  "id" : 319584598898130945,
  "created_at" : "2013-04-03 22:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319565501502193666",
  "text" : "President Obama: \"Why wouldn\u2019t you want to make it more difficult for a dangerous criminal to get his or her hands on a gun? #NowIsTheTime",
  "id" : 319565501502193666,
  "created_at" : "2013-04-03 21:42:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319563408003448832",
  "text" : "President Obama: \"The only way this time will be different is if the American people demand that this time must be different.\" #NowIsTheTime",
  "id" : 319563408003448832,
  "created_at" : "2013-04-03 21:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319563082768740355",
  "text" : "President Obama: \"90% of Americans \u2013 90% \u2013 support background checks that will keep criminals...from buying a gun.\" #NowIsTheTime",
  "id" : 319563082768740355,
  "created_at" : "2013-04-03 21:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319563011226488833",
  "text" : "President Obama: \"I don\u2019t believe that weapons designed for theaters of war have a place in movie theaters. Most Americans agree with that.\"",
  "id" : 319563011226488833,
  "created_at" : "2013-04-03 21:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319562288925401088",
  "text" : "\"If you want to buy a gun...you should at least have to pass a background check\"  \u2013President Obama #NowIsTheTime",
  "id" : 319562288925401088,
  "created_at" : "2013-04-03 21:29:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HpuKKDK8jr",
      "expanded_url" : "http:\/\/wh.gov\/now-is-the-time",
      "display_url" : "wh.gov\/now-is-the-time"
    } ]
  },
  "geo" : { },
  "id_str" : "319561658383093762",
  "text" : "President Obama: \"I put forward a series of commonsense proposals...to reduce gun violence &amp; keep our kids safe\" http:\/\/t.co\/HpuKKDK8jr",
  "id" : 319561658383093762,
  "created_at" : "2013-04-03 21:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 129, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319561263371911168",
  "text" : "\"There doesn\u2019t have to be a conflict between protecting our citizens &amp; protecting our 2nd Amendment rights\" -President Obama #Nowisthetime",
  "id" : 319561263371911168,
  "created_at" : "2013-04-03 21:25:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "319559414413656064",
  "text" : "Happening now: President Obama speaks on common-sense measures to prevent gun violence from CO. Watch: http:\/\/t.co\/b4tqL3nPDV #Nowisthetime",
  "id" : 319559414413656064,
  "created_at" : "2013-04-03 21:17:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319504872175198209",
  "text" : "RT @DavidAgnew44: Golden Mayor Marjorie Sloan shares her thoughts on gun safety and POTUS visit to Colorado #NowIsTheTime http:\/\/t.co\/tt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/ttTm3wn2rx",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/04\/03\/colorado-mayor-shares-thoughts-gun-safety-and-president-obama-s-visit-denver",
        "display_url" : "whitehouse.gov\/blog\/2013\/04\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "319477553322684417",
    "text" : "Golden Mayor Marjorie Sloan shares her thoughts on gun safety and POTUS visit to Colorado #NowIsTheTime http:\/\/t.co\/ttTm3wn2rx",
    "id" : 319477553322684417,
    "created_at" : "2013-04-03 15:52:38 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 319504872175198209,
  "created_at" : "2013-04-03 17:41:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "319495688268435456",
  "text" : "Today, President Obama travels to Colorado to speak on common-sense measures to reduce gun violence. Watch at 5ET: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 319495688268435456,
  "created_at" : "2013-04-03 17:04:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/319456096957911040\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/TtDwyHJloC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG7voKzCUAEdb75.jpg",
      "id_str" : "319456096962105345",
      "id" : 319456096962105345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG7voKzCUAEdb75.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/TtDwyHJloC"
    } ],
    "hashtags" : [ {
      "text" : "42movie",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319456096957911040",
  "text" : "Photo of the Day: President Obama &amp; Rachel Robinson, Jackie Robinson's widow, at a screening of #42movie at the WH: http:\/\/t.co\/TtDwyHJloC",
  "id" : 319456096957911040,
  "created_at" : "2013-04-03 14:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francis S. Collins",
      "screen_name" : "NIHDirector",
      "indices" : [ 14, 26 ],
      "id_str" : "124237063",
      "id" : 124237063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/lG1VafOxG5",
      "expanded_url" : "http:\/\/at.wh.gov\/jGpKZ",
      "display_url" : "at.wh.gov\/jGpKZ"
    } ]
  },
  "geo" : { },
  "id_str" : "319204973634269184",
  "text" : "On the Clock: @NIHDirector Collins explains everything you need to know about the BRAIN Initiative in 60 seconds: http:\/\/t.co\/lG1VafOxG5",
  "id" : 319204973634269184,
  "created_at" : "2013-04-02 21:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/oPNDfF3JTt",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/04\/02\/open-questions-brain-initiative",
      "display_url" : "whitehouse.gov\/blog\/2013\/04\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319192453657792513",
  "text" : "RT @whitehouseostp: Miss today's Open for Questions on the BRAIN Initiative? We don't mind; check it out here: http:\/\/t.co\/oPNDfF3JTt @N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Francis S. Collins",
        "screen_name" : "NIHDirector",
        "indices" : [ 114, 126 ],
        "id_str" : "124237063",
        "id" : 124237063
      }, {
        "name" : "DARPA",
        "screen_name" : "DARPA",
        "indices" : [ 127, 133 ],
        "id_str" : "54645160",
        "id" : 54645160
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/oPNDfF3JTt",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/04\/02\/open-questions-brain-initiative",
        "display_url" : "whitehouse.gov\/blog\/2013\/04\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "319187677834522624",
    "text" : "Miss today's Open for Questions on the BRAIN Initiative? We don't mind; check it out here: http:\/\/t.co\/oPNDfF3JTt @NIHDirector @DARPA",
    "id" : 319187677834522624,
    "created_at" : "2013-04-02 20:40:47 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 319192453657792513,
  "created_at" : "2013-04-02 20:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3hAxUMCfgi",
      "expanded_url" : "http:\/\/youtu.be\/uJuxLDRsSQc",
      "display_url" : "youtu.be\/uJuxLDRsSQc"
    } ]
  },
  "geo" : { },
  "id_str" : "319135647627616256",
  "text" : "Full video: President Obama speaks on the BRAIN Initiative &amp; the importance of investing in American innovation: http:\/\/t.co\/3hAxUMCfgi",
  "id" : 319135647627616256,
  "created_at" : "2013-04-02 17:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 43, 58 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Francis S. Collins",
      "screen_name" : "NIHDirector",
      "indices" : [ 59, 71 ],
      "id_str" : "124237063",
      "id" : 124237063
    }, {
      "name" : "DARPA",
      "screen_name" : "DARPA",
      "indices" : [ 72, 78 ],
      "id_str" : "54645160",
      "id" : 54645160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "319118626957455360",
  "text" : "Have questions about the BRAIN Initiative? @whitehouseostp @NIHDirector @DARPA are answering now on http:\/\/t.co\/b4tqL3nPDV. Ask w\/ #WHChat",
  "id" : 319118626957455360,
  "created_at" : "2013-04-02 16:06:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/qSx1JB00tq",
      "expanded_url" : "http:\/\/at.wh.gov\/jFqLr",
      "display_url" : "at.wh.gov\/jFqLr"
    } ]
  },
  "geo" : { },
  "id_str" : "319102474394947584",
  "text" : "RT @WHLive: Have questions about the BRAIN Initiative? Watch: http:\/\/t.co\/qSx1JB00tq Ask: #WHChat &amp; join live Q&amp;A at 12ET: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/qSx1JB00tq",
        "expanded_url" : "http:\/\/at.wh.gov\/jFqLr",
        "display_url" : "at.wh.gov\/jFqLr"
      }, {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/gPAEPNyPIo",
        "expanded_url" : "http:\/\/at.wh.gov\/jFqnZ",
        "display_url" : "at.wh.gov\/jFqnZ"
      } ]
    },
    "geo" : { },
    "id_str" : "319102281834450944",
    "text" : "Have questions about the BRAIN Initiative? Watch: http:\/\/t.co\/qSx1JB00tq Ask: #WHChat &amp; join live Q&amp;A at 12ET: http:\/\/t.co\/gPAEPNyPIo",
    "id" : 319102281834450944,
    "created_at" : "2013-04-02 15:01:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 319102474394947584,
  "created_at" : "2013-04-02 15:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/319101385939492865\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wIzCYZUD0X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG2tBRSCIAEWqGs.jpg",
      "id_str" : "319101385943687169",
      "id" : 319101385943687169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG2tBRSCIAEWqGs.jpg",
      "sizes" : [ {
        "h" : 2740,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 228
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 129
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 389
      } ],
      "display_url" : "pic.twitter.com\/wIzCYZUD0X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319101385939492865",
  "text" : "INFOGRAPHIC: The \"BRAIN\" Initiative: A bold new research effort to revolutionize our understanding of the human brain http:\/\/t.co\/wIzCYZUD0X",
  "id" : 319101385939492865,
  "created_at" : "2013-04-02 14:57:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319090888838111232",
  "text" : "RT @WHLive: Obama: \"If we keep taking bold steps...I\u2019m confident America will continue to lead the world into that next frontier of huma ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319090725843247105",
    "text" : "Obama: \"If we keep taking bold steps...I\u2019m confident America will continue to lead the world into that next frontier of human understanding\"",
    "id" : 319090725843247105,
    "created_at" : "2013-04-02 14:15:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 319090888838111232,
  "created_at" : "2013-04-02 14:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/054jFx7zwU",
      "expanded_url" : "http:\/\/wh.gov\/LsH3",
      "display_url" : "wh.gov\/LsH3"
    } ]
  },
  "geo" : { },
  "id_str" : "319089511151857664",
  "text" : "\"Today [we] announce the next great American project \u2013 the BRAIN initiative.\" \u2014President Obama: http:\/\/t.co\/054jFx7zwU",
  "id" : 319089511151857664,
  "created_at" : "2013-04-02 14:10:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319088802205405185",
  "text" : "RT @WHLive: President Obama: \"Every dollar we spent to map the human genome has returned $140 to our economy.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319088655715143680",
    "text" : "President Obama: \"Every dollar we spent to map the human genome has returned $140 to our economy.\"",
    "id" : 319088655715143680,
    "created_at" : "2013-04-02 14:07:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 319088802205405185,
  "created_at" : "2013-04-02 14:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "319088590422421505",
  "text" : "President Obama: \"Ideas are what power our economy. It's what sets us apart. It\u2019s what America is all about.\" http:\/\/t.co\/b4tqL3nPDV",
  "id" : 319088590422421505,
  "created_at" : "2013-04-02 14:07:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319087370878197760",
  "text" : "RT @WHLive: Happening now: The President announces a new research initiative to revolutionize our understanding of the brain: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/oPflTkkHep",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "319087328805126144",
    "text" : "Happening now: The President announces a new research initiative to revolutionize our understanding of the brain: http:\/\/t.co\/oPflTkkHep",
    "id" : 319087328805126144,
    "created_at" : "2013-04-02 14:02:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 319087370878197760,
  "created_at" : "2013-04-02 14:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "319081823911170048",
  "text" : "Happening 9:55ET: President Obama delivers remarks on the BRAIN Initiative from the East Room. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 319081823911170048,
  "created_at" : "2013-04-02 13:40:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 71, 79 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/GwiqAlZBjj",
      "expanded_url" : "http:\/\/nyti.ms\/10tzxcz",
      "display_url" : "nyti.ms\/10tzxcz"
    } ]
  },
  "geo" : { },
  "id_str" : "319075338934157313",
  "text" : "RT @pfeiffer44: Obama to Unveil Initiative to Map the Human Brain, via @nytimes http:\/\/t.co\/GwiqAlZBjj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 55, 63 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/GwiqAlZBjj",
        "expanded_url" : "http:\/\/nyti.ms\/10tzxcz",
        "display_url" : "nyti.ms\/10tzxcz"
      } ]
    },
    "geo" : { },
    "id_str" : "319030956583440384",
    "text" : "Obama to Unveil Initiative to Map the Human Brain, via @nytimes http:\/\/t.co\/GwiqAlZBjj",
    "id" : 319030956583440384,
    "created_at" : "2013-04-02 10:18:02 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 319075338934157313,
  "created_at" : "2013-04-02 13:14:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 34, 50 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/318929050259300352\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/TWF9WGeJ2g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG0QSA2CIAEsR5G.jpg",
      "id_str" : "318929050263494657",
      "id" : 318929050263494657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG0QSA2CIAEsR5G.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TWF9WGeJ2g"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318929050259300352",
  "text" : "Photo of the Day: The Obamas join @iamkidpresident &amp; the Easter Bunny in welcoming families to the WH #EasterEggRoll: http:\/\/t.co\/TWF9WGeJ2g",
  "id" : 318929050259300352,
  "created_at" : "2013-04-02 03:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/318913964186673152\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/bYMj8sslxW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BG0Cj43CIAAFW5p.jpg",
      "id_str" : "318913964195061760",
      "id" : 318913964195061760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BG0Cj43CIAAFW5p.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 991
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 991
      } ],
      "display_url" : "pic.twitter.com\/bYMj8sslxW"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318913964186673152",
  "text" : "\"If you know how to read then the whole world opens up to you.\"-President Obama to kids at the WH #EasterEggRoll: http:\/\/t.co\/bYMj8sslxW",
  "id" : 318913964186673152,
  "created_at" : "2013-04-02 02:33:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 17, 24 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 46, 62 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/318883743953723392\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RG5G91hCcU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGznE1uCIAAAOjH.jpg",
      "id_str" : "318883743962112000",
      "id" : 318883743962112000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGznE1uCIAAAOjH.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/RG5G91hCcU"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318883743953723392",
  "text" : "President Obama, @FLOTUS, Sasha, Malia, &amp; @iamkidpresident join kids on the South Lawn for the #EasterEggRoll: http:\/\/t.co\/RG5G91hCcU",
  "id" : 318883743953723392,
  "created_at" : "2013-04-02 00:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Sanchez",
      "screen_name" : "JessicaESanchez",
      "indices" : [ 28, 44 ],
      "id_str" : "462489802",
      "id" : 462489802
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/318853589365837824\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Tgqv31vLjy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGzLpnICUAI6Lkz.jpg",
      "id_str" : "318853589374226434",
      "id" : 318853589374226434,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGzLpnICUAI6Lkz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Tgqv31vLjy"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318853589365837824",
  "text" : "The First Family listens to @JessicaESanchez sing the National Anthem at the 2013 White House #EasterEggRoll: http:\/\/t.co\/Tgqv31vLjy",
  "id" : 318853589365837824,
  "created_at" : "2013-04-01 22:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 3, 19 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318801675504738304",
  "text" : "RT @iamkidpresident: We're at the White House and YOU made this happen. Thank you for sharing our videos &amp; our message! #AtTheWH #Aw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AtTheWH",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "Awesomeyear",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318800126514696196",
    "text" : "We're at the White House and YOU made this happen. Thank you for sharing our videos &amp; our message! #AtTheWH #Awesomeyear",
    "id" : 318800126514696196,
    "created_at" : "2013-04-01 19:00:47 +0000",
    "user" : {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "protected" : false,
      "id_str" : "627799297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2373000215\/qkp8f7490xr28uznmnkq_normal.jpeg",
      "id" : 627799297,
      "verified" : false
    }
  },
  "id" : 318801675504738304,
  "created_at" : "2013-04-01 19:06:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 60, 71 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318767953988431873",
  "text" : "RT @FLOTUS: So excited to host thousands of families at the @WhiteHouse today for the 2013 #EasterEggRoll. What a view! \u2013mo http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 48, 59 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/318762338268352513\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/8bzzdgpUct",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BGx4qGTCEAMrfTD.jpg",
        "id_str" : "318762338276741123",
        "id" : 318762338276741123,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGx4qGTCEAMrfTD.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        } ],
        "display_url" : "pic.twitter.com\/8bzzdgpUct"
      } ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 79, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318762338268352513",
    "text" : "So excited to host thousands of families at the @WhiteHouse today for the 2013 #EasterEggRoll. What a view! \u2013mo http:\/\/t.co\/8bzzdgpUct",
    "id" : 318762338268352513,
    "created_at" : "2013-04-01 16:30:38 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 318767953988431873,
  "created_at" : "2013-04-01 16:52:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Austin Mahone",
      "screen_name" : "AustinMahone",
      "indices" : [ 36, 49 ],
      "id_str" : "196795202",
      "id" : 196795202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "EasterEggRoll",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318766657793294336",
  "text" : "RT @letsmove: #AtTheWH listening to @AustinMahone at the Rock n' Egg Roll Stage? Share your #EasterEggRoll photos. Select tweets on http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Austin Mahone",
        "screen_name" : "AustinMahone",
        "indices" : [ 22, 35 ],
        "id_str" : "196795202",
        "id" : 196795202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AtTheWH",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "EasterEggRoll",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eA8DdR5ZL1",
        "expanded_url" : "http:\/\/Wh.gov\/EasterEggRoll",
        "display_url" : "Wh.gov\/EasterEggRoll"
      } ]
    },
    "geo" : { },
    "id_str" : "318766123908751361",
    "text" : "#AtTheWH listening to @AustinMahone at the Rock n' Egg Roll Stage? Share your #EasterEggRoll photos. Select tweets on http:\/\/t.co\/eA8DdR5ZL1",
    "id" : 318766123908751361,
    "created_at" : "2013-04-01 16:45:40 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 318766657793294336,
  "created_at" : "2013-04-01 16:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "318736032495452160",
  "text" : "Happening now: President Obama &amp; @FLOTUS Michelle Obama welcome families to the 2013 #EasterEggRoll. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 318736032495452160,
  "created_at" : "2013-04-01 14:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/qURaCeMcVh",
      "expanded_url" : "http:\/\/youtu.be\/5byDhm-E-YE",
      "display_url" : "youtu.be\/5byDhm-E-YE"
    } ]
  },
  "geo" : { },
  "id_str" : "318727194073522178",
  "text" : "This morning, the White House released a special video message from the President. Watch: http:\/\/t.co\/qURaCeMcVh",
  "id" : 318727194073522178,
  "created_at" : "2013-04-01 14:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/yBbHL80leY",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "318718826038566912",
  "text" : "At 10:00 a.m. ET, the White House will release a special video message from the President, available only at http:\/\/t.co\/yBbHL80leY.",
  "id" : 318718826038566912,
  "created_at" : "2013-04-01 13:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]