Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/Eyah277B",
      "expanded_url" : "http:\/\/ow.ly\/8eOBQ",
      "display_url" : "ow.ly\/8eOBQ"
    } ]
  },
  "geo" : { },
  "id_str" : "153263869450649600",
  "text" : "West Wing Week: Look back at 2011 with behind-the-scenes footage & some of our favorite Presidential moment: http:\/\/t.co\/Eyah277B",
  "id" : 153263869450649600,
  "created_at" : "2011-12-31 23:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 56, 66 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 108, 115 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Gj8npwuW",
      "expanded_url" : "http:\/\/bit.ly\/scDf9c",
      "display_url" : "bit.ly\/scDf9c"
    } ]
  },
  "geo" : { },
  "id_str" : "153249145220644864",
  "text" : "2011 in Photos: Chief Official @whitehouse photographer @petesouza takes you behind the scenes in a new set @flickr: http:\/\/t.co\/Gj8npwuW",
  "id" : 153249145220644864,
  "created_at" : "2011-12-31 23:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153230424129286145",
  "text" : "RT @jesseclee44: Obama on NDAA: \"Administration will aggressively seek to mitigate those concerns through...authorities available to me\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/JNaZHaUX",
        "expanded_url" : "http:\/\/wh.gov\/Waa",
        "display_url" : "wh.gov\/Waa"
      } ]
    },
    "geo" : { },
    "id_str" : "153230084130611201",
    "text" : "Obama on NDAA: \"Administration will aggressively seek to mitigate those concerns through...authorities available to me\" http:\/\/t.co\/JNaZHaUX",
    "id" : 153230084130611201,
    "created_at" : "2011-12-31 21:44:33 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 153230424129286145,
  "created_at" : "2011-12-31 21:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/w3VpfrfL",
      "expanded_url" : "http:\/\/bit.ly\/scDf9c",
      "display_url" : "bit.ly\/scDf9c"
    } ]
  },
  "geo" : { },
  "id_str" : "153201443170549760",
  "text" : "RT @petesouza: 2011 Year in Photos by Pete Souza: http:\/\/t.co\/w3VpfrfL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/w3VpfrfL",
        "expanded_url" : "http:\/\/bit.ly\/scDf9c",
        "display_url" : "bit.ly\/scDf9c"
      } ]
    },
    "geo" : { },
    "id_str" : "152704059625836545",
    "text" : "2011 Year in Photos by Pete Souza: http:\/\/t.co\/w3VpfrfL",
    "id" : 152704059625836545,
    "created_at" : "2011-12-30 10:54:19 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 153201443170549760,
  "created_at" : "2011-12-31 19:50:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/153200848065933312\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/y9AHw5BG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiBHXBCCMAAPVey.jpg",
      "id_str" : "153200848070127616",
      "id" : 153200848070127616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiBHXBCCMAAPVey.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y9AHw5BG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153200848065933312",
  "text" : "Photo of the Day: President Obama places a wreath at the USS Arizona Memorial in Pearl Harbor, Hawaii: http:\/\/t.co\/y9AHw5BG",
  "id" : 153200848065933312,
  "created_at" : "2011-12-31 19:48:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/SXVlC3TY",
      "expanded_url" : "http:\/\/ow.ly\/8eKum",
      "display_url" : "ow.ly\/8eKum"
    } ]
  },
  "geo" : { },
  "id_str" : "153199379006750720",
  "text" : "WEEKLY ADDRESS: Working together in the New Year to move America forward: http:\/\/t.co\/SXVlC3TY",
  "id" : 153199379006750720,
  "created_at" : "2011-12-31 19:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Kqgkilqf",
      "expanded_url" : "http:\/\/goo.gl\/fb\/OoXnU",
      "display_url" : "goo.gl\/fb\/OoXnU"
    } ]
  },
  "geo" : { },
  "id_str" : "152909029440634880",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: West Wing Week: 12\/30\/11 or Best of the West (Wing Week) http:\/\/t.co\/Kqgkilqf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/Kqgkilqf",
        "expanded_url" : "http:\/\/goo.gl\/fb\/OoXnU",
        "display_url" : "goo.gl\/fb\/OoXnU"
      } ]
    },
    "geo" : { },
    "id_str" : "152653659795230720",
    "text" : "http:\/\/t.co\/HxTO58SB: West Wing Week: 12\/30\/11 or Best of the West (Wing Week) http:\/\/t.co\/Kqgkilqf",
    "id" : 152653659795230720,
    "created_at" : "2011-12-30 07:34:03 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 152909029440634880,
  "created_at" : "2011-12-31 00:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Ht4YtxlS",
      "expanded_url" : "http:\/\/goo.gl\/fb\/PXGR4",
      "display_url" : "goo.gl\/fb\/PXGR4"
    } ]
  },
  "geo" : { },
  "id_str" : "152521160108675072",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: 2011 Year in Review: Top Photos from the White House Flickr Feed http:\/\/t.co\/Ht4YtxlS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/Ht4YtxlS",
        "expanded_url" : "http:\/\/goo.gl\/fb\/PXGR4",
        "display_url" : "goo.gl\/fb\/PXGR4"
      } ]
    },
    "geo" : { },
    "id_str" : "152514725878579200",
    "text" : "http:\/\/t.co\/HxTO58SB: 2011 Year in Review: Top Photos from the White House Flickr Feed http:\/\/t.co\/Ht4YtxlS",
    "id" : 152514725878579200,
    "created_at" : "2011-12-29 22:21:58 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 152521160108675072,
  "created_at" : "2011-12-29 22:47:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/jJ1oeJW2",
      "expanded_url" : "http:\/\/goo.gl\/fb\/PXGR4",
      "display_url" : "goo.gl\/fb\/PXGR4"
    } ]
  },
  "geo" : { },
  "id_str" : "152521126034161665",
  "text" : "2011 Year in Review: Top Photos from the @whitehouse  Flickr Feed http:\/\/t.co\/jJ1oeJW2\"",
  "id" : 152521126034161665,
  "created_at" : "2011-12-29 22:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 38, 49 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 50, 58 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/pd2NTGCG",
      "expanded_url" : "http:\/\/goo.gl\/fb\/jWwTP",
      "display_url" : "goo.gl\/fb\/jWwTP"
    } ]
  },
  "geo" : { },
  "id_str" : "152155744874151936",
  "text" : "2011 Year in Review: The most popular @whitehouse @YouTube videos: http:\/\/t.co\/pd2NTGCG",
  "id" : 152155744874151936,
  "created_at" : "2011-12-28 22:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/9Xp0RHl8",
      "expanded_url" : "http:\/\/ow.ly\/8cluZ",
      "display_url" : "ow.ly\/8cluZ"
    } ]
  },
  "geo" : { },
  "id_str" : "152101693373427713",
  "text" : "2011 Year in Review: 8 ways the health care law helps you: http:\/\/t.co\/9Xp0RHl8 #hcr",
  "id" : 152101693373427713,
  "created_at" : "2011-12-28 19:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/K9JE6qMT",
      "expanded_url" : "http:\/\/ow.ly\/8bpAr",
      "display_url" : "ow.ly\/8bpAr"
    } ]
  },
  "geo" : { },
  "id_str" : "151784487339032576",
  "text" : "President Obama & the First Lady Mark the beginning of Kwanzaa: http:\/\/t.co\/K9JE6qMT",
  "id" : 151784487339032576,
  "created_at" : "2011-12-27 22:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KCHonors",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/AKuVorNe",
      "expanded_url" : "http:\/\/ow.ly\/8bpuv",
      "display_url" : "ow.ly\/8bpuv"
    } ]
  },
  "geo" : { },
  "id_str" : "151761824101044224",
  "text" : "Behind the Scenes: The Ceremony at the @WhiteHouse before the 2011 Kennedy Center Honors: http:\/\/t.co\/AKuVorNe #KCHonors",
  "id" : 151761824101044224,
  "created_at" : "2011-12-27 20:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marine Corps Base HI",
      "screen_name" : "MCBHawaii",
      "indices" : [ 70, 80 ],
      "id_str" : "125519902",
      "id" : 125519902
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/151747324182401024\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/p21GlQcU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhsdYynCEAAoKx7.jpg",
      "id_str" : "151747324186595328",
      "id" : 151747324186595328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhsdYynCEAAoKx7.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1046,
        "resize" : "fit",
        "w" : 1574
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/p21GlQcU"
    } ],
    "hashtags" : [ {
      "text" : "cutebaby",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151747324182401024",
  "text" : "Photo of the Day: While visiting military families during Xmas dinner @MCBHawaii, #cutebaby grabs the President's face: http:\/\/t.co\/p21GlQcU",
  "id" : 151747324182401024,
  "created_at" : "2011-12-27 19:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/GNsrZEhX",
      "expanded_url" : "http:\/\/ow.ly\/8avMu",
      "display_url" : "ow.ly\/8avMu"
    } ]
  },
  "geo" : { },
  "id_str" : "151429627590619136",
  "text" : "Hanukkah at the @WhiteHouse: Watch the history of the 2011 Menorah: http:\/\/t.co\/GNsrZEhX",
  "id" : 151429627590619136,
  "created_at" : "2011-12-26 22:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/151380908040142848\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/IuxdeliB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhnQIkICQAA-hvI.jpg",
      "id_str" : "151380908048531456",
      "id" : 151380908048531456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhnQIkICQAA-hvI.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IuxdeliB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151380908040142848",
  "text" : "Photo: On Christmas Eve, President Obama calls to 10 American servicemembers stationed around the world from Hawaii: http:\/\/t.co\/IuxdeliB",
  "id" : 151380908040142848,
  "created_at" : "2011-12-26 19:16:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151379693453574144",
  "text" : "RT @JoiningForces: 1% of Americans may be fighting our wars, we need 100% to be supporting our troops & their families. Get involved @ h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/z59SlqHM",
        "expanded_url" : "http:\/\/joiningforces.gov",
        "display_url" : "joiningforces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "151379553317699584",
    "text" : "1% of Americans may be fighting our wars, we need 100% to be supporting our troops & their families. Get involved @ http:\/\/t.co\/z59SlqHM",
    "id" : 151379553317699584,
    "created_at" : "2011-12-26 19:11:12 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 151379693453574144,
  "created_at" : "2011-12-26 19:11:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/2AjqZAt4",
      "expanded_url" : "http:\/\/serve.gov",
      "display_url" : "serve.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "151378338689196032",
  "text" : "\"Giving of ourselves; service to others \u2013 that\u2019s what this season is all about\" -President Obama. Find opportunities @ http:\/\/t.co\/2AjqZAt4",
  "id" : 151378338689196032,
  "created_at" : "2011-12-26 19:06:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151154400361058304",
  "text" : "RT @VP: PHOTO: VP & Dr B get ready to visit w\/patients & fams @ Walter Reed National Military Medical Center on Christmas day http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/151145563092557824\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/1m7HOUh8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ahj6Fr3CIAEd5XK.jpg",
        "id_str" : "151145563096752129",
        "id" : 151145563096752129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ahj6Fr3CIAEd5XK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/1m7HOUh8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "151145563092557824",
    "text" : "PHOTO: VP & Dr B get ready to visit w\/patients & fams @ Walter Reed National Military Medical Center on Christmas day http:\/\/t.co\/1m7HOUh8",
    "id" : 151145563092557824,
    "created_at" : "2011-12-26 03:41:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 151154400361058304,
  "created_at" : "2011-12-26 04:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/cGugnsXD",
      "expanded_url" : "http:\/\/joiningforces.gov\/thanks",
      "display_url" : "joiningforces.gov\/thanks"
    } ]
  },
  "geo" : { },
  "id_str" : "151104996891566081",
  "text" : "There\u2019s no better time than the holidays to let our troops know how grateful we are for all that they do: http:\/\/t.co\/cGugnsXD",
  "id" : 151104996891566081,
  "created_at" : "2011-12-26 01:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/dUnpLPQw",
      "expanded_url" : "http:\/\/ow.ly\/89Muh",
      "display_url" : "ow.ly\/89Muh"
    } ]
  },
  "geo" : { },
  "id_str" : "151074780068593664",
  "text" : "\"For many military families, the best gift this year is...welcoming a loved one back for the holidays\" -President Obama http:\/\/t.co\/dUnpLPQw",
  "id" : 151074780068593664,
  "created_at" : "2011-12-25 23:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/1BDBlpv6",
      "expanded_url" : "http:\/\/ow.ly\/89MgQ",
      "display_url" : "ow.ly\/89MgQ"
    } ]
  },
  "geo" : { },
  "id_str" : "151044608158208000",
  "text" : "Shine, Give, Share: Have a look at how the @WhiteHouse honors military families this holiday season: http:\/\/t.co\/1BDBlpv6",
  "id" : 151044608158208000,
  "created_at" : "2011-12-25 21:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/tgMeVWms",
      "expanded_url" : "http:\/\/ow.ly\/89Mro",
      "display_url" : "ow.ly\/89Mro"
    } ]
  },
  "geo" : { },
  "id_str" : "151029476833234944",
  "text" : "Go behind the scenes in the @WhiteHouse kitchen for Hanukkah: http:\/\/t.co\/tgMeVWms",
  "id" : 151029476833234944,
  "created_at" : "2011-12-25 20:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "May Devers",
      "screen_name" : "JustinNOAA",
      "indices" : [ 85, 96 ],
      "id_str" : "4377747975",
      "id" : 4377747975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150982857609854977",
  "text" : "RT @whitehouseostp: Merry Christmas and thanks to NOAA for keeping our snow count RT @JustinNOAA White Christmas for 30% of US (Lower 48 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "May Devers",
        "screen_name" : "JustinNOAA",
        "indices" : [ 65, 76 ],
        "id_str" : "4377747975",
        "id" : 4377747975
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/04psAxTO",
        "expanded_url" : "http:\/\/bit.ly\/rYlcYK",
        "display_url" : "bit.ly\/rYlcYK"
      } ]
    },
    "geo" : { },
    "id_str" : "150981797650501633",
    "text" : "Merry Christmas and thanks to NOAA for keeping our snow count RT @JustinNOAA White Christmas for 30% of US (Lower 48) http:\/\/t.co\/04psAxTO",
    "id" : 150981797650501633,
    "created_at" : "2011-12-25 16:50:40 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 150982857609854977,
  "created_at" : "2011-12-25 16:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "indices" : [ 3, 14 ],
      "id_str" : "374019904",
      "id" : 374019904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150982708078706688",
  "text" : "RT @FitnessGov: Merry Christmas from the President's Council!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150970349180301312",
    "text" : "Merry Christmas from the President's Council!",
    "id" : 150970349180301312,
    "created_at" : "2011-12-25 16:05:10 +0000",
    "user" : {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "protected" : false,
      "id_str" : "374019904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1544099616\/President_s_Council_Fitness_Sports_Nutrition_3Color_Logo_V2_normal.png",
      "id" : 374019904,
      "verified" : true
    }
  },
  "id" : 150982708078706688,
  "created_at" : "2011-12-25 16:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150982683349094401",
  "text" : "RT @AmbassadorRice: A very Merry Christmas to all who are celebrating today around the world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150966287709900801",
    "text" : "A very Merry Christmas to all who are celebrating today around the world.",
    "id" : 150966287709900801,
    "created_at" : "2011-12-25 15:49:02 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 150982683349094401,
  "created_at" : "2011-12-25 16:54:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/L5idqhbb",
      "expanded_url" : "http:\/\/ow.ly\/89Mow",
      "display_url" : "ow.ly\/89Mow"
    } ]
  },
  "geo" : { },
  "id_str" : "150953965780086784",
  "text" : "This holiday season, let\u2019s make sure our troops & their families know how much we appreciate all they do. Get involved: http:\/\/t.co\/L5idqhbb",
  "id" : 150953965780086784,
  "created_at" : "2011-12-25 15:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 38, 49 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/3ZTMNkHM",
      "expanded_url" : "http:\/\/ow.ly\/89MiQ",
      "display_url" : "ow.ly\/89MiQ"
    } ]
  },
  "geo" : { },
  "id_str" : "150931331554091009",
  "text" : "Merry Christmas & Happy Holidays from @WhiteHouse! Watch a message from the President & First Lady: http:\/\/t.co\/3ZTMNkHM",
  "id" : 150931331554091009,
  "created_at" : "2011-12-25 13:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4JQ5esxM",
      "expanded_url" : "http:\/\/youtu.be\/GsYvgIVEROU",
      "display_url" : "youtu.be\/GsYvgIVEROU"
    } ]
  },
  "geo" : { },
  "id_str" : "150828637938130944",
  "text" : "\"Michelle, Malia, Sasha & I (and of course Bo) want to wish you all Merry Christmas & Happy Holidays\" -President Obama http:\/\/t.co\/4JQ5esxM",
  "id" : 150828637938130944,
  "created_at" : "2011-12-25 06:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/i0GpB5jG",
      "expanded_url" : "http:\/\/ow.ly\/89IWd",
      "display_url" : "ow.ly\/89IWd"
    } ]
  },
  "geo" : { },
  "id_str" : "150751378560659456",
  "text" : "Behind the scenes look: Time-Lapse of holidays at the @WhiteHouse: http:\/\/t.co\/i0GpB5jG",
  "id" : 150751378560659456,
  "created_at" : "2011-12-25 01:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NORAD Santa",
      "screen_name" : "NoradSanta",
      "indices" : [ 3, 14 ],
      "id_str" : "16460682",
      "id" : 16460682
    }, {
      "name" : "NORAD Santa",
      "screen_name" : "NoradSanta",
      "indices" : [ 98, 109 ],
      "id_str" : "16460682",
      "id" : 16460682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Santa",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/k2rOsu8x",
      "expanded_url" : "http:\/\/goo.gl\/qSwk",
      "display_url" : "goo.gl\/qSwk"
    } ]
  },
  "geo" : { },
  "id_str" : "150732061383208960",
  "text" : "RT @NoradSanta: #Santa just left the North Pole! http:\/\/t.co\/k2rOsu8x Stay tuned for updates from @NoradSanta all night!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NORAD Santa",
        "screen_name" : "NoradSanta",
        "indices" : [ 82, 93 ],
        "id_str" : "16460682",
        "id" : 16460682
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Santa",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/k2rOsu8x",
        "expanded_url" : "http:\/\/goo.gl\/qSwk",
        "display_url" : "goo.gl\/qSwk"
      } ]
    },
    "geo" : { },
    "id_str" : "150534068222705665",
    "text" : "#Santa just left the North Pole! http:\/\/t.co\/k2rOsu8x Stay tuned for updates from @NoradSanta all night!",
    "id" : 150534068222705665,
    "created_at" : "2011-12-24 11:11:33 +0000",
    "user" : {
      "name" : "NORAD Santa",
      "screen_name" : "NoradSanta",
      "protected" : false,
      "id_str" : "16460682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794299753437794305\/P3mYaMEg_normal.jpg",
      "id" : 16460682,
      "verified" : false
    }
  },
  "id" : 150732061383208960,
  "created_at" : "2011-12-25 00:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/hPSpoT0n",
      "expanded_url" : "http:\/\/ow.ly\/89IHa",
      "display_url" : "ow.ly\/89IHa"
    } ]
  },
  "geo" : { },
  "id_str" : "150731938834022402",
  "text" : "Photo: On Christmas Eve, First Lady Michelle Obama takes calls from kids as part of the NORAD tracks Santa program: http:\/\/t.co\/hPSpoT0n",
  "id" : 150731938834022402,
  "created_at" : "2011-12-25 00:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/44jzagGg",
      "expanded_url" : "http:\/\/ow.ly\/89D4L",
      "display_url" : "ow.ly\/89D4L"
    } ]
  },
  "geo" : { },
  "id_str" : "150674619349729281",
  "text" : "\"From our family to yours, Merry Christmas\" -First Lady Michelle Obama: http:\/\/t.co\/44jzagGg",
  "id" : 150674619349729281,
  "created_at" : "2011-12-24 20:30:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/m1mRFuJo",
      "expanded_url" : "http:\/\/ow.ly\/89D1D",
      "display_url" : "ow.ly\/89D1D"
    } ]
  },
  "geo" : { },
  "id_str" : "150659555938934785",
  "text" : "Behind the Scenes Videos: Holidays at the @WhiteHouse: http:\/\/t.co\/m1mRFuJo",
  "id" : 150659555938934785,
  "created_at" : "2011-12-24 19:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/zPqpnXSd",
      "expanded_url" : "http:\/\/ow.ly\/89CUr",
      "display_url" : "ow.ly\/89CUr"
    } ]
  },
  "geo" : { },
  "id_str" : "150637312089399297",
  "text" : "The President & First Lady wish all Americans a Merry Christmas & Happy Holidays & thank our troops & their families: http:\/\/t.co\/zPqpnXSd",
  "id" : 150637312089399297,
  "created_at" : "2011-12-24 18:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/rVdhzCvh",
      "expanded_url" : "http:\/\/ow.ly\/89d7u",
      "display_url" : "ow.ly\/89d7u"
    } ]
  },
  "geo" : { },
  "id_str" : "150323975438860291",
  "text" : "President Obama: Extending the payroll tax cut is a \"boost we need right now\": http:\/\/t.co\/rVdhzCvh #40dollars",
  "id" : 150323975438860291,
  "created_at" : "2011-12-23 21:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/AW3Nb1we",
      "expanded_url" : "http:\/\/go.usa.gov\/Npf",
      "display_url" : "go.usa.gov\/Npf"
    } ]
  },
  "geo" : { },
  "id_str" : "150286218716909568",
  "text" : "RT @ENERGY: We'll be using the latest technology to monitor Santa's flight path as he circles the globe - http:\/\/t.co\/AW3Nb1we",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/AW3Nb1we",
        "expanded_url" : "http:\/\/go.usa.gov\/Npf",
        "display_url" : "go.usa.gov\/Npf"
      } ]
    },
    "geo" : { },
    "id_str" : "150223949433815041",
    "text" : "We'll be using the latest technology to monitor Santa's flight path as he circles the globe - http:\/\/t.co\/AW3Nb1we",
    "id" : 150223949433815041,
    "created_at" : "2011-12-23 14:39:15 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 150286218716909568,
  "created_at" : "2011-12-23 18:46:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150281656077524992",
  "text" : "RT @WHLive: Obama: We need to make sure we\u2019re rebuilding an economy where if you work hard, that work will be rewarded.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150281574187937792",
    "text" : "Obama: We need to make sure we\u2019re rebuilding an economy where if you work hard, that work will be rewarded.",
    "id" : 150281574187937792,
    "created_at" : "2011-12-23 18:28:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 150281656077524992,
  "created_at" : "2011-12-23 18:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150281273607331840",
  "text" : "RT @WHLive: Obama: Finally, I want to take a moment to thank every American who brought their voice to this debate. #40dollars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150281230682824704",
    "text" : "Obama: Finally, I want to take a moment to thank every American who brought their voice to this debate. #40dollars",
    "id" : 150281230682824704,
    "created_at" : "2011-12-23 18:26:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 150281273607331840,
  "created_at" : "2011-12-23 18:27:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150280989992693760",
  "text" : "RT @WHLive: Obama: Because of this agreement, every working American will keep their tax cut...That's an extra #40dollars or so in every ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150280954223669248",
    "text" : "Obama: Because of this agreement, every working American will keep their tax cut...That's an extra #40dollars or so in every paycheck.",
    "id" : 150280954223669248,
    "created_at" : "2011-12-23 18:25:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 150280989992693760,
  "created_at" : "2011-12-23 18:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 90, 97 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SorryForTheDelay",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "150280770932588544",
  "text" : "Happening now: President Obama delivers remarks. Watch live: http:\/\/t.co\/u95y7hhB Follow: @WHLive #SorryForTheDelay",
  "id" : 150280770932588544,
  "created_at" : "2011-12-23 18:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 83, 91 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/hp31yD0U",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/what-does-40dollars-mean-to-americans",
      "display_url" : "storify.com\/whitehouse\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150254276671848448",
  "text" : "RT @ks44: More stories: What does #40dollars mean to you? http:\/\/t.co\/hp31yD0U via @Storify",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 73, 81 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 24, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/hp31yD0U",
        "expanded_url" : "http:\/\/storify.com\/whitehouse\/what-does-40dollars-mean-to-americans",
        "display_url" : "storify.com\/whitehouse\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "150254142202458113",
    "text" : "More stories: What does #40dollars mean to you? http:\/\/t.co\/hp31yD0U via @Storify",
    "id" : 150254142202458113,
    "created_at" : "2011-12-23 16:39:13 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 150254276671848448,
  "created_at" : "2011-12-23 16:39:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "150244895448240128",
  "text" : "At 12:15ET President Obama will deliver a statement in the Press Briefing Room. Watch live @ http:\/\/t.co\/hhNoX4fh",
  "id" : 150244895448240128,
  "created_at" : "2011-12-23 16:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/qmHT3idC",
      "expanded_url" : "http:\/\/youtu.be\/sCeRUvSvIu4",
      "display_url" : "youtu.be\/sCeRUvSvIu4"
    } ]
  },
  "geo" : { },
  "id_str" : "150236695076413441",
  "text" : "Check out the latest West Wing Week or #40dollars: http:\/\/t.co\/qmHT3idC",
  "id" : 150236695076413441,
  "created_at" : "2011-12-23 15:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150235425531887617",
  "text" : "RT @pfeiffer44: With House and Senate approval of the payroll tax cut extension, the countdown clock in the briefing room with be off sh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "150234010944151553",
    "text" : "With House and Senate approval of the payroll tax cut extension, the countdown clock in the briefing room with be off shortly",
    "id" : 150234010944151553,
    "created_at" : "2011-12-23 15:19:14 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 150235425531887617,
  "created_at" : "2011-12-23 15:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150012620815089664",
  "text" : "Thanks to all who shared #40dollars stories. Today's victory is yours. Keep making your voices heard \u2013 it makes all the difference. \u2013bo",
  "id" : 150012620815089664,
  "created_at" : "2011-12-23 00:39:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 43, 46 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150004071770767360",
  "text" : "RT @JoiningForces: Go inside @whitehouse & @VP's residence for a look at how we're honoring our troops & their families for the holidays ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 24, 27 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/9D5tztOt",
        "expanded_url" : "http:\/\/ow.ly\/88kJC",
        "display_url" : "ow.ly\/88kJC"
      } ]
    },
    "geo" : { },
    "id_str" : "150003716395761665",
    "text" : "Go inside @whitehouse & @VP's residence for a look at how we're honoring our troops & their families for the holidays: http:\/\/t.co\/9D5tztOt",
    "id" : 150003716395761665,
    "created_at" : "2011-12-23 00:04:07 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 150004071770767360,
  "created_at" : "2011-12-23 00:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149989011748962304",
  "text" : "\"Because of this agreement, every working American will keep his or her tax cut...about #40dollars in every paycheck\" -President Obama",
  "id" : 149989011748962304,
  "created_at" : "2011-12-22 23:05:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/lV4y0fen",
      "expanded_url" : "http:\/\/ow.ly\/88iR6",
      "display_url" : "ow.ly\/88iR6"
    } ]
  },
  "geo" : { },
  "id_str" : "149988813500989440",
  "text" : "\"This is good news, just in time for the holidays.\" Statement by the President: http:\/\/t.co\/lV4y0fen #40dollars",
  "id" : 149988813500989440,
  "created_at" : "2011-12-22 23:04:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149977734033059840",
  "text" : "\"Let\u2019s give the American people - the people who sent us here - the kind of leadership they deserve\" -President Obama #40dollars",
  "id" : 149977734033059840,
  "created_at" : "2011-12-22 22:20:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Al Sharpton",
      "screen_name" : "TheRevAl",
      "indices" : [ 3, 12 ],
      "id_str" : "42389136",
      "id" : 42389136
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149237000522825729\/photo\/1",
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/kEx91FUJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
      "id_str" : "149237000527020032",
      "id" : 149237000527020032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/kEx91FUJ"
    } ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149958874995232768",
  "text" : "RT @TheRevAl: Share your Story on what #40dollars means to you http:\/\/t.co\/kEx91FUJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149237000522825729\/photo\/1",
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/kEx91FUJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
        "id_str" : "149237000527020032",
        "id" : 149237000527020032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 615
        } ],
        "display_url" : "pic.twitter.com\/kEx91FUJ"
      } ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 25, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149944582631731200",
    "text" : "Share your Story on what #40dollars means to you http:\/\/t.co\/kEx91FUJ",
    "id" : 149944582631731200,
    "created_at" : "2011-12-22 20:09:08 +0000",
    "user" : {
      "name" : "Reverend Al Sharpton",
      "screen_name" : "TheRevAl",
      "protected" : false,
      "id_str" : "42389136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582666227811745792\/5An66SOQ_normal.png",
      "id" : 42389136,
      "verified" : true
    }
  },
  "id" : 149958874995232768,
  "created_at" : "2011-12-22 21:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 102, 113 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/asj5LQd2",
      "expanded_url" : "http:\/\/owl.li\/88atU",
      "display_url" : "owl.li\/88atU"
    } ]
  },
  "geo" : { },
  "id_str" : "149958379475968000",
  "text" : "RT @SBAgov: What #40dollars means to #smallbiz, our customers, and our employees http:\/\/t.co\/asj5LQd2 @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 90, 101 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 5, 15 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/asj5LQd2",
        "expanded_url" : "http:\/\/owl.li\/88atU",
        "display_url" : "owl.li\/88atU"
      } ]
    },
    "geo" : { },
    "id_str" : "149950314064257024",
    "text" : "What #40dollars means to #smallbiz, our customers, and our employees http:\/\/t.co\/asj5LQd2 @whitehouse",
    "id" : 149950314064257024,
    "created_at" : "2011-12-22 20:31:55 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 149958379475968000,
  "created_at" : "2011-12-22 21:03:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 3, 11 ],
      "id_str" : "24024778",
      "id" : 24024778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149957841208356865",
  "text" : "RT @kalpenn: Reading lot of tweets about the House refusing 2 pass bipartisan payroll tax cut. What does #40dollars mean 2 you? @whiteho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 115, 126 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 127, 139 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149954952050118656",
    "text" : "Reading lot of tweets about the House refusing 2 pass bipartisan payroll tax cut. What does #40dollars mean 2 you? @whitehouse @JonCarson44",
    "id" : 149954952050118656,
    "created_at" : "2011-12-22 20:50:21 +0000",
    "user" : {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "protected" : false,
      "id_str" : "24024778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684472236175036416\/yTKSwENk_normal.jpg",
      "id" : 24024778,
      "verified" : true
    }
  },
  "id" : 149957841208356865,
  "created_at" : "2011-12-22 21:01:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cathy fink",
      "screen_name" : "fink820",
      "indices" : [ 3, 11 ],
      "id_str" : "48887178",
      "id" : 48887178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 13, 23 ]
    }, {
      "text" : "40Dollars",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "40Dollars",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149948096678346752",
  "text" : "RT @fink820: #40Dollars means gas 4 a wk so that I can get to wor to earn #40Dollars for the next week. #40Dollars means ALOT to ALOT of ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40Dollars",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "40Dollars",
        "indices" : [ 61, 71 ]
      }, {
        "text" : "40Dollars",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149947262448050176",
    "text" : "#40Dollars means gas 4 a wk so that I can get to wor to earn #40Dollars for the next week. #40Dollars means ALOT to ALOT of us middle class",
    "id" : 149947262448050176,
    "created_at" : "2011-12-22 20:19:47 +0000",
    "user" : {
      "name" : "cathy fink",
      "screen_name" : "fink820",
      "protected" : false,
      "id_str" : "48887178",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 48887178,
      "verified" : false
    }
  },
  "id" : 149948096678346752,
  "created_at" : "2011-12-22 20:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 64, 73 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149936419870216192",
  "text" : "RT @jesseclee44: Obama just now: \"Keep sending your stories\" RT @mashable: White House Releases Infographic on #40dollars Campaign http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 47, 56 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/Rq2izLzM",
        "expanded_url" : "http:\/\/on.mash.to\/uwCK0R",
        "display_url" : "on.mash.to\/uwCK0R"
      } ]
    },
    "geo" : { },
    "id_str" : "149913390708559872",
    "text" : "Obama just now: \"Keep sending your stories\" RT @mashable: White House Releases Infographic on #40dollars Campaign http:\/\/t.co\/Rq2izLzM",
    "id" : 149913390708559872,
    "created_at" : "2011-12-22 18:05:12 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 149936419870216192,
  "created_at" : "2011-12-22 19:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayne Walling",
      "screen_name" : "MayorWalling",
      "indices" : [ 3, 16 ],
      "id_str" : "76699256",
      "id" : 76699256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149936289699987457",
  "text" : "RT @MayorWalling: This is the wrong time for major federal tax hike on workers. What does #40dollars a week mean to you? http:\/\/t.co\/LVy ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/LVy1o0kR",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/40dollars\/",
        "display_url" : "whitehouse.gov\/40dollars\/"
      } ]
    },
    "geo" : { },
    "id_str" : "149910829066756097",
    "text" : "This is the wrong time for major federal tax hike on workers. What does #40dollars a week mean to you? http:\/\/t.co\/LVy1o0kR",
    "id" : 149910829066756097,
    "created_at" : "2011-12-22 17:55:01 +0000",
    "user" : {
      "name" : "Dayne Walling",
      "screen_name" : "MayorWalling",
      "protected" : false,
      "id_str" : "76699256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1794492817\/Dayne_Walling02_normal.jpg",
      "id" : 76699256,
      "verified" : false
    }
  },
  "id" : 149936289699987457,
  "created_at" : "2011-12-22 19:36:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149935763952381952",
  "text" : "Obama: People in both parties agree\u2026has this place become so dysfunctional that even when people agree to things we can't do it? #40dollars",
  "id" : 149935763952381952,
  "created_at" : "2011-12-22 19:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enigma4ever",
      "screen_name" : "watergatesummer",
      "indices" : [ 3, 19 ],
      "id_str" : "48112717",
      "id" : 48112717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 21, 31 ]
    }, {
      "text" : "Books",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149917688809013248",
  "text" : "RT @watergatesummer: #40dollars helps my son keep studying since we can't afford college, it keeps him reading #Books",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Books",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149917425889058816",
    "text" : "#40dollars helps my son keep studying since we can't afford college, it keeps him reading #Books",
    "id" : 149917425889058816,
    "created_at" : "2011-12-22 18:21:14 +0000",
    "user" : {
      "name" : "enigma4ever",
      "screen_name" : "watergatesummer",
      "protected" : false,
      "id_str" : "48112717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1778779395\/18502599839_3M4bj_normal.jpg",
      "id" : 48112717,
      "verified" : false
    }
  },
  "id" : 149917688809013248,
  "created_at" : "2011-12-22 18:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reynaldo Mac\u00EDas",
      "screen_name" : "reynaldomacias",
      "indices" : [ 3, 18 ],
      "id_str" : "331242733",
      "id" : 331242733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149916236015345664",
  "text" : "RT @reynaldomacias: #40dollars or buying a full bag of groceries OR filling the car with gas to get to work. Without that $40, we'll be  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149916038191001601",
    "text" : "#40dollars or buying a full bag of groceries OR filling the car with gas to get to work. Without that $40, we'll be doing neither...",
    "id" : 149916038191001601,
    "created_at" : "2011-12-22 18:15:43 +0000",
    "user" : {
      "name" : "rey the jedi",
      "screen_name" : "bluphiv",
      "protected" : false,
      "id_str" : "20892381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797974077336002562\/1M5rlzBb_normal.jpg",
      "id" : 20892381,
      "verified" : false
    }
  },
  "id" : 149916236015345664,
  "created_at" : "2011-12-22 18:16:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149914155070132225",
  "text" : "RT @WHLive: Obama: This isn\u2019t a typical Democratic v. Republican issue...an overwhelming number of people in both parties agree",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149914087495704576",
    "text" : "Obama: This isn\u2019t a typical Democratic v. Republican issue...an overwhelming number of people in both parties agree",
    "id" : 149914087495704576,
    "created_at" : "2011-12-22 18:07:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 149914155070132225,
  "created_at" : "2011-12-22 18:08:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 107, 115 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 118, 127 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/endlN4yv",
      "expanded_url" : "http:\/\/whitehouse.gov",
      "display_url" : "whitehouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "149913375697154048",
  "text" : "Obama: I want to encourage everyone to keep sending us your stories at http:\/\/t.co\/endlN4yv & sharing them @Twitter & @Facebook. #40dollars",
  "id" : 149913375697154048,
  "created_at" : "2011-12-22 18:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149913314774880256",
  "text" : "RT @WHLive: Obama: We asked folks to tell us what it would be like to lose #40dollars in every paycheck\u2026the response has been overwhelming.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 63, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149913204640841729",
    "text" : "Obama: We asked folks to tell us what it would be like to lose #40dollars in every paycheck\u2026the response has been overwhelming.",
    "id" : 149913204640841729,
    "created_at" : "2011-12-22 18:04:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 149913314774880256,
  "created_at" : "2011-12-22 18:04:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149912997991694336",
  "text" : "Obama: Anyone who knows what it\u2019s like to stretch a budget knows that... #40dollars can make all the difference in the world.",
  "id" : 149912997991694336,
  "created_at" : "2011-12-22 18:03:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 123, 130 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "149912457060683776",
  "text" : "Happening now: President Obama speaks on the payroll tax cut & why #40dollars matters. Watch: http:\/\/t.co\/u95y7hhB Follow: @whlive",
  "id" : 149912457060683776,
  "created_at" : "2011-12-22 18:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 131, 138 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "149899841059827712",
  "text" : "Update: @ 1ET, President Obama will speak on the the payroll tax cut & why #40dollars matters. Watch: http:\/\/t.co\/u95y7hhB Follow: @Whlive",
  "id" : 149899841059827712,
  "created_at" : "2011-12-22 17:11:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 131, 138 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "149893001534124032",
  "text" : "Happening @ 12:15ET: Obama speaks on extending the payroll tax cut & why #40dollars matters. Watch: http:\/\/t.co\/u95y7hhB & follow: @WHLive",
  "id" : 149893001534124032,
  "created_at" : "2011-12-22 16:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsThatAreGood",
      "indices" : [ 101, 119 ]
    }, {
      "text" : "40dollars",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/x78Vc9rR",
      "expanded_url" : "http:\/\/1.usa.gov\/u17J58",
      "display_url" : "1.usa.gov\/u17J58"
    } ]
  },
  "geo" : { },
  "id_str" : "149892081702277121",
  "text" : "RT @jesseclee44: Infographic: Other things that have gotten 89 votes in Senate. http:\/\/t.co\/x78Vc9rR #ThingsThatAreGood #40dollars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsThatAreGood",
        "indices" : [ 84, 102 ]
      }, {
        "text" : "40dollars",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/x78Vc9rR",
        "expanded_url" : "http:\/\/1.usa.gov\/u17J58",
        "display_url" : "1.usa.gov\/u17J58"
      } ]
    },
    "geo" : { },
    "id_str" : "149889488041160705",
    "text" : "Infographic: Other things that have gotten 89 votes in Senate. http:\/\/t.co\/x78Vc9rR #ThingsThatAreGood #40dollars",
    "id" : 149889488041160705,
    "created_at" : "2011-12-22 16:30:13 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 149892081702277121,
  "created_at" : "2011-12-22 16:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/149891062402523136\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/EXrhpHff",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhSFIInCIAA-7XM.jpg",
      "id_str" : "149891062406717440",
      "id" : 149891062406717440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhSFIInCIAA-7XM.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 246
      }, {
        "h" : 1700,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 434
      }, {
        "h" : 1700,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EXrhpHff"
    } ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149891188034514945",
  "text" : "RT @macon44: I mean, seriously. SERIOUSLY. Researching child poverty ... Fighting AIDS & acid rain?! #40dollars http:\/\/t.co\/EXrhpHff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/149891062402523136\/photo\/1",
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/EXrhpHff",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AhSFIInCIAA-7XM.jpg",
        "id_str" : "149891062406717440",
        "id" : 149891062406717440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhSFIInCIAA-7XM.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 246
        }, {
          "h" : 1700,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 434
        }, {
          "h" : 1700,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/EXrhpHff"
      } ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149891062402523136",
    "text" : "I mean, seriously. SERIOUSLY. Researching child poverty ... Fighting AIDS & acid rain?! #40dollars http:\/\/t.co\/EXrhpHff",
    "id" : 149891062402523136,
    "created_at" : "2011-12-22 16:36:29 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 149891188034514945,
  "created_at" : "2011-12-22 16:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149881925388079104\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/OHs3F4mO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhR80SlCEAECUMo.jpg",
      "id_str" : "149881925392273409",
      "id" : 149881925392273409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhR80SlCEAECUMo.jpg",
      "sizes" : [ {
        "h" : 1548,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 246
      }, {
        "h" : 1548,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 434
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/OHs3F4mO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/OdKZo0VT",
      "expanded_url" : "http:\/\/1.usa.gov\/u17J58",
      "display_url" : "1.usa.gov\/u17J58"
    } ]
  },
  "geo" : { },
  "id_str" : "149881925388079104",
  "text" : "INFOGRAPHIC: Why can't the payroll tax cut get a vote? Full size: http:\/\/t.co\/OdKZo0VT Twit size: http:\/\/t.co\/OHs3F4mO",
  "id" : 149881925388079104,
  "created_at" : "2011-12-22 16:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 51, 60 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/yzyFnNFx",
      "expanded_url" : "http:\/\/lnkd.in\/--C62F",
      "display_url" : "lnkd.in\/--C62F"
    } ]
  },
  "geo" : { },
  "id_str" : "149880842808864768",
  "text" : "What does #40dollars mean to you? Share your story @LinkedIn: http:\/\/t.co\/yzyFnNFx",
  "id" : 149880842808864768,
  "created_at" : "2011-12-22 15:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "villaraigosa",
      "screen_name" : "villaraigosa",
      "indices" : [ 3, 16 ],
      "id_str" : "796800025749688322",
      "id" : 796800025749688322
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 127, 138 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149237000522825729\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/8LSUPOVE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
      "id_str" : "149237000527020032",
      "id" : 149237000527020032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/8LSUPOVE"
    } ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149877680479797248",
  "text" : "RT @villaraigosa: The House needs to pass the Senate's payroll tax cut! What does #40dollars mean to you? http:\/\/t.co\/8LSUPOVE @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 109, 120 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149237000522825729\/photo\/1",
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/8LSUPOVE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
        "id_str" : "149237000527020032",
        "id" : 149237000527020032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 615
        } ],
        "display_url" : "pic.twitter.com\/8LSUPOVE"
      } ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149718540113551361",
    "text" : "The House needs to pass the Senate's payroll tax cut! What does #40dollars mean to you? http:\/\/t.co\/8LSUPOVE @whitehouse",
    "id" : 149718540113551361,
    "created_at" : "2011-12-22 05:10:56 +0000",
    "user" : {
      "name" : "Mayor of Los Angeles",
      "screen_name" : "MayorOfLA",
      "protected" : false,
      "id_str" : "17070113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758035630441889792\/JPfM_c3Z_normal.jpg",
      "id" : 17070113,
      "verified" : true
    }
  },
  "id" : 149877680479797248,
  "created_at" : "2011-12-22 15:43:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149867925413699584\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/CpGBZww3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhRwFYnCIAEwk9I.jpg",
      "id_str" : "149867925417893889",
      "id" : 149867925417893889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhRwFYnCIAEwk9I.jpg",
      "sizes" : [ {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 476
      } ],
      "display_url" : "pic.twitter.com\/CpGBZww3"
    } ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/h1eFw9Ea",
      "expanded_url" : "http:\/\/1.usa.gov\/seNOMY",
      "display_url" : "1.usa.gov\/seNOMY"
    } ]
  },
  "geo" : { },
  "id_str" : "149867925413699584",
  "text" : "See what #40dollars means to Americans across the country. Check out this map: http:\/\/t.co\/h1eFw9Ea http:\/\/t.co\/CpGBZww3",
  "id" : 149867925413699584,
  "created_at" : "2011-12-22 15:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Intermill",
      "screen_name" : "mintermill",
      "indices" : [ 3, 14 ],
      "id_str" : "14898387",
      "id" : 14898387
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Star Tribune",
      "screen_name" : "StarTribune",
      "indices" : [ 121, 133 ],
      "id_str" : "17348525",
      "id" : 17348525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/OJJ3hQW9",
      "expanded_url" : "http:\/\/www.startribune.com\/opinion\/editorials\/136034568.html",
      "display_url" : "startribune.com\/opinion\/editor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149842617943855104",
  "text" : "RT @mintermill: The public is with the @whitehouse. Editorial: House GOP fails American workers http:\/\/t.co\/OJJ3hQW9 via @startribune #4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 23, 34 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Star Tribune",
        "screen_name" : "StarTribune",
        "indices" : [ 105, 117 ],
        "id_str" : "17348525",
        "id" : 17348525
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/OJJ3hQW9",
        "expanded_url" : "http:\/\/www.startribune.com\/opinion\/editorials\/136034568.html",
        "display_url" : "startribune.com\/opinion\/editor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "149841972595658752",
    "text" : "The public is with the @whitehouse. Editorial: House GOP fails American workers http:\/\/t.co\/OJJ3hQW9 via @startribune #40dollars",
    "id" : 149841972595658752,
    "created_at" : "2011-12-22 13:21:24 +0000",
    "user" : {
      "name" : "Micah Intermill",
      "screen_name" : "mintermill",
      "protected" : false,
      "id_str" : "14898387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469450227200430080\/ql_ImVcz_normal.jpeg",
      "id" : 14898387,
      "verified" : false
    }
  },
  "id" : 149842617943855104,
  "created_at" : "2011-12-22 13:23:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolfgang Cerniglia",
      "screen_name" : "salukiscjc",
      "indices" : [ 3, 14 ],
      "id_str" : "299970230",
      "id" : 299970230
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149736898607321088",
  "text" : "RT @salukiscjc: @whitehouse #40dollars is more than I made during my entire shift at work tonight. Hard times... could use it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149736791249924096",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is more than I made during my entire shift at work tonight. Hard times... could use it!",
    "id" : 149736791249924096,
    "created_at" : "2011-12-22 06:23:27 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Wolfgang Cerniglia",
      "screen_name" : "salukiscjc",
      "protected" : false,
      "id_str" : "299970230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788747828474605570\/Do0ziEZV_normal.jpg",
      "id" : 299970230,
      "verified" : false
    }
  },
  "id" : 149736898607321088,
  "created_at" : "2011-12-22 06:23:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martha Carter",
      "screen_name" : "FamilyCareWV",
      "indices" : [ 3, 16 ],
      "id_str" : "187054424",
      "id" : 187054424
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149736409861849088",
  "text" : "RT @FamilyCareWV: @whitehouse #40dollars is a doctor visit and medication refill for an uninsured patient at our Community Health Center",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149735832260059136",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is a doctor visit and medication refill for an uninsured patient at our Community Health Center",
    "id" : 149735832260059136,
    "created_at" : "2011-12-22 06:19:39 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Martha Carter",
      "screen_name" : "FamilyCareWV",
      "protected" : false,
      "id_str" : "187054424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601819589052272640\/tX6kZG54_normal.jpg",
      "id" : 187054424,
      "verified" : false
    }
  },
  "id" : 149736409861849088,
  "created_at" : "2011-12-22 06:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "invisiblebob08",
      "screen_name" : "invisiblebob08",
      "indices" : [ 3, 18 ],
      "id_str" : "15094053",
      "id" : 15094053
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149729973652037632",
  "text" : "RT @invisiblebob08: @whitehouse I'm a college student who just got my first raise ever. Please don't let the pay roll tax take that away ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149729793468923904",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I'm a college student who just got my first raise ever. Please don't let the pay roll tax take that away from me. #40dollars",
    "id" : 149729793468923904,
    "created_at" : "2011-12-22 05:55:39 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "invisiblebob08",
      "screen_name" : "invisiblebob08",
      "protected" : false,
      "id_str" : "15094053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1651748832\/cow_tongue_normal.jpg",
      "id" : 15094053,
      "verified" : false
    }
  },
  "id" : 149729973652037632,
  "created_at" : "2011-12-22 05:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Topher",
      "screen_name" : "OtakuJedi",
      "indices" : [ 3, 13 ],
      "id_str" : "28373135",
      "id" : 28373135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149728926967660544",
  "text" : "RT @OtakuJedi: #40dollars is extra money americans can put towards the american dream",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149727185501036545",
    "text" : "#40dollars is extra money americans can put towards the american dream",
    "id" : 149727185501036545,
    "created_at" : "2011-12-22 05:45:17 +0000",
    "user" : {
      "name" : "Topher",
      "screen_name" : "OtakuJedi",
      "protected" : false,
      "id_str" : "28373135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789991134403579904\/KDZLBoS__normal.jpg",
      "id" : 28373135,
      "verified" : false
    }
  },
  "id" : 149728926967660544,
  "created_at" : "2011-12-22 05:52:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Sam Abe",
      "screen_name" : "player2bnamed",
      "indices" : [ 3, 17 ],
      "id_str" : "58010665",
      "id" : 58010665
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149695285302525952",
  "text" : "RT @player2bnamed: @whitehouse #40dollars is a tank of gas for an 11-year old car, a careful grocery trip or one of our prescriptions le ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149237000522825729",
    "geo" : { },
    "id_str" : "149693964931444737",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is a tank of gas for an 11-year old car, a careful grocery trip or one of our prescriptions less $5.",
    "id" : 149693964931444737,
    "in_reply_to_status_id" : 149237000522825729,
    "created_at" : "2011-12-22 03:33:17 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Susan Sam Abe",
      "screen_name" : "player2bnamed",
      "protected" : false,
      "id_str" : "58010665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751506994620620800\/ZptBoL8D_normal.jpg",
      "id" : 58010665,
      "verified" : false
    }
  },
  "id" : 149695285302525952,
  "created_at" : "2011-12-22 03:38:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Local 8 News",
      "screen_name" : "wvlt",
      "indices" : [ 3, 8 ],
      "id_str" : "16455997",
      "id" : 16455997
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149694083080790016",
  "text" : "RT @wvlt: The @whitehouse is pushing Congress to pass a payroll tax extension, asking people what #40dollars means to them. What does it ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149692800835928064",
    "text" : "The @whitehouse is pushing Congress to pass a payroll tax extension, asking people what #40dollars means to them. What does it mean to you?",
    "id" : 149692800835928064,
    "created_at" : "2011-12-22 03:28:39 +0000",
    "user" : {
      "name" : "Local 8 News",
      "screen_name" : "wvlt",
      "protected" : false,
      "id_str" : "16455997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793202704080338944\/UcL2Dy-I_normal.jpg",
      "id" : 16455997,
      "verified" : true
    }
  },
  "id" : 149694083080790016,
  "created_at" : "2011-12-22 03:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149649591401332736",
  "text" : "Everyone should see what #40dollars means to folks: groceries, daycare, gas, copays. Keep it going. I'll talk abt this tmrw @ 12:15ET. \u2013bo",
  "id" : 149649591401332736,
  "created_at" : "2011-12-22 00:36:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wayne Langer",
      "screen_name" : "WayneLanger2",
      "indices" : [ 3, 16 ],
      "id_str" : "419790982",
      "id" : 419790982
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149639512123908096",
  "text" : "RT @WayneLanger2: @whitehouse $40 a week is a big deal, my wife & I are going to school full time and need this income to survive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149639002406924289",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse $40 a week is a big deal, my wife & I are going to school full time and need this income to survive.",
    "id" : 149639002406924289,
    "created_at" : "2011-12-21 23:54:52 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Wayne Langer",
      "screen_name" : "WayneLanger2",
      "protected" : false,
      "id_str" : "419790982",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_2_normal.png",
      "id" : 419790982,
      "verified" : false
    }
  },
  "id" : 149639512123908096,
  "created_at" : "2011-12-21 23:56:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anton J. Gunn",
      "screen_name" : "AntonJGunn",
      "indices" : [ 3, 14 ],
      "id_str" : "178071411",
      "id" : 178071411
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149636467239550977",
  "text" : "RT @AntonJGunn: @whitehouse #40dollars gets me enough gas to ensure that I can make that 3 hour drive back home every week to be w\/ my w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149636010249162752",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars gets me enough gas to ensure that I can make that 3 hour drive back home every week to be w\/ my wife & daughter.",
    "id" : 149636010249162752,
    "created_at" : "2011-12-21 23:42:59 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Anton J. Gunn",
      "screen_name" : "AntonJGunn",
      "protected" : false,
      "id_str" : "178071411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774083507375046657\/jNWSxhyC_normal.jpg",
      "id" : 178071411,
      "verified" : false
    }
  },
  "id" : 149636467239550977,
  "created_at" : "2011-12-21 23:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goodthingz08",
      "screen_name" : "goodthingz08",
      "indices" : [ 3, 16 ],
      "id_str" : "17141566",
      "id" : 17141566
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149635693893783552",
  "text" : "RT @goodthingz08: @whitehouse #40Dollars would buy one of my inhalers or my nephew two boxes of diapers...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40Dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149634860720455680",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40Dollars would buy one of my inhalers or my nephew two boxes of diapers...",
    "id" : 149634860720455680,
    "created_at" : "2011-12-21 23:38:25 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "goodthingz08",
      "screen_name" : "goodthingz08",
      "protected" : false,
      "id_str" : "17141566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593595641827201024\/YU1_T9P3_normal.jpg",
      "id" : 17141566,
      "verified" : false
    }
  },
  "id" : 149635693893783552,
  "created_at" : "2011-12-21 23:41:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 3, 11 ],
      "id_str" : "17814938",
      "id" : 17814938
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/ezCmFwGH",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/what-does-40dollars-mean-to-you",
      "display_url" : "storify.com\/whitehouse\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149631366965895168",
  "text" : "RT @Storify: Tell the @whitehouse what #40dollars means to you.  http:\/\/t.co\/ezCmFwGH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/ezCmFwGH",
        "expanded_url" : "http:\/\/storify.com\/whitehouse\/what-does-40dollars-mean-to-you",
        "display_url" : "storify.com\/whitehouse\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "149630905747652608",
    "text" : "Tell the @whitehouse what #40dollars means to you.  http:\/\/t.co\/ezCmFwGH",
    "id" : 149630905747652608,
    "created_at" : "2011-12-21 23:22:42 +0000",
    "user" : {
      "name" : "Storify",
      "screen_name" : "Storify",
      "protected" : false,
      "id_str" : "17814938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519538829858852865\/Rw_sIo6T_normal.png",
      "id" : 17814938,
      "verified" : true
    }
  },
  "id" : 149631366965895168,
  "created_at" : "2011-12-21 23:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellibelli",
      "screen_name" : "mrskelligurl",
      "indices" : [ 3, 16 ],
      "id_str" : "38957645",
      "id" : 38957645
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149630613815705601",
  "text" : "RT @mrskelligurl: @whitehouse #40dollars gets me one week of daycare so that I can complete my degree,3 days of my husbands gas fund (work",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149630207039504384",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars gets me one week of daycare so that I can complete my degree,3 days of my husbands gas fund (work",
    "id" : 149630207039504384,
    "created_at" : "2011-12-21 23:19:56 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kellibelli",
      "screen_name" : "mrskelligurl",
      "protected" : false,
      "id_str" : "38957645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1526805998\/206660_1894014422958_1019472329_2237584_4013450_n_normal.jpg",
      "id" : 38957645,
      "verified" : false
    }
  },
  "id" : 149630613815705601,
  "created_at" : "2011-12-21 23:21:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bourgeoisfem",
      "screen_name" : "bourgeoisfem",
      "indices" : [ 3, 16 ],
      "id_str" : "32782028",
      "id" : 32782028
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149630574296969216",
  "text" : "RT @bourgeoisfem: @whitehouse #40dollars is what I pay my dentist monthly to pay off a $1000 bill.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149618124981927936",
    "geo" : { },
    "id_str" : "149630406726139904",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is what I pay my dentist monthly to pay off a $1000 bill.",
    "id" : 149630406726139904,
    "in_reply_to_status_id" : 149618124981927936,
    "created_at" : "2011-12-21 23:20:43 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "bourgeoisfem",
      "screen_name" : "bourgeoisfem",
      "protected" : false,
      "id_str" : "32782028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419511059758592000\/L6lAkxjf_normal.jpeg",
      "id" : 32782028,
      "verified" : false
    }
  },
  "id" : 149630574296969216,
  "created_at" : "2011-12-21 23:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149618124981927936",
  "text" : "10 days: 6 hours: 28 minutes. If the House doesn't act, that's when middle class taxes will go up. What does #40dollars mean to you?",
  "id" : 149618124981927936,
  "created_at" : "2011-12-21 22:31:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149609341719298049",
  "text" : "RT @GovernorOMalley: If you have time today, read the #40dollars hashtag & let folks know what $40 means to you & your family.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149522913194819584",
    "text" : "If you have time today, read the #40dollars hashtag & let folks know what $40 means to you & your family.",
    "id" : 149522913194819584,
    "created_at" : "2011-12-21 16:13:35 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 149609341719298049,
  "created_at" : "2011-12-21 21:57:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/AOIARhdT",
      "expanded_url" : "http:\/\/ow.ly\/872NR",
      "display_url" : "ow.ly\/872NR"
    } ]
  },
  "geo" : { },
  "id_str" : "149606833743609858",
  "text" : "President Obama announces historic new standards to protect Americans & the environment from mercury pollution. Watch: http:\/\/t.co\/AOIARhdT",
  "id" : 149606833743609858,
  "created_at" : "2011-12-21 21:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candace Perrone",
      "screen_name" : "CandyPerrone",
      "indices" : [ 3, 16 ],
      "id_str" : "72921924",
      "id" : 72921924
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149600486859882496",
  "text" : "RT @CandyPerrone: @whitehouse #40dollars means not making the $270 copay for my son's health insurance that he needs! Or not having dinn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149599972692721664",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars means not making the $270 copay for my son's health insurance that he needs! Or not having dinner on the table...",
    "id" : 149599972692721664,
    "created_at" : "2011-12-21 21:19:47 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Candace Perrone",
      "screen_name" : "CandyPerrone",
      "protected" : false,
      "id_str" : "72921924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238422025\/profile_pic_normal.jpg",
      "id" : 72921924,
      "verified" : false
    }
  },
  "id" : 149600486859882496,
  "created_at" : "2011-12-21 21:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149598796949630976",
  "text" : "RT @ks44: Thanks for joining #WHChat w\/ Brian Deese. Have you seen his White Board video on the payroll tax cut? Check out here: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 19, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/QfyT7IMO",
        "expanded_url" : "http:\/\/ow.ly\/870CC",
        "display_url" : "ow.ly\/870CC"
      } ]
    },
    "geo" : { },
    "id_str" : "149598610139529216",
    "text" : "Thanks for joining #WHChat w\/ Brian Deese. Have you seen his White Board video on the payroll tax cut? Check out here: http:\/\/t.co\/QfyT7IMO",
    "id" : 149598610139529216,
    "created_at" : "2011-12-21 21:14:22 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 149598796949630976,
  "created_at" : "2011-12-21 21:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Michaila Nate",
      "screen_name" : "m_nate",
      "indices" : [ 13, 20 ],
      "id_str" : "291479117",
      "id" : 291479117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149593710705913856",
  "text" : "RT @WHLive: .@m_nate #1 issue small biz face is lack of demand, i.e. customers. Having 160m Americans w\/less to spend hurts small biz &  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michaila Nate",
        "screen_name" : "m_nate",
        "indices" : [ 1, 8 ],
        "id_str" : "291479117",
        "id" : 291479117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149593194064117760",
    "text" : ".@m_nate #1 issue small biz face is lack of demand, i.e. customers. Having 160m Americans w\/less to spend hurts small biz & economy #WHChat",
    "id" : 149593194064117760,
    "created_at" : "2011-12-21 20:52:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 149593710705913856,
  "created_at" : "2011-12-21 20:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Oliver Francies",
      "screen_name" : "terpanese",
      "indices" : [ 13, 23 ],
      "id_str" : "289044273",
      "id" : 289044273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149590308152295426",
  "text" : "RT @WHLive: .@terpanese POTUS called for yr-long ext 100+ days ago. But w\/ 10 days till taxes go up, bipart 2-mo ext is only viable opti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oliver Francies",
        "screen_name" : "terpanese",
        "indices" : [ 1, 11 ],
        "id_str" : "289044273",
        "id" : 289044273
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149590144184365056",
    "text" : ".@terpanese POTUS called for yr-long ext 100+ days ago. But w\/ 10 days till taxes go up, bipart 2-mo ext is only viable option. #WHChat",
    "id" : 149590144184365056,
    "created_at" : "2011-12-21 20:40:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 149590308152295426,
  "created_at" : "2011-12-21 20:41:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Francies",
      "screen_name" : "terpanese",
      "indices" : [ 3, 13 ],
      "id_str" : "289044273",
      "id" : 289044273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149590296261443584",
  "text" : "RT @terpanese: Why is president opposed for yearlong extension And why won't prez offer long term plan of his own #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149586149592141824",
    "text" : "Why is president opposed for yearlong extension And why won't prez offer long term plan of his own #WHChat",
    "id" : 149586149592141824,
    "created_at" : "2011-12-21 20:24:51 +0000",
    "user" : {
      "name" : "Oliver Francies",
      "screen_name" : "terpanese",
      "protected" : false,
      "id_str" : "289044273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3527453652\/c84fca9323a9a25360d80d02dfdd1b2e_normal.jpeg",
      "id" : 289044273,
      "verified" : false
    }
  },
  "id" : 149590296261443584,
  "created_at" : "2011-12-21 20:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149589077690290176",
  "text" : "RT @WHLive: Hi all, this is Brian Deese. I'm here and ready to take your questions on #40Dollars and the payroll tax cut. Ask with #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40Dollars",
        "indices" : [ 74, 84 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149588877328396289",
    "text" : "Hi all, this is Brian Deese. I'm here and ready to take your questions on #40Dollars and the payroll tax cut. Ask with #WHChat",
    "id" : 149588877328396289,
    "created_at" : "2011-12-21 20:35:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 149589077690290176,
  "created_at" : "2011-12-21 20:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/VqM8wH4a",
      "expanded_url" : "http:\/\/ow.ly\/86X5R",
      "display_url" : "ow.ly\/86X5R"
    } ]
  },
  "geo" : { },
  "id_str" : "149585127389937666",
  "text" : "More stories from everywhere: What #40dollars means to you: http:\/\/t.co\/VqM8wH4a",
  "id" : 149585127389937666,
  "created_at" : "2011-12-21 20:20:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Groehler",
      "screen_name" : "KellyGroehler",
      "indices" : [ 3, 17 ],
      "id_str" : "15172248",
      "id" : 15172248
    }, {
      "name" : "Best Buy",
      "screen_name" : "BestBuy",
      "indices" : [ 65, 73 ],
      "id_str" : "17475575",
      "id" : 17475575
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 112, 122 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Rk35AZPv",
      "expanded_url" : "http:\/\/instagr.am\/p\/ahZ2k\/",
      "display_url" : "instagr.am\/p\/ahZ2k\/"
    } ]
  },
  "geo" : { },
  "id_str" : "149581473521991680",
  "text" : "RT @KellyGroehler: Thank you, Mr. President, for shopping at our @BestBuy store today! http:\/\/t.co\/Rk35AZPv via @instagram",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Best Buy",
        "screen_name" : "BestBuy",
        "indices" : [ 46, 54 ],
        "id_str" : "17475575",
        "id" : 17475575
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 93, 103 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/Rk35AZPv",
        "expanded_url" : "http:\/\/instagr.am\/p\/ahZ2k\/",
        "display_url" : "instagr.am\/p\/ahZ2k\/"
      } ]
    },
    "geo" : { },
    "id_str" : "149571319418204160",
    "text" : "Thank you, Mr. President, for shopping at our @BestBuy store today! http:\/\/t.co\/Rk35AZPv via @instagram",
    "id" : 149571319418204160,
    "created_at" : "2011-12-21 19:25:56 +0000",
    "user" : {
      "name" : "Kelly Groehler",
      "screen_name" : "KellyGroehler",
      "protected" : false,
      "id_str" : "15172248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700449852660928512\/qH-9qnAm_normal.jpg",
      "id" : 15172248,
      "verified" : false
    }
  },
  "id" : 149581473521991680,
  "created_at" : "2011-12-21 20:06:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 52, 59 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149581106302287875",
  "text" : "Starting @ 3:30ET: WH economist Brian Deese will be @WHLive to answer ?s on the payroll tax cut & why #40dollars matters. Ask with #WHChat",
  "id" : 149581106302287875,
  "created_at" : "2011-12-21 20:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Harvey \uD83D\uDCCE",
      "screen_name" : "AdamInCLE",
      "indices" : [ 3, 13 ],
      "id_str" : "20485510",
      "id" : 20485510
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149579366064586752",
  "text" : "RT @AdamInCLE: @whitehouse #40dollars less means defaulting on my mortgage so I can feed my son.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149579044856414209",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars less means defaulting on my mortgage so I can feed my son.",
    "id" : 149579044856414209,
    "created_at" : "2011-12-21 19:56:37 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Adam Harvey \uD83D\uDCCE",
      "screen_name" : "AdamInCLE",
      "protected" : false,
      "id_str" : "20485510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788921793956417536\/gJ_YXkqX_normal.jpg",
      "id" : 20485510,
      "verified" : false
    }
  },
  "id" : 149579366064586752,
  "created_at" : "2011-12-21 19:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shari Leonelli",
      "screen_name" : "sharileon",
      "indices" : [ 3, 13 ],
      "id_str" : "285323503",
      "id" : 285323503
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149557485278208000",
  "text" : "RT @sharileon: #40dollars means milk, bread, eggs, cereal, apples, cheese, juice off a grocery list. Just do the right thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149557093601513472",
    "text" : "#40dollars means milk, bread, eggs, cereal, apples, cheese, juice off a grocery list. Just do the right thing.",
    "id" : 149557093601513472,
    "created_at" : "2011-12-21 18:29:24 +0000",
    "user" : {
      "name" : "Shari Leonelli",
      "screen_name" : "sharileon",
      "protected" : false,
      "id_str" : "285323503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1476450033\/image_normal.jpg",
      "id" : 285323503,
      "verified" : false
    }
  },
  "id" : 149557485278208000,
  "created_at" : "2011-12-21 18:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELAMAR",
      "screen_name" : "ElleLamar",
      "indices" : [ 3, 13 ],
      "id_str" : "16742973",
      "id" : 16742973
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 14, 23 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "POTUS",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149551145331867648",
  "text" : "RT @ElleLamar @PressSec Jay is reading off #40Dollars tweets & FB posts. Love that the our voice is important to #POTUS!",
  "id" : 149551145331867648,
  "created_at" : "2011-12-21 18:05:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 1, 7 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149540056191864832",
  "text" : ".@msnbc's @MikViq \"You click on \u201C#40dollars\u201D you can't keep up. It's scrolling so fast. Hundreds of people every hour are pitching in here.\"",
  "id" : 149540056191864832,
  "created_at" : "2011-12-21 17:21:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 1, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149538511844933632",
  "text" : "\"#40dollars means the world to me. It's the equivalent of 5 hrs work or feeding my family for 3 nights\" -TK, Gaylord, MI",
  "id" : 149538511844933632,
  "created_at" : "2011-12-21 17:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 0, 12 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "KRenner",
      "screen_name" : "KRenner2",
      "indices" : [ 13, 22 ],
      "id_str" : "114259310",
      "id" : 114259310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 82 ],
      "url" : "https:\/\/t.co\/rniVZJwt",
      "expanded_url" : "https:\/\/twitter.com\/#!\/OMBPress\/status\/149517004477435904",
      "display_url" : "twitter.com\/#!\/OMBPress\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "149535074155638785",
  "geo" : { },
  "id_str" : "149537147576254464",
  "in_reply_to_user_id" : 113436175,
  "text" : "@jesseclee44 @KRenner2 here's some more info on the SS issue https:\/\/t.co\/rniVZJwt #40dollars",
  "id" : 149537147576254464,
  "in_reply_to_status_id" : 149535074155638785,
  "created_at" : "2011-12-21 17:10:08 +0000",
  "in_reply_to_screen_name" : "jesseclee44",
  "in_reply_to_user_id_str" : "113436175",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dria Fearn",
      "screen_name" : "driafearn",
      "indices" : [ 3, 13 ],
      "id_str" : "164779229",
      "id" : 164779229
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149529512441430018",
  "text" : "RT @driafearn: @whitehouse #40dollars pays the monthly copays for the prescription drugs that I need to be healthy and get to work.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149528094892507136",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars pays the monthly copays for the prescription drugs that I need to be healthy and get to work.",
    "id" : 149528094892507136,
    "created_at" : "2011-12-21 16:34:10 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Dria Fearn",
      "screen_name" : "driafearn",
      "protected" : false,
      "id_str" : "164779229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1147056359\/IMG_0761_normal.jpg",
      "id" : 164779229,
      "verified" : false
    }
  },
  "id" : 149529512441430018,
  "created_at" : "2011-12-21 16:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa",
      "screen_name" : "lisa_speaks",
      "indices" : [ 3, 15 ],
      "id_str" : "20750608",
      "id" : 20750608
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "FirstWorldProblem",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149523138437324800",
  "text" : "RT @lisa_speaks: @whitehouse #40Dollars helps me pay for my gym membership. Its def a #FirstWorldProblem but it allows me to swim everyd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40Dollars",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "FirstWorldProblem",
        "indices" : [ 69, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149522215224881152",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40Dollars helps me pay for my gym membership. Its def a #FirstWorldProblem but it allows me to swim everyday + stay healthy.",
    "id" : 149522215224881152,
    "created_at" : "2011-12-21 16:10:48 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "lisa",
      "screen_name" : "lisa_speaks",
      "protected" : false,
      "id_str" : "20750608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455884691661676545\/JwCooknP_normal.jpeg",
      "id" : 20750608,
      "verified" : false
    }
  },
  "id" : 149523138437324800,
  "created_at" : "2011-12-21 16:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149520387015847936",
  "text" : "RT @WHLive: Office Hours @ 3:30ET today: Brian Deese answers your Qs on the payroll tax cut extension & why #40dollars matters. Ask with ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 96, 106 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149519860530020352",
    "text" : "Office Hours @ 3:30ET today: Brian Deese answers your Qs on the payroll tax cut extension & why #40dollars matters. Ask with #WHChat",
    "id" : 149519860530020352,
    "created_at" : "2011-12-21 16:01:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 149520387015847936,
  "created_at" : "2011-12-21 16:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia Elise",
      "screen_name" : "Elise8305",
      "indices" : [ 3, 13 ],
      "id_str" : "25071525",
      "id" : 25071525
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "80dollars",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "40dollars",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149519460225658881",
  "text" : "RT @Elise8305: @whitehouse Since many ppl are paid 2xs a month #40dollars a paycheck = #80dollars a month! #40dollars is \"almost\" a full ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twittergadget.com\" rel=\"nofollow\"\u003EtGadget\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 48, 58 ]
      }, {
        "text" : "80dollars",
        "indices" : [ 72, 82 ]
      }, {
        "text" : "40dollars",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149518858024271872",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Since many ppl are paid 2xs a month #40dollars a paycheck = #80dollars a month! #40dollars is \"almost\" a full tank of gas 4 me.",
    "id" : 149518858024271872,
    "created_at" : "2011-12-21 15:57:28 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kia Elise",
      "screen_name" : "Elise8305",
      "protected" : false,
      "id_str" : "25071525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485887249821609985\/yUud4ZX6_normal.jpeg",
      "id" : 25071525,
      "verified" : false
    }
  },
  "id" : 149519460225658881,
  "created_at" : "2011-12-21 15:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vance White",
      "screen_name" : "VanceMeister",
      "indices" : [ 0, 13 ],
      "id_str" : "69870533",
      "id" : 69870533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/uNfNUlYH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yB1DdBP3FH0",
      "display_url" : "youtube.com\/watch?v=yB1DdB\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "149517848635645954",
  "geo" : { },
  "id_str" : "149518678998790144",
  "in_reply_to_user_id" : 69870533,
  "text" : "@VanceMeister here's a good explainer video http:\/\/t.co\/uNfNUlYH",
  "id" : 149518678998790144,
  "in_reply_to_status_id" : 149517848635645954,
  "created_at" : "2011-12-21 15:56:45 +0000",
  "in_reply_to_screen_name" : "VanceMeister",
  "in_reply_to_user_id_str" : "69870533",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tristan Moody",
      "screen_name" : "SWGlassPit",
      "indices" : [ 3, 14 ],
      "id_str" : "22102861",
      "id" : 22102861
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 16, 31 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149517282421383168",
  "text" : "RT @SWGlassPit: @whitehouseostp in grad school, every dollar counts. #40dollars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 0, 15 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 53, 63 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149511438623453185",
    "geo" : { },
    "id_str" : "149513212881145856",
    "in_reply_to_user_id" : 33998183,
    "text" : "@whitehouseostp in grad school, every dollar counts. #40dollars",
    "id" : 149513212881145856,
    "in_reply_to_status_id" : 149511438623453185,
    "created_at" : "2011-12-21 15:35:02 +0000",
    "in_reply_to_screen_name" : "whitehouseostp",
    "in_reply_to_user_id_str" : "33998183",
    "user" : {
      "name" : "Tristan Moody",
      "screen_name" : "SWGlassPit",
      "protected" : false,
      "id_str" : "22102861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1436028186\/100_6696_small_normal.JPG",
      "id" : 22102861,
      "verified" : false
    }
  },
  "id" : 149517282421383168,
  "created_at" : "2011-12-21 15:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel",
      "screen_name" : "bardandbarker",
      "indices" : [ 3, 17 ],
      "id_str" : "55657302",
      "id" : 55657302
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 24, 34 ]
    }, {
      "text" : "40dollars",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149516850001219585",
  "text" : "RT @bardandbarker: This #40dollars hastag discussion from @whitehouse is v. interesting. #40dollars for me is 2 dr appts, or nearly 2 mo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 39, 50 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 5, 15 ]
      }, {
        "text" : "40dollars",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149513852650917888",
    "text" : "This #40dollars hastag discussion from @whitehouse is v. interesting. #40dollars for me is 2 dr appts, or nearly 2 mos of vet care for Amy.",
    "id" : 149513852650917888,
    "created_at" : "2011-12-21 15:37:34 +0000",
    "user" : {
      "name" : "Rachel",
      "screen_name" : "bardandbarker",
      "protected" : false,
      "id_str" : "55657302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724751988571910145\/NLHqdPcG_normal.jpg",
      "id" : 55657302,
      "verified" : false
    }
  },
  "id" : 149516850001219585,
  "created_at" : "2011-12-21 15:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley E. Sweeney",
      "screen_name" : "AshleyESweeney",
      "indices" : [ 3, 18 ],
      "id_str" : "241291756",
      "id" : 241291756
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149514091705278466",
  "text" : "RT @AshleyESweeney: @whitehouse #40dollars means driving from Chicago to Battle Creek, Michigan to see my family this Christmas.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149513149295497218",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars means driving from Chicago to Battle Creek, Michigan to see my family this Christmas.",
    "id" : 149513149295497218,
    "created_at" : "2011-12-21 15:34:47 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Ashley E. Sweeney",
      "screen_name" : "AshleyESweeney",
      "protected" : false,
      "id_str" : "241291756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648874097821282304\/2byHN4ye_normal.jpg",
      "id" : 241291756,
      "verified" : false
    }
  },
  "id" : 149514091705278466,
  "created_at" : "2011-12-21 15:38:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/rdU024hf",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/21\/what-40dollars-means-americans",
      "display_url" : "whitehouse.gov\/blog\/2011\/12\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "149513195915190274",
  "geo" : { },
  "id_str" : "149513989372649472",
  "in_reply_to_user_id" : 193484414,
  "text" : "@_SealedWitAKiss here's why:  http:\/\/t.co\/rdU024hf",
  "id" : 149513989372649472,
  "in_reply_to_status_id" : 149513195915190274,
  "created_at" : "2011-12-21 15:38:07 +0000",
  "in_reply_to_screen_name" : "Azgee__",
  "in_reply_to_user_id_str" : "193484414",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MDJ Online",
      "screen_name" : "mdjonline",
      "indices" : [ 3, 13 ],
      "id_str" : "85329284",
      "id" : 85329284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149513251489722368",
  "text" : "RT @mdjonline: What would an extra #40dollars per paycheck mean to you?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149512957288652800",
    "text" : "What would an extra #40dollars per paycheck mean to you?",
    "id" : 149512957288652800,
    "created_at" : "2011-12-21 15:34:01 +0000",
    "user" : {
      "name" : "MDJ Online",
      "screen_name" : "mdjonline",
      "protected" : false,
      "id_str" : "85329284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687638565619154945\/E1EmwjMi_normal.jpg",
      "id" : 85329284,
      "verified" : false
    }
  },
  "id" : 149513251489722368,
  "created_at" : "2011-12-21 15:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    }, {
      "text" : "STEM",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149512000806985728",
  "text" : "RT @whitehouseostp: How would #40dollars less in each paycheck affect you or your family members' ability to study\/work in #STEM fields? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 10, 20 ]
      }, {
        "text" : "STEM",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149511438623453185",
    "text" : "How would #40dollars less in each paycheck affect you or your family members' ability to study\/work in #STEM fields? Will RT best thoughts!",
    "id" : 149511438623453185,
    "created_at" : "2011-12-21 15:27:59 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 149512000806985728,
  "created_at" : "2011-12-21 15:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149510304294895617",
  "text" : "Amazing to read how #40dollars less in each paycheck would affect middle-class Americans. Check it out & RT best ones (we certainly are!).",
  "id" : 149510304294895617,
  "created_at" : "2011-12-21 15:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149508981520465920",
  "text" : "RT @OMBPress: For most family budgets, #40dollars means a lot. W\/o payroll extension, workers would lose that much a paycheck. What does ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 25, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149508611679326208",
    "text" : "For most family budgets, #40dollars means a lot. W\/o payroll extension, workers would lose that much a paycheck. What does it mean for u?",
    "id" : 149508611679326208,
    "created_at" : "2011-12-21 15:16:45 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 149508981520465920,
  "created_at" : "2011-12-21 15:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Futurist",
      "screen_name" : "GirlFuturist",
      "indices" : [ 3, 16 ],
      "id_str" : "18471312",
      "id" : 18471312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 24, 28 ]
    }, {
      "text" : "payrolltax",
      "indices" : [ 48, 59 ]
    }, {
      "text" : "GOP",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149508715307995136",
  "text" : "RT @GirlFuturist: House #GOP continues to block #payrolltax cut for 160 million Americans. Tell the #GOP how $40 will help your family.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOP",
        "indices" : [ 6, 10 ]
      }, {
        "text" : "payrolltax",
        "indices" : [ 30, 41 ]
      }, {
        "text" : "GOP",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "40Dollars",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149507353878859776",
    "text" : "House #GOP continues to block #payrolltax cut for 160 million Americans. Tell the #GOP how $40 will help your family. Use #40Dollars",
    "id" : 149507353878859776,
    "created_at" : "2011-12-21 15:11:45 +0000",
    "user" : {
      "name" : "Girl Futurist",
      "screen_name" : "GirlFuturist",
      "protected" : false,
      "id_str" : "18471312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795371821587578880\/1O6APy10_normal.jpg",
      "id" : 18471312,
      "verified" : false
    }
  },
  "id" : 149508715307995136,
  "created_at" : "2011-12-21 15:17:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Scott",
      "screen_name" : "TimothyAScott",
      "indices" : [ 3, 17 ],
      "id_str" : "16207678",
      "id" : 16207678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149508415503335424",
  "text" : "RT @TimothyAScott: The payroll tax cut is worth about $40 bucks. Wondering what folks in Central PA would buy with that extra cash? #40d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149507629155221504",
    "text" : "The payroll tax cut is worth about $40 bucks. Wondering what folks in Central PA would buy with that extra cash? #40dollars",
    "id" : 149507629155221504,
    "created_at" : "2011-12-21 15:12:51 +0000",
    "user" : {
      "name" : "Tim Scott",
      "screen_name" : "TimothyAScott",
      "protected" : false,
      "id_str" : "16207678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605588659518193664\/vDMo77tt_normal.jpg",
      "id" : 16207678,
      "verified" : false
    }
  },
  "id" : 149508415503335424,
  "created_at" : "2011-12-21 15:15:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendra Gagnon",
      "screen_name" : "KendraPedPT",
      "indices" : [ 3, 15 ],
      "id_str" : "244765164",
      "id" : 244765164
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/mEsLIJUN",
      "expanded_url" : "http:\/\/bit.ly\/uwx85F",
      "display_url" : "bit.ly\/uwx85F"
    } ]
  },
  "geo" : { },
  "id_str" : "149508306422083584",
  "text" : "RT @KendraPedPT: Anyone else following the #40dollars hashtag?  Interesting stuff.  http:\/\/t.co\/mEsLIJUN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/mEsLIJUN",
        "expanded_url" : "http:\/\/bit.ly\/uwx85F",
        "display_url" : "bit.ly\/uwx85F"
      } ]
    },
    "geo" : { },
    "id_str" : "149507696511565825",
    "text" : "Anyone else following the #40dollars hashtag?  Interesting stuff.  http:\/\/t.co\/mEsLIJUN",
    "id" : 149507696511565825,
    "created_at" : "2011-12-21 15:13:07 +0000",
    "user" : {
      "name" : "Kendra Gagnon",
      "screen_name" : "KendraPedPT",
      "protected" : false,
      "id_str" : "244765164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735867986196582402\/dbxuXNzg_normal.jpg",
      "id" : 244765164,
      "verified" : false
    }
  },
  "id" : 149508306422083584,
  "created_at" : "2011-12-21 15:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Bertin",
      "screen_name" : "richardbertin",
      "indices" : [ 3, 17 ],
      "id_str" : "14198072",
      "id" : 14198072
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149508258883833856",
  "text" : "RT @richardbertin: @whitehouse #40dollars means a very modest end-of-the-week meal with my girlfriend after a long week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149343562939633664",
    "geo" : { },
    "id_str" : "149507934869667840",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars means a very modest end-of-the-week meal with my girlfriend after a long week.",
    "id" : 149507934869667840,
    "in_reply_to_status_id" : 149343562939633664,
    "created_at" : "2011-12-21 15:14:04 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Richard Bertin",
      "screen_name" : "richardbertin",
      "protected" : false,
      "id_str" : "14198072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759531088331018241\/7COeGubu_normal.jpg",
      "id" : 14198072,
      "verified" : false
    }
  },
  "id" : 149508258883833856,
  "created_at" : "2011-12-21 15:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN iReport",
      "screen_name" : "cnnireport",
      "indices" : [ 3, 14 ],
      "id_str" : "9411482",
      "id" : 9411482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/QMcQcwxJ",
      "expanded_url" : "http:\/\/on.cnn.com\/tUDA24",
      "display_url" : "on.cnn.com\/tUDA24"
    } ]
  },
  "geo" : { },
  "id_str" : "149506653883072512",
  "text" : "RT @cnnireport: Like the White House, we want to know what #40dollars means to you: http:\/\/t.co\/QMcQcwxJ. Your video iReport could be on ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 43, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/QMcQcwxJ",
        "expanded_url" : "http:\/\/on.cnn.com\/tUDA24",
        "display_url" : "on.cnn.com\/tUDA24"
      } ]
    },
    "geo" : { },
    "id_str" : "149500686156050432",
    "text" : "Like the White House, we want to know what #40dollars means to you: http:\/\/t.co\/QMcQcwxJ. Your video iReport could be on CNN.",
    "id" : 149500686156050432,
    "created_at" : "2011-12-21 14:45:15 +0000",
    "user" : {
      "name" : "CNN iReport",
      "screen_name" : "cnnireport",
      "protected" : false,
      "id_str" : "9411482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1799625732\/vetted_video_62x62_normal.jpg",
      "id" : 9411482,
      "verified" : true
    }
  },
  "id" : 149506653883072512,
  "created_at" : "2011-12-21 15:08:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ways and Means Dems",
      "screen_name" : "WaysMeansCmte",
      "indices" : [ 3, 17 ],
      "id_str" : "31128529",
      "id" : 31128529
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "payrolltax",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "GOP",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149506174885175296",
  "text" : "RT @WaysMeansCmte: House #GOP continues to block #payrolltax cut for 160 million Americans. Tell the #GOP how $40 will help your family. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOP",
        "indices" : [ 6, 10 ]
      }, {
        "text" : "payrolltax",
        "indices" : [ 30, 41 ]
      }, {
        "text" : "GOP",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "40Dollars",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149269054958469121",
    "text" : "House #GOP continues to block #payrolltax cut for 160 million Americans. Tell the #GOP how $40 will help your family. Use #40Dollars",
    "id" : 149269054958469121,
    "created_at" : "2011-12-20 23:24:50 +0000",
    "user" : {
      "name" : "Ways and Means Dems",
      "screen_name" : "WaysMeansCmte",
      "protected" : false,
      "id_str" : "31128529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528207034827554816\/D7aoIe58_normal.png",
      "id" : 31128529,
      "verified" : true
    }
  },
  "id" : 149506174885175296,
  "created_at" : "2011-12-21 15:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Journal",
      "screen_name" : "nationaljournal",
      "indices" : [ 3, 19 ],
      "id_str" : "15210284",
      "id" : 15210284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/GINR6wkj",
      "expanded_url" : "http:\/\/njour.nl\/ut1lHf",
      "display_url" : "njour.nl\/ut1lHf"
    } ]
  },
  "geo" : { },
  "id_str" : "149506058229002240",
  "text" : "RT @nationaljournal: Wondering what the deal with the #40dollars hashtag is? http:\/\/t.co\/GINR6wkj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/GINR6wkj",
        "expanded_url" : "http:\/\/njour.nl\/ut1lHf",
        "display_url" : "njour.nl\/ut1lHf"
      } ]
    },
    "geo" : { },
    "id_str" : "149312501429977089",
    "text" : "Wondering what the deal with the #40dollars hashtag is? http:\/\/t.co\/GINR6wkj",
    "id" : 149312501429977089,
    "created_at" : "2011-12-21 02:17:29 +0000",
    "user" : {
      "name" : "National Journal",
      "screen_name" : "nationaljournal",
      "protected" : false,
      "id_str" : "15210284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638402569136541697\/Xj3WlW9w_normal.jpg",
      "id" : 15210284,
      "verified" : true
    }
  },
  "id" : 149506058229002240,
  "created_at" : "2011-12-21 15:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tomoko (USA)",
      "screen_name" : "tmko",
      "indices" : [ 3, 8 ],
      "id_str" : "23535848",
      "id" : 23535848
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149480522714841088",
  "text" : "RT @tmko: The @Whitehouse is asking whats #40dollars is worth to you. Please join me in telling them how it helps you or your family. It ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149480357002088448",
    "text" : "The @Whitehouse is asking whats #40dollars is worth to you. Please join me in telling them how it helps you or your family. It needs to pass",
    "id" : 149480357002088448,
    "created_at" : "2011-12-21 13:24:28 +0000",
    "user" : {
      "name" : "Tomoko (USA)",
      "screen_name" : "tmko",
      "protected" : false,
      "id_str" : "23535848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1237208842\/27977_Bla_Bla_normal.jpg",
      "id" : 23535848,
      "verified" : false
    }
  },
  "id" : 149480522714841088,
  "created_at" : "2011-12-21 13:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth S Remley",
      "screen_name" : "Slaterade",
      "indices" : [ 3, 13 ],
      "id_str" : "14497106",
      "id" : 14497106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 65, 75 ]
    }, {
      "text" : "Congress",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149479692498509824",
  "text" : "RT @Slaterade: It's amazing to read how far Americans are making #40dollars go these days. #Congress needs to remember who they represen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 124, 135 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "Congress",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149479190062833664",
    "text" : "It's amazing to read how far Americans are making #40dollars go these days. #Congress needs to remember who they represent. @whitehouse",
    "id" : 149479190062833664,
    "created_at" : "2011-12-21 13:19:50 +0000",
    "user" : {
      "name" : "Elizabeth S Remley",
      "screen_name" : "Slaterade",
      "protected" : false,
      "id_str" : "14497106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53206284\/boat_ride_normal.jpg",
      "id" : 14497106,
      "verified" : false
    }
  },
  "id" : 149479692498509824,
  "created_at" : "2011-12-21 13:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garland John Gates",
      "screen_name" : "garlandgates",
      "indices" : [ 3, 16 ],
      "id_str" : "84936614",
      "id" : 84936614
    }, {
      "name" : "O.A.A.C.E",
      "screen_name" : "OAACE",
      "indices" : [ 95, 101 ],
      "id_str" : "300270763",
      "id" : 300270763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "GED",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149477362034163712",
  "text" : "RT @garlandgates: #40dollars means a working Ohioan can pay the fee to take The #GED Test. cc: @OAACE.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "O.A.A.C.E",
        "screen_name" : "OAACE",
        "indices" : [ 77, 83 ],
        "id_str" : "300270763",
        "id" : 300270763
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "GED",
        "indices" : [ 62, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149467736630771712",
    "text" : "#40dollars means a working Ohioan can pay the fee to take The #GED Test. cc: @OAACE.",
    "id" : 149467736630771712,
    "created_at" : "2011-12-21 12:34:20 +0000",
    "user" : {
      "name" : "Garland John Gates",
      "screen_name" : "garlandgates",
      "protected" : false,
      "id_str" : "84936614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798685057267310592\/UHw_1RRZ_normal.jpg",
      "id" : 84936614,
      "verified" : false
    }
  },
  "id" : 149477362034163712,
  "created_at" : "2011-12-21 13:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamesa",
      "screen_name" : "tealmama2",
      "indices" : [ 3, 13 ],
      "id_str" : "41471840",
      "id" : 41471840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "40dollars",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149477122212245504",
  "text" : "RT @tealmama2: #40dollars to Congress: Fancy brunch. #40dollars to me: copay for my BP meds or a tank of gas to go to work. Do what's ri ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 126, 137 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "40dollars",
        "indices" : [ 38, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149472651239362560",
    "text" : "#40dollars to Congress: Fancy brunch. #40dollars to me: copay for my BP meds or a tank of gas to go to work. Do what's right! @whitehouse",
    "id" : 149472651239362560,
    "created_at" : "2011-12-21 12:53:51 +0000",
    "user" : {
      "name" : "Kamesa",
      "screen_name" : "tealmama2",
      "protected" : false,
      "id_str" : "41471840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745415356534009858\/vLNU37pE_normal.jpg",
      "id" : 41471840,
      "verified" : false
    }
  },
  "id" : 149477122212245504,
  "created_at" : "2011-12-21 13:11:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kaleta",
      "screen_name" : "JessicaKaleta",
      "indices" : [ 3, 17 ],
      "id_str" : "326531064",
      "id" : 326531064
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149476839415492609",
  "text" : "RT @JessicaKaleta: @whitehouse #40dollars is a box of diapers & 4 gallons of milk, or a week's worth of gas, or groceries on my tight bu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.motorola.com\" rel=\"nofollow\"\u003EDROID\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149476132570398721",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is a box of diapers & 4 gallons of milk, or a week's worth of gas, or groceries on my tight budget.",
    "id" : 149476132570398721,
    "created_at" : "2011-12-21 13:07:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jessica Kaleta",
      "screen_name" : "JessicaKaleta",
      "protected" : false,
      "id_str" : "326531064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1419716809\/Jessica_normal.jpg",
      "id" : 326531064,
      "verified" : false
    }
  },
  "id" : 149476839415492609,
  "created_at" : "2011-12-21 13:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 60, 68 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 5, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/liIBHOdH",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/what-does-40dollars-mean-to-you",
      "display_url" : "storify.com\/whitehouse\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149343562939633664",
  "text" : "What #40dollars Means to Americans http:\/\/t.co\/liIBHOdH via @Storify",
  "id" : 149343562939633664,
  "created_at" : "2011-12-21 04:20:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dave",
      "screen_name" : "dave32372",
      "indices" : [ 3, 13 ],
      "id_str" : "35362779",
      "id" : 35362779
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149340369312694273",
  "text" : "RT @dave32372: @whitehouse #40dollars is the cost of the smallest ad in our newspaper. I sell ads and need to sell 200 $40 ads per month ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149340164781649920",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is the cost of the smallest ad in our newspaper. I sell ads and need to sell 200 $40 ads per month to keep my job.",
    "id" : 149340164781649920,
    "created_at" : "2011-12-21 04:07:24 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "dave",
      "screen_name" : "dave32372",
      "protected" : false,
      "id_str" : "35362779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3583051348\/887e29f24164b597cb7d0650e23a90c4_normal.jpeg",
      "id" : 35362779,
      "verified" : false
    }
  },
  "id" : 149340369312694273,
  "created_at" : "2011-12-21 04:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Pease",
      "screen_name" : "peeease",
      "indices" : [ 3, 11 ],
      "id_str" : "284076823",
      "id" : 284076823
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149335160721125376",
  "text" : "RT @peeease: @whitehouse #40 dollars is 300 miles for my car, a week of good groceries (produce is expensive!), or 5 hours pay at my uni ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149333899443576832",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40 dollars is 300 miles for my car, a week of good groceries (produce is expensive!), or 5 hours pay at my university job.",
    "id" : 149333899443576832,
    "created_at" : "2011-12-21 03:42:30 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Sarah Pease",
      "screen_name" : "peeease",
      "protected" : false,
      "id_str" : "284076823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608000208861945856\/JA67vVR1_normal.jpg",
      "id" : 284076823,
      "verified" : false
    }
  },
  "id" : 149335160721125376,
  "created_at" : "2011-12-21 03:47:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gloria Attar RN BSN",
      "screen_name" : "redheadwritrgrl",
      "indices" : [ 3, 19 ],
      "id_str" : "21209313",
      "id" : 21209313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149334792847101952",
  "text" : "RT @redheadwritrgrl: .@whitehouse #40dollars is school lunches for 1mo or water bill for 2 mos.; or meat budget for 1mo w\/coupons, loyal ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149334016758267906",
    "text" : ".@whitehouse #40dollars is school lunches for 1mo or water bill for 2 mos.; or meat budget for 1mo w\/coupons, loyalty card & store specials",
    "id" : 149334016758267906,
    "created_at" : "2011-12-21 03:42:58 +0000",
    "user" : {
      "name" : "Gloria Attar RN BSN",
      "screen_name" : "redheadwritrgrl",
      "protected" : false,
      "id_str" : "21209313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000307910569\/f19d9a70b8a8e2322e96162958ec9fa9_normal.jpeg",
      "id" : 21209313,
      "verified" : false
    }
  },
  "id" : 149334792847101952,
  "created_at" : "2011-12-21 03:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Williams",
      "screen_name" : "Mzchellesoul",
      "indices" : [ 3, 16 ],
      "id_str" : "349045184",
      "id" : 349045184
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149327217497866240",
  "text" : "RT @Mzchellesoul: @whitehouse #40dollars means part of my electric bill keeping my house warm this winter, or how about gas to get to wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "40dollars",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149237000522825729",
    "geo" : { },
    "id_str" : "149326611643244547",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars means part of my electric bill keeping my house warm this winter, or how about gas to get to work to earn #40dollars",
    "id" : 149326611643244547,
    "in_reply_to_status_id" : 149237000522825729,
    "created_at" : "2011-12-21 03:13:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jennifer Williams",
      "screen_name" : "Mzchellesoul",
      "protected" : false,
      "id_str" : "349045184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738757189964177412\/fDMnx5NE_normal.jpg",
      "id" : 349045184,
      "verified" : false
    }
  },
  "id" : 149327217497866240,
  "created_at" : "2011-12-21 03:15:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle VanZandt",
      "screen_name" : "PRPirateDani",
      "indices" : [ 3, 16 ],
      "id_str" : "339130193",
      "id" : 339130193
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149324820222447616",
  "text" : "RT @PRPirateDani: @whitehouse #40dollars is money for my student loans and for my parents to buy themselves groceries.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149324299197624321",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is money for my student loans and for my parents to buy themselves groceries.",
    "id" : 149324299197624321,
    "created_at" : "2011-12-21 03:04:21 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Danielle VanZandt",
      "screen_name" : "PRPirateDani",
      "protected" : false,
      "id_str" : "339130193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1454336219\/110401-121823_normal.jpg",
      "id" : 339130193,
      "verified" : false
    }
  },
  "id" : 149324820222447616,
  "created_at" : "2011-12-21 03:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Layaly M. Zanca",
      "screen_name" : "LMzancaRN",
      "indices" : [ 3, 13 ],
      "id_str" : "441257096",
      "id" : 441257096
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "40dollars",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149320760211677184",
  "text" : "RT @LMzancaRN: @whitehouse #40dollars is half our electric bill, or our water bill, gas to get to work #40dollars makes a big difference ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "40dollars",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149320493693022208",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is half our electric bill, or our water bill, gas to get to work #40dollars makes a big difference eac paycheck.",
    "id" : 149320493693022208,
    "created_at" : "2011-12-21 02:49:14 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Layaly M. Zanca",
      "screen_name" : "LMzancaRN",
      "protected" : false,
      "id_str" : "441257096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687034898616586240\/jTYLPtr3_normal.jpg",
      "id" : 441257096,
      "verified" : false
    }
  },
  "id" : 149320760211677184,
  "created_at" : "2011-12-21 02:50:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee VanWinkle",
      "screen_name" : "VanWinky",
      "indices" : [ 3, 12 ],
      "id_str" : "47014632",
      "id" : 47014632
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149307865134399491",
  "text" : "RT @VanWinky: @whitehouse #40dollars is a portion of my student loan payment, or a tank of gas.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149237000522825729",
    "geo" : { },
    "id_str" : "149307520652025856",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is a portion of my student loan payment, or a tank of gas.",
    "id" : 149307520652025856,
    "in_reply_to_status_id" : 149237000522825729,
    "created_at" : "2011-12-21 01:57:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Aimee VanWinkle",
      "screen_name" : "VanWinky",
      "protected" : false,
      "id_str" : "47014632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1651453161\/5LtEQeoz_normal",
      "id" : 47014632,
      "verified" : false
    }
  },
  "id" : 149307865134399491,
  "created_at" : "2011-12-21 01:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pinar szabo",
      "screen_name" : "fourmommy",
      "indices" : [ 3, 13 ],
      "id_str" : "531995560",
      "id" : 531995560
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 15, 27 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149307268876337154",
  "text" : "RT @fourmommy: @BarackObama  @whitehouse #40dollars is a week worth of groceries at save a lot two weeks if I buy processed food",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149306961219944448",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama  @whitehouse #40dollars is a week worth of groceries at save a lot two weeks if I buy processed food",
    "id" : 149306961219944448,
    "created_at" : "2011-12-21 01:55:28 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Alexis Farmer",
      "screen_name" : "Six_Coil_Ela",
      "protected" : false,
      "id_str" : "115154856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1888763639\/profile_normal.jpg",
      "id" : 115154856,
      "verified" : false
    }
  },
  "id" : 149307268876337154,
  "created_at" : "2011-12-21 01:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/OlIYsxkj",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/12\/20\/statement-president-hanukkah",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149293878657298432",
  "text" : "\"Michelle & I send our warmest wishes to all those celebrating Hanukkah around the world.\" -President Obama: http:\/\/t.co\/OlIYsxkj",
  "id" : 149293878657298432,
  "created_at" : "2011-12-21 01:03:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ninkovich",
      "screen_name" : "CaptNink",
      "indices" : [ 0, 9 ],
      "id_str" : "19209349",
      "id" : 19209349
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149272674747691008",
  "geo" : { },
  "id_str" : "149273755712098304",
  "in_reply_to_user_id" : 19209349,
  "text" : "@CaptNink and don't worry about the #40Dollars! ;)",
  "id" : 149273755712098304,
  "in_reply_to_status_id" : 149272674747691008,
  "created_at" : "2011-12-20 23:43:31 +0000",
  "in_reply_to_screen_name" : "CaptNink",
  "in_reply_to_user_id_str" : "19209349",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Ninkovich",
      "screen_name" : "CaptNink",
      "indices" : [ 41, 50 ],
      "id_str" : "19209349",
      "id" : 19209349
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 64, 75 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 76, 86 ]
    }, {
      "text" : "40Dollar",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149272674747691008",
  "geo" : { },
  "id_str" : "149273549570441216",
  "in_reply_to_user_id" : 19209349,
  "text" : "We'll slow down but these are amazing RT @CaptNink I would give @WhiteHouse #40Dollars if they would stop retweeting these #40Dollar tweets!",
  "id" : 149273549570441216,
  "in_reply_to_status_id" : 149272674747691008,
  "created_at" : "2011-12-20 23:42:42 +0000",
  "in_reply_to_screen_name" : "CaptNink",
  "in_reply_to_user_id_str" : "19209349",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Quimby",
      "screen_name" : "david_quimby",
      "indices" : [ 3, 16 ],
      "id_str" : "1546989516",
      "id" : 1546989516
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 82, 93 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149272901294628864",
  "text" : "RT @David_Quimby: 2 weeks worth of money to cover Highway tolls to get to work RT @whitehouse: What does #40dollars mean to you? http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149237000522825729\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/ZA36b4Qg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
        "id_str" : "149237000527020032",
        "id" : 149237000527020032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 615
        } ],
        "display_url" : "pic.twitter.com\/ZA36b4Qg"
      } ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149272377744830464",
    "text" : "2 weeks worth of money to cover Highway tolls to get to work RT @whitehouse: What does #40dollars mean to you? http:\/\/t.co\/ZA36b4Qg",
    "id" : 149272377744830464,
    "created_at" : "2011-12-20 23:38:02 +0000",
    "user" : {
      "name" : "David Quimby",
      "screen_name" : "D_Quimby",
      "protected" : false,
      "id_str" : "298740280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1353627250\/209269_1658455387827_1430400118_31252026_7460333_o_normal.jpg",
      "id" : 298740280,
      "verified" : false
    }
  },
  "id" : 149272901294628864,
  "created_at" : "2011-12-20 23:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ntCJT4PV",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/economy\/jobs\/we-cant-wait",
      "display_url" : "whitehouse.gov\/economy\/jobs\/w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "149264934562304000",
  "geo" : { },
  "id_str" : "149267682154381312",
  "in_reply_to_user_id" : 192407271,
  "text" : "@carrinlove2011 We're trying to stop a $40 middle-class tax increase next year b\/c Congress didn't act. More info: http:\/\/t.co\/ntCJT4PV",
  "id" : 149267682154381312,
  "in_reply_to_status_id" : 149264934562304000,
  "created_at" : "2011-12-20 23:19:23 +0000",
  "in_reply_to_screen_name" : "carrbot",
  "in_reply_to_user_id_str" : "192407271",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Britt",
      "screen_name" : "alanlbritt",
      "indices" : [ 3, 14 ],
      "id_str" : "48397913",
      "id" : 48397913
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149265088531009536",
  "text" : "RT @alanlbritt: @whitehouse #40dollars per week is EXACTLY my children's health insurance premium.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149264890710855681",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars per week is EXACTLY my children's health insurance premium.",
    "id" : 149264890710855681,
    "created_at" : "2011-12-20 23:08:17 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Alan Britt",
      "screen_name" : "alanlbritt",
      "protected" : false,
      "id_str" : "48397913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630799117011128320\/-sCVQY3u_normal.jpg",
      "id" : 48397913,
      "verified" : false
    }
  },
  "id" : 149265088531009536,
  "created_at" : "2011-12-20 23:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara B Pickrel",
      "screen_name" : "joyousjava",
      "indices" : [ 3, 14 ],
      "id_str" : "26764781",
      "id" : 26764781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149264273732931584",
  "text" : "RT @joyousjava: Just paid off the eyeglasses I got last January.  With #40dollars less per paycheck it'll be even harder to pay off the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 55, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149263511158128641",
    "text" : "Just paid off the eyeglasses I got last January.  With #40dollars less per paycheck it'll be even harder to pay off the medical & loan debt.",
    "id" : 149263511158128641,
    "created_at" : "2011-12-20 23:02:48 +0000",
    "user" : {
      "name" : "Lara B Pickrel",
      "screen_name" : "joyousjava",
      "protected" : false,
      "id_str" : "26764781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1720833155\/image_normal.jpg",
      "id" : 26764781,
      "verified" : false
    }
  },
  "id" : 149264273732931584,
  "created_at" : "2011-12-20 23:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149263336800915457",
  "text" : "RT @ShawnaNBCNews: The White House's new tactic on the pay roll tax cut: Asking the twitters what $40 can buy.  Interesting to watch the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149262376783454208",
    "text" : "The White House's new tactic on the pay roll tax cut: Asking the twitters what $40 can buy.  Interesting to watch the #40dollars feed",
    "id" : 149262376783454208,
    "created_at" : "2011-12-20 22:58:18 +0000",
    "user" : {
      "name" : "Shawna Thomas",
      "screen_name" : "Shawna",
      "protected" : false,
      "id_str" : "1025521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763031749429342208\/q1D-2mGg_normal.jpg",
      "id" : 1025521,
      "verified" : true
    }
  },
  "id" : 149263336800915457,
  "created_at" : "2011-12-20 23:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Robert",
      "screen_name" : "JamesRobert_",
      "indices" : [ 3, 16 ],
      "id_str" : "407438618",
      "id" : 407438618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149261969701076992",
  "text" : "RT @JamesRobert_: My Flex spending account payroll deduction is #40Dollars to cover medical expenses not covered by insurance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40Dollars",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149261517248937984",
    "text" : "My Flex spending account payroll deduction is #40Dollars to cover medical expenses not covered by insurance.",
    "id" : 149261517248937984,
    "created_at" : "2011-12-20 22:54:53 +0000",
    "user" : {
      "name" : "James Robert",
      "screen_name" : "JamesRobert_",
      "protected" : false,
      "id_str" : "407438618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1631492777\/dscn0539_95__3__normal.jpg",
      "id" : 407438618,
      "verified" : false
    }
  },
  "id" : 149261969701076992,
  "created_at" : "2011-12-20 22:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 72, 83 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149261602779181056",
  "text" : "RT @minnie6998: $40 covers about 66% of my monthly electricity bill RT: @whitehouse What does #40dollars mean to u?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149261280723738625",
    "text" : "$40 covers about 66% of my monthly electricity bill RT: @whitehouse What does #40dollars mean to u?",
    "id" : 149261280723738625,
    "created_at" : "2011-12-20 22:53:57 +0000",
    "user" : {
      "name" : "Tiffany Black",
      "screen_name" : "TiffBlack",
      "protected" : false,
      "id_str" : "32518531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717364581685833729\/0yPLtX5x_normal.jpg",
      "id" : 32518531,
      "verified" : false
    }
  },
  "id" : 149261602779181056,
  "created_at" : "2011-12-20 22:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrohnieTweets",
      "screen_name" : "CrohnieTweets",
      "indices" : [ 3, 17 ],
      "id_str" : "81976870",
      "id" : 81976870
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40Dollars",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "Crohns",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149260061032710145",
  "text" : "RT @CrohnieTweets: #40Dollars is the cost of my monthly blood test to make sure my #Crohns meds aren't making me sick.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40Dollars",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Crohns",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149241323390644224",
    "text" : "#40Dollars is the cost of my monthly blood test to make sure my #Crohns meds aren't making me sick.",
    "id" : 149241323390644224,
    "created_at" : "2011-12-20 21:34:38 +0000",
    "user" : {
      "name" : "CrohnieTweets",
      "screen_name" : "CrohnieTweets",
      "protected" : false,
      "id_str" : "81976870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696543924\/4077212192_5bd514f5a6_m_normal.jpg",
      "id" : 81976870,
      "verified" : false
    }
  },
  "id" : 149260061032710145,
  "created_at" : "2011-12-20 22:49:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Adams",
      "screen_name" : "LMKAdams",
      "indices" : [ 3, 12 ],
      "id_str" : "112766734",
      "id" : 112766734
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149259340048637953",
  "text" : "RT @LMKAdams: Since  @whitehouse asked... #40dollars less per paycheck would mean fewer fresh fruits & veggies in my fridge or less to s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 7, 18 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 28, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149258952658534400",
    "text" : "Since  @whitehouse asked... #40dollars less per paycheck would mean fewer fresh fruits & veggies in my fridge or less to save to buy a home.",
    "id" : 149258952658534400,
    "created_at" : "2011-12-20 22:44:42 +0000",
    "user" : {
      "name" : "Lisa Adams",
      "screen_name" : "LMKAdams",
      "protected" : false,
      "id_str" : "112766734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764281896104624132\/yOptNTtL_normal.jpg",
      "id" : 112766734,
      "verified" : false
    }
  },
  "id" : 149259340048637953,
  "created_at" : "2011-12-20 22:46:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 1, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149254404418174977",
  "text" : "\"#40dollars less a paycheck means I will have to pick between my insulin & the water bill\" -BT, Roswell, NM",
  "id" : 149254404418174977,
  "created_at" : "2011-12-20 22:26:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/149247703518420993\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/LqrrpXpI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhI7_uBCIAANoLh.jpg",
      "id_str" : "149247703526809600",
      "id" : 149247703526809600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhI7_uBCIAANoLh.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 425
      } ],
      "display_url" : "pic.twitter.com\/LqrrpXpI"
    } ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/bqln8awQ",
      "expanded_url" : "http:\/\/1.usa.gov\/vUadd2",
      "display_url" : "1.usa.gov\/vUadd2"
    } ]
  },
  "geo" : { },
  "id_str" : "149247703518420993",
  "text" : "Wait, why is #40dollars trending?! What's it about? Your money. Learn more: http:\/\/t.co\/bqln8awQ http:\/\/t.co\/LqrrpXpI",
  "id" : 149247703518420993,
  "created_at" : "2011-12-20 22:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Jones",
      "screen_name" : "wmmjones",
      "indices" : [ 3, 12 ],
      "id_str" : "50537844",
      "id" : 50537844
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149240974579736576",
  "text" : "RT @wmmjones: @whitehouse #40dollars is half of my grocery budget for the week for my family.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149240588829593601",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is half of my grocery budget for the week for my family.",
    "id" : 149240588829593601,
    "created_at" : "2011-12-20 21:31:43 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Will Jones",
      "screen_name" : "wmmjones",
      "protected" : false,
      "id_str" : "50537844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768925801630793729\/w4hRzODY_normal.jpg",
      "id" : 50537844,
      "verified" : false
    }
  },
  "id" : 149240974579736576,
  "created_at" : "2011-12-20 21:33:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Nocella",
      "screen_name" : "mattnocella",
      "indices" : [ 3, 15 ],
      "id_str" : "153500150",
      "id" : 153500150
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149240679464308739",
  "text" : "RT @mattnocella: With #40dollars, it would be easier to make my student loan payments.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 5, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149240064432553984",
    "text" : "With #40dollars, it would be easier to make my student loan payments.",
    "id" : 149240064432553984,
    "created_at" : "2011-12-20 21:29:38 +0000",
    "user" : {
      "name" : "Matt Nocella",
      "screen_name" : "mattnocella",
      "protected" : false,
      "id_str" : "153500150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740763225487114240\/DPNrP4HM_normal.jpg",
      "id" : 153500150,
      "verified" : false
    }
  },
  "id" : 149240679464308739,
  "created_at" : "2011-12-20 21:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Schmidt",
      "screen_name" : "zaren",
      "indices" : [ 3, 9 ],
      "id_str" : "698903",
      "id" : 698903
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149239739113943040",
  "text" : "RT @zaren: @whitehouse #40dollars Is a tank of gas to get me to and from work for the week. That means two less tanks of gas a month.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "149237000522825729",
    "geo" : { },
    "id_str" : "149239433638584321",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars Is a tank of gas to get me to and from work for the week. That means two less tanks of gas a month.",
    "id" : 149239433638584321,
    "in_reply_to_status_id" : 149237000522825729,
    "created_at" : "2011-12-20 21:27:08 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jim Schmidt",
      "screen_name" : "zaren",
      "protected" : false,
      "id_str" : "698903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499981883313094656\/gFWQhb1M_normal.jpeg",
      "id" : 698903,
      "verified" : false
    }
  },
  "id" : 149239739113943040,
  "created_at" : "2011-12-20 21:28:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 1, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149239022106062848",
  "text" : "\"#40dollars will cover the co-pays for 2 of my husband's prescription medications\" -DN from Nelson, WI",
  "id" : 149239022106062848,
  "created_at" : "2011-12-20 21:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/149237000522825729\/photo\/1",
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/PG1jtofV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
      "id_str" : "149237000527020032",
      "id" : 149237000527020032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhIyQuPCAAAXoH_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/PG1jtofV"
    } ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149237000522825729",
  "text" : "What does #40dollars mean to you? http:\/\/t.co\/PG1jtofV",
  "id" : 149237000522825729,
  "created_at" : "2011-12-20 21:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyHannukah",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/XDkW6bI9",
      "expanded_url" : "http:\/\/ht.ly\/85wcK",
      "display_url" : "ht.ly\/85wcK"
    } ]
  },
  "geo" : { },
  "id_str" : "149231746662154241",
  "text" : "RT @OMBPress: Jack Lew lighting the National Menorah on the Ellipse today at 4. http:\/\/t.co\/XDkW6bI9 #HappyHannukah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HappyHannukah",
        "indices" : [ 87, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/XDkW6bI9",
        "expanded_url" : "http:\/\/ht.ly\/85wcK",
        "display_url" : "ht.ly\/85wcK"
      } ]
    },
    "geo" : { },
    "id_str" : "149188251075358722",
    "text" : "Jack Lew lighting the National Menorah on the Ellipse today at 4. http:\/\/t.co\/XDkW6bI9 #HappyHannukah",
    "id" : 149188251075358722,
    "created_at" : "2011-12-20 18:03:45 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 149231746662154241,
  "created_at" : "2011-12-20 20:56:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/xFp7wlgY",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "149202758011064320",
  "text" : "RT @jesseclee44: Obama speaking at press briefing now: http:\/\/t.co\/xFp7wlgY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/xFp7wlgY",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "149202491450466304",
    "text" : "Obama speaking at press briefing now: http:\/\/t.co\/xFp7wlgY",
    "id" : 149202491450466304,
    "created_at" : "2011-12-20 19:00:20 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 149202758011064320,
  "created_at" : "2011-12-20 19:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149169684279853057",
  "text" : "RT @JonCarson44: Happy Hannukah from everyone here at the White House.  Watch here to see the White House get \"Kosherized.\" http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/iI3LTzLu",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/20\/watch-white-house-kitchen-get-kosherized-hanukkah",
        "display_url" : "whitehouse.gov\/blog\/2011\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "149169322705682433",
    "text" : "Happy Hannukah from everyone here at the White House.  Watch here to see the White House get \"Kosherized.\" http:\/\/t.co\/iI3LTzLu",
    "id" : 149169322705682433,
    "created_at" : "2011-12-20 16:48:32 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 149169684279853057,
  "created_at" : "2011-12-20 16:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/dUn9YjJ6",
      "expanded_url" : "http:\/\/ow.ly\/85nkU",
      "display_url" : "ow.ly\/85nkU"
    } ]
  },
  "geo" : { },
  "id_str" : "149165326553194497",
  "text" : "Have questions on women's entrepreneurship? Ask now with #WHChat & tune in live @ 3ET for Open for Questions: http:\/\/t.co\/dUn9YjJ6",
  "id" : 149165326553194497,
  "created_at" : "2011-12-20 16:32:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Entrepreneur",
      "screen_name" : "EntMagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "2932542566",
      "id" : 2932542566
    }, {
      "name" : "Diana Ransom",
      "screen_name" : "dianaransom",
      "indices" : [ 96, 108 ],
      "id_str" : "244187775",
      "id" : 244187775
    }, {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 122, 129 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/cojevsCp",
      "expanded_url" : "http:\/\/entm.ag\/t1Vrss",
      "display_url" : "entm.ag\/t1Vrss"
    } ]
  },
  "geo" : { },
  "id_str" : "149148227244007424",
  "text" : "RT @EntMagazine: Women Entrepreneurs Put the Government in the Hot Seat http:\/\/t.co\/cojevsCp by @dianaransom #smallbiz cc @SBAgov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Diana Ransom",
        "screen_name" : "dianaransom",
        "indices" : [ 79, 91 ],
        "id_str" : "244187775",
        "id" : 244187775
      }, {
        "name" : "SBA",
        "screen_name" : "SBAgov",
        "indices" : [ 105, 112 ],
        "id_str" : "153149305",
        "id" : 153149305
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/cojevsCp",
        "expanded_url" : "http:\/\/entm.ag\/t1Vrss",
        "display_url" : "entm.ag\/t1Vrss"
      } ]
    },
    "geo" : { },
    "id_str" : "149142347672854528",
    "text" : "Women Entrepreneurs Put the Government in the Hot Seat http:\/\/t.co\/cojevsCp by @dianaransom #smallbiz cc @SBAgov",
    "id" : 149142347672854528,
    "created_at" : "2011-12-20 15:01:21 +0000",
    "user" : {
      "name" : "Entrepreneur",
      "screen_name" : "Entrepreneur",
      "protected" : false,
      "id_str" : "19407053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474753665970868224\/GcoCzmcI_normal.jpeg",
      "id" : 19407053,
      "verified" : true
    }
  },
  "id" : 149148227244007424,
  "created_at" : "2011-12-20 15:24:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/d3cbZQps",
      "expanded_url" : "http:\/\/owl.li\/84vM6",
      "display_url" : "owl.li\/84vM6"
    } ]
  },
  "geo" : { },
  "id_str" : "149136403756879873",
  "text" : "RT @SBAgov: We\u2019re talking about gov policies designed to help women entrepreneurs TODAY at 3PM EST,join us! http:\/\/t.co\/d3cbZQps #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/d3cbZQps",
        "expanded_url" : "http:\/\/owl.li\/84vM6",
        "display_url" : "owl.li\/84vM6"
      } ]
    },
    "geo" : { },
    "id_str" : "149119446898847744",
    "text" : "We\u2019re talking about gov policies designed to help women entrepreneurs TODAY at 3PM EST,join us! http:\/\/t.co\/d3cbZQps #WHChat",
    "id" : 149119446898847744,
    "created_at" : "2011-12-20 13:30:21 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 149136403756879873,
  "created_at" : "2011-12-20 14:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/vzH3j7Gh",
      "expanded_url" : "http:\/\/ow.ly\/85bg6",
      "display_url" : "ow.ly\/85bg6"
    } ]
  },
  "geo" : { },
  "id_str" : "149134269841801216",
  "text" : "If the House doesn't act, middle class taxes increase in 11 days: 14 hours: 30 minutes: 47 seconds. We can't wait: http:\/\/t.co\/vzH3j7Gh",
  "id" : 149134269841801216,
  "created_at" : "2011-12-20 14:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149133461565882369",
  "text" : "RT @pfeiffer44: Why won't the GOP have an up or down vote on the bipartisan Senate compromise? Has anyone heard a good answer to this qu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "149130856605294593",
    "text" : "Why won't the GOP have an up or down vote on the bipartisan Senate compromise? Has anyone heard a good answer to this question from the GOP?",
    "id" : 149130856605294593,
    "created_at" : "2011-12-20 14:15:41 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 149133461565882369,
  "created_at" : "2011-12-20 14:26:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/ocBr3qF2",
      "expanded_url" : "http:\/\/ow.ly\/84AG7",
      "display_url" : "ow.ly\/84AG7"
    } ]
  },
  "geo" : { },
  "id_str" : "148912984675205120",
  "text" : "12 days: 5 hours: 10 minutes. If the House doesn't act, that's when middle class taxes will increase. We can't wait: http:\/\/t.co\/ocBr3qF2",
  "id" : 148912984675205120,
  "created_at" : "2011-12-19 23:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148902722513547264",
  "text" : "RT @pfeiffer44: GOP Senators Heller and Snowe, join Lugar and Brown, in calling in the House Republicans to pass the Senate bill to ensu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "148874445459701762",
    "text" : "GOP Senators Heller and Snowe, join Lugar and Brown, in calling in the House Republicans to pass the Senate bill to ensure taxes dont go up",
    "id" : 148874445459701762,
    "created_at" : "2011-12-19 21:16:48 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 148902722513547264,
  "created_at" : "2011-12-19 23:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "osstocafme1982",
      "screen_name" : "jointbase",
      "indices" : [ 97, 107 ],
      "id_str" : "2982435514",
      "id" : 2982435514
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/148901767650869248\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/smaUt4EM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhEBXmeCAAAdlP9.jpg",
      "id_str" : "148901767655063552",
      "id" : 148901767655063552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhEBXmeCAAAdlP9.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1294,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/smaUt4EM"
    } ],
    "hashtags" : [ {
      "text" : "ToysForTots",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148901767650869248",
  "text" : "Photo of the Day: The First Lady drops off toys from @WhiteHouse staff to the #ToysForTots drive @jointbase in DC: http:\/\/t.co\/smaUt4EM",
  "id" : 148901767650869248,
  "created_at" : "2011-12-19 23:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rieva Lesonsky",
      "screen_name" : "Rieva",
      "indices" : [ 3, 9 ],
      "id_str" : "9015512",
      "id" : 9015512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneurs",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148880960153321473",
  "text" : "RT @Rieva: Women #entrepreneurs: Get your questions answered tomorrow in a livestream at 3 EST by White HOuse & SBA officials: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "entrepreneurs",
        "indices" : [ 6, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/ZSBLVoOv",
        "expanded_url" : "http:\/\/1.usa.gov\/rZ6Lv1",
        "display_url" : "1.usa.gov\/rZ6Lv1"
      } ]
    },
    "geo" : { },
    "id_str" : "148865233182662657",
    "text" : "Women #entrepreneurs: Get your questions answered tomorrow in a livestream at 3 EST by White HOuse & SBA officials: http:\/\/t.co\/ZSBLVoOv",
    "id" : 148865233182662657,
    "created_at" : "2011-12-19 20:40:12 +0000",
    "user" : {
      "name" : "Rieva Lesonsky",
      "screen_name" : "Rieva",
      "protected" : false,
      "id_str" : "9015512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1426370496\/Rieva_re-shopped__3__cropped_normal.jpg",
      "id" : 9015512,
      "verified" : false
    }
  },
  "id" : 148880960153321473,
  "created_at" : "2011-12-19 21:42:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/3yYmINpR",
      "expanded_url" : "http:\/\/ow.ly\/84oN1",
      "display_url" : "ow.ly\/84oN1"
    } ]
  },
  "geo" : { },
  "id_str" : "148864422067175425",
  "text" : "Will House Republicans allow taxes to go up on 160 million Americans? http:\/\/t.co\/3yYmINpR",
  "id" : 148864422067175425,
  "created_at" : "2011-12-19 20:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/rjJxStkI",
      "expanded_url" : "http:\/\/bit.ly\/sojEAk",
      "display_url" : "bit.ly\/sojEAk"
    } ]
  },
  "geo" : { },
  "id_str" : "148858458375069696",
  "text" : "RT @petesouza: New behind-the-scenes White House photos of President Obama: http:\/\/t.co\/rjJxStkI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/rjJxStkI",
        "expanded_url" : "http:\/\/bit.ly\/sojEAk",
        "display_url" : "bit.ly\/sojEAk"
      } ]
    },
    "geo" : { },
    "id_str" : "148855439805784064",
    "text" : "New behind-the-scenes White House photos of President Obama: http:\/\/t.co\/rjJxStkI",
    "id" : 148855439805784064,
    "created_at" : "2011-12-19 20:01:17 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 148858458375069696,
  "created_at" : "2011-12-19 20:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148818969183264768",
  "text" : "RT @StateDept: Today, President Obama released the first-ever U.S. National Action Plan on Women, Peace, and Security. http:\/\/t.co\/7R3W0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 125, 136 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/7R3W0rtE",
        "expanded_url" : "http:\/\/go.usa.gov\/Nk8",
        "display_url" : "go.usa.gov\/Nk8"
      } ]
    },
    "geo" : { },
    "id_str" : "148807949840691201",
    "text" : "Today, President Obama released the first-ever U.S. National Action Plan on Women, Peace, and Security. http:\/\/t.co\/7R3W0rtE @WhiteHouse",
    "id" : 148807949840691201,
    "created_at" : "2011-12-19 16:52:34 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 148818969183264768,
  "created_at" : "2011-12-19 17:36:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/pCl2Tpgr",
      "expanded_url" : "http:\/\/ow.ly\/8447a",
      "display_url" : "ow.ly\/8447a"
    } ]
  },
  "geo" : { },
  "id_str" : "148804206445346816",
  "text" : "Mark Hodesh, small business owner from MI on how tax credits from the Affordable Care Act help mom-and-pop businesses: http:\/\/t.co\/pCl2Tpgr",
  "id" : 148804206445346816,
  "created_at" : "2011-12-19 16:37:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/6UjR9LG0",
      "expanded_url" : "http:\/\/goo.gl\/fb\/Tb4Ju",
      "display_url" : "goo.gl\/fb\/Tb4Ju"
    } ]
  },
  "geo" : { },
  "id_str" : "148249393299079168",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: Extending the Agreement to Extend the Payroll Tax Cut http:\/\/t.co\/6UjR9LG0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/6UjR9LG0",
        "expanded_url" : "http:\/\/goo.gl\/fb\/Tb4Ju",
        "display_url" : "goo.gl\/fb\/Tb4Ju"
      } ]
    },
    "geo" : { },
    "id_str" : "148190159291166721",
    "text" : "http:\/\/t.co\/HxTO58SB: Extending the Agreement to Extend the Payroll Tax Cut http:\/\/t.co\/6UjR9LG0",
    "id" : 148190159291166721,
    "created_at" : "2011-12-17 23:57:41 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 148249393299079168,
  "created_at" : "2011-12-18 03:53:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "148093465367023616",
  "text" : "Happening now: President Obama Delivers a Statement. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 148093465367023616,
  "created_at" : "2011-12-17 17:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "148067541695201280",
  "text" : "RT @pfeiffer44: President Obama will make a statement in the White House Briefing Room at approximately 1230ET http:\/\/t.co\/u95y7hhB",
  "id" : 148067541695201280,
  "created_at" : "2011-12-17 15:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/jJZlzUHk",
      "expanded_url" : "http:\/\/ow.ly\/82zKA",
      "display_url" : "ow.ly\/82zKA"
    } ]
  },
  "geo" : { },
  "id_str" : "148065414507798528",
  "text" : "\"This holiday season, all of us can finally say: welcome home\" -President Obama on honoring those who served in #Iraq: http:\/\/t.co\/jJZlzUHk",
  "id" : 148065414507798528,
  "created_at" : "2011-12-17 15:42:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 13, 24 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/v317o0GI",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/12\/16\/statement-white-house-communications-director-dan-pfeiffer",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147867874768338944",
  "text" : "Statement by @pfeiffer44 on tonight\u2019s deal: http:\/\/t.co\/v317o0GI",
  "id" : 147867874768338944,
  "created_at" : "2011-12-17 02:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 112, 115 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 127, 136 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147816251496992768",
  "text" : "RT @JoiningForces: Must Watch: Meet Jimmy, whose dad serves in Afghanistan. Dr. Biden hosts military kids @ the @VP's home via @ivillage ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 93, 96 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 108, 117 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/P4JT7boE",
        "expanded_url" : "http:\/\/ow.ly\/82djF",
        "display_url" : "ow.ly\/82djF"
      } ]
    },
    "geo" : { },
    "id_str" : "147815067524665344",
    "text" : "Must Watch: Meet Jimmy, whose dad serves in Afghanistan. Dr. Biden hosts military kids @ the @VP's home via @ivillage: http:\/\/t.co\/P4JT7boE",
    "id" : 147815067524665344,
    "created_at" : "2011-12-16 23:07:13 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 147816251496992768,
  "created_at" : "2011-12-16 23:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/xRkwZiMI",
      "expanded_url" : "http:\/\/1.usa.gov\/uHVp4l",
      "display_url" : "1.usa.gov\/uHVp4l"
    } ]
  },
  "geo" : { },
  "id_str" : "147810020824854528",
  "text" : "RT @aneeshchopra: Secretary Sebelius wants to hear from you to deliver health IT through entrepreneurship. http:\/\/t.co\/xRkwZiMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/xRkwZiMI",
        "expanded_url" : "http:\/\/1.usa.gov\/uHVp4l",
        "display_url" : "1.usa.gov\/uHVp4l"
      } ]
    },
    "geo" : { },
    "id_str" : "147807052184567808",
    "text" : "Secretary Sebelius wants to hear from you to deliver health IT through entrepreneurship. http:\/\/t.co\/xRkwZiMI",
    "id" : 147807052184567808,
    "created_at" : "2011-12-16 22:35:22 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 147810020824854528,
  "created_at" : "2011-12-16 22:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/147794058583097344\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/pXtYDErG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ag0R6cpCQAEjnIu.jpg",
      "id_str" : "147794058591485953",
      "id" : 147794058591485953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ag0R6cpCQAEjnIu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/pXtYDErG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/vhYg2mxa",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/16\/numbers-25-million",
      "display_url" : "whitehouse.gov\/blog\/2011\/12\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147794058583097344",
  "text" : "By the Numbers: 2.5 Million: http:\/\/t.co\/vhYg2mxa An additional 2.5 million young adults now have health insurance: http:\/\/t.co\/pXtYDErG",
  "id" : 147794058583097344,
  "created_at" : "2011-12-16 21:43:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147793481346203648",
  "text" : "RT @letsmove: Q: What are your favorite healthy holiday recipes? Share them with #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147791982272585728",
    "text" : "Q: What are your favorite healthy holiday recipes? Share them with #LetsMove",
    "id" : 147791982272585728,
    "created_at" : "2011-12-16 21:35:29 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 147793481346203648,
  "created_at" : "2011-12-16 21:41:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147791524539793408",
  "text" : "RT @jesseclee44: Odd that Rs are simultaneously insisting that they've always supported the payroll tax cut & making demands in order fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147782667272847360",
    "text" : "Odd that Rs are simultaneously insisting that they've always supported the payroll tax cut & making demands in order for them to vote for it",
    "id" : 147782667272847360,
    "created_at" : "2011-12-16 20:58:28 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 147791524539793408,
  "created_at" : "2011-12-16 21:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "URJBiennial",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "147762479479525377",
  "text" : "Happening now: President Obama speaks @ the 71st General Assembly of the Union for Reform Judaism. Watch: http:\/\/t.co\/u95y7hhB #URJBiennial",
  "id" : 147762479479525377,
  "created_at" : "2011-12-16 19:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Value Of a Veteran",
      "screen_name" : "ValueOfaVeteran",
      "indices" : [ 13, 29 ],
      "id_str" : "16930961",
      "id" : 16930961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147744975562608640",
  "text" : "RT @WHLive: .@ValueOfaVeteran Make it a priority. 1500 companies hired 25,000 vets in 4 mos. Committed to hire 135,000 more in next 2 ye ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Value Of a Veteran",
        "screen_name" : "ValueOfaVeteran",
        "indices" : [ 1, 17 ],
        "id_str" : "16930961",
        "id" : 16930961
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147744345372631041",
    "text" : ".@ValueOfaVeteran Make it a priority. 1500 companies hired 25,000 vets in 4 mos. Committed to hire 135,000 more in next 2 years.BIG! #WHChat",
    "id" : 147744345372631041,
    "created_at" : "2011-12-16 18:26:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 147744975562608640,
  "created_at" : "2011-12-16 18:28:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Value Of a Veteran",
      "screen_name" : "ValueOfaVeteran",
      "indices" : [ 3, 19 ],
      "id_str" : "16930961",
      "id" : 16930961
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 21, 35 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 116, 123 ]
    }, {
      "text" : "HR",
      "indices" : [ 124, 127 ]
    }, {
      "text" : "SHRM",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147744921003098112",
  "text" : "RT @ValueOfaVeteran: @JoiningForces Brad:  What can you tell employers about making commitments to hire #veterans ? #WHChat #HR #SHRM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 0, 14 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "HR",
        "indices" : [ 103, 106 ]
      }, {
        "text" : "SHRM",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147743065283624961",
    "in_reply_to_user_id" : 26278266,
    "text" : "@JoiningForces Brad:  What can you tell employers about making commitments to hire #veterans ? #WHChat #HR #SHRM",
    "id" : 147743065283624961,
    "created_at" : "2011-12-16 18:21:06 +0000",
    "in_reply_to_screen_name" : "JoiningForces",
    "in_reply_to_user_id_str" : "26278266",
    "user" : {
      "name" : "Value Of a Veteran",
      "screen_name" : "ValueOfaVeteran",
      "protected" : false,
      "id_str" : "16930961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510527790102228992\/5Wzd74vO_normal.jpeg",
      "id" : 16930961,
      "verified" : false
    }
  },
  "id" : 147744921003098112,
  "created_at" : "2011-12-16 18:28:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 50, 64 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147740090268000256",
  "text" : "RT @WHLive: Hi everybody -- Brad Cooper here from @JoiningForces. Ready to answer questions. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 38, 52 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147738815958749184",
    "text" : "Hi everybody -- Brad Cooper here from @JoiningForces. Ready to answer questions. #WHChat",
    "id" : 147738815958749184,
    "created_at" : "2011-12-16 18:04:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 147740090268000256,
  "created_at" : "2011-12-16 18:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/147734741364387840\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/1hoNRt8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Agzb9uxCMAAOFsB.png",
      "id_str" : "147734741368582144",
      "id" : 147734741368582144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Agzb9uxCMAAOFsB.png",
      "sizes" : [ {
        "h" : 134,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 681
      } ],
      "display_url" : "pic.twitter.com\/1hoNRt8I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "147734741364387840",
  "text" : "If Congress doesn't act, middle class taxes increase in 15 days: 11 hours: http:\/\/t.co\/cleL6Kao The clock is ticking: http:\/\/t.co\/1hoNRt8I",
  "id" : 147734741364387840,
  "created_at" : "2011-12-16 17:48:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 105, 113 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/08XkPj66",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=64G6wVsewWY&feature=share",
      "display_url" : "youtube.com\/watch?v=64G6wV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147693672144703489",
  "text" : "Check this video out -- West Wing Week: 12\/16\/11 or \"A Final March Toward Home\" http:\/\/t.co\/08XkPj66 via @youtube",
  "id" : 147693672144703489,
  "created_at" : "2011-12-16 15:04:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 27, 41 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147690526357983232",
  "text" : "RT @WHLive: Have Qs on the @JoiningForces initiative & how you can get involved? Ask with #WHChat. Exec Dir Brad Cooper will be here lat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 15, 29 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147690039747424257",
    "text" : "Have Qs on the @JoiningForces initiative & how you can get involved? Ask with #WHChat. Exec Dir Brad Cooper will be here later to answer.",
    "id" : 147690039747424257,
    "created_at" : "2011-12-16 14:50:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 147690526357983232,
  "created_at" : "2011-12-16 14:52:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 42, 56 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147467747230617600",
  "text" : "RT @WHLive: WH Office Hours: Brad Cooper, @JoiningForces Exec Director, answers your Qs at 1ET tomorrow. Use #WHChat to ask now: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 30, 44 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/yPAOVfKI",
        "expanded_url" : "http:\/\/ow.ly\/810gZ",
        "display_url" : "ow.ly\/810gZ"
      } ]
    },
    "geo" : { },
    "id_str" : "147467683678519296",
    "text" : "WH Office Hours: Brad Cooper, @JoiningForces Exec Director, answers your Qs at 1ET tomorrow. Use #WHChat to ask now: http:\/\/t.co\/yPAOVfKI",
    "id" : 147467683678519296,
    "created_at" : "2011-12-16 00:06:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 147467747230617600,
  "created_at" : "2011-12-16 00:07:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/147453903825408000\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/Auna5OYg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Agvci1bCEAAJL7E.jpg",
      "id_str" : "147453903833796608",
      "id" : 147453903833796608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Agvci1bCEAAJL7E.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Auna5OYg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/G66GETm5",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/15\/casing-colors-iraq",
      "display_url" : "whitehouse.gov\/blog\/2011\/12\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147453903825408000",
  "text" : "Casing the Colors in Iraq: Today's ceremony marks the end of Operation New Dawn: http:\/\/t.co\/G66GETm5 Photo: http:\/\/t.co\/Auna5OYg",
  "id" : 147453903825408000,
  "created_at" : "2011-12-15 23:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHInternship",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/QtcDg447",
      "expanded_url" : "http:\/\/wh.gov\/internship",
      "display_url" : "wh.gov\/internship"
    } ]
  },
  "geo" : { },
  "id_str" : "147417588643790848",
  "text" : "#WHInternship: Reason #12 to apply: \"Top-ranking officials speak to us wk after wk, incredible window into the Admin\" http:\/\/t.co\/QtcDg447",
  "id" : 147417588643790848,
  "created_at" : "2011-12-15 20:47:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanJobsAct",
      "indices" : [ 27, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/373InsAk",
      "expanded_url" : "http:\/\/go.usa.gov\/N2J",
      "display_url" : "go.usa.gov\/N2J"
    } ]
  },
  "geo" : { },
  "id_str" : "147416689821220865",
  "text" : "RT @usedgov: How would the #AmericanJobsAct affect your state & school district? Our interactive maps have the answer http:\/\/t.co\/373InsAk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericanJobsAct",
        "indices" : [ 14, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/373InsAk",
        "expanded_url" : "http:\/\/go.usa.gov\/N2J",
        "display_url" : "go.usa.gov\/N2J"
      } ]
    },
    "geo" : { },
    "id_str" : "147415122330124288",
    "text" : "How would the #AmericanJobsAct affect your state & school district? Our interactive maps have the answer http:\/\/t.co\/373InsAk",
    "id" : 147415122330124288,
    "created_at" : "2011-12-15 20:37:58 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 147416689821220865,
  "created_at" : "2011-12-15 20:44:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeToTweet",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147396050519457792",
  "text" : "Happy Bill of Rights Day! The US continues to stand with citizens & governments around the world who empower free expression. #FreeToTweet",
  "id" : 147396050519457792,
  "created_at" : "2011-12-15 19:22:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/147366698834599939\/photo\/1",
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/YdCUqsMQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AguNO1gCIAAkGCo.jpg",
      "id_str" : "147366698838794240",
      "id" : 147366698838794240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AguNO1gCIAAkGCo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/YdCUqsMQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147366698834599939",
  "text" : "First Look: Check out the new Obama family portrait in the Oval Office: http:\/\/t.co\/YdCUqsMQ",
  "id" : 147366698834599939,
  "created_at" : "2011-12-15 17:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "147363694832136192",
  "text" : "Happening now: President Obama announces proposed changes to the Fair Labor Standards Act. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 147363694832136192,
  "created_at" : "2011-12-15 17:13:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/D6jsMD5x",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/15\/we-cant-wait-meet-home-healthcare-worker-who-inspired-president",
      "display_url" : "whitehouse.gov\/blog\/2011\/12\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147359489618755584",
  "text" : "RT @JonCarson44: meet the health care worker who inspired the President http:\/\/t.co\/D6jsMD5x \nToday President took action to help worker ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/D6jsMD5x",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/15\/we-cant-wait-meet-home-healthcare-worker-who-inspired-president",
        "display_url" : "whitehouse.gov\/blog\/2011\/12\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "147355066448363520",
    "text" : "meet the health care worker who inspired the President http:\/\/t.co\/D6jsMD5x \nToday President took action to help workers like her",
    "id" : 147355066448363520,
    "created_at" : "2011-12-15 16:39:20 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 147359489618755584,
  "created_at" : "2011-12-15 16:56:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/147350911973457920\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/A3rkkeEj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Agt-363CAAAQ2L8.jpg",
      "id_str" : "147350911977652224",
      "id" : 147350911977652224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Agt-363CAAAQ2L8.jpg",
      "sizes" : [ {
        "h" : 171,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 563
      } ],
      "display_url" : "pic.twitter.com\/A3rkkeEj"
    } ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/2FNL6J64",
      "expanded_url" : "https:\/\/twitter.com\/#!\/whitehouse\/status\/147116362140090369",
      "display_url" : "twitter.com\/#!\/whitehouse\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147350911973457920",
  "text" : "In case you missed it, here's President Obama's tweet on the end of the war in #Iraq: http:\/\/t.co\/2FNL6J64 Img: http:\/\/t.co\/A3rkkeEj",
  "id" : 147350911973457920,
  "created_at" : "2011-12-15 16:22:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 3, 15 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147344227762843648",
  "text" : "RT @CommerceSec: Secretary Bryson's complete remarks on his vision to Build it Here. Sell it Everywhere can be read here - http:\/\/t.co\/S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/S5JlVEX9",
        "expanded_url" : "http:\/\/1.usa.gov\/uW7uJJ",
        "display_url" : "1.usa.gov\/uW7uJJ"
      } ]
    },
    "geo" : { },
    "id_str" : "147341731204050945",
    "text" : "Secretary Bryson's complete remarks on his vision to Build it Here. Sell it Everywhere can be read here - http:\/\/t.co\/S5JlVEX9",
    "id" : 147341731204050945,
    "created_at" : "2011-12-15 15:46:20 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 147344227762843648,
  "created_at" : "2011-12-15 15:56:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/lKSwb6qh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=b_2XS04FtTo",
      "display_url" : "youtube.com\/watch?v=b_2XS0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147338873641500672",
  "text" : "Answer: http:\/\/t.co\/lKSwb6qh \/\/ In 2007, then-Senator Obama spent a day working in someone else's shoes. What was job & name of person?",
  "id" : 147338873641500672,
  "created_at" : "2011-12-15 15:34:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147330030983331841",
  "text" : "TRIVIA QUESTION: In 2007, then-Senator Obama spent a day working in someone else's shoes. What was the job and who was the person?",
  "id" : 147330030983331841,
  "created_at" : "2011-12-15 14:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fort Bragg Community",
      "screen_name" : "FortBraggNC",
      "indices" : [ 90, 102 ],
      "id_str" : "90440365",
      "id" : 90440365
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/147326980256301056\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/6iXSOE3n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgtpG6SCAAA13Lv.jpg",
      "id_str" : "147326980264689664",
      "id" : 147326980264689664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgtpG6SCAAA13Lv.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1274,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6iXSOE3n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147326980256301056",
  "text" : "Photo of the Day: The President & First Lady arrive on the South Lawn after their trip to @FortBraggNC: http:\/\/t.co\/6iXSOE3n",
  "id" : 147326980256301056,
  "created_at" : "2011-12-15 14:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 44, 54 ],
      "id_str" : "18622869",
      "id" : 18622869
    }, {
      "name" : "Rachel Maddow MSNBC",
      "screen_name" : "maddow",
      "indices" : [ 80, 87 ],
      "id_str" : "16129920",
      "id" : 16129920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/AmbXDdqy",
      "expanded_url" : "http:\/\/maddowblog.msnbc.msn.com\/_news\/2011\/12\/14\/9441306-payroll-tax-cut-explained-by-guy-who-is-not-ezra-klein#.TuoCRZJTVjN.twitter",
      "display_url" : "maddowblog.msnbc.msn.com\/_news\/2011\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "147320511532244992",
  "text" : "Payroll tax cut explained by guy who is not @EzraKlein http:\/\/t.co\/AmbXDdqy via @maddow",
  "id" : 147320511532244992,
  "created_at" : "2011-12-15 14:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 14, 25 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147158892781109249",
  "text" : "RT @OMBPress: @pfeiffer44 on problems w\/ the omnibus; call for short-term CR so Congress can finish that, payroll and UI extension: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 0, 11 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/Uh39qW0F",
        "expanded_url" : "http:\/\/ht.ly\/7ZTj2",
        "display_url" : "ht.ly\/7ZTj2"
      } ]
    },
    "geo" : { },
    "id_str" : "147138275361038336",
    "in_reply_to_user_id" : 131144091,
    "text" : "@pfeiffer44 on problems w\/ the omnibus; call for short-term CR so Congress can finish that, payroll and UI extension: http:\/\/t.co\/Uh39qW0F",
    "id" : 147138275361038336,
    "created_at" : "2011-12-15 02:17:53 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 147158892781109249,
  "created_at" : "2011-12-15 03:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/nnY0tntr",
      "expanded_url" : "http:\/\/wh.gov\/iraq",
      "display_url" : "wh.gov\/iraq"
    } ]
  },
  "geo" : { },
  "id_str" : "147116362140090369",
  "text" : "The #Iraq war is over. Show our veterans & their families that they have the thanks of a grateful nation:\u00A0http:\/\/t.co\/nnY0tntr\u00A0\u2013bo",
  "id" : 147116362140090369,
  "created_at" : "2011-12-15 00:50:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 3, 17 ],
      "id_str" : "28576135",
      "id" : 28576135
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 54, 68 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 71, 81 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147068489562210304",
  "text" : "RT @thejointstaff: Serving Abroad\u2026Through Their Eyes: @DeptofDefense & @StateDept collecting photos to use in museums & more. Get involv ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 35, 49 ],
        "id_str" : "66369181",
        "id" : 66369181
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 52, 62 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/AHMacyTU",
        "expanded_url" : "http:\/\/1.usa.gov\/sSacWI",
        "display_url" : "1.usa.gov\/sSacWI"
      } ]
    },
    "geo" : { },
    "id_str" : "147067897594912768",
    "text" : "Serving Abroad\u2026Through Their Eyes: @DeptofDefense & @StateDept collecting photos to use in museums & more. Get involved http:\/\/t.co\/AHMacyTU",
    "id" : 147067897594912768,
    "created_at" : "2011-12-14 21:38:13 +0000",
    "user" : {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "protected" : false,
      "id_str" : "28576135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459045440063672320\/SOEE5LHU_normal.png",
      "id" : 28576135,
      "verified" : true
    }
  },
  "id" : 147068489562210304,
  "created_at" : "2011-12-14 21:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/LO4CGHdJ",
      "expanded_url" : "http:\/\/ow.ly\/7ZF6d",
      "display_url" : "ow.ly\/7ZF6d"
    } ]
  },
  "geo" : { },
  "id_str" : "147062808561983488",
  "text" : "Have you watched our new WH White Board? Brian Deese explains how Obama's payroll tax cut helps families & the economy: http:\/\/t.co\/LO4CGHdJ",
  "id" : 147062808561983488,
  "created_at" : "2011-12-14 21:18:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 77, 88 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/zokAv3qi",
      "expanded_url" : "http:\/\/owl.li\/7ZD2L",
      "display_url" : "owl.li\/7ZD2L"
    } ]
  },
  "geo" : { },
  "id_str" : "147059275326427136",
  "text" : "RT @SBAgov: Ask questions & learn about gov programs for women entrepreneurs @whitehouse \u201COpen for Questions\u201D: http:\/\/t.co\/zokAv3qi #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 65, 76 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/zokAv3qi",
        "expanded_url" : "http:\/\/owl.li\/7ZD2L",
        "display_url" : "owl.li\/7ZD2L"
      } ]
    },
    "geo" : { },
    "id_str" : "147058288054386689",
    "text" : "Ask questions & learn about gov programs for women entrepreneurs @whitehouse \u201COpen for Questions\u201D: http:\/\/t.co\/zokAv3qi #WHChat",
    "id" : 147058288054386689,
    "created_at" : "2011-12-14 21:00:02 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 147059275326427136,
  "created_at" : "2011-12-14 21:03:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/CheCu7m6",
      "expanded_url" : "http:\/\/ow.ly\/7ZC7s",
      "display_url" : "ow.ly\/7ZC7s"
    } ]
  },
  "geo" : { },
  "id_str" : "147050880854790146",
  "text" : "\"I\u2019m proud to finally say these two words: Welcome home\" -President Obama on the end of the war in #Iraq: http:\/\/t.co\/CheCu7m6",
  "id" : 147050880854790146,
  "created_at" : "2011-12-14 20:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy Castro",
      "screen_name" : "_JoyCastro",
      "indices" : [ 3, 14 ],
      "id_str" : "334317918",
      "id" : 334317918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/V7aKP1KU",
      "expanded_url" : "http:\/\/1.usa.gov\/sEe4sh",
      "display_url" : "1.usa.gov\/sEe4sh"
    } ]
  },
  "geo" : { },
  "id_str" : "147045347510853633",
  "text" : "RT @_joycastro: 6-minute video explains the payroll tax cut in terms that make sense to working families: http:\/\/t.co\/V7aKP1KU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/V7aKP1KU",
        "expanded_url" : "http:\/\/1.usa.gov\/sEe4sh",
        "display_url" : "1.usa.gov\/sEe4sh"
      } ]
    },
    "geo" : { },
    "id_str" : "146987665424793600",
    "text" : "6-minute video explains the payroll tax cut in terms that make sense to working families: http:\/\/t.co\/V7aKP1KU",
    "id" : 146987665424793600,
    "created_at" : "2011-12-14 16:19:24 +0000",
    "user" : {
      "name" : "Joy Castro",
      "screen_name" : "_JoyCastro",
      "protected" : false,
      "id_str" : "334317918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660884400645640192\/61cjrCFd_normal.jpg",
      "id" : 334317918,
      "verified" : false
    }
  },
  "id" : 147045347510853633,
  "created_at" : "2011-12-14 20:08:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147043072704917504",
  "text" : "RT @DeptVetAffairs: A 20 year Navy Vet went back to school using the Post-9\/11 GI Bill. It's never too late for an education http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/wfnm99vo",
        "expanded_url" : "http:\/\/bit.ly\/tj5K60",
        "display_url" : "bit.ly\/tj5K60"
      } ]
    },
    "geo" : { },
    "id_str" : "147041897502875649",
    "text" : "A 20 year Navy Vet went back to school using the Post-9\/11 GI Bill. It's never too late for an education http:\/\/t.co\/wfnm99vo",
    "id" : 147041897502875649,
    "created_at" : "2011-12-14 19:54:54 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 147043072704917504,
  "created_at" : "2011-12-14 19:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147019994104987648",
  "text" : "RT @DeptVetAffairs: Four Iraq Veterans are gathered around a TV at VA headquarters, listening to the President talk about the war ending.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147002354141634560",
    "text" : "Four Iraq Veterans are gathered around a TV at VA headquarters, listening to the President talk about the war ending.",
    "id" : 147002354141634560,
    "created_at" : "2011-12-14 17:17:47 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 147019994104987648,
  "created_at" : "2011-12-14 18:27:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147019780270989312",
  "text" : "RT @ENERGY: Got questions about biofuels? Join us this Friday at 1 PM EST for a live Q+A with the head of our Biomass Program, Dr. Valer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147013624337137664",
    "text" : "Got questions about biofuels? Join us this Friday at 1 PM EST for a live Q+A with the head of our Biomass Program, Dr. Valerie Reed.",
    "id" : 147013624337137664,
    "created_at" : "2011-12-14 18:02:34 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 147019780270989312,
  "created_at" : "2011-12-14 18:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147003823225970690",
  "text" : "RT @WHLive: Obama: Because of you, we are ending these wars in a way that will make America stronger & the world more secure.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147003767940841472",
    "text" : "Obama: Because of you, we are ending these wars in a way that will make America stronger & the world more secure.",
    "id" : 147003767940841472,
    "created_at" : "2011-12-14 17:23:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 147003823225970690,
  "created_at" : "2011-12-14 17:23:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147003040963100672",
  "text" : "RT @WHLive: Obama: For all of the challenges...you remind us that there\u2019s nothing that we Americans can\u2019t do when we stick together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "147003009635860481",
    "text" : "Obama: For all of the challenges...you remind us that there\u2019s nothing that we Americans can\u2019t do when we stick together.",
    "id" : 147003009635860481,
    "created_at" : "2011-12-14 17:20:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 147003040963100672,
  "created_at" : "2011-12-14 17:20:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147001933499076608",
  "text" : "Obama: Let\u2019s give a heartfelt round of applause for every military family...You have the thanks of a grateful nation.",
  "id" : 147001933499076608,
  "created_at" : "2011-12-14 17:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146998056158629888",
  "text" : "Obama: As your Commander in Chief & on behalf of a grateful nation, I\u2019m proud to finally say these 2 words...welcome home!",
  "id" : 146998056158629888,
  "created_at" : "2011-12-14 17:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 91, 96 ]
    }, {
      "text" : "military",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/jh1r5rpW",
      "expanded_url" : "http:\/\/www.defense.gov\/live",
      "display_url" : "defense.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "146996826032185344",
  "text" : "RT @DeptofDefense: LIVE NOW: President Obama at Ft. Bragg to discuss the end of the war in #Iraq http:\/\/t.co\/jh1r5rpW #military",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 72, 77 ]
      }, {
        "text" : "military",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/jh1r5rpW",
        "expanded_url" : "http:\/\/www.defense.gov\/live",
        "display_url" : "defense.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "146996691277578241",
    "text" : "LIVE NOW: President Obama at Ft. Bragg to discuss the end of the war in #Iraq http:\/\/t.co\/jh1r5rpW #military",
    "id" : 146996691277578241,
    "created_at" : "2011-12-14 16:55:16 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 146996826032185344,
  "created_at" : "2011-12-14 16:55:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 133, 140 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "146996654308986881",
  "text" : "Happening now: President & First Lady speak to troops & military families @ Fort Bragg, NC. Watch live: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 146996654308986881,
  "created_at" : "2011-12-14 16:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146991986510012418",
  "text" : "RT @JoiningForces: The President & First Lady thank troops & military families\n@ Fort Bragg as the #Iraq war comes to an end. Live @ 12E ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 80, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/TnHxhX8v",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "146985321865822208",
    "text" : "The President & First Lady thank troops & military families\n@ Fort Bragg as the #Iraq war comes to an end. Live @ 12ET: http:\/\/t.co\/TnHxhX8v",
    "id" : 146985321865822208,
    "created_at" : "2011-12-14 16:10:06 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 146991986510012418,
  "created_at" : "2011-12-14 16:36:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/Qd91Acna",
      "expanded_url" : "http:\/\/wapo.st\/sRb3tQ",
      "display_url" : "wapo.st\/sRb3tQ"
    } ]
  },
  "geo" : { },
  "id_str" : "146964030928584706",
  "text" : "RT @jesseclee44: What change looks like: 2,500,000 young adults get health coverage, up from 1M earlier this year http:\/\/t.co\/Qd91Acna #hcr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 118, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/Qd91Acna",
        "expanded_url" : "http:\/\/wapo.st\/sRb3tQ",
        "display_url" : "wapo.st\/sRb3tQ"
      } ]
    },
    "geo" : { },
    "id_str" : "146962620262518784",
    "text" : "What change looks like: 2,500,000 young adults get health coverage, up from 1M earlier this year http:\/\/t.co\/Qd91Acna #hcr",
    "id" : 146962620262518784,
    "created_at" : "2011-12-14 14:39:53 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 146964030928584706,
  "created_at" : "2011-12-14 14:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 74, 85 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatDoesItMean",
      "indices" : [ 30, 45 ]
    }, {
      "text" : "doublewhiteboard",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/1uoBHgRW",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yB1DdBP3FH0",
      "display_url" : "youtube.com\/watch?v=yB1DdB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "146956325182648320",
  "text" : "RT @macon44: Payroll tax cut, #WhatDoesItMean? Watch Deese explain in new @WhiteHouse White Board http:\/\/t.co\/1uoBHgRW #doublewhiteboard ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 61, 72 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatDoesItMean",
        "indices" : [ 17, 32 ]
      }, {
        "text" : "doublewhiteboard",
        "indices" : [ 106, 123 ]
      }, {
        "text" : "sobeautiful",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/1uoBHgRW",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yB1DdBP3FH0",
        "display_url" : "youtube.com\/watch?v=yB1DdB\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "146956007103414272",
    "text" : "Payroll tax cut, #WhatDoesItMean? Watch Deese explain in new @WhiteHouse White Board http:\/\/t.co\/1uoBHgRW #doublewhiteboard #sobeautiful",
    "id" : 146956007103414272,
    "created_at" : "2011-12-14 14:13:37 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 146956325182648320,
  "created_at" : "2011-12-14 14:14:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/MoXIHilT",
      "expanded_url" : "http:\/\/ow.ly\/7XTy6",
      "display_url" : "ow.ly\/7XTy6"
    } ]
  },
  "geo" : { },
  "id_str" : "146779107684925440",
  "text" : "RT @lacasablanca: Republicans in the Senate blocked our Ambassador to El Salvador, choosing instead to play politics: http:\/\/t.co\/MoXIHilT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/MoXIHilT",
        "expanded_url" : "http:\/\/ow.ly\/7XTy6",
        "display_url" : "ow.ly\/7XTy6"
      } ]
    },
    "geo" : { },
    "id_str" : "146634078156886017",
    "text" : "Republicans in the Senate blocked our Ambassador to El Salvador, choosing instead to play politics: http:\/\/t.co\/MoXIHilT",
    "id" : 146634078156886017,
    "created_at" : "2011-12-13 16:54:23 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 146779107684925440,
  "created_at" : "2011-12-14 02:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/nnY0tntr",
      "expanded_url" : "http:\/\/wh.gov\/iraq",
      "display_url" : "wh.gov\/iraq"
    } ]
  },
  "geo" : { },
  "id_str" : "146754473879015425",
  "text" : "After nearly 9 years, the war in #Iraq is coming to an end & our troops are coming home. Check out a timeline: http:\/\/t.co\/nnY0tntr",
  "id" : 146754473879015425,
  "created_at" : "2011-12-14 00:52:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/K5s0QKFx",
      "expanded_url" : "http:\/\/go.usa.gov\/NOe",
      "display_url" : "go.usa.gov\/NOe"
    } ]
  },
  "geo" : { },
  "id_str" : "146698585172475904",
  "text" : "RT @usedgov: ED's blog has a new name and look. Welcome to Homeroom http:\/\/t.co\/K5s0QKFx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/K5s0QKFx",
        "expanded_url" : "http:\/\/go.usa.gov\/NOe",
        "display_url" : "go.usa.gov\/NOe"
      } ]
    },
    "geo" : { },
    "id_str" : "146696937473716224",
    "text" : "ED's blog has a new name and look. Welcome to Homeroom http:\/\/t.co\/K5s0QKFx",
    "id" : 146696937473716224,
    "created_at" : "2011-12-13 21:04:10 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 146698585172475904,
  "created_at" : "2011-12-13 21:10:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/CXBreph8",
      "expanded_url" : "http:\/\/ow.ly\/7Yl2R",
      "display_url" : "ow.ly\/7Yl2R"
    } ]
  },
  "geo" : { },
  "id_str" : "146688182015098881",
  "text" : "18 days: 8 hours: 30 minutes. If Congress doesn't act, that's when middle class taxes increase. How it affects you: http:\/\/t.co\/CXBreph8",
  "id" : 146688182015098881,
  "created_at" : "2011-12-13 20:29:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 33, 38 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 39, 48 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ZgpMxPem",
      "expanded_url" : "http:\/\/ow.ly\/7Yks7",
      "display_url" : "ow.ly\/7Yks7"
    } ]
  },
  "geo" : { },
  "id_str" : "146685953849827328",
  "text" : "RT @letsmove: Happy Anniversary! @USDA @LetsMove celebrate the 1 year anniv. of the Healthy, Hunger-Free Kids Act: http:\/\/t.co\/ZgpMxPem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dept. of Agriculture",
        "screen_name" : "USDA",
        "indices" : [ 19, 24 ],
        "id_str" : "61853389",
        "id" : 61853389
      }, {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 25, 34 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/ZgpMxPem",
        "expanded_url" : "http:\/\/ow.ly\/7Yks7",
        "display_url" : "ow.ly\/7Yks7"
      } ]
    },
    "geo" : { },
    "id_str" : "146685813005107200",
    "text" : "Happy Anniversary! @USDA @LetsMove celebrate the 1 year anniv. of the Healthy, Hunger-Free Kids Act: http:\/\/t.co\/ZgpMxPem",
    "id" : 146685813005107200,
    "created_at" : "2011-12-13 20:19:57 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 146685953849827328,
  "created_at" : "2011-12-13 20:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/8Uc0Ukh4",
      "expanded_url" : "http:\/\/ow.ly\/7Yjg5",
      "display_url" : "ow.ly\/7Yjg5"
    } ]
  },
  "geo" : { },
  "id_str" : "146681165141647360",
  "text" : "As we end the war in #Iraq, we pay tribute to all Americans who have sacrificed so much. View the timeline: http:\/\/t.co\/8Uc0Ukh4",
  "id" : 146681165141647360,
  "created_at" : "2011-12-13 20:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "USTreasuryDept",
      "screen_name" : "USTreasuryDept",
      "indices" : [ 14, 29 ],
      "id_str" : "2484739350",
      "id" : 2484739350
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 44, 51 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 66, 75 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 86, 101 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cuttingwaste",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146678906093715457",
  "text" : "RT @VP: VP w\/ @USTreasuryDept Sec Geithner, @HHSGov Sec Sebelius, @OMBPress Dir Lew & @TheJusticeDept DAG Cole #cuttingwaste http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USTreasuryDept",
        "screen_name" : "USTreasuryDept",
        "indices" : [ 6, 21 ],
        "id_str" : "2484739350",
        "id" : 2484739350
      }, {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 36, 43 ],
        "id_str" : "44783853",
        "id" : 44783853
      }, {
        "name" : "OMBPress",
        "screen_name" : "OMBPress",
        "indices" : [ 58, 67 ],
        "id_str" : "337742544",
        "id" : 337742544
      }, {
        "name" : "Justice Department",
        "screen_name" : "TheJusticeDept",
        "indices" : [ 78, 93 ],
        "id_str" : "73181712",
        "id" : 73181712
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/146677525110734848\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/IR2bMp5j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AgkabpUCQAAZ8s_.jpg",
        "id_str" : "146677525114929152",
        "id" : 146677525114929152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgkabpUCQAAZ8s_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/IR2bMp5j"
      } ],
      "hashtags" : [ {
        "text" : "cuttingwaste",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "146677525110734848",
    "text" : "VP w\/ @USTreasuryDept Sec Geithner, @HHSGov Sec Sebelius, @OMBPress Dir Lew & @TheJusticeDept DAG Cole #cuttingwaste http:\/\/t.co\/IR2bMp5j",
    "id" : 146677525110734848,
    "created_at" : "2011-12-13 19:47:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 146678906093715457,
  "created_at" : "2011-12-13 19:52:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cuttingwaste",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/ASjxiBKm",
      "expanded_url" : "http:\/\/ht.ly\/7YdB7",
      "display_url" : "ht.ly\/7YdB7"
    } ]
  },
  "geo" : { },
  "id_str" : "146666456149532672",
  "text" : "RT @OMBPress: The Buck Stops Here: Jack Lew on production of excess $1 coins, and other #cuttingwaste ideas http:\/\/t.co\/ASjxiBKm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cuttingwaste",
        "indices" : [ 74, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/ASjxiBKm",
        "expanded_url" : "http:\/\/ht.ly\/7YdB7",
        "display_url" : "ht.ly\/7YdB7"
      } ]
    },
    "geo" : { },
    "id_str" : "146662655829098496",
    "text" : "The Buck Stops Here: Jack Lew on production of excess $1 coins, and other #cuttingwaste ideas http:\/\/t.co\/ASjxiBKm",
    "id" : 146662655829098496,
    "created_at" : "2011-12-13 18:47:56 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 146666456149532672,
  "created_at" : "2011-12-13 19:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/ncnpwFx4",
      "expanded_url" : "http:\/\/youtu.be\/sGu-0kYFRoU",
      "display_url" : "youtu.be\/sGu-0kYFRoU"
    } ]
  },
  "geo" : { },
  "id_str" : "146654683086323713",
  "text" : "RT @CFPB: First Lady Michelle Obama offers a special message to today's Financial Fitness Forum. http:\/\/t.co\/ncnpwFx4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/ncnpwFx4",
        "expanded_url" : "http:\/\/youtu.be\/sGu-0kYFRoU",
        "display_url" : "youtu.be\/sGu-0kYFRoU"
      } ]
    },
    "geo" : { },
    "id_str" : "146654006981312512",
    "text" : "First Lady Michelle Obama offers a special message to today's Financial Fitness Forum. http:\/\/t.co\/ncnpwFx4",
    "id" : 146654006981312512,
    "created_at" : "2011-12-13 18:13:34 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 146654683086323713,
  "created_at" : "2011-12-13 18:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "National Guard",
      "screen_name" : "NationalGuard",
      "indices" : [ 27, 41 ],
      "id_str" : "20600214",
      "id" : 20600214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "service",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146625427555880960",
  "text" : "RT @VP: Congratulations to @NationalGuard in honor of their 375th birthday today \u2013 thank you for your #service - VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Guard",
        "screen_name" : "NationalGuard",
        "indices" : [ 19, 33 ],
        "id_str" : "20600214",
        "id" : 20600214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "service",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "146617520261038080",
    "text" : "Congratulations to @NationalGuard in honor of their 375th birthday today \u2013 thank you for your #service - VP",
    "id" : 146617520261038080,
    "created_at" : "2011-12-13 15:48:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 146625427555880960,
  "created_at" : "2011-12-13 16:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/nnY0tntr",
      "expanded_url" : "http:\/\/wh.gov\/iraq",
      "display_url" : "wh.gov\/iraq"
    } ]
  },
  "geo" : { },
  "id_str" : "146617493404925953",
  "text" : "After nearly 9 years of sacrifice, America\u2019s war in Iraq is coming to an end. Experience the interactive timeline: http:\/\/t.co\/nnY0tntr",
  "id" : 146617493404925953,
  "created_at" : "2011-12-13 15:48:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/eN6BriNu",
      "expanded_url" : "http:\/\/ow.ly\/7Xdu0",
      "display_url" : "ow.ly\/7Xdu0"
    } ]
  },
  "geo" : { },
  "id_str" : "146372589915353088",
  "text" : "From the Archives: President Obama meets with Prime Minister Maliki in 2009: http:\/\/t.co\/eN6BriNu",
  "id" : 146372589915353088,
  "created_at" : "2011-12-12 23:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/mJPrWcZo",
      "expanded_url" : "http:\/\/www.wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "146363939037523968",
  "text" : "We can't wait: If Congress doesn't act, middle class taxes increase in 19 days, 5 hours, 59 minutes: http:\/\/t.co\/mJPrWcZo",
  "id" : 146363939037523968,
  "created_at" : "2011-12-12 23:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 70, 84 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Blue Star Families",
      "screen_name" : "BlueStarFamily",
      "indices" : [ 87, 102 ],
      "id_str" : "15909372",
      "id" : 15909372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "volunteer",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "honorcards",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/5pnXjZIh",
      "expanded_url" : "http:\/\/go.usa.gov\/5JN",
      "display_url" : "go.usa.gov\/5JN"
    } ]
  },
  "geo" : { },
  "id_str" : "146361534162026498",
  "text" : "RT @ServeDotGov: 14,000,000 #volunteer hrs pledged via #honorcards w\/ @joiningforces & @bluestarfamily. http:\/\/t.co\/5pnXjZIh Made yours  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 53, 67 ],
        "id_str" : "26278266",
        "id" : 26278266
      }, {
        "name" : "Blue Star Families",
        "screen_name" : "BlueStarFamily",
        "indices" : [ 70, 85 ],
        "id_str" : "15909372",
        "id" : 15909372
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "volunteer",
        "indices" : [ 11, 21 ]
      }, {
        "text" : "honorcards",
        "indices" : [ 38, 49 ]
      }, {
        "text" : "militarymon",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/5pnXjZIh",
        "expanded_url" : "http:\/\/go.usa.gov\/5JN",
        "display_url" : "go.usa.gov\/5JN"
      } ]
    },
    "geo" : { },
    "id_str" : "146274915572649984",
    "text" : "14,000,000 #volunteer hrs pledged via #honorcards w\/ @joiningforces & @bluestarfamily. http:\/\/t.co\/5pnXjZIh Made yours yet? #militarymon",
    "id" : 146274915572649984,
    "created_at" : "2011-12-12 17:07:12 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 146361534162026498,
  "created_at" : "2011-12-12 22:51:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Dowd  \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "katiewdowd",
      "indices" : [ 3, 14 ],
      "id_str" : "12193642",
      "id" : 12193642
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 30, 40 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146342772377518080",
  "text" : "RT @katiewdowd: Did you hear? @StateDept just passed 200K #twitter followers! Yay! Great to see the conversation expanding and growing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 14, 24 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitter",
        "indices" : [ 42, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "146342271980290048",
    "text" : "Did you hear? @StateDept just passed 200K #twitter followers! Yay! Great to see the conversation expanding and growing.",
    "id" : 146342271980290048,
    "created_at" : "2011-12-12 21:34:51 +0000",
    "user" : {
      "name" : "Katie Dowd  \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "katiewdowd",
      "protected" : false,
      "id_str" : "12193642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654047435438825477\/lsyyjk3G_normal.jpg",
      "id" : 12193642,
      "verified" : false
    }
  },
  "id" : 146342772377518080,
  "created_at" : "2011-12-12 21:36:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 25, 36 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/tHAeo3Uo",
      "expanded_url" : "http:\/\/go.usa.gov\/5hf",
      "display_url" : "go.usa.gov\/5hf"
    } ]
  },
  "geo" : { },
  "id_str" : "146337863791939584",
  "text" : "RT @StateDept: Latest on @WhiteHouse Blog: President Obama Welcomes Iraqi Prime Minister Nouri al-Maliki http:\/\/t.co\/tHAeo3Uo #Iraq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/tHAeo3Uo",
        "expanded_url" : "http:\/\/go.usa.gov\/5hf",
        "display_url" : "go.usa.gov\/5hf"
      } ]
    },
    "geo" : { },
    "id_str" : "146337127406387200",
    "text" : "Latest on @WhiteHouse Blog: President Obama Welcomes Iraqi Prime Minister Nouri al-Maliki http:\/\/t.co\/tHAeo3Uo #Iraq",
    "id" : 146337127406387200,
    "created_at" : "2011-12-12 21:14:24 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 146337863791939584,
  "created_at" : "2011-12-12 21:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/APmS8i4Z",
      "expanded_url" : "http:\/\/ow.ly\/7X3VN",
      "display_url" : "ow.ly\/7X3VN"
    } ]
  },
  "geo" : { },
  "id_str" : "146333105131757568",
  "text" : "\"This is a season of homecomings & military families across America are being reunited for the holidays\" -Pres Obama http:\/\/t.co\/APmS8i4Z",
  "id" : 146333105131757568,
  "created_at" : "2011-12-12 20:58:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 110, 121 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146280181122867200",
  "text" : "RT @StateDept: Live Now! President Obama and Prime Minister al-Maliki of #Iraq hold a press conference at the @WhiteHouse. Watch on http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 95, 106 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 58, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/HUZms8Lq",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "146279941154148352",
    "text" : "Live Now! President Obama and Prime Minister al-Maliki of #Iraq hold a press conference at the @WhiteHouse. Watch on http:\/\/t.co\/HUZms8Lq.",
    "id" : 146279941154148352,
    "created_at" : "2011-12-12 17:27:10 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 146280181122867200,
  "created_at" : "2011-12-12 17:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JSOnline - NewsWatch",
      "screen_name" : "js_newswatch",
      "indices" : [ 3, 16 ],
      "id_str" : "15137097",
      "id" : 15137097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/yxrH3sN4",
      "expanded_url" : "http:\/\/bit.ly\/sS1ddz",
      "display_url" : "bit.ly\/sS1ddz"
    } ]
  },
  "geo" : { },
  "id_str" : "146271536800731136",
  "text" : "RT @js_newswatch: Obama establishes an Office of Manufacturing Policy http:\/\/t.co\/yxrH3sN4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/yxrH3sN4",
        "expanded_url" : "http:\/\/bit.ly\/sS1ddz",
        "display_url" : "bit.ly\/sS1ddz"
      } ]
    },
    "geo" : { },
    "id_str" : "146257592967118848",
    "text" : "Obama establishes an Office of Manufacturing Policy http:\/\/t.co\/yxrH3sN4",
    "id" : 146257592967118848,
    "created_at" : "2011-12-12 15:58:22 +0000",
    "user" : {
      "name" : "JSOnline - NewsWatch",
      "screen_name" : "js_newswatch",
      "protected" : false,
      "id_str" : "15137097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000675263479\/2470d7473c62e2e867f14b79926b6c3e_normal.jpeg",
      "id" : 15137097,
      "verified" : true
    }
  },
  "id" : 146271536800731136,
  "created_at" : "2011-12-12 16:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146265629375209473",
  "text" : "RT @WHLive: Happening @ 11:35ET: President Obama & Prime Minister Maliki of Iraq hold a joint press conference. Watch live: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/NMr2mHh9",
        "expanded_url" : "http:\/\/ow.ly\/7WG4a",
        "display_url" : "ow.ly\/7WG4a"
      } ]
    },
    "geo" : { },
    "id_str" : "146265586387791872",
    "text" : "Happening @ 11:35ET: President Obama & Prime Minister Maliki of Iraq hold a joint press conference. Watch live: http:\/\/t.co\/NMr2mHh9",
    "id" : 146265586387791872,
    "created_at" : "2011-12-12 16:30:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 146265629375209473,
  "created_at" : "2011-12-12 16:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/JvL5zdlQ",
      "expanded_url" : "http:\/\/ow.ly\/7Wwiu",
      "display_url" : "ow.ly\/7Wwiu"
    } ]
  },
  "geo" : { },
  "id_str" : "146245296375083008",
  "text" : "RT @letsmove: We broke the jumping jacks World Record! First Lady Michelle Obama announces some exciting news. Watch: http:\/\/t.co\/JvL5zdlQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/JvL5zdlQ",
        "expanded_url" : "http:\/\/ow.ly\/7Wwiu",
        "display_url" : "ow.ly\/7Wwiu"
      } ]
    },
    "geo" : { },
    "id_str" : "146245169220558848",
    "text" : "We broke the jumping jacks World Record! First Lady Michelle Obama announces some exciting news. Watch: http:\/\/t.co\/JvL5zdlQ",
    "id" : 146245169220558848,
    "created_at" : "2011-12-12 15:09:00 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 146245296375083008,
  "created_at" : "2011-12-12 15:09:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146233947079184384",
  "text" : "RT @pfeiffer44: Iraqi PM Maliki visits the White House today and holds a joint press conf with the President as the War in Iraq comes to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "146205206345039873",
    "text" : "Iraqi PM Maliki visits the White House today and holds a joint press conf with the President as the War in Iraq comes to an end this year",
    "id" : 146205206345039873,
    "created_at" : "2011-12-12 12:30:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 146233947079184384,
  "created_at" : "2011-12-12 14:24:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Engelman",
      "screen_name" : "momonashoe",
      "indices" : [ 3, 14 ],
      "id_str" : "40988939",
      "id" : 40988939
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 88, 97 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iVoices",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/diXlFFEY",
      "expanded_url" : "http:\/\/soc.li\/OhVok1S",
      "display_url" : "soc.li\/OhVok1S"
    } ]
  },
  "geo" : { },
  "id_str" : "145916246045622272",
  "text" : "RT @momonashoe: Have a Burning Question for Jill Biden, Wife of the Vice President? via @ivillage http:\/\/t.co\/diXlFFEY #iVoices",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 72, 81 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iVoices",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/diXlFFEY",
        "expanded_url" : "http:\/\/soc.li\/OhVok1S",
        "display_url" : "soc.li\/OhVok1S"
      } ]
    },
    "geo" : { },
    "id_str" : "145874583617155073",
    "text" : "Have a Burning Question for Jill Biden, Wife of the Vice President? via @ivillage http:\/\/t.co\/diXlFFEY #iVoices",
    "id" : 145874583617155073,
    "created_at" : "2011-12-11 14:36:25 +0000",
    "user" : {
      "name" : "Beth Engelman",
      "screen_name" : "momonashoe",
      "protected" : false,
      "id_str" : "40988939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2230680831\/Beth_Engelman_small_normal.jpg",
      "id" : 40988939,
      "verified" : false
    }
  },
  "id" : 145916246045622272,
  "created_at" : "2011-12-11 17:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 73, 80 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 85, 92 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/145644664043737088\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/YSATvBye",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgVvDOBCEAAhxbJ.jpg",
      "id_str" : "145644664052125696",
      "id" : 145644664052125696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgVvDOBCEAAhxbJ.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/YSATvBye"
    } ],
    "hashtags" : [ {
      "text" : "ArmyNavy",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145652300394921984",
  "text" : "RT @VP: PHOTO: VP with the Navy Midshipmen during the second half of the @USArmy vs. @USNavy football game #ArmyNavy http:\/\/t.co\/YSATvBye",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 65, 72 ],
        "id_str" : "8775672",
        "id" : 8775672
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 77, 84 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/145644664043737088\/photo\/1",
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/YSATvBye",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AgVvDOBCEAAhxbJ.jpg",
        "id_str" : "145644664052125696",
        "id" : 145644664052125696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgVvDOBCEAAhxbJ.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/YSATvBye"
      } ],
      "hashtags" : [ {
        "text" : "ArmyNavy",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145644664043737088",
    "text" : "PHOTO: VP with the Navy Midshipmen during the second half of the @USArmy vs. @USNavy football game #ArmyNavy http:\/\/t.co\/YSATvBye",
    "id" : 145644664043737088,
    "created_at" : "2011-12-10 23:22:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 145652300394921984,
  "created_at" : "2011-12-10 23:53:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rosie",
      "screen_name" : "rlbrown3",
      "indices" : [ 3, 12 ],
      "id_str" : "2161662877",
      "id" : 2161662877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145618809020092416",
  "text" : "RT @RLBrown3: Giant American flag unfurled & all 2,000+ Cadets & Midshipmen singing \"God Bless the USA\" together. Stunning scene at #Arm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArmyNavy",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145617595347906560",
    "text" : "Giant American flag unfurled & all 2,000+ Cadets & Midshipmen singing \"God Bless the USA\" together. Stunning scene at #ArmyNavy.",
    "id" : 145617595347906560,
    "created_at" : "2011-12-10 21:35:14 +0000",
    "user" : {
      "name" : "Drinker of rum.",
      "screen_name" : "TheRobBrownShow",
      "protected" : false,
      "id_str" : "16779974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774049573400477696\/LeI1NhZO_normal.jpg",
      "id" : 16779974,
      "verified" : false
    }
  },
  "id" : 145618809020092416,
  "created_at" : "2011-12-10 21:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/D4bIBSBQ",
      "expanded_url" : "http:\/\/goo.gl\/fb\/s49Kl",
      "display_url" : "goo.gl\/fb\/s49Kl"
    } ]
  },
  "geo" : { },
  "id_str" : "145609939837128704",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: Weekly Address: Ensuring a Fair Shot for the Middle Class http:\/\/t.co\/D4bIBSBQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/D4bIBSBQ",
        "expanded_url" : "http:\/\/goo.gl\/fb\/s49Kl",
        "display_url" : "goo.gl\/fb\/s49Kl"
      } ]
    },
    "geo" : { },
    "id_str" : "145459299496378368",
    "text" : "http:\/\/t.co\/HxTO58SB: Weekly Address: Ensuring a Fair Shot for the Middle Class http:\/\/t.co\/D4bIBSBQ",
    "id" : 145459299496378368,
    "created_at" : "2011-12-10 11:06:14 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 145609939837128704,
  "created_at" : "2011-12-10 21:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmyNavy",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "GoArmy",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "GoNavy",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145584165528670209",
  "text" : "RT @DeptofDefense: Watch the #ArmyNavy game live at 2:30 p.m. EST on CBS. #GoArmy #GoNavy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArmyNavy",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "GoArmy",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "GoNavy",
        "indices" : [ 63, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145582355896205312",
    "text" : "Watch the #ArmyNavy game live at 2:30 p.m. EST on CBS. #GoArmy #GoNavy",
    "id" : 145582355896205312,
    "created_at" : "2011-12-10 19:15:13 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 145584165528670209,
  "created_at" : "2011-12-10 19:22:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 3, 10 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmyNavy",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/WTozv9yW",
      "expanded_url" : "http:\/\/ow.ly\/1BNU3k",
      "display_url" : "ow.ly\/1BNU3k"
    } ]
  },
  "geo" : { },
  "id_str" : "145551218788417536",
  "text" : "RT @USNavy: Share your pregame moments-show off that Navy pride. Best ones RT'd.  We will go first- http:\/\/t.co\/WTozv9yW  #ArmyNavy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArmyNavy",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/WTozv9yW",
        "expanded_url" : "http:\/\/ow.ly\/1BNU3k",
        "display_url" : "ow.ly\/1BNU3k"
      } ]
    },
    "geo" : { },
    "id_str" : "145490824917037056",
    "text" : "Share your pregame moments-show off that Navy pride. Best ones RT'd.  We will go first- http:\/\/t.co\/WTozv9yW  #ArmyNavy",
    "id" : 145490824917037056,
    "created_at" : "2011-12-10 13:11:30 +0000",
    "user" : {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "protected" : false,
      "id_str" : "54885400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785776641066708992\/nEqdAKde_normal.jpg",
      "id" : 54885400,
      "verified" : true
    }
  },
  "id" : 145551218788417536,
  "created_at" : "2011-12-10 17:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 38, 45 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USArmy",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "ArmyNavy",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145550981684408322",
  "text" : "RT @USArmy: Tweeting from the #USArmy\/@USNavy football game today? Remember to tag your tweets with #ArmyNavy - GO Army!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 26, 33 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USArmy",
        "indices" : [ 18, 25 ]
      }, {
        "text" : "ArmyNavy",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145487801734021120",
    "text" : "Tweeting from the #USArmy\/@USNavy football game today? Remember to tag your tweets with #ArmyNavy - GO Army!",
    "id" : 145487801734021120,
    "created_at" : "2011-12-10 12:59:29 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 145550981684408322,
  "created_at" : "2011-12-10 17:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Burdo",
      "screen_name" : "SteveBurdo",
      "indices" : [ 3, 14 ],
      "id_str" : "48655836",
      "id" : 48655836
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145360869679841281",
  "text" : "RT @SteveBurdo: @whitehouse In honor of my grandfather who stayed afloat at sea for 3 days when his destroyer was destroyed n WW2 - GO N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoNavy",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145360338735472641",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse In honor of my grandfather who stayed afloat at sea for 3 days when his destroyer was destroyed n WW2 - GO Navy! #GoNavy",
    "id" : 145360338735472641,
    "created_at" : "2011-12-10 04:33:00 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Stephen Burdo",
      "screen_name" : "SteveBurdo",
      "protected" : false,
      "id_str" : "48655836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1400528014\/SB_Pic_normal.jpg",
      "id" : 48655836,
      "verified" : false
    }
  },
  "id" : 145360869679841281,
  "created_at" : "2011-12-10 04:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Scraper",
      "screen_name" : "itrainer1",
      "indices" : [ 3, 13 ],
      "id_str" : "109282104",
      "id" : 109282104
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145360832321171456",
  "text" : "RT @itrainer1: @whitehouse My son is a squad leader with the Wounded Warrior proj and will be at the game w\/some of his squad. Proud of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "goarmy",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145358395694780416",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse My son is a squad leader with the Wounded Warrior proj and will be at the game w\/some of his squad. Proud of his service #goarmy",
    "id" : 145358395694780416,
    "created_at" : "2011-12-10 04:25:16 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Mike Scraper",
      "screen_name" : "itrainer1",
      "protected" : false,
      "id_str" : "109282104",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661525928\/Buddycopy_normal.png",
      "id" : 109282104,
      "verified" : false
    }
  },
  "id" : 145360832321171456,
  "created_at" : "2011-12-10 04:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peg Mitchell",
      "screen_name" : "PegMitchell1",
      "indices" : [ 3, 16 ],
      "id_str" : "344843534",
      "id" : 344843534
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoArmy",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "GoNavy",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "ArmyNavy",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145354679507877889",
  "text" : "RT @PegMitchell1: @whitehouse Can it be a tie? My dad was an Army lifer and my son is a Navy SEAL! #GoArmy #GoNavy #ArmyNavy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoArmy",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "GoNavy",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "ArmyNavy",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145353981697339395",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Can it be a tie? My dad was an Army lifer and my son is a Navy SEAL! #GoArmy #GoNavy #ArmyNavy",
    "id" : 145353981697339395,
    "created_at" : "2011-12-10 04:07:44 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Peg Mitchell",
      "screen_name" : "PegMitchell1",
      "protected" : false,
      "id_str" : "344843534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797609879674318848\/bMcJvtEB_normal.jpg",
      "id" : 344843534,
      "verified" : false
    }
  },
  "id" : 145354679507877889,
  "created_at" : "2011-12-10 04:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katherine lorio",
      "screen_name" : "klorio",
      "indices" : [ 3, 10 ],
      "id_str" : "91120541",
      "id" : 91120541
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoNavy",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145353071424307200",
  "text" : "RT @klorio: @whitehouse in honor of my dad, a Vietnam veteran who raised three female Navy veterans. #GoNavy # BeatArmy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoNavy",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145346034481106944",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse in honor of my dad, a Vietnam veteran who raised three female Navy veterans. #GoNavy # BeatArmy",
    "id" : 145346034481106944,
    "created_at" : "2011-12-10 03:36:09 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "katherine lorio",
      "screen_name" : "klorio",
      "protected" : false,
      "id_str" : "91120541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781263640179597312\/Hcedardq_normal.jpg",
      "id" : 91120541,
      "verified" : false
    }
  },
  "id" : 145353071424307200,
  "created_at" : "2011-12-10 04:04:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatum N. Smith",
      "screen_name" : "UAtatey",
      "indices" : [ 3, 11 ],
      "id_str" : "32058488",
      "id" : 32058488
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoArmy",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145352934413180928",
  "text" : "RT @UAtatey: @whitehouse  the love of my life is a disabled veteran so #GoArmy !!!!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoArmy",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145346194179227648",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse  the love of my life is a disabled veteran so #GoArmy !!!!!!!",
    "id" : 145346194179227648,
    "created_at" : "2011-12-10 03:36:47 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Tatum N. Smith",
      "screen_name" : "UAtatey",
      "protected" : false,
      "id_str" : "32058488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679491411276881920\/Flvw3_l0_normal.jpg",
      "id" : 32058488,
      "verified" : false
    }
  },
  "id" : 145352934413180928,
  "created_at" : "2011-12-10 04:03:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Stanfield",
      "screen_name" : "Ben_Stanfield",
      "indices" : [ 3, 17 ],
      "id_str" : "21016484",
      "id" : 21016484
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145344217496035328",
  "text" : "RT @Ben_Stanfield: @whitehouse I have ties to neither, but I am a proud American that will enjoy the game! GO USA!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145343389297152002",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I have ties to neither, but I am a proud American that will enjoy the game! GO USA!",
    "id" : 145343389297152002,
    "created_at" : "2011-12-10 03:25:39 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Ben Stanfield",
      "screen_name" : "Ben_Stanfield",
      "protected" : false,
      "id_str" : "21016484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788423635291795456\/lbqAHMmc_normal.jpg",
      "id" : 21016484,
      "verified" : false
    }
  },
  "id" : 145344217496035328,
  "created_at" : "2011-12-10 03:28:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lucytwoshoes",
      "screen_name" : "Txgrobie",
      "indices" : [ 3, 12 ],
      "id_str" : "26850130",
      "id" : 26850130
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145342440088403968",
  "text" : "RT @Txgrobie: @whitehouse my nephew graduated from US Naval Academy, #GoNavy#BeatArmy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145341409241726976",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse my nephew graduated from US Naval Academy, #GoNavy#BeatArmy.",
    "id" : 145341409241726976,
    "created_at" : "2011-12-10 03:17:46 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "lucytwoshoes",
      "screen_name" : "Txgrobie",
      "protected" : false,
      "id_str" : "26850130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/280305426\/green_9268_default_profile_normal_normal.jpg",
      "id" : 26850130,
      "verified" : false
    }
  },
  "id" : 145342440088403968,
  "created_at" : "2011-12-10 03:21:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terri",
      "screen_name" : "terrifaerie",
      "indices" : [ 3, 15 ],
      "id_str" : "135054857",
      "id" : 135054857
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 29, 36 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 37, 44 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145315432524554240",
  "text" : "RT @terrifaerie: @whitehouse @USNavy @USArmy My husband is a Marine vet. GO NAVY all the way!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 12, 19 ],
        "id_str" : "54885400",
        "id" : 54885400
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 20, 27 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145313990581555200",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @USNavy @USArmy My husband is a Marine vet. GO NAVY all the way!",
    "id" : 145313990581555200,
    "created_at" : "2011-12-10 01:28:49 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Terri",
      "screen_name" : "terrifaerie",
      "protected" : false,
      "id_str" : "135054857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493403000505774080\/a7GV28V0_normal.jpeg",
      "id" : 135054857,
      "verified" : false
    }
  },
  "id" : 145315432524554240,
  "created_at" : "2011-12-10 01:34:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoArmy",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "BeatNavy",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145315395547574272",
  "text" : "RT @MeganLynFolger: @whitehouse From a future Army wife, #GoArmy! #BeatNavy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoArmy",
        "indices" : [ 37, 44 ]
      }, {
        "text" : "BeatNavy",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145313833551007744",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse From a future Army wife, #GoArmy! #BeatNavy",
    "id" : 145313833551007744,
    "created_at" : "2011-12-10 01:28:12 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Megan McReynolds",
      "screen_name" : "MeganMcReynolds",
      "protected" : false,
      "id_str" : "354991528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1619918449\/image_normal.jpg",
      "id" : 354991528,
      "verified" : false
    }
  },
  "id" : 145315395547574272,
  "created_at" : "2011-12-10 01:34:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Marlin Hicks",
      "screen_name" : "iPodDr",
      "indices" : [ 3, 10 ],
      "id_str" : "173973184",
      "id" : 173973184
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145311952288219136",
  "text" : "RT @iPodDr: @whitehouse USN, Ret. GO NAVY!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 35.1805217848, -86.0117991676 ]
    },
    "id_str" : "145309779865239552",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse USN, Ret. GO NAVY!",
    "id" : 145309779865239552,
    "created_at" : "2011-12-10 01:12:05 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "William Marlin Hicks",
      "screen_name" : "iPodDr",
      "protected" : false,
      "id_str" : "173973184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2187723509\/image_normal.jpg",
      "id" : 173973184,
      "verified" : false
    }
  },
  "id" : 145311952288219136,
  "created_at" : "2011-12-10 01:20:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa Mankin",
      "screen_name" : "teresamankin",
      "indices" : [ 3, 16 ],
      "id_str" : "301506749",
      "id" : 301506749
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 59, 66 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145311831764910083",
  "text" : "RT @TeresaMankin: @whitehouse Im a former Army journalist. @usarmy ALL THE WAY. GO Black Knights!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 41, 48 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145311119316226048",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Im a former Army journalist. @usarmy ALL THE WAY. GO Black Knights!",
    "id" : 145311119316226048,
    "created_at" : "2011-12-10 01:17:25 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Teresa Mankin",
      "screen_name" : "teresamankin",
      "protected" : false,
      "id_str" : "301506749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641696442336313345\/K4XuyOWQ_normal.jpg",
      "id" : 301506749,
      "verified" : false
    }
  },
  "id" : 145311831764910083,
  "created_at" : "2011-12-10 01:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 3, 10 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 36, 43 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USNavy",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "ArmyNavy",
      "indices" : [ 109, 118 ]
    }, {
      "text" : "fight",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145303446566871040",
  "text" : "RT @USNavy: Will u be tweeting from @USArmy vs. #USNavy football game Saturday? Be sure 2 tag ur tweets with #ArmyNavy - GO NAVY! #fight&win",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 24, 31 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USNavy",
        "indices" : [ 36, 43 ]
      }, {
        "text" : "ArmyNavy",
        "indices" : [ 97, 106 ]
      }, {
        "text" : "fight",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145302976104382464",
    "text" : "Will u be tweeting from @USArmy vs. #USNavy football game Saturday? Be sure 2 tag ur tweets with #ArmyNavy - GO NAVY! #fight&win",
    "id" : 145302976104382464,
    "created_at" : "2011-12-10 00:45:03 +0000",
    "user" : {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "protected" : false,
      "id_str" : "54885400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785776641066708992\/nEqdAKde_normal.jpg",
      "id" : 54885400,
      "verified" : true
    }
  },
  "id" : 145303446566871040,
  "created_at" : "2011-12-10 00:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pigmation Media",
      "screen_name" : "Hamletrules",
      "indices" : [ 3, 15 ],
      "id_str" : "193350607",
      "id" : 193350607
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 28, 35 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 60, 67 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145295576756527104",
  "text" : "RT @Hamletrules: (Navy Vet) @USNavy Go Navy 38 to I'll give @USArmy a fieldgoal 3, But whomever wins all of you deserve our thanks",
  "id" : 145295576756527104,
  "created_at" : "2011-12-10 00:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Giaconia",
      "screen_name" : "Jgiaconia001",
      "indices" : [ 3, 16 ],
      "id_str" : "185806314",
      "id" : 185806314
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 18, 25 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BEATNAVY",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "staysafe",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145295576823635968",
  "text" : "RT @Jgiaconia001: @usarmy My brother just finished a tour overseas GO ARMY #BEATNAVY but thanks to all the vets #staysafe\"",
  "id" : 145295576823635968,
  "created_at" : "2011-12-10 00:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick_bolzan",
      "screen_name" : "catevz",
      "indices" : [ 3, 10 ],
      "id_str" : "2562288966",
      "id" : 2562288966
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 107, 118 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoNavy",
      "indices" : [ 43, 50 ]
    }, {
      "text" : "GoArmy",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "GoAirForce",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "GoMarines",
      "indices" : [ 77, 87 ]
    }, {
      "text" : "GoCoastGuard",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145291539277557760",
  "text" : "RT @catevz: In my book, you're all heroes! #GoNavy #GoArmy (heck #GoAirForce #GoMarines #GoCoastGuard ...) @WhiteHouse http:\/\/t.co\/Qc8Rk ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 95, 106 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoNavy",
        "indices" : [ 31, 38 ]
      }, {
        "text" : "GoArmy",
        "indices" : [ 39, 46 ]
      }, {
        "text" : "GoAirForce",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "GoMarines",
        "indices" : [ 65, 75 ]
      }, {
        "text" : "GoCoastGuard",
        "indices" : [ 76, 89 ]
      }, {
        "text" : "ThankYou",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/Qc8RkNha",
        "expanded_url" : "http:\/\/1.usa.gov\/u3LG6q",
        "display_url" : "1.usa.gov\/u3LG6q"
      } ]
    },
    "geo" : { },
    "id_str" : "145290999449649152",
    "text" : "In my book, you're all heroes! #GoNavy #GoArmy (heck #GoAirForce #GoMarines #GoCoastGuard ...) @WhiteHouse http:\/\/t.co\/Qc8RkNha #ThankYou",
    "id" : 145290999449649152,
    "created_at" : "2011-12-09 23:57:28 +0000",
    "user" : {
      "name" : "Valley Cat",
      "screen_name" : "catabyte",
      "protected" : false,
      "id_str" : "15209873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796276389133492225\/llCTc-WQ_normal.jpg",
      "id" : 15209873,
      "verified" : false
    }
  },
  "id" : 145291539277557760,
  "created_at" : "2011-12-09 23:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee A, Dugas",
      "screen_name" : "LeeDugas2001",
      "indices" : [ 3, 16 ],
      "id_str" : "65846554",
      "id" : 65846554
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "David Chavarria",
      "screen_name" : "josechavarria",
      "indices" : [ 30, 44 ],
      "id_str" : "25750978",
      "id" : 25750978
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 45, 52 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 53, 60 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145287117713571841",
  "text" : "RT @LeeDugas2001: @whitehouse @josechavarria @USNavy @USArmy I am disabled Navy Seabee Go Navy!!!!!!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "David Chavarria",
        "screen_name" : "josechavarria",
        "indices" : [ 12, 26 ],
        "id_str" : "25750978",
        "id" : 25750978
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 27, 34 ],
        "id_str" : "54885400",
        "id" : 54885400
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 35, 42 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "145282789334450177",
    "geo" : { },
    "id_str" : "145286716184465408",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @josechavarria @USNavy @USArmy I am disabled Navy Seabee Go Navy!!!!!!!!!",
    "id" : 145286716184465408,
    "in_reply_to_status_id" : 145282789334450177,
    "created_at" : "2011-12-09 23:40:27 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Lee A, Dugas",
      "screen_name" : "LeeDugas2001",
      "protected" : false,
      "id_str" : "65846554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1223335330\/14319521_normal.jpg",
      "id" : 65846554,
      "verified" : false
    }
  },
  "id" : 145287117713571841,
  "created_at" : "2011-12-09 23:42:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Curry",
      "screen_name" : "stargazer_412",
      "indices" : [ 3, 17 ],
      "id_str" : "49608873",
      "id" : 49608873
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Shannon",
      "screen_name" : "starsstripes",
      "indices" : [ 31, 44 ],
      "id_str" : "24296369",
      "id" : 24296369
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 45, 52 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 53, 60 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmyNavy",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145287060402618368",
  "text" : "RT @stargazer_412: @whitehouse @StarsStripes @USNavy @USArmy #ArmyNavy AF brat w\/ ex-Army sister.  Go ARMY!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Shannon",
        "screen_name" : "starsstripes",
        "indices" : [ 12, 25 ],
        "id_str" : "24296369",
        "id" : 24296369
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 26, 33 ],
        "id_str" : "54885400",
        "id" : 54885400
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 34, 41 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArmyNavy",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "145278840665677824",
    "geo" : { },
    "id_str" : "145285981485019136",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @StarsStripes @USNavy @USArmy #ArmyNavy AF brat w\/ ex-Army sister.  Go ARMY!",
    "id" : 145285981485019136,
    "in_reply_to_status_id" : 145278840665677824,
    "created_at" : "2011-12-09 23:37:31 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kim Curry",
      "screen_name" : "stargazer_412",
      "protected" : false,
      "id_str" : "49608873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582923063794253824\/y1bDdNlg_normal.jpg",
      "id" : 49608873,
      "verified" : false
    }
  },
  "id" : 145287060402618368,
  "created_at" : "2011-12-09 23:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Bedard",
      "screen_name" : "marcelbedard",
      "indices" : [ 3, 16 ],
      "id_str" : "12049372",
      "id" : 12049372
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145284936142823425",
  "text" : "RT @marcelbedard: @whitehouse  Army all the way.  Hooah!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145284665773789184",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse  Army all the way.  Hooah!",
    "id" : 145284665773789184,
    "created_at" : "2011-12-09 23:32:18 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Marcel Bedard",
      "screen_name" : "marcelbedard",
      "protected" : false,
      "id_str" : "12049372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569829134873145344\/jXvZuVlu_normal.jpeg",
      "id" : 12049372,
      "verified" : false
    }
  },
  "id" : 145284936142823425,
  "created_at" : "2011-12-09 23:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Rodgers",
      "screen_name" : "flitterby79",
      "indices" : [ 3, 15 ],
      "id_str" : "47673994",
      "id" : 47673994
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Shannon",
      "screen_name" : "starsstripes",
      "indices" : [ 29, 42 ],
      "id_str" : "24296369",
      "id" : 24296369
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 43, 50 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 51, 58 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145284906338103296",
  "text" : "RT @flitterby79: @whitehouse @starsstripes @usnavy @usarmy GO NAVY!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Shannon",
        "screen_name" : "starsstripes",
        "indices" : [ 12, 25 ],
        "id_str" : "24296369",
        "id" : 24296369
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 26, 33 ],
        "id_str" : "54885400",
        "id" : 54885400
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 34, 41 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "145278840665677824",
    "geo" : { },
    "id_str" : "145284496609116160",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @starsstripes @usnavy @usarmy GO NAVY!!!!",
    "id" : 145284496609116160,
    "in_reply_to_status_id" : 145278840665677824,
    "created_at" : "2011-12-09 23:31:37 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Crystal Rodgers",
      "screen_name" : "flitterby79",
      "protected" : false,
      "id_str" : "47673994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2899501847\/aee74dc017a922a624c598d155c2678b_normal.jpeg",
      "id" : 47673994,
      "verified" : false
    }
  },
  "id" : 145284906338103296,
  "created_at" : "2011-12-09 23:33:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DWJ",
      "screen_name" : "theaofa",
      "indices" : [ 43, 51 ],
      "id_str" : "17720756",
      "id" : 17720756
    }, {
      "name" : "Erin Sutherland",
      "screen_name" : "erincarly",
      "indices" : [ 52, 62 ],
      "id_str" : "43346498",
      "id" : 43346498
    }, {
      "name" : "Tom Bridge",
      "screen_name" : "tbridge",
      "indices" : [ 63, 71 ],
      "id_str" : "11011",
      "id" : 11011
    }, {
      "name" : "DorothyStJames",
      "screen_name" : "DorothyStJames",
      "indices" : [ 72, 87 ],
      "id_str" : "2516786924",
      "id" : 2516786924
    }, {
      "name" : "Beachmom01",
      "screen_name" : "Beachmom01",
      "indices" : [ 88, 99 ],
      "id_str" : "49385922",
      "id" : 49385922
    }, {
      "name" : "Dennis Bonilla",
      "screen_name" : "harbingeralpha",
      "indices" : [ 100, 115 ],
      "id_str" : "15010721",
      "id" : 15010721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "ff",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Be6Ok4mB",
      "expanded_url" : "http:\/\/ow.ly\/7UNrc",
      "display_url" : "ow.ly\/7UNrc"
    } ]
  },
  "geo" : { },
  "id_str" : "145283994727096320",
  "text" : "#FollowFriday #WHTweetup: @clarendoncultur @theaofa @erincarly @tbridge @DorothyStJames @Beachmom01 @harbingeralpha http:\/\/t.co\/Be6Ok4mB #ff",
  "id" : 145283994727096320,
  "created_at" : "2011-12-09 23:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Chavarria",
      "screen_name" : "josechavarria",
      "indices" : [ 3, 17 ],
      "id_str" : "25750978",
      "id" : 25750978
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 31, 38 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 39, 46 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145282789334450177",
  "text" : "RT @josechavarria: @whitehouse @USNavy @USArmy I am a retired Army NCO..hmmm who do you think Im rooting for? GO ARMY!!!",
  "id" : 145282789334450177,
  "created_at" : "2011-12-09 23:24:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon",
      "screen_name" : "starsstripes",
      "indices" : [ 1, 14 ],
      "id_str" : "24296369",
      "id" : 24296369
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 121, 128 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 132, 139 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmyNavy",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/L6nRL0fP",
      "expanded_url" : "http:\/\/1.usa.gov\/sw0tM8",
      "display_url" : "1.usa.gov\/sw0tM8"
    } ]
  },
  "geo" : { },
  "id_str" : "145278840665677824",
  "text" : ".@StarsStripes: #ArmyNavy pre-game social media fight http:\/\/t.co\/L6nRL0fP Let's stir the pot - Who are you rooting for? @USNavy or @USArmy?",
  "id" : 145278840665677824,
  "created_at" : "2011-12-09 23:09:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145275309179158529",
  "text" : "RT @DeptVetAffairs: Big news coming Monday on the fight to end Veteran homelessness. Stay tuned.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145236001558773760",
    "text" : "Big news coming Monday on the fight to end Veteran homelessness. Stay tuned.",
    "id" : 145236001558773760,
    "created_at" : "2011-12-09 20:18:55 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 145275309179158529,
  "created_at" : "2011-12-09 22:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/mTOJ3XRT",
      "expanded_url" : "http:\/\/ow.ly\/7UCTM",
      "display_url" : "ow.ly\/7UCTM"
    } ]
  },
  "geo" : { },
  "id_str" : "145236360024952832",
  "text" : "If Congress doesn't act, middle class taxes increase in 22 days: 8 hours: 39 minutes: 47 seconds. We can't wait: http:\/\/t.co\/mTOJ3XRT",
  "id" : 145236360024952832,
  "created_at" : "2011-12-09 20:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145215454594609152",
  "text" : "\"We should be known for creating & selling products all around the wrld that are stamped w\/ 3 proud words: Made in America\" -President Obama",
  "id" : 145215454594609152,
  "created_at" : "2011-12-09 18:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 30, 41 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145209588310999040",
  "text" : "RT @VP: Learn more about VP & @arneduncan visit to Duncan HS in Neptune Beach, FL to talk college affordability BLOG POST http:\/\/t.co\/eW ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 22, 33 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/eWQLO8pO",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/09\/vice-president-talks-college-affordability-florida",
        "display_url" : "whitehouse.gov\/blog\/2011\/12\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "145207672793341953",
    "text" : "Learn more about VP & @arneduncan visit to Duncan HS in Neptune Beach, FL to talk college affordability BLOG POST http:\/\/t.co\/eWQLO8pO",
    "id" : 145207672793341953,
    "created_at" : "2011-12-09 18:26:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 145209588310999040,
  "created_at" : "2011-12-09 18:33:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 97, 106 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/jWAVOgsR",
      "expanded_url" : "http:\/\/ow.ly\/7UmdP",
      "display_url" : "ow.ly\/7UmdP"
    } ]
  },
  "geo" : { },
  "id_str" : "145186612224069633",
  "text" : "RT @JoiningForces: What's your question for Dr. Jill Biden about #JoiningForces? Chime in now on @iVillage: http:\/\/t.co\/jWAVOgsR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 78, 87 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/jWAVOgsR",
        "expanded_url" : "http:\/\/ow.ly\/7UmdP",
        "display_url" : "ow.ly\/7UmdP"
      } ]
    },
    "geo" : { },
    "id_str" : "145186363086610432",
    "text" : "What's your question for Dr. Jill Biden about #JoiningForces? Chime in now on @iVillage: http:\/\/t.co\/jWAVOgsR",
    "id" : 145186363086610432,
    "created_at" : "2011-12-09 17:01:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 145186612224069633,
  "created_at" : "2011-12-09 17:02:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 66, 73 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 78, 85 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmyNavy",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "Pentagon",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145172254387482624",
  "text" : "RT @DeptofDefense: Getting ready for the #ArmyNavy game tomorrow! @USArmy and @USNavy academy bands at the #Pentagon today. Can you hear ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 47, 54 ],
        "id_str" : "8775672",
        "id" : 8775672
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 59, 66 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArmyNavy",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "Pentagon",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145160777127571456",
    "text" : "Getting ready for the #ArmyNavy game tomorrow! @USArmy and @USNavy academy bands at the #Pentagon today. Can you hear them?",
    "id" : 145160777127571456,
    "created_at" : "2011-12-09 15:20:00 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 145172254387482624,
  "created_at" : "2011-12-09 16:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/IqV46VB2",
      "expanded_url" : "http:\/\/ow.ly\/7TGfo",
      "display_url" : "ow.ly\/7TGfo"
    } ]
  },
  "geo" : { },
  "id_str" : "144980072087044096",
  "text" : "23 days: 1 hour: 39 minutes. If Congress doesn't act, taxes will go up for 160 million Americans. Learn more: http:\/\/t.co\/IqV46VB2",
  "id" : 144980072087044096,
  "created_at" : "2011-12-09 03:21:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/9a86bgDV",
      "expanded_url" : "http:\/\/bit.ly\/tGEng6",
      "display_url" : "bit.ly\/tGEng6"
    } ]
  },
  "geo" : { },
  "id_str" : "144920373341859840",
  "text" : "Obama: \"Ask Osama bin Laden & the 22-out-of-30 top al Qaeda leaders ... whether I engage in appeasement.\" http:\/\/t.co\/9a86bgDV",
  "id" : 144920373341859840,
  "created_at" : "2011-12-08 23:24:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144914377320054784",
  "text" : "RT @jesseclee44: True & Amazing Fact: 20 GOP Senators voted 4 times against Payroll Tax Cut in 2 weeks, including 2 versions from McConnell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144907768288129024",
    "text" : "True & Amazing Fact: 20 GOP Senators voted 4 times against Payroll Tax Cut in 2 weeks, including 2 versions from McConnell",
    "id" : 144907768288129024,
    "created_at" : "2011-12-08 22:34:38 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 144914377320054784,
  "created_at" : "2011-12-08 23:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/5QTPZ7Sv",
      "expanded_url" : "http:\/\/ow.ly\/7Tqx6",
      "display_url" : "ow.ly\/7Tqx6"
    } ]
  },
  "geo" : { },
  "id_str" : "144891893115920384",
  "text" : "\"We are not giving up\" -President Obama on confirming Richard Cordray & extending the payroll tax cut. Watch: http:\/\/t.co\/5QTPZ7Sv",
  "id" : 144891893115920384,
  "created_at" : "2011-12-08 21:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 12, 22 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Scott Case",
      "screen_name" : "tscottcase",
      "indices" : [ 23, 34 ],
      "id_str" : "31455332",
      "id" : 31455332
    }, {
      "name" : "OLD Reid Hoffman",
      "screen_name" : "quixotic",
      "indices" : [ 35, 44 ],
      "id_str" : "1120330062",
      "id" : 1120330062
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 76, 91 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144856563704803328",
  "text" : "Have Qs for @stevecase @tscottcase @quixotic? They're @WhiteHouse today for @startupamerica board mtg. Ask your Qs on startups w\/ #WHChat",
  "id" : 144856563704803328,
  "created_at" : "2011-12-08 19:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 65, 77 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144848341677772804",
  "text" : "RT @SteveCase: At @WhiteHouse and just finished great meeting w\/ @BarackObama to talk about unleashing next wave of U.S. entrepreneurshi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 3, 14 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 50, 62 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 123, 138 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144845766849085440",
    "text" : "At @WhiteHouse and just finished great meeting w\/ @BarackObama to talk about unleashing next wave of U.S. entrepreneurship @startupamerica",
    "id" : 144845766849085440,
    "created_at" : "2011-12-08 18:28:16 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 144848341677772804,
  "created_at" : "2011-12-08 18:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "NetFreedom",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "Hague",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/0KdBvzVA",
      "expanded_url" : "http:\/\/go.usa.gov\/5AV",
      "display_url" : "go.usa.gov\/5AV"
    } ]
  },
  "geo" : { },
  "id_str" : "144826945509662721",
  "text" : "RT @StateDept: #SecClinton to deliver remarks on #NetFreedom at The #Hague today at 12:20 PM EST. Watch live: http:\/\/t.co\/0KdBvzVA @usem ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Embassy The Hague",
        "screen_name" : "usembthehague",
        "indices" : [ 116, 130 ],
        "id_str" : "64403845",
        "id" : 64403845
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "NetFreedom",
        "indices" : [ 34, 45 ]
      }, {
        "text" : "Hague",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "iFreedom",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/0KdBvzVA",
        "expanded_url" : "http:\/\/go.usa.gov\/5AV",
        "display_url" : "go.usa.gov\/5AV"
      } ]
    },
    "geo" : { },
    "id_str" : "144790742336933888",
    "text" : "#SecClinton to deliver remarks on #NetFreedom at The #Hague today at 12:20 PM EST. Watch live: http:\/\/t.co\/0KdBvzVA @usembthehague #iFreedom",
    "id" : 144790742336933888,
    "created_at" : "2011-12-08 14:49:37 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 144826945509662721,
  "created_at" : "2011-12-08 17:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/144823982145802240\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/ZxxlxF1t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgKEpPsCEAAxczW.jpg",
      "id_str" : "144823982149996544",
      "id" : 144823982149996544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgKEpPsCEAAxczW.jpg",
      "sizes" : [ {
        "h" : 379,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 841
      } ],
      "display_url" : "pic.twitter.com\/ZxxlxF1t"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "144823982145802240",
  "text" : "23 days: 11 hours: 58 minutes: http:\/\/t.co\/cleL6Kao Live now in the briefing room: Obama on why we can't wait: http:\/\/t.co\/ZxxlxF1t",
  "id" : 144823982145802240,
  "created_at" : "2011-12-08 17:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144821592717926400",
  "text" : "RT @jesseclee44: Obama on Cordray & recess appointment possibility: Continuing to push Senate, \"won't take any options off the table\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144821250257190912",
    "text" : "Obama on Cordray & recess appointment possibility: Continuing to push Senate, \"won't take any options off the table\"",
    "id" : 144821250257190912,
    "created_at" : "2011-12-08 16:50:51 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 144821592717926400,
  "created_at" : "2011-12-08 16:52:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 100, 105 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "144819162055839744",
  "text" : "Happening now: Obama kicks off daily briefing discussing GOP obstruction of Cordray's nomination to @CFPB. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 144819162055839744,
  "created_at" : "2011-12-08 16:42:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 100, 105 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "144813780210171904",
  "text" : "Today @ 11:30ET, Obama will speak on Republican obstruction of Richard Cordray\u2019s nomination to head @CFPB. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 144813780210171904,
  "created_at" : "2011-12-08 16:21:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 39, 45 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 48, 63 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/nrCLIFN9",
      "expanded_url" : "http:\/\/b.qr.ae\/sk4gy9",
      "display_url" : "b.qr.ae\/sk4gy9"
    } ]
  },
  "geo" : { },
  "id_str" : "144802570798514177",
  "text" : "RT @aneeshchopra: Check out my post on @Quora - @StartupAmerica Policy Challenge: We Want to Hear from You. http:\/\/t.co\/nrCLIFN9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quora",
        "screen_name" : "Quora",
        "indices" : [ 21, 27 ],
        "id_str" : "33696409",
        "id" : 33696409
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 30, 45 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/nrCLIFN9",
        "expanded_url" : "http:\/\/b.qr.ae\/sk4gy9",
        "display_url" : "b.qr.ae\/sk4gy9"
      } ]
    },
    "geo" : { },
    "id_str" : "144802266023596032",
    "text" : "Check out my post on @Quora - @StartupAmerica Policy Challenge: We Want to Hear from You. http:\/\/t.co\/nrCLIFN9",
    "id" : 144802266023596032,
    "created_at" : "2011-12-08 15:35:25 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 144802570798514177,
  "created_at" : "2011-12-08 15:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 86, 91 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/wy4GxHZi",
      "expanded_url" : "http:\/\/ow.ly\/7SXkY",
      "display_url" : "ow.ly\/7SXkY"
    } ]
  },
  "geo" : { },
  "id_str" : "144802091473436672",
  "text" : "Consumers deserve to have someone whose job it is to look out for their interests.The @CFPB needs its director: http:\/\/t.co\/wy4GxHZi",
  "id" : 144802091473436672,
  "created_at" : "2011-12-08 15:34:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Startup Florida",
      "screen_name" : "startupfl",
      "indices" : [ 74, 84 ],
      "id_str" : "405064671",
      "id" : 405064671
    }, {
      "name" : "StartupMass",
      "screen_name" : "StartupMass",
      "indices" : [ 85, 97 ],
      "id_str" : "395121718",
      "id" : 395121718
    }, {
      "name" : "Startup Connecticut",
      "screen_name" : "StartupCT",
      "indices" : [ 98, 108 ],
      "id_str" : "343366512",
      "id" : 343366512
    }, {
      "name" : "StartupTN",
      "screen_name" : "StartupTN",
      "indices" : [ 109, 119 ],
      "id_str" : "296854309",
      "id" : 296854309
    }, {
      "name" : "Startup Illinois",
      "screen_name" : "StartupIllinois",
      "indices" : [ 120, 136 ],
      "id_str" : "301627448",
      "id" : 301627448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/IdZmhmB7",
      "expanded_url" : "http:\/\/ar.gy\/o9K",
      "display_url" : "ar.gy\/o9K"
    } ]
  },
  "geo" : { },
  "id_str" : "144782087629705218",
  "text" : "RT @startupamerica: We're heading to the @WhiteHouse http:\/\/t.co\/IdZmhmB7 @StartupFL @StartupMass @StartupCT @StartupTN @StartupIllinois",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Startup Florida",
        "screen_name" : "startupfl",
        "indices" : [ 54, 64 ],
        "id_str" : "405064671",
        "id" : 405064671
      }, {
        "name" : "StartupMass",
        "screen_name" : "StartupMass",
        "indices" : [ 65, 77 ],
        "id_str" : "395121718",
        "id" : 395121718
      }, {
        "name" : "Startup Connecticut",
        "screen_name" : "StartupCT",
        "indices" : [ 78, 88 ],
        "id_str" : "343366512",
        "id" : 343366512
      }, {
        "name" : "StartupTN",
        "screen_name" : "StartupTN",
        "indices" : [ 89, 99 ],
        "id_str" : "296854309",
        "id" : 296854309
      }, {
        "name" : "Startup Illinois",
        "screen_name" : "StartupIllinois",
        "indices" : [ 100, 116 ],
        "id_str" : "301627448",
        "id" : 301627448
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/IdZmhmB7",
        "expanded_url" : "http:\/\/ar.gy\/o9K",
        "display_url" : "ar.gy\/o9K"
      } ]
    },
    "geo" : { },
    "id_str" : "144775754071281665",
    "text" : "We're heading to the @WhiteHouse http:\/\/t.co\/IdZmhmB7 @StartupFL @StartupMass @StartupCT @StartupTN @StartupIllinois",
    "id" : 144775754071281665,
    "created_at" : "2011-12-08 13:50:04 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 144782087629705218,
  "created_at" : "2011-12-08 14:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/144561151601152000\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/L5GHu5Tm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgGVmfnCEAAnEP0.jpg",
      "id_str" : "144561151605346304",
      "id" : 144561151605346304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgGVmfnCEAAnEP0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/L5GHu5Tm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/p8rLaEC1",
      "expanded_url" : "http:\/\/1.usa.gov\/v0cvXN",
      "display_url" : "1.usa.gov\/v0cvXN"
    } ]
  },
  "geo" : { },
  "id_str" : "144561151601152000",
  "text" : "By the Numbers: $4.2 Billion: http:\/\/t.co\/p8rLaEC1 Payday loan borrowers are paying nearly $4.2 billion\/year: http:\/\/t.co\/L5GHu5Tm",
  "id" : 144561151601152000,
  "created_at" : "2011-12-07 23:37:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/hbxbigf5",
      "expanded_url" : "http:\/\/ow.ly\/7Sk2V",
      "display_url" : "ow.ly\/7Sk2V"
    } ]
  },
  "geo" : { },
  "id_str" : "144551665670950912",
  "text" : "RT @lacasablanca: \u201CEn Estados Unidos, somos mejores juntos\u201D -Presidente Obama: http:\/\/t.co\/hbxbigf5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/hbxbigf5",
        "expanded_url" : "http:\/\/ow.ly\/7Sk2V",
        "display_url" : "ow.ly\/7Sk2V"
      } ]
    },
    "geo" : { },
    "id_str" : "144550857046900736",
    "text" : "\u201CEn Estados Unidos, somos mejores juntos\u201D -Presidente Obama: http:\/\/t.co\/hbxbigf5",
    "id" : 144550857046900736,
    "created_at" : "2011-12-07 22:56:24 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 144551665670950912,
  "created_at" : "2011-12-07 22:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/144549970148724738\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/NGwcnjM6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AgGLbpeCEAA_ffb.jpg",
      "id_str" : "144549970157113344",
      "id" : 144549970157113344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AgGLbpeCEAA_ffb.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NGwcnjM6"
    } ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "Kansas",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144549970148724738",
  "text" : "Photo of the Day: President Obama waves to people gathered along the motorcade route in #Osawatomie #Kansas: http:\/\/t.co\/NGwcnjM6",
  "id" : 144549970148724738,
  "created_at" : "2011-12-07 22:52:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "144493358398713856",
  "text" : "If Congress doesn't act, middle class taxes increase in 24 days: 9 hours: 53 minutes. Learn how it affects you: http:\/\/t.co\/cleL6Kao",
  "id" : 144493358398713856,
  "created_at" : "2011-12-07 19:07:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/QqTPqA8L",
      "expanded_url" : "http:\/\/ow.ly\/7RWYr",
      "display_url" : "ow.ly\/7RWYr"
    } ]
  },
  "geo" : { },
  "id_str" : "144482221313626113",
  "text" : "Happening Now: Live chat w\/ Jason Furman of the National Economic Council. Join us & ask a Q about jobs & the economy @ http:\/\/t.co\/QqTPqA8L",
  "id" : 144482221313626113,
  "created_at" : "2011-12-07 18:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "upnorthlive.com",
      "screen_name" : "upnorthlive",
      "indices" : [ 3, 15 ],
      "id_str" : "20791073",
      "id" : 20791073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UpNorthWH",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/3YVHD25D",
      "expanded_url" : "http:\/\/bit.ly\/w1flSD",
      "display_url" : "bit.ly\/w1flSD"
    } ]
  },
  "geo" : { },
  "id_str" : "144473041827659777",
  "text" : "RT @upnorthlive: Live chat with White House insider is less than two hours away. http:\/\/t.co\/3YVHD25D #UpNorthWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UpNorthWH",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/3YVHD25D",
        "expanded_url" : "http:\/\/bit.ly\/w1flSD",
        "display_url" : "bit.ly\/w1flSD"
      } ]
    },
    "geo" : { },
    "id_str" : "144449195456212992",
    "text" : "Live chat with White House insider is less than two hours away. http:\/\/t.co\/3YVHD25D #UpNorthWH",
    "id" : 144449195456212992,
    "created_at" : "2011-12-07 16:12:26 +0000",
    "user" : {
      "name" : "upnorthlive.com",
      "screen_name" : "upnorthlive",
      "protected" : false,
      "id_str" : "20791073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120994240\/upnorthlive_normal.JPG",
      "id" : 20791073,
      "verified" : true
    }
  },
  "id" : 144473041827659777,
  "created_at" : "2011-12-07 17:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/CEeZg3Jx",
      "expanded_url" : "http:\/\/1.usa.gov\/vXNGV0",
      "display_url" : "1.usa.gov\/vXNGV0"
    } ]
  },
  "geo" : { },
  "id_str" : "144468042666082305",
  "text" : "RT @todd_park: Calling all innovators -- answer the Health Care Innovation Challenge http:\/\/t.co\/CEeZg3Jx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/CEeZg3Jx",
        "expanded_url" : "http:\/\/1.usa.gov\/vXNGV0",
        "display_url" : "1.usa.gov\/vXNGV0"
      } ]
    },
    "geo" : { },
    "id_str" : "144455118488731649",
    "text" : "Calling all innovators -- answer the Health Care Innovation Challenge http:\/\/t.co\/CEeZg3Jx",
    "id" : 144455118488731649,
    "created_at" : "2011-12-07 16:35:58 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 144468042666082305,
  "created_at" : "2011-12-07 17:27:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/paH2x4Tl",
      "expanded_url" : "http:\/\/go.usa.gov\/5fq",
      "display_url" : "go.usa.gov\/5fq"
    } ]
  },
  "geo" : { },
  "id_str" : "144445138788302849",
  "text" : "RT @arneduncan: \"It starts by making education a national mission\" -President Obama in #Osawatomie, KS. http:\/\/t.co\/paH2x4Tl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Osawatomie",
        "indices" : [ 71, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/paH2x4Tl",
        "expanded_url" : "http:\/\/go.usa.gov\/5fq",
        "display_url" : "go.usa.gov\/5fq"
      } ]
    },
    "geo" : { },
    "id_str" : "144443958834118656",
    "text" : "\"It starts by making education a national mission\" -President Obama in #Osawatomie, KS. http:\/\/t.co\/paH2x4Tl",
    "id" : 144443958834118656,
    "created_at" : "2011-12-07 15:51:38 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 144445138788302849,
  "created_at" : "2011-12-07 15:56:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/lHklaxEC",
      "expanded_url" : "http:\/\/ow.ly\/7RHgl",
      "display_url" : "ow.ly\/7RHgl"
    } ]
  },
  "geo" : { },
  "id_str" : "144444831677165568",
  "text" : "President Obama talked about how this is a make or break moment for the middle class in #Osawatomie. Watch the speech: http:\/\/t.co\/lHklaxEC",
  "id" : 144444831677165568,
  "created_at" : "2011-12-07 15:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "144438854731055107",
  "text" : "24 days: 13 hours: 28 minutes: 42 seconds. If Congress doesn't act, that's when middle class taxes will increase: http:\/\/t.co\/cleL6Kao",
  "id" : 144438854731055107,
  "created_at" : "2011-12-07 15:31:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/weJoFy1M",
      "expanded_url" : "http:\/\/bit.ly\/uDDbBz",
      "display_url" : "bit.ly\/uDDbBz"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ysbINvGa",
      "expanded_url" : "http:\/\/bit.ly\/t8hDlj",
      "display_url" : "bit.ly\/t8hDlj"
    } ]
  },
  "geo" : { },
  "id_str" : "144435042914025472",
  "text" : "RT @jesseclee44: Reich: \"The Most Important Economic Speech of His Presidency\" http:\/\/t.co\/weJoFy1M  Speech video: http:\/\/t.co\/ysbINvGa #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 119, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/weJoFy1M",
        "expanded_url" : "http:\/\/bit.ly\/uDDbBz",
        "display_url" : "bit.ly\/uDDbBz"
      }, {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/ysbINvGa",
        "expanded_url" : "http:\/\/bit.ly\/t8hDlj",
        "display_url" : "bit.ly\/t8hDlj"
      } ]
    },
    "geo" : { },
    "id_str" : "144423489305190400",
    "text" : "Reich: \"The Most Important Economic Speech of His Presidency\" http:\/\/t.co\/weJoFy1M  Speech video: http:\/\/t.co\/ysbINvGa #p2",
    "id" : 144423489305190400,
    "created_at" : "2011-12-07 14:30:17 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 144435042914025472,
  "created_at" : "2011-12-07 15:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "mtvU",
      "screen_name" : "mtvU",
      "indices" : [ 29, 34 ],
      "id_str" : "18333645",
      "id" : 18333645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/bZ2cX36y",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/CampusChallenge",
      "display_url" : "whitehouse.gov\/CampusChallenge"
    } ]
  },
  "geo" : { },
  "id_str" : "144434742996123648",
  "text" : "RT @JonCarson44: @whitehouse @mtvU Campus \u201CChampions of Change\u201D Challenge submission deadline is this Friday 12\/9 http:\/\/t.co\/bZ2cX36y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "mtvU",
        "screen_name" : "mtvU",
        "indices" : [ 12, 17 ],
        "id_str" : "18333645",
        "id" : 18333645
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/bZ2cX36y",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/CampusChallenge",
        "display_url" : "whitehouse.gov\/CampusChallenge"
      } ]
    },
    "geo" : { },
    "id_str" : "144429748628631553",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @mtvU Campus \u201CChampions of Change\u201D Challenge submission deadline is this Friday 12\/9 http:\/\/t.co\/bZ2cX36y",
    "id" : 144429748628631553,
    "created_at" : "2011-12-07 14:55:10 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 144434742996123648,
  "created_at" : "2011-12-07 15:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Zfmuc6U8",
      "expanded_url" : "http:\/\/ow.ly\/7RxSv",
      "display_url" : "ow.ly\/7RxSv"
    } ]
  },
  "geo" : { },
  "id_str" : "144420882557829120",
  "text" : "\"In America, we are greater together\" -President Obama: http:\/\/t.co\/Zfmuc6U8",
  "id" : 144420882557829120,
  "created_at" : "2011-12-07 14:19:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/4P2ibLAe",
      "expanded_url" : "http:\/\/goo.gl\/fb\/wgnGg",
      "display_url" : "goo.gl\/fb\/wgnGg"
    } ]
  },
  "geo" : { },
  "id_str" : "144262678213431296",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: What a Fair Shot at Success Means http:\/\/t.co\/4P2ibLAe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/4P2ibLAe",
        "expanded_url" : "http:\/\/goo.gl\/fb\/wgnGg",
        "display_url" : "goo.gl\/fb\/wgnGg"
      } ]
    },
    "geo" : { },
    "id_str" : "144251014478966784",
    "text" : "http:\/\/t.co\/HxTO58SB: What a Fair Shot at Success Means http:\/\/t.co\/4P2ibLAe",
    "id" : 144251014478966784,
    "created_at" : "2011-12-07 03:04:56 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 144262678213431296,
  "created_at" : "2011-12-07 03:51:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144205157872304130",
  "text" : "RT @jesseclee44: WH Counsel Kathryn Ruemmler on Caitlin Halligan: \"Judicial System Continues To Fall Victim To Republican Obstruction\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/8DHiqzi8",
        "expanded_url" : "http:\/\/huff.to\/t1wUYL",
        "display_url" : "huff.to\/t1wUYL"
      } ]
    },
    "geo" : { },
    "id_str" : "144204911335317506",
    "text" : "WH Counsel Kathryn Ruemmler on Caitlin Halligan: \"Judicial System Continues To Fall Victim To Republican Obstruction\" http:\/\/t.co\/8DHiqzi8",
    "id" : 144204911335317506,
    "created_at" : "2011-12-07 00:01:44 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 144205157872304130,
  "created_at" : "2011-12-07 00:02:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144171646658412544",
  "text" : "RT @JonCarson44: Have you read the President's speech in Kansas today yet?  I'm hearing from everyone how impactful they thought it was",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144163338845290497",
    "text" : "Have you read the President's speech in Kansas today yet?  I'm hearing from everyone how impactful they thought it was",
    "id" : 144163338845290497,
    "created_at" : "2011-12-06 21:16:33 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 144171646658412544,
  "created_at" : "2011-12-06 21:49:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "WallStreetReform",
      "indices" : [ 38, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144153833415778305",
  "text" : "RT @OMBPress: POTUS at #Osawatomie on #WallStreetReform: \"I will veto any effort to delay, defund, or dismantle the new rules we put in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Osawatomie",
        "indices" : [ 9, 20 ]
      }, {
        "text" : "WallStreetReform",
        "indices" : [ 24, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144151326425747456",
    "text" : "POTUS at #Osawatomie on #WallStreetReform: \"I will veto any effort to delay, defund, or dismantle the new rules we put in place.\"",
    "id" : 144151326425747456,
    "created_at" : "2011-12-06 20:28:49 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 144153833415778305,
  "created_at" : "2011-12-06 20:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144144094124453888",
  "text" : "Did you watch President Obama's speech in #Osawatomie? Share some of your favorite quotes with us.",
  "id" : 144144094124453888,
  "created_at" : "2011-12-06 20:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144143318836719617",
  "text" : "\"I believe America is on its way up\" -President Obama in #Osawatomie, Kansas",
  "id" : 144143318836719617,
  "created_at" : "2011-12-06 19:56:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144143124514607105",
  "text" : "RT @WHLive: Obama: We still have a stake in each other\u2019s success. We still believe that this should be a place where you can make it if  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144143076036849665",
    "text" : "Obama: We still have a stake in each other\u2019s success. We still believe that this should be a place where you can make it if you try.",
    "id" : 144143076036849665,
    "created_at" : "2011-12-06 19:56:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144143124514607105,
  "created_at" : "2011-12-06 19:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144142255010222080",
  "text" : "RT @WHLive: Obama: Our success has never just been about survival of the fittest. It\u2019s been about building a nation where we\u2019re all bett ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144142222055579648",
    "text" : "Obama: Our success has never just been about survival of the fittest. It\u2019s been about building a nation where we\u2019re all better off.",
    "id" : 144142222055579648,
    "created_at" : "2011-12-06 19:52:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144142255010222080,
  "created_at" : "2011-12-06 19:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144141065996349440",
  "text" : "RT @jesseclee44: Obama on Wall St Reform & CFPB: \"hear me, Kansas: I will veto any effort to delay, defund or dismantle the new rules we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144140656963629056",
    "text" : "Obama on Wall St Reform & CFPB: \"hear me, Kansas: I will veto any effort to delay, defund or dismantle the new rules we put in place\"",
    "id" : 144140656963629056,
    "created_at" : "2011-12-06 19:46:25 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 144141065996349440,
  "created_at" : "2011-12-06 19:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144138962297036801",
  "text" : "\"This isn\u2019t about class warfare. This is about the nation\u2019s welfare.\" -President Obama in #Osawatomie, KS",
  "id" : 144138962297036801,
  "created_at" : "2011-12-06 19:39:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144138768444690432",
  "text" : "RT @WHLive: Obama: It is wrong for Warren Buffett\u2019s secretary to pay a higher tax rate than Warren Buffett & he agrees with me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144138716523413504",
    "text" : "Obama: It is wrong for Warren Buffett\u2019s secretary to pay a higher tax rate than Warren Buffett & he agrees with me.",
    "id" : 144138716523413504,
    "created_at" : "2011-12-06 19:38:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144138768444690432,
  "created_at" : "2011-12-06 19:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144138060068691969",
  "text" : "RT @WHLive: Obama: We need to extend a payroll tax cut\u2026If we don\u2019t do that, 160 million Americans will see their taxes go up by an avera ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144138027407638528",
    "text" : "Obama: We need to extend a payroll tax cut\u2026If we don\u2019t do that, 160 million Americans will see their taxes go up by an average of $1,000",
    "id" : 144138027407638528,
    "created_at" : "2011-12-06 19:35:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144138060068691969,
  "created_at" : "2011-12-06 19:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144137047890866176",
  "text" : "Obama: \"We should be known for creating & selling products all over the world that are stamped with 3 proud words: Made in America\"",
  "id" : 144137047890866176,
  "created_at" : "2011-12-06 19:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144131490224148480",
  "text" : "RT @WHLive: Obama: I believe that this country succeeds when everyone gets a fair shot\u2026does their fair share\u2026plays by the same rules.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144131457907040256",
    "text" : "Obama: I believe that this country succeeds when everyone gets a fair shot\u2026does their fair share\u2026plays by the same rules.",
    "id" : 144131457907040256,
    "created_at" : "2011-12-06 19:09:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144131490224148480,
  "created_at" : "2011-12-06 19:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144131132370337793",
  "text" : "RT @WHLive: Obama in #Osawatomie: This is a make or break moment for the middle class & all those who are fighting to get into the middl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Osawatomie",
        "indices" : [ 9, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144131090389532672",
    "text" : "Obama in #Osawatomie: This is a make or break moment for the middle class & all those who are fighting to get into the middle class.",
    "id" : 144131090389532672,
    "created_at" : "2011-12-06 19:08:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144131132370337793,
  "created_at" : "2011-12-06 19:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144131041697857536",
  "text" : "RT @WHLive: Obama: But #Osawatomie this isn\u2019t just another political debate.  This is the defining issue of our time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Osawatomie",
        "indices" : [ 11, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144131001222832133",
    "text" : "Obama: But #Osawatomie this isn\u2019t just another political debate.  This is the defining issue of our time.",
    "id" : 144131001222832133,
    "created_at" : "2011-12-06 19:08:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 144131041697857536,
  "created_at" : "2011-12-06 19:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 133, 140 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144128976154148865",
  "text" : "Live Now: Pres Obama on how this is a make-or-break moment for the middle class in #Osawatomie, KS. Watch: http:\/wh.gov\/live Follow: @WHLive",
  "id" : 144128976154148865,
  "created_at" : "2011-12-06 19:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144125586594467840",
  "text" : "RT @PressSec: En route on Marine One to Osawatomie, KS, where POTUS will talk about how this is a make-or-break moment for the middle cl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144113296453275648",
    "text" : "En route on Marine One to Osawatomie, KS, where POTUS will talk about how this is a make-or-break moment for the middle class. 2 pm EST.",
    "id" : 144113296453275648,
    "created_at" : "2011-12-06 17:57:42 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 144125586594467840,
  "created_at" : "2011-12-06 18:46:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 110, 118 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 3, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/9TWkycpP",
      "expanded_url" : "http:\/\/ow.ly\/7QtrN",
      "display_url" : "ow.ly\/7QtrN"
    } ]
  },
  "geo" : { },
  "id_str" : "144100828234514432",
  "text" : "In #Osawatomie today, Obama talks make-or-break moment for middle class. Watch @ 2ET & share a video response @YouTube: http:\/\/t.co\/9TWkycpP",
  "id" : 144100828234514432,
  "created_at" : "2011-12-06 17:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144098705363054592",
  "text" : "RT @jesseclee44: Obama directs fed agencies engaged abroad to ensure that US diplomacy\/assistance promote & protect #LGBT human rights h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/NvYf0VyV",
        "expanded_url" : "http:\/\/1.usa.gov\/rDCQyN",
        "display_url" : "1.usa.gov\/rDCQyN"
      } ]
    },
    "geo" : { },
    "id_str" : "144091871453523968",
    "text" : "Obama directs fed agencies engaged abroad to ensure that US diplomacy\/assistance promote & protect #LGBT human rights http:\/\/t.co\/NvYf0VyV",
    "id" : 144091871453523968,
    "created_at" : "2011-12-06 16:32:33 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 144098705363054592,
  "created_at" : "2011-12-06 16:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "144095473513398273",
  "text" : "If Congress doesn't act, middle class taxes increase in 25 days, 12 hours, 13 minutes. Find out how it affects you: http:\/\/t.co\/cleL6Kao",
  "id" : 144095473513398273,
  "created_at" : "2011-12-06 16:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Osawatomie",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144089542910156800",
  "text" : "RT @macon44: Going to keep an eye on #Osawatomie today to discuss reactions to President Obama's speech at 1:55pm EST - watch @ http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Osawatomie",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/X6z1v6Kb",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "144089287837745152",
    "text" : "Going to keep an eye on #Osawatomie today to discuss reactions to President Obama's speech at 1:55pm EST - watch @ http:\/\/t.co\/X6z1v6Kb",
    "id" : 144089287837745152,
    "created_at" : "2011-12-06 16:22:17 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 144089542910156800,
  "created_at" : "2011-12-06 16:23:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144078313990782978",
  "text" : "RT @arneduncan: Teachers moonlighting to make ends meet is more proof we need to elevate the profession & pay teachers more. http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/GFIbbMwY",
        "expanded_url" : "http:\/\/bit.ly\/sWbGkS",
        "display_url" : "bit.ly\/sWbGkS"
      } ]
    },
    "geo" : { },
    "id_str" : "144073926316789760",
    "text" : "Teachers moonlighting to make ends meet is more proof we need to elevate the profession & pay teachers more. http:\/\/t.co\/GFIbbMwY",
    "id" : 144073926316789760,
    "created_at" : "2011-12-06 15:21:15 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 144078313990782978,
  "created_at" : "2011-12-06 15:38:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144068527085715456",
  "text" : "RT @pfeiffer44: President Obama delivers an important economic speech today at what he views as a \"make or break moment for the middle c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "144067988977483776",
    "text" : "President Obama delivers an important economic speech today at what he views as a \"make or break moment for the middle class\"",
    "id" : 144067988977483776,
    "created_at" : "2011-12-06 14:57:39 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 144068527085715456,
  "created_at" : "2011-12-06 14:59:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143857979404464128",
  "text" : "RT @lacasablanca: Si el Congreso no act\u00FAa los impuestos de la clase media aumentar\u00E1n en 26 d\u00EDas, 3 horas. \u00BFC\u00F3mo lo afecta? Visite http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/YniRtjQX",
        "expanded_url" : "http:\/\/wh.gov\/taxcut",
        "display_url" : "wh.gov\/taxcut"
      } ]
    },
    "geo" : { },
    "id_str" : "143857652387160064",
    "text" : "Si el Congreso no act\u00FAa los impuestos de la clase media aumentar\u00E1n en 26 d\u00EDas, 3 horas. \u00BFC\u00F3mo lo afecta? Visite http:\/\/t.co\/YniRtjQX",
    "id" : 143857652387160064,
    "created_at" : "2011-12-06 01:01:51 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 143857979404464128,
  "created_at" : "2011-12-06 01:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "143851432351764480",
  "text" : "If Congress doesn't act, middle class taxes increase in 26 days, 4 hours, 23 minutes. Find out how it affects you: http:\/\/t.co\/cleL6Kao",
  "id" : 143851432351764480,
  "created_at" : "2011-12-06 00:37:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHtweetup",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143850154125045760",
  "text" : "RT @ks44: We had a great group @ the #WHtweetup today. Tweeps: What did you think? What can we do better? Let us know. Always looking to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHtweetup",
        "indices" : [ 27, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "143848223717597187",
    "text" : "We had a great group @ the #WHtweetup today. Tweeps: What did you think? What can we do better? Let us know. Always looking to improve.",
    "id" : 143848223717597187,
    "created_at" : "2011-12-06 00:24:23 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 143850154125045760,
  "created_at" : "2011-12-06 00:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/tpv2ae41",
      "expanded_url" : "http:\/\/ow.ly\/7PAuD",
      "display_url" : "ow.ly\/7PAuD"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/kdLgxonU",
      "expanded_url" : "http:\/\/ow.ly\/7PAAq",
      "display_url" : "ow.ly\/7PAAq"
    } ]
  },
  "geo" : { },
  "id_str" : "143823774796623872",
  "text" : "The clock is ticking: Check out this email from David Plouffe: http:\/\/t.co\/tpv2ae41 Didn't get the email? Sign up: http:\/\/t.co\/kdLgxonU",
  "id" : 143823774796623872,
  "created_at" : "2011-12-05 22:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Numbers To Know",
      "screen_name" : "NumbersToKnow",
      "indices" : [ 3, 17 ],
      "id_str" : "229873610",
      "id" : 229873610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0cr0yuQu",
      "expanded_url" : "http:\/\/go.usa.gov\/5Ei",
      "display_url" : "go.usa.gov\/5Ei"
    } ]
  },
  "geo" : { },
  "id_str" : "143809859140329472",
  "text" : "RT @NumbersToKnow: 26 days, 7 hrs: Time until taxes increase for middle class unless GOP stops blocking payroll tax cut http:\/\/t.co\/0cr0yuQu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/0cr0yuQu",
        "expanded_url" : "http:\/\/go.usa.gov\/5Ei",
        "display_url" : "go.usa.gov\/5Ei"
      } ]
    },
    "geo" : { },
    "id_str" : "143808074690461696",
    "text" : "26 days, 7 hrs: Time until taxes increase for middle class unless GOP stops blocking payroll tax cut http:\/\/t.co\/0cr0yuQu",
    "id" : 143808074690461696,
    "created_at" : "2011-12-05 21:44:51 +0000",
    "user" : {
      "name" : "Numbers To Know",
      "screen_name" : "NumbersToKnow",
      "protected" : false,
      "id_str" : "229873610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1218552654\/biopic_normal.jpg",
      "id" : 229873610,
      "verified" : false
    }
  },
  "id" : 143809859140329472,
  "created_at" : "2011-12-05 21:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/cleL6Kao",
      "expanded_url" : "http:\/\/wh.gov\/taxcut",
      "display_url" : "wh.gov\/taxcut"
    } ]
  },
  "geo" : { },
  "id_str" : "143809642487746560",
  "text" : "If Congress doesn't act, middle class taxes increase in 26 days, 7 hours, 8 minutes. Learn how it affects you: http:\/\/t.co\/cleL6Kao",
  "id" : 143809642487746560,
  "created_at" : "2011-12-05 21:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 97, 113 ],
      "id_str" : "17961886",
      "id" : 17961886
    }, {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 117, 128 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Volunteer",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "AmeriCorps",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "IVD",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143794839828430849",
  "text" : "RT @ServeDotGov: Happy 10th Intl #Volunteer Day! Thanks to all who've served through #AmeriCorps @NationalService, & @PeaceCorps #IVD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNCS",
        "screen_name" : "NationalService",
        "indices" : [ 80, 96 ],
        "id_str" : "17961886",
        "id" : 17961886
      }, {
        "name" : "Peace Corps",
        "screen_name" : "PeaceCorps",
        "indices" : [ 100, 111 ],
        "id_str" : "9109712",
        "id" : 9109712
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Volunteer",
        "indices" : [ 16, 26 ]
      }, {
        "text" : "AmeriCorps",
        "indices" : [ 68, 79 ]
      }, {
        "text" : "IVD",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "143790750377840640",
    "text" : "Happy 10th Intl #Volunteer Day! Thanks to all who've served through #AmeriCorps @NationalService, & @PeaceCorps #IVD",
    "id" : 143790750377840640,
    "created_at" : "2011-12-05 20:36:01 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 143794839828430849,
  "created_at" : "2011-12-05 20:52:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/bPhKxavO",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "143774278519762944",
  "text" : "Time is running out. If Congress doesn't act, middle class taxes increase in 26 days, 9 hours, 30 minutes http:\/\/t.co\/bPhKxavO",
  "id" : 143774278519762944,
  "created_at" : "2011-12-05 19:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 20, 29 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143772768725499904",
  "text" : "RT @jesseclee44: As @presssec noted, staggering how many in GOP oppose middle class tax cut not over pay-for, but point blank. Tick-tock ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 3, 12 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/Ucrzn85r",
        "expanded_url" : "http:\/\/wh.gov",
        "display_url" : "wh.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "143772690644344832",
    "text" : "As @presssec noted, staggering how many in GOP oppose middle class tax cut not over pay-for, but point blank. Tick-tock http:\/\/t.co\/Ucrzn85r",
    "id" : 143772690644344832,
    "created_at" : "2011-12-05 19:24:15 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 143772768725499904,
  "created_at" : "2011-12-05 19:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143771060213530624",
  "text" : "Obama: So my message to Congress is this: keep your word to working Americans, and do not raise taxes on them right now",
  "id" : 143771060213530624,
  "created_at" : "2011-12-05 19:17:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143770985420689410",
  "text" : "Obama: Independent economists agree that if we don\u2019t extend the payroll tax cut or unemployment insurance, it will be a blow to our economy.",
  "id" : 143770985420689410,
  "created_at" : "2011-12-05 19:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 18, 33 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143770083540467712",
  "text" : "Obama: last week, @speakerboehner said this tax cut helps the economy because it allows every working American to keep more of their money",
  "id" : 143770083540467712,
  "created_at" : "2011-12-05 19:13:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143769663229272064",
  "text" : "Obama: In my jobs bill, I proposed not only extending that tax cut, but expanding it to give the typical working family a tax cut of $1,500",
  "id" : 143769663229272064,
  "created_at" : "2011-12-05 19:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 130, 137 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "143769240451825664",
  "text" : "Now: Obama in the Briefing Rm to tell Rs to join Ds in extending payroll tax cut for working families http:\/\/t.co\/u95y7hhB follow @WHLive",
  "id" : 143769240451825664,
  "created_at" : "2011-12-05 19:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordon Wadlington",
      "screen_name" : "jwadlington",
      "indices" : [ 0, 12 ],
      "id_str" : "21201342",
      "id" : 21201342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "143765678980214785",
  "geo" : { },
  "id_str" : "143767865848377344",
  "in_reply_to_user_id" : 21201342,
  "text" : "@jwadlington nice shot!",
  "id" : 143767865848377344,
  "in_reply_to_status_id" : 143765678980214785,
  "created_at" : "2011-12-05 19:05:04 +0000",
  "in_reply_to_screen_name" : "jwadlington",
  "in_reply_to_user_id_str" : "21201342",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/xFp7wlgY",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "143753993204662272",
  "text" : "RT @jesseclee44: 1:30: Obama at briefing to tell Rs to join Dems in extending payroll tax cut for working families http:\/\/t.co\/xFp7wlgY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/xFp7wlgY",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "143750574771417088",
    "text" : "1:30: Obama at briefing to tell Rs to join Dems in extending payroll tax cut for working families http:\/\/t.co\/xFp7wlgY",
    "id" : 143750574771417088,
    "created_at" : "2011-12-05 17:56:22 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 143753993204662272,
  "created_at" : "2011-12-05 18:09:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/VVUkTrmD",
      "expanded_url" : "http:\/\/ow.ly\/7Pd6z",
      "display_url" : "ow.ly\/7Pd6z"
    } ]
  },
  "geo" : { },
  "id_str" : "143750770666373120",
  "text" : "Today @ 1:30ET, Obama will urge Rs in Congress to join Ds to ensure taxes don\u2019t go up on middle class families. Watch: http:\/\/t.co\/VVUkTrmD",
  "id" : 143750770666373120,
  "created_at" : "2011-12-05 17:57:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ally__katt",
      "screen_name" : "petitefleur77",
      "indices" : [ 3, 17 ],
      "id_str" : "2501319906",
      "id" : 2501319906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHtweetup",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143740756711063552",
  "text" : "RT @petitefleur77: Said by a few of the speakers, this year's holiday theme is Shine, Give and Share. #WHtweetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHtweetup",
        "indices" : [ 83, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "143740486853722113",
    "text" : "Said by a few of the speakers, this year's holiday theme is Shine, Give and Share. #WHtweetup",
    "id" : 143740486853722113,
    "created_at" : "2011-12-05 17:16:17 +0000",
    "user" : {
      "name" : "C\u00E9cile",
      "screen_name" : "cecileremington",
      "protected" : false,
      "id_str" : "30369608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744639813916196864\/UhcaqKP8_normal.jpg",
      "id" : 30369608,
      "verified" : false
    }
  },
  "id" : 143740756711063552,
  "created_at" : "2011-12-05 17:17:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/z2jBZf5q",
      "expanded_url" : "http:\/\/ow.ly\/7P1qM",
      "display_url" : "ow.ly\/7P1qM"
    } ]
  },
  "geo" : { },
  "id_str" : "143726429379633152",
  "text" : "Want to know why it\u2019s so important for Congress to confirm Richard Cordray as Director of the CFPB? Read the report: http:\/\/t.co\/z2jBZf5q",
  "id" : 143726429379633152,
  "created_at" : "2011-12-05 16:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/6mNMl7iV",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "143695263402426368",
  "text" : "RT @ks44: It's the holiday #whtweetup! We'll be livestreaming the whole thing here starting @ 9ET right here: http:\/\/t.co\/6mNMl7iV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/6mNMl7iV",
        "expanded_url" : "http:\/\/whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "143684374255247360",
    "text" : "It's the holiday #whtweetup! We'll be livestreaming the whole thing here starting @ 9ET right here: http:\/\/t.co\/6mNMl7iV",
    "id" : 143684374255247360,
    "created_at" : "2011-12-05 13:33:19 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 143695263402426368,
  "created_at" : "2011-12-05 14:16:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Kennedy Center",
      "screen_name" : "kencen",
      "indices" : [ 60, 67 ],
      "id_str" : "19936078",
      "id" : 19936078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "KCHonors",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/bMa1AS3n",
      "expanded_url" : "http:\/\/ow.ly\/7Oayv",
      "display_url" : "ow.ly\/7Oayv"
    } ]
  },
  "geo" : { },
  "id_str" : "143446989030424576",
  "text" : "Happening @ 5ET: President Obama & the First Lady honor the @kencen honorees #AtTheWH. Watch live: http:\/\/t.co\/bMa1AS3n #KCHonors",
  "id" : 143446989030424576,
  "created_at" : "2011-12-04 21:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143441171404959744",
  "text" : "President Obama calls on Congress to act in the best interests of middle class families & pass the payroll tax cut now. RT if you agree.",
  "id" : 143441171404959744,
  "created_at" : "2011-12-04 21:26:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/NK1vSOAm",
      "expanded_url" : "http:\/\/ow.ly\/7NFb5",
      "display_url" : "ow.ly\/7NFb5"
    } ]
  },
  "geo" : { },
  "id_str" : "143088922841448448",
  "text" : "\"We\u2019re all in this together. The more Americans succeed, the more America succeeds.\" -President Obama. Weekly Address: http:\/\/t.co\/NK1vSOAm",
  "id" : 143088922841448448,
  "created_at" : "2011-12-03 22:07:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/xngg1pU1",
      "expanded_url" : "http:\/\/ow.ly\/7NCRi",
      "display_url" : "ow.ly\/7NCRi"
    } ]
  },
  "geo" : { },
  "id_str" : "143071686290452481",
  "text" : "The President urges all Americans to tell Congress not to raise taxes during the holidays & pass the tax cuts now: http:\/\/t.co\/xngg1pU1",
  "id" : 143071686290452481,
  "created_at" : "2011-12-03 20:58:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143010585339117569",
  "text" : "RT @pfeiffer44: POTUS will talk abt the need for an economy where everyone engages in fair play,everyone does their fair share,and every ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142986747628892160",
    "text" : "POTUS will talk abt the need for an economy where everyone engages in fair play,everyone does their fair share,and everyone gets a fair shot",
    "id" : 142986747628892160,
    "created_at" : "2011-12-03 15:21:11 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 143010585339117569,
  "created_at" : "2011-12-03 16:55:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143010523724787712",
  "text" : "RT @pfeiffer44: Just over 100 years ago, President Teddy Roosevelt came to Osawatomie, Ks and called for a New Nationalism.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142986204223250432",
    "text" : "Just over 100 years ago, President Teddy Roosevelt came to Osawatomie, Ks and called for a New Nationalism.",
    "id" : 142986204223250432,
    "created_at" : "2011-12-03 15:19:02 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 143010523724787712,
  "created_at" : "2011-12-03 16:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/XmykvEOR",
      "expanded_url" : "http:\/\/ow.ly\/7N8v9",
      "display_url" : "ow.ly\/7N8v9"
    } ]
  },
  "geo" : { },
  "id_str" : "142760442731839489",
  "text" : "\"Don't be a Grinch\" -President Obama in the latest West Wing Week. Watch: http:\/\/t.co\/XmykvEOR",
  "id" : 142760442731839489,
  "created_at" : "2011-12-03 00:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142748589704232960",
  "text" : "RT @jesseclee44: \"Republicans don't believe in raising taxes on anyone, especially middle-class families\" -Cantor, 12\/1\/11 http:\/\/t.co\/a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoodOldDays",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/a2SRXXJE",
        "expanded_url" : "http:\/\/bit.ly\/vdwJlG",
        "display_url" : "bit.ly\/vdwJlG"
      } ]
    },
    "geo" : { },
    "id_str" : "142744236020858880",
    "text" : "\"Republicans don't believe in raising taxes on anyone, especially middle-class families\" -Cantor, 12\/1\/11 http:\/\/t.co\/a2SRXXJE #GoodOldDays",
    "id" : 142744236020858880,
    "created_at" : "2011-12-02 23:17:32 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 142748589704232960,
  "created_at" : "2011-12-02 23:34:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/fL7yoQr3",
      "expanded_url" : "http:\/\/ow.ly\/7MPbO",
      "display_url" : "ow.ly\/7MPbO"
    } ]
  },
  "geo" : { },
  "id_str" : "142684970262077441",
  "text" : "Happening now: President Obama Speaks at the @WhiteHouse #TribalNations Conference. Watch live: http:\/\/t.co\/fL7yoQr3",
  "id" : 142684970262077441,
  "created_at" : "2011-12-02 19:22:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142680072606846976",
  "text" : "RT @jesseclee44: Obama on payroll tax cut: \"expect it's going to get done...Otherwise Congress may not be leaving & we can all spend Chr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142679916553568256",
    "text" : "Obama on payroll tax cut: \"expect it's going to get done...Otherwise Congress may not be leaving & we can all spend Christmas here together\"",
    "id" : 142679916553568256,
    "created_at" : "2011-12-02 19:01:57 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 142680072606846976,
  "created_at" : "2011-12-02 19:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/IkKcHqqK",
      "expanded_url" : "http:\/\/ow.ly\/7MD1p",
      "display_url" : "ow.ly\/7MD1p"
    } ]
  },
  "geo" : { },
  "id_str" : "142650197925826560",
  "text" : "Obama announces $4B investment in energy upgrades to public & private buildings. Creates 10s of 1000s of jobs, saves Bs http:\/\/t.co\/IkKcHqqK",
  "id" : 142650197925826560,
  "created_at" : "2011-12-02 17:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 30, 35 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 83, 94 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/8dpJWeJX",
      "expanded_url" : "http:\/\/ow.ly\/i\/mA53",
      "display_url" : "ow.ly\/i\/mA53"
    } ]
  },
  "geo" : { },
  "id_str" : "142644032852602881",
  "text" : "RT @sbagov: SBA Chief Mills & @USDA Sec Vilsack meet w\/ tribal leaders today @ the @Whitehouse #TribalNations Conf: http:\/\/t.co\/8dpJWeJX",
  "id" : 142644032852602881,
  "created_at" : "2011-12-02 16:39:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/emGpg9Bk",
      "expanded_url" : "http:\/\/ow.ly\/7MvJR",
      "display_url" : "ow.ly\/7MvJR"
    } ]
  },
  "geo" : { },
  "id_str" : "142630900050571264",
  "text" : "RT @WHLive: Happening @ 11:15ET: President Obama delivers remarks @ the Transwestern Building in DC. Watch live: http:\/\/t.co\/emGpg9Bk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/emGpg9Bk",
        "expanded_url" : "http:\/\/ow.ly\/7MvJR",
        "display_url" : "ow.ly\/7MvJR"
      } ]
    },
    "geo" : { },
    "id_str" : "142630774158536704",
    "text" : "Happening @ 11:15ET: President Obama delivers remarks @ the Transwestern Building in DC. Watch live: http:\/\/t.co\/emGpg9Bk",
    "id" : 142630774158536704,
    "created_at" : "2011-12-02 15:46:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 142630900050571264,
  "created_at" : "2011-12-02 15:47:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142629596712550400",
  "text" : "RT @VP: VP: \"In America, and in Iraq, the tide of war is receding;\" read more about VP's visit to #Iraq this wk; BLOG POST http:\/\/t.co\/W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 90, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/WwZAILzB",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/12\/02\/vice-president-biden-relationship-iraq-new-more-normal-partnership",
        "display_url" : "whitehouse.gov\/blog\/2011\/12\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "142629138354802688",
    "text" : "VP: \"In America, and in Iraq, the tide of war is receding;\" read more about VP's visit to #Iraq this wk; BLOG POST http:\/\/t.co\/WwZAILzB",
    "id" : 142629138354802688,
    "created_at" : "2011-12-02 15:40:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 142629596712550400,
  "created_at" : "2011-12-02 15:42:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 39, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142626569637199872",
  "text" : "RT @jesseclee44: CEA's Krueger on Jobs #s: 2.9M jobs in 21 months, unemployment lowest since 3\/09, improvement \"still not fast enough\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s",
        "indices" : [ 22, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/DtOZ6LFt",
        "expanded_url" : "http:\/\/wh.gov\/Dq9",
        "display_url" : "wh.gov\/Dq9"
      } ]
    },
    "geo" : { },
    "id_str" : "142622683501314049",
    "text" : "CEA's Krueger on Jobs #s: 2.9M jobs in 21 months, unemployment lowest since 3\/09, improvement \"still not fast enough\" http:\/\/t.co\/DtOZ6LFt",
    "id" : 142622683501314049,
    "created_at" : "2011-12-02 15:14:32 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 142626569637199872,
  "created_at" : "2011-12-02 15:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/QHYAE2DW",
      "expanded_url" : "http:\/\/1.usa.gov\/uCPAng",
      "display_url" : "1.usa.gov\/uCPAng"
    } ]
  },
  "geo" : { },
  "id_str" : "142449892843991041",
  "text" : "RT @jesseclee44: Obama statement on Senate Rs voting to raise taxes on 160M hardworking Americans: \"Unacceptable\" http:\/\/t.co\/QHYAE2DW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/QHYAE2DW",
        "expanded_url" : "http:\/\/1.usa.gov\/uCPAng",
        "display_url" : "1.usa.gov\/uCPAng"
      } ]
    },
    "geo" : { },
    "id_str" : "142449638639804418",
    "text" : "Obama statement on Senate Rs voting to raise taxes on 160M hardworking Americans: \"Unacceptable\" http:\/\/t.co\/QHYAE2DW",
    "id" : 142449638639804418,
    "created_at" : "2011-12-02 03:46:55 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 142449892843991041,
  "created_at" : "2011-12-02 03:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142398571482841089",
  "text" : "RT @jesseclee44: On budget negotiations, GOP should \"stop attempting to re-litigate the August agreement & abandon ideological stunts\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/T3lOr3lf",
        "expanded_url" : "http:\/\/wh.gov\/jJK",
        "display_url" : "wh.gov\/jJK"
      } ]
    },
    "geo" : { },
    "id_str" : "142364990836449280",
    "text" : "On budget negotiations, GOP should \"stop attempting to re-litigate the August agreement & abandon ideological stunts\" http:\/\/t.co\/T3lOr3lf",
    "id" : 142364990836449280,
    "created_at" : "2011-12-01 22:10:33 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 142398571482841089,
  "created_at" : "2011-12-02 00:23:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 30, 41 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/7zAPmQF5",
      "expanded_url" : "http:\/\/ow.ly\/7LO8H",
      "display_url" : "ow.ly\/7LO8H"
    } ]
  },
  "geo" : { },
  "id_str" : "142385223433338880",
  "text" : "Time for a balanced approach: @pfeiffer44 on the current debate in Congress that could force a costly govt shutdown: http:\/\/t.co\/7zAPmQF5",
  "id" : 142385223433338880,
  "created_at" : "2011-12-01 23:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/8eNaOJO5",
      "expanded_url" : "http:\/\/ow.ly\/7LInq",
      "display_url" : "ow.ly\/7LInq"
    } ]
  },
  "geo" : { },
  "id_str" : "142359514384044032",
  "text" : "Happening @ 5ET: The First Family attends the National Christmas Tree Lighting on the Ellipse. Watch live: http:\/\/t.co\/8eNaOJO5",
  "id" : 142359514384044032,
  "created_at" : "2011-12-01 21:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 14, 25 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142357130798825472",
  "text" : "RT @OMBPress: @pfeiffer44 blog on '12 approps: to avoid veto and possible shutdown, \"abandon ideological stunts;\" pass balanced bill: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 0, 11 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/Ay74SjsW",
        "expanded_url" : "http:\/\/ht.ly\/7LF9P",
        "display_url" : "ht.ly\/7LF9P"
      } ]
    },
    "geo" : { },
    "id_str" : "142348019893944321",
    "in_reply_to_user_id" : 131144091,
    "text" : "@pfeiffer44 blog on '12 approps: to avoid veto and possible shutdown, \"abandon ideological stunts;\" pass balanced bill: http:\/\/t.co\/Ay74SjsW",
    "id" : 142348019893944321,
    "created_at" : "2011-12-01 21:03:07 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 142357130798825472,
  "created_at" : "2011-12-01 21:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/142336712339759105\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/KhDOZjty",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfmufFoCIAAKZX6.jpg",
      "id_str" : "142336712348147712",
      "id" : 142336712348147712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfmufFoCIAAKZX6.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KhDOZjty"
    } ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142336712339759105",
  "text" : "PHOTO: A red ribbon is hung from the North Portico of the @WhiteHouse to mark #WorldAIDSDay: http:\/\/t.co\/KhDOZjty",
  "id" : 142336712339759105,
  "created_at" : "2011-12-01 20:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 20, 33 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "142324007742615552",
  "text" : "Happening @ 2:30ET: #WorldAIDSDay Open for Questions on the Beginning of the End of AIDS. Watch live: http:\/\/t.co\/u95y7hhB Ask Qs: #WHChat",
  "id" : 142324007742615552,
  "created_at" : "2011-12-01 19:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/jCZ6HAxK",
      "expanded_url" : "http:\/\/ow.ly\/7LuB2",
      "display_url" : "ow.ly\/7LuB2"
    } ]
  },
  "geo" : { },
  "id_str" : "142314772682113024",
  "text" : "FACT SHEET: The Beginning of the End of AIDS: http:\/\/t.co\/jCZ6HAxK #WorldAIDSDay",
  "id" : 142314772682113024,
  "created_at" : "2011-12-01 18:51:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 106, 115 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Emmy Her Many Horses",
      "screen_name" : "emmyhmh",
      "indices" : [ 116, 124 ],
      "id_str" : "279750134",
      "id" : 279750134
    }, {
      "name" : "LeVon Thomas",
      "screen_name" : "lee14174",
      "indices" : [ 125, 134 ],
      "id_str" : "36773761",
      "id" : 36773761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "championsofchangeWH",
      "indices" : [ 85, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142314482285289473",
  "text" : "RT @JonCarson44: Here with our @Whitehouse Native American Youth Champions of Change #championsofchangeWH @Interior @Emmyhmh @lee14174 @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 89, 98 ],
        "id_str" : "76348185",
        "id" : 76348185
      }, {
        "name" : "Emmy Her Many Horses",
        "screen_name" : "emmyhmh",
        "indices" : [ 99, 107 ],
        "id_str" : "279750134",
        "id" : 279750134
      }, {
        "name" : "LeVon Thomas",
        "screen_name" : "lee14174",
        "indices" : [ 108, 117 ],
        "id_str" : "36773761",
        "id" : 36773761
      }, {
        "name" : "Tiffany Calabaza",
        "screen_name" : "tcalabaza",
        "indices" : [ 130, 140 ],
        "id_str" : "426016782",
        "id" : 426016782
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "championsofchangeWH",
        "indices" : [ 68, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142314344116518912",
    "text" : "Here with our @Whitehouse Native American Youth Champions of Change #championsofchangeWH @Interior @Emmyhmh @lee14174 @tessakayeb @tcalabaza",
    "id" : 142314344116518912,
    "created_at" : "2011-12-01 18:49:18 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 142314482285289473,
  "created_at" : "2011-12-01 18:49:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndofAIDS",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142267522249535488",
  "text" : "\"We can beat this disease. We can win this fight. We just have to keep at it...every day until we get to zero\" -President Obama #EndofAIDS",
  "id" : 142267522249535488,
  "created_at" : "2011-12-01 15:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142266418296135681",
  "text" : "\"Today we\u2019re setting a new target of helping six million people get on treatment by the end of 2013\" -President Obama on #WorldAIDSDay",
  "id" : 142266418296135681,
  "created_at" : "2011-12-01 15:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndOfAIDS",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142264404988280832",
  "text" : "Obama: Today is a remarkable day. Today, we come together...to renew our commitment to ending the AIDS pandemic once and for all #EndOfAIDS",
  "id" : 142264404988280832,
  "created_at" : "2011-12-01 15:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 111, 118 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 46, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/TGiY2X46",
      "expanded_url" : "http:\/\/ow.ly\/7Lcv9",
      "display_url" : "ow.ly\/7Lcv9"
    } ]
  },
  "geo" : { },
  "id_str" : "142263808105267202",
  "text" : "RT @WHLive: President Obama is speaking now @ #WorldAIDSDay. Watch live: http:\/\/t.co\/TGiY2X46 & follow remarks @WHLive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 99, 106 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 34, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/TGiY2X46",
        "expanded_url" : "http:\/\/ow.ly\/7Lcv9",
        "display_url" : "ow.ly\/7Lcv9"
      } ]
    },
    "geo" : { },
    "id_str" : "142263767613444096",
    "text" : "President Obama is speaking now @ #WorldAIDSDay. Watch live: http:\/\/t.co\/TGiY2X46 & follow remarks @WHLive",
    "id" : 142263767613444096,
    "created_at" : "2011-12-01 15:28:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 142263808105267202,
  "created_at" : "2011-12-01 15:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PEPFAR",
      "screen_name" : "PEPFAR",
      "indices" : [ 3, 10 ],
      "id_str" : "69091913",
      "id" : 69091913
    }, {
      "name" : "sgmd",
      "screen_name" : "SanjayGuptaCNN",
      "indices" : [ 26, 41 ],
      "id_str" : "987646394",
      "id" : 987646394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142259571631734784",
  "text" : "RT @PEPFAR: Now on stage: @sanjayguptaCNN: \"Today on 23rd anniversary of #WorldAIDSDay... we look to a hopeful future. The beginning of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "sgmd",
        "screen_name" : "SanjayGuptaCNN",
        "indices" : [ 14, 29 ],
        "id_str" : "987646394",
        "id" : 987646394
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 61, 74 ]
      }, {
        "text" : "EndofAIDS",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142259234669735936",
    "text" : "Now on stage: @sanjayguptaCNN: \"Today on 23rd anniversary of #WorldAIDSDay... we look to a hopeful future. The beginning of the #EndofAIDS\"",
    "id" : 142259234669735936,
    "created_at" : "2011-12-01 15:10:19 +0000",
    "user" : {
      "name" : "PEPFAR",
      "screen_name" : "PEPFAR",
      "protected" : false,
      "id_str" : "69091913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719590176289193984\/r0UMCuIN_normal.jpg",
      "id" : 69091913,
      "verified" : true
    }
  },
  "id" : 142259571631734784,
  "created_at" : "2011-12-01 15:11:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joinRED",
      "screen_name" : "joinRED",
      "indices" : [ 3, 11 ],
      "id_str" : "13632",
      "id" : 13632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "endofAIDS",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/fN24QLla",
      "expanded_url" : "http:\/\/t.joinred.com\/FSi",
      "display_url" : "t.joinred.com\/FSi"
    } ]
  },
  "geo" : { },
  "id_str" : "142259342501085185",
  "text" : "RT @joinRED: LIVE NOW: President Obama, former Presidents Bush & Clinton, Bono and Alicia Keys on #endofAIDS. http:\/\/t.co\/fN24QLla",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "endofAIDS",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/fN24QLla",
        "expanded_url" : "http:\/\/t.joinred.com\/FSi",
        "display_url" : "t.joinred.com\/FSi"
      } ]
    },
    "geo" : { },
    "id_str" : "142257986067365888",
    "text" : "LIVE NOW: President Obama, former Presidents Bush & Clinton, Bono and Alicia Keys on #endofAIDS. http:\/\/t.co\/fN24QLla",
    "id" : 142257986067365888,
    "created_at" : "2011-12-01 15:05:21 +0000",
    "user" : {
      "name" : "(RED)",
      "screen_name" : "RED",
      "protected" : false,
      "id_str" : "16423109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749999977145987073\/TIBx9FL__normal.jpg",
      "id" : 16423109,
      "verified" : true
    }
  },
  "id" : 142259342501085185,
  "created_at" : "2011-12-01 15:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 117, 124 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/E3fnLmMK",
      "expanded_url" : "http:\/\/ow.ly\/7L9qh",
      "display_url" : "ow.ly\/7L9qh"
    } ]
  },
  "geo" : { },
  "id_str" : "142258394127011840",
  "text" : "RT @WHLive: Happening now: President Obama speaks at #WorldAIDSDay event. Watch live: http:\/\/t.co\/E3fnLmMK & follow: @WHLive cc: @ONECam ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 105, 112 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "ONE",
        "screen_name" : "ONECampaign",
        "indices" : [ 117, 129 ],
        "id_str" : "16348549",
        "id" : 16348549
      }, {
        "name" : "joinRED",
        "screen_name" : "joinRED",
        "indices" : [ 130, 138 ],
        "id_str" : "13632",
        "id" : 13632
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 41, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/E3fnLmMK",
        "expanded_url" : "http:\/\/ow.ly\/7L9qh",
        "display_url" : "ow.ly\/7L9qh"
      } ]
    },
    "geo" : { },
    "id_str" : "142258317320925185",
    "text" : "Happening now: President Obama speaks at #WorldAIDSDay event. Watch live: http:\/\/t.co\/E3fnLmMK & follow: @WHLive cc: @ONECampaign @joinRED",
    "id" : 142258317320925185,
    "created_at" : "2011-12-01 15:06:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 142258394127011840,
  "created_at" : "2011-12-01 15:06:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/qL3m0Z2g",
      "expanded_url" : "http:\/\/bit.ly\/ifrf1R",
      "display_url" : "bit.ly\/ifrf1R"
    } ]
  },
  "geo" : { },
  "id_str" : "142254775109562368",
  "text" : "RT @pfeiffer44: Great front page from the Scranton Times-Tribune from the President's visit yesterday http:\/\/t.co\/qL3m0Z2g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/qL3m0Z2g",
        "expanded_url" : "http:\/\/bit.ly\/ifrf1R",
        "display_url" : "bit.ly\/ifrf1R"
      } ]
    },
    "geo" : { },
    "id_str" : "142243997958672384",
    "text" : "Great front page from the Scranton Times-Tribune from the President's visit yesterday http:\/\/t.co\/qL3m0Z2g",
    "id" : 142243997958672384,
    "created_at" : "2011-12-01 14:09:46 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 142254775109562368,
  "created_at" : "2011-12-01 14:52:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]