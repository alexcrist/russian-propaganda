Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 49, 59 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759917835795562496",
  "text" : "Judge Lewis and @VP on Republican obstruction of @SCOTUSnom: \"We\u2019re only as strong as the traditions we value.\" https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759917835795562496,
  "created_at" : "2016-08-01 01:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 102, 105 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759905314586058755",
  "text" : "\"For the sake of the country we love\u2014we all have to do our job...Senate Republicans must do theirs.\" \u2014@VP: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759905314586058755,
  "created_at" : "2016-08-01 00:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 74, 84 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA26",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/5lJGUj9lbB",
      "expanded_url" : "http:\/\/go.wh.gov\/a4brdg",
      "display_url" : "go.wh.gov\/a4brdg"
    } ]
  },
  "geo" : { },
  "id_str" : "759902473716764676",
  "text" : "ICYMI: This weekend, White House staffers with disabilities took over our @Instagram. Read their stories: https:\/\/t.co\/5lJGUj9lbB #ADA26",
  "id" : 759902473716764676,
  "created_at" : "2016-08-01 00:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA26",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759885135097450496",
  "geo" : { },
  "id_str" : "759889754703880195",
  "in_reply_to_user_id" : 30313925,
  "text" : "Check back later this week for a full audio description of the West Wing Tour. Happy #ADA26!",
  "id" : 759889754703880195,
  "in_reply_to_status_id" : 759885135097450496,
  "created_at" : "2016-07-31 23:13:30 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyISign",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/36hJG8cMWj",
      "expanded_url" : "http:\/\/snpy.tv\/2aGURvG",
      "display_url" : "snpy.tv\/2aGURvG"
    } ]
  },
  "geo" : { },
  "id_str" : "759885135097450496",
  "text" : "\"Being deaf wasn't a barrier to my career...It was a spur to public service\" \u2014West Wing Receptionist Leah. #WhyISign https:\/\/t.co\/36hJG8cMWj",
  "id" : 759885135097450496,
  "created_at" : "2016-07-31 22:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "indices" : [ 3, 13 ],
      "id_str" : "1665298740",
      "id" : 1665298740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA26",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759870986342793216",
  "text" : "RT @Hoffine44: We are a stronger and more vibrant country because of our diversity. Celebrate #ADA26 with a special West Wing Tour: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ADA26",
        "indices" : [ 79, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xDEtIa2kaN",
        "expanded_url" : "http:\/\/snpy.tv\/2aGURvG",
        "display_url" : "snpy.tv\/2aGURvG"
      } ]
    },
    "geo" : { },
    "id_str" : "759869174222950401",
    "text" : "We are a stronger and more vibrant country because of our diversity. Celebrate #ADA26 with a special West Wing Tour: https:\/\/t.co\/xDEtIa2kaN",
    "id" : 759869174222950401,
    "created_at" : "2016-07-31 21:51:43 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 759870986342793216,
  "created_at" : "2016-07-31 21:58:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/36hJG8cMWj",
      "expanded_url" : "http:\/\/snpy.tv\/2aGURvG",
      "display_url" : "snpy.tv\/2aGURvG"
    } ]
  },
  "geo" : { },
  "id_str" : "759859981348839424",
  "text" : "The White House isn't just @POTUS's office. It's the People's House too\u2014including for Americans with disabilities: https:\/\/t.co\/36hJG8cMWj",
  "id" : 759859981348839424,
  "created_at" : "2016-07-31 21:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/36hJG8uokT",
      "expanded_url" : "http:\/\/snpy.tv\/2aGURvG",
      "display_url" : "snpy.tv\/2aGURvG"
    } ]
  },
  "geo" : { },
  "id_str" : "759845848402522112",
  "text" : "As the People\u2019s House, the White House belongs to every American. Follow along on a special tour of the West Wing: https:\/\/t.co\/36hJG8uokT",
  "id" : 759845848402522112,
  "created_at" : "2016-07-31 20:19:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 109, 112 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759834550885232641",
  "text" : "\"There\u2019s enough dysfunction in Washington, D.C. Now is not the time for it to spread to the Supreme Court.\" \u2014@VP: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759834550885232641,
  "created_at" : "2016-07-31 19:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759807284083957760",
  "text" : "Unresolved decisions by an incomplete Supreme Court lead to confusion and uncertainty\u2014and harm our country: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759807284083957760,
  "created_at" : "2016-07-31 17:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/rtiJXxw2Ji",
      "expanded_url" : "http:\/\/www.cdc.gov\/zika",
      "display_url" : "cdc.gov\/zika"
    } ]
  },
  "geo" : { },
  "id_str" : "759802814516367360",
  "text" : "RT @DrFriedenCDC: We must do all that we can to protect pregnant women from #Zika virus. Stay updated at https:\/\/t.co\/rtiJXxw2Ji.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 58, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/rtiJXxw2Ji",
        "expanded_url" : "http:\/\/www.cdc.gov\/zika",
        "display_url" : "cdc.gov\/zika"
      } ]
    },
    "geo" : { },
    "id_str" : "759760719684440064",
    "text" : "We must do all that we can to protect pregnant women from #Zika virus. Stay updated at https:\/\/t.co\/rtiJXxw2Ji.",
    "id" : 759760719684440064,
    "created_at" : "2016-07-31 14:40:45 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 759802814516367360,
  "created_at" : "2016-07-31 17:28:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759773221516288000",
  "text" : "A divided SCOTUS means:\n\nFreedom of speech\nFreedom of religion\nRight to privacy\n\nCould all depend on where you live. https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759773221516288000,
  "created_at" : "2016-07-31 15:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 100, 103 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759743012377210880",
  "text" : "\"Saying nothing, seeing nothing, reading nothing...is not an option the Constitution leaves open.\" \u2014@VP to Congress: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759743012377210880,
  "created_at" : "2016-07-31 13:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759524110212837376",
  "text" : ".@VP presided over 9 Supreme Court nominations in the Senate, including during election years. Every one got a vote: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759524110212837376,
  "created_at" : "2016-07-30 23:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 55, 65 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759497625934585856",
  "text" : ".@VP and Judge Timothy Lewis on providing a hearing to @SCOTUSnom Garland: \"That's what the Constitution requires.\" https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759497625934585856,
  "created_at" : "2016-07-30 21:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 102, 105 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759471289279008768",
  "text" : "\"Merrick Garland is recognized...by the right and the left as one of America\u2019s sharpest legal minds\" \u2014@VP: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759471289279008768,
  "created_at" : "2016-07-30 19:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "indices" : [ 3, 15 ],
      "id_str" : "701725963",
      "id" : 701725963
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 126, 133 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759470710272069632",
  "text" : "RT @nowthisnews: These inspiring, dedicated, passionate students beat the odds. Now they're going to college and hanging with @FLOTUS https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 109, 116 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LejNq5VK0e",
        "expanded_url" : "http:\/\/on.nowth.is\/1dqq",
        "display_url" : "on.nowth.is\/1dqq"
      } ]
    },
    "geo" : { },
    "id_str" : "759396165792124928",
    "text" : "These inspiring, dedicated, passionate students beat the odds. Now they're going to college and hanging with @FLOTUS https:\/\/t.co\/LejNq5VK0e",
    "id" : 759396165792124928,
    "created_at" : "2016-07-30 14:32:09 +0000",
    "user" : {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "protected" : false,
      "id_str" : "701725963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783053831844298754\/p8H7pdtz_normal.jpg",
      "id" : 701725963,
      "verified" : true
    }
  },
  "id" : 759470710272069632,
  "created_at" : "2016-07-30 19:28:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 84, 87 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759444777272090628",
  "text" : "Judge Timothy Lewis was confirmed within 4 weeks of a presidential election. He and @VP tell Congress: #DoYourJob \u2192 https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759444777272090628,
  "created_at" : "2016-07-30 17:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/5x3HkRbxyC",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759414684135022592",
  "text" : "Chief Judge Garland, @POTUS's Supreme Court nominee, has waited longer for a hearing than any nominee in history: https:\/\/t.co\/5x3HkRbxyC",
  "id" : 759414684135022592,
  "created_at" : "2016-07-30 15:45:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 24, 27 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5x3HkQTWH4",
      "expanded_url" : "http:\/\/go.wh.gov\/MK259y",
      "display_url" : "go.wh.gov\/MK259y"
    } ]
  },
  "geo" : { },
  "id_str" : "759398998943948800",
  "text" : "In this week's address, @VP and retired Federal Judge Timothy Lewis tell Senate Republicans: #DoYourJob. Watch \u2192 https:\/\/t.co\/5x3HkQTWH4",
  "id" : 759398998943948800,
  "created_at" : "2016-07-30 14:43:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Qm71v8irVZ",
      "expanded_url" : "http:\/\/snpy.tv\/2akhCkx",
      "display_url" : "snpy.tv\/2akhCkx"
    } ]
  },
  "geo" : { },
  "id_str" : "759186810786504704",
  "text" : ".@POTUS's advice to WH interns: \"Orient yourself towards having an impact and making a difference\u2014and you will.\" https:\/\/t.co\/Qm71v8irVZ",
  "id" : 759186810786504704,
  "created_at" : "2016-07-30 00:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/759173601996206080\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/KgXTjxI68w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CokfPcKXgAA94sx.jpg",
      "id_str" : "759172362306813952",
      "id" : 759172362306813952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CokfPcKXgAA94sx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/KgXTjxI68w"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/XA2SlDmi1E",
      "expanded_url" : "http:\/\/go.wh.gov\/transportation",
      "display_url" : "go.wh.gov\/transportation"
    } ]
  },
  "geo" : { },
  "id_str" : "759173601996206080",
  "text" : "Here's how we're investing in infrastructure projects in all 50 states: https:\/\/t.co\/XA2SlDmi1E https:\/\/t.co\/KgXTjxI68w",
  "id" : 759173601996206080,
  "created_at" : "2016-07-29 23:47:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759140751905259520",
  "geo" : { },
  "id_str" : "759159245875150848",
  "in_reply_to_user_id" : 30313925,
  "text" : "Correction: President Obama has called on Congress to increase TIGER grants by 150% to help fund infrastructure projects across the country.",
  "id" : 759159245875150848,
  "in_reply_to_status_id" : 759140751905259520,
  "created_at" : "2016-07-29 22:50:43 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/759140751905259520\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/tBvZSgo5Uq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CokCEVuXgAEl5oZ.jpg",
      "id_str" : "759140285762994177",
      "id" : 759140285762994177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CokCEVuXgAEl5oZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/tBvZSgo5Uq"
    } ],
    "hashtags" : [ {
      "text" : "InternationalTigerDay",
      "indices" : [ 3, 25 ]
    }, {
      "text" : "TIGER",
      "indices" : [ 48, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/XA2SlDmi1E",
      "expanded_url" : "http:\/\/go.wh.gov\/transportation",
      "display_url" : "go.wh.gov\/transportation"
    } ]
  },
  "geo" : { },
  "id_str" : "759140751905259520",
  "text" : "On #InternationalTigerDay, learn about what the #TIGER program is doing for you \u2192 https:\/\/t.co\/XA2SlDmi1E https:\/\/t.co\/tBvZSgo5Uq",
  "id" : 759140751905259520,
  "created_at" : "2016-07-29 21:37:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTD",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759113694965932034",
  "text" : "RT @NASA: #OTD 1958, President Eisenhower signed act creating NASA. Our birthday is Oct 1, 1958, when we became operational. https:\/\/t.co\/f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/759064199792394242\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/fFrwrXidOR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coi83F9WIAAQVqX.jpg",
        "id_str" : "759064191890235392",
        "id" : 759064191890235392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coi83F9WIAAQVqX.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fFrwrXidOR"
      } ],
      "hashtags" : [ {
        "text" : "OTD",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759064199792394242",
    "text" : "#OTD 1958, President Eisenhower signed act creating NASA. Our birthday is Oct 1, 1958, when we became operational. https:\/\/t.co\/fFrwrXidOR",
    "id" : 759064199792394242,
    "created_at" : "2016-07-29 16:33:02 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 759113694965932034,
  "created_at" : "2016-07-29 19:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InternationalTigerDay",
      "indices" : [ 25, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bFRvSQRgZp",
      "expanded_url" : "http:\/\/bit.ly\/1SlY80S",
      "display_url" : "bit.ly\/1SlY80S"
    } ]
  },
  "geo" : { },
  "id_str" : "759105226821373952",
  "text" : "RT @WhiteHouseCEQ: Happy #InternationalTigerDay! Check out how @POTUS is protecting wildlife around the world \u2192 https:\/\/t.co\/bFRvSQRgZp htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 44, 50 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouseCEQ\/status\/759094830966329344\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/FWeGxzAsQ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CojYqUYVIAAdDg0.jpg",
        "id_str" : "759094758748790784",
        "id" : 759094758748790784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CojYqUYVIAAdDg0.jpg",
        "sizes" : [ {
          "h" : 218,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/FWeGxzAsQ2"
      } ],
      "hashtags" : [ {
        "text" : "InternationalTigerDay",
        "indices" : [ 6, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/bFRvSQRgZp",
        "expanded_url" : "http:\/\/bit.ly\/1SlY80S",
        "display_url" : "bit.ly\/1SlY80S"
      } ]
    },
    "geo" : { },
    "id_str" : "759094830966329344",
    "text" : "Happy #InternationalTigerDay! Check out how @POTUS is protecting wildlife around the world \u2192 https:\/\/t.co\/bFRvSQRgZp https:\/\/t.co\/FWeGxzAsQ2",
    "id" : 759094830966329344,
    "created_at" : "2016-07-29 18:34:45 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 759105226821373952,
  "created_at" : "2016-07-29 19:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deadspin",
      "screen_name" : "Deadspin",
      "indices" : [ 3, 12 ],
      "id_str" : "13213122",
      "id" : 13213122
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Deadspin\/status\/758750393316802560\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/BtBU31goI3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoefdYdVUAESjuT.jpg",
      "id_str" : "758750389365723137",
      "id" : 758750389365723137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoefdYdVUAESjuT.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2004,
        "resize" : "fit",
        "w" : 3000
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1368,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/BtBU31goI3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/jAgPjizM18",
      "expanded_url" : "http:\/\/deadsp.in\/KPD8dUX",
      "display_url" : "deadsp.in\/KPD8dUX"
    } ]
  },
  "geo" : { },
  "id_str" : "759035053485678593",
  "text" : "RT @Deadspin: The TSA's unrelentingly cheerful helpline is the best thing on Twitter https:\/\/t.co\/jAgPjizM18 https:\/\/t.co\/BtBU31goI3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deadspin\/status\/758750393316802560\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/BtBU31goI3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoefdYdVUAESjuT.jpg",
        "id_str" : "758750389365723137",
        "id" : 758750389365723137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoefdYdVUAESjuT.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2004,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 802,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1368,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/BtBU31goI3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/jAgPjizM18",
        "expanded_url" : "http:\/\/deadsp.in\/KPD8dUX",
        "display_url" : "deadsp.in\/KPD8dUX"
      } ]
    },
    "geo" : { },
    "id_str" : "758750393316802560",
    "text" : "The TSA's unrelentingly cheerful helpline is the best thing on Twitter https:\/\/t.co\/jAgPjizM18 https:\/\/t.co\/BtBU31goI3",
    "id" : 758750393316802560,
    "created_at" : "2016-07-28 19:46:05 +0000",
    "user" : {
      "name" : "Deadspin",
      "screen_name" : "Deadspin",
      "protected" : false,
      "id_str" : "13213122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590240306353811456\/Ee89NSpb_normal.png",
      "id" : 13213122,
      "verified" : true
    }
  },
  "id" : 759035053485678593,
  "created_at" : "2016-07-29 14:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 34, 41 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/rBvDynrOjc",
      "expanded_url" : "http:\/\/snpy.tv\/2a81ulo",
      "display_url" : "snpy.tv\/2a81ulo"
    } ]
  },
  "geo" : { },
  "id_str" : "758802996419448832",
  "text" : "Kids change the world. That\u2019s why @FLOTUS hosted young chefs from across the country for the #KidsStateDinner: https:\/\/t.co\/rBvDynrOjc",
  "id" : 758802996419448832,
  "created_at" : "2016-07-28 23:15:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 80, 87 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/S0cwDahVK8",
      "expanded_url" : "http:\/\/LetsMove.gov",
      "display_url" : "LetsMove.gov"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/rBvDynrOjc",
      "expanded_url" : "http:\/\/snpy.tv\/2a81ulo",
      "display_url" : "snpy.tv\/2a81ulo"
    } ]
  },
  "geo" : { },
  "id_str" : "758792315473309696",
  "text" : "\u201CI see the work of kids, the magic you all do. People change because of kids.\u201D \u2014@FLOTUS: https:\/\/t.co\/S0cwDahVK8 https:\/\/t.co\/rBvDynrOjc",
  "id" : 758792315473309696,
  "created_at" : "2016-07-28 22:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758777453296906241",
  "text" : "RT @VP: Committed. \nTrustworthy. \nAlways loyal.\n\nThat's who the Baton Rouge officers were. We can honor their memory by striving to be the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758773288571052032",
    "text" : "Committed. \nTrustworthy. \nAlways loyal.\n\nThat's who the Baton Rouge officers were. We can honor their memory by striving to be the same.",
    "id" : 758773288571052032,
    "created_at" : "2016-07-28 21:17:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 758777453296906241,
  "created_at" : "2016-07-28 21:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Laos",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/TmZUKDZ4bn",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/ab42524415ef#.z1ui8lx7r",
      "display_url" : "medium.com\/@WhiteHouse\/ab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758772751213690880",
  "text" : "RT @rhodes44: In September, @POTUS will become the first sitting President to visit #Laos. Here's why: https:\/\/t.co\/TmZUKDZ4bn https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 14, 20 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/758763242827022338\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/7QNVqKXRGC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoerH3MUkAA6Ueb.jpg",
        "id_str" : "758763213798281216",
        "id" : 758763213798281216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoerH3MUkAA6Ueb.jpg",
        "sizes" : [ {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 814
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 814
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 814
        } ],
        "display_url" : "pic.twitter.com\/7QNVqKXRGC"
      } ],
      "hashtags" : [ {
        "text" : "Laos",
        "indices" : [ 70, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/TmZUKDZ4bn",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/ab42524415ef#.z1ui8lx7r",
        "display_url" : "medium.com\/@WhiteHouse\/ab\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758763242827022338",
    "text" : "In September, @POTUS will become the first sitting President to visit #Laos. Here's why: https:\/\/t.co\/TmZUKDZ4bn https:\/\/t.co\/7QNVqKXRGC",
    "id" : 758763242827022338,
    "created_at" : "2016-07-28 20:37:08 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 758772751213690880,
  "created_at" : "2016-07-28 21:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758764309476364288",
  "text" : "RT @AmbassadorRice: Next Weds, 8\/3: @POTUS will host a town hall with the Young African Leaders Initiative (#YALI) in Washington, DC \u2192 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YALI",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/mA0w4tmsFP",
        "expanded_url" : "https:\/\/www.facebook.com\/YALINetwork\/photos\/a.324177887663682.72214.316156395132498\/1080722632009200\/?type=3&theater",
        "display_url" : "facebook.com\/YALINetwork\/ph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758758094742577152",
    "text" : "Next Weds, 8\/3: @POTUS will host a town hall with the Young African Leaders Initiative (#YALI) in Washington, DC \u2192 https:\/\/t.co\/mA0w4tmsFP",
    "id" : 758758094742577152,
    "created_at" : "2016-07-28 20:16:41 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 758764309476364288,
  "created_at" : "2016-07-28 20:41:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kirby",
      "screen_name" : "statedeptspox",
      "indices" : [ 16, 30 ],
      "id_str" : "1967216306",
      "id" : 1967216306
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 57, 67 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "France",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/rntsOjxSyM",
      "expanded_url" : "http:\/\/snpy.tv\/2akEQql",
      "display_url" : "snpy.tv\/2akEQql"
    } ]
  },
  "geo" : { },
  "id_str" : "758722865013424128",
  "text" : "RT @StateDept: .@statedeptspox Kirby announces Secretary @JohnKerry's travel to #France https:\/\/t.co\/rntsOjxSyM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kirby",
        "screen_name" : "statedeptspox",
        "indices" : [ 1, 15 ],
        "id_str" : "1967216306",
        "id" : 1967216306
      }, {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 42, 52 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "France",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/rntsOjxSyM",
        "expanded_url" : "http:\/\/snpy.tv\/2akEQql",
        "display_url" : "snpy.tv\/2akEQql"
      } ]
    },
    "geo" : { },
    "id_str" : "758720897951813632",
    "text" : ".@statedeptspox Kirby announces Secretary @JohnKerry's travel to #France https:\/\/t.co\/rntsOjxSyM",
    "id" : 758720897951813632,
    "created_at" : "2016-07-28 17:48:53 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 758722865013424128,
  "created_at" : "2016-07-28 17:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 27, 34 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/758709557975658496\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/kdQ2tDfZ6e",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cod5pEmUsAAeYKj.jpg",
      "id_str" : "758708808751296512",
      "id" : 758708808751296512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cod5pEmUsAAeYKj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kdQ2tDfZ6e"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/4Xw449EFpX",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "758709557975658496",
  "text" : "Get the facts: Here's what @CDCgov can tell us about the spread of the #Zika virus \u2192 https:\/\/t.co\/4Xw449EFpX https:\/\/t.co\/kdQ2tDfZ6e",
  "id" : 758709557975658496,
  "created_at" : "2016-07-28 17:03:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/WnP9sskXzl",
      "expanded_url" : "http:\/\/wapo.st\/29Y5CnR",
      "display_url" : "wapo.st\/29Y5CnR"
    } ]
  },
  "geo" : { },
  "id_str" : "758702548341653504",
  "text" : "RT @PressSec: This is heartbreaking \u2014 and why @POTUS asked for emergency funding to combat #Zika over 5 months ago. https:\/\/t.co\/WnP9sskXzl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 32, 38 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/WnP9sskXzl",
        "expanded_url" : "http:\/\/wapo.st\/29Y5CnR",
        "display_url" : "wapo.st\/29Y5CnR"
      } ]
    },
    "geo" : { },
    "id_str" : "758691312614780928",
    "text" : "This is heartbreaking \u2014 and why @POTUS asked for emergency funding to combat #Zika over 5 months ago. https:\/\/t.co\/WnP9sskXzl",
    "id" : 758691312614780928,
    "created_at" : "2016-07-28 15:51:19 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 758702548341653504,
  "created_at" : "2016-07-28 16:35:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/758697725076639744\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/muuiu01hB2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CodvF0FWIAAtQZH.jpg",
      "id_str" : "758697207906312192",
      "id" : 758697207906312192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CodvF0FWIAAtQZH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/muuiu01hB2"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/4Xw449WgOx",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "758697725076639744",
  "text" : ".@POTUS is calling on Congress to provide emergency funds to fight #Zika. Find out more \u2192 https:\/\/t.co\/4Xw449WgOx https:\/\/t.co\/muuiu01hB2",
  "id" : 758697725076639744,
  "created_at" : "2016-07-28 16:16:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758683627404288000",
  "text" : "RT @FactsOnClimate: To #ActOnClimate, plan ahead! The new Climate Explorer tool helps prepare\nyou for extreme weather in your area \u2192 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 3, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/yeOIcxMgza",
        "expanded_url" : "http:\/\/go.usa.gov\/xYVTH",
        "display_url" : "go.usa.gov\/xYVTH"
      } ]
    },
    "geo" : { },
    "id_str" : "758682217568538624",
    "text" : "To #ActOnClimate, plan ahead! The new Climate Explorer tool helps prepare\nyou for extreme weather in your area \u2192 https:\/\/t.co\/yeOIcxMgza",
    "id" : 758682217568538624,
    "created_at" : "2016-07-28 15:15:10 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 758683627404288000,
  "created_at" : "2016-07-28 15:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 53, 58 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 60, 75 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "WAI at W3C",
      "screen_name" : "w3c_wai",
      "indices" : [ 81, 89 ],
      "id_str" : "29858290",
      "id" : 29858290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA26",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758668825449627648",
  "text" : "26 years of the Americans with Disabilities Act: Ask @VJ44, @WhiteHouseOSTP, and @W3C_wai about web accessibility by 11am ET with #ADA26.",
  "id" : 758668825449627648,
  "created_at" : "2016-07-28 14:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/758478614773977088\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/DC9T67HbK2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoagI52WAAQGnIB.jpg",
      "id_str" : "758469662086660100",
      "id" : 758469662086660100,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoagI52WAAQGnIB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DC9T67HbK2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758478614773977088",
  "text" : "Jobs \u2191\nWind and solar \u2191\nUnemployment \u2193\nUninsured rate \u2193\nMarriage = \n\nProgress. https:\/\/t.co\/DC9T67HbK2",
  "id" : 758478614773977088,
  "created_at" : "2016-07-28 01:46:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/758474626028572673\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/uz6In3PaQy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoafgdqXYAA8LCk.jpg",
      "id_str" : "758468967325458432",
      "id" : 758468967325458432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoafgdqXYAA8LCk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/uz6In3PaQy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758474626028572673",
  "text" : "Now this is what progress looks like. https:\/\/t.co\/uz6In3PaQy",
  "id" : 758474626028572673,
  "created_at" : "2016-07-28 01:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Donovan",
      "screen_name" : "ShaunOMB",
      "indices" : [ 3, 12 ],
      "id_str" : "2207588833",
      "id" : 2207588833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758380865151991808",
  "text" : "RT @ShaunOMB: Veteran homelessness \u2B07 by 36%.\nChronic homelessness \u2B07 by 22%.\nFamily homelessness \u2B07 by 19%.\n\nNow that\u2019s progress. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/bc7gqenj3j",
        "expanded_url" : "http:\/\/bit.ly\/2ahVHdf",
        "display_url" : "bit.ly\/2ahVHdf"
      } ]
    },
    "geo" : { },
    "id_str" : "758378454672875520",
    "text" : "Veteran homelessness \u2B07 by 36%.\nChronic homelessness \u2B07 by 22%.\nFamily homelessness \u2B07 by 19%.\n\nNow that\u2019s progress. https:\/\/t.co\/bc7gqenj3j",
    "id" : 758378454672875520,
    "created_at" : "2016-07-27 19:08:08 +0000",
    "user" : {
      "name" : "Shaun Donovan",
      "screen_name" : "ShaunOMB",
      "protected" : false,
      "id_str" : "2207588833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000771300655\/430835535c9ab3f854683bc176cc0a65_normal.jpeg",
      "id" : 2207588833,
      "verified" : true
    }
  },
  "id" : 758380865151991808,
  "created_at" : "2016-07-27 19:17:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "WAI at W3C",
      "screen_name" : "w3c_wai",
      "indices" : [ 51, 59 ],
      "id_str" : "29858290",
      "id" : 29858290
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 70, 85 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758369477943754752",
  "text" : "RT @vj44: Qs on making the web accessible for all? @W3C_wai's joining\n@WhiteHouseOSTP's Tom Kalil &amp; me to answer. Ask by Thurs at 11am ET w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WAI at W3C",
        "screen_name" : "w3c_wai",
        "indices" : [ 41, 49 ],
        "id_str" : "29858290",
        "id" : 29858290
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 60, 75 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ADA26",
        "indices" : [ 137, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758362324361019392",
    "text" : "Qs on making the web accessible for all? @W3C_wai's joining\n@WhiteHouseOSTP's Tom Kalil &amp; me to answer. Ask by Thurs at 11am ET with\n#ADA26!",
    "id" : 758362324361019392,
    "created_at" : "2016-07-27 18:04:02 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 758369477943754752,
  "created_at" : "2016-07-27 18:32:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "David Lienemann",
      "screen_name" : "dcclphoto",
      "indices" : [ 37, 47 ],
      "id_str" : "2593484713",
      "id" : 2593484713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/4enujpZZvj",
      "expanded_url" : "https:\/\/goo.gl\/X58wCq",
      "display_url" : "goo.gl\/X58wCq"
    } ]
  },
  "geo" : { },
  "id_str" : "758351857739759616",
  "text" : "RT @DrBiden: Go behind the lens with @dcclphoto and see more photos from Dr. Biden's trip to Africa last week \u2192 https:\/\/t.co\/4enujpZZvj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Lienemann",
        "screen_name" : "dcclphoto",
        "indices" : [ 24, 34 ],
        "id_str" : "2593484713",
        "id" : 2593484713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/4enujpZZvj",
        "expanded_url" : "https:\/\/goo.gl\/X58wCq",
        "display_url" : "goo.gl\/X58wCq"
      } ]
    },
    "geo" : { },
    "id_str" : "758351405568712704",
    "text" : "Go behind the lens with @dcclphoto and see more photos from Dr. Biden's trip to Africa last week \u2192 https:\/\/t.co\/4enujpZZvj",
    "id" : 758351405568712704,
    "created_at" : "2016-07-27 17:20:39 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 758351857739759616,
  "created_at" : "2016-07-27 17:22:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "indices" : [ 3, 15 ],
      "id_str" : "701725963",
      "id" : 701725963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758326988125843457",
  "text" : "RT @nowthisnews: We celebrated Eid at the White House with President Obama and spoke to these hard-working, talented Muslim Americans https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/AWeiJljwxE",
        "expanded_url" : "http:\/\/on.nowth.is\/1dna",
        "display_url" : "on.nowth.is\/1dna"
      } ]
    },
    "geo" : { },
    "id_str" : "758324077534650368",
    "text" : "We celebrated Eid at the White House with President Obama and spoke to these hard-working, talented Muslim Americans https:\/\/t.co\/AWeiJljwxE",
    "id" : 758324077534650368,
    "created_at" : "2016-07-27 15:32:03 +0000",
    "user" : {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "protected" : false,
      "id_str" : "701725963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783053831844298754\/p8H7pdtz_normal.jpg",
      "id" : 701725963,
      "verified" : true
    }
  },
  "id" : 758326988125843457,
  "created_at" : "2016-07-27 15:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ombRb7sS4a",
      "expanded_url" : "http:\/\/www.hhs.gov\/blog\/2016\/07\/25\/heres-what-you-need-to-know-about-the-zika-virus.html",
      "display_url" : "hhs.gov\/blog\/2016\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758304644422508544",
  "text" : "RT @SecBurwell: Here\u2019s what we\u2019ve learned about the #Zika virus\u2026and what you should know to protect yourself https:\/\/t.co\/ombRb7sS4a https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SecBurwell\/status\/758051638292643840\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/QF3eG6sxYl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUjwGlWgAARxNY.jpg",
        "id_str" : "758051421589766144",
        "id" : 758051421589766144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUjwGlWgAARxNY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/QF3eG6sxYl"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 36, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ombRb7sS4a",
        "expanded_url" : "http:\/\/www.hhs.gov\/blog\/2016\/07\/25\/heres-what-you-need-to-know-about-the-zika-virus.html",
        "display_url" : "hhs.gov\/blog\/2016\/07\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758051638292643840",
    "text" : "Here\u2019s what we\u2019ve learned about the #Zika virus\u2026and what you should know to protect yourself https:\/\/t.co\/ombRb7sS4a https:\/\/t.co\/QF3eG6sxYl",
    "id" : 758051638292643840,
    "created_at" : "2016-07-26 21:29:29 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 758304644422508544,
  "created_at" : "2016-07-27 14:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/11cHO1CUfJ",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/why-im-here-the-importance-of-the-u-s-china-relationship-efb3fd167d81#.62opcxiv3",
      "display_url" : "medium.com\/@WhiteHouse\/wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758290567033868288",
  "text" : "RT @AmbassadorRice: Why I\u2019m Here: The Importance of the U.S.\u200A\u2014\u200AChina Relationship--https:\/\/t.co\/11cHO1CUfJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/11cHO1CUfJ",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/why-im-here-the-importance-of-the-u-s-china-relationship-efb3fd167d81#.62opcxiv3",
        "display_url" : "medium.com\/@WhiteHouse\/wh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757940220494950400",
    "text" : "Why I\u2019m Here: The Importance of the U.S.\u200A\u2014\u200AChina Relationship--https:\/\/t.co\/11cHO1CUfJ",
    "id" : 757940220494950400,
    "created_at" : "2016-07-26 14:06:45 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 758290567033868288,
  "created_at" : "2016-07-27 13:18:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/0cEYUFTzZD",
      "expanded_url" : "http:\/\/go.wh.gov\/XjMMtj",
      "display_url" : "go.wh.gov\/XjMMtj"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/0PzMYPjy40",
      "expanded_url" : "http:\/\/snpy.tv\/2a2DJet",
      "display_url" : "snpy.tv\/2a2DJet"
    } ]
  },
  "geo" : { },
  "id_str" : "758042200580116481",
  "text" : "\"The ADA sought to guarantee that the places we share...truly belong to everyone.\" \u2014@POTUS: https:\/\/t.co\/0cEYUFTzZD https:\/\/t.co\/0PzMYPjy40",
  "id" : 758042200580116481,
  "created_at" : "2016-07-26 20:51:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    }, {
      "name" : "Medscape",
      "screen_name" : "Medscape",
      "indices" : [ 83, 92 ],
      "id_str" : "16892009",
      "id" : 16892009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "ZikaMedChat",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758038542450696194",
  "text" : "RT @DrFriedenCDC: Healthcare providers: Have questions about #Zika? Join CDC &amp; @Medscape for #ZikaMedChat this Wed, July 27 at 7PM ET. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medscape",
        "screen_name" : "Medscape",
        "indices" : [ 65, 74 ],
        "id_str" : "16892009",
        "id" : 16892009
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrFriedenCDC\/status\/758024129530462209\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/hGOzn3BxA6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoUK7VCXgAESYj0.jpg",
        "id_str" : "758024126657429505",
        "id" : 758024126657429505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoUK7VCXgAESYj0.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/hGOzn3BxA6"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 43, 48 ]
      }, {
        "text" : "ZikaMedChat",
        "indices" : [ 79, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758024129530462209",
    "text" : "Healthcare providers: Have questions about #Zika? Join CDC &amp; @Medscape for #ZikaMedChat this Wed, July 27 at 7PM ET. https:\/\/t.co\/hGOzn3BxA6",
    "id" : 758024129530462209,
    "created_at" : "2016-07-26 19:40:10 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 758038542450696194,
  "created_at" : "2016-07-26 20:37:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 57, 68 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758021460002615296",
  "text" : "RT @Cecilia44: Important steps announced today to expand @WhiteHouse efforts to protect refugees from Central America https:\/\/t.co\/txjkxq8c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/txjkxq8c6a",
        "expanded_url" : "http:\/\/www.state.gov\/r\/pa\/prs\/ps\/2016\/07\/260507.htm",
        "display_url" : "state.gov\/r\/pa\/prs\/ps\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758016799111643136",
    "text" : "Important steps announced today to expand @WhiteHouse efforts to protect refugees from Central America https:\/\/t.co\/txjkxq8c6a",
    "id" : 758016799111643136,
    "created_at" : "2016-07-26 19:11:02 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 758021460002615296,
  "created_at" : "2016-07-26 19:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/0cEYUFTzZD",
      "expanded_url" : "http:\/\/go.wh.gov\/XjMMtj",
      "display_url" : "go.wh.gov\/XjMMtj"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/0PzMYPjy40",
      "expanded_url" : "http:\/\/snpy.tv\/2a2DJet",
      "display_url" : "snpy.tv\/2a2DJet"
    } ]
  },
  "geo" : { },
  "id_str" : "758019375962005505",
  "text" : "\"America is stronger and more vibrant. It's a better country because of the ADA.\" \u2014@POTUS:  https:\/\/t.co\/0cEYUFTzZD https:\/\/t.co\/0PzMYPjy40",
  "id" : 758019375962005505,
  "created_at" : "2016-07-26 19:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/757981304411402240\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bWz4fNsnTj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTjl4xW8AAApxy.jpg",
      "id_str" : "757980877339160576",
      "id" : 757980877339160576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTjl4xW8AAApxy.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/bWz4fNsnTj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/0cEYUFTzZD",
      "expanded_url" : "http:\/\/go.wh.gov\/XjMMtj",
      "display_url" : "go.wh.gov\/XjMMtj"
    } ]
  },
  "geo" : { },
  "id_str" : "757981304411402240",
  "text" : "Our diversity is our strength. @POTUS on 26 years of the Americans with Disabilities Act: https:\/\/t.co\/0cEYUFTzZD https:\/\/t.co\/bWz4fNsnTj",
  "id" : 757981304411402240,
  "created_at" : "2016-07-26 16:50:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 24, 32 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/757963857931345920\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/QQccDFx7n6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTUEzLWIAEoJkn.jpg",
      "id_str" : "757963816227446785",
      "id" : 757963816227446785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTUEzLWIAEoJkn.jpg",
      "sizes" : [ {
        "h" : 273,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 857
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 857
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 857
      } ],
      "display_url" : "pic.twitter.com\/QQccDFx7n6"
    } ],
    "hashtags" : [ {
      "text" : "Mogadishu",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/WpBMhd0IoH",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/26\/statement-nsc-spokesperson-ned-price-terrorist-attack-mogadishu-somalia",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757974473316237312",
  "text" : "RT @NSC44: Statement by @Price44 on the Terrorist Attack in Mogadishu, Somalia: https:\/\/t.co\/WpBMhd0IoH #Mogadishu https:\/\/t.co\/QQccDFx7n6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ned Price",
        "screen_name" : "Price44",
        "indices" : [ 13, 21 ],
        "id_str" : "4518870555",
        "id" : 4518870555
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/757963857931345920\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/QQccDFx7n6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTUEzLWIAEoJkn.jpg",
        "id_str" : "757963816227446785",
        "id" : 757963816227446785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTUEzLWIAEoJkn.jpg",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 857
        } ],
        "display_url" : "pic.twitter.com\/QQccDFx7n6"
      } ],
      "hashtags" : [ {
        "text" : "Mogadishu",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/WpBMhd0IoH",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/26\/statement-nsc-spokesperson-ned-price-terrorist-attack-mogadishu-somalia",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757963857931345920",
    "text" : "Statement by @Price44 on the Terrorist Attack in Mogadishu, Somalia: https:\/\/t.co\/WpBMhd0IoH #Mogadishu https:\/\/t.co\/QQccDFx7n6",
    "id" : 757963857931345920,
    "created_at" : "2016-07-26 15:40:40 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 757974473316237312,
  "created_at" : "2016-07-26 16:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 24, 32 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "normandy",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/WZBGM5K23i",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/26\/statement-nsc-spokesperson-ned-price-terrorist-attack-church-normandy",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757968455022874625",
  "text" : "RT @NSC44: Statement by @Price44 on the Terrorist Attack at a Church in Normandy, France: https:\/\/t.co\/WZBGM5K23i\n#normandy https:\/\/t.co\/oZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ned Price",
        "screen_name" : "Price44",
        "indices" : [ 13, 21 ],
        "id_str" : "4518870555",
        "id" : 4518870555
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/757962929782218758\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/oZc3oxipSO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTTKc9WEAACZun.jpg",
        "id_str" : "757962813830729728",
        "id" : 757962813830729728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTTKc9WEAACZun.jpg",
        "sizes" : [ {
          "h" : 352,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/oZc3oxipSO"
      } ],
      "hashtags" : [ {
        "text" : "normandy",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/WZBGM5K23i",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/26\/statement-nsc-spokesperson-ned-price-terrorist-attack-church-normandy",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757962929782218758",
    "text" : "Statement by @Price44 on the Terrorist Attack at a Church in Normandy, France: https:\/\/t.co\/WZBGM5K23i\n#normandy https:\/\/t.co\/oZc3oxipSO",
    "id" : 757962929782218758,
    "created_at" : "2016-07-26 15:36:59 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 757968455022874625,
  "created_at" : "2016-07-26 15:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/757960596117749760\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kAIIFoKWOD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTPScQWAAI4wov.jpg",
      "id_str" : "757958553034424322",
      "id" : 757958553034424322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTPScQWAAI4wov.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/kAIIFoKWOD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/0cEYUGbbod",
      "expanded_url" : "http:\/\/go.wh.gov\/XjMMtj",
      "display_url" : "go.wh.gov\/XjMMtj"
    } ]
  },
  "geo" : { },
  "id_str" : "757960596117749760",
  "text" : "26 years ago, our nation marked a pivotal moment in history for Americans with disabilities: https:\/\/t.co\/0cEYUGbbod https:\/\/t.co\/kAIIFoKWOD",
  "id" : 757960596117749760,
  "created_at" : "2016-07-26 15:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cybersecurity",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757955534389555200",
  "text" : "RT @NSC44: The President has made our nation's #cybersecurity a top priority. Today's Policy Directive shows it. Get the facts: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cybersecurity",
        "indices" : [ 36, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/IUO0o3BSiM",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/26\/fact-sheet-presidential-policy-directive-united-states-cyber-incident-0",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757953846081576960",
    "text" : "The President has made our nation's #cybersecurity a top priority. Today's Policy Directive shows it. Get the facts: https:\/\/t.co\/IUO0o3BSiM",
    "id" : 757953846081576960,
    "created_at" : "2016-07-26 15:00:53 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 757955534389555200,
  "created_at" : "2016-07-26 15:07:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757695777393283072",
  "text" : "RT @vj44: Change happens when one American at a time can no longer stay silent. Thank you Michael Jordan for speaking up! https:\/\/t.co\/YC0Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/YC0YqFcLvL",
        "expanded_url" : "https:\/\/twitter.com\/espn\/status\/757618406271090688",
        "display_url" : "twitter.com\/espn\/status\/75\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757695256473108480",
    "text" : "Change happens when one American at a time can no longer stay silent. Thank you Michael Jordan for speaking up! https:\/\/t.co\/YC0YqFcLvL",
    "id" : 757695256473108480,
    "created_at" : "2016-07-25 21:53:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 757695777393283072,
  "created_at" : "2016-07-25 21:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757620325026639873",
  "text" : "RT @LaborSec: It's been 7 years since the federal minimum wage was raised. Now more than ever, it's time to #RaiseTheWage. https:\/\/t.co\/S9q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 94, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/S9qAWzh489",
        "expanded_url" : "https:\/\/blog.dol.gov\/2016\/07\/22\/7-facts-about-the-minimum-wage\/",
        "display_url" : "blog.dol.gov\/2016\/07\/22\/7-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757616450614034432",
    "text" : "It's been 7 years since the federal minimum wage was raised. Now more than ever, it's time to #RaiseTheWage. https:\/\/t.co\/S9qAWzh489",
    "id" : 757616450614034432,
    "created_at" : "2016-07-25 16:40:12 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 757620325026639873,
  "created_at" : "2016-07-25 16:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 49, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757619149220614144",
  "text" : "RT @FactsOnClimate: Announcing the sequel to the #ParisAgreement \u2014 \"the most significant action this year\" to reduce global warming: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 29, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/FiJZ0gF4ka",
        "expanded_url" : "http:\/\/nyti.ms\/29S4tmh",
        "display_url" : "nyti.ms\/29S4tmh"
      } ]
    },
    "geo" : { },
    "id_str" : "757614710057529345",
    "text" : "Announcing the sequel to the #ParisAgreement \u2014 \"the most significant action this year\" to reduce global warming: https:\/\/t.co\/FiJZ0gF4ka",
    "id" : 757614710057529345,
    "created_at" : "2016-07-25 16:33:17 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 757619149220614144,
  "created_at" : "2016-07-25 16:50:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/T2I1DqL6vd",
      "expanded_url" : "http:\/\/snpy.tv\/2anWKdj",
      "display_url" : "snpy.tv\/2anWKdj"
    } ]
  },
  "geo" : { },
  "id_str" : "757291484882333698",
  "text" : "Go behind the scenes with @POTUS and @FLOTUS in the latest episode of #WestWingWeek: https:\/\/t.co\/T2I1DqL6vd",
  "id" : 757291484882333698,
  "created_at" : "2016-07-24 19:08:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fema\/status\/756892573009080321\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MwE5qoWTiC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoEFTHeXgAEsgsm.jpg",
      "id_str" : "756892038357024769",
      "id" : 756892038357024769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoEFTHeXgAEsgsm.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 515
      } ],
      "display_url" : "pic.twitter.com\/MwE5qoWTiC"
    } ],
    "hashtags" : [ {
      "text" : "heatwave",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/hPfOhoXpnf",
      "expanded_url" : "http:\/\/www.fema.gov\/blog\/2016-07-22\/beat-heat",
      "display_url" : "fema.gov\/blog\/2016-07-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757258476875870208",
  "text" : "RT @fema: Be smart &amp; safe during this weekend's #heatwave with these tips: https:\/\/t.co\/hPfOhoXpnf https:\/\/t.co\/MwE5qoWTiC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/756892573009080321\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/MwE5qoWTiC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoEFTHeXgAEsgsm.jpg",
        "id_str" : "756892038357024769",
        "id" : 756892038357024769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoEFTHeXgAEsgsm.jpg",
        "sizes" : [ {
          "h" : 424,
          "resize" : "fit",
          "w" : 515
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 515
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 515
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 515
        } ],
        "display_url" : "pic.twitter.com\/MwE5qoWTiC"
      } ],
      "hashtags" : [ {
        "text" : "heatwave",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/hPfOhoXpnf",
        "expanded_url" : "http:\/\/www.fema.gov\/blog\/2016-07-22\/beat-heat",
        "display_url" : "fema.gov\/blog\/2016-07-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756892573009080321",
    "text" : "Be smart &amp; safe during this weekend's #heatwave with these tips: https:\/\/t.co\/hPfOhoXpnf https:\/\/t.co\/MwE5qoWTiC",
    "id" : 756892573009080321,
    "created_at" : "2016-07-23 16:43:46 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 757258476875870208,
  "created_at" : "2016-07-24 16:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 12, 17 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Zj6EbdeS2v",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "757247237332230144",
  "text" : "\"Before the @CFPB, you didn\u2019t have a strong ally to turn to if your bank took advantage of you\u2026Now you do.\" \u2014@POTUS https:\/\/t.co\/Zj6EbdeS2v",
  "id" : 757247237332230144,
  "created_at" : "2016-07-24 16:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 101, 110 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/756957889860923393\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Nl4wgrbTdn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoFA2oPXYAAYY7F.jpg",
      "id_str" : "756957519633932288",
      "id" : 756957519633932288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoFA2oPXYAAYY7F.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/Nl4wgrbTdn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756957889860923393",
  "text" : "\"The United States condemns in the strongest terms the horrific attack today in Kabul, Afghanistan\" \u2014@PressSec: https:\/\/t.co\/Nl4wgrbTdn",
  "id" : 756957889860923393,
  "created_at" : "2016-07-23 21:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756949776122339328",
  "text" : "RT @USDOL: While the federal minimum wage hasn't been raised for 7 years, these states have taken action to #RaiseTheWage. https:\/\/t.co\/FTE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/756938363719090176\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/FTEhY6PPNE",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoEvbUqXgAAzgce.jpg",
        "id_str" : "756938358824337408",
        "id" : 756938358824337408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoEvbUqXgAAzgce.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FTEhY6PPNE"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756938363719090176",
    "text" : "While the federal minimum wage hasn't been raised for 7 years, these states have taken action to #RaiseTheWage. https:\/\/t.co\/FTEhY6PPNE",
    "id" : 756938363719090176,
    "created_at" : "2016-07-23 19:45:43 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 756949776122339328,
  "created_at" : "2016-07-23 20:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Zj6EbcXhaX",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "756944043280572416",
  "text" : "\"Strong consumer protections meant establishing the first-ever Consumer Financial Protection Bureau\" \u2014@POTUS https:\/\/t.co\/Zj6EbcXhaX",
  "id" : 756944043280572416,
  "created_at" : "2016-07-23 20:08:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HOHQRczOH4",
      "expanded_url" : "http:\/\/CFPB.gov",
      "display_url" : "CFPB.gov"
    }, {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Zj6EbdeS2v",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "756915642029092864",
  "text" : "Before you take out a mortgage, or a loan for college or a new car, check out https:\/\/t.co\/HOHQRczOH4: https:\/\/t.co\/Zj6EbdeS2v",
  "id" : 756915642029092864,
  "created_at" : "2016-07-23 18:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 87, 97 ],
      "id_str" : "970207298",
      "id" : 970207298
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 105, 110 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Zj6EbdeS2v",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "756904314698813440",
  "text" : "\"We\u2019ve seen what happened to the economy when we didn\u2019t have these rules.\" \u2014@POTUS and @SenWarren on the @CFPB: https:\/\/t.co\/Zj6EbdeS2v",
  "id" : 756904314698813440,
  "created_at" : "2016-07-23 17:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 43, 53 ],
      "id_str" : "970207298",
      "id" : 970207298
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Zj6EbdeS2v",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "756889233629941760",
  "text" : "\"It\u2019s about basic fairness for everyone.\" \u2014@SenWarren\n \n\"And it\u2019s about responsibility from everyone.\" \u2014@POTUS: https:\/\/t.co\/Zj6EbdeS2v",
  "id" : 756889233629941760,
  "created_at" : "2016-07-23 16:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Zj6EbdeS2v",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "756880557661749250",
  "text" : "If you\u2019re a hardworking American who plays by the rules, you should expect Wall Street to play by the rules, too. https:\/\/t.co\/Zj6EbdeS2v",
  "id" : 756880557661749250,
  "created_at" : "2016-07-23 15:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 1, 11 ],
      "id_str" : "970207298",
      "id" : 970207298
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Zj6EbdeS2v",
      "expanded_url" : "http:\/\/go.wh.gov\/9mNWLP",
      "display_url" : "go.wh.gov\/9mNWLP"
    } ]
  },
  "geo" : { },
  "id_str" : "756869019097927680",
  "text" : ".@SenWarren joined @POTUS for this week's address on protecting American consumers\u2014watch: https:\/\/t.co\/Zj6EbdeS2v",
  "id" : 756869019097927680,
  "created_at" : "2016-07-23 15:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "indices" : [ 3, 10 ],
      "id_str" : "2151620534",
      "id" : 2151620534
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756620706134290436",
  "text" : "RT @Hill44: .@POTUS on signing opioid bill: \"Now, it\u2019s up to Republicans to finish the job and provide adequate funding\" https:\/\/t.co\/XbGxx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Hill44\/status\/756613152322662400\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/XbGxxYyIQX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoAHcTXVMAAraLA.jpg",
        "id_str" : "756612920214106112",
        "id" : 756612920214106112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoAHcTXVMAAraLA.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 1185
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 1185
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 1185
        } ],
        "display_url" : "pic.twitter.com\/XbGxxYyIQX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756613152322662400",
    "text" : ".@POTUS on signing opioid bill: \"Now, it\u2019s up to Republicans to finish the job and provide adequate funding\" https:\/\/t.co\/XbGxxYyIQX",
    "id" : 756613152322662400,
    "created_at" : "2016-07-22 22:13:27 +0000",
    "user" : {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "protected" : false,
      "id_str" : "2151620534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658658579142959104\/85LEK24P_normal.jpg",
      "id" : 2151620534,
      "verified" : true
    }
  },
  "id" : 756620706134290436,
  "created_at" : "2016-07-22 22:43:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/756588504822362113\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/bAoTmnpE0V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_xKYkVIAAGsFC.jpg",
      "id_str" : "756588423117348864",
      "id" : 756588423117348864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_xKYkVIAAGsFC.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 1030
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 1030
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 1030
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bAoTmnpE0V"
    } ],
    "hashtags" : [ {
      "text" : "Munich",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756588504822362113",
  "text" : "Statement from @PressSec on the apparent terrorist attack in #Munich. https:\/\/t.co\/bAoTmnpE0V",
  "id" : 756588504822362113,
  "created_at" : "2016-07-22 20:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Munich",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756570643181645824",
  "text" : "RT @Price44: Lisa Monaco apprised @POTUS of the developing situation in #Munich.The President will continue to be updated as the situation\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Munich",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756569011060695044",
    "text" : "Lisa Monaco apprised @POTUS of the developing situation in #Munich.The President will continue to be updated as the situation warrants.",
    "id" : 756569011060695044,
    "created_at" : "2016-07-22 19:18:03 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 756570643181645824,
  "created_at" : "2016-07-22 19:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756568961546854400",
  "text" : "RT @POTUS: \u00A1Bienvenido, amigo! We value our enduring partnership with Mexico &amp; will work to strengthen it in the years to come. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/mjlABSm7jF",
        "expanded_url" : "https:\/\/twitter.com\/EPN\/status\/756289302418497536",
        "display_url" : "twitter.com\/EPN\/status\/756\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756568912691601410",
    "text" : "\u00A1Bienvenido, amigo! We value our enduring partnership with Mexico &amp; will work to strengthen it in the years to come. https:\/\/t.co\/mjlABSm7jF",
    "id" : 756568912691601410,
    "created_at" : "2016-07-22 19:17:39 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 756568961546854400,
  "created_at" : "2016-07-22 19:17:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Munich",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/RKJMCirtS9",
      "expanded_url" : "http:\/\/snpy.tv\/2a68PpF",
      "display_url" : "snpy.tv\/2a68PpF"
    } ]
  },
  "geo" : { },
  "id_str" : "756567128661233664",
  "text" : "Watch as @POTUS provides an update on the developing situation in #Munich, Germany: https:\/\/t.co\/RKJMCirtS9",
  "id" : 756567128661233664,
  "created_at" : "2016-07-22 19:10:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ktcGCL46ED",
      "expanded_url" : "http:\/\/go.wh.gov\/L7DTSQ",
      "display_url" : "go.wh.gov\/L7DTSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "756562873380397057",
  "text" : "Watch as @POTUS makes a surprise drop by at the 21st Century Policing briefing: https:\/\/t.co\/ktcGCL46ED",
  "id" : 756562873380397057,
  "created_at" : "2016-07-22 18:53:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Z4jQAexZxD",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "756562675556114432",
  "text" : "RT @vj44: Surprise drop by from @POTUS during the 21st Century Policing Briefing. Tune in now: https:\/\/t.co\/Z4jQAexZxD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/Z4jQAexZxD",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "756562209430466561",
    "text" : "Surprise drop by from @POTUS during the 21st Century Policing Briefing. Tune in now: https:\/\/t.co\/Z4jQAexZxD",
    "id" : 756562209430466561,
    "created_at" : "2016-07-22 18:51:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 756562675556114432,
  "created_at" : "2016-07-22 18:52:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/npj5749tBB",
      "expanded_url" : "http:\/\/bit.ly\/2afp98h",
      "display_url" : "bit.ly\/2afp98h"
    } ]
  },
  "geo" : { },
  "id_str" : "756552963393327104",
  "text" : "RT @DrFriedenCDC: The only winner from the failure of the supplemental funding is the #Zika virus. https:\/\/t.co\/npj5749tBB via @NatGeoScien\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nat Geo Science",
        "screen_name" : "NatGeoScience",
        "indices" : [ 109, 123 ],
        "id_str" : "97701898",
        "id" : 97701898
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 68, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/npj5749tBB",
        "expanded_url" : "http:\/\/bit.ly\/2afp98h",
        "display_url" : "bit.ly\/2afp98h"
      } ]
    },
    "geo" : { },
    "id_str" : "756539367959752704",
    "text" : "The only winner from the failure of the supplemental funding is the #Zika virus. https:\/\/t.co\/npj5749tBB via @NatGeoScience",
    "id" : 756539367959752704,
    "created_at" : "2016-07-22 17:20:15 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 756552963393327104,
  "created_at" : "2016-07-22 18:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/QrvmlE1LZl",
      "expanded_url" : "http:\/\/snpy.tv\/2aiHIpk",
      "display_url" : "snpy.tv\/2aiHIpk"
    } ]
  },
  "geo" : { },
  "id_str" : "756543672947093504",
  "text" : "Today, @POTUS laid out the #TPP improves on previous trade agreements to benefit U.S. workers. https:\/\/t.co\/QrvmlE1LZl",
  "id" : 756543672947093504,
  "created_at" : "2016-07-22 17:37:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 112, 116 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kcCbHNvY6Q",
      "expanded_url" : "http:\/\/snpy.tv\/2a2WsHj",
      "display_url" : "snpy.tv\/2a2WsHj"
    } ]
  },
  "geo" : { },
  "id_str" : "756537955561320448",
  "text" : "\u201CThe United States values tremendously our enduring partnership with Mexico\" \u2014@POTUS in a press conference with @EPN https:\/\/t.co\/kcCbHNvY6Q",
  "id" : 756537955561320448,
  "created_at" : "2016-07-22 17:14:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 72, 76 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mexico",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/8aXmJl2vea",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "756526517283323905",
  "text" : "RT @lacasablanca: En Vivo Ahora: ruedo de prensa con @POTUS y #Mexico's @EPN https:\/\/t.co\/8aXmJl2vea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 35, 41 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Enrique Pe\u00F1a Nieto",
        "screen_name" : "EPN",
        "indices" : [ 54, 58 ],
        "id_str" : "2897441",
        "id" : 2897441
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mexico",
        "indices" : [ 44, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/8aXmJl2vea",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "756524693851602944",
    "text" : "En Vivo Ahora: ruedo de prensa con @POTUS y #Mexico's @EPN https:\/\/t.co\/8aXmJl2vea",
    "id" : 756524693851602944,
    "created_at" : "2016-07-22 16:21:57 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 756526517283323905,
  "created_at" : "2016-07-22 16:29:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756521805628792832",
  "text" : "\u201CI\u2019m confident that our nations will continue to grow even stronger and more prosperous together.\" \u2014@POTUS with President Nieto of Mexico",
  "id" : 756521805628792832,
  "created_at" : "2016-07-22 16:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756521564544393216",
  "text" : "RT @WHLive: \u201CWe\u2019ll continue to protect the safety and health of our people\u2014especially from the opioid epidemic that is taking so many lives\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 130, 136 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756521152097480704",
    "text" : "\u201CWe\u2019ll continue to protect the safety and health of our people\u2014especially from the opioid epidemic that is taking so many lives\" \u2014@POTUS",
    "id" : 756521152097480704,
    "created_at" : "2016-07-22 16:07:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 756521564544393216,
  "created_at" : "2016-07-22 16:09:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756520725385740288",
  "text" : "\u201CWe\u2019re not just strategic or economic partners\u2014we\u2019re neighbors, and we\u2019re friends\u201D \u2014@POTUS with President Nieto of Mexico",
  "id" : 756520725385740288,
  "created_at" : "2016-07-22 16:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756520445596360705",
  "text" : "\u201CEvery year, millions of tourists and businesspeople and friends and families cross our border legally.\u201D \u2014@POTUS with President Nieto",
  "id" : 756520445596360705,
  "created_at" : "2016-07-22 16:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756520081924980736",
  "text" : "\u201CMexico is our third-largest trading partner. We sell more to Mexico than we do to China, India and Russia combined.\" \u2014@POTUS",
  "id" : 756520081924980736,
  "created_at" : "2016-07-22 16:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756519962420871168",
  "text" : "\u201CThe United States values tremendously our enduring partnership with Mexico and our extraordinary ties\" \u2014@POTUS with President Nieto",
  "id" : 756519962420871168,
  "created_at" : "2016-07-22 16:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Llr1WYbl9E",
      "expanded_url" : "http:\/\/go.wh.gov\/UmUTvG",
      "display_url" : "go.wh.gov\/UmUTvG"
    } ]
  },
  "geo" : { },
  "id_str" : "756519785752649728",
  "text" : "RT @WHLive: Happening now: @POTUS holds a press conference with President Pe\u00F1a Nieto of Mexico \u2192 https:\/\/t.co\/Llr1WYbl9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/Llr1WYbl9E",
        "expanded_url" : "http:\/\/go.wh.gov\/UmUTvG",
        "display_url" : "go.wh.gov\/UmUTvG"
      } ]
    },
    "geo" : { },
    "id_str" : "756519751720001536",
    "text" : "Happening now: @POTUS holds a press conference with President Pe\u00F1a Nieto of Mexico \u2192 https:\/\/t.co\/Llr1WYbl9E",
    "id" : 756519751720001536,
    "created_at" : "2016-07-22 16:02:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 756519785752649728,
  "created_at" : "2016-07-22 16:02:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/756510294231412736\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/xlXHxHoNbN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn-o4isUAAAWE3o.jpg",
      "id_str" : "756508951760338944",
      "id" : 756508951760338944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn-o4isUAAAWE3o.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/xlXHxHoNbN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/0WZyzTJqiI",
      "expanded_url" : "http:\/\/go.wh.gov\/UmUTvG",
      "display_url" : "go.wh.gov\/UmUTvG"
    } ]
  },
  "geo" : { },
  "id_str" : "756510294231412736",
  "text" : "At 11:45am ET, @POTUS holds a press conference with President Pe\u00F1a Nieto of Mexico \u2192 https:\/\/t.co\/0WZyzTJqiI \uD83C\uDDF2\uD83C\uDDFD  \uD83C\uDDFA https:\/\/t.co\/xlXHxHoNbN",
  "id" : 756510294231412736,
  "created_at" : "2016-07-22 15:24:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    }, {
      "name" : "NWS",
      "screen_name" : "NWS",
      "indices" : [ 47, 51 ],
      "id_str" : "454313925",
      "id" : 454313925
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 66, 71 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CraigatFEMA\/status\/756495711437410304\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/eIwTIprs8t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn-c1RpVIAIjw_o.jpg",
      "id_str" : "756495701505286146",
      "id" : 756495701505286146,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn-c1RpVIAIjw_o.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 891
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 891
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 891
      } ],
      "display_url" : "pic.twitter.com\/eIwTIprs8t"
    } ],
    "hashtags" : [ {
      "text" : "BeatTheHeat",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/iXybZNHbUh",
      "expanded_url" : "https:\/\/www.fema.gov\/mobile-app",
      "display_url" : "fema.gov\/mobile-app"
    } ]
  },
  "geo" : { },
  "id_str" : "756505049115729920",
  "text" : "RT @CraigatFEMA: Get your heat alerts from the @NWS, download the @FEMA app  https:\/\/t.co\/iXybZNHbUh  #BeatTheHeat https:\/\/t.co\/eIwTIprs8t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NWS",
        "screen_name" : "NWS",
        "indices" : [ 30, 34 ],
        "id_str" : "454313925",
        "id" : 454313925
      }, {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 49, 54 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CraigatFEMA\/status\/756495711437410304\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/eIwTIprs8t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn-c1RpVIAIjw_o.jpg",
        "id_str" : "756495701505286146",
        "id" : 756495701505286146,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn-c1RpVIAIjw_o.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 891
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 891
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 891
        } ],
        "display_url" : "pic.twitter.com\/eIwTIprs8t"
      } ],
      "hashtags" : [ {
        "text" : "BeatTheHeat",
        "indices" : [ 85, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/iXybZNHbUh",
        "expanded_url" : "https:\/\/www.fema.gov\/mobile-app",
        "display_url" : "fema.gov\/mobile-app"
      } ]
    },
    "geo" : { },
    "id_str" : "756495711437410304",
    "text" : "Get your heat alerts from the @NWS, download the @FEMA app  https:\/\/t.co\/iXybZNHbUh  #BeatTheHeat https:\/\/t.co\/eIwTIprs8t",
    "id" : 756495711437410304,
    "created_at" : "2016-07-22 14:26:47 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 756505049115729920,
  "created_at" : "2016-07-22 15:03:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabi Chojkier",
      "screen_name" : "Gabi44",
      "indices" : [ 3, 10 ],
      "id_str" : "1623730970",
      "id" : 1623730970
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 65, 69 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mexico",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/mJmLfSMxv0",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "756491224589164545",
  "text" : "RT @Gabi44: Friday 11:45amET: @POTUS &amp; President Pe\u00F1a Nieto (@EPN) of #Mexico to hold joint press conf. https:\/\/t.co\/mJmLfSMxv0 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 18, 24 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Enrique Pe\u00F1a Nieto",
        "screen_name" : "EPN",
        "indices" : [ 53, 57 ],
        "id_str" : "2897441",
        "id" : 2897441
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gabi44\/status\/756347471903789056\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/BEWrzHUot1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn8WAtlWgAAemW9.jpg",
        "id_str" : "756347463913603072",
        "id" : 756347463913603072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn8WAtlWgAAemW9.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/BEWrzHUot1"
      } ],
      "hashtags" : [ {
        "text" : "Mexico",
        "indices" : [ 62, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/mJmLfSMxv0",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "756347471903789056",
    "text" : "Friday 11:45amET: @POTUS &amp; President Pe\u00F1a Nieto (@EPN) of #Mexico to hold joint press conf. https:\/\/t.co\/mJmLfSMxv0 https:\/\/t.co\/BEWrzHUot1",
    "id" : 756347471903789056,
    "created_at" : "2016-07-22 04:37:44 +0000",
    "user" : {
      "name" : "Gabi Chojkier",
      "screen_name" : "Gabi44",
      "protected" : false,
      "id_str" : "1623730970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707606391322648578\/3gdwtL3O_normal.jpg",
      "id" : 1623730970,
      "verified" : true
    }
  },
  "id" : 756491224589164545,
  "created_at" : "2016-07-22 14:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 73, 78 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 83, 95 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeatTheHeat",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756484869325139969",
  "text" : "RT @whitehouseostp: Stay safe as summer heat settles in! Send your Qs to @VJ44 and @CraigAtFEMA by 10am ET today using #BeatTheHeat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 53, 58 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "Craig Fugate",
        "screen_name" : "CraigatFEMA",
        "indices" : [ 63, 75 ],
        "id_str" : "67378554",
        "id" : 67378554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeatTheHeat",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756478828013248516",
    "text" : "Stay safe as summer heat settles in! Send your Qs to @VJ44 and @CraigAtFEMA by 10am ET today using #BeatTheHeat",
    "id" : 756478828013248516,
    "created_at" : "2016-07-22 13:19:41 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 756484869325139969,
  "created_at" : "2016-07-22 13:43:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 102, 114 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/747XDm3OWm",
      "expanded_url" : "http:\/\/go.wh.gov\/VGQZAd",
      "display_url" : "go.wh.gov\/VGQZAd"
    } ]
  },
  "geo" : { },
  "id_str" : "756326805234077696",
  "text" : "RT @vj44: .@POTUS on why it's important to stay safe in the heat: https:\/\/t.co\/747XDm3OWm\nGot Qs? Ask @CraigAtFEMA &amp; me by 10am ET with #Be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Craig Fugate",
        "screen_name" : "CraigatFEMA",
        "indices" : [ 92, 104 ],
        "id_str" : "67378554",
        "id" : 67378554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeatTheHeat",
        "indices" : [ 130, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/747XDm3OWm",
        "expanded_url" : "http:\/\/go.wh.gov\/VGQZAd",
        "display_url" : "go.wh.gov\/VGQZAd"
      } ]
    },
    "geo" : { },
    "id_str" : "756308645491662848",
    "text" : ".@POTUS on why it's important to stay safe in the heat: https:\/\/t.co\/747XDm3OWm\nGot Qs? Ask @CraigAtFEMA &amp; me by 10am ET with #BeatTheHeat.",
    "id" : 756308645491662848,
    "created_at" : "2016-07-22 02:03:27 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 756326805234077696,
  "created_at" : "2016-07-22 03:15:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 15, 20 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 27, 39 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beattheheat",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756308004463480833",
  "text" : "RT @fema: Join @vj44 &amp; @CraigatFEMA for a chat on extreme heat, 7\/22 @ 10am ET. Ask your questions using #beattheheat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 5, 10 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "Craig Fugate",
        "screen_name" : "CraigatFEMA",
        "indices" : [ 17, 29 ],
        "id_str" : "67378554",
        "id" : 67378554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "beattheheat",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756307227288494081",
    "text" : "Join @vj44 &amp; @CraigatFEMA for a chat on extreme heat, 7\/22 @ 10am ET. Ask your questions using #beattheheat.",
    "id" : 756307227288494081,
    "created_at" : "2016-07-22 01:57:49 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 756308004463480833,
  "created_at" : "2016-07-22 02:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/756283335186395137\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5L01ye2lnR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn7bqF3WIAEQsXb.jpg",
      "id_str" : "756283303620124673",
      "id" : 756283303620124673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn7bqF3WIAEQsXb.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/5L01ye2lnR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756283335186395137",
  "text" : "\u201CYou\u2019re a valued part of the American family\u201D \u2014@POTUS to Muslim Americans at today's Eid al-Fitr reception: https:\/\/t.co\/5L01ye2lnR",
  "id" : 756283335186395137,
  "created_at" : "2016-07-22 00:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/lrAUtnND7j",
      "expanded_url" : "http:\/\/snpy.tv\/2acfooN",
      "display_url" : "snpy.tv\/2acfooN"
    } ]
  },
  "geo" : { },
  "id_str" : "756275097539751936",
  "text" : "\"Discriminating against Muslim Americans is also an affront to the very values that already make our nation great.\" https:\/\/t.co\/lrAUtnND7j",
  "id" : 756275097539751936,
  "created_at" : "2016-07-21 23:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AL4QnnMUWy",
      "expanded_url" : "http:\/\/snpy.tv\/29RUIzO",
      "display_url" : "snpy.tv\/29RUIzO"
    } ]
  },
  "geo" : { },
  "id_str" : "756270172948705280",
  "text" : "\"Muslim Americans are as patriotic, as integrated, as American as any other members of the American family.\" \u2014@POTUS https:\/\/t.co\/AL4QnnMUWy",
  "id" : 756270172948705280,
  "created_at" : "2016-07-21 23:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/BxWmJhOtsS",
      "expanded_url" : "http:\/\/snpy.tv\/2a3TiWu",
      "display_url" : "snpy.tv\/2a3TiWu"
    } ]
  },
  "geo" : { },
  "id_str" : "756265916833394689",
  "text" : "15-year-old Aisha wrote to @POTUS to make her voice heard. Watch her tell her story at the Eid al-Fitr reception: https:\/\/t.co\/BxWmJhOtsS",
  "id" : 756265916833394689,
  "created_at" : "2016-07-21 23:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/lrAUto5evT",
      "expanded_url" : "http:\/\/snpy.tv\/2acfooN",
      "display_url" : "snpy.tv\/2acfooN"
    } ]
  },
  "geo" : { },
  "id_str" : "756262209790087168",
  "text" : "\"You\u2019re a valued part of the American family &amp; there\u2019s nothing that you cannot do\" \u2014@POTUS to young Muslim Americans https:\/\/t.co\/lrAUto5evT",
  "id" : 756262209790087168,
  "created_at" : "2016-07-21 22:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lrAUto5evT",
      "expanded_url" : "http:\/\/snpy.tv\/2acfooN",
      "display_url" : "snpy.tv\/2acfooN"
    } ]
  },
  "geo" : { },
  "id_str" : "756260325108908036",
  "text" : "\"We need to be clear about what we stand for. Muslim Americans\u2014and all Americans\u2014have to reject hatred.\" \u2014@POTUS https:\/\/t.co\/lrAUto5evT",
  "id" : 756260325108908036,
  "created_at" : "2016-07-21 22:51:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/FWBtjOkABe",
      "expanded_url" : "http:\/\/go.wh.gov\/yaGf2u",
      "display_url" : "go.wh.gov\/yaGf2u"
    } ]
  },
  "geo" : { },
  "id_str" : "756243650414161920",
  "text" : "Muslim Americans of all backgrounds\u2014Arab and Asian, African and Latino, Black and White\u2014have helped build America. https:\/\/t.co\/FWBtjOkABe",
  "id" : 756243650414161920,
  "created_at" : "2016-07-21 21:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O57LklOozr",
      "expanded_url" : "http:\/\/snpy.tv\/2acfFrV",
      "display_url" : "snpy.tv\/2acfFrV"
    } ]
  },
  "geo" : { },
  "id_str" : "756240361731792897",
  "text" : "\"We recommit ourselves to building an America where everybody has the opportunity to achieve their dreams.\" \u2014@POTUS  https:\/\/t.co\/O57LklOozr",
  "id" : 756240361731792897,
  "created_at" : "2016-07-21 21:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/UvQhVfxD61",
      "expanded_url" : "http:\/\/snpy.tv\/2ace4Cp",
      "display_url" : "snpy.tv\/2ace4Cp"
    } ]
  },
  "geo" : { },
  "id_str" : "756238030814507011",
  "text" : "\"The Champ taught us that the most important thing in life is to be ourselves.\" \u2014@POTUS on Muhammad Ali https:\/\/t.co\/UvQhVfxD61",
  "id" : 756238030814507011,
  "created_at" : "2016-07-21 21:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756235491884826624",
  "text" : "\"No matter who you are, what you look like, where you\u2019re from or how you worship, if you work hard, you can make it here in America\" \u2014@POTUS",
  "id" : 756235491884826624,
  "created_at" : "2016-07-21 21:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 3, 14 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756235097733468160",
  "text" : "RT @WhiteHouse: \"We rededicate ourselves to making sure that no American feels isolated or second-class citizens.\" \u2014@POTUS speaking to Musl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 100, 106 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756235031257972737",
    "text" : "\"We rededicate ourselves to making sure that no American feels isolated or second-class citizens.\" \u2014@POTUS speaking to Muslim Americans",
    "id" : 756235031257972737,
    "created_at" : "2016-07-21 21:10:56 +0000",
    "user" : {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "protected" : false,
      "id_str" : "30313925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
      "id" : 30313925,
      "verified" : true
    }
  },
  "id" : 756235097733468160,
  "created_at" : "2016-07-21 21:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756235031257972737",
  "text" : "\"We rededicate ourselves to making sure that no American feels isolated or second-class citizens.\" \u2014@POTUS speaking to Muslim Americans",
  "id" : 756235031257972737,
  "created_at" : "2016-07-21 21:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756233914365145088",
  "text" : "\u201CLet\u2019s be clear\u2014Muslim Americans are as patriotic, as integrated, as American as any other member of our American family.\u201D \u2014@POTUS",
  "id" : 756233914365145088,
  "created_at" : "2016-07-21 21:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/PaOVnwLsKX",
      "expanded_url" : "http:\/\/go.wh.gov\/qQM7v7",
      "display_url" : "go.wh.gov\/qQM7v7"
    } ]
  },
  "geo" : { },
  "id_str" : "756233305150910469",
  "text" : "\u201CToday is also another reminder that Muslims have always been part of America.\u201D \u2014@POTUS marking Eid al-Fitr: https:\/\/t.co\/PaOVnwLsKX",
  "id" : 756233305150910469,
  "created_at" : "2016-07-21 21:04:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756233085822402561",
  "text" : "RT @WHLive: \u201CFor Muslims across the United States and around the world, this is a time of spiritual renewal\u201D \u2014@POTUS marking Eid al-Fitr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 98, 104 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756233019334078464",
    "text" : "\u201CFor Muslims across the United States and around the world, this is a time of spiritual renewal\u201D \u2014@POTUS marking Eid al-Fitr",
    "id" : 756233019334078464,
    "created_at" : "2016-07-21 21:02:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 756233085822402561,
  "created_at" : "2016-07-21 21:03:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756232902900232192",
  "text" : "\u201CWe\u2019re very proud to be joined by so many patriotic Muslim Americans from across our country and all walks of life\u201D \u2014@POTUS marking Eid",
  "id" : 756232902900232192,
  "created_at" : "2016-07-21 21:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/PaOVnwtRmn",
      "expanded_url" : "http:\/\/go.wh.gov\/qQM7v7",
      "display_url" : "go.wh.gov\/qQM7v7"
    } ]
  },
  "geo" : { },
  "id_str" : "756230538013265921",
  "text" : "\u201CEid Mubarak!\u201D Watch as @POTUS delivers remarks at the Eid al-Fitr reception \u2192 https:\/\/t.co\/PaOVnwtRmn",
  "id" : 756230538013265921,
  "created_at" : "2016-07-21 20:53:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 43, 46 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 85, 92 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbt",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756212303083692032",
  "text" : "RT @VPLive: \"That could beat my Corvette!\" @VP observes flight operations aboard the @USNavy USS John C. Stennis last week. #tbt\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 31, 34 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 73, 80 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tbt",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/y714Ae1Lqm",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/a6087af4-8017-44cc-a931-ee83eadb0c5e",
        "display_url" : "amp.twimg.com\/v\/a6087af4-801\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756204810404110337",
    "text" : "\"That could beat my Corvette!\" @VP observes flight operations aboard the @USNavy USS John C. Stennis last week. #tbt\nhttps:\/\/t.co\/y714Ae1Lqm",
    "id" : 756204810404110337,
    "created_at" : "2016-07-21 19:10:51 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 756212303083692032,
  "created_at" : "2016-07-21 19:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Salvador Perez",
      "screen_name" : "SalvadorPerez15",
      "indices" : [ 57, 73 ],
      "id_str" : "351127535",
      "id" : 351127535
    }, {
      "name" : "Eric Hosmer",
      "screen_name" : "TheRealHos35",
      "indices" : [ 75, 88 ],
      "id_str" : "1315298502",
      "id" : 1315298502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ForeverRoyal",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756186064906285056",
  "text" : "RT @PressSec: Quite a thrill (&amp; surprise) to welcome @SalvadorPerez15, @TheRealHos35 &amp; Ned Yost to today's briefing! #ForeverRoyal\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salvador Perez",
        "screen_name" : "SalvadorPerez15",
        "indices" : [ 43, 59 ],
        "id_str" : "351127535",
        "id" : 351127535
      }, {
        "name" : "Eric Hosmer",
        "screen_name" : "TheRealHos35",
        "indices" : [ 61, 74 ],
        "id_str" : "1315298502",
        "id" : 1315298502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ForeverRoyal",
        "indices" : [ 111, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/lfpIwK4T6Z",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/a6937933-2b53-4d7d-b158-fb1f40fa912c",
        "display_url" : "amp.twimg.com\/v\/a6937933-2b5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756185382568407040",
    "text" : "Quite a thrill (&amp; surprise) to welcome @SalvadorPerez15, @TheRealHos35 &amp; Ned Yost to today's briefing! #ForeverRoyal\nhttps:\/\/t.co\/lfpIwK4T6Z",
    "id" : 756185382568407040,
    "created_at" : "2016-07-21 17:53:39 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 756186064906285056,
  "created_at" : "2016-07-21 17:56:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Kansas City Royals",
      "screen_name" : "Royals",
      "indices" : [ 59, 66 ],
      "id_str" : "28603812",
      "id" : 28603812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/KR4qz0lSt4",
      "expanded_url" : "http:\/\/snpy.tv\/29OCqUU",
      "display_url" : "snpy.tv\/29OCqUU"
    } ]
  },
  "geo" : { },
  "id_str" : "756184208129884160",
  "text" : "Watch @POTUS welcome the World Series Champion Kansas City @Royals to the White House. https:\/\/t.co\/KR4qz0lSt4",
  "id" : 756184208129884160,
  "created_at" : "2016-07-21 17:48:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Royals",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756160454632808448",
  "text" : "\u201CIn all, they had eight comeback wins in the playoffs which is a Major League record\u201D \u2014@POTUS honoring the Kansas City #Royals",
  "id" : 756160454632808448,
  "created_at" : "2016-07-21 16:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ForeverRoyal",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756158820007702528",
  "text" : "\u201CLet\u2019s give it up for the World Series Champions, the Kansas City Royals!\u201D \u2014@POTUS #ForeverRoyal",
  "id" : 756158820007702528,
  "created_at" : "2016-07-21 16:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Kansas City Royals",
      "screen_name" : "Royals",
      "indices" : [ 66, 73 ],
      "id_str" : "28603812",
      "id" : 28603812
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/756157810795225089\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/IzlrdY5SZo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn5nQmrWIAAGdK6.jpg",
      "id_str" : "756155322402742272",
      "id" : 756155322402742272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn5nQmrWIAAGdK6.jpg",
      "sizes" : [ {
        "h" : 876,
        "resize" : "fit",
        "w" : 1199
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 876,
        "resize" : "fit",
        "w" : 1199
      }, {
        "h" : 876,
        "resize" : "fit",
        "w" : 1199
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/IzlrdY5SZo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/HopKdMfbnK",
      "expanded_url" : "http:\/\/go.wh.gov\/thxVdA",
      "display_url" : "go.wh.gov\/thxVdA"
    } ]
  },
  "geo" : { },
  "id_str" : "756157810795225089",
  "text" : "Watch live as @POTUS honors the World Series Champion Kansas City @Royals: https:\/\/t.co\/HopKdMfbnK https:\/\/t.co\/IzlrdY5SZo",
  "id" : 756157810795225089,
  "created_at" : "2016-07-21 16:04:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kansas City Royals",
      "screen_name" : "Royals",
      "indices" : [ 3, 10 ],
      "id_str" : "28603812",
      "id" : 28603812
    }, {
      "name" : "Salvador Perez",
      "screen_name" : "SalvadorPerez15",
      "indices" : [ 13, 29 ],
      "id_str" : "351127535",
      "id" : 351127535
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 49, 60 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756150435287670784",
  "text" : "RT @Royals: .@SalvadorPerez15 has taken over the @WhiteHouse Snapchat account! Follow along to go behind the scenes with him. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salvador Perez",
        "screen_name" : "SalvadorPerez15",
        "indices" : [ 1, 17 ],
        "id_str" : "351127535",
        "id" : 351127535
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 37, 48 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Royals\/status\/756146660514926593\/video\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/25zxjlfRQd",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/756146619125465088\/pu\/img\/X03EMHJDURfgVWqR.jpg",
        "id_str" : "756146619125465088",
        "id" : 756146619125465088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/756146619125465088\/pu\/img\/X03EMHJDURfgVWqR.jpg",
        "sizes" : [ {
          "h" : 568,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/25zxjlfRQd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756146660514926593",
    "text" : ".@SalvadorPerez15 has taken over the @WhiteHouse Snapchat account! Follow along to go behind the scenes with him. https:\/\/t.co\/25zxjlfRQd",
    "id" : 756146660514926593,
    "created_at" : "2016-07-21 15:19:47 +0000",
    "user" : {
      "name" : "Kansas City Royals",
      "screen_name" : "Royals",
      "protected" : false,
      "id_str" : "28603812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789471916918583296\/Q-cBOK1A_normal.jpg",
      "id" : 28603812,
      "verified" : true
    }
  },
  "id" : 756150435287670784,
  "created_at" : "2016-07-21 15:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755936597770502144\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/1Rib6JxZT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn2b7BqUEAAW436.jpg",
      "id_str" : "755931750828609536",
      "id" : 755931750828609536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn2b7BqUEAAW436.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 845
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 845
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 845
      } ],
      "display_url" : "pic.twitter.com\/1Rib6JxZT8"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755936597770502144",
  "text" : "Today, @POTUS spoke with Florida Governor Rick Scott to discuss the #Zika virus: https:\/\/t.co\/1Rib6JxZT8",
  "id" : 755936597770502144,
  "created_at" : "2016-07-21 01:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755930514683342848\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/64jUx4y2e0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn2X1x5XgAArRYw.jpg",
      "id_str" : "755927262650925056",
      "id" : 755927262650925056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn2X1x5XgAArRYw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 804
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 804
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 804
      } ],
      "display_url" : "pic.twitter.com\/64jUx4y2e0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755930514683342848",
  "text" : "\"Our country is better off because of Mark\u2019s contributions\" \u2014@POTUS on the passing of Representative Mark Takai: https:\/\/t.co\/64jUx4y2e0",
  "id" : 755930514683342848,
  "created_at" : "2016-07-21 01:00:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/SnVIsYGifT",
      "expanded_url" : "http:\/\/snpy.tv\/2abFbQQ",
      "display_url" : "snpy.tv\/2abFbQQ"
    } ]
  },
  "geo" : { },
  "id_str" : "755907416458354688",
  "text" : "\"The world has achieved incredible advances in development and human dignity\" \u2014@POTUS on #GlobalDevelopment https:\/\/t.co\/SnVIsYGifT",
  "id" : 755907416458354688,
  "created_at" : "2016-07-20 23:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoodSecurity",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/lMafVBiT45",
      "expanded_url" : "http:\/\/snpy.tv\/2a9w7ZZ",
      "display_url" : "snpy.tv\/2a9w7ZZ"
    } ]
  },
  "geo" : { },
  "id_str" : "755902377207721984",
  "text" : "\"No society can flourish while its citizens go hungry.\" \u2014@POTUS on the importance of #FoodSecurity: https:\/\/t.co\/lMafVBiT45",
  "id" : 755902377207721984,
  "created_at" : "2016-07-20 23:09:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoodSecurity",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/sXttETXoZo",
      "expanded_url" : "http:\/\/snpy.tv\/2a9w7ZZ",
      "display_url" : "snpy.tv\/2a9w7ZZ"
    } ]
  },
  "geo" : { },
  "id_str" : "755894924734763008",
  "text" : "RT @NSC44: Today @POTUS signed the Global Food Security Act. Here\u2019s what he said about it: https:\/\/t.co\/sXttETXoZo\n#FoodSecurity #GlobalDev\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FoodSecurity",
        "indices" : [ 104, 117 ]
      }, {
        "text" : "GlobalDevelopment",
        "indices" : [ 118, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/sXttETXoZo",
        "expanded_url" : "http:\/\/snpy.tv\/2a9w7ZZ",
        "display_url" : "snpy.tv\/2a9w7ZZ"
      } ]
    },
    "geo" : { },
    "id_str" : "755894064919130112",
    "text" : "Today @POTUS signed the Global Food Security Act. Here\u2019s what he said about it: https:\/\/t.co\/sXttETXoZo\n#FoodSecurity #GlobalDevelopment",
    "id" : 755894064919130112,
    "created_at" : "2016-07-20 22:36:03 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 755894924734763008,
  "created_at" : "2016-07-20 22:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/cZXk4MDn46",
      "expanded_url" : "http:\/\/snpy.tv\/29MtfEc",
      "display_url" : "snpy.tv\/29MtfEc"
    } ]
  },
  "geo" : { },
  "id_str" : "755888379972157440",
  "text" : "\"Republicans in Congress can help pass that bill that treats #Zika like the serious threat that it is\" \u2014@POTUS https:\/\/t.co\/cZXk4MDn46",
  "id" : 755888379972157440,
  "created_at" : "2016-07-20 22:13:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gayle Smith",
      "screen_name" : "GayleSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "4362952695",
      "id" : 4362952695
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 47, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755868173098950656",
  "text" : "RT @GayleSmith: Thank you @POTUS for elevating #GlobalDevelopment. Your leadership has helped make shared progress possible. https:\/\/t.co\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GayleSmith\/status\/755862634600202240\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/b6WoYzymen",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn1dDu7WAAEtsvC.jpg",
        "id_str" : "755862631186038785",
        "id" : 755862631186038785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn1dDu7WAAEtsvC.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/b6WoYzymen"
      } ],
      "hashtags" : [ {
        "text" : "GlobalDevelopment",
        "indices" : [ 31, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755862634600202240",
    "text" : "Thank you @POTUS for elevating #GlobalDevelopment. Your leadership has helped make shared progress possible. https:\/\/t.co\/b6WoYzymen",
    "id" : 755862634600202240,
    "created_at" : "2016-07-20 20:31:09 +0000",
    "user" : {
      "name" : "Gayle Smith",
      "screen_name" : "GayleSmith",
      "protected" : false,
      "id_str" : "4362952695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723577327335145472\/jahpvNQ8_normal.jpg",
      "id" : 4362952695,
      "verified" : true
    }
  },
  "id" : 755868173098950656,
  "created_at" : "2016-07-20 20:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/V29fUGAsHZ",
      "expanded_url" : "http:\/\/snpy.tv\/2av4fyo",
      "display_url" : "snpy.tv\/2av4fyo"
    } ]
  },
  "geo" : { },
  "id_str" : "755865736602583040",
  "text" : "\"One of the best measures of a nation's success is how it treats its women.\" \u2014@POTUS #LetGirlsLearn https:\/\/t.co\/V29fUGAsHZ",
  "id" : 755865736602583040,
  "created_at" : "2016-07-20 20:43:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/lHAvsVrnOU",
      "expanded_url" : "http:\/\/snpy.tv\/2a9JBX6",
      "display_url" : "snpy.tv\/2a9JBX6"
    } ]
  },
  "geo" : { },
  "id_str" : "755863391084969985",
  "text" : "\"Hard things are hard.\" Here's why @POTUS has a plaque with this phrase on his desk: https:\/\/t.co\/lHAvsVrnOU",
  "id" : 755863391084969985,
  "created_at" : "2016-07-20 20:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/SnVIsYXTEt",
      "expanded_url" : "http:\/\/snpy.tv\/2abFbQQ",
      "display_url" : "snpy.tv\/2abFbQQ"
    } ]
  },
  "geo" : { },
  "id_str" : "755860526832422912",
  "text" : "Iin just the past 25 years, more than one billion people have been lifted out of extreme poverty.\" \u2014@POTUS https:\/\/t.co\/SnVIsYXTEt",
  "id" : 755860526832422912,
  "created_at" : "2016-07-20 20:22:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/KakG4ok2n2",
      "expanded_url" : "http:\/\/snpy.tv\/2abGD5H",
      "display_url" : "snpy.tv\/2abGD5H"
    } ]
  },
  "geo" : { },
  "id_str" : "755859068103843840",
  "text" : "\"Whoever the next president is\u2014development has to remain a fundamental pillar of American foreign policy\" \u2014@POTUS https:\/\/t.co\/KakG4ok2n2",
  "id" : 755859068103843840,
  "created_at" : "2016-07-20 20:16:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755856319618220033",
  "text" : "\"Whenever the task seems too great, I\u2019m reminded of the people I\u2019ve met these past eight years\u2014the odds they face; the promise they hold.\"",
  "id" : 755856319618220033,
  "created_at" : "2016-07-20 20:06:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755855224661651457",
  "text" : "RT @USAID: The message is simple: #LetGirlsLearn. When women have equal futures, families &amp; communities are stronger. - @POTUS #GlobalDevel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 113, 119 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 23, 37 ]
      }, {
        "text" : "GlobalDevelopment",
        "indices" : [ 120, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755855060958121984",
    "text" : "The message is simple: #LetGirlsLearn. When women have equal futures, families &amp; communities are stronger. - @POTUS #GlobalDevelopment",
    "id" : 755855060958121984,
    "created_at" : "2016-07-20 20:01:04 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 755855224661651457,
  "created_at" : "2016-07-20 20:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755854925582696448",
  "text" : "\"Because when women have equal futures, families and communities and countries are stronger. It\u2019s a fact.\" \u2014@POTUS",
  "id" : 755854925582696448,
  "created_at" : "2016-07-20 20:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755854525617967104\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/lvvLD4xBSu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn1VoNtUEAQSJDR.jpg",
      "id_str" : "755854461830959108",
      "id" : 755854461830959108,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn1VoNtUEAQSJDR.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lvvLD4xBSu"
    } ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755854525617967104",
  "text" : "\"Let\u2019s keep empowering our young people\" \u2014@POTUS #GlobalDevelopment https:\/\/t.co\/lvvLD4xBSu",
  "id" : 755854525617967104,
  "created_at" : "2016-07-20 19:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755854300480282624",
  "text" : "\"Republicans in Congress can help: Pass that bill that treats Zika like the serious threat it is, and fully funding our response.\" \u2014@POTUS",
  "id" : 755854300480282624,
  "created_at" : "2016-07-20 19:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755853992542949377\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/c1rKyI7gqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn1VL8OUsAADas1.jpg",
      "id_str" : "755853976101236736",
      "id" : 755853976101236736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn1VL8OUsAADas1.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c1rKyI7gqE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755853992542949377",
  "text" : "\"Our vision is within reach\u2014the first AIDS-free generation.\" \u2014@POTUS https:\/\/t.co\/c1rKyI7gqE",
  "id" : 755853992542949377,
  "created_at" : "2016-07-20 19:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755853910368104449\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/oBcxBw4wm0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn1VHkZUsAAjqal.jpg",
      "id_str" : "755853900985446400",
      "id" : 755853900985446400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn1VHkZUsAAjqal.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oBcxBw4wm0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755853910368104449",
  "text" : "\"We\u2019ve saved an estimated 6 million lives from malaria since 2000.\" \u2014@POTUS https:\/\/t.co\/oBcxBw4wm0",
  "id" : 755853910368104449,
  "created_at" : "2016-07-20 19:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755853639499915265\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/kZ1dbEsQtu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn1UguZVUAEgTNG.jpg",
      "id_str" : "755853233654943745",
      "id" : 755853233654943745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn1UguZVUAEgTNG.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kZ1dbEsQtu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755853639499915265",
  "text" : "\"Let\u2019s keep strengthening food security &amp; nutrition\" \u2014@POTUS on how no society can flourish while citizens go hungry https:\/\/t.co\/kZ1dbEsQtu",
  "id" : 755853639499915265,
  "created_at" : "2016-07-20 19:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Millennium Challenge",
      "screen_name" : "MCCgov",
      "indices" : [ 3, 10 ],
      "id_str" : "48398586",
      "id" : 48398586
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755853117774663684",
  "text" : "RT @MCCgov: Let's keep unleashing broad-based growth that lifts people out of poverty #GlobalDevelopment @POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 93, 99 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GlobalDevelopment",
        "indices" : [ 74, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755852807274573824",
    "text" : "Let's keep unleashing broad-based growth that lifts people out of poverty #GlobalDevelopment @POTUS",
    "id" : 755852807274573824,
    "created_at" : "2016-07-20 19:52:06 +0000",
    "user" : {
      "name" : "Millennium Challenge",
      "screen_name" : "MCCgov",
      "protected" : false,
      "id_str" : "48398586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656475318354595840\/_IjSvvVX_normal.jpg",
      "id" : 48398586,
      "verified" : true
    }
  },
  "id" : 755853117774663684,
  "created_at" : "2016-07-20 19:53:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 23, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755852677234339840",
  "text" : "RT @USAID: \"We measure #GlobalDevelopment not just by the dollars we invest but whether people and nations are better off.\" - @POTUS #Globa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 115, 121 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GlobalDevelopment",
        "indices" : [ 12, 30 ]
      }, {
        "text" : "GlobalDevelopment",
        "indices" : [ 122, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755851848771174401",
    "text" : "\"We measure #GlobalDevelopment not just by the dollars we invest but whether people and nations are better off.\" - @POTUS #GlobalDevelopment",
    "id" : 755851848771174401,
    "created_at" : "2016-07-20 19:48:18 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 755852677234339840,
  "created_at" : "2016-07-20 19:51:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/755851777862361088\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/pHK8t8gnNH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn1TKfIUkAALLnq.jpg",
      "id_str" : "755851752088309760",
      "id" : 755851752088309760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn1TKfIUkAALLnq.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pHK8t8gnNH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755851777862361088",
  "text" : "\"We\u2019re building local capacity\u2014because local partners have to be in the lead.\" \u2014@POTUS on fighting poverty https:\/\/t.co\/pHK8t8gnNH",
  "id" : 755851777862361088,
  "created_at" : "2016-07-20 19:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755850595844562944",
  "text" : "\"No one should be denied opportunity because of where they\u2019re born... gender... religion... color of their skin... who they love\" \u2014@POTUS",
  "id" : 755850595844562944,
  "created_at" : "2016-07-20 19:43:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755850504303812609",
  "text" : "\"We reaffirm our belief that in the 21st century, no child should go to bed hungry.\" \u2014@POTUS",
  "id" : 755850504303812609,
  "created_at" : "2016-07-20 19:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 23, 29 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755850366688698369",
  "text" : "\"My mother worked with @USAID and the Ford Foundation, traveling Indonesia and Pakistan to help lift up the rural poor.\" \u2014@POTUS",
  "id" : 755850366688698369,
  "created_at" : "2016-07-20 19:42:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755849880245903360",
  "text" : "\"In just the past 25 years, more than one billion people have been lifted out of extreme poverty. One billion.\"  \u2014@POTUS #GlobalDevelopment",
  "id" : 755849880245903360,
  "created_at" : "2016-07-20 19:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/f2k6igguOr",
      "expanded_url" : "http:\/\/wh.gov\/GlobalDevelopment",
      "display_url" : "wh.gov\/GlobalDevelopm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755848574370394112",
  "text" : "Happening now: @POTUS talks about the steps we\u2019re taking to advance #GlobalDevelopment: https:\/\/t.co\/f2k6igguOr",
  "id" : 755848574370394112,
  "created_at" : "2016-07-20 19:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/f2k6igguOr",
      "expanded_url" : "http:\/\/wh.gov\/GlobalDevelopment",
      "display_url" : "wh.gov\/GlobalDevelopm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755835774587633664",
  "text" : "Food security is vital to addressing global hunger. Here's how we've made progress: https:\/\/t.co\/f2k6igguOr",
  "id" : 755835774587633664,
  "created_at" : "2016-07-20 18:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 42, 51 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "Expedia",
      "screen_name" : "Expedia",
      "indices" : [ 75, 83 ],
      "id_str" : "17365848",
      "id" : 17365848
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755818990837039105\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/uHKhQzngAR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn01BsfWgAARqnu.jpg",
      "id_str" : "755818615706910720",
      "id" : 755818615706910720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn01BsfWgAARqnu.jpg",
      "sizes" : [ {
        "h" : 1575,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1575,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/uHKhQzngAR"
    } ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VP3HOugUZv",
      "expanded_url" : "https:\/\/viewfinder.expedia.com\/features\/year-later-changing-course-cuba\/",
      "display_url" : "viewfinder.expedia.com\/features\/year-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755818990837039105",
  "text" : "One year ago, we changed course in #Cuba. @Rhodes44 shares our progress on @Expedia: https:\/\/t.co\/VP3HOugUZv https:\/\/t.co\/uHKhQzngAR",
  "id" : 755818990837039105,
  "created_at" : "2016-07-20 17:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Expedia",
      "screen_name" : "Expedia",
      "indices" : [ 3, 11 ],
      "id_str" : "17365848",
      "id" : 17365848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 105, 114 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/GHcpQbpBqe",
      "expanded_url" : "http:\/\/bit.ly\/2agPKSB",
      "display_url" : "bit.ly\/2agPKSB"
    } ]
  },
  "geo" : { },
  "id_str" : "755812247750971393",
  "text" : "RT @Expedia: .@POTUS changing course with Cuba and what it means for travel: https:\/\/t.co\/GHcpQbpBqe via @Rhodes44 @WhiteHouse https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 92, 101 ],
        "id_str" : "249722522",
        "id" : 249722522
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 102, 113 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Expedia\/status\/755810771850977281\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/6AqboN49sY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0t431XgAAWm2-.jpg",
        "id_str" : "755810767551823872",
        "id" : 755810767551823872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0t431XgAAWm2-.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/6AqboN49sY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/GHcpQbpBqe",
        "expanded_url" : "http:\/\/bit.ly\/2agPKSB",
        "display_url" : "bit.ly\/2agPKSB"
      } ]
    },
    "geo" : { },
    "id_str" : "755810771850977281",
    "text" : ".@POTUS changing course with Cuba and what it means for travel: https:\/\/t.co\/GHcpQbpBqe via @Rhodes44 @WhiteHouse https:\/\/t.co\/6AqboN49sY",
    "id" : 755810771850977281,
    "created_at" : "2016-07-20 17:05:04 +0000",
    "user" : {
      "name" : "Expedia",
      "screen_name" : "Expedia",
      "protected" : false,
      "id_str" : "17365848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751465002071056384\/1Y7byTNG_normal.jpg",
      "id" : 17365848,
      "verified" : true
    }
  },
  "id" : 755812247750971393,
  "created_at" : "2016-07-20 17:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755808216001294336\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/u9h6cMWpzn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0rLwhWAAA3iTa.jpg",
      "id_str" : "755807793471422464",
      "id" : 755807793471422464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0rLwhWAAA3iTa.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/u9h6cMWpzn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755803507760902144",
  "geo" : { },
  "id_str" : "755808216001294336",
  "in_reply_to_user_id" : 1536791610,
  "text" : "Yesterday, @POTUS was briefed on extreme heat by his science advisor, Dr. John Holdren. https:\/\/t.co\/u9h6cMWpzn",
  "id" : 755808216001294336,
  "in_reply_to_status_id" : 755803507760902144,
  "created_at" : "2016-07-20 16:54:55 +0000",
  "in_reply_to_screen_name" : "POTUS",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755803647661879299",
  "text" : "RT @POTUS: This map says it all. Stay safe as it heats up: Drink water, stay out of the sun, and check on your neighbors. https:\/\/t.co\/c1qF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/755803507760902144\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/c1qFTmq2IV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0nElrUAAAtuKm.jpg",
        "id_str" : "755803272254849024",
        "id" : 755803272254849024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0nElrUAAAtuKm.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/c1qFTmq2IV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755803507760902144",
    "text" : "This map says it all. Stay safe as it heats up: Drink water, stay out of the sun, and check on your neighbors. https:\/\/t.co\/c1qFTmq2IV",
    "id" : 755803507760902144,
    "created_at" : "2016-07-20 16:36:13 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 755803647661879299,
  "created_at" : "2016-07-20 16:36:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalDevelopment",
      "indices" : [ 54, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/f2k6igguOr",
      "expanded_url" : "http:\/\/wh.gov\/GlobalDevelopment",
      "display_url" : "wh.gov\/GlobalDevelopm\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/oYLQA2RYCp",
      "expanded_url" : "http:\/\/snpy.tv\/2agkDGv",
      "display_url" : "snpy.tv\/2agkDGv"
    } ]
  },
  "geo" : { },
  "id_str" : "755800728212348928",
  "text" : "Together we can end poverty. Watch @POTUS speak about #GlobalDevelopment today at 3:35pm ET: https:\/\/t.co\/f2k6igguOr https:\/\/t.co\/oYLQA2RYCp",
  "id" : 755800728212348928,
  "created_at" : "2016-07-20 16:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755794926302920704\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/58Bl43PnAt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn0c27qWIAA9DCM.jpg",
      "id_str" : "755792042521927680",
      "id" : 755792042521927680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn0c27qWIAA9DCM.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/58Bl43PnAt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/f2k6igguOr",
      "expanded_url" : "http:\/\/wh.gov\/GlobalDevelopment",
      "display_url" : "wh.gov\/GlobalDevelopm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755794926302920704",
  "text" : "Young people can change the world\u2014and under @POTUS, we\u2019re investing in their success. https:\/\/t.co\/f2k6igguOr https:\/\/t.co\/58Bl43PnAt",
  "id" : 755794926302920704,
  "created_at" : "2016-07-20 16:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/f2k6igguOr",
      "expanded_url" : "http:\/\/wh.gov\/GlobalDevelopment",
      "display_url" : "wh.gov\/GlobalDevelopm\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/oYLQA2RYCp",
      "expanded_url" : "http:\/\/snpy.tv\/2agkDGv",
      "display_url" : "snpy.tv\/2agkDGv"
    } ]
  },
  "geo" : { },
  "id_str" : "755789483090382848",
  "text" : "\u201CProgress in the most impoverished parts of our world enriches us all.\u201D \u2014@POTUS: https:\/\/t.co\/f2k6igguOr https:\/\/t.co\/oYLQA2RYCp",
  "id" : 755789483090382848,
  "created_at" : "2016-07-20 15:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/7DRVmcrFTW",
      "expanded_url" : "http:\/\/go.wh.gov\/GD5m9D",
      "display_url" : "go.wh.gov\/GD5m9D"
    } ]
  },
  "geo" : { },
  "id_str" : "755555350791622656",
  "text" : "\"You confront danger so it does not find our families\u2026we depend on you.\" \u2014@POTUS in a letter to law enforcement: https:\/\/t.co\/7DRVmcrFTW",
  "id" : 755555350791622656,
  "created_at" : "2016-07-20 00:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZLrUMsmHmS",
      "expanded_url" : "http:\/\/snpy.tv\/2a7bu0A",
      "display_url" : "snpy.tv\/2a7bu0A"
    } ]
  },
  "geo" : { },
  "id_str" : "755551562915799041",
  "text" : ".@POTUS: \"There is no contradiction between us protecting our officers... and building trust\" in our communities: https:\/\/t.co\/ZLrUMsmHmS",
  "id" : 755551562915799041,
  "created_at" : "2016-07-19 23:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/3FqAHqrkI8",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/147656962333\/over-the-past-twenty-years-student-debt-has-risen",
      "display_url" : "whitehouse.tumblr.com\/post\/147656962\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755542356057788416",
  "text" : "RT @CEAChair: Answering questions tomorrow on CEA's new student debt report! Ask here: https:\/\/t.co\/3FqAHqrkI8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/3FqAHqrkI8",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/147656962333\/over-the-past-twenty-years-student-debt-has-risen",
        "display_url" : "whitehouse.tumblr.com\/post\/147656962\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "755372828245889024",
    "geo" : { },
    "id_str" : "755540209262030848",
    "in_reply_to_user_id" : 1861751828,
    "text" : "Answering questions tomorrow on CEA's new student debt report! Ask here: https:\/\/t.co\/3FqAHqrkI8",
    "id" : 755540209262030848,
    "in_reply_to_status_id" : 755372828245889024,
    "created_at" : "2016-07-19 23:09:57 +0000",
    "in_reply_to_screen_name" : "CEAChair",
    "in_reply_to_user_id_str" : "1861751828",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 755542356057788416,
  "created_at" : "2016-07-19 23:18:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 46, 53 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/2fWMMLJyKI",
      "expanded_url" : "http:\/\/snpy.tv\/2a6WfEP",
      "display_url" : "snpy.tv\/2a6WfEP"
    } ]
  },
  "geo" : { },
  "id_str" : "755514400082190337",
  "text" : "Yesterday @POTUS awarded the #MedalOfHonor to @USArmy Lt. Col. Charles Kettles. \nGet a behind-the-scenes look: https:\/\/t.co\/2fWMMLJyKI",
  "id" : 755514400082190337,
  "created_at" : "2016-07-19 21:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Turkey",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/8HCBIJ37v2",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/19\/readout-presidents-call-president-recep-tayyip-erdogan-turkey",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755481663703056384",
  "text" : "RT @NSC44: Today @POTUS spoke w\/ Pres. Erdogan &amp; expressed his support for Turkish democracy: https:\/\/t.co\/8HCBIJ37v2\n#Turkey https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/755480495954104325\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/QWc82Pw0HG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnwBQ_vUIAAhemB.jpg",
        "id_str" : "755480228990820352",
        "id" : 755480228990820352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnwBQ_vUIAAhemB.jpg",
        "sizes" : [ {
          "h" : 296,
          "resize" : "fit",
          "w" : 776
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 776
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 776
        } ],
        "display_url" : "pic.twitter.com\/QWc82Pw0HG"
      } ],
      "hashtags" : [ {
        "text" : "Turkey",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/8HCBIJ37v2",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/19\/readout-presidents-call-president-recep-tayyip-erdogan-turkey",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755480495954104325",
    "text" : "Today @POTUS spoke w\/ Pres. Erdogan &amp; expressed his support for Turkish democracy: https:\/\/t.co\/8HCBIJ37v2\n#Turkey https:\/\/t.co\/QWc82Pw0HG",
    "id" : 755480495954104325,
    "created_at" : "2016-07-19 19:12:41 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 755481663703056384,
  "created_at" : "2016-07-19 19:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/bJ3kw6vowy",
      "expanded_url" : "http:\/\/go.wh.gov\/N49RyD",
      "display_url" : "go.wh.gov\/N49RyD"
    } ]
  },
  "geo" : { },
  "id_str" : "755478194703044609",
  "text" : "Ida Rhyne made the switch to solar. \nSee how we're making it easier for everyone to choose cleaner energy: https:\/\/t.co\/bJ3kw6vowy",
  "id" : 755478194703044609,
  "created_at" : "2016-07-19 19:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755469273267658752\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/DjKKpHJGoc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnv2-OMUMAA1e5C.jpg",
      "id_str" : "755468911336763392",
      "id" : 755468911336763392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnv2-OMUMAA1e5C.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DjKKpHJGoc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jt9fhSq6Lk",
      "expanded_url" : "http:\/\/go.wh.gov\/GoSolar",
      "display_url" : "go.wh.gov\/GoSolar"
    } ]
  },
  "geo" : { },
  "id_str" : "755469273267658752",
  "text" : "\"The solar industry is adding jobs 12 times faster than the rest of the economy.\" \u2014@POTUS: https:\/\/t.co\/jt9fhSq6Lk https:\/\/t.co\/DjKKpHJGoc",
  "id" : 755469273267658752,
  "created_at" : "2016-07-19 18:28:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755458477498044417\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/p1F3hT6DvS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvqEshWIAUIo4W.jpg",
      "id_str" : "755454728906088453",
      "id" : 755454728906088453,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvqEshWIAUIo4W.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/p1F3hT6DvS"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755458477498044417",
  "text" : "FACT: Since @POTUS took office more than 50,000 workers have been trained to enter the solar industry #ActOnClimate https:\/\/t.co\/p1F3hT6DvS",
  "id" : 755458477498044417,
  "created_at" : "2016-07-19 17:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/lR7ZR31DuU",
      "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/755440985354543104",
      "display_url" : "twitter.com\/ENERGY\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755454889304752133",
  "text" : "RT @ErnestMoniz: This is a big deal. #CleanEnergy should be available to all Americans. https:\/\/t.co\/lR7ZR31DuU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 20, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/lR7ZR31DuU",
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/755440985354543104",
        "display_url" : "twitter.com\/ENERGY\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755451246933188609",
    "text" : "This is a big deal. #CleanEnergy should be available to all Americans. https:\/\/t.co\/lR7ZR31DuU",
    "id" : 755451246933188609,
    "created_at" : "2016-07-19 17:16:27 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 755454889304752133,
  "created_at" : "2016-07-19 17:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jt9fhSq6Lk",
      "expanded_url" : "http:\/\/go.wh.gov\/GoSolar",
      "display_url" : "go.wh.gov\/GoSolar"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/bJ3kw6dNF0",
      "expanded_url" : "http:\/\/go.wh.gov\/N49RyD",
      "display_url" : "go.wh.gov\/N49RyD"
    } ]
  },
  "geo" : { },
  "id_str" : "755453749041229824",
  "text" : "\"You can go solar right now. You can save money on your energy bills right away.\" \u2014@POTUS: https:\/\/t.co\/jt9fhSq6Lk https:\/\/t.co\/bJ3kw6dNF0",
  "id" : 755453749041229824,
  "created_at" : "2016-07-19 17:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755446896857145344\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/QQ4ra8kFh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnviQKtW8AAzhNr.jpg",
      "id_str" : "755446129895075840",
      "id" : 755446129895075840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnviQKtW8AAzhNr.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/QQ4ra8kFh8"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755446896857145344",
  "text" : "\"We generate over 30 times more solar power than we did just eight years go.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/QQ4ra8kFh8",
  "id" : 755446896857145344,
  "created_at" : "2016-07-19 16:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/bJ3kw6vowy",
      "expanded_url" : "http:\/\/go.wh.gov\/N49RyD",
      "display_url" : "go.wh.gov\/N49RyD"
    } ]
  },
  "geo" : { },
  "id_str" : "755439940813463553",
  "text" : "Big news: We're making it easier for American homeowners to choose cleaner sources of energy. #ActOnClimate https:\/\/t.co\/bJ3kw6vowy",
  "id" : 755439940813463553,
  "created_at" : "2016-07-19 16:31:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755429426741948416\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/r2ZPRLXSjZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvS3BKUsAAGng_.jpg",
      "id_str" : "755429205161062400",
      "id" : 755429205161062400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvS3BKUsAAGng_.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/r2ZPRLXSjZ"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755429426741948416\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/r2ZPRLXSjZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvS3HMVUAEJ0la.jpg",
      "id_str" : "755429206780104705",
      "id" : 755429206780104705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvS3HMVUAEJ0la.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      } ],
      "display_url" : "pic.twitter.com\/r2ZPRLXSjZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/7DRVmcrFTW",
      "expanded_url" : "http:\/\/go.wh.gov\/GD5m9D",
      "display_url" : "go.wh.gov\/GD5m9D"
    } ]
  },
  "geo" : { },
  "id_str" : "755429426741948416",
  "text" : "Read @POTUS's open letter to America's law enforcement community \u2192 https:\/\/t.co\/7DRVmcrFTW https:\/\/t.co\/r2ZPRLXSjZ",
  "id" : 755429426741948416,
  "created_at" : "2016-07-19 15:49:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Tyler Oakley",
      "screen_name" : "tyleroakley",
      "indices" : [ 74, 86 ],
      "id_str" : "14222536",
      "id" : 14222536
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 88, 96 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeatingTheOdds",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755421182002954240",
  "text" : "RT @FLOTUS: Moments away from the First Lady's #BeatingTheOdds panel with @TylerOakley, @USEDGov and more. \uD83C\uDF93 Join us live\uD83D\uDC49 https:\/\/t.co\/WsL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyler Oakley",
        "screen_name" : "tyleroakley",
        "indices" : [ 62, 74 ],
        "id_str" : "14222536",
        "id" : 14222536
      }, {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 76, 84 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeatingTheOdds",
        "indices" : [ 35, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/WsLgLyJheN",
        "expanded_url" : "http:\/\/go.wh.gov\/BTOLive",
        "display_url" : "go.wh.gov\/BTOLive"
      } ]
    },
    "geo" : { },
    "id_str" : "755420065021960192",
    "text" : "Moments away from the First Lady's #BeatingTheOdds panel with @TylerOakley, @USEDGov and more. \uD83C\uDF93 Join us live\uD83D\uDC49 https:\/\/t.co\/WsLgLyJheN",
    "id" : 755420065021960192,
    "created_at" : "2016-07-19 15:12:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 755421182002954240,
  "created_at" : "2016-07-19 15:16:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 3, 8 ],
      "id_str" : "14342564",
      "id" : 14342564
    }, {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "indices" : [ 69, 85 ],
      "id_str" : "916735110",
      "id" : 916735110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfClimate",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/8dpMpSrk1a",
      "expanded_url" : "http:\/\/bit.ly\/2a67X2v",
      "display_url" : "bit.ly\/2a67X2v"
    } ]
  },
  "geo" : { },
  "id_str" : "755420169653157888",
  "text" : "RT @NOAA: JUST IN: Globe record warm for 14th consec month (June) -  @NOAANCEIclimate https:\/\/t.co\/8dpMpSrk1a #StateOfClimate https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOAA NCEI Climate",
        "screen_name" : "NOAANCEIclimate",
        "indices" : [ 59, 75 ],
        "id_str" : "916735110",
        "id" : 916735110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOAA\/status\/755418550140108800\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fEA20RAc4V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvJAygW8AAqRgc.jpg",
        "id_str" : "755418377909366784",
        "id" : 755418377909366784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvJAygW8AAqRgc.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 990
        } ],
        "display_url" : "pic.twitter.com\/fEA20RAc4V"
      } ],
      "hashtags" : [ {
        "text" : "StateOfClimate",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/8dpMpSrk1a",
        "expanded_url" : "http:\/\/bit.ly\/2a67X2v",
        "display_url" : "bit.ly\/2a67X2v"
      } ]
    },
    "geo" : { },
    "id_str" : "755418550140108800",
    "text" : "JUST IN: Globe record warm for 14th consec month (June) -  @NOAANCEIclimate https:\/\/t.co\/8dpMpSrk1a #StateOfClimate https:\/\/t.co\/fEA20RAc4V",
    "id" : 755418550140108800,
    "created_at" : "2016-07-19 15:06:32 +0000",
    "user" : {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "protected" : false,
      "id_str" : "14342564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529277799018676225\/MOsMKe14_normal.jpeg",
      "id" : 14342564,
      "verified" : true
    }
  },
  "id" : 755420169653157888,
  "created_at" : "2016-07-19 15:12:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterMakeRoom",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755418267183742977",
  "text" : "RT @FLOTUS: Passion. Grit. Determination. You can \u2014 and you will \u2014 beat the odds to achieve your dreams. #BetterMakeRoom\nhttps:\/\/t.co\/Nn44i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterMakeRoom",
        "indices" : [ 93, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/Nn44iXtp30",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/a4d2ed81-a3db-4d2e-adef-19a450b19944",
        "display_url" : "amp.twimg.com\/v\/a4d2ed81-a3d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755408768465108993",
    "text" : "Passion. Grit. Determination. You can \u2014 and you will \u2014 beat the odds to achieve your dreams. #BetterMakeRoom\nhttps:\/\/t.co\/Nn44iXtp30",
    "id" : 755408768465108993,
    "created_at" : "2016-07-19 14:27:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 755418267183742977,
  "created_at" : "2016-07-19 15:05:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National FOP",
      "screen_name" : "GLFOP",
      "indices" : [ 3, 9 ],
      "id_str" : "222196210",
      "id" : 222196210
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "National FOP",
      "screen_name" : "GLFOP",
      "indices" : [ 74, 80 ],
      "id_str" : "222196210",
      "id" : 222196210
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GLFOP\/status\/755188650493771776\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/XQu2ykHFNS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnr4EOrXEAACBOc.jpg",
      "id_str" : "755188639081107456",
      "id" : 755188639081107456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnr4EOrXEAACBOc.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      } ],
      "display_url" : "pic.twitter.com\/XQu2ykHFNS"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/GLFOP\/status\/755188650493771776\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/XQu2ykHFNS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnr4ElRWEAAMjsi.jpg",
      "id_str" : "755188645146005504",
      "id" : 755188645146005504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnr4ElRWEAAMjsi.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 742
      } ],
      "display_url" : "pic.twitter.com\/XQu2ykHFNS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755396396921085952",
  "text" : "RT @GLFOP: An open letter to America's Law Enforcement from @POTUS to the @GLFOP https:\/\/t.co\/XQu2ykHFNS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 49, 55 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "National FOP",
        "screen_name" : "GLFOP",
        "indices" : [ 63, 69 ],
        "id_str" : "222196210",
        "id" : 222196210
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GLFOP\/status\/755188650493771776\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/XQu2ykHFNS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnr4EOrXEAACBOc.jpg",
        "id_str" : "755188639081107456",
        "id" : 755188639081107456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnr4EOrXEAACBOc.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        } ],
        "display_url" : "pic.twitter.com\/XQu2ykHFNS"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/GLFOP\/status\/755188650493771776\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/XQu2ykHFNS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnr4ElRWEAAMjsi.jpg",
        "id_str" : "755188645146005504",
        "id" : 755188645146005504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnr4ElRWEAAMjsi.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 742
        } ],
        "display_url" : "pic.twitter.com\/XQu2ykHFNS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755188650493771776",
    "text" : "An open letter to America's Law Enforcement from @POTUS to the @GLFOP https:\/\/t.co\/XQu2ykHFNS",
    "id" : 755188650493771776,
    "created_at" : "2016-07-18 23:52:59 +0000",
    "user" : {
      "name" : "National FOP",
      "screen_name" : "GLFOP",
      "protected" : false,
      "id_str" : "222196210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464858326149259264\/ibLYWtIQ_normal.jpeg",
      "id" : 222196210,
      "verified" : true
    }
  },
  "id" : 755396396921085952,
  "created_at" : "2016-07-19 13:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/k80g4qGRV3",
      "expanded_url" : "http:\/\/huff.to\/2a86o3R",
      "display_url" : "huff.to\/2a86o3R"
    } ]
  },
  "geo" : { },
  "id_str" : "755389588491886592",
  "text" : "RT @SCOTUSnom: Day 125: @POTUS's #SCOTUS nominee has now waited longest time in history for confirmation \u2192 https:\/\/t.co\/k80g4qGRV3 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/755388023395618819\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/m7es3EIfeK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnutAp4VUAIis6b.jpg",
        "id_str" : "755387589268426754",
        "id" : 755387589268426754,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnutAp4VUAIis6b.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/m7es3EIfeK"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/k80g4qGRV3",
        "expanded_url" : "http:\/\/huff.to\/2a86o3R",
        "display_url" : "huff.to\/2a86o3R"
      } ]
    },
    "geo" : { },
    "id_str" : "755388023395618819",
    "text" : "Day 125: @POTUS's #SCOTUS nominee has now waited longest time in history for confirmation \u2192 https:\/\/t.co\/k80g4qGRV3 https:\/\/t.co\/m7es3EIfeK",
    "id" : 755388023395618819,
    "created_at" : "2016-07-19 13:05:13 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 755389588491886592,
  "created_at" : "2016-07-19 13:11:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 35, 44 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755179310705631233",
  "text" : "RT @JFriedman44: New: readout from @PressSec of @POTUS calls today to Baton Rouge law enforcement officials and families https:\/\/t.co\/2oexG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 18, 27 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 31, 37 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JFriedman44\/status\/755172086545469440\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/2oexGBfIkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnropCMUsAAgUzh.jpg",
        "id_str" : "755171679198818304",
        "id" : 755171679198818304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnropCMUsAAgUzh.jpg",
        "sizes" : [ {
          "h" : 229,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/2oexGBfIkM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755172086545469440",
    "text" : "New: readout from @PressSec of @POTUS calls today to Baton Rouge law enforcement officials and families https:\/\/t.co\/2oexGBfIkM",
    "id" : 755172086545469440,
    "created_at" : "2016-07-18 22:47:10 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 755179310705631233,
  "created_at" : "2016-07-18 23:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755160378917711873\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Vn8Y2Gy355",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnreL9kVMAA-f1G.jpg",
      "id_str" : "755160184624852992",
      "id" : 755160184624852992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnreL9kVMAA-f1G.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 531
      } ],
      "display_url" : "pic.twitter.com\/Vn8Y2Gy355"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755160378917711873",
  "text" : ".@POTUS orders U.S. flags flown at half-staff to honor the victims of the attack on law enforcement in Baton Rouge. https:\/\/t.co\/Vn8Y2Gy355",
  "id" : 755160378917711873,
  "created_at" : "2016-07-18 22:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USArmy\/status\/755136072854622208\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UgRq1VDXQf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnrIQJtUIAAWOW8.jpg",
      "id_str" : "755136067347423232",
      "id" : 755136067347423232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnrIQJtUIAAWOW8.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1557,
        "resize" : "fit",
        "w" : 2339
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1363,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/UgRq1VDXQf"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/w0gDxBm5zc",
      "expanded_url" : "http:\/\/go.usa.gov\/xag2z",
      "display_url" : "go.usa.gov\/xag2z"
    } ]
  },
  "geo" : { },
  "id_str" : "755147408707903489",
  "text" : "RT @USArmy: \"Death or injury was all but certain..\" @POTUS tells heroic #MedalOfHonor story https:\/\/t.co\/w0gDxBm5zc https:\/\/t.co\/UgRq1VDXQf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 40, 46 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USArmy\/status\/755136072854622208\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/UgRq1VDXQf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnrIQJtUIAAWOW8.jpg",
        "id_str" : "755136067347423232",
        "id" : 755136067347423232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnrIQJtUIAAWOW8.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1557,
          "resize" : "fit",
          "w" : 2339
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/UgRq1VDXQf"
      } ],
      "hashtags" : [ {
        "text" : "MedalOfHonor",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/w0gDxBm5zc",
        "expanded_url" : "http:\/\/go.usa.gov\/xag2z",
        "display_url" : "go.usa.gov\/xag2z"
      } ]
    },
    "geo" : { },
    "id_str" : "755136072854622208",
    "text" : "\"Death or injury was all but certain..\" @POTUS tells heroic #MedalOfHonor story https:\/\/t.co\/w0gDxBm5zc https:\/\/t.co\/UgRq1VDXQf",
    "id" : 755136072854622208,
    "created_at" : "2016-07-18 20:24:04 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 755147408707903489,
  "created_at" : "2016-07-18 21:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755095904844210177\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vOpRlM4gwf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnqitl8WAAADmYn.jpg",
      "id_str" : "755094791701004288",
      "id" : 755094791701004288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnqitl8WAAADmYn.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/vOpRlM4gwf"
    } ],
    "hashtags" : [ {
      "text" : "MandelaDay",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755095904844210177",
  "text" : "Compassion, understanding, and reconciliation\u2014on #MandelaDay, we are reminded of the promise for a better world. https:\/\/t.co\/vOpRlM4gwf",
  "id" : 755095904844210177,
  "created_at" : "2016-07-18 17:44:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/755082666102366209\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/SOBj7CVcKD",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CnqXRO_XgAA3VWm.jpg",
      "id_str" : "755082209875427328",
      "id" : 755082209875427328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CnqXRO_XgAA3VWm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/SOBj7CVcKD"
    } ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/bBzKRUNNip",
      "expanded_url" : "http:\/\/go.wh.gov\/ZeBLdE",
      "display_url" : "go.wh.gov\/ZeBLdE"
    } ]
  },
  "geo" : { },
  "id_str" : "755082666102366209",
  "text" : "\"Chuck Kettles is America.\" \u2014@POTUS awarding the #MedalofHonor: https:\/\/t.co\/bBzKRUNNip https:\/\/t.co\/SOBj7CVcKD",
  "id" : 755082666102366209,
  "created_at" : "2016-07-18 16:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Debbie Dingell",
      "screen_name" : "RepDebDingell",
      "indices" : [ 3, 17 ],
      "id_str" : "2970279814",
      "id" : 2970279814
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 122, 133 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755067929612447744",
  "text" : "RT @RepDebDingell: What an incredible moment. At long last LTC Charles Kettles awarded the #MedalOfHonor by @POTUS at the @WhiteHouse https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 89, 95 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RepDebDingell\/status\/755066268831670273\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/kfT2uXApzd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnqIB0FW8AAdScT.jpg",
        "id_str" : "755065452280344576",
        "id" : 755065452280344576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnqIB0FW8AAdScT.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/kfT2uXApzd"
      } ],
      "hashtags" : [ {
        "text" : "MedalOfHonor",
        "indices" : [ 72, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755066268831670273",
    "text" : "What an incredible moment. At long last LTC Charles Kettles awarded the #MedalOfHonor by @POTUS at the @WhiteHouse https:\/\/t.co\/kfT2uXApzd",
    "id" : 755066268831670273,
    "created_at" : "2016-07-18 15:46:41 +0000",
    "user" : {
      "name" : "Rep. Debbie Dingell",
      "screen_name" : "RepDebDingell",
      "protected" : false,
      "id_str" : "2970279814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618194716304130048\/NFxM7gqR_normal.png",
      "id" : 2970279814,
      "verified" : true
    }
  },
  "id" : 755067929612447744,
  "created_at" : "2016-07-18 15:53:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 48, 55 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/JPX4A7MX7f",
      "expanded_url" : "http:\/\/snpy.tv\/29PQStY",
      "display_url" : "snpy.tv\/29PQStY"
    } ]
  },
  "geo" : { },
  "id_str" : "755066427976155136",
  "text" : "Watch @POTUS award the #MedalOfHonor to Retired @USArmy Lt. Col. Kettles for his heroism in saving 44 Americans: https:\/\/t.co\/JPX4A7MX7f",
  "id" : 755066427976155136,
  "created_at" : "2016-07-18 15:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755062388152537088",
  "text" : "\"Join me in saluting this proud American soldier and veteran who reminds us all of the true meaning of service\u2014Chuck Kettles.\" #MedalOfHonor",
  "id" : 755062388152537088,
  "created_at" : "2016-07-18 15:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755062091879424000",
  "text" : "RT @WHLive: \"Because of that heroism, 44 American soldiers made it out that day. We are honored today to be joined by some\" https:\/\/t.co\/C4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/755061944168640512\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/C47tUIOBX3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnqE09MW8AAF_YS.jpg",
        "id_str" : "755061932852441088",
        "id" : 755061932852441088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnqE09MW8AAF_YS.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 556,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 1596
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 1596
        } ],
        "display_url" : "pic.twitter.com\/C47tUIOBX3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755061944168640512",
    "text" : "\"Because of that heroism, 44 American soldiers made it out that day. We are honored today to be joined by some\" https:\/\/t.co\/C47tUIOBX3",
    "id" : 755061944168640512,
    "created_at" : "2016-07-18 15:29:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 755062091879424000,
  "created_at" : "2016-07-18 15:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755061997012709377",
  "text" : "\"The belief that no one should be left behind. This shouldn't just a creed for our soldiers\u2014this should be a creed for all of us.\" \u2014@POTUS",
  "id" : 755061997012709377,
  "created_at" : "2016-07-18 15:29:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755060988374818816",
  "text" : "\"A soldier never leaves his comrades behind. Chuck Kettles honored that creed\u2014not with a single act of heroism, but over and over and over.\"",
  "id" : 755060988374818816,
  "created_at" : "2016-07-18 15:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755059514198589441",
  "text" : "\"To the dozens of American soldiers he saved in Vietnam half a century ago, Chuck is the reason they lived and came home.\" #MedalOfHonor",
  "id" : 755059514198589441,
  "created_at" : "2016-07-18 15:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/bBzKRUNNip",
      "expanded_url" : "http:\/\/go.wh.gov\/ZeBLdE",
      "display_url" : "go.wh.gov\/ZeBLdE"
    } ]
  },
  "geo" : { },
  "id_str" : "755058860348542976",
  "text" : "\"Of all the military decorations our nation can bestow, we have none higher than the #MedalOfHonor.\" \u2014@POTUS: https:\/\/t.co\/bBzKRUNNip",
  "id" : 755058860348542976,
  "created_at" : "2016-07-18 15:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 68, 75 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/bBzKRUNNip",
      "expanded_url" : "http:\/\/go.wh.gov\/ZeBLdE",
      "display_url" : "go.wh.gov\/ZeBLdE"
    } ]
  },
  "geo" : { },
  "id_str" : "755055296167510016",
  "text" : "Tune in at 11:20am ET as @POTUS awards the #MedalOfHonor to Retired @USArmy Lt. Colonel Charles Kettles: https:\/\/t.co\/bBzKRUNNip",
  "id" : 755055296167510016,
  "created_at" : "2016-07-18 15:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UymO2AaRHg",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/2cf646b9-e282-483c-87c3-7cdb02ca6895",
      "display_url" : "amp.twimg.com\/v\/2cf646b9-e28\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755043267503280128",
  "text" : "RT @POTUS: 44 men came home because Chuck Kettles believed that we leave no man behind. That's America at our best. https:\/\/t.co\/UymO2AaRHg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/UymO2AaRHg",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/2cf646b9-e282-483c-87c3-7cdb02ca6895",
        "display_url" : "amp.twimg.com\/v\/2cf646b9-e28\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755043199731675137",
    "text" : "44 men came home because Chuck Kettles believed that we leave no man behind. That's America at our best. https:\/\/t.co\/UymO2AaRHg",
    "id" : 755043199731675137,
    "created_at" : "2016-07-18 14:15:01 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 755043267503280128,
  "created_at" : "2016-07-18 14:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 91, 95 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/CFu871CWpi",
      "expanded_url" : "http:\/\/go.wh.gov\/QxrbTD",
      "display_url" : "go.wh.gov\/QxrbTD"
    } ]
  },
  "geo" : { },
  "id_str" : "755038815241195520",
  "text" : "RT @SCOTUSnom: \"Merrick Garland Deserves a Vote\u2014For Democracy\u2019s Sake\" \n\nRead @POTUS in the @WSJ: https:\/\/t.co\/CFu871CWpi https:\/\/t.co\/1XGpU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 62, 68 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 76, 80 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/755038005975330816\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/1XGpUtZVAE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnpvDglUIAAgD-D.jpg",
        "id_str" : "755037993614712832",
        "id" : 755037993614712832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnpvDglUIAAgD-D.jpg",
        "sizes" : [ {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/1XGpUtZVAE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/CFu871CWpi",
        "expanded_url" : "http:\/\/go.wh.gov\/QxrbTD",
        "display_url" : "go.wh.gov\/QxrbTD"
      } ]
    },
    "geo" : { },
    "id_str" : "755038005975330816",
    "text" : "\"Merrick Garland Deserves a Vote\u2014For Democracy\u2019s Sake\" \n\nRead @POTUS in the @WSJ: https:\/\/t.co\/CFu871CWpi https:\/\/t.co\/1XGpUtZVAE",
    "id" : 755038005975330816,
    "created_at" : "2016-07-18 13:54:23 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 755038815241195520,
  "created_at" : "2016-07-18 13:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754844459834216448",
  "text" : "RT @VP: We owe these officers &amp; families more than gratitude. We owe them a commitment as a country to stand together when hate tries to di\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "754842206582804480",
    "geo" : { },
    "id_str" : "754844129746706436",
    "in_reply_to_user_id" : 325830217,
    "text" : "We owe these officers &amp; families more than gratitude. We owe them a commitment as a country to stand together when hate tries to divide us.",
    "id" : 754844129746706436,
    "in_reply_to_status_id" : 754842206582804480,
    "created_at" : "2016-07-18 01:03:59 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 754844459834216448,
  "created_at" : "2016-07-18 01:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754843531789864960",
  "text" : "RT @VP: I join the President in condemning today's despicable, cowardly attack in Baton Rouge. An attack on our very way of life and rule o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754842206582804480",
    "text" : "I join the President in condemning today's despicable, cowardly attack in Baton Rouge. An attack on our very way of life and rule of law.",
    "id" : 754842206582804480,
    "created_at" : "2016-07-18 00:56:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 754843531789864960,
  "created_at" : "2016-07-18 01:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754800876884201472\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/dQhjwPsgQd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnmXMEHUEAAAFDx.jpg",
      "id_str" : "754800646079909888",
      "id" : 754800646079909888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnmXMEHUEAAAFDx.jpg",
      "sizes" : [ {
        "h" : 820,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1913,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1399,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/dQhjwPsgQd"
    } ],
    "hashtags" : [ {
      "text" : "BatonRouge",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rczTFpblUa",
      "expanded_url" : "http:\/\/go.wh.gov\/rd4aWU",
      "display_url" : "go.wh.gov\/rd4aWU"
    } ]
  },
  "geo" : { },
  "id_str" : "754800876884201472",
  "text" : "\"We need to temper our words, and open our hearts\" \u2014@POTUS after the attack in #BatonRouge: https:\/\/t.co\/rczTFpblUa https:\/\/t.co\/dQhjwPsgQd",
  "id" : 754800876884201472,
  "created_at" : "2016-07-17 22:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/5I4OiS3kSi",
      "expanded_url" : "http:\/\/snpy.tv\/2a0GIX0",
      "display_url" : "snpy.tv\/2a0GIX0"
    } ]
  },
  "geo" : { },
  "id_str" : "754795143245496320",
  "text" : "\"Attacks on police are an attack on all of us and the rule of law that makes society possible.\" \u2014@POTUS https:\/\/t.co\/5I4OiS3kSi",
  "id" : 754795143245496320,
  "created_at" : "2016-07-17 21:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5I4OiRLJtI",
      "expanded_url" : "http:\/\/snpy.tv\/2a0GIX0",
      "display_url" : "snpy.tv\/2a0GIX0"
    } ]
  },
  "geo" : { },
  "id_str" : "754789041841713152",
  "text" : "\"We as a nation have to be loud and clear that nothing justifies violence against law enforcement.\" \u2014@POTUS https:\/\/t.co\/5I4OiRLJtI",
  "id" : 754789041841713152,
  "created_at" : "2016-07-17 21:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/5I4OiRLJtI",
      "expanded_url" : "http:\/\/snpy.tv\/2a0GIX0",
      "display_url" : "snpy.tv\/2a0GIX0"
    } ]
  },
  "geo" : { },
  "id_str" : "754785891390935040",
  "text" : "Watch @POTUS give remarks on the attack on law enforcement in Baton Rouge: https:\/\/t.co\/5I4OiRLJtI",
  "id" : 754785891390935040,
  "created_at" : "2016-07-17 21:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754785066149031936",
  "text" : "\"Only we can prove, in our own actions and words, that we will not be divided, even if we have to do it again and again and again.\" \u2014@POTUS",
  "id" : 754785066149031936,
  "created_at" : "2016-07-17 21:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754784804340498432",
  "text" : "\"It is up to all of us to make sure we are part of the solution, and not part of the problem.\" \u2014@POTUS speaks on the attack in Baton Rouge.",
  "id" : 754784804340498432,
  "created_at" : "2016-07-17 21:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754784559892271106",
  "text" : "\"Everyone right now focus on words and actions that can unite this country...We need to temper our words, and open our hearts.\" \u2014@POTUS",
  "id" : 754784559892271106,
  "created_at" : "2016-07-17 21:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754784275849805824",
  "text" : "\"What I want you to feel today is the respect &amp; gratitude of the American people for everything you do\" \u2014@POTUS to law enforcement",
  "id" : 754784275849805824,
  "created_at" : "2016-07-17 21:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754784018420215809",
  "text" : "\"I spoke with Governor Edwards and Mayor Holden. I offered them the full support of the federal government...Justice will be done.\" \u2014@POTUS",
  "id" : 754784018420215809,
  "created_at" : "2016-07-17 21:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754783895669706752",
  "text" : "\"Attacks on police are an attack on all of us and the rule of law that makes society possible.\" \u2014@POTUS",
  "id" : 754783895669706752,
  "created_at" : "2016-07-17 21:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/rczTFoTKvA",
      "expanded_url" : "http:\/\/go.wh.gov\/rd4aWU",
      "display_url" : "go.wh.gov\/rd4aWU"
    } ]
  },
  "geo" : { },
  "id_str" : "754783597538578432",
  "text" : "Watch live: @POTUS addresses the shooting of law enforcement officers in Baton Rouge: https:\/\/t.co\/rczTFoTKvA",
  "id" : 754783597538578432,
  "created_at" : "2016-07-17 21:03:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/rczTFpblUa",
      "expanded_url" : "http:\/\/go.wh.gov\/rd4aWU",
      "display_url" : "go.wh.gov\/rd4aWU"
    } ]
  },
  "geo" : { },
  "id_str" : "754770242119884800",
  "text" : "At 4:30 PM ET today, @POTUS will speak on the shooting of law enforcement officers in Baton Rouge. Tune in: https:\/\/t.co\/rczTFpblUa",
  "id" : 754770242119884800,
  "created_at" : "2016-07-17 20:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754753965707886593\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zgyPvCS0Na",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnlsqs5XEAQewxC.jpg",
      "id_str" : "754753893423321092",
      "id" : 754753893423321092,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnlsqs5XEAQewxC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/zgyPvCS0Na"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/rczTFpblUa",
      "expanded_url" : "http:\/\/go.wh.gov\/rd4aWU",
      "display_url" : "go.wh.gov\/rd4aWU"
    } ]
  },
  "geo" : { },
  "id_str" : "754753965707886593",
  "text" : ".@POTUS on the attack on law enforcement in Baton Rouge: https:\/\/t.co\/rczTFpblUa https:\/\/t.co\/zgyPvCS0Na",
  "id" : 754753965707886593,
  "created_at" : "2016-07-17 19:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XAmvtWJozX",
      "expanded_url" : "http:\/\/go.wh.gov\/uvNZic",
      "display_url" : "go.wh.gov\/uvNZic"
    } ]
  },
  "geo" : { },
  "id_str" : "754683672981282816",
  "text" : "\"We have to be able to talk about these things...Otherwise, we\u2019ll never break this dangerous cycle.\" \u2014@POTUS: https:\/\/t.co\/XAmvtWJozX",
  "id" : 754683672981282816,
  "created_at" : "2016-07-17 14:26:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/HUcVSiCVKV",
      "expanded_url" : "http:\/\/snpy.tv\/29D9D5m",
      "display_url" : "snpy.tv\/29D9D5m"
    } ]
  },
  "geo" : { },
  "id_str" : "754460643416117248",
  "text" : "\"I am absolutely confident that people of goodwill will ultimately overcome those that seek to divide\" \u2014@POTUS: https:\/\/t.co\/HUcVSiCVKV",
  "id" : 754460643416117248,
  "created_at" : "2016-07-16 23:40:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Plouffe",
      "screen_name" : "davidplouffe",
      "indices" : [ 3, 16 ],
      "id_str" : "1111940934",
      "id" : 1111940934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754454983261564928",
  "text" : "RT @davidplouffe: Fun video that captures much of his consequential presidency. President Obama addresses Netroots Nation 2016 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/mRDJni6Vxa",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2p6Ph-K8M1M&feature=share",
        "display_url" : "youtube.com\/watch?v=2p6Ph-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754453342420631554",
    "text" : "Fun video that captures much of his consequential presidency. President Obama addresses Netroots Nation 2016 https:\/\/t.co\/mRDJni6Vxa",
    "id" : 754453342420631554,
    "created_at" : "2016-07-16 23:11:08 +0000",
    "user" : {
      "name" : "David Plouffe",
      "screen_name" : "davidplouffe",
      "protected" : false,
      "id_str" : "1111940934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603500121159049216\/NqC2nF2l_normal.jpg",
      "id" : 1111940934,
      "verified" : true
    }
  },
  "id" : 754454983261564928,
  "created_at" : "2016-07-16 23:17:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/XAmvtWrNbn",
      "expanded_url" : "http:\/\/go.wh.gov\/uvNZic",
      "display_url" : "go.wh.gov\/uvNZic"
    } ]
  },
  "geo" : { },
  "id_str" : "754442118421057536",
  "text" : "\u201CThese conversations were candid, challenging\u201D \u2014@POTUS on building trust between communities and police: https:\/\/t.co\/XAmvtWrNbn",
  "id" : 754442118421057536,
  "created_at" : "2016-07-16 22:26:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/XAmvtWJozX",
      "expanded_url" : "http:\/\/go.wh.gov\/uvNZic",
      "display_url" : "go.wh.gov\/uvNZic"
    } ]
  },
  "geo" : { },
  "id_str" : "754420823734284288",
  "text" : "\u201CThe America I saw this week is just not as divided as some folks try to insist.\u201D \u2014@POTUS: https:\/\/t.co\/XAmvtWJozX",
  "id" : 754420823734284288,
  "created_at" : "2016-07-16 21:01:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/754408772496338944\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/u8lRxdPLD2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnghnL7UAAAjUuo.jpg",
      "id_str" : "754389894684737536",
      "id" : 754389894684737536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnghnL7UAAAjUuo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/u8lRxdPLD2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/KUqneDrAuU",
      "expanded_url" : "http:\/\/WH.Gov\/FilmFest",
      "display_url" : "WH.Gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "754408772496338944",
  "text" : "WH Student Film Fest submissions are extended to 8\/15! Still time to film, edit, and enter: https:\/\/t.co\/KUqneDrAuU https:\/\/t.co\/u8lRxdPLD2",
  "id" : 754408772496338944,
  "created_at" : "2016-07-16 20:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/754397767905140737\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Twifnsux1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cngg2a5VMAAmYcJ.jpg",
      "id_str" : "754389056889368576",
      "id" : 754389056889368576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cngg2a5VMAAmYcJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Twifnsux1O"
    } ],
    "hashtags" : [ {
      "text" : "5G",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/wu8Q2SMiHh",
      "expanded_url" : "http:\/\/go.wh.gov\/AdvancedWireless",
      "display_url" : "go.wh.gov\/AdvancedWirele\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754397767905140737",
  "text" : "This week, we announced new wireless research efforts. Here's what #5G means for you: https:\/\/t.co\/wu8Q2SMiHh https:\/\/t.co\/Twifnsux1O",
  "id" : 754397767905140737,
  "created_at" : "2016-07-16 19:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754382682348359680\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/CDmrIy7pdA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CngKYKUVYAAwzjI.jpg",
      "id_str" : "754364347787337728",
      "id" : 754364347787337728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CngKYKUVYAAwzjI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CDmrIy7pdA"
    } ],
    "hashtags" : [ {
      "text" : "5G",
      "indices" : [ 26, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/wu8Q2SMiHh",
      "expanded_url" : "http:\/\/go.wh.gov\/AdvancedWireless",
      "display_url" : "go.wh.gov\/AdvancedWirele\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754382682348359680",
  "text" : "Here's what a future with #5G\u2015and beyond\u2015means for you: https:\/\/t.co\/wu8Q2SMiHh https:\/\/t.co\/CDmrIy7pdA",
  "id" : 754382682348359680,
  "created_at" : "2016-07-16 18:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754368782584254464\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/8viQd6QrPw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CngJ7f-UIAAHabi.jpg",
      "id_str" : "754363855384354816",
      "id" : 754363855384354816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CngJ7f-UIAAHabi.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/8viQd6QrPw"
    } ],
    "hashtags" : [ {
      "text" : "5G",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/wu8Q2SMiHh",
      "expanded_url" : "http:\/\/go.wh.gov\/AdvancedWireless",
      "display_url" : "go.wh.gov\/AdvancedWirele\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754368782584254464",
  "text" : ".@POTUS is investing in our future with new #5G research funding. Get the facts \u2192 https:\/\/t.co\/wu8Q2SMiHh https:\/\/t.co\/8viQd6QrPw",
  "id" : 754368782584254464,
  "created_at" : "2016-07-16 17:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754355601958801408\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/zqsHgfwPsZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CngCasGWgAAiPyB.jpg",
      "id_str" : "754355595122212864",
      "id" : 754355595122212864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CngCasGWgAAiPyB.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 772
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zqsHgfwPsZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754355601958801408",
  "text" : "This morning, @POTUS received an update on the situation in Turkey: https:\/\/t.co\/zqsHgfwPsZ",
  "id" : 754355601958801408,
  "created_at" : "2016-07-16 16:42:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/XAmvtWrNbn",
      "expanded_url" : "http:\/\/go.wh.gov\/uvNZic",
      "display_url" : "go.wh.gov\/uvNZic"
    } ]
  },
  "geo" : { },
  "id_str" : "754346265442254848",
  "text" : ".@POTUS on forging consensus: \"That\u2019s what America\u2019s all about.\u201D https:\/\/t.co\/XAmvtWrNbn",
  "id" : 754346265442254848,
  "created_at" : "2016-07-16 16:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/XAmvtWrNbn",
      "expanded_url" : "http:\/\/go.wh.gov\/uvNZic",
      "display_url" : "go.wh.gov\/uvNZic"
    } ]
  },
  "geo" : { },
  "id_str" : "754317272466935808",
  "text" : "Watch @POTUS reflect on the tragic shootings in Dallas, Baton Rouge, and Falcon Heights in this week's address: https:\/\/t.co\/XAmvtWrNbn",
  "id" : 754317272466935808,
  "created_at" : "2016-07-16 14:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 47, 57 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/754095845524451328\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/c32Pb2xTgG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CncVzH3XYAArT4s.jpg",
      "id_str" : "754095430636625920",
      "id" : 754095430636625920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncVzH3XYAArT4s.jpg",
      "sizes" : [ {
        "h" : 531,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/c32Pb2xTgG"
    } ],
    "hashtags" : [ {
      "text" : "Turkey",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754096486162558976",
  "text" : "RT @StateDept: Statement by Secretary of State @JohnKerry on the situation in #Turkey https:\/\/t.co\/c32Pb2xTgG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 32, 42 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/754095845524451328\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/c32Pb2xTgG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CncVzH3XYAArT4s.jpg",
        "id_str" : "754095430636625920",
        "id" : 754095430636625920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncVzH3XYAArT4s.jpg",
        "sizes" : [ {
          "h" : 531,
          "resize" : "fit",
          "w" : 752
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 752
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 752
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/c32Pb2xTgG"
      } ],
      "hashtags" : [ {
        "text" : "Turkey",
        "indices" : [ 63, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754095845524451328",
    "text" : "Statement by Secretary of State @JohnKerry on the situation in #Turkey https:\/\/t.co\/c32Pb2xTgG",
    "id" : 754095845524451328,
    "created_at" : "2016-07-15 23:30:34 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 754096486162558976,
  "created_at" : "2016-07-15 23:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 117, 127 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754095401490325504",
  "text" : "RT @NSC44: \"The US views with gravest concern events unfolding in Turkey. We are monitoring a very fluid situation.\"-@JohnKerry.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 106, 116 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754094121854308352",
    "text" : "\"The US views with gravest concern events unfolding in Turkey. We are monitoring a very fluid situation.\"-@JohnKerry.",
    "id" : 754094121854308352,
    "created_at" : "2016-07-15 23:23:43 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 754095401490325504,
  "created_at" : "2016-07-15 23:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 33, 43 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/754094726614179841\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9SVvaDJ8Sn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CncVF7nVUAA_oQe.jpg",
      "id_str" : "754094654254043136",
      "id" : 754094654254043136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncVF7nVUAA_oQe.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9SVvaDJ8Sn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/VnR9yy53HV",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/whitehouse\/27716300004\/in\/datetaken",
      "display_url" : "flickr.com\/photos\/whiteho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754095112431472640",
  "text" : "RT @Price44: .@POTUS speaking to @JohnKerry regarding the situation in Turkey: https:\/\/t.co\/VnR9yy53HV https:\/\/t.co\/9SVvaDJ8Sn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 20, 30 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/754094726614179841\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/9SVvaDJ8Sn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CncVF7nVUAA_oQe.jpg",
        "id_str" : "754094654254043136",
        "id" : 754094654254043136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncVF7nVUAA_oQe.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9SVvaDJ8Sn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/VnR9yy53HV",
        "expanded_url" : "https:\/\/www.flickr.com\/photos\/whitehouse\/27716300004\/in\/datetaken",
        "display_url" : "flickr.com\/photos\/whiteho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754094726614179841",
    "text" : ".@POTUS speaking to @JohnKerry regarding the situation in Turkey: https:\/\/t.co\/VnR9yy53HV https:\/\/t.co\/9SVvaDJ8Sn",
    "id" : 754094726614179841,
    "created_at" : "2016-07-15 23:26:07 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 754095112431472640,
  "created_at" : "2016-07-15 23:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 29, 39 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754093311103758337",
  "text" : "RT @StateDept: .@POTUS &amp; @JohnKerry agreed all parties in Turkey should support the democratically-elected Gov't of Turkey, show restraint,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 14, 24 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754089931169861633",
    "text" : ".@POTUS &amp; @JohnKerry agreed all parties in Turkey should support the democratically-elected Gov't of Turkey, show restraint, avoid violence.",
    "id" : 754089931169861633,
    "created_at" : "2016-07-15 23:07:04 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 754093311103758337,
  "created_at" : "2016-07-15 23:20:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 46, 56 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754090830395281408\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/dcNGE0lJiN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CncRPOTXYAUvWAY.jpg",
      "id_str" : "754090415842877445",
      "id" : 754090415842877445,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncRPOTXYAUvWAY.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/dcNGE0lJiN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754090830395281408",
  "text" : "Tonight, @POTUS spoke with Secretary of State @JohnKerry about the ongoing situation in Turkey. https:\/\/t.co\/dcNGE0lJiN",
  "id" : 754090830395281408,
  "created_at" : "2016-07-15 23:10:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Turkey",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754063946655596544",
  "text" : "RT @Price44: .@POTUS' national security team has apprised him of the unfolding situation in #Turkey. @POTUS will continue to receive regula\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 88, 94 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Turkey",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754062410835595269",
    "text" : ".@POTUS' national security team has apprised him of the unfolding situation in #Turkey. @POTUS will continue to receive regular updates.",
    "id" : 754062410835595269,
    "created_at" : "2016-07-15 21:17:43 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 754063946655596544,
  "created_at" : "2016-07-15 21:23:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 29, 39 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754054367209263104\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/RTNxp1sYyj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnbvoKlW8AIElrp.jpg",
      "id_str" : "754053460945989634",
      "id" : 754053460945989634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnbvoKlW8AIElrp.jpg",
      "sizes" : [ {
        "h" : 297,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 780
      } ],
      "display_url" : "pic.twitter.com\/RTNxp1sYyj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/0DrcIVYyBJ",
      "expanded_url" : "http:\/\/go.wh.gov\/oufV31",
      "display_url" : "go.wh.gov\/oufV31"
    } ]
  },
  "geo" : { },
  "id_str" : "754054367209263104",
  "text" : ".@POTUS spoke with President @FHollande today to discuss the attack on Nice, France: https:\/\/t.co\/0DrcIVYyBJ https:\/\/t.co\/RTNxp1sYyj",
  "id" : 754054367209263104,
  "created_at" : "2016-07-15 20:45:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754042407386288128",
  "text" : "RT @AmbassadorRice: France has an unwavering friend in the U.S. We will support the investigation &amp; continue joint efforts to fight terrori\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754039782859169792",
    "text" : "France has an unwavering friend in the U.S. We will support the investigation &amp; continue joint efforts to fight terrorism around the globe.",
    "id" : 754039782859169792,
    "created_at" : "2016-07-15 19:47:48 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 754042407386288128,
  "created_at" : "2016-07-15 19:58:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/cw3nNNB95F",
      "expanded_url" : "http:\/\/snpy.tv\/29KfHaL",
      "display_url" : "snpy.tv\/29KfHaL"
    } ]
  },
  "geo" : { },
  "id_str" : "754033758563557377",
  "text" : "Watch @POTUS deliver a statement to the diplomatic corps on last night's terrorist attack in Nice, France. https:\/\/t.co\/cw3nNNB95F",
  "id" : 754033758563557377,
  "created_at" : "2016-07-15 19:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754028559312654337",
  "text" : "\"The hatred and the violence of a few ultimately is no match for the love and decency and hardwork of people of goodwill\" \u2014@POTUS",
  "id" : 754028559312654337,
  "created_at" : "2016-07-15 19:03:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754027100655394816",
  "text" : "\"We are going to destroy this vile terrorist organization.\" \u2014@POTUS on taking out ISIL and its leaders",
  "id" : 754027100655394816,
  "created_at" : "2016-07-15 18:57:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754026651936174081",
  "text" : "\"France is America's oldest ally\u2014and one of our strongest. We owe our freedom to each other.\" \u2014@POTUS on speaking with President Hollande",
  "id" : 754026651936174081,
  "created_at" : "2016-07-15 18:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754026275090542592",
  "text" : "\"Today, our hearts are with the people of France and with all the innocent men, women and children\" \u2014@POTUS",
  "id" : 754026275090542592,
  "created_at" : "2016-07-15 18:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/fLJcDBsEuE",
      "expanded_url" : "http:\/\/go.wh.gov\/c2nhDN",
      "display_url" : "go.wh.gov\/c2nhDN"
    } ]
  },
  "geo" : { },
  "id_str" : "754026129250320384",
  "text" : "Watch @POTUS host the diplomatic corps at the White House: https:\/\/t.co\/fLJcDBsEuE",
  "id" : 754026129250320384,
  "created_at" : "2016-07-15 18:53:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 67, 71 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754022753968152576\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/akQU5VxMfi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnbOL6FXYAAmF2f.jpg",
      "id_str" : "754016691596779520",
      "id" : 754016691596779520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnbOL6FXYAAmF2f.jpg",
      "sizes" : [ {
        "h" : 490,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1081,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 865,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1081,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/akQU5VxMfi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9xzA1MfBnT",
      "expanded_url" : "http:\/\/wh.gov\/BuildingTrust",
      "display_url" : "wh.gov\/BuildingTrust"
    } ]
  },
  "geo" : { },
  "id_str" : "754022753968152576",
  "text" : "\"Kindness and compassion...that makes a big difference\" \u2014@POTUS in @ABC town hall: https:\/\/t.co\/9xzA1MfBnT https:\/\/t.co\/akQU5VxMfi",
  "id" : 754022753968152576,
  "created_at" : "2016-07-15 18:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754018969774804992\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/6HvLhPsiA1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnbMP2rWgAEvkYV.jpg",
      "id_str" : "754014560378585089",
      "id" : 754014560378585089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnbMP2rWgAEvkYV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/6HvLhPsiA1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9xzA1MfBnT",
      "expanded_url" : "http:\/\/wh.gov\/BuildingTrust",
      "display_url" : "wh.gov\/BuildingTrust"
    } ]
  },
  "geo" : { },
  "id_str" : "754018969774804992",
  "text" : "We all have a role to play. \nHere's how community leaders can help build trust: https:\/\/t.co\/9xzA1MfBnT https:\/\/t.co\/6HvLhPsiA1",
  "id" : 754018969774804992,
  "created_at" : "2016-07-15 18:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/pyOvfDievG",
      "expanded_url" : "http:\/\/snpy.tv\/29HVYVR",
      "display_url" : "snpy.tv\/29HVYVR"
    } ]
  },
  "geo" : { },
  "id_str" : "754014192068243456",
  "text" : ".@POTUS on why we have to work together to successfully build trust between police and the community: https:\/\/t.co\/pyOvfDievG",
  "id" : 754014192068243456,
  "created_at" : "2016-07-15 18:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/pyOvfDzPUg",
      "expanded_url" : "http:\/\/snpy.tv\/29HVYVR",
      "display_url" : "snpy.tv\/29HVYVR"
    } ]
  },
  "geo" : { },
  "id_str" : "754011105819824128",
  "text" : "\"We can't put the burden on the police alone\" \u2014@POTUS on why we all have a role to play to help #StopGunViolence: https:\/\/t.co\/pyOvfDzPUg",
  "id" : 754011105819824128,
  "created_at" : "2016-07-15 17:53:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/754005886234980352\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bp62xZxkhC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnbD3tOWgAANrYs.jpg",
      "id_str" : "754005349431148544",
      "id" : 754005349431148544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnbD3tOWgAANrYs.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bp62xZxkhC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/qDnQCepBvm",
      "expanded_url" : "http:\/\/go.wh.gov\/bP6D8X",
      "display_url" : "go.wh.gov\/bP6D8X"
    } ]
  },
  "geo" : { },
  "id_str" : "754005886234980352",
  "text" : ".@POTUS orders U.S. flags to half-staff to honor victims of the attack in Nice, France: https:\/\/t.co\/qDnQCepBvm https:\/\/t.co\/bp62xZxkhC",
  "id" : 754005886234980352,
  "created_at" : "2016-07-15 17:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TSA",
      "screen_name" : "TSA",
      "indices" : [ 3, 7 ],
      "id_str" : "414331122",
      "id" : 414331122
    }, {
      "name" : "AskTSA",
      "screen_name" : "AskTSA",
      "indices" : [ 10, 17 ],
      "id_str" : "3292337961",
      "id" : 3292337961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TSA\/status\/751099725475028992\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/lgWklDmBi0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmxZr-AWEAIZVvn.jpg",
      "id_str" : "751073849777721346",
      "id" : 751073849777721346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmxZr-AWEAIZVvn.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/lgWklDmBi0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753984541983932416",
  "text" : "RT @TSA: .@AskTSA is now available Facebook Messenger to provide travelers with live assistance 365 days a year https:\/\/t.co\/lgWklDmBi0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AskTSA",
        "screen_name" : "AskTSA",
        "indices" : [ 1, 8 ],
        "id_str" : "3292337961",
        "id" : 3292337961
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TSA\/status\/751099725475028992\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/lgWklDmBi0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmxZr-AWEAIZVvn.jpg",
        "id_str" : "751073849777721346",
        "id" : 751073849777721346,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmxZr-AWEAIZVvn.jpg",
        "sizes" : [ {
          "h" : 601,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/lgWklDmBi0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753699361146535936",
    "text" : ".@AskTSA is now available Facebook Messenger to provide travelers with live assistance 365 days a year https:\/\/t.co\/lgWklDmBi0",
    "id" : 753699361146535936,
    "created_at" : "2016-07-14 21:15:05 +0000",
    "user" : {
      "name" : "TSA",
      "screen_name" : "TSA",
      "protected" : false,
      "id_str" : "414331122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695121003207233536\/OTkSdMvE_normal.png",
      "id" : 414331122,
      "verified" : true
    }
  },
  "id" : 753984541983932416,
  "created_at" : "2016-07-15 16:08:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "AskTSA",
      "screen_name" : "AskTSA",
      "indices" : [ 68, 75 ],
      "id_str" : "3292337961",
      "id" : 3292337961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753982240019849216\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/QgHs2omT2y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnauMmlVUAYDDjk.png",
      "id_str" : "753981519169933318",
      "id" : 753981519169933318,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnauMmlVUAYDDjk.png",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/QgHs2omT2y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/BIWF8FNrpU",
      "expanded_url" : "http:\/\/facebook.com\/AskTSA",
      "display_url" : "facebook.com\/AskTSA"
    } ]
  },
  "geo" : { },
  "id_str" : "753982240019849216",
  "text" : "Under @POTUS, we\u2019re building a 21st century government. Introducing @AskTSA on Facebook: https:\/\/t.co\/BIWF8FNrpU https:\/\/t.co\/QgHs2omT2y",
  "id" : 753982240019849216,
  "created_at" : "2016-07-15 15:59:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 78, 82 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753769588911902721\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JlX1Uf2ce8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnXtZWdWEAADmqU.jpg",
      "id_str" : "753769532435599360",
      "id" : 753769532435599360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnXtZWdWEAADmqU.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/JlX1Uf2ce8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/JYjVOq4HOs",
      "expanded_url" : "http:\/\/wh.gov\/buildingtrust",
      "display_url" : "wh.gov\/buildingtrust"
    } ]
  },
  "geo" : { },
  "id_str" : "753769588911902721",
  "text" : "\u201CIt all starts with kindness and empathy and respect for everybody\u201D\u2014@POTUS at @ABC town hall https:\/\/t.co\/JYjVOq4HOs https:\/\/t.co\/JlX1Uf2ce8",
  "id" : 753769588911902721,
  "created_at" : "2016-07-15 01:54:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUStownhall",
      "indices" : [ 70, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/NIsnWTWY2w",
      "expanded_url" : "http:\/\/snpy.tv\/2ae2HJc",
      "display_url" : "snpy.tv\/2ae2HJc"
    } ]
  },
  "geo" : { },
  "id_str" : "753763237414465536",
  "text" : ".@POTUS shares his personal story on prejudice in his own life during #POTUStownhall: https:\/\/t.co\/NIsnWTWY2w",
  "id" : 753763237414465536,
  "created_at" : "2016-07-15 01:28:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rjMGKRT4gy",
      "expanded_url" : "http:\/\/snpy.tv\/29Uj3KQ",
      "display_url" : "snpy.tv\/29Uj3KQ"
    } ]
  },
  "geo" : { },
  "id_str" : "753755369294270464",
  "text" : "RT @ABC: .@POTUS: \"For good police officers...the community has to stand up for them and speak out on their behalf.\" https:\/\/t.co\/rjMGKRT4gy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/rjMGKRT4gy",
        "expanded_url" : "http:\/\/snpy.tv\/29Uj3KQ",
        "display_url" : "snpy.tv\/29Uj3KQ"
      } ]
    },
    "geo" : { },
    "id_str" : "753749308738908160",
    "text" : ".@POTUS: \"For good police officers...the community has to stand up for them and speak out on their behalf.\" https:\/\/t.co\/rjMGKRT4gy",
    "id" : 753749308738908160,
    "created_at" : "2016-07-15 00:33:33 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658688193651277824\/Kv_cNNub_normal.png",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 753755369294270464,
  "created_at" : "2016-07-15 00:57:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 86, 90 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUStownhall",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Kma6YaNaxq",
      "expanded_url" : "http:\/\/snpy.tv\/29TPgPI",
      "display_url" : "snpy.tv\/29TPgPI"
    } ]
  },
  "geo" : { },
  "id_str" : "753753348868825088",
  "text" : "\"It's easier to get a gun than it is to get access to a computer or book.\" \u2014@POTUS at @ABC town hall #POTUStownhall  https:\/\/t.co\/Kma6YaNaxq",
  "id" : 753753348868825088,
  "created_at" : "2016-07-15 00:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "ABC News",
      "screen_name" : "abcnews",
      "indices" : [ 24, 32 ],
      "id_str" : "2768501",
      "id" : 2768501
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753741482092355584\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ocvSTeUtgW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnXTvqMW8AEhchY.jpg",
      "id_str" : "753741328387862529",
      "id" : 753741328387862529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnXTvqMW8AEhchY.jpg",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1950,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1426,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ocvSTeUtgW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/9xzA1MxcMt",
      "expanded_url" : "http:\/\/wh.gov\/BuildingTrust",
      "display_url" : "wh.gov\/BuildingTrust"
    } ]
  },
  "geo" : { },
  "id_str" : "753741482092355584",
  "text" : "Today, @POTUS joined an @ABCNews town hall on building trust in our communities. Watch now: https:\/\/t.co\/9xzA1MxcMt https:\/\/t.co\/ocvSTeUtgW",
  "id" : 753741482092355584,
  "created_at" : "2016-07-15 00:02:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/753739701236801536\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/CrbChxZs04",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnXQEXgUAAA2-dj.jpg",
      "id_str" : "753737286102024192",
      "id" : 753737286102024192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnXQEXgUAAA2-dj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CrbChxZs04"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753739701236801536",
  "text" : ".@POTUS on the attack in Nice, France: https:\/\/t.co\/CrbChxZs04",
  "id" : 753739701236801536,
  "created_at" : "2016-07-14 23:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753723702370525184",
  "text" : "RT @Price44: The President has been apprised of the situation in Nice, France, and his national security team will update him, as appropria\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753723586616012800",
    "text" : "The President has been apprised of the situation in Nice, France, and his national security team will update him, as appropriate.",
    "id" : 753723586616012800,
    "created_at" : "2016-07-14 22:51:21 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 753723702370525184,
  "created_at" : "2016-07-14 22:51:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "summerlearning",
      "screen_name" : "summerlearning",
      "indices" : [ 3, 18 ],
      "id_str" : "18978314",
      "id" : 18978314
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/summerlearning\/status\/753676220861063168\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/w7wkSpr3iv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnWYhs6UsAEhIbv.jpg",
      "id_str" : "753676217413316609",
      "id" : 753676217413316609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnWYhs6UsAEhIbv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/w7wkSpr3iv"
    } ],
    "hashtags" : [ {
      "text" : "KeepKidsLearning",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753696241423265792",
  "text" : "RT @summerlearning: What's your community doing this summer to keep kids learning? Tell us with #KeepKidsLearning! https:\/\/t.co\/w7wkSpr3iv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/summerlearning\/status\/753676220861063168\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/w7wkSpr3iv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnWYhs6UsAEhIbv.jpg",
        "id_str" : "753676217413316609",
        "id" : 753676217413316609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnWYhs6UsAEhIbv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/w7wkSpr3iv"
      } ],
      "hashtags" : [ {
        "text" : "KeepKidsLearning",
        "indices" : [ 76, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753676220861063168",
    "text" : "What's your community doing this summer to keep kids learning? Tell us with #KeepKidsLearning! https:\/\/t.co\/w7wkSpr3iv",
    "id" : 753676220861063168,
    "created_at" : "2016-07-14 19:43:08 +0000",
    "user" : {
      "name" : "summerlearning",
      "screen_name" : "summerlearning",
      "protected" : false,
      "id_str" : "18978314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740901989421309953\/uoFHIqPY_normal.jpg",
      "id" : 18978314,
      "verified" : false
    }
  },
  "id" : 753696241423265792,
  "created_at" : "2016-07-14 21:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753684363766796288",
  "text" : "RT @NSC44: This week Congress will depart for 7 weeks of summer recess. We still need to them to enact emergency #Zika funding. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/753684045201104896\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Aeunt2vKDL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnWfkfZVMAAUMxq.jpg",
        "id_str" : "753683961906278400",
        "id" : 753683961906278400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnWfkfZVMAAUMxq.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Aeunt2vKDL"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753684045201104896",
    "text" : "This week Congress will depart for 7 weeks of summer recess. We still need to them to enact emergency #Zika funding. https:\/\/t.co\/Aeunt2vKDL",
    "id" : 753684045201104896,
    "created_at" : "2016-07-14 20:14:13 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 753684363766796288,
  "created_at" : "2016-07-14 20:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/CkPvXOS6Tk",
      "expanded_url" : "http:\/\/snpy.tv\/29wAUXa",
      "display_url" : "snpy.tv\/29wAUXa"
    } ]
  },
  "geo" : { },
  "id_str" : "753654788584243201",
  "text" : ".@POTUS shares 5 ways we can forge a path forward on community policing. Watch: https:\/\/t.co\/CkPvXOS6Tk",
  "id" : 753654788584243201,
  "created_at" : "2016-07-14 18:17:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753648015362002944\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/obG5fnAA0I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnV6dOoWIAAocMt.jpg",
      "id_str" : "753643155216539648",
      "id" : 753643155216539648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnV6dOoWIAAocMt.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/obG5fnAA0I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/kmXCb5gSfO",
      "expanded_url" : "http:\/\/go.wh.gov\/bpYkHy",
      "display_url" : "go.wh.gov\/bpYkHy"
    } ]
  },
  "geo" : { },
  "id_str" : "753648015362002944",
  "text" : "\"All of us have the power to make change in our own communities.\" \u2014@POTUS: https:\/\/t.co\/kmXCb5gSfO https:\/\/t.co\/obG5fnAA0I",
  "id" : 753648015362002944,
  "created_at" : "2016-07-14 17:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/CkPvXOS6Tk",
      "expanded_url" : "http:\/\/snpy.tv\/29wAUXa",
      "display_url" : "snpy.tv\/29wAUXa"
    } ]
  },
  "geo" : { },
  "id_str" : "753642949808979968",
  "text" : "Watch what @POTUS had to say after hearing from different perspectives in yesterday's meeting on community policing: https:\/\/t.co\/CkPvXOS6Tk",
  "id" : 753642949808979968,
  "created_at" : "2016-07-14 17:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 41, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753631924237770752",
  "text" : "RT @FLOTUS: .@POTUS's special message to #KidsStateDinner attendees: \"Your creative recipes are showing everybody that healthy food is deli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 29, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753628570573017088",
    "text" : ".@POTUS's special message to #KidsStateDinner attendees: \"Your creative recipes are showing everybody that healthy food is delicious too.\"",
    "id" : 753628570573017088,
    "created_at" : "2016-07-14 16:33:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 753631924237770752,
  "created_at" : "2016-07-14 16:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kansas City Royals",
      "screen_name" : "Royals",
      "indices" : [ 3, 10 ],
      "id_str" : "28603812",
      "id" : 28603812
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 106, 117 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Royals",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753615644541591552",
  "text" : "RT @Royals: Your 2015 World Champion Kansas City #Royals are excited to share a special announcement from @WhiteHouse!\nhttps:\/\/t.co\/itJUdqu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 94, 105 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Royals",
        "indices" : [ 37, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/itJUdquEaN",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/07b261e8-1ba6-4ce3-ac27-b5fa46cea621",
        "display_url" : "amp.twimg.com\/v\/07b261e8-1ba\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753614153680510976",
    "text" : "Your 2015 World Champion Kansas City #Royals are excited to share a special announcement from @WhiteHouse!\nhttps:\/\/t.co\/itJUdquEaN",
    "id" : 753614153680510976,
    "created_at" : "2016-07-14 15:36:30 +0000",
    "user" : {
      "name" : "Kansas City Royals",
      "screen_name" : "Royals",
      "protected" : false,
      "id_str" : "28603812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789471916918583296\/Q-cBOK1A_normal.jpg",
      "id" : 28603812,
      "verified" : true
    }
  },
  "id" : 753615644541591552,
  "created_at" : "2016-07-14 15:42:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753599756509872128\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/z3ytQx8ROC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnVS0awUMAEcdO0.jpg",
      "id_str" : "753599573143072769",
      "id" : 753599573143072769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnVS0awUMAEcdO0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/z3ytQx8ROC"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/4SHCkaOVH2",
      "expanded_url" : "http:\/\/go.wh.gov\/AyctPt",
      "display_url" : "go.wh.gov\/AyctPt"
    } ]
  },
  "geo" : { },
  "id_str" : "753599756509872128",
  "text" : "1 year later, the #IranDeal has helped make the U.S., our partners &amp; the world more secure: https:\/\/t.co\/4SHCkaOVH2 https:\/\/t.co\/z3ytQx8ROC",
  "id" : 753599756509872128,
  "created_at" : "2016-07-14 14:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/4WGFL6wyRO",
      "expanded_url" : "http:\/\/go.wh.gov\/AyctPt",
      "display_url" : "go.wh.gov\/AyctPt"
    } ]
  },
  "geo" : { },
  "id_str" : "753581489732943872",
  "text" : "RT @TheIranDeal: \"The United States, our partners &amp; the world are more secure\" \u2014@POTUS a year after #IranDeal https:\/\/t.co\/4WGFL6wyRO https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 67, 73 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/4WGFL6wyRO",
        "expanded_url" : "http:\/\/go.wh.gov\/AyctPt",
        "display_url" : "go.wh.gov\/AyctPt"
      }, {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/N94icSElUU",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/5922f2b7-4eaf-4ce0-aadb-db0efd32dba9",
        "display_url" : "amp.twimg.com\/v\/5922f2b7-4ea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753581278864093184",
    "text" : "\"The United States, our partners &amp; the world are more secure\" \u2014@POTUS a year after #IranDeal https:\/\/t.co\/4WGFL6wyRO https:\/\/t.co\/N94icSElUU",
    "id" : 753581278864093184,
    "created_at" : "2016-07-14 13:25:52 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 753581489732943872,
  "created_at" : "2016-07-14 13:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753577909584064512",
  "text" : "RT @JohnKerry: Agreement on the #IranDeal was reached 1 year ago today. Commitment to diplomacy made the world safer. https:\/\/t.co\/IbjSbExt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/753499302845157376\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/IbjSbExtLw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnT3nSRWIAA7i1r.jpg",
        "id_str" : "753499291969265664",
        "id" : 753499291969265664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnT3nSRWIAA7i1r.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IbjSbExtLw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/753499302845157376\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/IbjSbExtLw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnT3nSVWAAA-wV5.jpg",
        "id_str" : "753499291986034688",
        "id" : 753499291986034688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnT3nSVWAAA-wV5.jpg",
        "sizes" : [ {
          "h" : 318,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/IbjSbExtLw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/753499302845157376\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/IbjSbExtLw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnT3nSTXEAEutCj.jpg",
        "id_str" : "753499291977715713",
        "id" : 753499291977715713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnT3nSTXEAEutCj.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IbjSbExtLw"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753499302845157376",
    "text" : "Agreement on the #IranDeal was reached 1 year ago today. Commitment to diplomacy made the world safer. https:\/\/t.co\/IbjSbExtLw",
    "id" : 753499302845157376,
    "created_at" : "2016-07-14 08:00:07 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 753577909584064512,
  "created_at" : "2016-07-14 13:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESPYS",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/7pKls0rIaE",
      "expanded_url" : "http:\/\/snpy.tv\/29R9ucL",
      "display_url" : "snpy.tv\/29R9ucL"
    } ]
  },
  "geo" : { },
  "id_str" : "753425165275521024",
  "text" : "\"It's up to all of us to build a country that's worthy of Zaevion's promise.\" \u2014@POTUS on Zaevion Dobson #ESPYS https:\/\/t.co\/7pKls0rIaE",
  "id" : 753425165275521024,
  "created_at" : "2016-07-14 03:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/XOjvD3x6j3",
      "expanded_url" : "http:\/\/snpy.tv\/29RcvwC",
      "display_url" : "snpy.tv\/29RcvwC"
    } ]
  },
  "geo" : { },
  "id_str" : "753416493715435520",
  "text" : "\"We have to, as a country, sit down and just grind it out, solve these problems.\" \u2014@POTUS: https:\/\/t.co\/XOjvD3x6j3",
  "id" : 753416493715435520,
  "created_at" : "2016-07-14 02:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/AyVzIxNIEV",
      "expanded_url" : "https:\/\/twitter.com\/espn\/status\/753400071304179712",
      "display_url" : "twitter.com\/espn\/status\/75\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753410676039622656",
  "text" : "Zaevion Dobson gave his life to protect his friends. We can build a future worthy of his promise. #StopGunViolence https:\/\/t.co\/AyVzIxNIEV",
  "id" : 753410676039622656,
  "created_at" : "2016-07-14 02:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/CkPvXP9HKS",
      "expanded_url" : "http:\/\/snpy.tv\/29wAUXa",
      "display_url" : "snpy.tv\/29wAUXa"
    } ]
  },
  "geo" : { },
  "id_str" : "753406692482625536",
  "text" : "Here's what @POTUS had to say after a convening on building community\ntrust and ensuring justice for all Americans: https:\/\/t.co\/CkPvXP9HKS",
  "id" : 753406692482625536,
  "created_at" : "2016-07-14 01:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753403556321832960",
  "text" : "RT @POTUS: Congrats Carla Hayden, our newest Librarian of Congress! Her confirmation is certainly one for the history books.\nhttps:\/\/t.co\/5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/5T8rvSRp9e",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/146bf05b-4ac0-49e4-8eab-322885e67fe5",
        "display_url" : "amp.twimg.com\/v\/146bf05b-4ac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753403382744780800",
    "text" : "Congrats Carla Hayden, our newest Librarian of Congress! Her confirmation is certainly one for the history books.\nhttps:\/\/t.co\/5T8rvSRp9e",
    "id" : 753403382744780800,
    "created_at" : "2016-07-14 01:38:58 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 753403556321832960,
  "created_at" : "2016-07-14 01:39:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753401847419801600\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/DbJgkk7fQc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnSembWWgAAA6RB.jpg",
      "id_str" : "753401420691439616",
      "id" : 753401420691439616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnSembWWgAAA6RB.jpg",
      "sizes" : [ {
        "h" : 635,
        "resize" : "fit",
        "w" : 1273
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 1273
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/DbJgkk7fQc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/kmXCb5gSfO",
      "expanded_url" : "http:\/\/go.wh.gov\/bpYkHy",
      "display_url" : "go.wh.gov\/bpYkHy"
    } ]
  },
  "geo" : { },
  "id_str" : "753401847419801600",
  "text" : "\"All of us have the power to make change in our own communities.\" \u2014@POTUS: https:\/\/t.co\/kmXCb5gSfO https:\/\/t.co\/DbJgkk7fQc",
  "id" : 753401847419801600,
  "created_at" : "2016-07-14 01:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESPYS",
      "screen_name" : "ESPYS",
      "indices" : [ 3, 9 ],
      "id_str" : "40104936",
      "id" : 40104936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753398806725685248",
  "text" : "RT @ESPYS: ICYMI: Here's the powerful message from LeBron James, Dwyane Wade, Chris Paul and Carmelo Anthony to open the show. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Cab78Fapoo",
        "expanded_url" : "http:\/\/es.pn\/29QUADn",
        "display_url" : "es.pn\/29QUADn"
      } ]
    },
    "geo" : { },
    "id_str" : "753384631160930304",
    "text" : "ICYMI: Here's the powerful message from LeBron James, Dwyane Wade, Chris Paul and Carmelo Anthony to open the show. https:\/\/t.co\/Cab78Fapoo",
    "id" : 753384631160930304,
    "created_at" : "2016-07-14 00:24:27 +0000",
    "user" : {
      "name" : "ESPYS",
      "screen_name" : "ESPYS",
      "protected" : false,
      "id_str" : "40104936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621441931982307328\/oH4RRWGt_normal.jpg",
      "id" : 40104936,
      "verified" : true
    }
  },
  "id" : 753398806725685248,
  "created_at" : "2016-07-14 01:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NLC",
      "screen_name" : "leagueofcities",
      "indices" : [ 3, 18 ],
      "id_str" : "21803333",
      "id" : 21803333
    }, {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "indices" : [ 34, 43 ],
      "id_str" : "15012352",
      "id" : 15012352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/yjoRsQpBXz",
      "expanded_url" : "http:\/\/bit.ly\/29wl12Q",
      "display_url" : "bit.ly\/29wl12Q"
    } ]
  },
  "geo" : { },
  "id_str" : "753392674145579008",
  "text" : "RT @leagueofcities: Proud to join @usmayors in support of WH Efforts to Encourage Community Conversations https:\/\/t.co\/yjoRsQpBXz https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Mayors",
        "screen_name" : "usmayors",
        "indices" : [ 14, 23 ],
        "id_str" : "15012352",
        "id" : 15012352
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/leagueofcities\/status\/753356489247653890\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/phAcTmpP61",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnR1pN2XgAA9HLn.jpg",
        "id_str" : "753356388630495232",
        "id" : 753356388630495232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnR1pN2XgAA9HLn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/phAcTmpP61"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/yjoRsQpBXz",
        "expanded_url" : "http:\/\/bit.ly\/29wl12Q",
        "display_url" : "bit.ly\/29wl12Q"
      } ]
    },
    "geo" : { },
    "id_str" : "753356489247653890",
    "text" : "Proud to join @usmayors in support of WH Efforts to Encourage Community Conversations https:\/\/t.co\/yjoRsQpBXz https:\/\/t.co\/phAcTmpP61",
    "id" : 753356489247653890,
    "created_at" : "2016-07-13 22:32:38 +0000",
    "user" : {
      "name" : "NLC",
      "screen_name" : "leagueofcities",
      "protected" : false,
      "id_str" : "21803333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747225708456456192\/1LQaHPX3_normal.jpg",
      "id" : 21803333,
      "verified" : false
    }
  },
  "id" : 753392674145579008,
  "created_at" : "2016-07-14 00:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753369726068355072",
  "text" : "RT @PressSec: .@POTUS will sign opioid bill. BUT it falls far short bc GOP blocked $ for treatment. He will keep pushing for it. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/753369580471332864\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/jpbgr9N6Ll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnSBgf2XgAIjYNo.jpg",
        "id_str" : "753369432983044098",
        "id" : 753369432983044098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnSBgf2XgAIjYNo.jpg",
        "sizes" : [ {
          "h" : 311,
          "resize" : "fit",
          "w" : 881
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 881
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 881
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/jpbgr9N6Ll"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753369580471332864",
    "text" : ".@POTUS will sign opioid bill. BUT it falls far short bc GOP blocked $ for treatment. He will keep pushing for it. https:\/\/t.co\/jpbgr9N6Ll",
    "id" : 753369580471332864,
    "created_at" : "2016-07-13 23:24:39 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 753369726068355072,
  "created_at" : "2016-07-13 23:25:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 102, 105 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Port of San Diego",
      "screen_name" : "portofsandiego",
      "indices" : [ 109, 124 ],
      "id_str" : "15456558",
      "id" : 15456558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753351977107501056",
  "text" : "RT @VPLive: \"We've won every case that's been decided by the WTO. I'm confident we'll win this one.\" -@VP at @portofsandiego https:\/\/t.co\/y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 90, 93 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Port of San Diego",
        "screen_name" : "portofsandiego",
        "indices" : [ 97, 112 ],
        "id_str" : "15456558",
        "id" : 15456558
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VPLive\/status\/753333857382834176\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/yuz2bLjYlL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnRg_gzUkAAwMdM.jpg",
        "id_str" : "753333681930932224",
        "id" : 753333681930932224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnRg_gzUkAAwMdM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/yuz2bLjYlL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753333857382834176",
    "text" : "\"We've won every case that's been decided by the WTO. I'm confident we'll win this one.\" -@VP at @portofsandiego https:\/\/t.co\/yuz2bLjYlL",
    "id" : 753333857382834176,
    "created_at" : "2016-07-13 21:02:42 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 753351977107501056,
  "created_at" : "2016-07-13 22:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/6pIhWXGOxR",
      "expanded_url" : "http:\/\/go.wh.gov\/ZTwehr",
      "display_url" : "go.wh.gov\/ZTwehr"
    } ]
  },
  "geo" : { },
  "id_str" : "753335964576034816",
  "text" : "Dr. Carla Hayden has helped libraries innovate and expand access. Today she became our 14th Librarian of Congress: https:\/\/t.co\/6pIhWXGOxR",
  "id" : 753335964576034816,
  "created_at" : "2016-07-13 21:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Library of Congress",
      "screen_name" : "librarycongress",
      "indices" : [ 3, 19 ],
      "id_str" : "7152572",
      "id" : 7152572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753321184050024448",
  "text" : "RT @librarycongress: The U.S. Senate has approved the nomination of Dr. Carla Hayden to be the 14th Librarian of Congress. https:\/\/t.co\/8VU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/librarycongress\/status\/753305519998308353\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/8VUnWECTO7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnRFXatWcAEQxvB.jpg",
        "id_str" : "753303306286559233",
        "id" : 753303306286559233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnRFXatWcAEQxvB.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1363
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2254,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 799
        } ],
        "display_url" : "pic.twitter.com\/8VUnWECTO7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753305519998308353",
    "text" : "The U.S. Senate has approved the nomination of Dr. Carla Hayden to be the 14th Librarian of Congress. https:\/\/t.co\/8VUnWECTO7",
    "id" : 753305519998308353,
    "created_at" : "2016-07-13 19:10:06 +0000",
    "user" : {
      "name" : "Library of Congress",
      "screen_name" : "librarycongress",
      "protected" : false,
      "id_str" : "7152572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463771973139447808\/Gv1mSKiG_normal.jpeg",
      "id" : 7152572,
      "verified" : true
    }
  },
  "id" : 753321184050024448,
  "created_at" : "2016-07-13 20:12:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/sOADttVUU3",
      "expanded_url" : "http:\/\/goo.gl\/qLE0Wh",
      "display_url" : "goo.gl\/qLE0Wh"
    } ]
  },
  "geo" : { },
  "id_str" : "753320276998356994",
  "text" : "RT @PressSec: Why Congress GOP's plan to ignore the #Zika threat until the fall is a deeply bad idea: https:\/\/t.co\/sOADttVUU3 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/753318949832445952\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/B46b9KhQJb",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CnRTlDWUAAAcBiW.jpg",
        "id_str" : "753318933696872448",
        "id" : 753318933696872448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CnRTlDWUAAAcBiW.jpg",
        "sizes" : [ {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/B46b9KhQJb"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 38, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/sOADttVUU3",
        "expanded_url" : "http:\/\/goo.gl\/qLE0Wh",
        "display_url" : "goo.gl\/qLE0Wh"
      } ]
    },
    "geo" : { },
    "id_str" : "753318949832445952",
    "text" : "Why Congress GOP's plan to ignore the #Zika threat until the fall is a deeply bad idea: https:\/\/t.co\/sOADttVUU3 https:\/\/t.co\/B46b9KhQJb",
    "id" : 753318949832445952,
    "created_at" : "2016-07-13 20:03:28 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 753320276998356994,
  "created_at" : "2016-07-13 20:08:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 29, 35 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 94, 101 ],
      "id_str" : "146569971",
      "id" : 146569971
    }, {
      "name" : "March of Dimes",
      "screen_name" : "modhealthtalk",
      "indices" : [ 108, 122 ],
      "id_str" : "12414552",
      "id" : 12414552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZAPzika",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753246569558777857",
  "text" : "RT @NSC44: Today at 12pm ET, @NSC44's Amy Pope will answer your Zika questions at #ZAPzika w\/ @CDCgov &amp; @modhealthtalk. https:\/\/t.co\/pASTI8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WH National Security",
        "screen_name" : "NSC44",
        "indices" : [ 18, 24 ],
        "id_str" : "369245377",
        "id" : 369245377
      }, {
        "name" : "CDC",
        "screen_name" : "CDCgov",
        "indices" : [ 83, 90 ],
        "id_str" : "146569971",
        "id" : 146569971
      }, {
        "name" : "March of Dimes",
        "screen_name" : "modhealthtalk",
        "indices" : [ 97, 111 ],
        "id_str" : "12414552",
        "id" : 12414552
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/753246174782554112\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/pASTI8ih6T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnQRZXKVIAIpSUV.jpg",
        "id_str" : "753246165089460226",
        "id" : 753246165089460226,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnQRZXKVIAIpSUV.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/pASTI8ih6T"
      } ],
      "hashtags" : [ {
        "text" : "ZAPzika",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753246174782554112",
    "text" : "Today at 12pm ET, @NSC44's Amy Pope will answer your Zika questions at #ZAPzika w\/ @CDCgov &amp; @modhealthtalk. https:\/\/t.co\/pASTI8ih6T",
    "id" : 753246174782554112,
    "created_at" : "2016-07-13 15:14:17 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 753246569558777857,
  "created_at" : "2016-07-13 15:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/753027376854863872\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/D0fthAPb0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNKRtUWgAAsb_C.jpg",
      "id_str" : "753027230784192512",
      "id" : 753027230784192512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNKRtUWgAAsb_C.jpg",
      "sizes" : [ {
        "h" : 1327,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 2666
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/D0fthAPb0F"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/753027376854863872\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/D0fthAPb0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNKRvmW8AAm818.jpg",
      "id_str" : "753027231396589568",
      "id" : 753027231396589568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNKRvmW8AAm818.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1800,
        "resize" : "fit",
        "w" : 2700
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/D0fthAPb0F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753027376854863872",
  "text" : "\"I\u2019m here to say we must reject such despair. I\u2019m here to insist that we are not as divided as we seem.\" \u2014@POTUS https:\/\/t.co\/D0fthAPb0F",
  "id" : 753027376854863872,
  "created_at" : "2016-07-13 00:44:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/753025033304322048\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/8KVWrhdWPK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNH6f9UkAANoG3.jpg",
      "id_str" : "753024633037688832",
      "id" : 753024633037688832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNH6f9UkAANoG3.jpg",
      "sizes" : [ {
        "h" : 1519,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1244,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8KVWrhdWPK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753025033304322048",
  "text" : "\"We are one American family, all deserving of equal treatment, all deserving of equal respect\" \u2014@POTUS in Dallas https:\/\/t.co\/8KVWrhdWPK",
  "id" : 753025033304322048,
  "created_at" : "2016-07-13 00:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 10, 14 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/LCoD7a5Frd",
      "expanded_url" : "http:\/\/abcn.ws\/29NwdJq",
      "display_url" : "abcn.ws\/29NwdJq"
    } ]
  },
  "geo" : { },
  "id_str" : "753006209045827584",
  "text" : "RT @ABC: .@ABC to host town hall with Pres. Obama Thursday following tragic shootings across America. https:\/\/t.co\/LCoD7a5Frd https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 1, 5 ],
        "id_str" : "28785486",
        "id" : 28785486
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ABC\/status\/752996425487806464\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/YVDb1sncog",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMtOlNUMAEuoBE.jpg",
        "id_str" : "752995291230384129",
        "id" : 752995291230384129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMtOlNUMAEuoBE.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/YVDb1sncog"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/LCoD7a5Frd",
        "expanded_url" : "http:\/\/abcn.ws\/29NwdJq",
        "display_url" : "abcn.ws\/29NwdJq"
      } ]
    },
    "geo" : { },
    "id_str" : "752996425487806464",
    "text" : ".@ABC to host town hall with Pres. Obama Thursday following tragic shootings across America. https:\/\/t.co\/LCoD7a5Frd https:\/\/t.co\/YVDb1sncog",
    "id" : 752996425487806464,
    "created_at" : "2016-07-12 22:41:52 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658688193651277824\/Kv_cNNub_normal.png",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 753006209045827584,
  "created_at" : "2016-07-12 23:20:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bF5WPhxTCh",
      "expanded_url" : "http:\/\/snpy.tv\/29ClW0l",
      "display_url" : "snpy.tv\/29ClW0l"
    } ]
  },
  "geo" : { },
  "id_str" : "752975855287087105",
  "text" : "\"We cannot match their courage, but we can strive to match their devotion.\" \u2014 @POTUS on honoring the fallen officers https:\/\/t.co\/bF5WPhxTCh",
  "id" : 752975855287087105,
  "created_at" : "2016-07-12 21:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DallasMemorial",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/4fCI6iLBy4",
      "expanded_url" : "http:\/\/snpy.tv\/29CkQ4D",
      "display_url" : "snpy.tv\/29CkQ4D"
    } ]
  },
  "geo" : { },
  "id_str" : "752973134295343107",
  "text" : "\"With an open heart, we can learn to stand in each other's shoes.\" \u2014@POTUS at the #DallasMemorial https:\/\/t.co\/4fCI6iLBy4",
  "id" : 752973134295343107,
  "created_at" : "2016-07-12 21:09:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DallasMemorial",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/S2Lueskwzf",
      "expanded_url" : "http:\/\/snpy.tv\/29NxU6Z",
      "display_url" : "snpy.tv\/29NxU6Z"
    } ]
  },
  "geo" : { },
  "id_str" : "752962009931460609",
  "text" : "\"We cannot simply turn away and dismiss those in peaceful protest as troublemakers\" \u2014@POTUS #DallasMemorial https:\/\/t.co\/S2Lueskwzf",
  "id" : 752962009931460609,
  "created_at" : "2016-07-12 20:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/eNwmJM5UVW",
      "expanded_url" : "http:\/\/snpy.tv\/29UNtw5",
      "display_url" : "snpy.tv\/29UNtw5"
    } ]
  },
  "geo" : { },
  "id_str" : "752958733286649856",
  "text" : "\u201CI\u2019m here to say we must reject such despair. I\u2019m here to insist that we are not as divided as we seem.\u201D \u2014@POTUS  https:\/\/t.co\/eNwmJM5UVW",
  "id" : 752958733286649856,
  "created_at" : "2016-07-12 20:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752957374453977088",
  "text" : "RT @VP: These broken-hearted families will only be redeemed by the courage of our actions. This violence has to stop. And we have to stop i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "752955006718971904",
    "geo" : { },
    "id_str" : "752956521089212417",
    "in_reply_to_user_id" : 325830217,
    "text" : "These broken-hearted families will only be redeemed by the courage of our actions. This violence has to stop. And we have to stop it.",
    "id" : 752956521089212417,
    "in_reply_to_status_id" : 752955006718971904,
    "created_at" : "2016-07-12 20:03:18 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 752957374453977088,
  "created_at" : "2016-07-12 20:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/HtPzzOR29l",
      "expanded_url" : "http:\/\/snpy.tv\/29w73cX",
      "display_url" : "snpy.tv\/29w73cX"
    } ]
  },
  "geo" : { },
  "id_str" : "752956189584089088",
  "text" : "\u201CI see what\u2019s possible when we recognize that we are one American family, all deserving of equal treatment\u201D \u2014@POTUS  https:\/\/t.co\/HtPzzOR29l",
  "id" : 752956189584089088,
  "created_at" : "2016-07-12 20:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DallasMemorial",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/K9inIEjNMH",
      "expanded_url" : "http:\/\/snpy.tv\/29ClzTx",
      "display_url" : "snpy.tv\/29ClzTx"
    } ]
  },
  "geo" : { },
  "id_str" : "752953203566579712",
  "text" : "\"I believe our sorrow can make us a better country.\"\nWatch @POTUS deliver remarks at the #DallasMemorial:\nhttps:\/\/t.co\/K9inIEjNMH",
  "id" : 752953203566579712,
  "created_at" : "2016-07-12 19:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DallasMemorial",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/fbQxve1JMB",
      "expanded_url" : "http:\/\/snpy.tv\/29UMtI7",
      "display_url" : "snpy.tv\/29UMtI7"
    } ]
  },
  "geo" : { },
  "id_str" : "752950844002340864",
  "text" : "\"These men &amp; their families shared a commitment to something larger than themselves.\" \u2014@POTUS at the #DallasMemorial https:\/\/t.co\/fbQxve1JMB",
  "id" : 752950844002340864,
  "created_at" : "2016-07-12 19:40:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752947675415339008",
  "text" : "\"I believe our sorrow can make us a better country. I believe our righteous anger can be transformed into more justice &amp; more peace\" \u2014@POTUS",
  "id" : 752947675415339008,
  "created_at" : "2016-07-12 19:28:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752945729820323840",
  "text" : "\u201CFor even those who dislike the phrase Black Lives Matter should be able to hear the pain of Alton Sterling\u2019s family\u201D \u2014@POTUS in Dallas",
  "id" : 752945729820323840,
  "created_at" : "2016-07-12 19:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752944933493813248",
  "text" : "\"Can we see in each other a common humanity, a shared dignity, and recognize how our different experiences have shaped us?\" \u2014@POTUS",
  "id" : 752944933493813248,
  "created_at" : "2016-07-12 19:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752944856951951360",
  "text" : "\u201CCan we do this? Can we find the character, as Americans, to open our hearts to each other?\u201D \u2014@POTUS in Dallas",
  "id" : 752944856951951360,
  "created_at" : "2016-07-12 19:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752944815088689152",
  "text" : "\u201CIt is not about finding policies that work; it\u2019s about forging consensus; fighting cynicism; and finding the will to make change\u201D  \u2014@POTUS",
  "id" : 752944815088689152,
  "created_at" : "2016-07-12 19:16:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DallasMemorial",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752944701871841280",
  "text" : "\u201CIf we cannot even talk about these things honestly and openly...we will never break this dangerous cycle.\u201D \u2014@POTUS at the #DallasMemorial",
  "id" : 752944701871841280,
  "created_at" : "2016-07-12 19:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752944248937259008",
  "text" : "\"We flood communities with so many guns that it is easier for a teenager to by a Glock than to get his hands on a computer\" \u2014@POTUS",
  "id" : 752944248937259008,
  "created_at" : "2016-07-12 19:14:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752943565265707009",
  "text" : "\u201CWe cannot simply turn away and dismiss those in peaceful protest as troublemakers, or paranoid\" \u2014@POTUS in Dallas",
  "id" : 752943565265707009,
  "created_at" : "2016-07-12 19:11:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DallasMemorial",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752941816027107328",
  "text" : "\u201CI see what\u2019s possible when we recognize that we are all one American family, all deserving of equal treatment\u201D \u2014@POTUS at #DallasMemorial",
  "id" : 752941816027107328,
  "created_at" : "2016-07-12 19:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752941546245197824",
  "text" : "\"The Dallas Police Department has been at the forefront of improving relations between police and the community\" \u2014@POTUS in Dallas",
  "id" : 752941546245197824,
  "created_at" : "2016-07-12 19:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752940349849341952",
  "text" : "\u201CI\u2019m here to say we must reject such despair. I\u2019m here to insist that we are not as divided as we seem.\u201D \u2014@POTUS in Dallas",
  "id" : 752940349849341952,
  "created_at" : "2016-07-12 18:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752940197461929984",
  "text" : "RT @WHLive: \u201CAll of it has left us wounded, and angry, and hurt. It\u2019s as if the deepest fault lines of our democracy have been exposed\" \u2014@P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 125, 131 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752940065915932672",
    "text" : "\u201CAll of it has left us wounded, and angry, and hurt. It\u2019s as if the deepest fault lines of our democracy have been exposed\" \u2014@POTUS",
    "id" : 752940065915932672,
    "created_at" : "2016-07-12 18:57:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 752940197461929984,
  "created_at" : "2016-07-12 18:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752939714945089536",
  "text" : "\u201CAnother community torn apart; more hearts broken; more questions about what caused, and what might prevent, another such tragedy.\u201D \u2014@POTUS",
  "id" : 752939714945089536,
  "created_at" : "2016-07-12 18:56:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/fi41y6GwN9",
      "expanded_url" : "http:\/\/go.wh.gov\/KCqhaP",
      "display_url" : "go.wh.gov\/KCqhaP"
    } ]
  },
  "geo" : { },
  "id_str" : "752939637883150336",
  "text" : "\u201CThese men and this department did their jobs like the professionals they were.\u201D \u2014@POTUS in Dallas: https:\/\/t.co\/fi41y6GwN9",
  "id" : 752939637883150336,
  "created_at" : "2016-07-12 18:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752939037170728960",
  "text" : "\u201CLike police officers across the country, these men and their families shared a commitment to something larger than themselves.\u201D \u2014@POTUS",
  "id" : 752939037170728960,
  "created_at" : "2016-07-12 18:53:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752937759829069825",
  "text" : "\u201CWe are here to honor the memory, and mourn the loss, of five fellow Americans\u2014to grieve with their loved ones\u201D \u2014@POTUS in Dallas",
  "id" : 752937759829069825,
  "created_at" : "2016-07-12 18:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/L31ZZVXEcn",
      "expanded_url" : "http:\/\/go.wh.gov\/KCqhaP",
      "display_url" : "go.wh.gov\/KCqhaP"
    } ]
  },
  "geo" : { },
  "id_str" : "752937133581688832",
  "text" : "RT @WHLive: Happening now: @POTUS delivers remarks to honor the fallen at a memorial service in Dallas \u2192 https:\/\/t.co\/L31ZZVXEcn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/L31ZZVXEcn",
        "expanded_url" : "http:\/\/go.wh.gov\/KCqhaP",
        "display_url" : "go.wh.gov\/KCqhaP"
      } ]
    },
    "geo" : { },
    "id_str" : "752937040182935553",
    "text" : "Happening now: @POTUS delivers remarks to honor the fallen at a memorial service in Dallas \u2192 https:\/\/t.co\/L31ZZVXEcn",
    "id" : 752937040182935553,
    "created_at" : "2016-07-12 18:45:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 752937133581688832,
  "created_at" : "2016-07-12 18:46:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/fi41y6GwN9",
      "expanded_url" : "http:\/\/go.wh.gov\/KCqhaP",
      "display_url" : "go.wh.gov\/KCqhaP"
    } ]
  },
  "geo" : { },
  "id_str" : "752926178789453824",
  "text" : "Watch live: @POTUS joins the people of Dallas in a service to honor the five fallen police officers \u2192 https:\/\/t.co\/fi41y6GwN9",
  "id" : 752926178789453824,
  "created_at" : "2016-07-12 18:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/752907904668151809\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/zFydvAOmPn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLTYGJWYAAJXQW.jpg",
      "id_str" : "752896498644443136",
      "id" : 752896498644443136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLTYGJWYAAJXQW.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zFydvAOmPn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/fi41y6oVoz",
      "expanded_url" : "http:\/\/go.wh.gov\/KCqhaP",
      "display_url" : "go.wh.gov\/KCqhaP"
    } ]
  },
  "geo" : { },
  "id_str" : "752907904668151809",
  "text" : "At 1:40pm ET, @POTUS will speak to families of the fallen and the Dallas community. Watch \u2192 https:\/\/t.co\/fi41y6oVoz https:\/\/t.co\/zFydvAOmPn",
  "id" : 752907904668151809,
  "created_at" : "2016-07-12 16:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/7Ffj0Qf9Pl",
      "expanded_url" : "http:\/\/nyti.ms\/29BpcJr",
      "display_url" : "nyti.ms\/29BpcJr"
    } ]
  },
  "geo" : { },
  "id_str" : "752894549459165186",
  "text" : "RT @Denis44: Every day Congress fails to fund treatment is a missed opportunity to help prevent overdoses  https:\/\/t.co\/7Ffj0Qf9Pl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/7Ffj0Qf9Pl",
        "expanded_url" : "http:\/\/nyti.ms\/29BpcJr",
        "display_url" : "nyti.ms\/29BpcJr"
      } ]
    },
    "geo" : { },
    "id_str" : "752894172835684353",
    "text" : "Every day Congress fails to fund treatment is a missed opportunity to help prevent overdoses  https:\/\/t.co\/7Ffj0Qf9Pl",
    "id" : 752894172835684353,
    "created_at" : "2016-07-12 15:55:33 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 752894549459165186,
  "created_at" : "2016-07-12 15:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/752629402471526400\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/WVfUBmcTBy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnHgTmvXgAAdC0C.jpg",
      "id_str" : "752629240168939520",
      "id" : 752629240168939520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnHgTmvXgAAdC0C.jpg",
      "sizes" : [ {
        "h" : 520,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 517
      } ],
      "display_url" : "pic.twitter.com\/WVfUBmcTBy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ZBlNBFfMln",
      "expanded_url" : "http:\/\/go.wh.gov\/dsq32q",
      "display_url" : "go.wh.gov\/dsq32q"
    } ]
  },
  "geo" : { },
  "id_str" : "752629402471526400",
  "text" : "Today, @POTUS and @VP met with law enforcement leaders ahead of their trip to Dallas: https:\/\/t.co\/ZBlNBFfMln https:\/\/t.co\/WVfUBmcTBy",
  "id" : 752629402471526400,
  "created_at" : "2016-07-11 22:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JAMA",
      "screen_name" : "JAMA_current",
      "indices" : [ 3, 16 ],
      "id_str" : "38489678",
      "id" : 38489678
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/zCKD3gorwU",
      "expanded_url" : "http:\/\/ja.ma\/29tqwuV",
      "display_url" : "ja.ma\/29tqwuV"
    } ]
  },
  "geo" : { },
  "id_str" : "752620300811010049",
  "text" : "RT @JAMA_current: .@POTUS on #ACA: decline in % uninsured from 16% to 9.1% since ACA became law https:\/\/t.co\/zCKD3gorwU https:\/\/t.co\/pNsvVt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JAMA_current\/status\/752612179971629057\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/pNsvVtkMP2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnHQyY8WIAIG00u.jpg",
        "id_str" : "752612176855179266",
        "id" : 752612176855179266,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnHQyY8WIAIG00u.jpg",
        "sizes" : [ {
          "h" : 475,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/pNsvVtkMP2"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 11, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/zCKD3gorwU",
        "expanded_url" : "http:\/\/ja.ma\/29tqwuV",
        "display_url" : "ja.ma\/29tqwuV"
      } ]
    },
    "geo" : { },
    "id_str" : "752612179971629057",
    "text" : ".@POTUS on #ACA: decline in % uninsured from 16% to 9.1% since ACA became law https:\/\/t.co\/zCKD3gorwU https:\/\/t.co\/pNsvVtkMP2",
    "id" : 752612179971629057,
    "created_at" : "2016-07-11 21:15:01 +0000",
    "user" : {
      "name" : "JAMA",
      "screen_name" : "JAMA_current",
      "protected" : false,
      "id_str" : "38489678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000143912285\/b018993d545bc3a951b018f2a1e24fb8_normal.png",
      "id" : 38489678,
      "verified" : false
    }
  },
  "id" : 752620300811010049,
  "created_at" : "2016-07-11 21:47:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/752613795244027906\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RlyWkERSDr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnHR8DtXYAAdBMs.jpg",
      "id_str" : "752613442465521664",
      "id" : 752613442465521664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnHR8DtXYAAdBMs.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1281
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1281
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/RlyWkERSDr"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/1Iz1EKy0Z4",
      "expanded_url" : "http:\/\/go.wh.gov\/SUDg7E",
      "display_url" : "go.wh.gov\/SUDg7E"
    } ]
  },
  "geo" : { },
  "id_str" : "752613795244027906",
  "text" : "\"Health care is not a privilege for a few, but a right for all\" \u2014@POTUS on why #ACAWorks: https:\/\/t.co\/1Iz1EKy0Z4 https:\/\/t.co\/RlyWkERSDr",
  "id" : 752613795244027906,
  "created_at" : "2016-07-11 21:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/CutKLcMaVq",
      "expanded_url" : "http:\/\/snpy.tv\/29thr4X",
      "display_url" : "snpy.tv\/29thr4X"
    } ]
  },
  "geo" : { },
  "id_str" : "752280000573812737",
  "text" : "\"This is an American issue.\"\nWatch @POTUS's remarks in this episode of West Wing Week: https:\/\/t.co\/CutKLcMaVq",
  "id" : 752280000573812737,
  "created_at" : "2016-07-10 23:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 60, 63 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "752263903464132608",
  "text" : "\"We endure.\nWe persevere.\nWe overcome.\nWe stand together.\"\n\u2014@VP: https:\/\/t.co\/StC5AcrNmG",
  "id" : 752263903464132608,
  "created_at" : "2016-07-10 22:11:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 105, 108 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "752248803479003136",
  "text" : "\"While we\u2019re being tested, we can\u2019t be pulled apart. We are America, with bonds that hold us together.\" \u2014@VP: https:\/\/t.co\/StC5AcrNmG",
  "id" : 752248803479003136,
  "created_at" : "2016-07-10 21:11:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 72, 75 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "752233690227322880",
  "text" : "\"Let us use our words carefully. Let us act with unity, not division.\" \u2014@VP on coming together as Americans: https:\/\/t.co\/StC5AcrNmG",
  "id" : 752233690227322880,
  "created_at" : "2016-07-10 20:11:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 56, 59 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "752218599834529792",
  "text" : "\"As Americans, we are wounded by all of these deaths.\" \u2014@VP on Dallas, Baton Rouge, and St. Paul: https:\/\/t.co\/StC5AcrNmG",
  "id" : 752218599834529792,
  "created_at" : "2016-07-10 19:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 68, 71 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dallas Police Dept",
      "screen_name" : "DallasPD",
      "indices" : [ 95, 104 ],
      "id_str" : "28758060",
      "id" : 28758060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "752203506526744576",
  "text" : "\"The Dallas Police Department is one of the finest in the nation.\" \u2014@VP on the officers of the @DallasPD: https:\/\/t.co\/StC5AcrNmG",
  "id" : 752203506526744576,
  "created_at" : "2016-07-10 18:11:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Pa\u00EDs in English",
      "screen_name" : "elpaisinenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "216739115",
      "id" : 216739115
    }, {
      "name" : "EL PA\u00CDS",
      "screen_name" : "el_pais",
      "indices" : [ 117, 125 ],
      "id_str" : "7996082",
      "id" : 7996082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752196854134243328",
  "text" : "RT @elpaisinenglish: Ahead of his first official visit to Spain US President Barack Obama responds to questions from @el_pais https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EL PA\u00CDS",
        "screen_name" : "el_pais",
        "indices" : [ 96, 104 ],
        "id_str" : "7996082",
        "id" : 7996082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/9X8AN3HJjT",
        "expanded_url" : "http:\/\/elpais.com\/elpais\/2016\/07\/09\/inenglish\/1468084544_676871.html?id_externo_rsoc=TW_CC",
        "display_url" : "elpais.com\/elpais\/2016\/07\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751899353170706437",
    "text" : "Ahead of his first official visit to Spain US President Barack Obama responds to questions from @el_pais https:\/\/t.co\/9X8AN3HJjT",
    "id" : 751899353170706437,
    "created_at" : "2016-07-09 22:02:30 +0000",
    "user" : {
      "name" : "El Pa\u00EDs in English",
      "screen_name" : "elpaisinenglish",
      "protected" : false,
      "id_str" : "216739115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517764795227852800\/FQP2CScN_normal.jpeg",
      "id" : 216739115,
      "verified" : true
    }
  },
  "id" : 752196854134243328,
  "created_at" : "2016-07-10 17:44:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752187075672309760",
  "text" : "\"I am absolutely confident that people of goodwill will ultimately overcome the forces that seek to divide and destroy us.\" \u2014@POTUS",
  "id" : 752187075672309760,
  "created_at" : "2016-07-10 17:05:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752186319594483712",
  "text" : "\"Thank you for your service on behalf of a safer America, a safer Spain, and a safer world.\" \u2014@POTUS to service members in Spain",
  "id" : 752186319594483712,
  "created_at" : "2016-07-10 17:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752186004962967552",
  "text" : "\"We\u2019re going to keep standing together to meet the challenges of our time.\" \u2014@POTUS in Spain",
  "id" : 752186004962967552,
  "created_at" : "2016-07-10 17:01:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/752180572345294848\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/et2fUTFd7z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBIOEbW8AEOF2Y.jpg",
      "id_str" : "752180544314732545",
      "id" : 752180544314732545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBIOEbW8AEOF2Y.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/et2fUTFd7z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752182550215426048",
  "text" : "RT @PressSec: .@POTUS visiting with some of America's finest sailors aboard the USS Ross in Rota,Spain. https:\/\/t.co\/et2fUTFd7z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/752180572345294848\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/et2fUTFd7z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnBIOEbW8AEOF2Y.jpg",
        "id_str" : "752180544314732545",
        "id" : 752180544314732545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnBIOEbW8AEOF2Y.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/et2fUTFd7z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752180572345294848",
    "text" : ".@POTUS visiting with some of America's finest sailors aboard the USS Ross in Rota,Spain. https:\/\/t.co\/et2fUTFd7z",
    "id" : 752180572345294848,
    "created_at" : "2016-07-10 16:39:57 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 752182550215426048,
  "created_at" : "2016-07-10 16:47:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/BiNOJckIcy",
      "expanded_url" : "http:\/\/go.wh.gov\/NsEeez",
      "display_url" : "go.wh.gov\/NsEeez"
    } ]
  },
  "geo" : { },
  "id_str" : "752175995482955776",
  "text" : "Tune in at 12:30pm ET to watch @POTUS talk with service members in Spain: https:\/\/t.co\/BiNOJckIcy",
  "id" : 752175995482955776,
  "created_at" : "2016-07-10 16:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 96, 99 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "751913905589395456",
  "text" : "\"Those killed and wounded were protecting the safety of those who were peacefully protesting.\" \u2014@VP on Dallas: https:\/\/t.co\/StC5AcrNmG",
  "id" : 751913905589395456,
  "created_at" : "2016-07-09 23:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 101, 104 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "751898808510930944",
  "text" : "\"When an assassin\u2019s bullet targeted the police force in Dallas, it touched the soul of the nation.\" \u2014@VP: https:\/\/t.co\/StC5AcrNmG",
  "id" : 751898808510930944,
  "created_at" : "2016-07-09 22:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 64, 67 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dallas Police Dept",
      "screen_name" : "DallasPD",
      "indices" : [ 91, 100 ],
      "id_str" : "28758060",
      "id" : 28758060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/StC5AcrNmG",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "751883709163253760",
  "text" : "\"Being a cop wasn\u2019t just what they did. It was who they were.\" \u2014@VP on the officers of the @DallasPD: https:\/\/t.co\/StC5AcrNmG",
  "id" : 751883709163253760,
  "created_at" : "2016-07-09 21:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 10, 13 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/StC5AcJoLg",
      "expanded_url" : "http:\/\/go.wh.gov\/rGvmP3",
      "display_url" : "go.wh.gov\/rGvmP3"
    } ]
  },
  "geo" : { },
  "id_str" : "751877749829144576",
  "text" : "Watch the @VP's weekly address on standing together to stop the violence: https:\/\/t.co\/StC5AcJoLg",
  "id" : 751877749829144576,
  "created_at" : "2016-07-09 20:36:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/udRGEbDA6H",
      "expanded_url" : "http:\/\/snpy.tv\/29pbiHb",
      "display_url" : "snpy.tv\/29pbiHb"
    } ]
  },
  "geo" : { },
  "id_str" : "751834996764270592",
  "text" : "\"If we don't talk about it, we're not going to solve these underlying problems.\" \u2014@POTUS on gun violence: https:\/\/t.co\/udRGEbDA6H",
  "id" : 751834996764270592,
  "created_at" : "2016-07-09 17:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/b3FjoLHvZl",
      "expanded_url" : "http:\/\/snpy.tv\/29K3Uvg",
      "display_url" : "snpy.tv\/29K3Uvg"
    } ]
  },
  "geo" : { },
  "id_str" : "751828305192574976",
  "text" : "\"I firmly believe that America is not as divided as some have suggested.\" \u2014@POTUS: https:\/\/t.co\/b3FjoLHvZl",
  "id" : 751828305192574976,
  "created_at" : "2016-07-09 17:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751819417500184576",
  "text" : "\"Throughout my time in office, one of my top foreign policy priorities has been to strengthen our alliances, especially with NATO.\" \u2014@POTUS",
  "id" : 751819417500184576,
  "created_at" : "2016-07-09 16:44:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NATOsummit",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751818390852005889",
  "text" : "\"NATO is sending a clear message that we will defend every ally.\" \u2014@POTUS #NATOsummit",
  "id" : 751818390852005889,
  "created_at" : "2016-07-09 16:40:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751817851195891712",
  "text" : "\"What will never change: The unwavering commitment of the United States to the security and defense of Europe\" \u2014@POTUS",
  "id" : 751817851195891712,
  "created_at" : "2016-07-09 16:38:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Dallas Police Dept",
      "screen_name" : "DallasPD",
      "indices" : [ 102, 111 ],
      "id_str" : "28758060",
      "id" : 28758060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751815899498352641",
  "text" : "\"The American people are grieving with them and...we stand with them.\" \u2014@POTUS on the officers of the @DallasPD and their families",
  "id" : 751815899498352641,
  "created_at" : "2016-07-09 16:30:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NATOsummit",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/x8txQSZvI3",
      "expanded_url" : "http:\/\/go.wh.gov\/D6gvHd",
      "display_url" : "go.wh.gov\/D6gvHd"
    } ]
  },
  "geo" : { },
  "id_str" : "751813751171584001",
  "text" : "Tune in at 12:25pm ET to watch @POTUS hold a press conference in Warsaw, Poland, after the #NATOsummit: https:\/\/t.co\/x8txQSZvI3",
  "id" : 751813751171584001,
  "created_at" : "2016-07-09 16:22:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Mike Rawlings",
      "screen_name" : "Mike_Rawlings",
      "indices" : [ 27, 41 ],
      "id_str" : "252409940",
      "id" : 252409940
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/751563923459944448\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/NZCGu0JcxS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm4XYAxUEAAOLq9.jpg",
      "id_str" : "751563889108586496",
      "id" : 751563889108586496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm4XYAxUEAAOLq9.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 874
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 874
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 874
      } ],
      "display_url" : "pic.twitter.com\/NZCGu0JcxS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751563923459944448",
  "text" : "At the invitation of Mayor @Mike_Rawlings, @POTUS will travel to Dallas early next week: https:\/\/t.co\/NZCGu0JcxS",
  "id" : 751563923459944448,
  "created_at" : "2016-07-08 23:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/751462993431502848\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/TiE62vk8pP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm27coQUkAAiB7E.jpg",
      "id_str" : "751462813357346816",
      "id" : 751462813357346816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm27coQUkAAiB7E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/TiE62vk8pP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BIJFsuATPk",
      "expanded_url" : "http:\/\/go.wh.gov\/6buoTM",
      "display_url" : "go.wh.gov\/6buoTM"
    } ]
  },
  "geo" : { },
  "id_str" : "751462993431502848",
  "text" : "To honor victims of the attack in Dallas, @POTUS ordered the U.S. flag flown at half-staff: https:\/\/t.co\/BIJFsuATPk https:\/\/t.co\/TiE62vk8pP",
  "id" : 751462993431502848,
  "created_at" : "2016-07-08 17:08:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 37, 50 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/RHALbfG4mi",
      "expanded_url" : "https:\/\/www.justice.gov\/opa\/speech\/attorney-general-loretta-e-lynch-delivers-statement-dallas-shooting",
      "display_url" : "justice.gov\/opa\/speech\/att\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751450399748427776",
  "text" : "RT @TheJusticeDept: Attorney General @LorettaLynch\u2019s Statement on the Shooting in Dallas https:\/\/t.co\/RHALbfG4mi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 17, 30 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/RHALbfG4mi",
        "expanded_url" : "https:\/\/www.justice.gov\/opa\/speech\/attorney-general-loretta-e-lynch-delivers-statement-dallas-shooting",
        "display_url" : "justice.gov\/opa\/speech\/att\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751449010561552384",
    "text" : "Attorney General @LorettaLynch\u2019s Statement on the Shooting in Dallas https:\/\/t.co\/RHALbfG4mi",
    "id" : 751449010561552384,
    "created_at" : "2016-07-08 16:13:00 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 751450399748427776,
  "created_at" : "2016-07-08 16:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 52, 65 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gJS7W44UgC",
      "expanded_url" : "http:\/\/www.justice.gov\/live-stream",
      "display_url" : "justice.gov\/live-stream"
    } ]
  },
  "geo" : { },
  "id_str" : "751436828192886785",
  "text" : "RT @TheJusticeDept: At 11:30am ET, Attorney General @LorettaLynch will make a statement on the shooting in Dallas https:\/\/t.co\/gJS7W44UgC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 32, 45 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/gJS7W44UgC",
        "expanded_url" : "http:\/\/www.justice.gov\/live-stream",
        "display_url" : "justice.gov\/live-stream"
      } ]
    },
    "geo" : { },
    "id_str" : "751435322496606209",
    "text" : "At 11:30am ET, Attorney General @LorettaLynch will make a statement on the shooting in Dallas https:\/\/t.co\/gJS7W44UgC",
    "id" : 751435322496606209,
    "created_at" : "2016-07-08 15:18:36 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 751436828192886785,
  "created_at" : "2016-07-08 15:24:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dallas",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/lqd4OaFQpk",
      "expanded_url" : "http:\/\/snpy.tv\/29FSmZS",
      "display_url" : "snpy.tv\/29FSmZS"
    } ]
  },
  "geo" : { },
  "id_str" : "751417633505816576",
  "text" : "\"We stand united with the people and the police department in Dallas.\" \u2014@POTUS on last night's attack in #Dallas: https:\/\/t.co\/lqd4OaFQpk",
  "id" : 751417633505816576,
  "created_at" : "2016-07-08 14:08:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/lqd4OaofxM",
      "expanded_url" : "http:\/\/snpy.tv\/29FSmZS",
      "display_url" : "snpy.tv\/29FSmZS"
    } ]
  },
  "geo" : { },
  "id_str" : "751408924356702208",
  "text" : "\"There is no possible justification for these kinds of attacks or any violence against law enforcement\"\u2014@POTUS: https:\/\/t.co\/lqd4OaofxM",
  "id" : 751408924356702208,
  "created_at" : "2016-07-08 13:33:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/lqd4OaofxM",
      "expanded_url" : "http:\/\/snpy.tv\/29FSmZS",
      "display_url" : "snpy.tv\/29FSmZS"
    } ]
  },
  "geo" : { },
  "id_str" : "751385615984386049",
  "text" : "Watch @POTUS's statement on last night's attack on law enforcement in Dallas, Texas. https:\/\/t.co\/lqd4OaofxM",
  "id" : 751385615984386049,
  "created_at" : "2016-07-08 12:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/751206926285873152\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/IJE7V4a5xX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmzNrnfVIAABsvf.jpg",
      "id_str" : "751201387082489856",
      "id" : 751201387082489856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmzNrnfVIAABsvf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/IJE7V4a5xX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/h292HStTk9",
      "expanded_url" : "http:\/\/go.wh.gov\/Tqxe43",
      "display_url" : "go.wh.gov\/Tqxe43"
    } ]
  },
  "geo" : { },
  "id_str" : "751206926285873152",
  "text" : "We can do better than this. \nWe are better than this. \nhttps:\/\/t.co\/h292HStTk9 https:\/\/t.co\/IJE7V4a5xX",
  "id" : 751206926285873152,
  "created_at" : "2016-07-08 00:11:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/gawmjdMFWF",
      "expanded_url" : "http:\/\/snpy.tv\/29SZGOe",
      "display_url" : "snpy.tv\/29SZGOe"
    } ]
  },
  "geo" : { },
  "id_str" : "751199057272573952",
  "text" : "\"Change has been too slow. We have to have a greater sense of urgency about this.\" \u2014@POTUS: https:\/\/t.co\/gawmjdMFWF",
  "id" : 751199057272573952,
  "created_at" : "2016-07-07 23:39:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gawmje4gOd",
      "expanded_url" : "http:\/\/snpy.tv\/29SZGOe",
      "display_url" : "snpy.tv\/29SZGOe"
    } ]
  },
  "geo" : { },
  "id_str" : "751196107380633600",
  "text" : "\"I'd just ask folks to step back and think: What if this happened to somebody in your family?\" \u2014@POTUS: https:\/\/t.co\/gawmje4gOd",
  "id" : 751196107380633600,
  "created_at" : "2016-07-07 23:28:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gawmjdMFWF",
      "expanded_url" : "http:\/\/snpy.tv\/29SZGOe",
      "display_url" : "snpy.tv\/29SZGOe"
    } ]
  },
  "geo" : { },
  "id_str" : "751195423881191424",
  "text" : "\"I'd just ask folks to step back and think: What if this happened to somebody in your family?\" \u2014@POTUS: https:\/\/t.co\/gawmjdMFWF",
  "id" : 751195423881191424,
  "created_at" : "2016-07-07 23:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/gawmjdMFWF",
      "expanded_url" : "http:\/\/snpy.tv\/29SZGOe",
      "display_url" : "snpy.tv\/29SZGOe"
    } ]
  },
  "geo" : { },
  "id_str" : "751192402858213376",
  "text" : "\"We can do better than this. We are better than this.\" \u2014@POTUS: https:\/\/t.co\/gawmjdMFWF",
  "id" : 751192402858213376,
  "created_at" : "2016-07-07 23:13:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/h292HScisB",
      "expanded_url" : "http:\/\/go.wh.gov\/Tqxe43",
      "display_url" : "go.wh.gov\/Tqxe43"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/gawmjdMFWF",
      "expanded_url" : "http:\/\/snpy.tv\/29SZGOe",
      "display_url" : "snpy.tv\/29SZGOe"
    } ]
  },
  "geo" : { },
  "id_str" : "751189621917282304",
  "text" : "Watch @POTUS speak on the fatal shootings of Alton Sterling and Philando Castile: https:\/\/t.co\/h292HScisB https:\/\/t.co\/gawmjdMFWF",
  "id" : 751189621917282304,
  "created_at" : "2016-07-07 23:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/h292HStTk9",
      "expanded_url" : "http:\/\/go.wh.gov\/Tqxe43",
      "display_url" : "go.wh.gov\/Tqxe43"
    } ]
  },
  "geo" : { },
  "id_str" : "751184630603100160",
  "text" : "Happening now: @POTUS speaks on the fatal shootings in Louisiana and Minnesota \u2192 https:\/\/t.co\/h292HStTk9",
  "id" : 751184630603100160,
  "created_at" : "2016-07-07 22:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751178317450010624",
  "text" : "RT @VP: More black lives lost. More anger I share with the country. More broken trust we have to restore. We all must do this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751178148834865152",
    "text" : "More black lives lost. More anger I share with the country. More broken trust we have to restore. We all must do this.",
    "id" : 751178148834865152,
    "created_at" : "2016-07-07 22:16:41 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 751178317450010624,
  "created_at" : "2016-07-07 22:17:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/h292HStTk9",
      "expanded_url" : "http:\/\/go.wh.gov\/Tqxe43",
      "display_url" : "go.wh.gov\/Tqxe43"
    } ]
  },
  "geo" : { },
  "id_str" : "751174345485983745",
  "text" : "At 6:35pm ET, @POTUS will speak on the reports of police shootings in Louisiana and Minnesota. Tune in: https:\/\/t.co\/h292HStTk9",
  "id" : 751174345485983745,
  "created_at" : "2016-07-07 22:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/751116804974489600\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/rVj40rHRKE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmyAjtGXEAEBZck.jpg",
      "id_str" : "751116588754079745",
      "id" : 751116588754079745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmyAjtGXEAEBZck.jpg",
      "sizes" : [ {
        "h" : 695,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 433
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 443
      } ],
      "display_url" : "pic.twitter.com\/rVj40rHRKE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/K313srpinP",
      "expanded_url" : "http:\/\/go.wh.gov\/FwkbMx",
      "display_url" : "go.wh.gov\/FwkbMx"
    } ]
  },
  "geo" : { },
  "id_str" : "751116804974489600",
  "text" : "Read @POTUS\u2019s statement on the fatal shootings of Alton Sterling and Philando Castile: https:\/\/t.co\/K313srpinP https:\/\/t.co\/rVj40rHRKE",
  "id" : 751116804974489600,
  "created_at" : "2016-07-07 18:12:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "indices" : [ 3, 16 ],
      "id_str" : "44873497",
      "id" : 44873497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/4yOYIs0AYp",
      "expanded_url" : "https:\/\/medium.com\/@JohnKingAtED\/priorities-check-education-vs-incarceration-73ef44d41f30#.165",
      "display_url" : "medium.com\/@JohnKingAtED\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751093054191333376",
  "text" : "RT @JohnKingatED: We know that education works. We know that it can and will save lives.\nhttps:\/\/t.co\/4yOYIs0AYp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/4yOYIs0AYp",
        "expanded_url" : "https:\/\/medium.com\/@JohnKingAtED\/priorities-check-education-vs-incarceration-73ef44d41f30#.165",
        "display_url" : "medium.com\/@JohnKingAtED\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751070917195886593",
    "text" : "We know that education works. We know that it can and will save lives.\nhttps:\/\/t.co\/4yOYIs0AYp",
    "id" : 751070917195886593,
    "created_at" : "2016-07-07 15:10:35 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 751093054191333376,
  "created_at" : "2016-07-07 16:38:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 3, 17 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751076067344089088",
  "text" : "RT @SecretaryFoxx: Today, we take another important step toward delivering on President Obama\u2019s promise to reengage #Cuba https:\/\/t.co\/qVmG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/qVmGTzURBo",
        "expanded_url" : "http:\/\/bit.ly\/29Ru8rO",
        "display_url" : "bit.ly\/29Ru8rO"
      } ]
    },
    "geo" : { },
    "id_str" : "751055226170404864",
    "text" : "Today, we take another important step toward delivering on President Obama\u2019s promise to reengage #Cuba https:\/\/t.co\/qVmGTzURBo",
    "id" : 751055226170404864,
    "created_at" : "2016-07-07 14:08:14 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 751076067344089088,
  "created_at" : "2016-07-07 15:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/751074170876731392\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ROYoVPW1tB",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmxZy7nUMAAaXE4.jpg",
      "id_str" : "751073969394954240",
      "id" : 751073969394954240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmxZy7nUMAAaXE4.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ROYoVPW1tB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/pE27XPjvGc",
      "expanded_url" : "http:\/\/go.wh.gov\/x4i2kL",
      "display_url" : "go.wh.gov\/x4i2kL"
    } ]
  },
  "geo" : { },
  "id_str" : "751074170876731392",
  "text" : "BREAKING: \n20 daily flights to Havana, Cuba \nfrom 10 U.S. cities\nby 8 U.S. airlines:   \nhttps:\/\/t.co\/pE27XPjvGc https:\/\/t.co\/ROYoVPW1tB",
  "id" : 751074170876731392,
  "created_at" : "2016-07-07 15:23:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "indices" : [ 3, 15 ],
      "id_str" : "95431448",
      "id" : 95431448
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Boston Globe Opinion",
      "screen_name" : "GlobeOpinion",
      "indices" : [ 28, 41 ],
      "id_str" : "324962560",
      "id" : 324962560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/9VKQ6vDobL",
      "expanded_url" : "http:\/\/bos.gl\/90B4tA6",
      "display_url" : "bos.gl\/90B4tA6"
    } ]
  },
  "geo" : { },
  "id_str" : "751036233053184001",
  "text" : "RT @BostonGlobe: .@POTUS in @globeOpinion: Precision medicine can help us learn more about various diseases https:\/\/t.co\/9VKQ6vDobL https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Boston Globe Opinion",
        "screen_name" : "GlobeOpinion",
        "indices" : [ 11, 24 ],
        "id_str" : "324962560",
        "id" : 324962560
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BostonGlobe\/status\/751004684496896000\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/1bnRBCvku7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmwax2MWIAAslGB.jpg",
        "id_str" : "751004681527238656",
        "id" : 751004681527238656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmwax2MWIAAslGB.jpg",
        "sizes" : [ {
          "h" : 646,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 646,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 646,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1bnRBCvku7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/9VKQ6vDobL",
        "expanded_url" : "http:\/\/bos.gl\/90B4tA6",
        "display_url" : "bos.gl\/90B4tA6"
      } ]
    },
    "geo" : { },
    "id_str" : "751004684496896000",
    "text" : ".@POTUS in @globeOpinion: Precision medicine can help us learn more about various diseases https:\/\/t.co\/9VKQ6vDobL https:\/\/t.co\/1bnRBCvku7",
    "id" : 751004684496896000,
    "created_at" : "2016-07-07 10:47:24 +0000",
    "user" : {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "protected" : false,
      "id_str" : "95431448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586570157734019072\/Qxz1LIIM_normal.png",
      "id" : 95431448,
      "verified" : true
    }
  },
  "id" : 751036233053184001,
  "created_at" : "2016-07-07 12:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/d9sNItZFth",
      "expanded_url" : "http:\/\/bit.ly\/29o6J2G",
      "display_url" : "bit.ly\/29o6J2G"
    } ]
  },
  "geo" : { },
  "id_str" : "750863298493636609",
  "text" : "Worth a read: @POTUS on the new steps we're announcing to bring doctors and data together like never before \u2192 https:\/\/t.co\/d9sNItZFth",
  "id" : 750863298493636609,
  "created_at" : "2016-07-07 01:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Pt8akqrjfh",
      "expanded_url" : "http:\/\/go.wh.gov\/wZabYz",
      "display_url" : "go.wh.gov\/wZabYz"
    } ]
  },
  "geo" : { },
  "id_str" : "750815436267220992",
  "text" : "\u201CWe are not just Muslims, or just Americans, but we are both. We are Muslim-Americans.\u201D Read the letters to @POTUS: https:\/\/t.co\/Pt8akqrjfh",
  "id" : 750815436267220992,
  "created_at" : "2016-07-06 22:15:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/750802244463919104\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/1mMd3XwN4Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmtimvtXgAABk1F.jpg",
      "id_str" : "750802180668620800",
      "id" : 750802180668620800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmtimvtXgAABk1F.jpg",
      "sizes" : [ {
        "h" : 1271,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1271,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1mMd3XwN4Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Pt8akqrjfh",
      "expanded_url" : "http:\/\/go.wh.gov\/wZabYz",
      "display_url" : "go.wh.gov\/wZabYz"
    } ]
  },
  "geo" : { },
  "id_str" : "750802244463919104",
  "text" : "Eid Mubarak! Read some of the letters @POTUS has recently received from Muslim Americans: https:\/\/t.co\/Pt8akqrjfh https:\/\/t.co\/1mMd3XwN4Y",
  "id" : 750802244463919104,
  "created_at" : "2016-07-06 21:22:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Feed the Future",
      "screen_name" : "FeedtheFuture",
      "indices" : [ 99, 113 ],
      "id_str" : "441938188",
      "id" : 441938188
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750792905162448896\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/nljXiIj1ww",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmtaKSGXEAAKoLI.jpg",
      "id_str" : "750792895591026688",
      "id" : 750792895591026688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmtaKSGXEAAKoLI.jpg",
      "sizes" : [ {
        "h" : 407,
        "resize" : "fit",
        "w" : 1027
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 1027
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 1027
      } ],
      "display_url" : "pic.twitter.com\/nljXiIj1ww"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750792905162448896",
  "text" : "\"We can end global poverty and hunger within our lifetimes.\" \u2014@POTUS on Congress's vote to support @FeedtheFuture. https:\/\/t.co\/nljXiIj1ww",
  "id" : 750792905162448896,
  "created_at" : "2016-07-06 20:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750787248161853441",
  "text" : "RT @PressSec: The Republican opioid bill doesn't provide funding states desperately need to fight this tragic epidemic. https:\/\/t.co\/cG5na8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/cG5na8NnHm",
        "expanded_url" : "http:\/\/snpy.tv\/29xdj9P",
        "display_url" : "snpy.tv\/29xdj9P"
      } ]
    },
    "geo" : { },
    "id_str" : "750787148677156864",
    "text" : "The Republican opioid bill doesn't provide funding states desperately need to fight this tragic epidemic. https:\/\/t.co\/cG5na8NnHm",
    "id" : 750787148677156864,
    "created_at" : "2016-07-06 20:22:59 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 750787248161853441,
  "created_at" : "2016-07-06 20:23:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750785898652966912\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/C5wIiG5XD5",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmtPHnFVUAA0LrM.jpg",
      "id_str" : "750780755056349184",
      "id" : 750780755056349184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmtPHnFVUAA0LrM.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/C5wIiG5XD5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/FFRiySWHWb",
      "expanded_url" : "http:\/\/go.wh.gov\/ECXKsM",
      "display_url" : "go.wh.gov\/ECXKsM"
    } ]
  },
  "geo" : { },
  "id_str" : "750785898652966912",
  "text" : "FACT: More Americans die every year from drug overdoses than they do in traffic accidents. https:\/\/t.co\/FFRiySWHWb https:\/\/t.co\/C5wIiG5XD5",
  "id" : 750785898652966912,
  "created_at" : "2016-07-06 20:18:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750776731179618305\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/S9GvVw16bt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmtLXQ_VYAAlYRA.jpg",
      "id_str" : "750776625957003264",
      "id" : 750776625957003264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmtLXQ_VYAAlYRA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/S9GvVw16bt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/FFRiyTejkL",
      "expanded_url" : "http:\/\/go.wh.gov\/ECXKsM",
      "display_url" : "go.wh.gov\/ECXKsM"
    } ]
  },
  "geo" : { },
  "id_str" : "750776731179618305",
  "text" : "Today @POTUS took additional actions to expand access to opioid treatment\u2014here's how: https:\/\/t.co\/FFRiyTejkL https:\/\/t.co\/S9GvVw16bt",
  "id" : 750776731179618305,
  "created_at" : "2016-07-06 19:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opioid",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750742878725562368",
  "text" : "RT @SecBurwell: Today, we\u2019re taking a number of steps forward in our effort to combat the #opioid epidemic &amp; ultimately save lives. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opioid",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/O8zyHSFLUV",
        "expanded_url" : "http:\/\/www.hhs.gov\/about\/news\/2016\/07\/06\/hhs-announces-new-actions-combat-opioid-epidemic.html",
        "display_url" : "hhs.gov\/about\/news\/201\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "750701425135583232",
    "geo" : { },
    "id_str" : "750701676504416257",
    "in_reply_to_user_id" : 2458567464,
    "text" : "Today, we\u2019re taking a number of steps forward in our effort to combat the #opioid epidemic &amp; ultimately save lives. https:\/\/t.co\/O8zyHSFLUV",
    "id" : 750701676504416257,
    "in_reply_to_status_id" : 750701425135583232,
    "created_at" : "2016-07-06 14:43:21 +0000",
    "in_reply_to_screen_name" : "SecBurwell",
    "in_reply_to_user_id_str" : "2458567464",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 750742878725562368,
  "created_at" : "2016-07-06 17:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/iKNR8TVh0O",
      "expanded_url" : "http:\/\/snpy.tv\/29hVxSe",
      "display_url" : "snpy.tv\/29hVxSe"
    } ]
  },
  "geo" : { },
  "id_str" : "750713989756121090",
  "text" : "\"I will not allow Afghanistan to be used as safe haven for terrorists to attack our nation again.\" \u2014@POTUS: https:\/\/t.co\/iKNR8TVh0O",
  "id" : 750713989756121090,
  "created_at" : "2016-07-06 15:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/iKNR8TVh0O",
      "expanded_url" : "http:\/\/snpy.tv\/29hVxSe",
      "display_url" : "snpy.tv\/29hVxSe"
    } ]
  },
  "geo" : { },
  "id_str" : "750707639248572416",
  "text" : ".@POTUS just gave an update on the continued U.S. presence in Afghanistan\u2014here's what he had to say: https:\/\/t.co\/iKNR8TVh0O",
  "id" : 750707639248572416,
  "created_at" : "2016-07-06 15:07:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750706473156612097",
  "text" : "RT @PressSec: \"I will not allow Afghanistan to be used as safe haven for terrorists\" \u2014@POTUS on keeping 8400 troops in Afghanistan https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 72, 78 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/K8wakBZrao",
        "expanded_url" : "http:\/\/snpy.tv\/29hVxSe",
        "display_url" : "snpy.tv\/29hVxSe"
      } ]
    },
    "geo" : { },
    "id_str" : "750706022767947776",
    "text" : "\"I will not allow Afghanistan to be used as safe haven for terrorists\" \u2014@POTUS on keeping 8400 troops in Afghanistan https:\/\/t.co\/K8wakBZrao",
    "id" : 750706022767947776,
    "created_at" : "2016-07-06 15:00:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 750706473156612097,
  "created_at" : "2016-07-06 15:02:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/729kBYzSxO",
      "expanded_url" : "http:\/\/snpy.tv\/29nV6HV",
      "display_url" : "snpy.tv\/29nV6HV"
    } ]
  },
  "geo" : { },
  "id_str" : "750702759146500096",
  "text" : "\"Compared to the 100,000 troops we once had there, today fewer than 10,000 remain\" \u2014@POTUS on mission in Afghanistan https:\/\/t.co\/729kBYzSxO",
  "id" : 750702759146500096,
  "created_at" : "2016-07-06 14:47:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750700803854200832",
  "text" : "\u201CLet\u2019s never forget the progress their service has made possible\" \u2014@POTUS on the 2,200 Americans who gave their lives in Afghanistan",
  "id" : 750700803854200832,
  "created_at" : "2016-07-06 14:39:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/750699396082180096\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/F5MmsvlOjd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmsFEqVVUAAu60g.jpg",
      "id_str" : "750699340528701440",
      "id" : 750699340528701440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmsFEqVVUAAu60g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/F5MmsvlOjd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750699396082180096",
  "text" : "\u201CThe United States will maintain approximately 8,400 troops in Afghanistan into next year\u201D \u2014@POTUS https:\/\/t.co\/F5MmsvlOjd",
  "id" : 750699396082180096,
  "created_at" : "2016-07-06 14:34:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750698914509041664",
  "text" : "\u201CI\u2019ve made it clear that I will not allow Afghanistan to be used as safe haven for terrorists to attack our nation again.\u201D \u2014@POTUS",
  "id" : 750698914509041664,
  "created_at" : "2016-07-06 14:32:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750698642671935488",
  "text" : "RT @NSC44: \u201COur forces are now focused on two narrow missions: training and advising Afghan forces and supporting counterterrorist operatio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 132, 138 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750698526623928323",
    "text" : "\u201COur forces are now focused on two narrow missions: training and advising Afghan forces and supporting counterterrorist operations\u201D-@POTUS.",
    "id" : 750698526623928323,
    "created_at" : "2016-07-06 14:30:50 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 750698642671935488,
  "created_at" : "2016-07-06 14:31:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750698509800599552",
  "text" : "RT @WHLive: \u201CIn Afghanistan, we are joined by a coalition of 41 allies and partners that contribute more than 6,000 troops of their own.\u201D \u2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 127, 133 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750698465890492416",
    "text" : "\u201CIn Afghanistan, we are joined by a coalition of 41 allies and partners that contribute more than 6,000 troops of their own.\u201D \u2014@POTUS",
    "id" : 750698465890492416,
    "created_at" : "2016-07-06 14:30:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 750698509800599552,
  "created_at" : "2016-07-06 14:30:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750698403449876482",
  "text" : "\u201COver the past year and a half, 38 Americans...have given their lives in Afghanistan for our security. We honor their sacrifice.\u201D \u2014@POTUS",
  "id" : 750698403449876482,
  "created_at" : "2016-07-06 14:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750698358403059713",
  "text" : "\u201CEven as we remain relentless against those who threaten us, we are no longer engaged in a major ground war in Afghanistan.\u201D \u2014@POTUS",
  "id" : 750698358403059713,
  "created_at" : "2016-07-06 14:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750698303000641536\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1vXnx4LB0V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmsEGC4XgAAMjvr.jpg",
      "id_str" : "750698264786337792",
      "id" : 750698264786337792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmsEGC4XgAAMjvr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1vXnx4LB0V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750698303000641536",
  "text" : "\u201CCompared to the 100,000 troops we once had there, today, fewer than 10,000 remain.\u201D \u2014@POTUS https:\/\/t.co\/1vXnx4LB0V",
  "id" : 750698303000641536,
  "created_at" : "2016-07-06 14:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/GGfqprVK1s",
      "expanded_url" : "http:\/\/go.wh.gov\/X4FQ1T",
      "display_url" : "go.wh.gov\/X4FQ1T"
    } ]
  },
  "geo" : { },
  "id_str" : "750697803089735684",
  "text" : "RT @WHLive: Happening now: @POTUS provides an update on our mission in Afghanistan \u2192 https:\/\/t.co\/GGfqprVK1s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/GGfqprVK1s",
        "expanded_url" : "http:\/\/go.wh.gov\/X4FQ1T",
        "display_url" : "go.wh.gov\/X4FQ1T"
      } ]
    },
    "geo" : { },
    "id_str" : "750697720747220992",
    "text" : "Happening now: @POTUS provides an update on our mission in Afghanistan \u2192 https:\/\/t.co\/GGfqprVK1s",
    "id" : 750697720747220992,
    "created_at" : "2016-07-06 14:27:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 750697803089735684,
  "created_at" : "2016-07-06 14:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Ysn614kW2H",
      "expanded_url" : "http:\/\/go.wh.gov\/X4FQ1T",
      "display_url" : "go.wh.gov\/X4FQ1T"
    } ]
  },
  "geo" : { },
  "id_str" : "750693102097010688",
  "text" : "At 10:25am ET, @POTUS will provide an update on our mission in Afghanistan. Tune in \u2192 https:\/\/t.co\/Ysn614kW2H",
  "id" : 750693102097010688,
  "created_at" : "2016-07-06 14:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750691199556677632\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/0dDumpRdrQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmr9exFWcAAkTBF.jpg",
      "id_str" : "750690992924291072",
      "id" : 750690992924291072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmr9exFWcAAkTBF.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0dDumpRdrQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/u9RUyoFPsi",
      "expanded_url" : "http:\/\/go.wh.gov\/jdM8MM",
      "display_url" : "go.wh.gov\/jdM8MM"
    } ]
  },
  "geo" : { },
  "id_str" : "750691199556677632",
  "text" : "\u201CFrom our family to yours, Eid Mubarak!\u201D \u2014@POTUS marking the occasion of Eid al-Fitr: https:\/\/t.co\/u9RUyoFPsi https:\/\/t.co\/0dDumpRdrQ",
  "id" : 750691199556677632,
  "created_at" : "2016-07-06 14:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 22, 25 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Haider Al-Abadi",
      "screen_name" : "HaiderAlAbadi",
      "indices" : [ 76, 90 ],
      "id_str" : "80817491",
      "id" : 80817491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/mZpZBxowUN",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/05\/readout-vice-president-bidens-call-prime-minister-haider-al-abadi-iraq",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750465481140609025",
  "text" : "RT @NSC44: Readout of @VP Biden\u2019s Call with Prime Minister Haider Al-Abadi (@HaiderAlAbadi) of Iraq: https:\/\/t.co\/mZpZBxowUN https:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 11, 14 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Haider Al-Abadi",
        "screen_name" : "HaiderAlAbadi",
        "indices" : [ 65, 79 ],
        "id_str" : "80817491",
        "id" : 80817491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/750460764847083520\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/j2mG6jIvLF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmosE4CUcAE_o2J.jpg",
        "id_str" : "750460750183821313",
        "id" : 750460750183821313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmosE4CUcAE_o2J.jpg",
        "sizes" : [ {
          "h" : 321,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/j2mG6jIvLF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/mZpZBxowUN",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/07\/05\/readout-vice-president-bidens-call-prime-minister-haider-al-abadi-iraq",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750460764847083520",
    "text" : "Readout of @VP Biden\u2019s Call with Prime Minister Haider Al-Abadi (@HaiderAlAbadi) of Iraq: https:\/\/t.co\/mZpZBxowUN https:\/\/t.co\/j2mG6jIvLF",
    "id" : 750460764847083520,
    "created_at" : "2016-07-05 22:46:03 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 750465481140609025,
  "created_at" : "2016-07-05 23:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750458538691010560",
  "text" : "RT @Denis44: House &amp; Senate Democrats are taking a stand 2 make sure we have the resources we need to combat the opioid epidemic: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/ZenDj1Ms63",
        "expanded_url" : "https:\/\/www.leahy.senate.gov\/imo\/media\/doc\/Upton%20Opioid%20Conf%20Committee%20Letter%20-%20Final%202016%2007%2005.pdf",
        "display_url" : "leahy.senate.gov\/imo\/media\/doc\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750456760247283712",
    "text" : "House &amp; Senate Democrats are taking a stand 2 make sure we have the resources we need to combat the opioid epidemic: https:\/\/t.co\/ZenDj1Ms63",
    "id" : 750456760247283712,
    "created_at" : "2016-07-05 22:30:09 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 750458538691010560,
  "created_at" : "2016-07-05 22:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA's Juno Mission",
      "screen_name" : "NASAJuno",
      "indices" : [ 3, 12 ],
      "id_str" : "19789439",
      "id" : 19789439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750447742816747532",
  "text" : "RT @NASAJuno: Great to be here, Mr President. Can't wait to peer into Jupiter + learn the secret recipe for planets. Science soon! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Qgo9SRFUOD",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/750379001546416128",
        "display_url" : "twitter.com\/POTUS\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750438072802635776",
    "text" : "Great to be here, Mr President. Can't wait to peer into Jupiter + learn the secret recipe for planets. Science soon! https:\/\/t.co\/Qgo9SRFUOD",
    "id" : 750438072802635776,
    "created_at" : "2016-07-05 21:15:53 +0000",
    "user" : {
      "name" : "NASA's Juno Mission",
      "screen_name" : "NASAJuno",
      "protected" : false,
      "id_str" : "19789439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1277417903\/JunoProfilePic_normal.jpg",
      "id" : 19789439,
      "verified" : true
    }
  },
  "id" : 750447742816747532,
  "created_at" : "2016-07-05 21:54:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 19, 25 ],
      "id_str" : "15460572",
      "id" : 15460572
    }, {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 35, 48 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/rgKVvTgcCG",
      "expanded_url" : "http:\/\/go.wh.gov\/bUwp8f",
      "display_url" : "go.wh.gov\/bUwp8f"
    } ]
  },
  "geo" : { },
  "id_str" : "750416381724594177",
  "text" : "Tune in now: Watch @ONDCP Director @Botticelli44 in a live Q&amp;A on the opioid epidemic: https:\/\/t.co\/rgKVvTgcCG",
  "id" : 750416381724594177,
  "created_at" : "2016-07-05 19:49:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 26, 35 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 50, 56 ],
      "id_str" : "15460572",
      "id" : 15460572
    }, {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 59, 72 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750403559024365568",
  "text" : "RT @WHLive: Watch live on @Facebook at 3:45pm ET: @ONDCP's @Botticelli44 discusses how we\u2019re addressing the opioid epidemic \u2192 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 14, 23 ],
        "id_str" : "2425151",
        "id" : 2425151
      }, {
        "name" : "U.S. Drug Policy",
        "screen_name" : "ONDCP",
        "indices" : [ 38, 44 ],
        "id_str" : "15460572",
        "id" : 15460572
      }, {
        "name" : "Michael Botticelli",
        "screen_name" : "Botticelli44",
        "indices" : [ 47, 60 ],
        "id_str" : "2382297056",
        "id" : 2382297056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/U7SUPS3sq3",
        "expanded_url" : "http:\/\/go.wh.gov\/bUwp8f",
        "display_url" : "go.wh.gov\/bUwp8f"
      } ]
    },
    "geo" : { },
    "id_str" : "750403492389457920",
    "text" : "Watch live on @Facebook at 3:45pm ET: @ONDCP's @Botticelli44 discusses how we\u2019re addressing the opioid epidemic \u2192 https:\/\/t.co\/U7SUPS3sq3",
    "id" : 750403492389457920,
    "created_at" : "2016-07-05 18:58:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 750403559024365568,
  "created_at" : "2016-07-05 18:58:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750380947527176192",
  "text" : "RT @POTUS: Incredible! After a 5-year journey, we're up close and personal with our solar system's largest planet. Welcome to Jupiter, @NAS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA's Juno Mission",
        "screen_name" : "NASAJuno",
        "indices" : [ 124, 133 ],
        "id_str" : "19789439",
        "id" : 19789439
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750379001546416128",
    "text" : "Incredible! After a 5-year journey, we're up close and personal with our solar system's largest planet. Welcome to Jupiter, @NASAJuno!",
    "id" : 750379001546416128,
    "created_at" : "2016-07-05 17:21:09 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 750380947527176192,
  "created_at" : "2016-07-05 17:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 15, 23 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750380009647329280\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/8k1LNLQSVN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmnioNVWcAAEAE0.jpg",
      "id_str" : "750379993335754752",
      "id" : 750379993335754752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmnioNVWcAAEAE0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8k1LNLQSVN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/qtXW32fmiT",
      "expanded_url" : "http:\/\/go.wh.gov\/mKsq6t",
      "display_url" : "go.wh.gov\/mKsq6t"
    } ]
  },
  "geo" : { },
  "id_str" : "750380009647329280",
  "text" : "Happening now: @Denis44 hosts a conversation on robots and automation \u2192 https:\/\/t.co\/qtXW32fmiT https:\/\/t.co\/8k1LNLQSVN",
  "id" : 750380009647329280,
  "created_at" : "2016-07-05 17:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 1, 6 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750370693162741762\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/S0aHQ98Y2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmnXdb1XgAEi740.jpg",
      "id_str" : "750367713621671937",
      "id" : 750367713621671937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmnXdb1XgAEi740.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/S0aHQ98Y2i"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/sHXjMLcHx1",
      "expanded_url" : "http:\/\/go.wh.gov\/2LW5P5",
      "display_url" : "go.wh.gov\/2LW5P5"
    } ]
  },
  "geo" : { },
  "id_str" : "750370693162741762",
  "text" : ".@USDS just made it easier for veterans to sign up for health care. Here's how: https:\/\/t.co\/sHXjMLcHx1 https:\/\/t.co\/S0aHQ98Y2i",
  "id" : 750370693162741762,
  "created_at" : "2016-07-05 16:48:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750363981907369985\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/lbHe8mqad9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmnS6LdXEAA6e-W.jpg",
      "id_str" : "750362709884080128",
      "id" : 750362709884080128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmnS6LdXEAA6e-W.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/lbHe8mqad9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/onkf04zwd9",
      "expanded_url" : "http:\/\/go.wh.gov\/zuawCC",
      "display_url" : "go.wh.gov\/zuawCC"
    } ]
  },
  "geo" : { },
  "id_str" : "750363981907369985",
  "text" : ".@POTUS on the passing of his mentor and friend, Ab Mikva: https:\/\/t.co\/onkf04zwd9 https:\/\/t.co\/lbHe8mqad9",
  "id" : 750363981907369985,
  "created_at" : "2016-07-05 16:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/qtXW31XLrl",
      "expanded_url" : "http:\/\/go.wh.gov\/mKsq6t",
      "display_url" : "go.wh.gov\/mKsq6t"
    }, {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/FsBfYHqAp1",
      "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/748619760590417920",
      "display_url" : "twitter.com\/Denis44\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750344574908989440",
  "text" : "Tune in today at 1:15pm ET for a conversation on automation \u2192 https:\/\/t.co\/qtXW31XLrl https:\/\/t.co\/FsBfYHqAp1",
  "id" : 750344574908989440,
  "created_at" : "2016-07-05 15:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 10, 16 ]
    }, {
      "text" : "Juno",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/2uqevTkJj4",
      "expanded_url" : "http:\/\/go.nasa.gov\/29q7t8u",
      "display_url" : "go.nasa.gov\/29q7t8u"
    } ]
  },
  "geo" : { },
  "id_str" : "750321576382521344",
  "text" : "RT @NASA: #ICYMI, our #Juno spacecraft is in Jupiter\u2019s orbit! Confirmation was received at 11:53pm ET: https:\/\/t.co\/2uqevTkJj4 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/750206443123597312\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/lUi1D5hlHH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmlEyFPXEAEJq1f.jpg",
        "id_str" : "750206440124649473",
        "id" : 750206440124649473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmlEyFPXEAEJq1f.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lUi1D5hlHH"
      } ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "Juno",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/2uqevTkJj4",
        "expanded_url" : "http:\/\/go.nasa.gov\/29q7t8u",
        "display_url" : "go.nasa.gov\/29q7t8u"
      } ]
    },
    "geo" : { },
    "id_str" : "750206443123597312",
    "text" : "#ICYMI, our #Juno spacecraft is in Jupiter\u2019s orbit! Confirmation was received at 11:53pm ET: https:\/\/t.co\/2uqevTkJj4 https:\/\/t.co\/lUi1D5hlHH",
    "id" : 750206443123597312,
    "created_at" : "2016-07-05 05:55:28 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 750321576382521344,
  "created_at" : "2016-07-05 13:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 36, 43 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FourthOfJuly",
      "indices" : [ 6, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/q0L5Hs28gI",
      "expanded_url" : "http:\/\/snpy.tv\/29ughZt",
      "display_url" : "snpy.tv\/29ughZt"
    } ]
  },
  "geo" : { },
  "id_str" : "750125557707190272",
  "text" : "Happy #FourthOfJuly from @POTUS and @FLOTUS! https:\/\/t.co\/q0L5Hs28gI",
  "id" : 750125557707190272,
  "created_at" : "2016-07-05 00:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendrick Lamar",
      "screen_name" : "kendricklamar",
      "indices" : [ 16, 30 ],
      "id_str" : "23561980",
      "id" : 23561980
    }, {
      "name" : "Janelle Mon\u00E1e, Cindi",
      "screen_name" : "JanelleMonae",
      "indices" : [ 35, 48 ],
      "id_str" : "12266442",
      "id" : 12266442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FourthOfJuly",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/XLmIMn7Hhp",
      "expanded_url" : "http:\/\/go.wh.gov\/TLMQBV",
      "display_url" : "go.wh.gov\/TLMQBV"
    } ]
  },
  "geo" : { },
  "id_str" : "750099203074854912",
  "text" : "Live now: Watch @KendrickLamar and @JanelleMonae perform at the White House for a #FourthOfJuly celebration: https:\/\/t.co\/XLmIMn7Hhp",
  "id" : 750099203074854912,
  "created_at" : "2016-07-04 22:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendrick Lamar",
      "screen_name" : "kendricklamar",
      "indices" : [ 41, 55 ],
      "id_str" : "23561980",
      "id" : 23561980
    }, {
      "name" : "Janelle Mon\u00E1e, Cindi",
      "screen_name" : "JanelleMonae",
      "indices" : [ 60, 73 ],
      "id_str" : "12266442",
      "id" : 12266442
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/750086734852026368\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Eh81o4augS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmjXfn7WcAAJGtF.jpg",
      "id_str" : "750086276251021312",
      "id" : 750086276251021312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmjXfn7WcAAJGtF.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Eh81o4augS"
    } ],
    "hashtags" : [ {
      "text" : "HappyFourth",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/XLmIMmQ6pR",
      "expanded_url" : "http:\/\/go.wh.gov\/TLMQBV",
      "display_url" : "go.wh.gov\/TLMQBV"
    } ]
  },
  "geo" : { },
  "id_str" : "750086734852026368",
  "text" : "Live at 6:45pm ET: Watch performances by @KendrickLamar and @JanelleMonae \u2192\nhttps:\/\/t.co\/XLmIMmQ6pR #HappyFourth https:\/\/t.co\/Eh81o4augS",
  "id" : 750086734852026368,
  "created_at" : "2016-07-04 21:59:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "750041640379699200",
  "text" : "\"To all our brave men and women in uniform\u2014you represent the best of who we are as a nation\" \u2014@POTUS: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 750041640379699200,
  "created_at" : "2016-07-04 19:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/i3BJMLxs07",
      "expanded_url" : "http:\/\/JoiningForces.gov",
      "display_url" : "JoiningForces.gov"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749996423823839232",
  "text" : "\"This holiday weekend, take a look at https:\/\/t.co\/i3BJMLxs07 to find out how you can serve the troops\" \u2014@POTUS: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749996423823839232,
  "created_at" : "2016-07-04 16:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749971283543142400",
  "text" : "RT @POTUS: Happy Fourth of July, everybody! And to our brave men and women in uniform: On this day and every day, we thank you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749966042135293952",
    "text" : "Happy Fourth of July, everybody! And to our brave men and women in uniform: On this day and every day, we thank you.",
    "id" : 749966042135293952,
    "created_at" : "2016-07-04 14:00:12 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 749971283543142400,
  "created_at" : "2016-07-04 14:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749701794343718913",
  "text" : "\"That\u2019s what this is all about\u2014serving our men and women in uniform as well as they have served us.\" \u2014@POTUS: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749701794343718913,
  "created_at" : "2016-07-03 20:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FourthOfJulyWeekend",
      "indices" : [ 19, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749677496736575488",
  "text" : "RT @DrBiden: Happy #FourthOfJulyWeekend! Thank you to all those who sacrifice so much for the freedoms we enjoy every day. \u2014Jill https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/749653932813717504\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/R4EsxGwy7f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmdORPUWEAAsz_h.jpg",
        "id_str" : "749653921057083392",
        "id" : 749653921057083392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmdORPUWEAAsz_h.jpg",
        "sizes" : [ {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/R4EsxGwy7f"
      } ],
      "hashtags" : [ {
        "text" : "FourthOfJulyWeekend",
        "indices" : [ 6, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749653932813717504",
    "text" : "Happy #FourthOfJulyWeekend! Thank you to all those who sacrifice so much for the freedoms we enjoy every day. \u2014Jill https:\/\/t.co\/R4EsxGwy7f",
    "id" : 749653932813717504,
    "created_at" : "2016-07-03 17:20:00 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 749677496736575488,
  "created_at" : "2016-07-03 18:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "indices" : [ 3, 8 ],
      "id_str" : "214112621",
      "id" : 214112621
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 90, 97 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/mu7PeJZxxH",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/fc277fec-1da0-4a8a-b806-0112f4b06b2b",
      "display_url" : "amp.twimg.com\/v\/fc277fec-1da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749667974882131968",
  "text" : "RT @attn: No military spouse should lose their job because their partner is transferred. -@FLOTUS\nhttps:\/\/t.co\/mu7PeJZxxH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 80, 87 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/mu7PeJZxxH",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/fc277fec-1da0-4a8a-b806-0112f4b06b2b",
        "display_url" : "amp.twimg.com\/v\/fc277fec-1da\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749633905142083585",
    "text" : "No military spouse should lose their job because their partner is transferred. -@FLOTUS\nhttps:\/\/t.co\/mu7PeJZxxH",
    "id" : 749633905142083585,
    "created_at" : "2016-07-03 16:00:25 +0000",
    "user" : {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "protected" : false,
      "id_str" : "214112621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616387650560389120\/7dI5Ky0i_normal.jpg",
      "id" : 214112621,
      "verified" : true
    }
  },
  "id" : 749667974882131968,
  "created_at" : "2016-07-03 18:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749652709045702656",
  "text" : "\"When you move, you\u2019ll no longer be forced to put the career you love on hold\" \u2014@POTUS to military spouses: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749652709045702656,
  "created_at" : "2016-07-03 17:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UYx8aDhsvw",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749613843391864832",
  "text" : "\"All 50 states have acted to streamline many of these licensing issues\" for military members and families \u2014@POTUS: https:\/\/t.co\/UYx8aDhsvw",
  "id" : 749613843391864832,
  "created_at" : "2016-07-03 14:40:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/749389707650314240\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/TqvWcm7zQi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmZb-q2XYAE2aev.jpg",
      "id_str" : "749387520216096769",
      "id" : 749387520216096769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmZb-q2XYAE2aev.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/TqvWcm7zQi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/d83QNEqroz",
      "expanded_url" : "http:\/\/go.wh.gov\/C9asbs",
      "display_url" : "go.wh.gov\/C9asbs"
    } ]
  },
  "geo" : { },
  "id_str" : "749389707650314240",
  "text" : "\"In the face of evil, we must summon our capacity for good.\" \u2014@POTUS on Elie Wiesel: https:\/\/t.co\/d83QNEqroz https:\/\/t.co\/TqvWcm7zQi",
  "id" : 749389707650314240,
  "created_at" : "2016-07-02 23:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749378968105746432",
  "text" : "RT @POTUS: Elie Wiesel was a great moral voice of our time and a conscience for our world. He was also a dear friend. We will miss him deep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749378629822545920",
    "text" : "Elie Wiesel was a great moral voice of our time and a conscience for our world. He was also a dear friend. We will miss him deeply.",
    "id" : 749378629822545920,
    "created_at" : "2016-07-02 23:06:02 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 749378968105746432,
  "created_at" : "2016-07-02 23:07:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749346994431270912",
  "text" : "\"When these spouses were asked to move across state lines, they often needed to recertify for a job...We changed it\" https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749346994431270912,
  "created_at" : "2016-07-02 21:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749343149273657344",
  "text" : "\"Our troops are often transferred...Their spouses move ten times more often than the rest of us.\" \u2014@POTUS: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749343149273657344,
  "created_at" : "2016-07-02 20:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 100, 114 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749324309328334849",
  "text" : "\"They\u2019ve rallied businesses to hire more than 1.2 million veterans and military spouses\" \u2014@POTUS on @JoiningForces: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749324309328334849,
  "created_at" : "2016-07-02 19:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749301705376878593",
  "text" : "\"Honoring our service members, our veterans, and their families is something that so many Americans...do every day\": https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749301705376878593,
  "created_at" : "2016-07-02 18:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/wyXPM4zG2B",
      "expanded_url" : "http:\/\/go.wh.gov\/94yX5W",
      "display_url" : "go.wh.gov\/94yX5W"
    } ]
  },
  "geo" : { },
  "id_str" : "749295004464521216",
  "text" : "RT @FLOTUS: Today, all 50 states have acted to streamline military spouse licensing. #JoiningForces https:\/\/t.co\/wyXPM4zG2B https:\/\/t.co\/7j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/749271674508292096\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/7jy1UMX8Fi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmXyaXDVIAI0iWl.jpg",
        "id_str" : "749271447705559042",
        "id" : 749271447705559042,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmXyaXDVIAI0iWl.jpg",
        "sizes" : [ {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/7jy1UMX8Fi"
      } ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/wyXPM4zG2B",
        "expanded_url" : "http:\/\/go.wh.gov\/94yX5W",
        "display_url" : "go.wh.gov\/94yX5W"
      } ]
    },
    "geo" : { },
    "id_str" : "749271674508292096",
    "text" : "Today, all 50 states have acted to streamline military spouse licensing. #JoiningForces https:\/\/t.co\/wyXPM4zG2B https:\/\/t.co\/7jy1UMX8Fi",
    "id" : 749271674508292096,
    "created_at" : "2016-07-02 16:01:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 749295004464521216,
  "created_at" : "2016-07-02 17:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 64, 73 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/749284268778647553\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/9PGlPTjKAZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmX9_yqUIAASMgs.jpg",
      "id_str" : "749284185399894016",
      "id" : 749284185399894016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmX9_yqUIAASMgs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/9PGlPTjKAZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749284268778647553",
  "text" : "The United States stands with Bangladesh. Read the statement by @PressSec: https:\/\/t.co\/9PGlPTjKAZ",
  "id" : 749284268778647553,
  "created_at" : "2016-07-02 16:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FourthOfJuly",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/UYx8aDz3n4",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749267671678496768",
  "text" : ".@POTUS celebrates America's men and women in uniform in this week's #FourthOfJuly address. Watch: https:\/\/t.co\/UYx8aDz3n4",
  "id" : 749267671678496768,
  "created_at" : "2016-07-02 15:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FourthOfJulyWeekend",
      "indices" : [ 6, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/UYx8aDhsvw",
      "expanded_url" : "http:\/\/go.wh.gov\/ktiFCz",
      "display_url" : "go.wh.gov\/ktiFCz"
    } ]
  },
  "geo" : { },
  "id_str" : "749249189465452544",
  "text" : "Happy #FourthOfJulyWeekend! Watch @POTUS honor service members, veterans, and their families: https:\/\/t.co\/UYx8aDhsvw",
  "id" : 749249189465452544,
  "created_at" : "2016-07-02 14:31:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 3, 9 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 23, 28 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/NXBTpxZfp8",
      "expanded_url" : "https:\/\/www.quora.com\/What-is-the-one-thing-you-are-most-proud-of-that-the-Obama-administration-accomplished\/answer\/Valerie-Jarrett",
      "display_url" : "quora.com\/What-is-the-on\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749022442996305920",
  "text" : "RT @Quora: Answer from @vj44, Sr Advsr to @POTUS, on what she's most proud of during this admin: https:\/\/t.co\/NXBTpxZfp8 https:\/\/t.co\/dOyTB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 12, 17 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 31, 37 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Quora\/status\/748964374585368576\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/dOyTBqlYtC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmTbHHTUIAAGJaY.jpg",
        "id_str" : "748964353315971072",
        "id" : 748964353315971072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmTbHHTUIAAGJaY.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/dOyTBqlYtC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/NXBTpxZfp8",
        "expanded_url" : "https:\/\/www.quora.com\/What-is-the-one-thing-you-are-most-proud-of-that-the-Obama-administration-accomplished\/answer\/Valerie-Jarrett",
        "display_url" : "quora.com\/What-is-the-on\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748964374585368576",
    "text" : "Answer from @vj44, Sr Advsr to @POTUS, on what she's most proud of during this admin: https:\/\/t.co\/NXBTpxZfp8 https:\/\/t.co\/dOyTBqlYtC",
    "id" : 748964374585368576,
    "created_at" : "2016-07-01 19:39:56 +0000",
    "user" : {
      "name" : "Quora",
      "screen_name" : "Quora",
      "protected" : false,
      "id_str" : "33696409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615648367943651328\/51pM5n5v_normal.png",
      "id" : 33696409,
      "verified" : true
    }
  },
  "id" : 749022442996305920,
  "created_at" : "2016-07-01 23:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 104, 111 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/BrW4qi9kcG",
      "expanded_url" : "http:\/\/snpy.tv\/29mUWkP",
      "display_url" : "snpy.tv\/29mUWkP"
    } ]
  },
  "geo" : { },
  "id_str" : "749008176167657472",
  "text" : "\"Every single one of us has the power and the obligation to be a champion for girls around the world.\" \u2014@FLOTUS https:\/\/t.co\/BrW4qi9kcG",
  "id" : 749008176167657472,
  "created_at" : "2016-07-01 22:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748997957924507648",
  "text" : "RT @Denis44: Big accomplishments 2 kick off July 4\n\uD83C\uDDFA\uD83C\uDDF8Sign PROMESA\n\uD83C\uDDFA\uD83C\uDDF8New actions to make FOIA work better for citizens\n\uD83C\uDDFA\uD83C\uDDF8Increasing transpar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748996442040262656",
    "text" : "Big accomplishments 2 kick off July 4\n\uD83C\uDDFA\uD83C\uDDF8Sign PROMESA\n\uD83C\uDDFA\uD83C\uDDF8New actions to make FOIA work better for citizens\n\uD83C\uDDFA\uD83C\uDDF8Increasing transparency in CT ops",
    "id" : 748996442040262656,
    "created_at" : "2016-07-01 21:47:22 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 748997957924507648,
  "created_at" : "2016-07-01 21:53:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/748988841726472192\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5MQhVUnovY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmTxHzMWgAAFVo6.jpg",
      "id_str" : "748988554353737728",
      "id" : 748988554353737728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmTxHzMWgAAFVo6.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/5MQhVUnovY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/4Xw449WgOx",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "748988841726472192",
  "text" : "\u201CWhen there are public health emergencies\u2026politics need to be set aside.\u201D \u2014@POTUS on Zika: https:\/\/t.co\/4Xw449WgOx https:\/\/t.co\/5MQhVUnovY",
  "id" : 748988841726472192,
  "created_at" : "2016-07-01 21:17:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "indices" : [ 3, 15 ],
      "id_str" : "701725963",
      "id" : 701725963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/W28I9kEIWl",
      "expanded_url" : "https:\/\/www.facebook.com\/NowThisNews\/videos\/1097143857042404\/",
      "display_url" : "facebook.com\/NowThisNews\/vi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748948004854493184",
  "text" : "RT @nowthisnews: U.S. Ambassador to the U.N. Samantha Power is live on Facebook taking your questions: https:\/\/t.co\/W28I9kEIWl https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nowthisnews\/status\/748946457856663552\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/nneOiAsPL0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmTKzdFVIAA1NbU.jpg",
        "id_str" : "748946423379468288",
        "id" : 748946423379468288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmTKzdFVIAA1NbU.jpg",
        "sizes" : [ {
          "h" : 369,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 673
        } ],
        "display_url" : "pic.twitter.com\/nneOiAsPL0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/W28I9kEIWl",
        "expanded_url" : "https:\/\/www.facebook.com\/NowThisNews\/videos\/1097143857042404\/",
        "display_url" : "facebook.com\/NowThisNews\/vi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748946457856663552",
    "text" : "U.S. Ambassador to the U.N. Samantha Power is live on Facebook taking your questions: https:\/\/t.co\/W28I9kEIWl https:\/\/t.co\/nneOiAsPL0",
    "id" : 748946457856663552,
    "created_at" : "2016-07-01 18:28:44 +0000",
    "user" : {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "protected" : false,
      "id_str" : "701725963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783053831844298754\/p8H7pdtz_normal.jpg",
      "id" : 701725963,
      "verified" : true
    }
  },
  "id" : 748948004854493184,
  "created_at" : "2016-07-01 18:34:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Turn 2 Foundation",
      "screen_name" : "JeterTurn2",
      "indices" : [ 78, 89 ],
      "id_str" : "1947644899",
      "id" : 1947644899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/JJylBRq6nS",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/df1fbdd1-60f0-4d8e-ae61-1ddc073dcf7b",
      "display_url" : "amp.twimg.com\/v\/df1fbdd1-60f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748937016528830464",
  "text" : "ICYMI: @POTUS and Derek Jeter on mentorship through #MyBrothersKeeper and the @JeterTurn2 Foundation: https:\/\/t.co\/JJylBRq6nS",
  "id" : 748937016528830464,
  "created_at" : "2016-07-01 17:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/RzXhEdbQJR",
      "expanded_url" : "http:\/\/snpy.tv\/1XFwM84",
      "display_url" : "snpy.tv\/1XFwM84"
    } ]
  },
  "geo" : { },
  "id_str" : "748928931001143296",
  "text" : "\u201CCongress should not leave, should not adjourn until they have this done.\u201D \u2014@POTUS on Zika. Get the facts: https:\/\/t.co\/RzXhEdbQJR",
  "id" : 748928931001143296,
  "created_at" : "2016-07-01 17:19:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748905229316423680",
  "text" : "RT @JFriedman44: .@POTUS after a briefing from his public health team re: resources to fight Zika: \"Congress should not adjourn until they\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748897134687158272",
    "text" : ".@POTUS after a briefing from his public health team re: resources to fight Zika: \"Congress should not adjourn until they get this done.\"",
    "id" : 748897134687158272,
    "created_at" : "2016-07-01 15:12:45 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 748905229316423680,
  "created_at" : "2016-07-01 15:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "indices" : [ 111, 116 ],
      "id_str" : "17461978",
      "id" : 17461978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748885095105323008",
  "text" : "RT @rhodes44: \u201CWe\u2019re building bridges, extending our friendship, and teaching children how to play basketball\u201D-@Shaq in #Cuba https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SHAQ",
        "screen_name" : "SHAQ",
        "indices" : [ 97, 102 ],
        "id_str" : "17461978",
        "id" : 17461978
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/BjAzBVeqxw",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2DHrbjFhAJM",
        "display_url" : "youtube.com\/watch?v=2DHrbj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748879767131213824",
    "text" : "\u201CWe\u2019re building bridges, extending our friendship, and teaching children how to play basketball\u201D-@Shaq in #Cuba https:\/\/t.co\/BjAzBVeqxw",
    "id" : 748879767131213824,
    "created_at" : "2016-07-01 14:03:44 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 748885095105323008,
  "created_at" : "2016-07-01 14:24:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748875786380255232",
  "text" : "RT @Recode: White House will employ data analytics to help cities like San Francisco and Oakland reduce local jail population. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/avFbKCoptV",
        "expanded_url" : "http:\/\/on.recode.net\/298lcPs",
        "display_url" : "on.recode.net\/298lcPs"
      } ]
    },
    "geo" : { },
    "id_str" : "748705240891875329",
    "text" : "White House will employ data analytics to help cities like San Francisco and Oakland reduce local jail population. https:\/\/t.co\/avFbKCoptV",
    "id" : 748705240891875329,
    "created_at" : "2016-07-01 02:30:14 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 748875786380255232,
  "created_at" : "2016-07-01 13:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]