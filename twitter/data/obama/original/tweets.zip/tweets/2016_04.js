Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/p1xFpHrSmP",
      "expanded_url" : "http:\/\/snpy.tv\/1X0D9Co",
      "display_url" : "snpy.tv\/1X0D9Co"
    } ]
  },
  "geo" : { },
  "id_str" : "726603674181578752",
  "text" : "Watch @POTUS in \"Couch Commander.\" https:\/\/t.co\/p1xFpHrSmP",
  "id" : 726603674181578752,
  "created_at" : "2016-05-01 02:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726602492742635524\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/RQSDh92YsU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChVpE8jVEAAgsbf.jpg",
      "id_str" : "726602448584904704",
      "id" : 726602448584904704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChVpE8jVEAAgsbf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/RQSDh92YsU"
    } ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726602492742635524",
  "text" : "\"With that, I have just two more words to say: Obama Out.\" \u2014@POTUS #WHCD https:\/\/t.co\/RQSDh92YsU",
  "id" : 726602492742635524,
  "created_at" : "2016-05-01 02:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726601413636292608",
  "text" : "\"It has been an honor and a privilege to work side by side with you to strengthen our democracy.\" \u2014@POTUS at the #WHCD",
  "id" : 726601413636292608,
  "created_at" : "2016-05-01 02:37:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726600569742307328",
  "text" : "\"I have always appreciated the role that you have all played as equal partners in reaching those goals\" \u2014@POTUS on the goals of a free press",
  "id" : 726600569742307328,
  "created_at" : "2016-05-01 02:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/p1xFpHrSmP",
      "expanded_url" : "http:\/\/snpy.tv\/1X0D9Co",
      "display_url" : "snpy.tv\/1X0D9Co"
    } ]
  },
  "geo" : { },
  "id_str" : "726600186869506049",
  "text" : "\"Presidents don\u2019t stick around after they\u2019re done. It\u2019s something I\u2019ve been thinking about a lot.\" \u2014@POTUS at #WHCD: https:\/\/t.co\/p1xFpHrSmP",
  "id" : 726600186869506049,
  "created_at" : "2016-05-01 02:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726599075106328576\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jAmW1ZdkzE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChVl5xiUgAAQ06-.jpg",
      "id_str" : "726598958114439168",
      "id" : 726598958114439168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChVl5xiUgAAQ06-.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jAmW1ZdkzE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726599075106328576",
  "text" : "\"We've decided to stay in DC\"\n\"Youngest daughter can finish up HS\"\n\"Michelle can stay closer to her plot of carrots\" https:\/\/t.co\/jAmW1ZdkzE",
  "id" : 726599075106328576,
  "created_at" : "2016-05-01 02:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 55, 64 ],
      "id_str" : "5695632",
      "id" : 5695632
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 83, 98 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726596562386849796",
  "text" : "\"Every year at this dinner, someone makes a joke about @BuzzFeed\"\n\"Every year, the @WashingtonPost laughs a little bit less\"",
  "id" : 726596562386849796,
  "created_at" : "2016-05-01 02:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726595997116280832",
  "text" : "\"I love Joe Biden\"\n\"I just want to thank him for being a great friend\"\n\"For not shooting anybody in the face\" \u2014@POTUS #WHCD",
  "id" : 726595997116280832,
  "created_at" : "2016-05-01 02:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726595160457535489",
  "text" : "\"Even some foreign leaders have been giving me grief. Last week, Prince George showed up to our meeting in his bathrobe.\" \u2014@POTUS #WHCD",
  "id" : 726595160457535489,
  "created_at" : "2016-05-01 02:12:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/726594477746429956\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hloflknfMZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChVhuLuWgAAdbq4.jpg",
      "id_str" : "726594360939282432",
      "id" : 726594360939282432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChVhuLuWgAAdbq4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hloflknfMZ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/726594477746429956\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hloflknfMZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChVhxh4WwAAu00i.jpg",
      "id_str" : "726594418426429440",
      "id" : 726594418426429440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChVhxh4WwAAu00i.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hloflknfMZ"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/726594477746429956\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hloflknfMZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChVhygRWkAAVRhP.jpg",
      "id_str" : "726594435174273024",
      "id" : 726594435174273024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChVhygRWkAAVRhP.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hloflknfMZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726594477746429956",
  "text" : "\"Michelle has not aged a day. The only way you can date her in photos is by looking at me.\" \u2014@POTUS sharing photos: https:\/\/t.co\/hloflknfMZ",
  "id" : 726594477746429956,
  "created_at" : "2016-05-01 02:09:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726594022228267009",
  "text" : "\"8 years ago, I said it was time to change the tone of our politics. In hindsight, I clearly should have been more specific.\" \u2014@POTUS #WHCD",
  "id" : 726594022228267009,
  "created_at" : "2016-05-01 02:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bLXImCaPI2",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    } ]
  },
  "geo" : { },
  "id_str" : "726593440629317632",
  "text" : "\"It is an honor to be here at my last\u2014and perhaps the last\u2014White House Correspondents Dinner.\" \u2014@POTUS at the #WHCD: https:\/\/t.co\/bLXImCaPI2",
  "id" : 726593440629317632,
  "created_at" : "2016-05-01 02:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bLXImBTejs",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    } ]
  },
  "geo" : { },
  "id_str" : "726583171999895552",
  "text" : "\"Some people still say I\u2019m arrogant and aloof...Some people are so dumb.\" Look back at @POTUS's top #WHCD jokes \u2192 https:\/\/t.co\/bLXImBTejs",
  "id" : 726583171999895552,
  "created_at" : "2016-05-01 01:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726574348241260545\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/pbXmh3v7fk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChVPWxFUkAA_Hqf.jpg",
      "id_str" : "726574167441575936",
      "id" : 726574167441575936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChVPWxFUkAA_Hqf.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/pbXmh3v7fk"
    } ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/bLXImBTejs",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    } ]
  },
  "geo" : { },
  "id_str" : "726574348241260545",
  "text" : "Tonight is @POTUS's final #WHCD. Check out some of his top jokes from the past 7 years: https:\/\/t.co\/bLXImBTejs https:\/\/t.co\/pbXmh3v7fk",
  "id" : 726574348241260545,
  "created_at" : "2016-05-01 00:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 3, 14 ],
      "id_str" : "15693493",
      "id" : 15693493
    }, {
      "name" : "matt walsh",
      "screen_name" : "mrmattwalsh",
      "indices" : [ 17, 29 ],
      "id_str" : "38934368",
      "id" : 38934368
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 77, 82 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726529165411946496",
  "text" : "RT @funnyordie: .@MrMattWalsh shares comedy advice w Obama\u2019s senior advisor, @vj44, before the White House Correspondents\u2019 Dinner.\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "matt walsh",
        "screen_name" : "mrmattwalsh",
        "indices" : [ 1, 13 ],
        "id_str" : "38934368",
        "id" : 38934368
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 61, 66 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/N0dG0In4Zi",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/ced8eff8-c013-40e2-a9c6-63398d59153a",
        "display_url" : "amp.twimg.com\/v\/ced8eff8-c01\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726063366637113344",
    "text" : ".@MrMattWalsh shares comedy advice w Obama\u2019s senior advisor, @vj44, before the White House Correspondents\u2019 Dinner.\nhttps:\/\/t.co\/N0dG0In4Zi",
    "id" : 726063366637113344,
    "created_at" : "2016-04-29 14:59:30 +0000",
    "user" : {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "protected" : false,
      "id_str" : "15693493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796062959185182720\/FN6QGp0H_normal.jpg",
      "id" : 15693493,
      "verified" : true
    }
  },
  "id" : 726529165411946496,
  "created_at" : "2016-04-30 21:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/EtPiHn0IHl",
      "expanded_url" : "http:\/\/snpy.tv\/1r3GO6",
      "display_url" : "snpy.tv\/1r3GO6"
    } ]
  },
  "geo" : { },
  "id_str" : "726492893020590080",
  "text" : "Your pets are a part of your family. Here's some tips on how to keep them safe in an emergency\u2014with Bo and Sunny! https:\/\/t.co\/EtPiHn0IHl",
  "id" : 726492893020590080,
  "created_at" : "2016-04-30 19:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QYiIYb4ep3",
      "expanded_url" : "http:\/\/go.wh.gov\/3YaCG5",
      "display_url" : "go.wh.gov\/3YaCG5"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/IddjwVX9BZ",
      "expanded_url" : "http:\/\/snpy.tv\/1O1uKr3",
      "display_url" : "snpy.tv\/1O1uKr3"
    } ]
  },
  "geo" : { },
  "id_str" : "726480021766836225",
  "text" : "\"It is more important than ever.\" \u2014@POTUS on filling the vacancy on the Supreme Court: https:\/\/t.co\/QYiIYb4ep3 https:\/\/t.co\/IddjwVX9BZ",
  "id" : 726480021766836225,
  "created_at" : "2016-04-30 18:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/bS3obcDpUK",
      "expanded_url" : "http:\/\/snpy.tv\/1SzWCIr",
      "display_url" : "snpy.tv\/1SzWCIr"
    } ]
  },
  "geo" : { },
  "id_str" : "726471325494042625",
  "text" : "\u201CGuten tag!\"\u2014 Watch @POTUS in this week's #WestWingWeek. https:\/\/t.co\/bS3obcDpUK",
  "id" : 726471325494042625,
  "created_at" : "2016-04-30 18:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726461161076445185\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/AYcPaRhaI1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChTbg69VEAIYTu4.jpg",
      "id_str" : "726446798542278658",
      "id" : 726446798542278658,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChTbg69VEAIYTu4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AYcPaRhaI1"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/QYiIYb4ep3",
      "expanded_url" : "http:\/\/go.wh.gov\/3YaCG5",
      "display_url" : "go.wh.gov\/3YaCG5"
    } ]
  },
  "geo" : { },
  "id_str" : "726461161076445185",
  "text" : "It\u2019s time for the Senate to do its job: Give @POTUS\u2019s #SCOTUS nominee an up-or-down vote. https:\/\/t.co\/QYiIYb4ep3 https:\/\/t.co\/AYcPaRhaI1",
  "id" : 726461161076445185,
  "created_at" : "2016-04-30 17:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726451075570503682\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/3Urx0x40ZH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChTUsD8UUAAmJRy.jpg",
      "id_str" : "726439293351120896",
      "id" : 726439293351120896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChTUsD8UUAAmJRy.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/3Urx0x40ZH"
    } ],
    "hashtags" : [ {
      "text" : "Passover",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/QYjEycB5r6",
      "expanded_url" : "http:\/\/go.wh.gov\/p3zmRe",
      "display_url" : "go.wh.gov\/p3zmRe"
    } ]
  },
  "geo" : { },
  "id_str" : "726451075570503682",
  "text" : "\"From our family to yours, chag sameach.\" \u2014@POTUS on the last day of #Passover: https:\/\/t.co\/QYjEycB5r6 https:\/\/t.co\/3Urx0x40ZH",
  "id" : 726451075570503682,
  "created_at" : "2016-04-30 16:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726438701169942530",
  "text" : "RT @SCOTUSnom: \"Every #SCOTUS nominee since 1875 who hasn\u2019t withdrawn from the process has received a hearing or a vote\u201D \u2014@POTUS: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 107, 113 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 7, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/oYLvrNu502",
        "expanded_url" : "http:\/\/snpy.tv\/1O1uKr3",
        "display_url" : "snpy.tv\/1O1uKr3"
      } ]
    },
    "geo" : { },
    "id_str" : "726407157638397953",
    "text" : "\"Every #SCOTUS nominee since 1875 who hasn\u2019t withdrawn from the process has received a hearing or a vote\u201D \u2014@POTUS: https:\/\/t.co\/oYLvrNu502",
    "id" : 726407157638397953,
    "created_at" : "2016-04-30 13:45:37 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 726438701169942530,
  "created_at" : "2016-04-30 15:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IddjwVX9BZ",
      "expanded_url" : "http:\/\/snpy.tv\/1O1uKr3",
      "display_url" : "snpy.tv\/1O1uKr3"
    } ]
  },
  "geo" : { },
  "id_str" : "726426138206068736",
  "text" : "\"This is not about partisan politics\u2014it\u2019s about upholding the institutions that make our democracy work.\" \u2014@POTUS: https:\/\/t.co\/IddjwVX9BZ",
  "id" : 726426138206068736,
  "created_at" : "2016-04-30 15:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/3WxW0ez5Wc",
      "expanded_url" : "http:\/\/snpy.tv\/1r3Xc6x",
      "display_url" : "snpy.tv\/1r3Xc6x"
    } ]
  },
  "geo" : { },
  "id_str" : "726203188513112065",
  "text" : "\"Jazz. It\u2019s always been where people come together, across seemingly unbridgeable divides.\" \u2014@POTUS https:\/\/t.co\/3WxW0ez5Wc",
  "id" : 726203188513112065,
  "created_at" : "2016-04-30 00:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JazzDay",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/KCMljMbD0a",
      "expanded_url" : "http:\/\/snpy.tv\/1rouUUR",
      "display_url" : "snpy.tv\/1rouUUR"
    } ]
  },
  "geo" : { },
  "id_str" : "726197238997913600",
  "text" : "\"We\u2019re turning this place into the Blues House.\" \u2014@POTUS at the International #JazzDay Concert on the South Lawn https:\/\/t.co\/KCMljMbD0a",
  "id" : 726197238997913600,
  "created_at" : "2016-04-29 23:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/RzImVGO1Dv",
      "expanded_url" : "http:\/\/snpy.tv\/1SzRDay",
      "display_url" : "snpy.tv\/1SzRDay"
    } ]
  },
  "geo" : { },
  "id_str" : "726195760388280321",
  "text" : "Watch @POTUS talk about the moment when he first fell in love with Jazz. https:\/\/t.co\/RzImVGO1Dv",
  "id" : 726195760388280321,
  "created_at" : "2016-04-29 23:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ovzpf4gYeb",
      "expanded_url" : "http:\/\/go.wh.gov\/PKKgqJ",
      "display_url" : "go.wh.gov\/PKKgqJ"
    } ]
  },
  "geo" : { },
  "id_str" : "726194171229429760",
  "text" : "\"There is something fearless and true about jazz. This is truth-telling music.\" \u2014@POTUS \n\nWatch live: https:\/\/t.co\/ovzpf4gYeb",
  "id" : 726194171229429760,
  "created_at" : "2016-04-29 23:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JazzDay",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726193675814969344",
  "text" : "\"Perhaps more than any other form of art, jazz is driven by an unmistakably American spirit\" \u2014@POTUS at the International #JazzDay Concert",
  "id" : 726193675814969344,
  "created_at" : "2016-04-29 23:37:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JazzDay",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ovzpf4gYeb",
      "expanded_url" : "http:\/\/go.wh.gov\/PKKgqJ",
      "display_url" : "go.wh.gov\/PKKgqJ"
    } ]
  },
  "geo" : { },
  "id_str" : "726190575851024384",
  "text" : "Tune in at 7:30pm ET: Watch @POTUS deliver remarks at the International #JazzDay Concert \u2192 https:\/\/t.co\/ovzpf4gYeb",
  "id" : 726190575851024384,
  "created_at" : "2016-04-29 23:24:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Janney",
      "screen_name" : "AllisonBJanney",
      "indices" : [ 3, 18 ],
      "id_str" : "123015364",
      "id" : 123015364
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AllisonBJanney\/status\/726118314204905473\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Zi4c98USCy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOwpo7WIAAFZ0O.jpg",
      "id_str" : "726118194344239104",
      "id" : 726118194344239104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOwpo7WIAAFZ0O.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Zi4c98USCy"
    } ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "CJrulesagain",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726120511764369409",
  "text" : "RT @AllisonBJanney: Back at the podium @WhiteHouse !! #WHChamps #CJrulesagain https:\/\/t.co\/Zi4c98USCy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 19, 30 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AllisonBJanney\/status\/726118314204905473\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Zi4c98USCy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOwpo7WIAAFZ0O.jpg",
        "id_str" : "726118194344239104",
        "id" : 726118194344239104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOwpo7WIAAFZ0O.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Zi4c98USCy"
      } ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 34, 43 ]
      }, {
        "text" : "CJrulesagain",
        "indices" : [ 44, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726118314204905473",
    "text" : "Back at the podium @WhiteHouse !! #WHChamps #CJrulesagain https:\/\/t.co\/Zi4c98USCy",
    "id" : 726118314204905473,
    "created_at" : "2016-04-29 18:37:51 +0000",
    "user" : {
      "name" : "Allison Janney",
      "screen_name" : "AllisonBJanney",
      "protected" : false,
      "id_str" : "123015364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625791513629331456\/N4ozKlZG_normal.jpg",
      "id" : 123015364,
      "verified" : true
    }
  },
  "id" : 726120511764369409,
  "created_at" : "2016-04-29 18:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Janney",
      "screen_name" : "AllisonBJanney",
      "indices" : [ 1, 16 ],
      "id_str" : "123015364",
      "id" : 123015364
    }, {
      "name" : "Mom",
      "screen_name" : "MomCBS",
      "indices" : [ 44, 51 ],
      "id_str" : "1180675964",
      "id" : 1180675964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/TK4NJ7TEyM",
      "expanded_url" : "http:\/\/snpy.tv\/26BlfKL",
      "display_url" : "snpy.tv\/26BlfKL"
    } ]
  },
  "geo" : { },
  "id_str" : "726094688365740032",
  "text" : ".@AllisonBJanney\nAKA CJ Cregg\nAKA Bonnie on @MomCBS\ndrops by the White House press briefing. https:\/\/t.co\/TK4NJ7TEyM",
  "id" : 726094688365740032,
  "created_at" : "2016-04-29 17:03:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/RCnqZUBtQy",
      "expanded_url" : "https:\/\/www.facebook.com\/WhiteHouse\/",
      "display_url" : "facebook.com\/WhiteHouse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "726092177424683008",
  "text" : "Watch live: A surprise guest drops by the White House Press Briefing: https:\/\/t.co\/RCnqZUBtQy #FlashbackFriday",
  "id" : 726092177424683008,
  "created_at" : "2016-04-29 16:53:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 77, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/7Hp7GU007U",
      "expanded_url" : "http:\/\/apne.ws\/1SDbDpw",
      "display_url" : "apne.ws\/1SDbDpw"
    } ]
  },
  "geo" : { },
  "id_str" : "726081056164708353",
  "text" : "RT @vj44: Thanks to Will and Jada Smith for your work in support of @POTUS's #MyBrothersKeeper initiative: https:\/\/t.co\/7Hp7GU007U CC:@Brod\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 58, 64 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Broderick Johnson",
        "screen_name" : "Broderick44",
        "indices" : [ 124, 136 ],
        "id_str" : "3246838764",
        "id" : 3246838764
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 67, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/7Hp7GU007U",
        "expanded_url" : "http:\/\/apne.ws\/1SDbDpw",
        "display_url" : "apne.ws\/1SDbDpw"
      } ]
    },
    "geo" : { },
    "id_str" : "726080699019579392",
    "text" : "Thanks to Will and Jada Smith for your work in support of @POTUS's #MyBrothersKeeper initiative: https:\/\/t.co\/7Hp7GU007U CC:@Broderick44",
    "id" : 726080699019579392,
    "created_at" : "2016-04-29 16:08:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 726081056164708353,
  "created_at" : "2016-04-29 16:09:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726078741747625984\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lWJlYkDJeN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOKJ5TVEAUKrIc.jpg",
      "id_str" : "726075867542130693",
      "id" : 726075867542130693,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOKJ5TVEAUKrIc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/lWJlYkDJeN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pfjPQiUPQi",
      "expanded_url" : "http:\/\/go.wh.gov\/SvnSmM",
      "display_url" : "go.wh.gov\/SvnSmM"
    } ]
  },
  "geo" : { },
  "id_str" : "726078741747625984",
  "text" : ".@POTUS is boosting the development of gun safety technology to help prevent gun deaths: https:\/\/t.co\/pfjPQiUPQi https:\/\/t.co\/lWJlYkDJeN",
  "id" : 726078741747625984,
  "created_at" : "2016-04-29 16:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726073820101132290\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/HoRwCjYxE3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOIQg9UYAAaiCp.jpg",
      "id_str" : "726073782243188736",
      "id" : 726073782243188736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOIQg9UYAAaiCp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/HoRwCjYxE3"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 74, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pfjPQiDeYK",
      "expanded_url" : "http:\/\/go.wh.gov\/SvnSmM",
      "display_url" : "go.wh.gov\/SvnSmM"
    } ]
  },
  "geo" : { },
  "id_str" : "726073820101132290",
  "text" : "More than 30,000 Americans die from guns every year.\n\nWhat we're doing to #StopGunViolence: https:\/\/t.co\/pfjPQiDeYK https:\/\/t.co\/HoRwCjYxE3",
  "id" : 726073820101132290,
  "created_at" : "2016-04-29 15:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat Geo Channel",
      "screen_name" : "NatGeoChannel",
      "indices" : [ 3, 17 ],
      "id_str" : "18244358",
      "id" : 18244358
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 29, 37 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Jason Silva",
      "screen_name" : "JasonSilva",
      "indices" : [ 42, 53 ],
      "id_str" : "43904362",
      "id" : 43904362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/l8r7k8hlso",
      "expanded_url" : "http:\/\/ow.ly\/4nfeMm",
      "display_url" : "ow.ly\/4nfeMm"
    } ]
  },
  "geo" : { },
  "id_str" : "726069246644621312",
  "text" : "RT @NatGeoChannel: LIVE NOW: @DrBiden and @JasonSilva have a big announcement, plus some Brain Games fun! Watch: https:\/\/t.co\/l8r7k8hlso #J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 10, 18 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      }, {
        "name" : "Jason Silva",
        "screen_name" : "JasonSilva",
        "indices" : [ 23, 34 ],
        "id_str" : "43904362",
        "id" : 43904362
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 118, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/l8r7k8hlso",
        "expanded_url" : "http:\/\/ow.ly\/4nfeMm",
        "display_url" : "ow.ly\/4nfeMm"
      } ]
    },
    "geo" : { },
    "id_str" : "726065605732909056",
    "text" : "LIVE NOW: @DrBiden and @JasonSilva have a big announcement, plus some Brain Games fun! Watch: https:\/\/t.co\/l8r7k8hlso #JoiningForces",
    "id" : 726065605732909056,
    "created_at" : "2016-04-29 15:08:24 +0000",
    "user" : {
      "name" : "Nat Geo Channel",
      "screen_name" : "NatGeoChannel",
      "protected" : false,
      "id_str" : "18244358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767771700796743680\/v5IPVvjS_normal.jpg",
      "id" : 18244358,
      "verified" : true
    }
  },
  "id" : 726069246644621312,
  "created_at" : "2016-04-29 15:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726065318850912256\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/OMnTGhrilC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChOAZPsW4AAbntg.jpg",
      "id_str" : "726065136134447104",
      "id" : 726065136134447104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChOAZPsW4AAbntg.jpg",
      "sizes" : [ {
        "h" : 553,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 492
      } ],
      "display_url" : "pic.twitter.com\/OMnTGhrilC"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/uyNBuAQeUl",
      "expanded_url" : "http:\/\/go.wh.gov\/vX2r4A",
      "display_url" : "go.wh.gov\/vX2r4A"
    } ]
  },
  "geo" : { },
  "id_str" : "726065318850912256",
  "text" : "\"We've jumpstarted the development of smart gun technology.\" \u2014@POTUS: https:\/\/t.co\/uyNBuAQeUl #StopGunViolence https:\/\/t.co\/OMnTGhrilC",
  "id" : 726065318850912256,
  "created_at" : "2016-04-29 15:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "indices" : [ 3, 19 ],
      "id_str" : "2812768561",
      "id" : 2812768561
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 43, 50 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/sjfSQvkzb6",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/99f408b2-faea-40a8-9532-add82527df8a",
      "display_url" : "amp.twimg.com\/v\/99f408b2-fae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726063719403405313",
  "text" : "RT @KensingtonRoyal: Unfortunately for you @FLOTUS and @POTUS I wasn't alone when you sent me that video \uD83D\uDE09 - H.\nhttps:\/\/t.co\/sjfSQvkzb6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 22, 29 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 34, 40 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/sjfSQvkzb6",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/99f408b2-faea-40a8-9532-add82527df8a",
        "display_url" : "amp.twimg.com\/v\/99f408b2-fae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726062251354914817",
    "text" : "Unfortunately for you @FLOTUS and @POTUS I wasn't alone when you sent me that video \uD83D\uDE09 - H.\nhttps:\/\/t.co\/sjfSQvkzb6",
    "id" : 726062251354914817,
    "created_at" : "2016-04-29 14:55:04 +0000",
    "user" : {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "protected" : false,
      "id_str" : "2812768561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798099622455640065\/4XELymPa_normal.jpg",
      "id" : 2812768561,
      "verified" : true
    }
  },
  "id" : 726063719403405313,
  "created_at" : "2016-04-29 15:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/726055116214784001\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/SZ9qNSTJL2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChN2-79U8AAdmuU.jpg",
      "id_str" : "726054788555665408",
      "id" : 726054788555665408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChN2-79U8AAdmuU.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/SZ9qNSTJL2"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/eZwdRbn8YE",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "726055116214784001",
  "text" : "Announcing our third-annual #WHFilmFest! Submit your film by July 15 \u2192 https:\/\/t.co\/eZwdRbn8YE https:\/\/t.co\/SZ9qNSTJL2",
  "id" : 726055116214784001,
  "created_at" : "2016-04-29 14:26:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "indices" : [ 17, 33 ],
      "id_str" : "2812768561",
      "id" : 2812768561
    }, {
      "name" : "Invictus Games 2016",
      "screen_name" : "InvictusOrlando",
      "indices" : [ 53, 69 ],
      "id_str" : "3342818044",
      "id" : 3342818044
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/726033605093412864\/video\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/S34KrEv5Is",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/726033556267364352\/pu\/img\/37kVhPeXjd0AX5LW.jpg",
      "id_str" : "726033556267364352",
      "id" : 726033556267364352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/726033556267364352\/pu\/img\/37kVhPeXjd0AX5LW.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/S34KrEv5Is"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726053581363798017",
  "text" : "RT @FLOTUS: Hey, @KensingtonRoyal! Are you ready for @InvictusOrlando? Game on. https:\/\/t.co\/S34KrEv5Is",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kensington Palace",
        "screen_name" : "KensingtonRoyal",
        "indices" : [ 5, 21 ],
        "id_str" : "2812768561",
        "id" : 2812768561
      }, {
        "name" : "Invictus Games 2016",
        "screen_name" : "InvictusOrlando",
        "indices" : [ 41, 57 ],
        "id_str" : "3342818044",
        "id" : 3342818044
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/726033605093412864\/video\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/S34KrEv5Is",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/726033556267364352\/pu\/img\/37kVhPeXjd0AX5LW.jpg",
        "id_str" : "726033556267364352",
        "id" : 726033556267364352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/726033556267364352\/pu\/img\/37kVhPeXjd0AX5LW.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/S34KrEv5Is"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726033605093412864",
    "text" : "Hey, @KensingtonRoyal! Are you ready for @InvictusOrlando? Game on. https:\/\/t.co\/S34KrEv5Is",
    "id" : 726033605093412864,
    "created_at" : "2016-04-29 13:01:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 726053581363798017,
  "created_at" : "2016-04-29 14:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalReentryWeek",
      "indices" : [ 105, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725867416782249984",
  "text" : "RT @vj44: Qs on the work we're doing to help those who deserve a 2nd chance earn one?\nAsk by 1pm ET with #NationalReentryWeek: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalReentryWeek",
        "indices" : [ 95, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/PQqXL84uyd",
        "expanded_url" : "http:\/\/1.usa.gov\/1qHPIWx",
        "display_url" : "1.usa.gov\/1qHPIWx"
      } ]
    },
    "geo" : { },
    "id_str" : "725863946524217344",
    "text" : "Qs on the work we're doing to help those who deserve a 2nd chance earn one?\nAsk by 1pm ET with #NationalReentryWeek: https:\/\/t.co\/PQqXL84uyd",
    "id" : 725863946524217344,
    "created_at" : "2016-04-29 01:47:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 725867416782249984,
  "created_at" : "2016-04-29 02:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 94, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/L5VfdxVOcx",
      "expanded_url" : "http:\/\/snpy.tv\/1SwlO2p",
      "display_url" : "snpy.tv\/1SwlO2p"
    } ]
  },
  "geo" : { },
  "id_str" : "725836994492923904",
  "text" : "\"If you care about climate change, you care about college costs...you\u2019ve got to vote\" \u2014@POTUS #CollegeReporterDay https:\/\/t.co\/L5VfdxVOcx",
  "id" : 725836994492923904,
  "created_at" : "2016-04-28 23:59:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725814735917060097\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/gXNLUIOaTQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChKcobeVEAAX8kn.jpg",
      "id_str" : "725814708343738368",
      "id" : 725814708343738368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChKcobeVEAAX8kn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/gXNLUIOaTQ"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 93, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/n6Tmuk5Nn8",
      "expanded_url" : "http:\/\/StudentLoans.gov\/Repay",
      "display_url" : "StudentLoans.gov\/Repay"
    } ]
  },
  "geo" : { },
  "id_str" : "725814735917060097",
  "text" : "You can now pick a student loan repayment option in 5 steps or less: https:\/\/t.co\/n6Tmuk5Nn8 #CollegeOpportunity https:\/\/t.co\/gXNLUIOaTQ",
  "id" : 725814735917060097,
  "created_at" : "2016-04-28 22:31:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725798022215405569\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ymbSBfedOJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChKKSplUcAACP61.jpg",
      "id_str" : "725794542964731904",
      "id" : 725794542964731904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChKKSplUcAACP61.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ymbSBfedOJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/bByGgQFgiK",
      "expanded_url" : "http:\/\/go.wh.gov\/TpyWa4",
      "display_url" : "go.wh.gov\/TpyWa4"
    } ]
  },
  "geo" : { },
  "id_str" : "725798022215405569",
  "text" : "Since @POTUS took office, more students are graduating than ever before: https:\/\/t.co\/bByGgQFgiK https:\/\/t.co\/ymbSBfedOJ",
  "id" : 725798022215405569,
  "created_at" : "2016-04-28 21:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725793672026046464\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/9zL11O3OqR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChKJfCfUkAEQ1PR.jpg",
      "id_str" : "725793656297263105",
      "id" : 725793656297263105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChKJfCfUkAEQ1PR.jpg",
      "sizes" : [ {
        "h" : 121,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 984
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 984
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9zL11O3OqR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/n6TmujOcvA",
      "expanded_url" : "http:\/\/StudentLoans.gov\/Repay",
      "display_url" : "StudentLoans.gov\/Repay"
    } ]
  },
  "geo" : { },
  "id_str" : "725793672026046464",
  "text" : "5 steps in 60 seconds or less: Find the student loan repayment option that works for you \u2192 https:\/\/t.co\/n6TmujOcvA https:\/\/t.co\/9zL11O3OqR",
  "id" : 725793672026046464,
  "created_at" : "2016-04-28 21:07:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 37, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725789315956133889",
  "text" : "RT @PressSec: Enjoyed our first-ever #CollegeReporterDay briefing w\/ @POTUS &amp; looking forward to taking your q's at 5:15pm, send them using\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 55, 61 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeReporterDay",
        "indices" : [ 23, 42 ]
      }, {
        "text" : "AskPressSec",
        "indices" : [ 130, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725786039940354049",
    "text" : "Enjoyed our first-ever #CollegeReporterDay briefing w\/ @POTUS &amp; looking forward to taking your q's at 5:15pm, send them using #AskPressSec",
    "id" : 725786039940354049,
    "created_at" : "2016-04-28 20:37:31 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 725789315956133889,
  "created_at" : "2016-04-28 20:50:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/L5VfdxVOcx",
      "expanded_url" : "http:\/\/snpy.tv\/1SwlO2p",
      "display_url" : "snpy.tv\/1SwlO2p"
    } ]
  },
  "geo" : { },
  "id_str" : "725787870456373248",
  "text" : "\"JFK said, 'there's no problem that man creates that man can't solve.' I would add women to that.\" \u2014@POTUS https:\/\/t.co\/L5VfdxVOcx",
  "id" : 725787870456373248,
  "created_at" : "2016-04-28 20:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 81, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/L5VfdxVOcx",
      "expanded_url" : "http:\/\/snpy.tv\/1SwlO2p",
      "display_url" : "snpy.tv\/1SwlO2p"
    } ]
  },
  "geo" : { },
  "id_str" : "725786374478155776",
  "text" : "\"Our democracy only works when people participate.\" \u2014@POTUS to college reporters #CollegeReporterDay https:\/\/t.co\/L5VfdxVOcx",
  "id" : 725786374478155776,
  "created_at" : "2016-04-28 20:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Dx3GN31u36",
      "expanded_url" : "https:\/\/studentloans.gov\/repay",
      "display_url" : "studentloans.gov\/repay"
    } ]
  },
  "geo" : { },
  "id_str" : "725784607296245761",
  "text" : "RT @usedgov: When it comes to dealing with your student loan debt, know that you have options: https:\/\/t.co\/Dx3GN31u36 https:\/\/t.co\/IcHfuVg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/725762279745032194\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/IcHfuVgcPX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJkyDeWgAEEDY8.jpg",
        "id_str" : "725753301048918017",
        "id" : 725753301048918017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJkyDeWgAEEDY8.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/IcHfuVgcPX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Dx3GN31u36",
        "expanded_url" : "https:\/\/studentloans.gov\/repay",
        "display_url" : "studentloans.gov\/repay"
      } ]
    },
    "geo" : { },
    "id_str" : "725762279745032194",
    "text" : "When it comes to dealing with your student loan debt, know that you have options: https:\/\/t.co\/Dx3GN31u36 https:\/\/t.co\/IcHfuVgcPX",
    "id" : 725762279745032194,
    "created_at" : "2016-04-28 19:03:06 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 725784607296245761,
  "created_at" : "2016-04-28 20:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 24, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/5glSHALxQW",
      "expanded_url" : "http:\/\/snpy.tv\/1SwdWhj",
      "display_url" : "snpy.tv\/1SwdWhj"
    } ]
  },
  "geo" : { },
  "id_str" : "725780866169892867",
  "text" : ".@POTUS just dropped by #CollegeReporterDay to talk about new steps to help more Americans manage student debt: https:\/\/t.co\/5glSHALxQW",
  "id" : 725780866169892867,
  "created_at" : "2016-04-28 20:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/qGPxcNqY9y",
      "expanded_url" : "http:\/\/snpy.tv\/1rlCmA5",
      "display_url" : "snpy.tv\/1rlCmA5"
    } ]
  },
  "geo" : { },
  "id_str" : "725778285062287363",
  "text" : "\"I just wanted to stop by and say hello!\" \n@POTUS just surprised over 50 student reporters. Watch: https:\/\/t.co\/qGPxcNqY9y",
  "id" : 725778285062287363,
  "created_at" : "2016-04-28 20:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/725776494199345152\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/sTGS5P7P7c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJ5tk0U4AADFAx.jpg",
      "id_str" : "725776313844293632",
      "id" : 725776313844293632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJ5tk0U4AADFAx.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/sTGS5P7P7c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725776494199345152",
  "text" : "\"We\u2019re aiming to enroll two million more people in Pay as You Earn by this time next year.\" \u2014@POTUS https:\/\/t.co\/sTGS5P7P7c",
  "id" : 725776494199345152,
  "created_at" : "2016-04-28 19:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/725775778525274113\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cFp9mLiC8u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJ5KGfUoAAvetC.jpg",
      "id_str" : "725775704407711744",
      "id" : 725775704407711744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJ5KGfUoAAvetC.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cFp9mLiC8u"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 93, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725775778525274113",
  "text" : "\"We've expanded pell grants to make sure more people could have access.\" \u2014@POTUS on creating #CollegeOpportunity https:\/\/t.co\/cFp9mLiC8u",
  "id" : 725775778525274113,
  "created_at" : "2016-04-28 19:56:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725775024070651905\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/OsOckEqriP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJ4hR0U8AAYZkm.jpg",
      "id_str" : "725775003073966080",
      "id" : 725775003073966080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJ4hR0U8AAYZkm.jpg",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/OsOckEqriP"
    } ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 60, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/69xUWSPL6Z",
      "expanded_url" : "http:\/\/go.wh.gov\/EFvV3Q",
      "display_url" : "go.wh.gov\/EFvV3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "725775024070651905",
  "text" : "Surprise! Tune in now as @POTUS makes a surprise drop-by at #CollegeReporterDay \u2192 https:\/\/t.co\/69xUWSPL6Z https:\/\/t.co\/OsOckEqriP",
  "id" : 725775024070651905,
  "created_at" : "2016-04-28 19:53:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 20, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/69xUWSPL6Z",
      "expanded_url" : "http:\/\/go.wh.gov\/EFvV3Q",
      "display_url" : "go.wh.gov\/EFvV3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "725769257816985600",
  "text" : "It's the first-ever #CollegeReporterDay at the White House! Tune in for a special press briefing: https:\/\/t.co\/69xUWSPL6Z",
  "id" : 725769257816985600,
  "created_at" : "2016-04-28 19:30:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725747369178980352\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/eIiWiBm4Ra",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJfX0cW0AE6vql.jpg",
      "id_str" : "725747352779280385",
      "id" : 725747352779280385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJfX0cW0AE6vql.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1165,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1165,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/eIiWiBm4Ra"
    } ],
    "hashtags" : [ {
      "text" : "AmericaCreates",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/XXR7pSKR3q",
      "expanded_url" : "http:\/\/go.wh.gov\/TheList",
      "display_url" : "go.wh.gov\/TheList"
    } ]
  },
  "geo" : { },
  "id_str" : "725747369178980352",
  "text" : "The Bulls \u2713\nThe Wire \u2713\nThe Godfather \u2713\n@POTUS's favorite examples of what #AmericaCreates: https:\/\/t.co\/XXR7pSKR3q https:\/\/t.co\/eIiWiBm4Ra",
  "id" : 725747369178980352,
  "created_at" : "2016-04-28 18:03:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/725713811932504064\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/kex7EhSkeV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJA3bPWwAApgOV.jpg",
      "id_str" : "725713810909216768",
      "id" : 725713810909216768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJA3bPWwAApgOV.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kex7EhSkeV"
    } ],
    "hashtags" : [ {
      "text" : "CollegeReporterDay",
      "indices" : [ 67, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725719048567283714",
  "text" : "RT @vj44: Great to welcome talented young journalists at our first #CollegeReporterDay! https:\/\/t.co\/kex7EhSkeV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/725713811932504064\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/kex7EhSkeV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJA3bPWwAApgOV.jpg",
        "id_str" : "725713810909216768",
        "id" : 725713810909216768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJA3bPWwAApgOV.jpg",
        "sizes" : [ {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kex7EhSkeV"
      } ],
      "hashtags" : [ {
        "text" : "CollegeReporterDay",
        "indices" : [ 57, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725713811932504064",
    "text" : "Great to welcome talented young journalists at our first #CollegeReporterDay! https:\/\/t.co\/kex7EhSkeV",
    "id" : 725713811932504064,
    "created_at" : "2016-04-28 15:50:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 725719048567283714,
  "created_at" : "2016-04-28 16:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Haider Al-Abadi",
      "screen_name" : "HaiderAlAbadi",
      "indices" : [ 44, 58 ],
      "id_str" : "80817491",
      "id" : 80817491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725716091444428800",
  "text" : "RT @VPLive: The @VP met with Prime Minister @HaiderAlAbadi for nearly 90 minutes today at the Government Palace in Baghdad. https:\/\/t.co\/C9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 4, 7 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Haider Al-Abadi",
        "screen_name" : "HaiderAlAbadi",
        "indices" : [ 32, 46 ],
        "id_str" : "80817491",
        "id" : 80817491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/725713523221868544\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/C9F27cz5uI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChJAmoxUYAEgcdt.jpg",
        "id_str" : "725713522483552257",
        "id" : 725713522483552257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChJAmoxUYAEgcdt.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 964,
          "resize" : "fit",
          "w" : 1444
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/C9F27cz5uI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725713523221868544",
    "text" : "The @VP met with Prime Minister @HaiderAlAbadi for nearly 90 minutes today at the Government Palace in Baghdad. https:\/\/t.co\/C9F27cz5uI",
    "id" : 725713523221868544,
    "created_at" : "2016-04-28 15:49:21 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 725716091444428800,
  "created_at" : "2016-04-28 15:59:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725702174668410881\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/wLPpskbrT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChI2JRiWUAA-HYa.jpg",
      "id_str" : "725702022914265088",
      "id" : 725702022914265088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChI2JRiWUAA-HYa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1165,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1165,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/wLPpskbrT8"
    } ],
    "hashtags" : [ {
      "text" : "AmericaCreates",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/XXR7pSKR3q",
      "expanded_url" : "http:\/\/go.wh.gov\/TheList",
      "display_url" : "go.wh.gov\/TheList"
    } ]
  },
  "geo" : { },
  "id_str" : "725702174668410881",
  "text" : ".@POTUS wrote down a few of his favorite examples of what #AmericaCreates. Here's why \u2192 https:\/\/t.co\/XXR7pSKR3q https:\/\/t.co\/wLPpskbrT8",
  "id" : 725702174668410881,
  "created_at" : "2016-04-28 15:04:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 49, 60 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725700568321167360",
  "text" : "RT @PressSec: We've got college reporters at the @WhiteHouse today! I'll answer their q's &amp; yours too at 5:15pm ET. So ask away using #AskP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 35, 46 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725691900087406592",
    "text" : "We've got college reporters at the @WhiteHouse today! I'll answer their q's &amp; yours too at 5:15pm ET. So ask away using #AskPressSec!",
    "id" : 725691900087406592,
    "created_at" : "2016-04-28 14:23:26 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 725700568321167360,
  "created_at" : "2016-04-28 14:57:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Nathan Deal",
      "screen_name" : "GovernorDeal",
      "indices" : [ 33, 46 ],
      "id_str" : "217416964",
      "id" : 217416964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725458504249569281\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/ONwT9y9vkf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChFW9MLWMAAJAbH.jpg",
      "id_str" : "725456624224186368",
      "id" : 725456624224186368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChFW9MLWMAAJAbH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ONwT9y9vkf"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 61, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725458504249569281",
  "text" : "Congratulations to Georgia &amp; @GovernorDeal on bipartisan #CriminalJusticeReform. Now it's time for Congress to act. https:\/\/t.co\/ONwT9y9vkf",
  "id" : 725458504249569281,
  "created_at" : "2016-04-27 22:56:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725457053272043520\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/yOrxTFJHqO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChFXULTXEAAZlgW.jpg",
      "id_str" : "725457019126353920",
      "id" : 725457019126353920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChFXULTXEAAZlgW.jpg",
      "sizes" : [ {
        "h" : 716,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1221,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 1282
      } ],
      "display_url" : "pic.twitter.com\/yOrxTFJHqO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/NRFqmGYHQK",
      "expanded_url" : "http:\/\/go.wh.gov\/wEzsCU",
      "display_url" : "go.wh.gov\/wEzsCU"
    } ]
  },
  "geo" : { },
  "id_str" : "725457053272043520",
  "text" : "\"I want you to be the first to know that I'm coming to visit Flint on May 4\" \u2014@POTUS: https:\/\/t.co\/NRFqmGYHQK https:\/\/t.co\/yOrxTFJHqO",
  "id" : 725457053272043520,
  "created_at" : "2016-04-27 22:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 18, 28 ],
      "id_str" : "14344823",
      "id" : 14344823
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/QYMNwC0PyS",
      "expanded_url" : "http:\/\/go.wh.gov\/x6kyGt",
      "display_url" : "go.wh.gov\/x6kyGt"
    } ]
  },
  "geo" : { },
  "id_str" : "725456620348526593",
  "text" : "RT @PressSec: The @SenateGOP is setting a dangerous precedent on #SCOTUS. A lesson from Professor @POTUS: https:\/\/t.co\/QYMNwC0PyS https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 4, 14 ],
        "id_str" : "14344823",
        "id" : 14344823
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 84, 90 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/QYMNwC0PyS",
        "expanded_url" : "http:\/\/go.wh.gov\/x6kyGt",
        "display_url" : "go.wh.gov\/x6kyGt"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ebq2yREZG7",
        "expanded_url" : "http:\/\/snpy.tv\/1QAuHlX",
        "display_url" : "snpy.tv\/1QAuHlX"
      } ]
    },
    "geo" : { },
    "id_str" : "725452949858750464",
    "text" : "The @SenateGOP is setting a dangerous precedent on #SCOTUS. A lesson from Professor @POTUS: https:\/\/t.co\/QYMNwC0PyS https:\/\/t.co\/ebq2yREZG7",
    "id" : 725452949858750464,
    "created_at" : "2016-04-27 22:33:56 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 725456620348526593,
  "created_at" : "2016-04-27 22:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 3, 15 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/ntkjgHHPOm",
      "expanded_url" : "http:\/\/bit.ly\/1NxjyYt",
      "display_url" : "bit.ly\/1NxjyYt"
    } ]
  },
  "geo" : { },
  "id_str" : "725451383470743552",
  "text" : "RT @USWomen2016: Here's your chance to attend the #StateOfWomen summit! Nominations are now open: https:\/\/t.co\/ntkjgHHPOm https:\/\/t.co\/CV7z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USWomen2016\/status\/725428787631013888\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/CV7zfcYIBU",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChE9oYMW4AAOzhv.jpg",
        "id_str" : "725428778881703936",
        "id" : 725428778881703936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChE9oYMW4AAOzhv.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CV7zfcYIBU"
      } ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ntkjgHHPOm",
        "expanded_url" : "http:\/\/bit.ly\/1NxjyYt",
        "display_url" : "bit.ly\/1NxjyYt"
      } ]
    },
    "geo" : { },
    "id_str" : "725428787631013888",
    "text" : "Here's your chance to attend the #StateOfWomen summit! Nominations are now open: https:\/\/t.co\/ntkjgHHPOm https:\/\/t.co\/CV7zfcYIBU",
    "id" : 725428787631013888,
    "created_at" : "2016-04-27 20:57:55 +0000",
    "user" : {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "protected" : false,
      "id_str" : "4795344505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692985821901754368\/5UoBC1W1_normal.png",
      "id" : 4795344505,
      "verified" : true
    }
  },
  "id" : 725451383470743552,
  "created_at" : "2016-04-27 22:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 40, 47 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 69, 77 ],
      "id_str" : "21870081",
      "id" : 21870081
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 104, 113 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725441311738761216",
  "text" : "RT @letsmove: Go behind the scenes with @FLOTUS in Times Square with @TeamUSA &amp; add \"WhiteHouse\" on @Snapchat to see more!\nhttps:\/\/t.co\/vmp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 26, 33 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 55, 63 ],
        "id_str" : "21870081",
        "id" : 21870081
      }, {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 90, 99 ],
        "id_str" : "376502929",
        "id" : 376502929
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/vmprsu3RPG",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/4ef039ee-3f23-465e-b598-e809b808ea14",
        "display_url" : "amp.twimg.com\/v\/4ef039ee-3f2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725437655664611328",
    "text" : "Go behind the scenes with @FLOTUS in Times Square with @TeamUSA &amp; add \"WhiteHouse\" on @Snapchat to see more!\nhttps:\/\/t.co\/vmprsu3RPG",
    "id" : 725437655664611328,
    "created_at" : "2016-04-27 21:33:09 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 725441311738761216,
  "created_at" : "2016-04-27 21:47:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wCtiMIKpJ3",
      "expanded_url" : "http:\/\/go.wh.gov\/x6kyGt",
      "display_url" : "go.wh.gov\/x6kyGt"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GYdBdGUd9c",
      "expanded_url" : "http:\/\/snpy.tv\/1QAuHlX",
      "display_url" : "snpy.tv\/1QAuHlX"
    } ]
  },
  "geo" : { },
  "id_str" : "725431969224388608",
  "text" : "A quick lesson from Professor @POTUS on why Senate Republicans must do their job on #SCOTUS: https:\/\/t.co\/wCtiMIKpJ3 https:\/\/t.co\/GYdBdGUd9c",
  "id" : 725431969224388608,
  "created_at" : "2016-04-27 21:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 45, 57 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1coSNioZJt",
      "expanded_url" : "http:\/\/www.unitedstateofwomen.org",
      "display_url" : "unitedstateofwomen.org"
    } ]
  },
  "geo" : { },
  "id_str" : "725418949068873729",
  "text" : "RT @vj44: Nominations are now open to attend @USWomen2016! Here's how you can join us on June 14: https:\/\/t.co\/1coSNioZJt https:\/\/t.co\/cJSL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UnitedStateofWomen",
        "screen_name" : "USWomen2016",
        "indices" : [ 35, 47 ],
        "id_str" : "4795344505",
        "id" : 4795344505
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/1coSNioZJt",
        "expanded_url" : "http:\/\/www.unitedstateofwomen.org",
        "display_url" : "unitedstateofwomen.org"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/cJSLj2Q5p9",
        "expanded_url" : "http:\/\/snpy.tv\/1NUi6KH",
        "display_url" : "snpy.tv\/1NUi6KH"
      } ]
    },
    "geo" : { },
    "id_str" : "725418823684235264",
    "text" : "Nominations are now open to attend @USWomen2016! Here's how you can join us on June 14: https:\/\/t.co\/1coSNioZJt https:\/\/t.co\/cJSLj2Q5p9",
    "id" : 725418823684235264,
    "created_at" : "2016-04-27 20:18:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 725418949068873729,
  "created_at" : "2016-04-27 20:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Navy Football",
      "screen_name" : "NavyFB",
      "indices" : [ 131, 138 ],
      "id_str" : "2429051735",
      "id" : 2429051735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725397831410958336",
  "text" : "\"I will continue to do my best to support all the men and women who have the distinction to wear our nation\u2019s uniform.\" \u2014@POTUS to @NavyFB",
  "id" : 725397831410958336,
  "created_at" : "2016-04-27 18:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Navy Football",
      "screen_name" : "NavyFB",
      "indices" : [ 69, 76 ],
      "id_str" : "2429051735",
      "id" : 2429051735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725397554049982465",
  "text" : "\"These players are just as impressive off the field.\" \u2014@POTUS on the @NavyFB players working for their communities and their country",
  "id" : 725397554049982465,
  "created_at" : "2016-04-27 18:53:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725396636021743617",
  "text" : "RT @WHLive: \"This squad wasn\u2019t just the best service academy on the gridiron this year\u2014it was one of the best teams in America.\" \u2014@POTUS to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 118, 124 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Navy Football",
        "screen_name" : "NavyFB",
        "indices" : [ 128, 135 ],
        "id_str" : "2429051735",
        "id" : 2429051735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725396600344989696",
    "text" : "\"This squad wasn\u2019t just the best service academy on the gridiron this year\u2014it was one of the best teams in America.\" \u2014@POTUS to @NavyFB",
    "id" : 725396600344989696,
    "created_at" : "2016-04-27 18:50:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 725396636021743617,
  "created_at" : "2016-04-27 18:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Navy Football",
      "screen_name" : "NavyFB",
      "indices" : [ 133, 140 ],
      "id_str" : "2429051735",
      "id" : 2429051735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725396320568115201",
  "text" : "\"Navy Football has now won the service-academy rivalry 10 of the last 13 years.\" \u2014@POTUS awarding the Commander-in-Chief's Trophy to @NavyFB",
  "id" : 725396320568115201,
  "created_at" : "2016-04-27 18:48:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Navy Football",
      "screen_name" : "NavyFB",
      "indices" : [ 54, 61 ],
      "id_str" : "2429051735",
      "id" : 2429051735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/kdpz12p352",
      "expanded_url" : "http:\/\/go.wh.gov\/uxMcPa",
      "display_url" : "go.wh.gov\/uxMcPa"
    } ]
  },
  "geo" : { },
  "id_str" : "725396121011535872",
  "text" : "Watch @POTUS award the Commander-in-Chief's Trophy to @NavyFB: https:\/\/t.co\/kdpz12p352",
  "id" : 725396121011535872,
  "created_at" : "2016-04-27 18:48:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wCtiMIsORv",
      "expanded_url" : "http:\/\/go.wh.gov\/x6kyGt",
      "display_url" : "go.wh.gov\/x6kyGt"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/GYdBdHbOxM",
      "expanded_url" : "http:\/\/snpy.tv\/1QAuHlX",
      "display_url" : "snpy.tv\/1QAuHlX"
    } ]
  },
  "geo" : { },
  "id_str" : "725343316162793472",
  "text" : "What will happen if the Senate fails to do its job on #SCOTUS? Professor @POTUS explains \u2192 https:\/\/t.co\/wCtiMIsORv https:\/\/t.co\/GYdBdHbOxM",
  "id" : 725343316162793472,
  "created_at" : "2016-04-27 15:18:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5ReTz6Kkav",
      "expanded_url" : "http:\/\/go.wh.gov\/x6kyGt",
      "display_url" : "go.wh.gov\/x6kyGt"
    } ]
  },
  "geo" : { },
  "id_str" : "725336116505788416",
  "text" : "RT @SCOTUSnom: .@POTUS gives a short lesson on the long-term impacts of failing to fill the #SCOTUS bench \u2192 https:\/\/t.co\/5ReTz6Kkav\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/5ReTz6Kkav",
        "expanded_url" : "http:\/\/go.wh.gov\/x6kyGt",
        "display_url" : "go.wh.gov\/x6kyGt"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3YI89BoIvL",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/f0efc8d5-1ae0-4ada-a66a-818ae46c1334",
        "display_url" : "amp.twimg.com\/v\/f0efc8d5-1ae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725335928898641920",
    "text" : ".@POTUS gives a short lesson on the long-term impacts of failing to fill the #SCOTUS bench \u2192 https:\/\/t.co\/5ReTz6Kkav\nhttps:\/\/t.co\/3YI89BoIvL",
    "id" : 725335928898641920,
    "created_at" : "2016-04-27 14:48:56 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 725336116505788416,
  "created_at" : "2016-04-27 14:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/NRFqmHgjfk",
      "expanded_url" : "http:\/\/go.wh.gov\/wEzsCU",
      "display_url" : "go.wh.gov\/wEzsCU"
    } ]
  },
  "geo" : { },
  "id_str" : "725332610562543616",
  "text" : "Just announced: @POTUS will travel to Flint, Michigan to hear from members of the community: https:\/\/t.co\/NRFqmHgjfk",
  "id" : 725332610562543616,
  "created_at" : "2016-04-27 14:35:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2Iou1LJoHC",
      "expanded_url" : "http:\/\/go.wh.gov\/V7UnjY",
      "display_url" : "go.wh.gov\/V7UnjY"
    } ]
  },
  "geo" : { },
  "id_str" : "725328736334176256",
  "text" : "RT @PressSec: The #Zika virus is an emergency, and the American people are counting on Congress to act. https:\/\/t.co\/2Iou1LJoHC https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 4, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/2Iou1LJoHC",
        "expanded_url" : "http:\/\/go.wh.gov\/V7UnjY",
        "display_url" : "go.wh.gov\/V7UnjY"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/YHESBPRudV",
        "expanded_url" : "http:\/\/snpy.tv\/1NPVwTt",
        "display_url" : "snpy.tv\/1NPVwTt"
      } ]
    },
    "geo" : { },
    "id_str" : "725326722200047617",
    "text" : "The #Zika virus is an emergency, and the American people are counting on Congress to act. https:\/\/t.co\/2Iou1LJoHC https:\/\/t.co\/YHESBPRudV",
    "id" : 725326722200047617,
    "created_at" : "2016-04-27 14:12:21 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 725328736334176256,
  "created_at" : "2016-04-27 14:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725111096496021504\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/HTlIzp32in",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAca5sU4AAtUEh.jpg",
      "id_str" : "725110788495564800",
      "id" : 725110788495564800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAca5sU4AAtUEh.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HTlIzp32in"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/UlZZWcaWLx",
      "expanded_url" : "http:\/\/go.wh.gov\/hR5wup",
      "display_url" : "go.wh.gov\/hR5wup"
    } ]
  },
  "geo" : { },
  "id_str" : "725111096496021504",
  "text" : "Every student should have access to an affordable, high-quality education: https:\/\/t.co\/UlZZWcaWLx #ReachHigher https:\/\/t.co\/HTlIzp32in",
  "id" : 725111096496021504,
  "created_at" : "2016-04-26 23:55:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 95, 104 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 54, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725106034558160896",
  "text" : "RT @FLOTUS: The First Lady is off to NYC to celebrate #CollegeSigningDay!\n\nAdd \"WhiteHouse\" on @Snapchat to follow along along. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 83, 92 ],
        "id_str" : "376502929",
        "id" : 376502929
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/725020794456313860\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/XE55jV6A9o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg_KR_0UoAADYzS.jpg",
        "id_str" : "725020475567415296",
        "id" : 725020475567415296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg_KR_0UoAADYzS.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/XE55jV6A9o"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 42, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725020794456313860",
    "text" : "The First Lady is off to NYC to celebrate #CollegeSigningDay!\n\nAdd \"WhiteHouse\" on @Snapchat to follow along along. https:\/\/t.co\/XE55jV6A9o",
    "id" : 725020794456313860,
    "created_at" : "2016-04-26 17:56:42 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 725106034558160896,
  "created_at" : "2016-04-26 23:35:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shonda rhimes",
      "screen_name" : "shondarhimes",
      "indices" : [ 3, 16 ],
      "id_str" : "17565514",
      "id" : 17565514
    }, {
      "name" : "Dartmouth",
      "screen_name" : "dartmouth",
      "indices" : [ 90, 100 ],
      "id_str" : "21226678",
      "id" : 21226678
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 24, 42 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "BetterMakeRoom",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725104660365844481",
  "text" : "RT @shondarhimes: Happy #CollegeSigningDay, Class of 2020. Here I am on my graduation day @dartmouth! #ReachHigher #BetterMakeRoom https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dartmouth",
        "screen_name" : "dartmouth",
        "indices" : [ 72, 82 ],
        "id_str" : "21226678",
        "id" : 21226678
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shondarhimes\/status\/725057421798842368\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/F1K3mlVQLi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg_r4KxUoAAwMC4.jpg",
        "id_str" : "725057415226368000",
        "id" : 725057415226368000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg_r4KxUoAAwMC4.jpg",
        "sizes" : [ {
          "h" : 1378,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 807,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1613,
          "resize" : "fit",
          "w" : 1199
        } ],
        "display_url" : "pic.twitter.com\/F1K3mlVQLi"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 6, 24 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 84, 96 ]
      }, {
        "text" : "BetterMakeRoom",
        "indices" : [ 97, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725057421798842368",
    "text" : "Happy #CollegeSigningDay, Class of 2020. Here I am on my graduation day @dartmouth! #ReachHigher #BetterMakeRoom https:\/\/t.co\/F1K3mlVQLi",
    "id" : 725057421798842368,
    "created_at" : "2016-04-26 20:22:14 +0000",
    "user" : {
      "name" : "shonda rhimes",
      "screen_name" : "shondarhimes",
      "protected" : false,
      "id_str" : "17565514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770768752858107904\/6gV0N9j9_normal.jpg",
      "id" : 17565514,
      "verified" : true
    }
  },
  "id" : 725104660365844481,
  "created_at" : "2016-04-26 23:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 3, 7 ],
      "id_str" : "2367911",
      "id" : 2367911
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 15, 22 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 53, 63 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 76, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/I7G9UFy9dN",
      "expanded_url" : "http:\/\/on.mtv.com\/1Qz6ZX7",
      "display_url" : "on.mtv.com\/1Qz6ZX7"
    } ]
  },
  "geo" : { },
  "id_str" : "725096702156271620",
  "text" : "RT @MTV: GUYS! @FLOTUS has officially taken over our @Instagram in honor of #CollegeSigningDay \uD83D\uDC9E https:\/\/t.co\/I7G9UFy9dN https:\/\/t.co\/rJDSz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 6, 13 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 44, 54 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MTV\/status\/725070574763003905\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/rJDSz8JQdZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg_32D7WYAERkdL.jpg",
        "id_str" : "725070573169172481",
        "id" : 725070573169172481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg_32D7WYAERkdL.jpg",
        "sizes" : [ {
          "h" : 656,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1170,
          "resize" : "fit",
          "w" : 1070
        }, {
          "h" : 1120,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rJDSz8JQdZ"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 67, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/I7G9UFy9dN",
        "expanded_url" : "http:\/\/on.mtv.com\/1Qz6ZX7",
        "display_url" : "on.mtv.com\/1Qz6ZX7"
      } ]
    },
    "geo" : { },
    "id_str" : "725070574763003905",
    "text" : "GUYS! @FLOTUS has officially taken over our @Instagram in honor of #CollegeSigningDay \uD83D\uDC9E https:\/\/t.co\/I7G9UFy9dN https:\/\/t.co\/rJDSz8JQdZ",
    "id" : 725070574763003905,
    "created_at" : "2016-04-26 21:14:30 +0000",
    "user" : {
      "name" : "MTV",
      "screen_name" : "MTV",
      "protected" : false,
      "id_str" : "2367911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796753394778144768\/IUKITJH1_normal.jpg",
      "id" : 2367911,
      "verified" : true
    }
  },
  "id" : 725096702156271620,
  "created_at" : "2016-04-26 22:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725085687947530240\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2WnYSJ1bHy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAFlY_U8AAtdQi.jpg",
      "id_str" : "725085679928012800",
      "id" : 725085679928012800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAFlY_U8AAtdQi.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2WnYSJ1bHy"
    } ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 5, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/UlZZWbTlmX",
      "expanded_url" : "http:\/\/go.wh.gov\/hR5wup",
      "display_url" : "go.wh.gov\/hR5wup"
    } ]
  },
  "geo" : { },
  "id_str" : "725085687947530240",
  "text" : "It's #CollegeSigningDay\uD83C\uDF93! Here's how we're committed to helping all students go to college \u2192 https:\/\/t.co\/UlZZWbTlmX https:\/\/t.co\/2WnYSJ1bHy",
  "id" : 725085687947530240,
  "created_at" : "2016-04-26 22:14:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/725080936572923904\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2kMpEzGlg2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChABRJwW0AAnKWk.jpg",
      "id_str" : "725080934194794496",
      "id" : 725080934194794496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChABRJwW0AAnKWk.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2kMpEzGlg2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BPmSouctlR",
      "expanded_url" : "http:\/\/go.wh.gov\/U2eP9D",
      "display_url" : "go.wh.gov\/U2eP9D"
    } ]
  },
  "geo" : { },
  "id_str" : "725080936572923904",
  "text" : "Here's how we're helping train workers for the skills they need to earn higher-paying jobs: https:\/\/t.co\/BPmSouctlR https:\/\/t.co\/2kMpEzGlg2",
  "id" : 725080936572923904,
  "created_at" : "2016-04-26 21:55:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 67, 85 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725035489749798912",
  "text" : "RT @FLOTUS: Today we show our college pride in honor of you! Happy #CollegeSigningDay, Class of 2020. \uD83C\uDF93 \uD83C\uDF89 #ReachHigher https:\/\/t.co\/m3yyylB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/725033690707972096\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/m3yyylBoHQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg_V6zqW0AAyrZm.jpg",
        "id_str" : "725033271306932224",
        "id" : 725033271306932224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg_V6zqW0AAyrZm.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/m3yyylBoHQ"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 55, 73 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725033690707972096",
    "text" : "Today we show our college pride in honor of you! Happy #CollegeSigningDay, Class of 2020. \uD83C\uDF93 \uD83C\uDF89 #ReachHigher https:\/\/t.co\/m3yyylBoHQ",
    "id" : 725033690707972096,
    "created_at" : "2016-04-26 18:47:56 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 725035489749798912,
  "created_at" : "2016-04-26 18:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSForAll",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/PSrBS42L8E",
      "expanded_url" : "https:\/\/twitter.com\/Tanchee23\/status\/723522938075529216",
      "display_url" : "twitter.com\/Tanchee23\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725024244770426880",
  "text" : "Thanks to all the teachers who are working to teach our girls and boys to code. #CSForAll https:\/\/t.co\/PSrBS42L8E",
  "id" : 725024244770426880,
  "created_at" : "2016-04-26 18:10:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Mayor Muriel Bowser",
      "screen_name" : "MayorBowser",
      "indices" : [ 20, 32 ],
      "id_str" : "976542720",
      "id" : 976542720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Q3IFwHRrTr",
      "expanded_url" : "https:\/\/twitter.com\/MurielBowser\/status\/725014576643842048",
      "display_url" : "twitter.com\/MurielBowser\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725021072165314561",
  "text" : "RT @vj44: Big news: @MayorBowser stopped by Virginia's home with a new ID. Think they danced together too?  https:\/\/t.co\/Q3IFwHRrTr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Muriel Bowser",
        "screen_name" : "MayorBowser",
        "indices" : [ 10, 22 ],
        "id_str" : "976542720",
        "id" : 976542720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/Q3IFwHRrTr",
        "expanded_url" : "https:\/\/twitter.com\/MurielBowser\/status\/725014576643842048",
        "display_url" : "twitter.com\/MurielBowser\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725019230576500737",
    "text" : "Big news: @MayorBowser stopped by Virginia's home with a new ID. Think they danced together too?  https:\/\/t.co\/Q3IFwHRrTr",
    "id" : 725019230576500737,
    "created_at" : "2016-04-26 17:50:29 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 725021072165314561,
  "created_at" : "2016-04-26 17:57:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 19, 37 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724991784166801409",
  "text" : "RT @usedgov: Happy #CollegeSigningDay! Congrats to all students making important decisions for their future today. #ReachHigher https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/724991228308258816\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/0FncgnqD3T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-vn_8WwAA5gJD.jpg",
        "id_str" : "724991166744281088",
        "id" : 724991166744281088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-vn_8WwAA5gJD.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0FncgnqD3T"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 6, 24 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724991228308258816",
    "text" : "Happy #CollegeSigningDay! Congrats to all students making important decisions for their future today. #ReachHigher https:\/\/t.co\/0FncgnqD3T",
    "id" : 724991228308258816,
    "created_at" : "2016-04-26 15:59:13 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 724991784166801409,
  "created_at" : "2016-04-26 16:01:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karlie Kloss",
      "screen_name" : "karliekloss",
      "indices" : [ 3, 15 ],
      "id_str" : "28412286",
      "id" : 28412286
    }, {
      "name" : "New York University",
      "screen_name" : "nyuniversity",
      "indices" : [ 59, 72 ],
      "id_str" : "28421825",
      "id" : 28421825
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 23, 41 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724986797030182917",
  "text" : "RT @karliekloss: Happy #CollegeSigningDay! Throwback to my @nyuniversity acceptance. Celebrate yours &amp; show the\uD83C\uDF0E how you #ReachHigher https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New York University",
        "screen_name" : "nyuniversity",
        "indices" : [ 42, 55 ],
        "id_str" : "28421825",
        "id" : 28421825
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/karliekloss\/status\/724980096977784832\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/YoP3Gi5UJr",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg-lQ8qW0AEfvtQ.jpg",
        "id_str" : "724979775610212353",
        "id" : 724979775610212353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg-lQ8qW0AEfvtQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/YoP3Gi5UJr"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 6, 24 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724980096977784832",
    "text" : "Happy #CollegeSigningDay! Throwback to my @nyuniversity acceptance. Celebrate yours &amp; show the\uD83C\uDF0E how you #ReachHigher https:\/\/t.co\/YoP3Gi5UJr",
    "id" : 724980096977784832,
    "created_at" : "2016-04-26 15:14:59 +0000",
    "user" : {
      "name" : "Karlie Kloss",
      "screen_name" : "karliekloss",
      "protected" : false,
      "id_str" : "28412286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711979086210539520\/AOh5fBuR_normal.jpg",
      "id" : 28412286,
      "verified" : true
    }
  },
  "id" : 724986797030182917,
  "created_at" : "2016-04-26 15:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/724975196889862145\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ABoQTDE5wR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-hGazWwAAt1yV.jpg",
      "id_str" : "724975196675948544",
      "id" : 724975196675948544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-hGazWwAAt1yV.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ABoQTDE5wR"
    } ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 29, 34 ]
    }, {
      "text" : "CollegeSigningDay",
      "indices" : [ 56, 74 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724985356479664129",
  "text" : "RT @ErnestMoniz: A degree in #STEM can take you places. #CollegeSigningDay #ReachHigher https:\/\/t.co\/ABoQTDE5wR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/724975196889862145\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/ABoQTDE5wR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-hGazWwAAt1yV.jpg",
        "id_str" : "724975196675948544",
        "id" : 724975196675948544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-hGazWwAAt1yV.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ABoQTDE5wR"
      } ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "CollegeSigningDay",
        "indices" : [ 39, 57 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724975196889862145",
    "text" : "A degree in #STEM can take you places. #CollegeSigningDay #ReachHigher https:\/\/t.co\/ABoQTDE5wR",
    "id" : 724975196889862145,
    "created_at" : "2016-04-26 14:55:30 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 724985356479664129,
  "created_at" : "2016-04-26 15:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/724964450965540864\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6eXUD8m6C6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-W8DLVEAABmeb.jpg",
      "id_str" : "724964023419080704",
      "id" : 724964023419080704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-W8DLVEAABmeb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6eXUD8m6C6"
    } ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724970050147504129",
  "text" : "RT @FLOTUS: Happy #CollegeSigningDay! Wear your college gear with pride and show us how you #ReachHigher \uD83C\uDF93 https:\/\/t.co\/6eXUD8m6C6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/724964450965540864\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/6eXUD8m6C6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-W8DLVEAABmeb.jpg",
        "id_str" : "724964023419080704",
        "id" : 724964023419080704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-W8DLVEAABmeb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6eXUD8m6C6"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 6, 24 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724964450965540864",
    "text" : "Happy #CollegeSigningDay! Wear your college gear with pride and show us how you #ReachHigher \uD83C\uDF93 https:\/\/t.co\/6eXUD8m6C6",
    "id" : 724964450965540864,
    "created_at" : "2016-04-26 14:12:48 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 724970050147504129,
  "created_at" : "2016-04-26 14:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724944457771053056",
  "text" : "RT @Denis44: States preparing for Zika need Congress to pass POTUS's request for additional funding. Now. As the emergency it is. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/OCnEtlSqmJ",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/to-your-health\/wp\/2016\/04\/25\/zika-funding-battle-steals-states-public-health-emergency-money\/",
        "display_url" : "washingtonpost.com\/news\/to-your-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724943321156734981",
    "text" : "States preparing for Zika need Congress to pass POTUS's request for additional funding. Now. As the emergency it is. https:\/\/t.co\/OCnEtlSqmJ",
    "id" : 724943321156734981,
    "created_at" : "2016-04-26 12:48:51 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 724944457771053056,
  "created_at" : "2016-04-26 12:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/724738191270514688\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/nxpoboZHGl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg7JLcoU4AAhUYx.jpg",
      "id_str" : "724737788554305536",
      "id" : 724737788554305536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg7JLcoU4AAhUYx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nxpoboZHGl"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 39, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/6gGrkbsdgw",
      "expanded_url" : "http:\/\/go.wh.gov\/ChNCPQ",
      "display_url" : "go.wh.gov\/ChNCPQ"
    } ]
  },
  "geo" : { },
  "id_str" : "724738191270514688",
  "text" : "Here's how @POTUS is helping to expand #FreeCommunityCollege to nearly 40,0000 Americans: https:\/\/t.co\/6gGrkbsdgw https:\/\/t.co\/nxpoboZHGl",
  "id" : 724738191270514688,
  "created_at" : "2016-04-25 23:13:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 86, 89 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724728123569389568",
  "text" : "RT @SCOTUSnom: Q: What happens if a #SCOTUS decision results in a 4-4 tie? \n\nA: Watch @VP explain why we need a full Court:  https:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 71, 74 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 21, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/1aS7GkC4hm",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/2fa50a48-ce91-4811-8f56-5dd3b78bc8a1",
        "display_url" : "amp.twimg.com\/v\/2fa50a48-ce9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724666167353217024",
    "text" : "Q: What happens if a #SCOTUS decision results in a 4-4 tie? \n\nA: Watch @VP explain why we need a full Court:  https:\/\/t.co\/1aS7GkC4hm",
    "id" : 724666167353217024,
    "created_at" : "2016-04-25 18:27:32 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 724728123569389568,
  "created_at" : "2016-04-25 22:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724726834349379584",
  "text" : "RT @Denis44: $12\/hr minimum wage is a smarter way to fight crime than spending add'l $10bn on incarceration. From new CEA report: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Z6n0qNmt5b",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/sites\/default\/files\/page\/files\/20160423_cea_incarceration_criminal_justice.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724676287592325121",
    "text" : "$12\/hr minimum wage is a smarter way to fight crime than spending add'l $10bn on incarceration. From new CEA report: https:\/\/t.co\/Z6n0qNmt5b",
    "id" : 724676287592325121,
    "created_at" : "2016-04-25 19:07:45 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 724726834349379584,
  "created_at" : "2016-04-25 22:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 17, 20 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 27, 35 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/724711691120988161\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/8VicuX0Imf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg6xZKYWsAA2H1Y.jpg",
      "id_str" : "724711635894579200",
      "id" : 724711635894579200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg6xZKYWsAA2H1Y.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8VicuX0Imf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/6gGrkbsdgw",
      "expanded_url" : "http:\/\/go.wh.gov\/ChNCPQ",
      "display_url" : "go.wh.gov\/ChNCPQ"
    } ]
  },
  "geo" : { },
  "id_str" : "724711691120988161",
  "text" : "Good news: Today @VP &amp; @DrBiden announced new investments to expand tuition-free training \u2192 https:\/\/t.co\/6gGrkbsdgw https:\/\/t.co\/8VicuX0Imf",
  "id" : 724711691120988161,
  "created_at" : "2016-04-25 21:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/724691111806177280\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/764f1DQj0u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg6emgAUoAE1Oky.jpg",
      "id_str" : "724690974316732417",
      "id" : 724690974316732417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg6emgAUoAE1Oky.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/764f1DQj0u"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 11, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/6gGrkbsdgw",
      "expanded_url" : "http:\/\/go.wh.gov\/ChNCPQ",
      "display_url" : "go.wh.gov\/ChNCPQ"
    } ]
  },
  "geo" : { },
  "id_str" : "724691111806177280",
  "text" : "Let's make #FreeCommunityCollege a reality for every student willing to work for it \u2192 https:\/\/t.co\/6gGrkbsdgw https:\/\/t.co\/764f1DQj0u",
  "id" : 724691111806177280,
  "created_at" : "2016-04-25 20:06:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 28, 31 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 36, 44 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUpAmerica",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724685536259149824",
  "text" : "RT @USDOL: #HeadsUpAmerica: @VP and @DrBiden just introduced a community college investment to expand education and training. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 17, 20 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 25, 33 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HeadsUpAmerica",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/12axEbz5NQ",
        "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/why-we-re-heading-back-to-philadelphia-today-ccd7e3c7309a#.qrwcyzo6g",
        "display_url" : "medium.com\/@VPOTUS\/why-we\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724679424646459393",
    "text" : "#HeadsUpAmerica: @VP and @DrBiden just introduced a community college investment to expand education and training. https:\/\/t.co\/12axEbz5NQ",
    "id" : 724679424646459393,
    "created_at" : "2016-04-25 19:20:13 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 724685536259149824,
  "created_at" : "2016-04-25 19:44:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 105, 108 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2V5iOiKLdD",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/2fa50a48-ce91-4811-8f56-5dd3b78bc8a1",
      "display_url" : "amp.twimg.com\/v\/2fa50a48-ce9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724664993350848512",
  "text" : "\"Not to let the constitution function is totally irresponsible and it's never happened this way before\" \u2014@VP #SCOTUS https:\/\/t.co\/2V5iOiKLdD",
  "id" : 724664993350848512,
  "created_at" : "2016-04-25 18:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 37, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724659125150314496",
  "text" : "RT @DrBiden: Since @POTUS called for #FreeCommunityCollege, over 25 communities have stepped up. Join them \u2192 HeadsUpAmerica.us https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreeCommunityCollege",
        "indices" : [ 24, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/XqLyt9RijY",
        "expanded_url" : "https:\/\/twitter.com\/HeadsUp_America\/status\/724576842993168384",
        "display_url" : "twitter.com\/HeadsUp_Americ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724593044528443393",
    "text" : "Since @POTUS called for #FreeCommunityCollege, over 25 communities have stepped up. Join them \u2192 HeadsUpAmerica.us https:\/\/t.co\/XqLyt9RijY",
    "id" : 724593044528443393,
    "created_at" : "2016-04-25 13:36:58 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 724659125150314496,
  "created_at" : "2016-04-25 17:59:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/AlwMWEAYoI",
      "expanded_url" : "http:\/\/snpy.tv\/1VxPY80",
      "display_url" : "snpy.tv\/1VxPY80"
    } ]
  },
  "geo" : { },
  "id_str" : "724656590930857984",
  "text" : "\"We have to uphold our values, not just when it\u2019s easy, but when it\u2019s hard.\" \u2014@POTUS to the people of Europe: https:\/\/t.co\/AlwMWEAYoI",
  "id" : 724656590930857984,
  "created_at" : "2016-04-25 17:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/c2seA1ExWW",
      "expanded_url" : "http:\/\/snpy.tv\/1NJNbjT",
      "display_url" : "snpy.tv\/1NJNbjT"
    } ]
  },
  "geo" : { },
  "id_str" : "724389170542743553",
  "text" : "3 nations. 7 days. \nGo behind the scenes during @POTUS's trip abroad in this #WestWingWeek: https:\/\/t.co\/c2seA1ExWW",
  "id" : 724389170542743553,
  "created_at" : "2016-04-25 00:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/724315760730869760\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RbV6MMIKeF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg1BLusU8AAMHPO.jpg",
      "id_str" : "724306784844836864",
      "id" : 724306784844836864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg1BLusU8AAMHPO.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RbV6MMIKeF"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 90, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724315760730869760",
  "text" : "FACT: America has more people in prison than any other developed country. \n\nIt's time for #CriminalJusticeReform. https:\/\/t.co\/RbV6MMIKeF",
  "id" : 724315760730869760,
  "created_at" : "2016-04-24 19:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/eMvCr2FSir",
      "expanded_url" : "http:\/\/Wh.gov\/ISIL",
      "display_url" : "Wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "724295676293746688",
  "text" : "RT @NSC44: \u201CGermany is a vital member of the coalition to destroy ISIL\u201D-@POTUS with Chancellor Merkel. \nhttps:\/\/t.co\/eMvCr2FSir https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 61, 67 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/724254264080654336\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/jxALbcuxnx",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg0RWdnVEAAXN3P.jpg",
        "id_str" : "724254192680898560",
        "id" : 724254192680898560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg0RWdnVEAAXN3P.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jxALbcuxnx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/eMvCr2FSir",
        "expanded_url" : "http:\/\/Wh.gov\/ISIL",
        "display_url" : "Wh.gov\/ISIL"
      } ]
    },
    "geo" : { },
    "id_str" : "724254264080654336",
    "text" : "\u201CGermany is a vital member of the coalition to destroy ISIL\u201D-@POTUS with Chancellor Merkel. \nhttps:\/\/t.co\/eMvCr2FSir https:\/\/t.co\/jxALbcuxnx",
    "id" : 724254264080654336,
    "created_at" : "2016-04-24 15:10:47 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 724295676293746688,
  "created_at" : "2016-04-24 17:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QE0nIBIhAn",
      "expanded_url" : "http:\/\/snpy.tv\/1VvYLav",
      "display_url" : "snpy.tv\/1VvYLav"
    } ]
  },
  "geo" : { },
  "id_str" : "724292212373237764",
  "text" : "\"Given the urgency of climate change, our nations have signed the Paris climate change agreement\" \u2014@POTUS in Germany https:\/\/t.co\/QE0nIBIhAn",
  "id" : 724292212373237764,
  "created_at" : "2016-04-24 17:41:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/724191675854114817\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bkY09Rx1KO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgzYebMWYAAijB0.jpg",
      "id_str" : "724191657307037696",
      "id" : 724191657307037696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgzYebMWYAAijB0.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bkY09Rx1KO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724281002957242368",
  "text" : "RT @PressSec: A snowy welcome for @POTUS at the airport in Hannover, Germany. Two days of economic mtgs on tap. https:\/\/t.co\/bkY09Rx1KO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 20, 26 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/724191675854114817\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/bkY09Rx1KO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgzYebMWYAAijB0.jpg",
        "id_str" : "724191657307037696",
        "id" : 724191657307037696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgzYebMWYAAijB0.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bkY09Rx1KO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724191675854114817",
    "text" : "A snowy welcome for @POTUS at the airport in Hannover, Germany. Two days of economic mtgs on tap. https:\/\/t.co\/bkY09Rx1KO",
    "id" : 724191675854114817,
    "created_at" : "2016-04-24 11:02:05 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 724281002957242368,
  "created_at" : "2016-04-24 16:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/724276581145829376\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/UA8tjLpRyd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg0ltaaWMAAdpjk.jpg",
      "id_str" : "724276577190686720",
      "id" : 724276577190686720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg0ltaaWMAAdpjk.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UA8tjLpRyd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/fcgqxCDQAH",
      "expanded_url" : "http:\/\/go.wh.gov\/rySHZ5",
      "display_url" : "go.wh.gov\/rySHZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "724276581145829376",
  "text" : "Here's why @POTUS is working to make our justice system smarter, fairer, and more effective: https:\/\/t.co\/fcgqxCDQAH https:\/\/t.co\/UA8tjLpRyd",
  "id" : 724276581145829376,
  "created_at" : "2016-04-24 16:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 94, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/K3Sy1vDMI4",
      "expanded_url" : "http:\/\/go.wh.gov\/wWfLa4",
      "display_url" : "go.wh.gov\/wWfLa4"
    } ]
  },
  "geo" : { },
  "id_str" : "723953859790401537",
  "text" : "More than 600,000 people leave prison each year. We can help them prepare to reenter society. #CriminalJusticeReform https:\/\/t.co\/K3Sy1vDMI4",
  "id" : 723953859790401537,
  "created_at" : "2016-04-23 19:17:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 84, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/K3Sy1vDMI4",
      "expanded_url" : "http:\/\/go.wh.gov\/wWfLa4",
      "display_url" : "go.wh.gov\/wWfLa4"
    } ]
  },
  "geo" : { },
  "id_str" : "723934581137666048",
  "text" : ".@POTUS lays out a few of the steps we're taking to create a fairer justice system. #CriminalJusticeReform https:\/\/t.co\/K3Sy1vDMI4",
  "id" : 723934581137666048,
  "created_at" : "2016-04-23 18:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723919646299037697\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/j4DEMRUhFo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cguw6wYUkAUbEuO.jpg",
      "id_str" : "723866688588910597",
      "id" : 723866688588910597,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cguw6wYUkAUbEuO.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/j4DEMRUhFo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/fcgqxCDQAH",
      "expanded_url" : "http:\/\/go.wh.gov\/rySHZ5",
      "display_url" : "go.wh.gov\/rySHZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "723919646299037697",
  "text" : "FACT: State prison spending has grown faster than education spending. Let's fix that. https:\/\/t.co\/fcgqxCDQAH https:\/\/t.co\/j4DEMRUhFo",
  "id" : 723919646299037697,
  "created_at" : "2016-04-23 17:01:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 93, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/K3Sy1vDMI4",
      "expanded_url" : "http:\/\/go.wh.gov\/wWfLa4",
      "display_url" : "go.wh.gov\/wWfLa4"
    } ]
  },
  "geo" : { },
  "id_str" : "723909333864435712",
  "text" : "\"We spend $80 billion taxpayer dollars each year to keep people locked up\" \u2014@POTUS calls for #CriminalJusticeReform https:\/\/t.co\/K3Sy1vDMI4",
  "id" : 723909333864435712,
  "created_at" : "2016-04-23 16:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 82, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/K3Sy1vDMI4",
      "expanded_url" : "http:\/\/go.wh.gov\/wWfLa4",
      "display_url" : "go.wh.gov\/wWfLa4"
    } ]
  },
  "geo" : { },
  "id_str" : "723896782875287553",
  "text" : "America has more people in prison than any other developed country. It's time for #CriminalJusticeReform. https:\/\/t.co\/K3Sy1vDMI4",
  "id" : 723896782875287553,
  "created_at" : "2016-04-23 15:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 43, 52 ],
      "id_str" : "376502929",
      "id" : 376502929
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shakespeare400",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/1BNAJodvvt",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/5f8290c0-b821-4a8b-8d44-d18f8c51cd98",
      "display_url" : "amp.twimg.com\/v\/5f8290c0-b82\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723877200580079617",
  "text" : "\"To be, or not to be\u2026\"\nAdd \"WhiteHouse\" on @Snapchat to watch @POTUS drop by the Globe Theatre. #Shakespeare400\nhttps:\/\/t.co\/1BNAJodvvt",
  "id" : 723877200580079617,
  "created_at" : "2016-04-23 14:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/n2XEgzHpFv",
      "expanded_url" : "http:\/\/snpy.tv\/1VJsJZ3",
      "display_url" : "snpy.tv\/1VJsJZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "723874254312230912",
  "text" : "\"Know that progress is possible, that our problems can be solved.\" \u2014@POTUS message to young people https:\/\/t.co\/n2XEgzHpFv",
  "id" : 723874254312230912,
  "created_at" : "2016-04-23 14:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/n2XEgzHpFv",
      "expanded_url" : "http:\/\/snpy.tv\/1VJsJZ3",
      "display_url" : "snpy.tv\/1VJsJZ3"
    } ]
  },
  "geo" : { },
  "id_str" : "723865378506469376",
  "text" : "\"Your capacity to shape this world is unmatched\" \u2014@POTUS  message to young people during a town hall in London https:\/\/t.co\/n2XEgzHpFv",
  "id" : 723865378506469376,
  "created_at" : "2016-04-23 13:25:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shakespeare400",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bKEA9ZIt1l",
      "expanded_url" : "http:\/\/snpy.tv\/1Sq8oBG",
      "display_url" : "snpy.tv\/1Sq8oBG"
    } ]
  },
  "geo" : { },
  "id_str" : "723858542273257472",
  "text" : "Watch @POTUS talk about his visit to the Globe Theatre during a town hall in London this morning. #Shakespeare400 https:\/\/t.co\/bKEA9ZIt1l",
  "id" : 723858542273257472,
  "created_at" : "2016-04-23 12:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shakespeare400",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723856672247152640",
  "text" : "RT @PressSec: All the world's a stage. POTUS visited the Globe Theatre this am for a special tour &amp; performance. #Shakespeare400 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/723845766242951168\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/3dC5vf2OwG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgud2KxUgAEabTz.jpg",
        "id_str" : "723845719052812289",
        "id" : 723845719052812289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgud2KxUgAEabTz.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3dC5vf2OwG"
      } ],
      "hashtags" : [ {
        "text" : "Shakespeare400",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723845766242951168",
    "text" : "All the world's a stage. POTUS visited the Globe Theatre this am for a special tour &amp; performance. #Shakespeare400 https:\/\/t.co\/3dC5vf2OwG",
    "id" : 723845766242951168,
    "created_at" : "2016-04-23 12:07:33 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 723856672247152640,
  "created_at" : "2016-04-23 12:50:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/sNXyuhywjY",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "723806169756667905",
  "text" : "At 5:45am ET, watch @POTUS hold a town hall discussion in London: https:\/\/t.co\/sNXyuhywjY",
  "id" : 723806169756667905,
  "created_at" : "2016-04-23 09:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723684692805980162\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/NiZ7yH7Mzc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgsLFTzUgAEeegf.jpg",
      "id_str" : "723684350965874689",
      "id" : 723684350965874689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgsLFTzUgAEeegf.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NiZ7yH7Mzc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/QYjEycSGPG",
      "expanded_url" : "http:\/\/go.wh.gov\/p3zmRe",
      "display_url" : "go.wh.gov\/p3zmRe"
    } ]
  },
  "geo" : { },
  "id_str" : "723684692805980162",
  "text" : "\"Michelle and I send our best wishes to everyone celebrating Pesach\" \u2014@POTUS: https:\/\/t.co\/QYjEycSGPG https:\/\/t.co\/NiZ7yH7Mzc",
  "id" : 723684692805980162,
  "created_at" : "2016-04-23 01:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723649185787064320\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/AxsDa5x4gk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrrFBPWkAEXmUx.jpg",
      "id_str" : "723649161611087873",
      "id" : 723649161611087873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrrFBPWkAEXmUx.jpg",
      "sizes" : [ {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AxsDa5x4gk"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723649185787064320",
  "text" : "#ObamaAndKids across the pond. https:\/\/t.co\/AxsDa5x4gk",
  "id" : 723649185787064320,
  "created_at" : "2016-04-22 23:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723640079311208449\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/R3RIsKWWVU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgrbC_ZWsAQ3VGP.jpg",
      "id_str" : "723631534570385412",
      "id" : 723631534570385412,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgrbC_ZWsAQ3VGP.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R3RIsKWWVU"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723640079311208449",
  "text" : "\"We can be more confident that we'll leave our children a planet worthy of their promise.\" \u2014@POTUS #ParisAgreement https:\/\/t.co\/R3RIsKWWVU",
  "id" : 723640079311208449,
  "created_at" : "2016-04-22 22:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/723636284346880001\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/6cqEgIwlDo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrZ7CeWsAAwFoS.jpg",
      "id_str" : "723630298446082048",
      "id" : 723630298446082048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrZ7CeWsAAwFoS.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/6cqEgIwlDo"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 36, 49 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/DK9rdytjru",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    } ]
  },
  "geo" : { },
  "id_str" : "723636284346880001",
  "text" : "RT if you agree: The time is now to #ActOnClimate \u2192 https:\/\/t.co\/DK9rdytjru #EarthDay https:\/\/t.co\/6cqEgIwlDo",
  "id" : 723636284346880001,
  "created_at" : "2016-04-22 22:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723629912846782465\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/vyNT2jNLQO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrZQKnXEAAe0RO.jpg",
      "id_str" : "723629561896964096",
      "id" : 723629561896964096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrZQKnXEAAe0RO.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/vyNT2jNLQO"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723629912846782465",
  "text" : "For our planet,\nOur children,\nOur future:\nOn #EarthDay, let's recommit ourselves to #ActOnClimate. https:\/\/t.co\/vyNT2jNLQO",
  "id" : 723629912846782465,
  "created_at" : "2016-04-22 21:49:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723623692744294401\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7kIf2oE6Tt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgrSyQNW0AEoeI6.jpg",
      "id_str" : "723622450932666369",
      "id" : 723622450932666369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgrSyQNW0AEoeI6.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/7kIf2oE6Tt"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/1RDyrjG7DA",
      "expanded_url" : "http:\/\/go.wh.gov\/Y7uQCp",
      "display_url" : "go.wh.gov\/Y7uQCp"
    } ]
  },
  "geo" : { },
  "id_str" : "723623692744294401",
  "text" : "Here's why the #ParisAgreement marked a turning point to save the one planet we\u2019ve got: https:\/\/t.co\/1RDyrjG7DA https:\/\/t.co\/7kIf2oE6Tt",
  "id" : 723623692744294401,
  "created_at" : "2016-04-22 21:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723618989344198658\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/GOzbmPmjDE",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgrPbPYW0AAMmcr.jpg",
      "id_str" : "723618757038493696",
      "id" : 723618757038493696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgrPbPYW0AAMmcr.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GOzbmPmjDE"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 86, 101 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723618989344198658",
  "text" : "\"Today, America is leading the fight against climate change.\" \u2014@POTUS on the historic #ParisAgreement on #EarthDay https:\/\/t.co\/GOzbmPmjDE",
  "id" : 723618989344198658,
  "created_at" : "2016-04-22 21:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 3, 12 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/DK9rdyKUQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2eODM191xd",
      "expanded_url" : "http:\/\/snpy.tv\/1VHQkJu",
      "display_url" : "snpy.tv\/1VHQkJu"
    } ]
  },
  "geo" : { },
  "id_str" : "723615763425275904",
  "text" : "On #EarthDay\uD83C\uDF0E, let's continue to #ActOnClimate to protect its beauty for future generations: https:\/\/t.co\/DK9rdyKUQ4 https:\/\/t.co\/2eODM191xd",
  "id" : 723615763425275904,
  "created_at" : "2016-04-22 20:53:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723613927871934466",
  "text" : "RT @VP: Paris Agreement signed. Means a cleaner environment, stronger economy, and better future for our kids. And we led the way. Happy #E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "675781019102932992",
    "geo" : { },
    "id_str" : "723570447556562944",
    "in_reply_to_user_id" : 325830217,
    "text" : "Paris Agreement signed. Means a cleaner environment, stronger economy, and better future for our kids. And we led the way. Happy #EarthDay.",
    "id" : 723570447556562944,
    "in_reply_to_status_id" : 675781019102932992,
    "created_at" : "2016-04-22 17:53:32 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 723613927871934466,
  "created_at" : "2016-04-22 20:46:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723591550501027840\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/E1VoZubxq2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgq2l4PWMAAKEew.jpg",
      "id_str" : "723591452014555136",
      "id" : 723591452014555136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgq2l4PWMAAKEew.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/E1VoZubxq2"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 22, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Xy7jCAUuEk",
      "expanded_url" : "http:\/\/go.wh.gov\/FacesofMBK",
      "display_url" : "go.wh.gov\/FacesofMBK"
    } ]
  },
  "geo" : { },
  "id_str" : "723591550501027840",
  "text" : "Meet the young men of #MyBrothersKeeper who overcame barriers &amp; are achieving their dreams: https:\/\/t.co\/Xy7jCAUuEk https:\/\/t.co\/E1VoZubxq2",
  "id" : 723591550501027840,
  "created_at" : "2016-04-22 19:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "indices" : [ 3, 19 ],
      "id_str" : "2812768561",
      "id" : 2812768561
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 78, 85 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KensingtonRoyal\/status\/723579867065929728\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/zrlimthPsP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqsBA0XEAEIvvN.jpg",
      "id_str" : "723579823545847809",
      "id" : 723579823545847809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqsBA0XEAEIvvN.jpg",
      "sizes" : [ {
        "h" : 711,
        "resize" : "fit",
        "w" : 1064
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zrlimthPsP"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/KensingtonRoyal\/status\/723579867065929728\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/zrlimthPsP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqsB78WYAATUi4.jpg",
      "id_str" : "723579839417049088",
      "id" : 723579839417049088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqsB78WYAATUi4.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1616
      } ],
      "display_url" : "pic.twitter.com\/zrlimthPsP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723582948662894593",
  "text" : "RT @KensingtonRoyal: The Duke and Duchess and Prince Harry welcome @POTUS and @FLOTUS to Kensington Palace https:\/\/t.co\/zrlimthPsP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 46, 52 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 57, 64 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KensingtonRoyal\/status\/723579867065929728\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/zrlimthPsP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqsBA0XEAEIvvN.jpg",
        "id_str" : "723579823545847809",
        "id" : 723579823545847809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqsBA0XEAEIvvN.jpg",
        "sizes" : [ {
          "h" : 711,
          "resize" : "fit",
          "w" : 1064
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zrlimthPsP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KensingtonRoyal\/status\/723579867065929728\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/zrlimthPsP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqsB78WYAATUi4.jpg",
        "id_str" : "723579839417049088",
        "id" : 723579839417049088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqsB78WYAATUi4.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1616
        } ],
        "display_url" : "pic.twitter.com\/zrlimthPsP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723579867065929728",
    "text" : "The Duke and Duchess and Prince Harry welcome @POTUS and @FLOTUS to Kensington Palace https:\/\/t.co\/zrlimthPsP",
    "id" : 723579867065929728,
    "created_at" : "2016-04-22 18:30:58 +0000",
    "user" : {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "protected" : false,
      "id_str" : "2812768561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798099622455640065\/4XELymPa_normal.jpg",
      "id" : 2812768561,
      "verified" : true
    }
  },
  "id" : 723582948662894593,
  "created_at" : "2016-04-22 18:43:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723568545108516864",
  "text" : "RT @POTUS: Today, the US joined some 170 nations to sign the Paris Agreement - an historic step this Earth Day to protect the one planet we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723568187447500800",
    "text" : "Today, the US joined some 170 nations to sign the Paris Agreement - an historic step this Earth Day to protect the one planet we've got.",
    "id" : 723568187447500800,
    "created_at" : "2016-04-22 17:44:33 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 723568545108516864,
  "created_at" : "2016-04-22 17:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Prince",
      "screen_name" : "prince",
      "indices" : [ 86, 93 ],
      "id_str" : "3065429605",
      "id" : 3065429605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/N8ic41JXkE",
      "expanded_url" : "http:\/\/snpy.tv\/1ppDVey",
      "display_url" : "snpy.tv\/1ppDVey"
    } ]
  },
  "geo" : { },
  "id_str" : "723560929196003328",
  "text" : "\"This morning we played Purple Rain and Delirious\" \u2014@POTUS comments on the passing of @Prince https:\/\/t.co\/N8ic41JXkE",
  "id" : 723560929196003328,
  "created_at" : "2016-04-22 17:15:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/71MlPQerc2",
      "expanded_url" : "http:\/\/snpy.tv\/1SoH1rE",
      "display_url" : "snpy.tv\/1SoH1rE"
    } ]
  },
  "geo" : { },
  "id_str" : "723557895879561220",
  "text" : ".@POTUS on where he keeps the Winston Churchill bust in the White House\u2014and why: https:\/\/t.co\/71MlPQerc2",
  "id" : 723557895879561220,
  "created_at" : "2016-04-22 17:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 37, 40 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "ParisAgreement",
      "indices" : [ 52, 67 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723556159077113856",
  "text" : "RT @JohnKerry: Historic #EarthDay at @UN as we sign #ParisAgreement on #climatechange. We must sustain this forward momentum. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 22, 25 ],
        "id_str" : "14159148",
        "id" : 14159148
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/723545064069324802\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/ALPwD7mqE7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqMXv_WkAAE-hr.jpg",
        "id_str" : "723545029793452032",
        "id" : 723545029793452032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqMXv_WkAAE-hr.jpg",
        "sizes" : [ {
          "h" : 1354,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ALPwD7mqE7"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 9, 18 ]
      }, {
        "text" : "ParisAgreement",
        "indices" : [ 37, 52 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 56, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723545064069324802",
    "text" : "Historic #EarthDay at @UN as we sign #ParisAgreement on #climatechange. We must sustain this forward momentum. https:\/\/t.co\/ALPwD7mqE7",
    "id" : 723545064069324802,
    "created_at" : "2016-04-22 16:12:40 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 723556159077113856,
  "created_at" : "2016-04-22 16:56:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 51, 64 ]
    }, {
      "text" : "ParisAgreement",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7ha4yJhjuZ",
      "expanded_url" : "http:\/\/snpy.tv\/1SoDGsw",
      "display_url" : "snpy.tv\/1SoDGsw"
    } ]
  },
  "geo" : { },
  "id_str" : "723553944232955908",
  "text" : "Today, about 170 countries took a historic step to #ActOnClimate. Watch @POTUS speak on the #ParisAgreement:  https:\/\/t.co\/7ha4yJhjuZ",
  "id" : 723553944232955908,
  "created_at" : "2016-04-22 16:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInUK",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7ha4yJhjuZ",
      "expanded_url" : "http:\/\/snpy.tv\/1SoDGsw",
      "display_url" : "snpy.tv\/1SoDGsw"
    } ]
  },
  "geo" : { },
  "id_str" : "723549615614767104",
  "text" : "\u201CThe Queen has been a source of inspiration for me, like so many people around the world.\u201D \u2014@POTUS #ObamaInUK https:\/\/t.co\/7ha4yJhjuZ",
  "id" : 723549615614767104,
  "created_at" : "2016-04-22 16:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723547344864710657\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/FGA9X010Wp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqOEUyWwAQSQXw.jpg",
      "id_str" : "723546895096922116",
      "id" : 723546895096922116,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqOEUyWwAQSQXw.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FGA9X010Wp"
    } ],
    "hashtags" : [ {
      "text" : "ObamaInUK",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723547344864710657",
  "text" : "\"The nations that make their presence felt on the world stage aren\u2019t the nations that go it alone\"\u2014@POTUS #ObamaInUK https:\/\/t.co\/FGA9X010Wp",
  "id" : 723547344864710657,
  "created_at" : "2016-04-22 16:21:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/723545038433574912\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hyYNRoSvgH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgqMW7CUcAAW728.jpg",
      "id_str" : "723545015578816512",
      "id" : 723545015578816512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgqMW7CUcAAW728.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hyYNRoSvgH"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723545038433574912",
  "text" : "\u201CToday, on #EarthDay, our governments, along with about 170 others, are in New York to sign that agreement.\u201D \u2014@POTUS https:\/\/t.co\/hyYNRoSvgH",
  "id" : 723545038433574912,
  "created_at" : "2016-04-22 16:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723544433262620672",
  "text" : "\"Should we be fortunate enough to reach 90, may we all be as vibrant as she is.\" \u2014@POTUS wishing Queen Elizabeth a happy 90th birthday",
  "id" : 723544433262620672,
  "created_at" : "2016-04-22 16:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "David Cameron",
      "screen_name" : "David_Cameron",
      "indices" : [ 62, 76 ],
      "id_str" : "103065157",
      "id" : 103065157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/4j8jN674Z3",
      "expanded_url" : "http:\/\/go.wh.gov\/Hb4S4J",
      "display_url" : "go.wh.gov\/Hb4S4J"
    } ]
  },
  "geo" : { },
  "id_str" : "723542275511320576",
  "text" : "Happening now: @POTUS participates in a press conference with @David_Cameron \u2192 https:\/\/t.co\/4j8jN674Z3",
  "id" : 723542275511320576,
  "created_at" : "2016-04-22 16:01:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 61, 73 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Sv7Q3AhVVj",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "723540924563873792",
  "text" : "RT @NSC44: TUNE IN: In a few minutes, @POTUS will speak from @Number10gov with PM Cameron. Watch here: https:\/\/t.co\/Sv7Q3AhVVj https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 27, 33 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "UK Prime Minister",
        "screen_name" : "Number10gov",
        "indices" : [ 50, 62 ],
        "id_str" : "14224719",
        "id" : 14224719
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/723540575257927680\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zRYiHW6CuJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqIUapUYAE_chg.jpg",
        "id_str" : "723540574477770753",
        "id" : 723540574477770753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqIUapUYAE_chg.jpg",
        "sizes" : [ {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zRYiHW6CuJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/Sv7Q3AhVVj",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "723540575257927680",
    "text" : "TUNE IN: In a few minutes, @POTUS will speak from @Number10gov with PM Cameron. Watch here: https:\/\/t.co\/Sv7Q3AhVVj https:\/\/t.co\/zRYiHW6CuJ",
    "id" : 723540575257927680,
    "created_at" : "2016-04-22 15:54:50 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 723540924563873792,
  "created_at" : "2016-04-22 15:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/723540417833254912\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/d5FKw9wTR0",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgqIGcSWMAAg83Z.jpg",
      "id_str" : "723540334400122880",
      "id" : 723540334400122880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgqIGcSWMAAg83Z.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d5FKw9wTR0"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "ParisAgreement",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723540417833254912",
  "text" : "Big news on #EarthDay! The U.S. has officially signed the #ParisAgreement, a historic step to combat climate change. https:\/\/t.co\/d5FKw9wTR0",
  "id" : 723540417833254912,
  "created_at" : "2016-04-22 15:54:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723528869697990656",
  "text" : "RT @vj44: Have questions on open data &amp; policing? Submit Qs by 2PM ET for a Facebook Q&amp;A w\/ leaders in policing reform https:\/\/t.co\/FhNVTTd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/FhNVTTdb8p",
        "expanded_url" : "https:\/\/www.facebook.com\/WhiteHouse\/posts\/10154313388784238",
        "display_url" : "facebook.com\/WhiteHouse\/pos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723528159807705088",
    "text" : "Have questions on open data &amp; policing? Submit Qs by 2PM ET for a Facebook Q&amp;A w\/ leaders in policing reform https:\/\/t.co\/FhNVTTdb8p",
    "id" : 723528159807705088,
    "created_at" : "2016-04-22 15:05:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 723528869697990656,
  "created_at" : "2016-04-22 15:08:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 25, 35 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 68, 83 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Mg1z5Q1a6j",
      "expanded_url" : "http:\/\/snpy.tv\/26jyksa",
      "display_url" : "snpy.tv\/26jyksa"
    } ]
  },
  "geo" : { },
  "id_str" : "723527540929925122",
  "text" : "RT @StateDept: Secretary @JohnKerry's remarks on the signing of the #ParisAgreement.\n#ActOnClimate\n#EarthDay https:\/\/t.co\/Mg1z5Q1a6j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 10, 20 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 53, 68 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 70, 83 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/Mg1z5Q1a6j",
        "expanded_url" : "http:\/\/snpy.tv\/26jyksa",
        "display_url" : "snpy.tv\/26jyksa"
      } ]
    },
    "geo" : { },
    "id_str" : "723516393560248320",
    "text" : "Secretary @JohnKerry's remarks on the signing of the #ParisAgreement.\n#ActOnClimate\n#EarthDay https:\/\/t.co\/Mg1z5Q1a6j",
    "id" : 723516393560248320,
    "created_at" : "2016-04-22 14:18:45 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 723527540929925122,
  "created_at" : "2016-04-22 15:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Prince",
      "screen_name" : "prince",
      "indices" : [ 67, 74 ],
      "id_str" : "3065429605",
      "id" : 3065429605
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723238674201214977\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/gowq1MExM3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgl1q2PW4AAttWl.jpg",
      "id_str" : "723238594144559104",
      "id" : 723238594144559104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgl1q2PW4AAttWl.jpg",
      "sizes" : [ {
        "h" : 345,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 621
      } ],
      "display_url" : "pic.twitter.com\/gowq1MExM3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/MTb3nKxruR",
      "expanded_url" : "http:\/\/go.wh.gov\/pwk91h",
      "display_url" : "go.wh.gov\/pwk91h"
    } ]
  },
  "geo" : { },
  "id_str" : "723238674201214977",
  "text" : "\"Today, the world lost a creative icon.\" \u2014@POTUS on the passing of @Prince: https:\/\/t.co\/MTb3nKxruR https:\/\/t.co\/gowq1MExM3",
  "id" : 723238674201214977,
  "created_at" : "2016-04-21 19:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723207034183651328\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fvRhsfSa7A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CglY9fiVEAADpeP.jpg",
      "id_str" : "723207028630425600",
      "id" : 723207028630425600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CglY9fiVEAADpeP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fvRhsfSa7A"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/N275eVmRla",
      "expanded_url" : "http:\/\/go.wh.gov\/apprenticeship",
      "display_url" : "go.wh.gov\/apprenticeship"
    } ]
  },
  "geo" : { },
  "id_str" : "723207034183651328",
  "text" : "Today, @POTUS took another big step to increase access to apprenticeships: https:\/\/t.co\/N275eVmRla https:\/\/t.co\/fvRhsfSa7A",
  "id" : 723207034183651328,
  "created_at" : "2016-04-21 17:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 35, 44 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TIME100",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/2GGqjGrYvg",
      "expanded_url" : "http:\/\/time.com\/4301270\/pope-francis-2016-time-100\/",
      "display_url" : "time.com\/4301270\/pope-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723198573874057217",
  "text" : "RT @VP: An honor to pay tribute to @pontifex, a man who has truly electrified the world. https:\/\/t.co\/2GGqjGrYvg #TIME100 https:\/\/t.co\/lLRs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 27, 36 ],
        "id_str" : "500704345",
        "id" : 500704345
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/723194214046011392\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/lLRsX90xQP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CglNThyXEAAF6I_.jpg",
        "id_str" : "723194213052125184",
        "id" : 723194213052125184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CglNThyXEAAF6I_.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/lLRsX90xQP"
      } ],
      "hashtags" : [ {
        "text" : "TIME100",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/2GGqjGrYvg",
        "expanded_url" : "http:\/\/time.com\/4301270\/pope-francis-2016-time-100\/",
        "display_url" : "time.com\/4301270\/pope-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723194214046011392",
    "text" : "An honor to pay tribute to @pontifex, a man who has truly electrified the world. https:\/\/t.co\/2GGqjGrYvg #TIME100 https:\/\/t.co\/lLRsX90xQP",
    "id" : 723194214046011392,
    "created_at" : "2016-04-21 16:58:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 723198573874057217,
  "created_at" : "2016-04-21 17:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/723185980094734336\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/BLQXPuawmw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CglFxFsUYAAgBkB.jpg",
      "id_str" : "723185924813643776",
      "id" : 723185924813643776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CglFxFsUYAAgBkB.jpg",
      "sizes" : [ {
        "h" : 345,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1084,
        "resize" : "fit",
        "w" : 1068
      } ],
      "display_url" : "pic.twitter.com\/BLQXPuawmw"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723185980094734336",
  "text" : "That's no filter\u2014that's @POTUS in the 70s. Share your national park #TBT to get every kid in a park. #FindYourPark https:\/\/t.co\/BLQXPuawmw",
  "id" : 723185980094734336,
  "created_at" : "2016-04-21 16:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/723175089403994113\/video\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/oLTKkk0Tip",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723174658883870720\/pu\/img\/Mf08lf45KRXMySFp.jpg",
      "id_str" : "723174658883870720",
      "id" : 723174658883870720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723174658883870720\/pu\/img\/Mf08lf45KRXMySFp.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oLTKkk0Tip"
    } ],
    "hashtags" : [ {
      "text" : "AskInterior",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723182218965823488",
  "text" : "RT @Interior: Hi - Sally Jewell here, Sec of Interior. Ready to take your questions! #AskInterior https:\/\/t.co\/oLTKkk0Tip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter QandA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/723175089403994113\/video\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/oLTKkk0Tip",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723174658883870720\/pu\/img\/Mf08lf45KRXMySFp.jpg",
        "id_str" : "723174658883870720",
        "id" : 723174658883870720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/723174658883870720\/pu\/img\/Mf08lf45KRXMySFp.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oLTKkk0Tip"
      } ],
      "hashtags" : [ {
        "text" : "AskInterior",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723175089403994113",
    "text" : "Hi - Sally Jewell here, Sec of Interior. Ready to take your questions! #AskInterior https:\/\/t.co\/oLTKkk0Tip",
    "id" : 723175089403994113,
    "created_at" : "2016-04-21 15:42:31 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 723182218965823488,
  "created_at" : "2016-04-21 16:10:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 61, 73 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/0Oa7WL1IWb",
      "expanded_url" : "https:\/\/www.producthunt.com\/live\/jason-goldman",
      "display_url" : "producthunt.com\/live\/jason-gol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723179738856980480",
  "text" : "RT @Goldman44: Ok! About to start my Product Hunt chat about @wethepeople, the White House and other topics! https:\/\/t.co\/0Oa7WL1IWb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 46, 58 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/0Oa7WL1IWb",
        "expanded_url" : "https:\/\/www.producthunt.com\/live\/jason-goldman",
        "display_url" : "producthunt.com\/live\/jason-gol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723179467938496513",
    "text" : "Ok! About to start my Product Hunt chat about @wethepeople, the White House and other topics! https:\/\/t.co\/0Oa7WL1IWb",
    "id" : 723179467938496513,
    "created_at" : "2016-04-21 15:59:55 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 723179738856980480,
  "created_at" : "2016-04-21 16:01:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 3, 8 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/zo7IEKzIYk",
      "expanded_url" : "http:\/\/medium.com\/@USDigitalService\/new-tool-launches-to-improve-the-benefits-claim-appeals-process-at-the-va-59c2557a4a1c#.p7w1gh84u",
      "display_url" : "medium.com\/@USDigitalServ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723174650591629318",
  "text" : "RT @USDS: How the Digital Service at VA is improving paperless appeals processing for Veterans: https:\/\/t.co\/zo7IEKzIYk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/zo7IEKzIYk",
        "expanded_url" : "http:\/\/medium.com\/@USDigitalService\/new-tool-launches-to-improve-the-benefits-claim-appeals-process-at-the-va-59c2557a4a1c#.p7w1gh84u",
        "display_url" : "medium.com\/@USDigitalServ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723159313326297090",
    "text" : "How the Digital Service at VA is improving paperless appeals processing for Veterans: https:\/\/t.co\/zo7IEKzIYk",
    "id" : 723159313326297090,
    "created_at" : "2016-04-21 14:39:50 +0000",
    "user" : {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "protected" : false,
      "id_str" : "2983206962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557352808672817152\/HWxVbTrV_normal.png",
      "id" : 2983206962,
      "verified" : true
    }
  },
  "id" : 723174650591629318,
  "created_at" : "2016-04-21 15:40:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 60, 72 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "Dawn Chmielewski",
      "screen_name" : "DawnC331",
      "indices" : [ 100, 109 ],
      "id_str" : "17071143",
      "id" : 17071143
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Recode\/status\/723134349516795906\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/3bJjI7PJ7x",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgkW27nVEAAGg6l.jpg",
      "id_str" : "723134348141072384",
      "id" : 723134348141072384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgkW27nVEAAGg6l.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/3bJjI7PJ7x"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/GkwnZUlisj",
      "expanded_url" : "http:\/\/on.recode.net\/1SlvPvO",
      "display_url" : "on.recode.net\/1SlvPvO"
    } ]
  },
  "geo" : { },
  "id_str" : "723170786152837120",
  "text" : "RT @Recode: White House makes it easier to petition through @WethePeople https:\/\/t.co\/GkwnZUlisj by @DawnC331 https:\/\/t.co\/3bJjI7PJ7x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/recode.net\/\" rel=\"nofollow\"\u003ERe\/code Auto Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 48, 60 ],
        "id_str" : "369507958",
        "id" : 369507958
      }, {
        "name" : "Dawn Chmielewski",
        "screen_name" : "DawnC331",
        "indices" : [ 88, 97 ],
        "id_str" : "17071143",
        "id" : 17071143
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Recode\/status\/723134349516795906\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/3bJjI7PJ7x",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgkW27nVEAAGg6l.jpg",
        "id_str" : "723134348141072384",
        "id" : 723134348141072384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgkW27nVEAAGg6l.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/3bJjI7PJ7x"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/GkwnZUlisj",
        "expanded_url" : "http:\/\/on.recode.net\/1SlvPvO",
        "display_url" : "on.recode.net\/1SlvPvO"
      } ]
    },
    "geo" : { },
    "id_str" : "723134349516795906",
    "text" : "White House makes it easier to petition through @WethePeople https:\/\/t.co\/GkwnZUlisj by @DawnC331 https:\/\/t.co\/3bJjI7PJ7x",
    "id" : 723134349516795906,
    "created_at" : "2016-04-21 13:00:38 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 723170786152837120,
  "created_at" : "2016-04-21 15:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 76, 88 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/723163819455832066\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/47RlRnGdaq",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cgkwx6WW0AE8J4Z.jpg",
      "id_str" : "723162849204424705",
      "id" : 723162849204424705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cgkwx6WW0AE8J4Z.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/47RlRnGdaq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/aoc9SRMgke",
      "expanded_url" : "http:\/\/go.wh.gov\/PetitionsRedesign",
      "display_url" : "go.wh.gov\/PetitionsRedes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723163819455832066",
  "text" : "We just made it easier, faster and more mobile-friendly to petition through @WeThePeople:  https:\/\/t.co\/aoc9SRMgke https:\/\/t.co\/47RlRnGdaq",
  "id" : 723163819455832066,
  "created_at" : "2016-04-21 14:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnMuir",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Cm5fcZT4sL",
      "expanded_url" : "http:\/\/on.doi.gov\/1MucmMu",
      "display_url" : "on.doi.gov\/1MucmMu"
    } ]
  },
  "geo" : { },
  "id_str" : "723162089963974656",
  "text" : "RT @Interior: Happy birthday #JohnMuir, the OG conservationist &amp; Father of National Parks! https:\/\/t.co\/Cm5fcZT4sL #FindYourPark https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/723141626424520705\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/kltTyac52O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgkdee6UcAA9rK8.jpg",
        "id_str" : "723141624700628992",
        "id" : 723141624700628992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgkdee6UcAA9rK8.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2764,
          "resize" : "fit",
          "w" : 3686
        } ],
        "display_url" : "pic.twitter.com\/kltTyac52O"
      } ],
      "hashtags" : [ {
        "text" : "JohnMuir",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Cm5fcZT4sL",
        "expanded_url" : "http:\/\/on.doi.gov\/1MucmMu",
        "display_url" : "on.doi.gov\/1MucmMu"
      } ]
    },
    "geo" : { },
    "id_str" : "723141626424520705",
    "text" : "Happy birthday #JohnMuir, the OG conservationist &amp; Father of National Parks! https:\/\/t.co\/Cm5fcZT4sL #FindYourPark https:\/\/t.co\/kltTyac52O",
    "id" : 723141626424520705,
    "created_at" : "2016-04-21 13:29:33 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 723162089963974656,
  "created_at" : "2016-04-21 14:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EveryKidinaPark",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ioRa2mS2o6",
      "expanded_url" : "http:\/\/1.usa.gov\/1SdsF0r",
      "display_url" : "1.usa.gov\/1SdsF0r"
    } ]
  },
  "geo" : { },
  "id_str" : "723161537347645444",
  "text" : "RT @WhiteHouseCEQ: Big news: we just announced commitments to get half a million kids outside! #EveryKidinaPark https:\/\/t.co\/ioRa2mS2o6 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouseCEQ\/status\/723154954442039297\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3r5IqDhxhn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgkkcNGVEAAZW3P.jpg",
        "id_str" : "723149282140819456",
        "id" : 723149282140819456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgkkcNGVEAAZW3P.jpg",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/3r5IqDhxhn"
      } ],
      "hashtags" : [ {
        "text" : "EveryKidinaPark",
        "indices" : [ 76, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ioRa2mS2o6",
        "expanded_url" : "http:\/\/1.usa.gov\/1SdsF0r",
        "display_url" : "1.usa.gov\/1SdsF0r"
      } ]
    },
    "geo" : { },
    "id_str" : "723154954442039297",
    "text" : "Big news: we just announced commitments to get half a million kids outside! #EveryKidinaPark https:\/\/t.co\/ioRa2mS2o6 https:\/\/t.co\/3r5IqDhxhn",
    "id" : 723154954442039297,
    "created_at" : "2016-04-21 14:22:31 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 723161537347645444,
  "created_at" : "2016-04-21 14:48:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/RREp3CWC3E",
      "expanded_url" : "http:\/\/petitions.whitehouse.gov",
      "display_url" : "petitions.whitehouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "723150903205847041",
  "text" : "RT @Goldman44: I'll be chatting about the new https:\/\/t.co\/RREp3CWC3E and digital strategy at the WH on Product Hunt at noon ET: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/RREp3CWC3E",
        "expanded_url" : "http:\/\/petitions.whitehouse.gov",
        "display_url" : "petitions.whitehouse.gov"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/0Oa7WL1IWb",
        "expanded_url" : "https:\/\/www.producthunt.com\/live\/jason-goldman",
        "display_url" : "producthunt.com\/live\/jason-gol\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "723136201884999680",
    "geo" : { },
    "id_str" : "723136980855328768",
    "in_reply_to_user_id" : 131144091,
    "text" : "I'll be chatting about the new https:\/\/t.co\/RREp3CWC3E and digital strategy at the WH on Product Hunt at noon ET: https:\/\/t.co\/0Oa7WL1IWb",
    "id" : 723136980855328768,
    "in_reply_to_status_id" : 723136201884999680,
    "created_at" : "2016-04-21 13:11:06 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 723150903205847041,
  "created_at" : "2016-04-21 14:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/VILCdRzv8K",
      "expanded_url" : "http:\/\/petitions.whitehouse.gov",
      "display_url" : "petitions.whitehouse.gov"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/C9qThDpqFu",
      "expanded_url" : "http:\/\/go.wh.gov\/PetitionsRedesign",
      "display_url" : "go.wh.gov\/PetitionsRedes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723139147335131136",
  "text" : "RT @wethepeople: We're live! So excited to bring you a re-envisioned https:\/\/t.co\/VILCdRzv8K. Here's why \u2192 https:\/\/t.co\/C9qThDpqFu https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wethepeople\/status\/723138448882847744\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/RD18KnvQM5",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgkZ4LLWgAArtEw.jpg",
        "id_str" : "723137668033445888",
        "id" : 723137668033445888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgkZ4LLWgAArtEw.jpg",
        "sizes" : [ {
          "h" : 494,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 944,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 871,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 944,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/RD18KnvQM5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/VILCdRzv8K",
        "expanded_url" : "http:\/\/petitions.whitehouse.gov",
        "display_url" : "petitions.whitehouse.gov"
      }, {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/C9qThDpqFu",
        "expanded_url" : "http:\/\/go.wh.gov\/PetitionsRedesign",
        "display_url" : "go.wh.gov\/PetitionsRedes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723138448882847744",
    "text" : "We're live! So excited to bring you a re-envisioned https:\/\/t.co\/VILCdRzv8K. Here's why \u2192 https:\/\/t.co\/C9qThDpqFu https:\/\/t.co\/RD18KnvQM5",
    "id" : 723138448882847744,
    "created_at" : "2016-04-21 13:16:56 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 723139147335131136,
  "created_at" : "2016-04-21 13:19:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Smith",
      "screen_name" : "MikeSmith_44",
      "indices" : [ 3, 16 ],
      "id_str" : "3243718652",
      "id" : 3243718652
    }, {
      "name" : "DC CFSA",
      "screen_name" : "DCCFSA",
      "indices" : [ 130, 137 ],
      "id_str" : "1598831328",
      "id" : 1598831328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaughtersAndSons",
      "indices" : [ 81, 98 ]
    }, {
      "text" : "MyBrothersKeeper",
      "indices" : [ 112, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722976168517898242",
  "text" : "RT @MikeSmith_44: Jalonnie &amp; Jahlil taught me this cool handshake @ Take Our #DaughtersAndSons to Work Day! #MyBrothersKeeper @DCCFSA https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DC CFSA",
        "screen_name" : "DCCFSA",
        "indices" : [ 112, 119 ],
        "id_str" : "1598831328",
        "id" : 1598831328
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MikeSmith_44\/status\/722924985983995905\/video\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/6B7duU4hZE",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/722924695746531328\/pu\/img\/O4Pc7AjJ1jpjQHVA.jpg",
        "id_str" : "722924695746531328",
        "id" : 722924695746531328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/722924695746531328\/pu\/img\/O4Pc7AjJ1jpjQHVA.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6B7duU4hZE"
      } ],
      "hashtags" : [ {
        "text" : "DaughtersAndSons",
        "indices" : [ 63, 80 ]
      }, {
        "text" : "MyBrothersKeeper",
        "indices" : [ 94, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722924985983995905",
    "text" : "Jalonnie &amp; Jahlil taught me this cool handshake @ Take Our #DaughtersAndSons to Work Day! #MyBrothersKeeper @DCCFSA https:\/\/t.co\/6B7duU4hZE",
    "id" : 722924985983995905,
    "created_at" : "2016-04-20 23:08:42 +0000",
    "user" : {
      "name" : "Michael Smith",
      "screen_name" : "MikeSmith_44",
      "protected" : false,
      "id_str" : "3243718652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615903404158787584\/dg9_SpSH_normal.jpg",
      "id" : 3243718652,
      "verified" : true
    }
  },
  "id" : 722976168517898242,
  "created_at" : "2016-04-21 02:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 53, 60 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaughtersAndSons",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/D7nRzC0PyI",
      "expanded_url" : "http:\/\/snpy.tv\/26f84PB",
      "display_url" : "snpy.tv\/26f84PB"
    } ]
  },
  "geo" : { },
  "id_str" : "722974407392563204",
  "text" : "\"I want to be a 90-year-old lady that's really fly\" \u2014@FLOTUS on why she likes to exercise. #DaughtersAndSons https:\/\/t.co\/D7nRzC0PyI",
  "id" : 722974407392563204,
  "created_at" : "2016-04-21 02:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722972314581618689",
  "text" : "RT @Goldman44: I'll be chatting about digital strategy at the White House tomorrow at Product Hunt at 9a PT\/12p ET. Please join in! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0Oa7WL1IWb",
        "expanded_url" : "https:\/\/www.producthunt.com\/live\/jason-goldman",
        "display_url" : "producthunt.com\/live\/jason-gol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722935018947891201",
    "text" : "I'll be chatting about digital strategy at the White House tomorrow at Product Hunt at 9a PT\/12p ET. Please join in! https:\/\/t.co\/0Oa7WL1IWb",
    "id" : 722935018947891201,
    "created_at" : "2016-04-20 23:48:34 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 722972314581618689,
  "created_at" : "2016-04-21 02:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/FQ4WENnaDY",
      "expanded_url" : "http:\/\/snpy.tv\/26fHHZP",
      "display_url" : "snpy.tv\/26fHHZP"
    } ]
  },
  "geo" : { },
  "id_str" : "722936662985060352",
  "text" : "The ridiculous price you pay for your cable box and what we're doing to help fix it, explained\u2014in one minute: https:\/\/t.co\/FQ4WENnaDY",
  "id" : 722936662985060352,
  "created_at" : "2016-04-20 23:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/722932222089568257\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NDobPPUfuY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CghfA7-WsAA6yIc.jpg",
      "id_str" : "722932209896828928",
      "id" : 722932209896828928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CghfA7-WsAA6yIc.jpg",
      "sizes" : [ {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 1397
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NDobPPUfuY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722934065477861376",
  "text" : "RT @vj44: Just called Sofia to let her know her wish came true. Harriet Tubman will be on the face of the $20 bill! https:\/\/t.co\/NDobPPUfuY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/722932222089568257\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/NDobPPUfuY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CghfA7-WsAA6yIc.jpg",
        "id_str" : "722932209896828928",
        "id" : 722932209896828928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CghfA7-WsAA6yIc.jpg",
        "sizes" : [ {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 1397
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 572,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NDobPPUfuY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "722932004338073601",
    "geo" : { },
    "id_str" : "722932222089568257",
    "in_reply_to_user_id" : 595515713,
    "text" : "Just called Sofia to let her know her wish came true. Harriet Tubman will be on the face of the $20 bill! https:\/\/t.co\/NDobPPUfuY",
    "id" : 722932222089568257,
    "in_reply_to_status_id" : 722932004338073601,
    "created_at" : "2016-04-20 23:37:27 +0000",
    "in_reply_to_screen_name" : "vj44",
    "in_reply_to_user_id_str" : "595515713",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 722934065477861376,
  "created_at" : "2016-04-20 23:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/722932004338073601\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ezmvHVgnbU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cghez-5XEAEz_6y.jpg",
      "id_str" : "722931987342888961",
      "id" : 722931987342888961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cghez-5XEAEz_6y.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1582,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ezmvHVgnbU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722934055818391552",
  "text" : "RT @vj44: Two years ago, 8 year old Sofia wrote to @POTUS that more women should be on our currency. https:\/\/t.co\/ezmvHVgnbU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 41, 47 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/722932004338073601\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ezmvHVgnbU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cghez-5XEAEz_6y.jpg",
        "id_str" : "722931987342888961",
        "id" : 722931987342888961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cghez-5XEAEz_6y.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1582,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 791,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ezmvHVgnbU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722932004338073601",
    "text" : "Two years ago, 8 year old Sofia wrote to @POTUS that more women should be on our currency. https:\/\/t.co\/ezmvHVgnbU",
    "id" : 722932004338073601,
    "created_at" : "2016-04-20 23:36:35 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 722934055818391552,
  "created_at" : "2016-04-20 23:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 6, 15 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/adWSeO0qrI",
      "expanded_url" : "http:\/\/go.wh.gov\/YQ2Ysz",
      "display_url" : "go.wh.gov\/YQ2Ysz"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/FQ4WENEM2y",
      "expanded_url" : "http:\/\/snpy.tv\/26fHHZP",
      "display_url" : "snpy.tv\/26fHHZP"
    } ]
  },
  "geo" : { },
  "id_str" : "722921719380471808",
  "text" : "Watch @CEAChair break down how competition can get you a better deal on your cable box \u2192 https:\/\/t.co\/adWSeO0qrI https:\/\/t.co\/FQ4WENEM2y",
  "id" : 722921719380471808,
  "created_at" : "2016-04-20 22:55:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 54, 64 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/QSE3tQeZTv",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/39e0c8a8-039c-4a01-ab70-ffc10e3b9058",
      "display_url" : "amp.twimg.com\/v\/39e0c8a8-039\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722909871104888832",
  "text" : "RT @SCOTUSnom: Take the next 2 minutes to see why the @SenateGOP's failure to do it's job on #SCOTUS is a problem. https:\/\/t.co\/QSE3tQeZTv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 39, 49 ],
        "id_str" : "14344823",
        "id" : 14344823
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/QSE3tQeZTv",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/39e0c8a8-039c-4a01-ab70-ffc10e3b9058",
        "display_url" : "amp.twimg.com\/v\/39e0c8a8-039\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722908454386413569",
    "text" : "Take the next 2 minutes to see why the @SenateGOP's failure to do it's job on #SCOTUS is a problem. https:\/\/t.co\/QSE3tQeZTv",
    "id" : 722908454386413569,
    "created_at" : "2016-04-20 22:03:01 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 722909871104888832,
  "created_at" : "2016-04-20 22:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 34, 51 ]
    }, {
      "text" : "parksforall",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722906178020204545",
  "text" : "RT @SecretaryJewell: This week is #NationalParkWeek\u2014a time when we celebrate the most incredible parks system in the world. #parksforall ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722482037530173440\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DfwVOOfXtP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbFi0_UUAAqurz.jpg",
        "id_str" : "722481992369983488",
        "id" : 722481992369983488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbFi0_UUAAqurz.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/DfwVOOfXtP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722482037530173440\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DfwVOOfXtP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbFlMYUsAABx9q.jpg",
        "id_str" : "722482033008619520",
        "id" : 722482033008619520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbFlMYUsAABx9q.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DfwVOOfXtP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722482037530173440\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DfwVOOfXtP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbFiKQUIAAdgoq.jpg",
        "id_str" : "722481980898549760",
        "id" : 722481980898549760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbFiKQUIAAdgoq.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/DfwVOOfXtP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722482037530173440\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DfwVOOfXtP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbFlX7VIAIr3MO.jpg",
        "id_str" : "722482036108238850",
        "id" : 722482036108238850,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbFlX7VIAIr3MO.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/DfwVOOfXtP"
      } ],
      "hashtags" : [ {
        "text" : "NationalParkWeek",
        "indices" : [ 13, 30 ]
      }, {
        "text" : "parksforall",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722482037530173440",
    "text" : "This week is #NationalParkWeek\u2014a time when we celebrate the most incredible parks system in the world. #parksforall https:\/\/t.co\/DfwVOOfXtP",
    "id" : 722482037530173440,
    "created_at" : "2016-04-19 17:48:35 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 722906178020204545,
  "created_at" : "2016-04-20 21:53:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722888840449396739\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/lAcfSYd6aR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgg3h_hXEAAI6ya.jpg",
      "id_str" : "722888797319532544",
      "id" : 722888797319532544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgg3h_hXEAAI6ya.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lAcfSYd6aR"
    } ],
    "hashtags" : [ {
      "text" : "NationalParksWeek",
      "indices" : [ 5, 23 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722888840449396739",
  "text" : "This #NationalParksWeek, remember the vital role our national parks play in the fight to #ActOnClimate! https:\/\/t.co\/lAcfSYd6aR",
  "id" : 722888840449396739,
  "created_at" : "2016-04-20 20:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/722871928852074496\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yE0U1cAV0N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CggoMCvUEAETvUc.jpg",
      "id_str" : "722871927551823873",
      "id" : 722871927551823873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CggoMCvUEAETvUc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yE0U1cAV0N"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722876195897872386",
  "text" : "RT @FactsOnClimate: Our National Parks keep our planet healthy. Protecting them is one way we #ActOnClimate. https:\/\/t.co\/yE0U1cAV0N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/722871928852074496\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/yE0U1cAV0N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CggoMCvUEAETvUc.jpg",
        "id_str" : "722871927551823873",
        "id" : 722871927551823873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CggoMCvUEAETvUc.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yE0U1cAV0N"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 74, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722871928852074496",
    "text" : "Our National Parks keep our planet healthy. Protecting them is one way we #ActOnClimate. https:\/\/t.co\/yE0U1cAV0N",
    "id" : 722871928852074496,
    "created_at" : "2016-04-20 19:37:52 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 722876195897872386,
  "created_at" : "2016-04-20 19:54:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722871254789832704\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/zqDbWDmDIp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cggnd2vWIAAWuhf.jpg",
      "id_str" : "722871134056751104",
      "id" : 722871134056751104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cggnd2vWIAAWuhf.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/zqDbWDmDIp"
    } ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 73, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722871254789832704",
  "text" : "FACT: @POTUS has preserved more land and water than any other president. #NationalParkWeek https:\/\/t.co\/zqDbWDmDIp",
  "id" : 722871254789832704,
  "created_at" : "2016-04-20 19:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 64, 75 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/nSO63b7eBV",
      "expanded_url" : "http:\/\/go.wh.gov\/DbP5aK",
      "display_url" : "go.wh.gov\/DbP5aK"
    } ]
  },
  "geo" : { },
  "id_str" : "722808164979249152",
  "text" : "RT @FLOTUS: It's Take Our Daughters and Sons to Work Day at the @WhiteHouse! Join us at 11am ET: https:\/\/t.co\/nSO63b7eBV https:\/\/t.co\/MYu3d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 52, 63 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/722798353889828864\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/MYu3dPFJNp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgflRbhXEAAbdno.jpg",
        "id_str" : "722798352824471552",
        "id" : 722798352824471552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgflRbhXEAAbdno.jpg",
        "sizes" : [ {
          "h" : 796,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1555,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/MYu3dPFJNp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/nSO63b7eBV",
        "expanded_url" : "http:\/\/go.wh.gov\/DbP5aK",
        "display_url" : "go.wh.gov\/DbP5aK"
      } ]
    },
    "geo" : { },
    "id_str" : "722798353889828864",
    "text" : "It's Take Our Daughters and Sons to Work Day at the @WhiteHouse! Join us at 11am ET: https:\/\/t.co\/nSO63b7eBV https:\/\/t.co\/MYu3dPFJNp",
    "id" : 722798353889828864,
    "created_at" : "2016-04-20 14:45:31 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 722808164979249152,
  "created_at" : "2016-04-20 15:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Mary Kay Henry",
      "screen_name" : "MaryKayHenry",
      "indices" : [ 98, 111 ],
      "id_str" : "21765244",
      "id" : 21765244
    }, {
      "name" : "SEIU",
      "screen_name" : "SEIU",
      "indices" : [ 116, 121 ],
      "id_str" : "14695985",
      "id" : 14695985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722588632427548672",
  "text" : "RT @vj44: Homecare workers deserve our respect &amp; thanks for vital work they do. Proud to join @MaryKayHenry and @SEIU today. https:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Kay Henry",
        "screen_name" : "MaryKayHenry",
        "indices" : [ 88, 101 ],
        "id_str" : "21765244",
        "id" : 21765244
      }, {
        "name" : "SEIU",
        "screen_name" : "SEIU",
        "indices" : [ 106, 111 ],
        "id_str" : "14695985",
        "id" : 14695985
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/722568791905976320\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/c6XO9173H4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgcUelOW8AAC1j8.jpg",
        "id_str" : "722568780837220352",
        "id" : 722568780837220352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgcUelOW8AAC1j8.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/c6XO9173H4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722568791905976320",
    "text" : "Homecare workers deserve our respect &amp; thanks for vital work they do. Proud to join @MaryKayHenry and @SEIU today. https:\/\/t.co\/c6XO9173H4",
    "id" : 722568791905976320,
    "created_at" : "2016-04-19 23:33:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 722588632427548672,
  "created_at" : "2016-04-20 00:52:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 7, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/8AvZn8CFO7",
      "expanded_url" : "https:\/\/vine.co\/v\/eOamHY0W033",
      "display_url" : "vine.co\/v\/eOamHY0W033"
    } ]
  },
  "geo" : { },
  "id_str" : "722583378977918976",
  "text" : "During #NationalParkWeek, run (don't walk) on into your favorite national park for free. \uD83D\uDC22 https:\/\/t.co\/8AvZn8CFO7",
  "id" : 722583378977918976,
  "created_at" : "2016-04-20 00:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 82, 92 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/rukR6DiTlj",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/39e0c8a8-039c-4a01-ab70-ffc10e3b9058",
      "display_url" : "amp.twimg.com\/v\/39e0c8a8-039\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722551616277065728",
  "text" : ".@VP breaks down why it's time for the Senate Republicans to give the President's @SCOTUSnom a hearing. #DoYourJob  https:\/\/t.co\/rukR6DiTlj",
  "id" : 722551616277065728,
  "created_at" : "2016-04-19 22:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722543341422845952\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/phtL1YdY8n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgb1irYVIAAttq5.jpg",
      "id_str" : "722534766348673024",
      "id" : 722534766348673024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgb1irYVIAAttq5.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1494,
        "resize" : "fit",
        "w" : 2240
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/phtL1YdY8n"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722543341422845952\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/phtL1YdY8n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgb1ikLVIAAKKax.jpg",
      "id_str" : "722534764415098880",
      "id" : 722534764415098880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgb1ikLVIAAKKax.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/phtL1YdY8n"
    } ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 26, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/VGShEzwatN",
      "expanded_url" : "http:\/\/go.wh.gov\/gDmiwD",
      "display_url" : "go.wh.gov\/gDmiwD"
    } ]
  },
  "geo" : { },
  "id_str" : "722543341422845952",
  "text" : "Planning your trip during #NationalParkWeek? Here's a little inspiration from @POTUS: https:\/\/t.co\/VGShEzwatN https:\/\/t.co\/phtL1YdY8n",
  "id" : 722543341422845952,
  "created_at" : "2016-04-19 21:52:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722532679443476480\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/yBmhCTpNar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbzfX6WcAMpNHp.jpg",
      "id_str" : "722532510559793155",
      "id" : 722532510559793155,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbzfX6WcAMpNHp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/yBmhCTpNar"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 27, 40 ]
    }, {
      "text" : "NationalParkWeek",
      "indices" : [ 48, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/VGShEzezCf",
      "expanded_url" : "http:\/\/go.wh.gov\/gDmiwD",
      "display_url" : "go.wh.gov\/gDmiwD"
    } ]
  },
  "geo" : { },
  "id_str" : "722532679443476480",
  "text" : "Get inspired by @POTUS and #FindYourPark during #NationalParkWeek: https:\/\/t.co\/VGShEzezCf https:\/\/t.co\/yBmhCTpNar",
  "id" : 722532679443476480,
  "created_at" : "2016-04-19 21:09:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Lin-Manuel Miranda",
      "screen_name" : "Lin_Manuel",
      "indices" : [ 32, 43 ],
      "id_str" : "79923701",
      "id" : 79923701
    }, {
      "name" : "Hamiltonmusic",
      "screen_name" : "Hamiltonmusic",
      "indices" : [ 60, 74 ],
      "id_str" : "18375806",
      "id" : 18375806
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pulitzer",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722526510549229569",
  "text" : "RT @DrBiden: Congratulations to @Lin_Manuel &amp; the whole @HamiltonMusic cast! Joe &amp; I couldn't be happier for you. #Pulitzer \u2014Jill https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lin-Manuel Miranda",
        "screen_name" : "Lin_Manuel",
        "indices" : [ 19, 30 ],
        "id_str" : "79923701",
        "id" : 79923701
      }, {
        "name" : "Hamiltonmusic",
        "screen_name" : "Hamiltonmusic",
        "indices" : [ 47, 61 ],
        "id_str" : "18375806",
        "id" : 18375806
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/722501114042527745\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/rwOdWxUEGC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbW7mtVIAA2Prg.jpg",
        "id_str" : "722501109730844672",
        "id" : 722501109730844672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbW7mtVIAA2Prg.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rwOdWxUEGC"
      } ],
      "hashtags" : [ {
        "text" : "Pulitzer",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722501114042527745",
    "text" : "Congratulations to @Lin_Manuel &amp; the whole @HamiltonMusic cast! Joe &amp; I couldn't be happier for you. #Pulitzer \u2014Jill https:\/\/t.co\/rwOdWxUEGC",
    "id" : 722501114042527745,
    "created_at" : "2016-04-19 19:04:23 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 722526510549229569,
  "created_at" : "2016-04-19 20:45:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 3, 10 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Google Arts",
      "screen_name" : "googleart",
      "indices" : [ 77, 87 ],
      "id_str" : "4433429660",
      "id" : 4433429660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StreetView",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "NationalParkWeek",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/mhmHAhLSph",
      "expanded_url" : "https:\/\/goo.gl\/vqei8r",
      "display_url" : "goo.gl\/vqei8r"
    } ]
  },
  "geo" : { },
  "id_str" : "722518268678971393",
  "text" : "RT @google: Yosemite: stunning through any lens. See it on #StreetView &amp; @googleart \u2192 https:\/\/t.co\/mhmHAhLSph #NationalParkWeek https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google Arts",
        "screen_name" : "googleart",
        "indices" : [ 65, 75 ],
        "id_str" : "4433429660",
        "id" : 4433429660
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/google\/status\/722453204663996417\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/YgMOsJPGRs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgarXIpUIAA0tTp.jpg",
        "id_str" : "722453204185653248",
        "id" : 722453204185653248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgarXIpUIAA0tTp.jpg",
        "sizes" : [ {
          "h" : 557,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YgMOsJPGRs"
      } ],
      "hashtags" : [ {
        "text" : "StreetView",
        "indices" : [ 47, 58 ]
      }, {
        "text" : "NationalParkWeek",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/mhmHAhLSph",
        "expanded_url" : "https:\/\/goo.gl\/vqei8r",
        "display_url" : "goo.gl\/vqei8r"
      } ]
    },
    "geo" : { },
    "id_str" : "722453204663996417",
    "text" : "Yosemite: stunning through any lens. See it on #StreetView &amp; @googleart \u2192 https:\/\/t.co\/mhmHAhLSph #NationalParkWeek https:\/\/t.co\/YgMOsJPGRs",
    "id" : 722453204663996417,
    "created_at" : "2016-04-19 15:54:01 +0000",
    "user" : {
      "name" : "Google",
      "screen_name" : "google",
      "protected" : false,
      "id_str" : "20536157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762369348300251136\/5Obhonwa_normal.jpg",
      "id" : 20536157,
      "verified" : true
    }
  },
  "id" : 722518268678971393,
  "created_at" : "2016-04-19 20:12:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 52, 68 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722516443548553216\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/KMX97HcXiE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgbky07UAAAxbwo.jpg",
      "id_str" : "722516352091553792",
      "id" : 722516352091553792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgbky07UAAAxbwo.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 794,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/KMX97HcXiE"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722516443548553216",
  "text" : "RT to spread the word: Every dollar invested in the @NatlParkService returns $10 to the U.S. economy. #FindYourPark https:\/\/t.co\/KMX97HcXiE",
  "id" : 722516443548553216,
  "created_at" : "2016-04-19 20:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/rukR6DiTlj",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/39e0c8a8-039c-4a01-ab70-ffc10e3b9058",
      "display_url" : "amp.twimg.com\/v\/39e0c8a8-039\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722501378195607552",
  "text" : "No hearing?\nNo vote?\nNot an option.\nIt's time for the Senate GOP to uphold its constitutional duty. #DoYourJob  https:\/\/t.co\/rukR6DiTlj",
  "id" : 722501378195607552,
  "created_at" : "2016-04-19 19:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "parksforall",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722493664979718144",
  "text" : "RT @SecretaryJewell: For 100+ yrs, presidents have used Antiquities Act to protect special places that might be lost forever #parksforall h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722491785772183552\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Rk8RFVlCUF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbOcSaUIAArKkV.jpg",
        "id_str" : "722491775613411328",
        "id" : 722491775613411328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbOcSaUIAArKkV.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/Rk8RFVlCUF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722491785772183552\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Rk8RFVlCUF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbObleUUAA4a19.jpg",
        "id_str" : "722491763550605312",
        "id" : 722491763550605312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbObleUUAA4a19.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/Rk8RFVlCUF"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/722491785772183552\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Rk8RFVlCUF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbOczmUYAAJolm.jpg",
        "id_str" : "722491784522129408",
        "id" : 722491784522129408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbOczmUYAAJolm.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Rk8RFVlCUF"
      } ],
      "hashtags" : [ {
        "text" : "parksforall",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722491785772183552",
    "text" : "For 100+ yrs, presidents have used Antiquities Act to protect special places that might be lost forever #parksforall https:\/\/t.co\/Rk8RFVlCUF",
    "id" : 722491785772183552,
    "created_at" : "2016-04-19 18:27:19 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 722493664979718144,
  "created_at" : "2016-04-19 18:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OKC Memorial",
      "screen_name" : "OKCNM",
      "indices" : [ 3, 9 ],
      "id_str" : "182978734",
      "id" : 182978734
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OKCNM\/status\/722454345803935744\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/bbRNcA8kme",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgasZiVUEAAKdy_.jpg",
      "id_str" : "722454344952451072",
      "id" : 722454344952451072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgasZiVUEAAKdy_.jpg",
      "sizes" : [ {
        "h" : 781,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/bbRNcA8kme"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722468799140630529",
  "text" : "RT @OKCNM: @POTUS shared his thoughts this Anniversary with this special letter, read at the Remembrance Ceremony. https:\/\/t.co\/bbRNcA8kme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OKCNM\/status\/722454345803935744\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/bbRNcA8kme",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgasZiVUEAAKdy_.jpg",
        "id_str" : "722454344952451072",
        "id" : 722454344952451072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgasZiVUEAAKdy_.jpg",
        "sizes" : [ {
          "h" : 781,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 976,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 976,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/bbRNcA8kme"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722454345803935744",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS shared his thoughts this Anniversary with this special letter, read at the Remembrance Ceremony. https:\/\/t.co\/bbRNcA8kme",
    "id" : 722454345803935744,
    "created_at" : "2016-04-19 15:58:33 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "OKC Memorial",
      "screen_name" : "OKCNM",
      "protected" : false,
      "id_str" : "182978734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785490050825859073\/c1Y36JlR_normal.jpg",
      "id" : 182978734,
      "verified" : false
    }
  },
  "id" : 722468799140630529,
  "created_at" : "2016-04-19 16:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 3, 8 ],
      "id_str" : "14342564",
      "id" : 14342564
    }, {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "indices" : [ 69, 85 ],
      "id_str" : "916735110",
      "id" : 916735110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfClimate",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/PeJolOxbK3",
      "expanded_url" : "http:\/\/1.usa.gov\/1ShIGnX",
      "display_url" : "1.usa.gov\/1ShIGnX"
    } ]
  },
  "geo" : { },
  "id_str" : "722461260298657792",
  "text" : "RT @NOAA: January\u2013March 2016 global temp record high for period, per @NOAANCEIclimate https:\/\/t.co\/PeJolOxbK3 #StateOfClimate https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOAA NCEI Climate",
        "screen_name" : "NOAANCEIclimate",
        "indices" : [ 59, 75 ],
        "id_str" : "916735110",
        "id" : 916735110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOAA\/status\/722438791122853888\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/7mzhl9RSbZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgaeMRkXEAACX3j.jpg",
        "id_str" : "722438723951071232",
        "id" : 722438723951071232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgaeMRkXEAACX3j.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        } ],
        "display_url" : "pic.twitter.com\/7mzhl9RSbZ"
      } ],
      "hashtags" : [ {
        "text" : "StateOfClimate",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/PeJolOxbK3",
        "expanded_url" : "http:\/\/1.usa.gov\/1ShIGnX",
        "display_url" : "1.usa.gov\/1ShIGnX"
      } ]
    },
    "geo" : { },
    "id_str" : "722438791122853888",
    "text" : "January\u2013March 2016 global temp record high for period, per @NOAANCEIclimate https:\/\/t.co\/PeJolOxbK3 #StateOfClimate https:\/\/t.co\/7mzhl9RSbZ",
    "id" : 722438791122853888,
    "created_at" : "2016-04-19 14:56:44 +0000",
    "user" : {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "protected" : false,
      "id_str" : "14342564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529277799018676225\/MOsMKe14_normal.jpeg",
      "id" : 14342564,
      "verified" : true
    }
  },
  "id" : 722461260298657792,
  "created_at" : "2016-04-19 16:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvictusGames",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722429467323428864",
  "text" : "RT @DrBiden: \"One of the things that never ceases to amaze me is the spirit of our wounded warriors.\" \u2014Dr. Biden #InvictusGames\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvictusGames",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/WajgNuC8Zl",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/b1e259a0-cd99-4ffa-b0b8-b7d279460e8b",
        "display_url" : "amp.twimg.com\/v\/b1e259a0-cd9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722412467628847104",
    "text" : "\"One of the things that never ceases to amaze me is the spirit of our wounded warriors.\" \u2014Dr. Biden #InvictusGames\nhttps:\/\/t.co\/WajgNuC8Zl",
    "id" : 722412467628847104,
    "created_at" : "2016-04-19 13:12:08 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 722429467323428864,
  "created_at" : "2016-04-19 14:19:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722218673885216768",
  "text" : "RT @POTUS: Thank you, Adrianne, for being Boston Strong. Terror and bombs can't beat us. We carry on. We finish the race! https:\/\/t.co\/55hm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/55hmcsCHbJ",
        "expanded_url" : "http:\/\/cbsloc.al\/1S6LCSs",
        "display_url" : "cbsloc.al\/1S6LCSs"
      } ]
    },
    "geo" : { },
    "id_str" : "722217866330636288",
    "text" : "Thank you, Adrianne, for being Boston Strong. Terror and bombs can't beat us. We carry on. We finish the race! https:\/\/t.co\/55hmcsCHbJ",
    "id" : 722217866330636288,
    "created_at" : "2016-04-19 00:18:52 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 722218673885216768,
  "created_at" : "2016-04-19 00:22:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 80, 97 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/QFzxZLmnET",
      "expanded_url" : "http:\/\/findyourpark.com",
      "display_url" : "findyourpark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "722182653533949953",
  "text" : "RT @FactsOnClimate: ICYMI: Thanks to @POTUS, there's a lot more to explore this #NationalParkWeek: https:\/\/t.co\/QFzxZLmnET #FindYourPark ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 17, 23 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/722154190940733441\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/VUuHiZ8byU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWbZ3QVIAAI14f.jpg",
        "id_str" : "722154183894310912",
        "id" : 722154183894310912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWbZ3QVIAAI14f.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/VUuHiZ8byU"
      } ],
      "hashtags" : [ {
        "text" : "NationalParkWeek",
        "indices" : [ 60, 77 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/QFzxZLmnET",
        "expanded_url" : "http:\/\/findyourpark.com",
        "display_url" : "findyourpark.com"
      } ]
    },
    "geo" : { },
    "id_str" : "722154190940733441",
    "text" : "ICYMI: Thanks to @POTUS, there's a lot more to explore this #NationalParkWeek: https:\/\/t.co\/QFzxZLmnET #FindYourPark https:\/\/t.co\/VUuHiZ8byU",
    "id" : 722154190940733441,
    "created_at" : "2016-04-18 20:05:50 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 722182653533949953,
  "created_at" : "2016-04-18 21:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722170969943478273\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/gPO7fPG1nW",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgWqlV9WcAIr-88.jpg",
      "id_str" : "722170873789181954",
      "id" : 722170873789181954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgWqlV9WcAIr-88.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/gPO7fPG1nW"
    } ],
    "hashtags" : [ {
      "text" : "ThanksForFollowing",
      "indices" : [ 24, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722170969943478273",
  "text" : "We just hit 10 million! #ThanksForFollowing https:\/\/t.co\/gPO7fPG1nW",
  "id" : 722170969943478273,
  "created_at" : "2016-04-18 21:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722166602989486080\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/qYp1Qdiymr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWmjHTUkAAQYR3.jpg",
      "id_str" : "722166437448552448",
      "id" : 722166437448552448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWmjHTUkAAQYR3.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/qYp1Qdiymr"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/v0fDlXOWDk",
      "expanded_url" : "http:\/\/go.wh.gov\/TaxDay",
      "display_url" : "go.wh.gov\/TaxDay"
    } ]
  },
  "geo" : { },
  "id_str" : "722166602989486080",
  "text" : "FACT: Middle-class families are paying historically low federal income tax rates \u2192 https:\/\/t.co\/v0fDlXOWDk #TaxDay https:\/\/t.co\/qYp1Qdiymr",
  "id" : 722166602989486080,
  "created_at" : "2016-04-18 20:55:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722154902391242752\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bOu8gvFynv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWbrYaUEAEYxAQ.jpg",
      "id_str" : "722154484852330497",
      "id" : 722154484852330497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWbrYaUEAEYxAQ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/bOu8gvFynv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/v0fDlXOWDk",
      "expanded_url" : "http:\/\/go.wh.gov\/TaxDay",
      "display_url" : "go.wh.gov\/TaxDay"
    } ]
  },
  "geo" : { },
  "id_str" : "722154902391242752",
  "text" : ".@POTUS has fought for and passed significant tax relief for nearly all working families: https:\/\/t.co\/v0fDlXOWDk https:\/\/t.co\/bOu8gvFynv",
  "id" : 722154902391242752,
  "created_at" : "2016-04-18 20:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722135984108777473\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/T12rlZBgRt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWKzSTW8AECYnp.jpg",
      "id_str" : "722135928953827329",
      "id" : 722135928953827329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWKzSTW8AECYnp.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/T12rlZBgRt"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 3, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/n1vDgq4RgW",
      "expanded_url" : "http:\/\/go.wh.gov\/7NEgfn",
      "display_url" : "go.wh.gov\/7NEgfn"
    } ]
  },
  "geo" : { },
  "id_str" : "722135984108777473",
  "text" : "On #TaxDay, take a look at what @POTUS has done to make the tax code fairer: https:\/\/t.co\/n1vDgq4RgW https:\/\/t.co\/T12rlZBgRt",
  "id" : 722135984108777473,
  "created_at" : "2016-04-18 18:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722123292107214849\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/gTfLyT1jOh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgV_ONCWcAAeZ3c.jpg",
      "id_str" : "722123197257248768",
      "id" : 722123197257248768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgV_ONCWcAAeZ3c.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/gTfLyT1jOh"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/v0fDlXOWDk",
      "expanded_url" : "http:\/\/go.wh.gov\/TaxDay",
      "display_url" : "go.wh.gov\/TaxDay"
    } ]
  },
  "geo" : { },
  "id_str" : "722123292107214849",
  "text" : "Share the news on #TaxDay: Middle-class federal income taxes are near historic lows.  https:\/\/t.co\/v0fDlXOWDk https:\/\/t.co\/gTfLyT1jOh",
  "id" : 722123292107214849,
  "created_at" : "2016-04-18 18:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/oqRpqVBKnC",
      "expanded_url" : "http:\/\/bit.ly\/1STQve5",
      "display_url" : "bit.ly\/1STQve5"
    } ]
  },
  "geo" : { },
  "id_str" : "722118525456945153",
  "text" : "RT @NatlParkService: Former President Jimmy Carter was made an Honorary National Park Ranger today! https:\/\/t.co\/oqRpqVBKnC #FindYourPark h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatlParkService\/status\/721823032847790080\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wNUrR7pcrW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgRuOSoUUAACPln.jpg",
        "id_str" : "721823032084287488",
        "id" : 721823032084287488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgRuOSoUUAACPln.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wNUrR7pcrW"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/oqRpqVBKnC",
        "expanded_url" : "http:\/\/bit.ly\/1STQve5",
        "display_url" : "bit.ly\/1STQve5"
      } ]
    },
    "geo" : { },
    "id_str" : "721823032847790080",
    "text" : "Former President Jimmy Carter was made an Honorary National Park Ranger today! https:\/\/t.co\/oqRpqVBKnC #FindYourPark https:\/\/t.co\/wNUrR7pcrW",
    "id" : 721823032847790080,
    "created_at" : "2016-04-17 22:09:56 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 722118525456945153,
  "created_at" : "2016-04-18 17:44:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722113227149062144\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5WOngnj7jL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVxt0DW4AAbHCY.jpg",
      "id_str" : "722108347143610368",
      "id" : 722108347143610368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVxt0DW4AAbHCY.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/5WOngnj7jL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722113227149062144",
  "text" : "Since day one of his presidency, @POTUS has fought to make sure America's wealthy few pay their fair share. https:\/\/t.co\/5WOngnj7jL",
  "id" : 722113227149062144,
  "created_at" : "2016-04-18 17:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722108146399973377\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2xBSd0hn2Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVxeIqWsAAt0XE.jpg",
      "id_str" : "722108077797978112",
      "id" : 722108077797978112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVxeIqWsAAt0XE.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/2xBSd0hn2Z"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/v0fDlXOWDk",
      "expanded_url" : "http:\/\/go.wh.gov\/TaxDay",
      "display_url" : "go.wh.gov\/TaxDay"
    } ]
  },
  "geo" : { },
  "id_str" : "722108146399973377",
  "text" : "It's #TaxDay! Here's a look at what @POTUS has done to provide relief to working families: https:\/\/t.co\/v0fDlXOWDk https:\/\/t.co\/2xBSd0hn2Z",
  "id" : 722108146399973377,
  "created_at" : "2016-04-18 17:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/722099811026010112\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/gMCDVoHL68",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVp822UMAAQxwp.jpg",
      "id_str" : "722099809499230208",
      "id" : 722099809499230208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVp822UMAAQxwp.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gMCDVoHL68"
    } ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 6, 23 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722099811026010112",
  "text" : "Happy #NationalParkWeek! This week, national parks are free across the country! Where will you go? #FindYourPark https:\/\/t.co\/gMCDVoHL68",
  "id" : 722099811026010112,
  "created_at" : "2016-04-18 16:29:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "indices" : [ 3, 19 ],
      "id_str" : "2812768561",
      "id" : 2812768561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722083974760304642",
  "text" : "RT @KensingtonRoyal: The Duke and Duchess of Cambridge and Prince Harry will host President and Mrs Obama for dinner on Friday at Kensingto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722077716342681600",
    "text" : "The Duke and Duchess of Cambridge and Prince Harry will host President and Mrs Obama for dinner on Friday at Kensington Palace",
    "id" : 722077716342681600,
    "created_at" : "2016-04-18 15:01:57 +0000",
    "user" : {
      "name" : "Kensington Palace",
      "screen_name" : "KensingtonRoyal",
      "protected" : false,
      "id_str" : "2812768561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798099622455640065\/4XELymPa_normal.jpg",
      "id" : 2812768561,
      "verified" : true
    }
  },
  "id" : 722083974760304642,
  "created_at" : "2016-04-18 15:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722082295155466241",
  "text" : "RT @Interior: RT to spread the word \u2192 Free entrance to all national parks April 16-24 for National Park Week #FindYourPark https:\/\/t.co\/j2n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/720750802718035968\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/j2nmdNGhq8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCfAuJUAAA_V5u.jpg",
        "id_str" : "720750775115186176",
        "id" : 720750775115186176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCfAuJUAAA_V5u.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/j2nmdNGhq8"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720750802718035968",
    "text" : "RT to spread the word \u2192 Free entrance to all national parks April 16-24 for National Park Week #FindYourPark https:\/\/t.co\/j2nmdNGhq8",
    "id" : 720750802718035968,
    "created_at" : "2016-04-14 23:09:16 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 722082295155466241,
  "created_at" : "2016-04-18 15:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/SHpLWDE1lV",
      "expanded_url" : "http:\/\/go.wh.gov\/HXJ7bu",
      "display_url" : "go.wh.gov\/HXJ7bu"
    } ]
  },
  "geo" : { },
  "id_str" : "721894904952131585",
  "text" : "\"I understand we have a live chicken!\"\u2014@POTUS checks out his final #WHScienceFair in this West Wing Week: https:\/\/t.co\/SHpLWDE1lV",
  "id" : 721894904952131585,
  "created_at" : "2016-04-18 02:55:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentorIRL",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/hvtvCpbvob",
      "expanded_url" : "http:\/\/go.wh.gov\/Wn79bW",
      "display_url" : "go.wh.gov\/Wn79bW"
    } ]
  },
  "geo" : { },
  "id_str" : "721789607776391168",
  "text" : "Connect Four Game Face. #MentorIRL https:\/\/t.co\/hvtvCpbvob",
  "id" : 721789607776391168,
  "created_at" : "2016-04-17 19:57:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721756866557005828",
  "text" : "\"I'm going to keep doing everything I can to make sure that our free market works for everyone.\" \u2014@POTUS: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721756866557005828,
  "created_at" : "2016-04-17 17:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721741776151650304",
  "text" : "\"Competition is good for consumers, workers, businesses, and our economy\" \u2014@POTUS on new action to spur competition: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721741776151650304,
  "created_at" : "2016-04-17 16:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Stephen Curry",
      "screen_name" : "StephenCurry30",
      "indices" : [ 46, 61 ],
      "id_str" : "42562446",
      "id" : 42562446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentorIRL",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/kKAv3UYm1W",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/hvtvCpt6ML",
      "expanded_url" : "http:\/\/go.wh.gov\/Wn79bW",
      "display_url" : "go.wh.gov\/Wn79bW"
    } ]
  },
  "geo" : { },
  "id_str" : "721728979007365120",
  "text" : "From the cutting room floor of the @POTUS and @StephenCurry30 taping for https:\/\/t.co\/kKAv3UYm1W. #MentorIRL https:\/\/t.co\/hvtvCpt6ML",
  "id" : 721728979007365120,
  "created_at" : "2016-04-17 15:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721726422646005760",
  "text" : "\"One industry that's ripe for change is cable TV.\" \u2014@POTUS on taking action to spur competition for cable boxes: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721726422646005760,
  "created_at" : "2016-04-17 15:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721711489569005569",
  "text" : "\"I've directed federal agencies to identify anti-competitive behavior in different industries\" \u2014@POTUS: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721711489569005569,
  "created_at" : "2016-04-17 14:46:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Stephen Curry",
      "screen_name" : "StephenCurry30",
      "indices" : [ 50, 65 ],
      "id_str" : "42562446",
      "id" : 42562446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentorIRL",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/qtf5dCNxBC",
      "expanded_url" : "http:\/\/mentor.gov",
      "display_url" : "mentor.gov"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/NkW7KfnyRf",
      "expanded_url" : "http:\/\/go.wh.gov\/upzNG6",
      "display_url" : "go.wh.gov\/upzNG6"
    } ]
  },
  "geo" : { },
  "id_str" : "721455128763432960",
  "text" : "\"I'm really proud of you, man.\" \u2014@POTUS mentoring @StephenCurry30\nBecome a #MentorIRL at https:\/\/t.co\/qtf5dCNxBC https:\/\/t.co\/NkW7KfnyRf",
  "id" : 721455128763432960,
  "created_at" : "2016-04-16 21:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "StephenCurry30",
      "indices" : [ 31, 46 ],
      "id_str" : "42562446",
      "id" : 42562446
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentorIRL",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/kKAv3VfWTu",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/NkW7KfnyRf",
      "expanded_url" : "http:\/\/go.wh.gov\/upzNG6",
      "display_url" : "go.wh.gov\/upzNG6"
    } ]
  },
  "geo" : { },
  "id_str" : "721440047807864832",
  "text" : "\"Maybe I should shoot lefty.\" \u2014@StephenCurry30\n\"You can try that.\" \u2014@POTUS\nhttps:\/\/t.co\/kKAv3VfWTu #MentorIRL\nhttps:\/\/t.co\/NkW7KfnyRf",
  "id" : 721440047807864832,
  "created_at" : "2016-04-16 20:48:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 24, 28 ],
      "id_str" : "19923144",
      "id" : 19923144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kKAv3UYm1W",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NkW7Kf5XZH",
      "expanded_url" : "http:\/\/go.wh.gov\/upzNG6",
      "display_url" : "go.wh.gov\/upzNG6"
    } ]
  },
  "geo" : { },
  "id_str" : "721424875026530304",
  "text" : "You don\u2019t need to be an @NBA star or the President to be someone\u2019s hero. Become a mentor at https:\/\/t.co\/kKAv3UYm1W. https:\/\/t.co\/NkW7Kf5XZH",
  "id" : 721424875026530304,
  "created_at" : "2016-04-16 19:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Stephen Curry",
      "screen_name" : "StephenCurry30",
      "indices" : [ 45, 60 ],
      "id_str" : "42562446",
      "id" : 42562446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MentorIRL",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/tfW3hr3zW7",
      "expanded_url" : "http:\/\/go.wh.gov\/LU6w47",
      "display_url" : "go.wh.gov\/LU6w47"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kKAv3VfWTu",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "721417528145129472",
  "text" : "Watch \u201CThe Mentorship\u201D starring @POTUS &amp; @StephenCurry30 at https:\/\/t.co\/tfW3hr3zW7, then become a #MentorIRL at https:\/\/t.co\/kKAv3VfWTu.",
  "id" : 721417528145129472,
  "created_at" : "2016-04-16 19:18:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721397860810403840",
  "text" : "\"The deck should not be stacked in favor of the wealthiest\" \u2014@POTUS on ensuring our free market works for everyone: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721397860810403840,
  "created_at" : "2016-04-16 18:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721390264175038464",
  "text" : "\"Too many companies are engaging in behaviors that stifle competition\" \u2014@POTUS on taking action to spur competition: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721390264175038464,
  "created_at" : "2016-04-16 17:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721382817226104832",
  "text" : "\"One of America's greatest strengths is our free market. A thriving private sector is the lifeblood of our economy.\" https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721382817226104832,
  "created_at" : "2016-04-16 17:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/z4mA9kN2ea",
      "expanded_url" : "http:\/\/go.wh.gov\/iigHr2",
      "display_url" : "go.wh.gov\/iigHr2"
    } ]
  },
  "geo" : { },
  "id_str" : "721377591106535424",
  "text" : "Watch @POTUS's weekly address on new actions we're taking to make sure our free market works for everyone: https:\/\/t.co\/z4mA9kN2ea",
  "id" : 721377591106535424,
  "created_at" : "2016-04-16 16:39:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/721118480473296897\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/T1uS0N4C2m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgHhr0HWwAEmTNG.jpg",
      "id_str" : "721105558196109313",
      "id" : 721105558196109313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgHhr0HWwAEmTNG.jpg",
      "sizes" : [ {
        "h" : 722,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/T1uS0N4C2m"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721118480473296897",
  "text" : "Crawling race! #ObamaAndKids https:\/\/t.co\/T1uS0N4C2m",
  "id" : 721118480473296897,
  "created_at" : "2016-04-15 23:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/WP12LS5VY0",
      "expanded_url" : "http:\/\/snpy.tv\/1p4HR4p",
      "display_url" : "snpy.tv\/1p4HR4p"
    } ]
  },
  "geo" : { },
  "id_str" : "721065712094154752",
  "text" : "Watch @POTUS reflect on what Boston taught us about strength in the face of fear. #OneBostonDay https:\/\/t.co\/WP12LS5VY0",
  "id" : 721065712094154752,
  "created_at" : "2016-04-15 20:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 63, 76 ]
    }, {
      "text" : "OneBostonDay",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/WP12LS5VY0",
      "expanded_url" : "http:\/\/snpy.tv\/1p4HR4p",
      "display_url" : "snpy.tv\/1p4HR4p"
    } ]
  },
  "geo" : { },
  "id_str" : "721049020651741184",
  "text" : "\"How to be strong. How to be resilient.\" \u2014@POTUS on what being #BostonStrong taught all Americans. #OneBostonDay https:\/\/t.co\/WP12LS5VY0",
  "id" : 721049020651741184,
  "created_at" : "2016-04-15 18:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 13, 26 ]
    }, {
      "text" : "BostonStrong",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Zxjre77QyP",
      "expanded_url" : "https:\/\/www.youtube.com\/embed\/h3J4HaxCvfE?autoplay=1&rel=0",
      "display_url" : "youtube.com\/embed\/h3J4HaxC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721047374009917440",
  "text" : "RT @DrBiden: #OneBostonDay has inspired countless acts of kindness, big and small. #BostonStrong https:\/\/t.co\/Zxjre77QyP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneBostonDay",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "BostonStrong",
        "indices" : [ 70, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/Zxjre77QyP",
        "expanded_url" : "https:\/\/www.youtube.com\/embed\/h3J4HaxCvfE?autoplay=1&rel=0",
        "display_url" : "youtube.com\/embed\/h3J4HaxC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "721018074661588992",
    "text" : "#OneBostonDay has inspired countless acts of kindness, big and small. #BostonStrong https:\/\/t.co\/Zxjre77QyP",
    "id" : 721018074661588992,
    "created_at" : "2016-04-15 16:51:19 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 721047374009917440,
  "created_at" : "2016-04-15 18:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "indices" : [ 31, 43 ],
      "id_str" : "77764733",
      "id" : 77764733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721047276165165056",
  "text" : "RT @vj44: Today, we stand with @marty_walsh and all Bostonians as we honor #OneBostonDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Marty Walsh",
        "screen_name" : "marty_walsh",
        "indices" : [ 21, 33 ],
        "id_str" : "77764733",
        "id" : 77764733
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneBostonDay",
        "indices" : [ 65, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721023085810466816",
    "text" : "Today, we stand with @marty_walsh and all Bostonians as we honor #OneBostonDay",
    "id" : 721023085810466816,
    "created_at" : "2016-04-15 17:11:14 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 721047276165165056,
  "created_at" : "2016-04-15 18:47:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/721018503512195072\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/gbwDVgpwlT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CgGSeedUMAEu9AX.jpg",
      "id_str" : "721018467625742337",
      "id" : 721018467625742337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CgGSeedUMAEu9AX.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 590
      } ],
      "display_url" : "pic.twitter.com\/gbwDVgpwlT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jGdUfVXCmK",
      "expanded_url" : "http:\/\/go.wh.gov\/mixkmB",
      "display_url" : "go.wh.gov\/mixkmB"
    } ]
  },
  "geo" : { },
  "id_str" : "721018503512195072",
  "text" : ".@POTUS is getting tough on cable boxes. Here's how it could change your cable bill \u2192 https:\/\/t.co\/jGdUfVXCmK https:\/\/t.co\/gbwDVgpwlT",
  "id" : 721018503512195072,
  "created_at" : "2016-04-15 16:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/NF72TEnegU",
      "expanded_url" : "https:\/\/twitter.com\/marty_walsh\/status\/720999666054217728",
      "display_url" : "twitter.com\/marty_walsh\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721016715350413313",
  "text" : "RT @VP: We run. We endure. We are America. And we own the finish line. #OneBostonDay https:\/\/t.co\/NF72TEnegU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneBostonDay",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/NF72TEnegU",
        "expanded_url" : "https:\/\/twitter.com\/marty_walsh\/status\/720999666054217728",
        "display_url" : "twitter.com\/marty_walsh\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "721013464957861888",
    "text" : "We run. We endure. We are America. And we own the finish line. #OneBostonDay https:\/\/t.co\/NF72TEnegU",
    "id" : 721013464957861888,
    "created_at" : "2016-04-15 16:33:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 721016715350413313,
  "created_at" : "2016-04-15 16:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720997588229570560\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/9OtRU5vE42",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgF_b5BUUAMOKu3.jpg",
      "id_str" : "720997532495532035",
      "id" : 720997532495532035,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgF_b5BUUAMOKu3.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/9OtRU5vE42"
    } ],
    "hashtags" : [ {
      "text" : "JackieRobinsonDay",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/YTByh8mLO9",
      "expanded_url" : "http:\/\/go.wh.gov\/irBK5C",
      "display_url" : "go.wh.gov\/irBK5C"
    } ]
  },
  "geo" : { },
  "id_str" : "720997588229570560",
  "text" : "What @POTUS's historic trip to Cuba meant to Jackie Robinsons' family: https:\/\/t.co\/YTByh8mLO9 #JackieRobinsonDay https:\/\/t.co\/9OtRU5vE42",
  "id" : 720997588229570560,
  "created_at" : "2016-04-15 15:29:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jGdUfWfdLk",
      "expanded_url" : "http:\/\/go.wh.gov\/mixkmB",
      "display_url" : "go.wh.gov\/mixkmB"
    } ]
  },
  "geo" : { },
  "id_str" : "720991160626520064",
  "text" : ".@POTUS's new executive order:\nBoosts competition \u2713\nEmpowers consumers \u2713\nSupports economic growth \u2713\n\nGet the facts: https:\/\/t.co\/jGdUfWfdLk",
  "id" : 720991160626520064,
  "created_at" : "2016-04-15 15:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 3, 16 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YahooFinance\/status\/720984440189620224\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/G3gJVh0Rdt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgFzPXDWIAEVsga.jpg",
      "id_str" : "720984123079270401",
      "id" : 720984123079270401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgFzPXDWIAEVsga.jpg",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/G3gJVh0Rdt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/V5kmYysFBv",
      "expanded_url" : "http:\/\/yhoo.it\/1TVPTtd",
      "display_url" : "yhoo.it\/1TVPTtd"
    } ]
  },
  "geo" : { },
  "id_str" : "720988249167175681",
  "text" : "RT @YahooFinance: Exclusive: President Obama gets tough on set top boxes - Watch https:\/\/t.co\/V5kmYysFBv https:\/\/t.co\/G3gJVh0Rdt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YahooFinance\/status\/720984440189620224\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/G3gJVh0Rdt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgFzPXDWIAEVsga.jpg",
        "id_str" : "720984123079270401",
        "id" : 720984123079270401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgFzPXDWIAEVsga.jpg",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 660
        } ],
        "display_url" : "pic.twitter.com\/G3gJVh0Rdt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/V5kmYysFBv",
        "expanded_url" : "http:\/\/yhoo.it\/1TVPTtd",
        "display_url" : "yhoo.it\/1TVPTtd"
      } ]
    },
    "geo" : { },
    "id_str" : "720984440189620224",
    "text" : "Exclusive: President Obama gets tough on set top boxes - Watch https:\/\/t.co\/V5kmYysFBv https:\/\/t.co\/G3gJVh0Rdt",
    "id" : 720984440189620224,
    "created_at" : "2016-04-15 14:37:40 +0000",
    "user" : {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "protected" : false,
      "id_str" : "19546277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710978975376388096\/1U2djlFO_normal.jpg",
      "id" : 19546277,
      "verified" : true
    }
  },
  "id" : 720988249167175681,
  "created_at" : "2016-04-15 14:52:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jGdUfVXCmK",
      "expanded_url" : "http:\/\/go.wh.gov\/mixkmB",
      "display_url" : "go.wh.gov\/mixkmB"
    } ]
  },
  "geo" : { },
  "id_str" : "720986609034747905",
  "text" : "BREAKING: @POTUS signs new executive order to spur corporate competition. Here's how it could get you a better deal\u2192 https:\/\/t.co\/jGdUfVXCmK",
  "id" : 720986609034747905,
  "created_at" : "2016-04-15 14:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President's Park",
      "screen_name" : "PresParkNPS",
      "indices" : [ 88, 100 ],
      "id_str" : "2451908772",
      "id" : 2451908772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Ax7Km3dMmL",
      "expanded_url" : "http:\/\/go.wh.gov\/AcnnfZ",
      "display_url" : "go.wh.gov\/AcnnfZ"
    } ]
  },
  "geo" : { },
  "id_str" : "720786288027107328",
  "text" : "Did you know the White House is a national park? Apply to social media your way through @PresParkNPS: https:\/\/t.co\/Ax7Km3dMmL #FindYourPark",
  "id" : 720786288027107328,
  "created_at" : "2016-04-15 01:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WWP",
      "screen_name" : "wwp",
      "indices" : [ 85, 89 ],
      "id_str" : "33600887",
      "id" : 33600887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/3QdyyUKZkB",
      "expanded_url" : "http:\/\/snpy.tv\/1Vt476B",
      "display_url" : "snpy.tv\/1Vt476B"
    } ]
  },
  "geo" : { },
  "id_str" : "720778771767242752",
  "text" : "On your mark! Get set! Ride! \uD83D\uDEB2  \n\nWatch @POTUS &amp; military families celebrate the @WWP ride as it kicked off today: https:\/\/t.co\/3QdyyUKZkB",
  "id" : 720778771767242752,
  "created_at" : "2016-04-15 01:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mapVCJ6VaY",
      "expanded_url" : "http:\/\/snpy.tv\/1Saw3G4",
      "display_url" : "snpy.tv\/1Saw3G4"
    } ]
  },
  "geo" : { },
  "id_str" : "720769221974560768",
  "text" : "\"There are things that are important. And you\u2019ll need to fight for them in your lives.\" \n\n.@POTUS's words of wisdom: https:\/\/t.co\/mapVCJ6VaY",
  "id" : 720769221974560768,
  "created_at" : "2016-04-15 00:22:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720747972577869824\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/HqNQpfDYHX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCb1lyWEAAQq5z.jpg",
      "id_str" : "720747285357924352",
      "id" : 720747285357924352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCb1lyWEAAQq5z.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/HqNQpfDYHX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/n1vDgpNgpo",
      "expanded_url" : "http:\/\/go.wh.gov\/7NEgfn",
      "display_url" : "go.wh.gov\/7NEgfn"
    } ]
  },
  "geo" : { },
  "id_str" : "720747972577869824",
  "text" : "Today, the wealthiest Americans are paying more of their fair share thanks to @POTUS: https:\/\/t.co\/n1vDgpNgpo https:\/\/t.co\/HqNQpfDYHX",
  "id" : 720747972577869824,
  "created_at" : "2016-04-14 22:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720732823439716353\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ZUazzUaGOQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCOrZWUYAAQt9t.jpg",
      "id_str" : "720732816569294848",
      "id" : 720732816569294848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCOrZWUYAAQt9t.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/ZUazzUaGOQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720732823439716353",
  "text" : "Good news: Under @POTUS, unemployment claims have dropped to match their lowest level in 42 years. https:\/\/t.co\/ZUazzUaGOQ",
  "id" : 720732823439716353,
  "created_at" : "2016-04-14 21:57:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "indices" : [ 3, 15 ],
      "id_str" : "77764733",
      "id" : 77764733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720732065621282818",
  "text" : "RT @marty_walsh: Tomorrow, across the city &amp; nation, please join us in a moment of silence at 2:49 p.m. on #OneBostonDay. https:\/\/t.co\/1BmG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marty_walsh\/status\/720719054093316098\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/1BmGWKAKGi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCCKR2XEAAUWcI.jpg",
        "id_str" : "720719053480988672",
        "id" : 720719053480988672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCCKR2XEAAUWcI.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 1054
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1BmGWKAKGi"
      } ],
      "hashtags" : [ {
        "text" : "OneBostonDay",
        "indices" : [ 94, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720719054093316098",
    "text" : "Tomorrow, across the city &amp; nation, please join us in a moment of silence at 2:49 p.m. on #OneBostonDay. https:\/\/t.co\/1BmGWKAKGi",
    "id" : 720719054093316098,
    "created_at" : "2016-04-14 21:03:07 +0000",
    "user" : {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "protected" : false,
      "id_str" : "77764733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616696311857844224\/JFuutOER_normal.jpg",
      "id" : 77764733,
      "verified" : true
    }
  },
  "id" : 720732065621282818,
  "created_at" : "2016-04-14 21:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720721321215266816\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/jLTia0xgBu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCEFQIXEAAEpU8.jpg",
      "id_str" : "720721166143524864",
      "id" : 720721166143524864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCEFQIXEAAEpU8.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/jLTia0xgBu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/n1vDgpNgpo",
      "expanded_url" : "http:\/\/go.wh.gov\/7NEgfn",
      "display_url" : "go.wh.gov\/7NEgfn"
    } ]
  },
  "geo" : { },
  "id_str" : "720721321215266816",
  "text" : "Middle-class families have a lower income tax rate than at almost any point in 60 years \u2192 https:\/\/t.co\/n1vDgpNgpo https:\/\/t.co\/jLTia0xgBu",
  "id" : 720721321215266816,
  "created_at" : "2016-04-14 21:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720716369344466944\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/9nmoA6KXdA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgB_qjnWQAAicF9.jpg",
      "id_str" : "720716309470789632",
      "id" : 720716309470789632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgB_qjnWQAAicF9.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/9nmoA6KXdA"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/n1vDgpNgpo",
      "expanded_url" : "http:\/\/go.wh.gov\/7NEgfn",
      "display_url" : "go.wh.gov\/7NEgfn"
    } ]
  },
  "geo" : { },
  "id_str" : "720716369344466944",
  "text" : "Ahead of #TaxDay, take a look at what @POTUS has done to make the tax code fairer: https:\/\/t.co\/n1vDgpNgpo https:\/\/t.co\/9nmoA6KXdA",
  "id" : 720716369344466944,
  "created_at" : "2016-04-14 20:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/8VrWqQMO9Y",
      "expanded_url" : "http:\/\/go.wh.gov\/Its-On-Us-Champs",
      "display_url" : "go.wh.gov\/Its-On-Us-Cham\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720644799359950848",
  "text" : "RT @VP: Proud to stand with some real champions\u2014real heroes\u2014today at the White House. Starts at 2 p.m. Eastern: https:\/\/t.co\/8VrWqQMO9Y #It\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/8VrWqQMO9Y",
        "expanded_url" : "http:\/\/go.wh.gov\/Its-On-Us-Champs",
        "display_url" : "go.wh.gov\/Its-On-Us-Cham\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720634602461593600",
    "text" : "Proud to stand with some real champions\u2014real heroes\u2014today at the White House. Starts at 2 p.m. Eastern: https:\/\/t.co\/8VrWqQMO9Y #ItsOnUs",
    "id" : 720634602461593600,
    "created_at" : "2016-04-14 15:27:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 720644799359950848,
  "created_at" : "2016-04-14 16:08:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/720639660578512896\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/rbjpCxpB4k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgA57EFUsAAzFvJ.jpg",
      "id_str" : "720639627250413568",
      "id" : 720639627250413568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgA57EFUsAAzFvJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 376
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 376
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 376
      } ],
      "display_url" : "pic.twitter.com\/rbjpCxpB4k"
    } ],
    "hashtags" : [ {
      "text" : "WoundedWarriorRide",
      "indices" : [ 37, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/T4XggWtaLv",
      "expanded_url" : "http:\/\/go.wh.gov\/VCrvap",
      "display_url" : "go.wh.gov\/VCrvap"
    } ]
  },
  "geo" : { },
  "id_str" : "720639660578512896",
  "text" : "And they're off! Take a lap with the #WoundedWarriorRide around the South Lawn: https:\/\/t.co\/T4XggWtaLv \uD83D\uDEB4\uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/rbjpCxpB4k",
  "id" : 720639660578512896,
  "created_at" : "2016-04-14 15:47:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/BQ55zZbBpp",
      "expanded_url" : "http:\/\/go.wh.gov\/WJ14Zr",
      "display_url" : "go.wh.gov\/WJ14Zr"
    } ]
  },
  "geo" : { },
  "id_str" : "720637823313973248",
  "text" : "\"Jason\u2019s spirit, the spirit of all of you, is the story of our armed forces.\"\n\nRead Jason's letter to @POTUS: https:\/\/t.co\/BQ55zZbBpp",
  "id" : 720637823313973248,
  "created_at" : "2016-04-14 15:40:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720636577366597632\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/sJpy9GS7ZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgA3GYDUYAAIO4f.jpg",
      "id_str" : "720636523054391296",
      "id" : 720636523054391296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgA3GYDUYAAIO4f.jpg",
      "sizes" : [ {
        "h" : 4096,
        "resize" : "fit",
        "w" : 2731
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sJpy9GS7ZK"
    } ],
    "hashtags" : [ {
      "text" : "WoundedWarriorRide",
      "indices" : [ 88, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720636577366597632",
  "text" : "\"Part of this great movement is to help each get other across the finish line.\" \u2014@POTUS #WoundedWarriorRide https:\/\/t.co\/sJpy9GS7ZK",
  "id" : 720636577366597632,
  "created_at" : "2016-04-14 15:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WoundedWarriorRide",
      "indices" : [ 61, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/GD4FwCj6qG",
      "expanded_url" : "http:\/\/go.wh.gov\/QuCLc7",
      "display_url" : "go.wh.gov\/QuCLc7"
    } ]
  },
  "geo" : { },
  "id_str" : "720635110266044416",
  "text" : "RT @WHLive: Great day for a \uD83D\uDEB2 ride. Watch @POTUS welcome the #WoundedWarriorRide to the White House: https:\/\/t.co\/GD4FwCj6qG https:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 30, 36 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/720635003260932096\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/iKcu1OaQhA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgA1tumUYAAYUT4.jpg",
        "id_str" : "720635000098414592",
        "id" : 720635000098414592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgA1tumUYAAYUT4.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/iKcu1OaQhA"
      } ],
      "hashtags" : [ {
        "text" : "WoundedWarriorRide",
        "indices" : [ 49, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/GD4FwCj6qG",
        "expanded_url" : "http:\/\/go.wh.gov\/QuCLc7",
        "display_url" : "go.wh.gov\/QuCLc7"
      } ]
    },
    "geo" : { },
    "id_str" : "720635003260932096",
    "text" : "Great day for a \uD83D\uDEB2 ride. Watch @POTUS welcome the #WoundedWarriorRide to the White House: https:\/\/t.co\/GD4FwCj6qG https:\/\/t.co\/iKcu1OaQhA",
    "id" : 720635003260932096,
    "created_at" : "2016-04-14 15:29:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 720635110266044416,
  "created_at" : "2016-04-14 15:29:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720628886556565505\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/WGUbGfamkU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgAwF4-WwAI6gHJ.jpg",
      "id_str" : "720628818130681858",
      "id" : 720628818130681858,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgAwF4-WwAI6gHJ.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/WGUbGfamkU"
    } ],
    "hashtags" : [ {
      "text" : "WoundedWarriorRide",
      "indices" : [ 40, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/McSpJgUuqS",
      "expanded_url" : "http:\/\/go.wh.gov\/QuCLc7",
      "display_url" : "go.wh.gov\/QuCLc7"
    } ]
  },
  "geo" : { },
  "id_str" : "720628886556565505",
  "text" : "At 11:25am ET, watch @POTUS welcome the #WoundedWarriorRide to the White House: https:\/\/t.co\/McSpJgUuqS \uD83D\uDEB2 \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/WGUbGfamkU",
  "id" : 720628886556565505,
  "created_at" : "2016-04-14 15:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rutgers University",
      "screen_name" : "RutgersU",
      "indices" : [ 105, 114 ],
      "id_str" : "19272796",
      "id" : 19272796
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 116, 124 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720627877788717057",
  "text" : "RT @Denis44: .@POTUS will deliver his last commencement addresses as President to the classes of 2016 at @RutgersU, @HowardU, and @AF_Acade\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Rutgers University",
        "screen_name" : "RutgersU",
        "indices" : [ 92, 101 ],
        "id_str" : "19272796",
        "id" : 19272796
      }, {
        "name" : "Howard University",
        "screen_name" : "HowardU",
        "indices" : [ 103, 111 ],
        "id_str" : "27147528",
        "id" : 27147528
      }, {
        "name" : "USAFA (Official)",
        "screen_name" : "AF_Academy",
        "indices" : [ 117, 128 ],
        "id_str" : "69073724",
        "id" : 69073724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720627714747535360",
    "text" : ".@POTUS will deliver his last commencement addresses as President to the classes of 2016 at @RutgersU, @HowardU, and @AF_Academy!",
    "id" : 720627714747535360,
    "created_at" : "2016-04-14 15:00:10 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 720627877788717057,
  "created_at" : "2016-04-14 15:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 27, 36 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720477646870736896",
  "text" : "RT @POTUS: Congrats to the @Warriors, a great group of guys on and off the court. If somebody had to break the Bulls' record, I'm glad it's\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GoldenStateWarriors",
        "screen_name" : "warriors",
        "indices" : [ 16, 25 ],
        "id_str" : "26270913",
        "id" : 26270913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720476914243280896",
    "text" : "Congrats to the @Warriors, a great group of guys on and off the court. If somebody had to break the Bulls' record, I'm glad it's them.",
    "id" : 720476914243280896,
    "created_at" : "2016-04-14 05:00:56 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 720477646870736896,
  "created_at" : "2016-04-14 05:03:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 37, 46 ],
      "id_str" : "26270913",
      "id" : 26270913
    }, {
      "name" : "Kobe Bryant",
      "screen_name" : "kobebryant",
      "indices" : [ 91, 102 ],
      "id_str" : "1059194370",
      "id" : 1059194370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720416796558229504",
  "text" : "RT @POTUS: Big night of basketball - @Warriors chasing 73 and a farewell for an\nall-timer, @KobeBryant. NBA fans feeling like: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GoldenStateWarriors",
        "screen_name" : "warriors",
        "indices" : [ 26, 35 ],
        "id_str" : "26270913",
        "id" : 26270913
      }, {
        "name" : "Kobe Bryant",
        "screen_name" : "kobebryant",
        "indices" : [ 80, 91 ],
        "id_str" : "1059194370",
        "id" : 1059194370
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/720416675196223488\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/hvno2ZO5b0",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf9u8jmVIAEiO_e.jpg",
        "id_str" : "720416452029784065",
        "id" : 720416452029784065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf9u8jmVIAEiO_e.jpg",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hvno2ZO5b0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720416675196223488",
    "text" : "Big night of basketball - @Warriors chasing 73 and a farewell for an\nall-timer, @KobeBryant. NBA fans feeling like: https:\/\/t.co\/hvno2ZO5b0",
    "id" : 720416675196223488,
    "created_at" : "2016-04-14 01:01:34 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 720416796558229504,
  "created_at" : "2016-04-14 01:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalParkWeek",
      "indices" : [ 13, 30 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Ax7Km3dMmL",
      "expanded_url" : "http:\/\/go.wh.gov\/AcnnfZ",
      "display_url" : "go.wh.gov\/AcnnfZ"
    } ]
  },
  "geo" : { },
  "id_str" : "720415286969499652",
  "text" : "Next week is #NationalParkWeek! Want to come visit President's Park? Apply for the April 23 #FindYourPark InstaMeet: https:\/\/t.co\/Ax7Km3dMmL",
  "id" : 720415286969499652,
  "created_at" : "2016-04-14 00:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/sUylnvxUW6",
      "expanded_url" : "http:\/\/snpy.tv\/23vXdC1",
      "display_url" : "snpy.tv\/23vXdC1"
    } ]
  },
  "geo" : { },
  "id_str" : "720410513402802177",
  "text" : "\"For ISIL's leadership, it has been a bad few months.\" \u2014@POTUS on our military campaign to degrade and destroy ISIL: https:\/\/t.co\/sUylnvxUW6",
  "id" : 720410513402802177,
  "created_at" : "2016-04-14 00:37:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/cSHz0WxGrQ",
      "expanded_url" : "http:\/\/snpy.tv\/1S80Zqj",
      "display_url" : "snpy.tv\/1S80Zqj"
    } ]
  },
  "geo" : { },
  "id_str" : "720410230090244096",
  "text" : "RT @Denis44: A powerful perspective from @POTUS on his confidence in America and why we will prevail against ISIL. https:\/\/t.co\/cSHz0WxGrQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 28, 34 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/cSHz0WxGrQ",
        "expanded_url" : "http:\/\/snpy.tv\/1S80Zqj",
        "display_url" : "snpy.tv\/1S80Zqj"
      } ]
    },
    "geo" : { },
    "id_str" : "720410162733936640",
    "text" : "A powerful perspective from @POTUS on his confidence in America and why we will prevail against ISIL. https:\/\/t.co\/cSHz0WxGrQ",
    "id" : 720410162733936640,
    "created_at" : "2016-04-14 00:35:42 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 720410230090244096,
  "created_at" : "2016-04-14 00:35:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/RHT1advcKi",
      "expanded_url" : "http:\/\/snpy.tv\/1S7ZKrp",
      "display_url" : "snpy.tv\/1S7ZKrp"
    } ]
  },
  "geo" : { },
  "id_str" : "720409245292716032",
  "text" : "\"The ISIL core in Syria and Iraq continues to shrink.\" \u2014@POTUS on the progress in the fight against ISIL: https:\/\/t.co\/RHT1advcKi",
  "id" : 720409245292716032,
  "created_at" : "2016-04-14 00:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/RHfqVvpVvv",
      "expanded_url" : "http:\/\/snpy.tv\/22vnmLg",
      "display_url" : "snpy.tv\/22vnmLg"
    } ]
  },
  "geo" : { },
  "id_str" : "720407964276776960",
  "text" : "Watch @POTUS speak on the dedicated men and women leading our counterterrorism efforts: https:\/\/t.co\/RHfqVvpVvv",
  "id" : 720407964276776960,
  "created_at" : "2016-04-14 00:26:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720374544771354624",
  "text" : "\"Terrorists like ISIL and al Qaeda, they can\u2019t destroy a great nation like the United States of America.\" \u2014@POTUS",
  "id" : 720374544771354624,
  "created_at" : "2016-04-13 22:14:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720374057858805761",
  "text" : "\"Many have given their lives so that we can live free. We're safer because of their patriotic service.\" \u2014@POTUS",
  "id" : 720374057858805761,
  "created_at" : "2016-04-13 22:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720373622087426048",
  "text" : "\"We're sending a message: If you target Americans, you have no safe haven. We will find you.\" \u2014@POTUS",
  "id" : 720373622087426048,
  "created_at" : "2016-04-13 22:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720373354750869504",
  "text" : "\"Beyond Syria and Iraq, we continue to go after ISIL wherever it tries to rear its ugly head.\" \u2014@POTUS",
  "id" : 720373354750869504,
  "created_at" : "2016-04-13 22:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720373168062369792",
  "text" : "\"The U.S. will continue to do everything we can to help the cessation succeed and to advance a political solution to the Syrian civil war.\"",
  "id" : 720373168062369792,
  "created_at" : "2016-04-13 22:08:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720372829347143681",
  "text" : "\"The ISIL core in Syria and Iraq continues to shrink. Their ranks of fighters are estimated to be at the lowest levels in about two years\"",
  "id" : 720372829347143681,
  "created_at" : "2016-04-13 22:07:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720371613280043008",
  "text" : "\"As President and Commander in Chief, my top priority\u2014above all else\u2014is the security of the U.S. and the safety of the American people.\"",
  "id" : 720371613280043008,
  "created_at" : "2016-04-13 22:02:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/IczXdBjLxj",
      "expanded_url" : "http:\/\/go.wh.gov\/Tdzxmj",
      "display_url" : "go.wh.gov\/Tdzxmj"
    } ]
  },
  "geo" : { },
  "id_str" : "720359943472226304",
  "text" : "Tune in at 5:30pm ET: @POTUS will deliver a statement after meeting with his National Security Council: https:\/\/t.co\/IczXdBjLxj",
  "id" : 720359943472226304,
  "created_at" : "2016-04-13 21:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/qQ9CCxfmwE",
      "expanded_url" : "http:\/\/snpy.tv\/1qpAlC4",
      "display_url" : "snpy.tv\/1qpAlC4"
    } ]
  },
  "geo" : { },
  "id_str" : "720353395702308864",
  "text" : "In the new economy, computer science isn\u2019t optional\u2014it\u2019s a basic skill. #CSforAll #WHScienceFair\nhttps:\/\/t.co\/qQ9CCxfmwE",
  "id" : 720353395702308864,
  "created_at" : "2016-04-13 20:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bX1qEz02L9",
      "expanded_url" : "http:\/\/snpy.tv\/260IE8j",
      "display_url" : "snpy.tv\/260IE8j"
    } ]
  },
  "geo" : { },
  "id_str" : "720350920198856705",
  "text" : "\"Science has always been the hallmark of American progress.\" \u2014@POTUS at the #WHScienceFair https:\/\/t.co\/bX1qEz02L9",
  "id" : 720350920198856705,
  "created_at" : "2016-04-13 20:40:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/zebPBWO67z",
      "expanded_url" : "http:\/\/wh.gov\/ScienceFair",
      "display_url" : "wh.gov\/ScienceFair"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/lA6FZFUYsk",
      "expanded_url" : "http:\/\/snpy.tv\/23vmUCJ",
      "display_url" : "snpy.tv\/23vmUCJ"
    } ]
  },
  "geo" : { },
  "id_str" : "720346760216911872",
  "text" : ".@POTUS highlights a few of the young innovators at the #WHScienceFair: https:\/\/t.co\/zebPBWO67z https:\/\/t.co\/lA6FZFUYsk",
  "id" : 720346760216911872,
  "created_at" : "2016-04-13 20:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720343464177602563\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/I0W8YiRu7D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8seK7UkAAE42b.jpg",
      "id_str" : "720343362243432448",
      "id" : 720343362243432448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8seK7UkAAE42b.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I0W8YiRu7D"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720343464177602563",
  "text" : "Under @POTUS, the number of students graduating with engineering degrees has increased by 25,000. #WHScienceFair https:\/\/t.co\/I0W8YiRu7D",
  "id" : 720343464177602563,
  "created_at" : "2016-04-13 20:10:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 44, 52 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720341241053851648",
  "text" : "RT @PressSec: Getting ready to head over to @twitter's HQ in DC, send questions along for our chat at 4:30pm ET using #AskPressSec, looking\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 30, 38 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720340478726516737",
    "text" : "Getting ready to head over to @twitter's HQ in DC, send questions along for our chat at 4:30pm ET using #AskPressSec, looking forward to it!",
    "id" : 720340478726516737,
    "created_at" : "2016-04-13 19:58:48 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 720341241053851648,
  "created_at" : "2016-04-13 20:01:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720332613609594881",
  "text" : "\"We are counting on all of you to help build a brighter future.\" \u2014@POTUS to the students from across the country at the #WHScienceFair",
  "id" : 720332613609594881,
  "created_at" : "2016-04-13 19:27:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720331470603218944",
  "text" : "\"In the new economy, computer science isn\u2019t optional\u2014it\u2019s a basic skill.\" \u2014@POTUS #CSforAll",
  "id" : 720331470603218944,
  "created_at" : "2016-04-13 19:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720331219129516032",
  "text" : "\"We've got to give all our young people the tools they need to explore and discover, and to dig their hands in, and experiment\" \u2014@POTUS",
  "id" : 720331219129516032,
  "created_at" : "2016-04-13 19:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720329572873408514",
  "text" : "\"Somewhere in your generation\u2014maybe in this room\u2014are pioneers who are going to be the 1st to set their foot on Mars.\" \u2014@POTUS #WHScienceFair",
  "id" : 720329572873408514,
  "created_at" : "2016-04-13 19:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720328120918794240",
  "text" : "\"Our youngest innovators can change the world.\" \u2014@POTUS at the #WHScienceFair",
  "id" : 720328120918794240,
  "created_at" : "2016-04-13 19:09:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/DYD0fk2J18",
      "expanded_url" : "http:\/\/go.wh.gov\/ScienceFair",
      "display_url" : "go.wh.gov\/ScienceFair"
    } ]
  },
  "geo" : { },
  "id_str" : "720326947432198146",
  "text" : "Watch @POTUS talk with students from across the country at the #WHScienceFair who are leading the way in innovation: https:\/\/t.co\/DYD0fk2J18",
  "id" : 720326947432198146,
  "created_at" : "2016-04-13 19:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/720326286942429186\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/prFY0Uv0tY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8c8MBUYAQJQQV.jpg",
      "id_str" : "720326285747052548",
      "id" : 720326285747052548,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8c8MBUYAQJQQV.jpg",
      "sizes" : [ {
        "h" : 2225,
        "resize" : "fit",
        "w" : 2224
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/prFY0Uv0tY"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720326452001054720",
  "text" : "RT @Denis44: Thomas Jefferson is celebrating his birthday today with fellow inventors at the #WHScienceFair. HBD TJ. https:\/\/t.co\/prFY0Uv0tY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/720326286942429186\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/prFY0Uv0tY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8c8MBUYAQJQQV.jpg",
        "id_str" : "720326285747052548",
        "id" : 720326285747052548,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8c8MBUYAQJQQV.jpg",
        "sizes" : [ {
          "h" : 2225,
          "resize" : "fit",
          "w" : 2224
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/prFY0Uv0tY"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 80, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720326286942429186",
    "text" : "Thomas Jefferson is celebrating his birthday today with fellow inventors at the #WHScienceFair. HBD TJ. https:\/\/t.co\/prFY0Uv0tY",
    "id" : 720326286942429186,
    "created_at" : "2016-04-13 19:02:24 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 720326452001054720,
  "created_at" : "2016-04-13 19:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Mars Generation",
      "screen_name" : "TheMarsGen",
      "indices" : [ 3, 14 ],
      "id_str" : "1289621131",
      "id" : 1289621131
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720323357347028992",
  "text" : "RT @TheMarsGen: It was great to watch @POTUS take the time to encourage all of the students that were at the #WHScienceFair today! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheMarsGen\/status\/720323023136550912\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/IrGcUTVcaJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8Z95-UUAAKwp3.jpg",
        "id_str" : "720323016727482368",
        "id" : 720323016727482368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8Z95-UUAAKwp3.jpg",
        "sizes" : [ {
          "h" : 527,
          "resize" : "fit",
          "w" : 661
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 661
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IrGcUTVcaJ"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720323023136550912",
    "text" : "It was great to watch @POTUS take the time to encourage all of the students that were at the #WHScienceFair today! https:\/\/t.co\/IrGcUTVcaJ",
    "id" : 720323023136550912,
    "created_at" : "2016-04-13 18:49:26 +0000",
    "user" : {
      "name" : "The Mars Generation",
      "screen_name" : "TheMarsGen",
      "protected" : false,
      "id_str" : "1289621131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622061789484707840\/0-1_A-Dc_normal.jpg",
      "id" : 1289621131,
      "verified" : false
    }
  },
  "id" : 720323357347028992,
  "created_at" : "2016-04-13 18:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STEM Challenge",
      "screen_name" : "STEMChallenge",
      "indices" : [ 3, 17 ],
      "id_str" : "369478072",
      "id" : 369478072
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/STEMChallenge\/status\/720321718535872512\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/DflKNMrWFd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8YyRoUYAAYU1q.jpg",
      "id_str" : "720321717407604736",
      "id" : 720321717407604736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8YyRoUYAAYU1q.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DflKNMrWFd"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720322886460768258",
  "text" : "RT @STEMChallenge: Olivia's booth is all set up for a visit from the @POTUS on his tour of the #WHScienceFair! https:\/\/t.co\/DflKNMrWFd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 50, 56 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/STEMChallenge\/status\/720321718535872512\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/DflKNMrWFd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8YyRoUYAAYU1q.jpg",
        "id_str" : "720321717407604736",
        "id" : 720321717407604736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8YyRoUYAAYU1q.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DflKNMrWFd"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 76, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720321718535872512",
    "text" : "Olivia's booth is all set up for a visit from the @POTUS on his tour of the #WHScienceFair! https:\/\/t.co\/DflKNMrWFd",
    "id" : 720321718535872512,
    "created_at" : "2016-04-13 18:44:15 +0000",
    "user" : {
      "name" : "STEM Challenge",
      "screen_name" : "STEMChallenge",
      "protected" : false,
      "id_str" : "369478072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707627464252649472\/XNoypleW_normal.jpg",
      "id" : 369478072,
      "verified" : false
    }
  },
  "id" : 720322886460768258,
  "created_at" : "2016-04-13 18:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSE Coalition",
      "screen_name" : "CSECoalition",
      "indices" : [ 3, 16 ],
      "id_str" : "705433542709415936",
      "id" : 705433542709415936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 105, 119 ]
    }, {
      "text" : "CSForAll",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720322418573754369",
  "text" : "RT @CSECoalition: Robots that clean subways and swim underwater. Check out the amazing inventions at the #WHScienceFair! #CSForAll https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 87, 101 ]
      }, {
        "text" : "CSForAll",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ADCUM82sZm",
        "expanded_url" : "http:\/\/1.usa.gov\/1S1S9fX",
        "display_url" : "1.usa.gov\/1S1S9fX"
      } ]
    },
    "geo" : { },
    "id_str" : "720322040159449089",
    "text" : "Robots that clean subways and swim underwater. Check out the amazing inventions at the #WHScienceFair! #CSForAll https:\/\/t.co\/ADCUM82sZm",
    "id" : 720322040159449089,
    "created_at" : "2016-04-13 18:45:31 +0000",
    "user" : {
      "name" : "CSE Coalition",
      "screen_name" : "CSECoalition",
      "protected" : false,
      "id_str" : "705433542709415936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705834213216382976\/8xyzVd2Y_normal.jpg",
      "id" : 705433542709415936,
      "verified" : false
    }
  },
  "id" : 720322418573754369,
  "created_at" : "2016-04-13 18:47:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "indices" : [ 3, 18 ],
      "id_str" : "73206956",
      "id" : 73206956
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720321727763390464",
  "text" : "RT @chefjoseandres: @WhiteHouse #WHScienceFair fascinating study by Mikayla on feed to egg conversion rates of various chicken breeds! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chefjoseandres\/status\/720308560307949568\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/fVTGEBJzwT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8MxrNWIAAyZlt.jpg",
        "id_str" : "720308512954392576",
        "id" : 720308512954392576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8MxrNWIAAyZlt.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/fVTGEBJzwT"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 12, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720308560307949568",
    "in_reply_to_user_id" : 30313925,
    "text" : "@WhiteHouse #WHScienceFair fascinating study by Mikayla on feed to egg conversion rates of various chicken breeds! https:\/\/t.co\/fVTGEBJzwT",
    "id" : 720308560307949568,
    "created_at" : "2016-04-13 17:51:58 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "protected" : false,
      "id_str" : "73206956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468467014772600832\/vauGQ8wb_normal.jpeg",
      "id" : 73206956,
      "verified" : true
    }
  },
  "id" : 720321727763390464,
  "created_at" : "2016-04-13 18:44:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "indices" : [ 3, 15 ],
      "id_str" : "15661871",
      "id" : 15661871
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/donttrythis\/status\/720317961819549696\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ZcjkOl6GcB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8VV6RXIAAQx-S.jpg",
      "id_str" : "720317931566080000",
      "id" : 720317931566080000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8VV6RXIAAQx-S.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ZcjkOl6GcB"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720320628365074432",
  "text" : "RT @donttrythis: Fifteen and looking seriously at a cure for gastric cancer. Amazing #WHScienceFair https:\/\/t.co\/ZcjkOl6GcB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/donttrythis\/status\/720317961819549696\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/ZcjkOl6GcB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8VV6RXIAAQx-S.jpg",
        "id_str" : "720317931566080000",
        "id" : 720317931566080000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8VV6RXIAAQx-S.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ZcjkOl6GcB"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720317961819549696",
    "text" : "Fifteen and looking seriously at a cure for gastric cancer. Amazing #WHScienceFair https:\/\/t.co\/ZcjkOl6GcB",
    "id" : 720317961819549696,
    "created_at" : "2016-04-13 18:29:19 +0000",
    "user" : {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "protected" : false,
      "id_str" : "15661871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458749057985282048\/cre48Dcf_normal.jpeg",
      "id" : 15661871,
      "verified" : true
    }
  },
  "id" : 720320628365074432,
  "created_at" : "2016-04-13 18:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Benoist",
      "screen_name" : "MelissaBenoist",
      "indices" : [ 3, 18 ],
      "id_str" : "736417956",
      "id" : 736417956
    }, {
      "name" : "Girl Scouts East OK",
      "screen_name" : "newsGSEOK",
      "indices" : [ 79, 89 ],
      "id_str" : "85984193",
      "id" : 85984193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/RYS8giGS9F",
      "expanded_url" : "https:\/\/twitter.com\/nasa\/status\/720297753985871872",
      "display_url" : "twitter.com\/nasa\/status\/72\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720317979414503425",
  "text" : "RT @MelissaBenoist: You girls just keep getting more amazing. Real life heroes @newsGSEOK  https:\/\/t.co\/RYS8giGS9F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Girl Scouts East OK",
        "screen_name" : "newsGSEOK",
        "indices" : [ 59, 69 ],
        "id_str" : "85984193",
        "id" : 85984193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/RYS8giGS9F",
        "expanded_url" : "https:\/\/twitter.com\/nasa\/status\/720297753985871872",
        "display_url" : "twitter.com\/nasa\/status\/72\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720313878161154048",
    "text" : "You girls just keep getting more amazing. Real life heroes @newsGSEOK  https:\/\/t.co\/RYS8giGS9F",
    "id" : 720313878161154048,
    "created_at" : "2016-04-13 18:13:05 +0000",
    "user" : {
      "name" : "Melissa Benoist",
      "screen_name" : "MelissaBenoist",
      "protected" : false,
      "id_str" : "736417956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779434680592404481\/NvdWzvtL_normal.jpg",
      "id" : 736417956,
      "verified" : true
    }
  },
  "id" : 720317979414503425,
  "created_at" : "2016-04-13 18:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/720317242991247361\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/8ycGdwPhtn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8UtwjUsAIjFfb.jpg",
      "id_str" : "720317241762295810",
      "id" : 720317241762295810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8UtwjUsAIjFfb.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8ycGdwPhtn"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720317576421711872",
  "text" : "RT @vj44: The Supergirls are back at the @WhiteHouse #WHScienceFair today! https:\/\/t.co\/8ycGdwPhtn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 31, 42 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/720317242991247361\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/8ycGdwPhtn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8UtwjUsAIjFfb.jpg",
        "id_str" : "720317241762295810",
        "id" : 720317241762295810,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8UtwjUsAIjFfb.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/8ycGdwPhtn"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 43, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720317242991247361",
    "text" : "The Supergirls are back at the @WhiteHouse #WHScienceFair today! https:\/\/t.co\/8ycGdwPhtn",
    "id" : 720317242991247361,
    "created_at" : "2016-04-13 18:26:28 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 720317576421711872,
  "created_at" : "2016-04-13 18:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karlie Kloss",
      "screen_name" : "karliekloss",
      "indices" : [ 3, 15 ],
      "id_str" : "28412286",
      "id" : 28412286
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 94, 105 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720314913118412805",
  "text" : "RT @karliekloss: Thanks for tuning in to the #WHScienceFair live stream! Be sure to catch the @WhiteHouse FB live at 2:15pmET \uD83D\uDC49 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 77, 88 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 28, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/xRa6Hl7sD3",
        "expanded_url" : "http:\/\/www.facebook.com\/WhiteHouse",
        "display_url" : "facebook.com\/WhiteHouse"
      } ]
    },
    "geo" : { },
    "id_str" : "720305437686439936",
    "text" : "Thanks for tuning in to the #WHScienceFair live stream! Be sure to catch the @WhiteHouse FB live at 2:15pmET \uD83D\uDC49 https:\/\/t.co\/xRa6Hl7sD3 \uD83D\uDD2C\uD83D\uDE80\u2697",
    "id" : 720305437686439936,
    "created_at" : "2016-04-13 17:39:33 +0000",
    "user" : {
      "name" : "Karlie Kloss",
      "screen_name" : "karliekloss",
      "protected" : false,
      "id_str" : "28412286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711979086210539520\/AOh5fBuR_normal.jpg",
      "id" : 28412286,
      "verified" : true
    }
  },
  "id" : 720314913118412805,
  "created_at" : "2016-04-13 18:17:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720314089256415234\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/VPYP5sliTX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8R1XOXEAAZb-y.jpg",
      "id_str" : "720314073867554816",
      "id" : 720314073867554816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8R1XOXEAAZb-y.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/VPYP5sliTX"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/jrGYXBaqjL",
      "expanded_url" : "http:\/\/go.wh.gov\/qHdC2D",
      "display_url" : "go.wh.gov\/qHdC2D"
    } ]
  },
  "geo" : { },
  "id_str" : "720314089256415234",
  "text" : "Happening now: Hop on @POTUS's tour of the #WHScienceFair \u2192 https:\/\/t.co\/jrGYXBaqjL https:\/\/t.co\/VPYP5sliTX",
  "id" : 720314089256415234,
  "created_at" : "2016-04-13 18:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "indices" : [ 3, 14 ],
      "id_str" : "14592723",
      "id" : 14592723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/d4oN9jf7B1",
      "expanded_url" : "http:\/\/bit.ly\/23v0LnR",
      "display_url" : "bit.ly\/23v0LnR"
    } ]
  },
  "geo" : { },
  "id_str" : "720309126773911552",
  "text" : "RT @MayoClinic: Meet students exhibiting innovative projects, including 2 Minnesotans with Mayo Free Time app! https:\/\/t.co\/d4oN9jf7B1 #WHS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 119, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/d4oN9jf7B1",
        "expanded_url" : "http:\/\/bit.ly\/23v0LnR",
        "display_url" : "bit.ly\/23v0LnR"
      } ]
    },
    "geo" : { },
    "id_str" : "720306052760236032",
    "text" : "Meet students exhibiting innovative projects, including 2 Minnesotans with Mayo Free Time app! https:\/\/t.co\/d4oN9jf7B1 #WHScienceFair",
    "id" : 720306052760236032,
    "created_at" : "2016-04-13 17:42:00 +0000",
    "user" : {
      "name" : "Mayo Clinic",
      "screen_name" : "MayoClinic",
      "protected" : false,
      "id_str" : "14592723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760454818422857728\/2WFm5vUI_normal.jpg",
      "id" : 14592723,
      "verified" : true
    }
  },
  "id" : 720309126773911552,
  "created_at" : "2016-04-13 17:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/DYD0fk2J18",
      "expanded_url" : "http:\/\/go.wh.gov\/ScienceFair",
      "display_url" : "go.wh.gov\/ScienceFair"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2gI3dUFjIf",
      "expanded_url" : "http:\/\/snpy.tv\/1oY5Thm",
      "display_url" : "snpy.tv\/1oY5Thm"
    } ]
  },
  "geo" : { },
  "id_str" : "720304719231631360",
  "text" : "Check out @POTUS's final #WHScienceFair from anywhere on the planet\u2026 or off it! https:\/\/t.co\/DYD0fk2J18 https:\/\/t.co\/2gI3dUFjIf",
  "id" : 720304719231631360,
  "created_at" : "2016-04-13 17:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 3, 13 ],
      "id_str" : "50393960",
      "id" : 50393960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/AZIRLfJB94",
      "expanded_url" : "http:\/\/b-gat.es\/23v10zv",
      "display_url" : "b-gat.es\/23v10zv"
    } ]
  },
  "geo" : { },
  "id_str" : "720303748350750720",
  "text" : "RT @BillGates: Exciting to see the next generation of innovators participating in the #WHScienceFair: https:\/\/t.co\/AZIRLfJB94 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BillGates\/status\/720299371666022400\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/na8Wq2TnRN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8EdjYUsAAcT8u.jpg",
        "id_str" : "720299371162546176",
        "id" : 720299371162546176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8EdjYUsAAcT8u.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/na8Wq2TnRN"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 71, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/AZIRLfJB94",
        "expanded_url" : "http:\/\/b-gat.es\/23v10zv",
        "display_url" : "b-gat.es\/23v10zv"
      } ]
    },
    "geo" : { },
    "id_str" : "720299371666022400",
    "text" : "Exciting to see the next generation of innovators participating in the #WHScienceFair: https:\/\/t.co\/AZIRLfJB94 https:\/\/t.co\/na8Wq2TnRN",
    "id" : 720299371666022400,
    "created_at" : "2016-04-13 17:15:27 +0000",
    "user" : {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "protected" : false,
      "id_str" : "50393960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558109954561679360\/j1f9DiJi_normal.jpeg",
      "id" : 50393960,
      "verified" : true
    }
  },
  "id" : 720303748350750720,
  "created_at" : "2016-04-13 17:32:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 70, 84 ]
    }, {
      "text" : "STEM",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720298386470133760",
  "text" : "RT @ErnestMoniz: Couldn't agree more. Looking forward to visiting the #WHScienceFair today to celebrate students in #STEM. https:\/\/t.co\/rYD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/720264682737573889\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/rYDcDUNF7E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7k6U5WQAA88jN.jpg",
        "id_str" : "720264681118646272",
        "id" : 720264681118646272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7k6U5WQAA88jN.jpg",
        "sizes" : [ {
          "h" : 749,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rYDcDUNF7E"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 53, 67 ]
      }, {
        "text" : "STEM",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720264682737573889",
    "text" : "Couldn't agree more. Looking forward to visiting the #WHScienceFair today to celebrate students in #STEM. https:\/\/t.co\/rYDcDUNF7E",
    "id" : 720264682737573889,
    "created_at" : "2016-04-13 14:57:36 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 720298386470133760,
  "created_at" : "2016-04-13 17:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yara shahidi",
      "screen_name" : "YaraShahidi",
      "indices" : [ 53, 65 ],
      "id_str" : "346353711",
      "id" : 346353711
    }, {
      "name" : "Karlie Kloss",
      "screen_name" : "karliekloss",
      "indices" : [ 72, 84 ],
      "id_str" : "28412286",
      "id" : 28412286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/DYD0fk2J18",
      "expanded_url" : "http:\/\/go.wh.gov\/ScienceFair",
      "display_url" : "go.wh.gov\/ScienceFair"
    } ]
  },
  "geo" : { },
  "id_str" : "720294273724379136",
  "text" : "At 1:00pm ET, join your favorite science enthusiasts @YaraShahidi &amp; @KarlieKloss live at the #WHScienceFair  \u2192 https:\/\/t.co\/DYD0fk2J18",
  "id" : 720294273724379136,
  "created_at" : "2016-04-13 16:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "indices" : [ 3, 12 ],
      "id_str" : "113439399",
      "id" : 113439399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720290984911859712",
  "text" : "RT @smrtgrls: Smart Girls is honored and excited to be here today at the #WHScienceFair! Tune in at 1pm ET &amp; watch LIVE here \uD83D\uDC49https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 59, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/VIkAdeIrjO",
        "expanded_url" : "http:\/\/go.wh.gov\/ScienceFair",
        "display_url" : "go.wh.gov\/ScienceFair"
      } ]
    },
    "geo" : { },
    "id_str" : "720279703622262785",
    "text" : "Smart Girls is honored and excited to be here today at the #WHScienceFair! Tune in at 1pm ET &amp; watch LIVE here \uD83D\uDC49https:\/\/t.co\/VIkAdeIrjO \uD83D\uDD2C\u2697",
    "id" : 720279703622262785,
    "created_at" : "2016-04-13 15:57:18 +0000",
    "user" : {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "protected" : false,
      "id_str" : "113439399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700467562413297664\/0qESscTd_normal.png",
      "id" : 113439399,
      "verified" : true
    }
  },
  "id" : 720290984911859712,
  "created_at" : "2016-04-13 16:42:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "indices" : [ 3, 15 ],
      "id_str" : "15661871",
      "id" : 15661871
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/tHD7yT56iq",
      "expanded_url" : "http:\/\/1.usa.gov\/1UNo07G",
      "display_url" : "1.usa.gov\/1UNo07G"
    } ]
  },
  "geo" : { },
  "id_str" : "720284819129765889",
  "text" : "RT @donttrythis: Like my trick? Share YOUR science fair project w\/the @WhiteHouse this weekl! #WHScienceFair! https:\/\/t.co\/tHD7yT56iq\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 53, 64 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 77, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/tHD7yT56iq",
        "expanded_url" : "http:\/\/1.usa.gov\/1UNo07G",
        "display_url" : "1.usa.gov\/1UNo07G"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/WXtWxHbLx0",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/061dea86-01a4-46d6-bec6-2109155f4ab8",
        "display_url" : "amp.twimg.com\/v\/061dea86-01a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719937525733675008",
    "text" : "Like my trick? Share YOUR science fair project w\/the @WhiteHouse this weekl! #WHScienceFair! https:\/\/t.co\/tHD7yT56iq\nhttps:\/\/t.co\/WXtWxHbLx0",
    "id" : 719937525733675008,
    "created_at" : "2016-04-12 17:17:36 +0000",
    "user" : {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "protected" : false,
      "id_str" : "15661871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458749057985282048\/cre48Dcf_normal.jpeg",
      "id" : 15661871,
      "verified" : true
    }
  },
  "id" : 720284819129765889,
  "created_at" : "2016-04-13 16:17:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Jo Handelsman",
      "screen_name" : "Jo44",
      "indices" : [ 92, 97 ],
      "id_str" : "3580701441",
      "id" : 3580701441
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 100, 105 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "indices" : [ 108, 117 ],
      "id_str" : "113439399",
      "id" : 113439399
    }, {
      "name" : "Yara shahidi",
      "screen_name" : "YaraShahidi",
      "indices" : [ 120, 132 ],
      "id_str" : "346353711",
      "id" : 346353711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 59, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720272343466131456",
  "text" : "RT @vj44: Ready to talk science? We'll take your Qs on the #WHScienceFair today after 5 ET!\n@Jo44 \u2713\n@VJ44 \u2713\n@SmrtGrls \u2713\n@YaraShahidi \u2713\n@Kar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jo Handelsman",
        "screen_name" : "Jo44",
        "indices" : [ 82, 87 ],
        "id_str" : "3580701441",
        "id" : 3580701441
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 90, 95 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "AmyPoehlerSmartGirls",
        "screen_name" : "smrtgrls",
        "indices" : [ 98, 107 ],
        "id_str" : "113439399",
        "id" : 113439399
      }, {
        "name" : "Yara shahidi",
        "screen_name" : "YaraShahidi",
        "indices" : [ 110, 122 ],
        "id_str" : "346353711",
        "id" : 346353711
      }, {
        "name" : "Karlie Kloss",
        "screen_name" : "karliekloss",
        "indices" : [ 125, 137 ],
        "id_str" : "28412286",
        "id" : 28412286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 49, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720271996194394113",
    "text" : "Ready to talk science? We'll take your Qs on the #WHScienceFair today after 5 ET!\n@Jo44 \u2713\n@VJ44 \u2713\n@SmrtGrls \u2713\n@YaraShahidi \u2713\n@KarlieKloss \u2713",
    "id" : 720271996194394113,
    "created_at" : "2016-04-13 15:26:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 720272343466131456,
  "created_at" : "2016-04-13 15:28:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 41, 49 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720256156506177536",
  "text" : "RT @PressSec: I'm taking #AskPressSec to @Twitter's HQ in DC today. Got questions on issues you care about? Send them my way and I'll answe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 27, 35 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 11, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720254132242624512",
    "text" : "I'm taking #AskPressSec to @Twitter's HQ in DC today. Got questions on issues you care about? Send them my way and I'll answer at 4:30pm ET.",
    "id" : 720254132242624512,
    "created_at" : "2016-04-13 14:15:41 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 720256156506177536,
  "created_at" : "2016-04-13 14:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zIVUxQSZCL",
      "expanded_url" : "http:\/\/snpy.tv\/25YC6Xu",
      "display_url" : "snpy.tv\/25YC6Xu"
    } ]
  },
  "geo" : { },
  "id_str" : "720076591615729664",
  "text" : "\"That\u2019s the thing about America\u2014we are never finished\" \u2014@POTUS designating Belmont-Paul Women's Equality Monument: https:\/\/t.co\/zIVUxQSZCL",
  "id" : 720076591615729664,
  "created_at" : "2016-04-13 02:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UConn Women's Hoops",
      "screen_name" : "UConnWBB",
      "indices" : [ 87, 96 ],
      "id_str" : "242785840",
      "id" : 242785840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ifVfHc8JIB",
      "expanded_url" : "http:\/\/snpy.tv\/23sSD7l",
      "display_url" : "snpy.tv\/23sSD7l"
    } ]
  },
  "geo" : { },
  "id_str" : "720053854478430208",
  "text" : "\"That kind of sustained excellence is a remarkable achievement\" \u2014@POTUS congratulating @UConnWBB on their victory: https:\/\/t.co\/ifVfHc8JIB",
  "id" : 720053854478430208,
  "created_at" : "2016-04-13 00:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/52HKuS87xA",
      "expanded_url" : "http:\/\/wh.gov\/Science-Fair",
      "display_url" : "wh.gov\/Science-Fair"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Q2SpHKeelG",
      "expanded_url" : "http:\/\/snpy.tv\/23sPgxm",
      "display_url" : "snpy.tv\/23sPgxm"
    } ]
  },
  "geo" : { },
  "id_str" : "720044943243403264",
  "text" : "\"It\u2019s a prototype!\"\nTune in tomorrow for @POTUS's final #WHScienceFair: https:\/\/t.co\/52HKuS87xA https:\/\/t.co\/Q2SpHKeelG",
  "id" : 720044943243403264,
  "created_at" : "2016-04-13 00:24:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/eenRMTaf4R",
      "expanded_url" : "http:\/\/snpy.tv\/1S3VAAw",
      "display_url" : "snpy.tv\/1S3VAAw"
    } ]
  },
  "geo" : { },
  "id_str" : "720017415107555329",
  "text" : "\"I\u2019m hoping a young generation will come here and draw inspiration\" \u2014@POTUS on a new monument for women's equality https:\/\/t.co\/eenRMTaf4R",
  "id" : 720017415107555329,
  "created_at" : "2016-04-12 22:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/vU0TrHxAzn",
      "expanded_url" : "http:\/\/snpy.tv\/23rP1Ti",
      "display_url" : "snpy.tv\/23rP1Ti"
    } ]
  },
  "geo" : { },
  "id_str" : "720010382522195969",
  "text" : "On average, women who work full-time still earn just $0.79 for every $1 men earn.\n\nIt's time to change that.  https:\/\/t.co\/vU0TrHxAzn",
  "id" : 720010382522195969,
  "created_at" : "2016-04-12 22:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/720004849866121216\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/eOzulZwPiR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf3ymu5XIAAdizj.jpg",
      "id_str" : "719998262686720000",
      "id" : 719998262686720000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf3ymu5XIAAdizj.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/eOzulZwPiR"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/hBUwaPEpde",
      "expanded_url" : "http:\/\/go.wh.gov\/EqualPayDay",
      "display_url" : "go.wh.gov\/EqualPayDay"
    } ]
  },
  "geo" : { },
  "id_str" : "720004849866121216",
  "text" : "FACT: The pay gap is even wider for women of color. https:\/\/t.co\/hBUwaPEpde #EqualPayDay https:\/\/t.co\/eOzulZwPiR",
  "id" : 720004849866121216,
  "created_at" : "2016-04-12 21:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/719895601605910529\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5Cp4OwWLaC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2VPCTWIAA-PPy.jpg",
      "id_str" : "719895600997736448",
      "id" : 719895600997736448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2VPCTWIAA-PPy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1012
      } ],
      "display_url" : "pic.twitter.com\/5Cp4OwWLaC"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/z6e84YX3Qb",
      "expanded_url" : "http:\/\/1.usa.gov\/1VlG4q6",
      "display_url" : "1.usa.gov\/1VlG4q6"
    } ]
  },
  "geo" : { },
  "id_str" : "720000429585608704",
  "text" : "RT @USDOL: Curious about your state's equal pay protections? Get the facts: https:\/\/t.co\/z6e84YX3Qb #EqualPayDay https:\/\/t.co\/5Cp4OwWLaC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/719895601605910529\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/5Cp4OwWLaC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2VPCTWIAA-PPy.jpg",
        "id_str" : "719895600997736448",
        "id" : 719895600997736448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2VPCTWIAA-PPy.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1012
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1012
        } ],
        "display_url" : "pic.twitter.com\/5Cp4OwWLaC"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/z6e84YX3Qb",
        "expanded_url" : "http:\/\/1.usa.gov\/1VlG4q6",
        "display_url" : "1.usa.gov\/1VlG4q6"
      } ]
    },
    "geo" : { },
    "id_str" : "719895601605910529",
    "text" : "Curious about your state's equal pay protections? Get the facts: https:\/\/t.co\/z6e84YX3Qb #EqualPayDay https:\/\/t.co\/5Cp4OwWLaC",
    "id" : 719895601605910529,
    "created_at" : "2016-04-12 14:31:01 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 720000429585608704,
  "created_at" : "2016-04-12 21:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719998085414256640\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/gJa7md31AO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf3yahbWEAAVR_p.jpg",
      "id_str" : "719998052912730112",
      "id" : 719998052912730112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf3yahbWEAAVR_p.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gJa7md31AO"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719998085414256640",
  "text" : "It's 2016. Women should earn the same pay as men for doing the same work. \nPeriod. #EqualPayDay https:\/\/t.co\/gJa7md31AO",
  "id" : 719998085414256640,
  "created_at" : "2016-04-12 21:18:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 47, 52 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 94, 105 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719992130823974920",
  "text" : "RT @LaborSec: Today at 5pm ET, I'll be joining @vj44 to answer Qs on #EqualPayDay. Ask on the @WhiteHouse Facebook page: https:\/\/t.co\/Acv5c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 33, 38 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 80, 91 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 55, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Acv5c7PwGL",
        "expanded_url" : "http:\/\/bit.ly\/22rRtDr",
        "display_url" : "bit.ly\/22rRtDr"
      } ]
    },
    "geo" : { },
    "id_str" : "719991858093563904",
    "text" : "Today at 5pm ET, I'll be joining @vj44 to answer Qs on #EqualPayDay. Ask on the @WhiteHouse Facebook page: https:\/\/t.co\/Acv5c7PwGL",
    "id" : 719991858093563904,
    "created_at" : "2016-04-12 20:53:30 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 719992130823974920,
  "created_at" : "2016-04-12 20:54:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "indices" : [ 3, 10 ],
      "id_str" : "207686162",
      "id" : 207686162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "CloseThePayGap",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/We4MBsOQVD",
      "expanded_url" : "http:\/\/bit.ly\/1N60gZR",
      "display_url" : "bit.ly\/1N60gZR"
    } ]
  },
  "geo" : { },
  "id_str" : "719989472260157440",
  "text" : "RT @GapInc: \"The way the world should work.\" See what our CEO has to say about #EqualPay https:\/\/t.co\/We4MBsOQVD #CloseThePayGap https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GapInc\/status\/719863545924599808\/video\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9gYd0qOoVS",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719863288096546816\/pu\/img\/1aiTAoUmDcGKsyVZ.jpg",
        "id_str" : "719863288096546816",
        "id" : 719863288096546816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719863288096546816\/pu\/img\/1aiTAoUmDcGKsyVZ.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9gYd0qOoVS"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "CloseThePayGap",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/We4MBsOQVD",
        "expanded_url" : "http:\/\/bit.ly\/1N60gZR",
        "display_url" : "bit.ly\/1N60gZR"
      } ]
    },
    "geo" : { },
    "id_str" : "719863545924599808",
    "text" : "\"The way the world should work.\" See what our CEO has to say about #EqualPay https:\/\/t.co\/We4MBsOQVD #CloseThePayGap https:\/\/t.co\/9gYd0qOoVS",
    "id" : 719863545924599808,
    "created_at" : "2016-04-12 12:23:38 +0000",
    "user" : {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "protected" : false,
      "id_str" : "207686162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634867462404599808\/vrI08ztG_normal.jpg",
      "id" : 207686162,
      "verified" : true
    }
  },
  "id" : 719989472260157440,
  "created_at" : "2016-04-12 20:44:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "EqualPayDay",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Kam2WoN0Sq",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/9c98a523-dae7-4cdf-857c-31033d4db080",
      "display_url" : "amp.twimg.com\/v\/9c98a523-dae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719988588180611074",
  "text" : "Take a minute to watch this: Here's why it's long-past time to ensure #EqualPay for women. #EqualPayDay https:\/\/t.co\/Kam2WoN0Sq",
  "id" : 719988588180611074,
  "created_at" : "2016-04-12 20:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/719969767080112128\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Llx179zN4Y",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf3YrEfUMAAY_CE.jpg",
      "id_str" : "719969749900210176",
      "id" : 719969749900210176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf3YrEfUMAAY_CE.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Llx179zN4Y"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/8Nd6zs7fxU",
      "expanded_url" : "http:\/\/go.wh.gov\/XwSn9y",
      "display_url" : "go.wh.gov\/XwSn9y"
    } ]
  },
  "geo" : { },
  "id_str" : "719969767080112128",
  "text" : "Today is known as #EqualPayDay. Here\u2019s why \u2192 https:\/\/t.co\/8Nd6zs7fxU https:\/\/t.co\/Llx179zN4Y",
  "id" : 719969767080112128,
  "created_at" : "2016-04-12 19:25:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 72, 83 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/2L8nocK5mN",
      "expanded_url" : "http:\/\/bit.ly\/22rRtDr",
      "display_url" : "bit.ly\/22rRtDr"
    } ]
  },
  "geo" : { },
  "id_str" : "719935825488818176",
  "text" : "RT @vj44: At 5pm ET, I'll be taking your Qs on #EqualPayDay. Ask on the @WhiteHouse\nFacebook page: https:\/\/t.co\/2L8nocK5mN https:\/\/t.co\/Fy3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 62, 73 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/719933668223913984\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/Fy3hOOIZcy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf232yBUAAA4ddd.jpg",
        "id_str" : "719933667217244160",
        "id" : 719933667217244160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf232yBUAAA4ddd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Fy3hOOIZcy"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 37, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/2L8nocK5mN",
        "expanded_url" : "http:\/\/bit.ly\/22rRtDr",
        "display_url" : "bit.ly\/22rRtDr"
      } ]
    },
    "geo" : { },
    "id_str" : "719933668223913984",
    "text" : "At 5pm ET, I'll be taking your Qs on #EqualPayDay. Ask on the @WhiteHouse\nFacebook page: https:\/\/t.co\/2L8nocK5mN https:\/\/t.co\/Fy3hOOIZcy",
    "id" : 719933668223913984,
    "created_at" : "2016-04-12 17:02:16 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 719935825488818176,
  "created_at" : "2016-04-12 17:10:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 22, 34 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719928015380168704",
  "text" : "RT @NancyPelosi: This #EqualPayDay, we will continue fighting to unleash the full power of America\u2019s women. #WomenSucceed --&gt; https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 5, 17 ]
      }, {
        "text" : "WomenSucceed",
        "indices" : [ 91, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/49AY5bsOzk",
        "expanded_url" : "https:\/\/goo.gl\/O7FnAZ",
        "display_url" : "goo.gl\/O7FnAZ"
      } ]
    },
    "geo" : { },
    "id_str" : "719923932367863811",
    "text" : "This #EqualPayDay, we will continue fighting to unleash the full power of America\u2019s women. #WomenSucceed --&gt; https:\/\/t.co\/49AY5bsOzk",
    "id" : 719923932367863811,
    "created_at" : "2016-04-12 16:23:35 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 719928015380168704,
  "created_at" : "2016-04-12 16:39:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/smysRM3uDq",
      "expanded_url" : "http:\/\/go.wh.gov\/Belmont-Paul",
      "display_url" : "go.wh.gov\/Belmont-Paul"
    }, {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/eenRMTaf4R",
      "expanded_url" : "http:\/\/snpy.tv\/1S3VAAw",
      "display_url" : "snpy.tv\/1S3VAAw"
    } ]
  },
  "geo" : { },
  "id_str" : "719923080886296576",
  "text" : "\"This house is a monument to the fight for women\u2019s equality.\" \u2014@POTUS: https:\/\/t.co\/smysRM3uDq https:\/\/t.co\/eenRMTaf4R",
  "id" : 719923080886296576,
  "created_at" : "2016-04-12 16:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VoRI9Og95C",
      "expanded_url" : "http:\/\/on.doi.gov\/1NmuC5m",
      "display_url" : "on.doi.gov\/1NmuC5m"
    } ]
  },
  "geo" : { },
  "id_str" : "719917501203759104",
  "text" : "RT @Interior: Our nation's newest national monument honors the fight for women's equality https:\/\/t.co\/VoRI9Og95C #EqualPayDay https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/719909191222222848\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0tfjL1YXfP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2hjW2UYAACZXQ.jpg",
        "id_str" : "719909144250048512",
        "id" : 719909144250048512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2hjW2UYAACZXQ.jpg",
        "sizes" : [ {
          "h" : 1350,
          "resize" : "fit",
          "w" : 1842
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0tfjL1YXfP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/719909191222222848\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0tfjL1YXfP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2hjVFVIAAGeCK.jpg",
        "id_str" : "719909143776141312",
        "id" : 719909143776141312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2hjVFVIAAGeCK.jpg",
        "sizes" : [ {
          "h" : 379,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 947,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 646,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0tfjL1YXfP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/719909191222222848\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0tfjL1YXfP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2hl_UUkAAM4Ra.jpg",
        "id_str" : "719909189473046528",
        "id" : 719909189473046528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2hl_UUkAAM4Ra.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2685,
          "resize" : "fit",
          "w" : 4027
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0tfjL1YXfP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/719909191222222848\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0tfjL1YXfP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2hmBtVIAE4ZEn.jpg",
        "id_str" : "719909190114811905",
        "id" : 719909190114811905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2hmBtVIAE4ZEn.jpg",
        "sizes" : [ {
          "h" : 3856,
          "resize" : "fit",
          "w" : 2571
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0tfjL1YXfP"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/VoRI9Og95C",
        "expanded_url" : "http:\/\/on.doi.gov\/1NmuC5m",
        "display_url" : "on.doi.gov\/1NmuC5m"
      } ]
    },
    "geo" : { },
    "id_str" : "719909191222222848",
    "text" : "Our nation's newest national monument honors the fight for women's equality https:\/\/t.co\/VoRI9Og95C #EqualPayDay https:\/\/t.co\/0tfjL1YXfP",
    "id" : 719909191222222848,
    "created_at" : "2016-04-12 15:25:01 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 719917501203759104,
  "created_at" : "2016-04-12 15:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/vU0TrHPbXX",
      "expanded_url" : "http:\/\/snpy.tv\/23rP1Ti",
      "display_url" : "snpy.tv\/23rP1Ti"
    } ]
  },
  "geo" : { },
  "id_str" : "719916515106144256",
  "text" : "RT if you agree with @POTUS: Equal pay for equal work should be a fundamental principle of our economy. #EqualPayDay https:\/\/t.co\/vU0TrHPbXX",
  "id" : 719916515106144256,
  "created_at" : "2016-04-12 15:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719914411012583424\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/c8Vi4Ru5Vk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2mRP0UIAASYyg.jpg",
      "id_str" : "719914330683088896",
      "id" : 719914330683088896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2mRP0UIAASYyg.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1190
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c8Vi4Ru5Vk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/smysRLLTLS",
      "expanded_url" : "http:\/\/go.wh.gov\/Belmont-Paul",
      "display_url" : "go.wh.gov\/Belmont-Paul"
    } ]
  },
  "geo" : { },
  "id_str" : "719914411012583424",
  "text" : "\"Today, I\u2019m designating it as America\u2019s newest national monument\" \u2014@POTUS: https:\/\/t.co\/smysRLLTLS https:\/\/t.co\/c8Vi4Ru5Vk",
  "id" : 719914411012583424,
  "created_at" : "2016-04-12 15:45:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719913988746829824",
  "text" : "\"I\u2019m not here just to say we should close the wage gap. I\u2019m here to say we will close the wage gap.\"\u2014@POTUS on #EqualPayDay",
  "id" : 719913988746829824,
  "created_at" : "2016-04-12 15:44:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8UoDjaKAtg",
      "expanded_url" : "http:\/\/go.wh.gov\/EqualPay",
      "display_url" : "go.wh.gov\/EqualPay"
    } ]
  },
  "geo" : { },
  "id_str" : "719913765148475392",
  "text" : "\u201CCongress should pass the Paycheck Fairness Act to put sensible rules in place\" \u2014@POTUS on #EqualPayDay: https:\/\/t.co\/8UoDjaKAtg",
  "id" : 719913765148475392,
  "created_at" : "2016-04-12 15:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719913575104516097\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/esbDHrQPA9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2lOhQUUAAyg4_.jpg",
      "id_str" : "719913184312709120",
      "id" : 719913184312709120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2lOhQUUAAyg4_.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/esbDHrQPA9"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 55, 67 ]
    }, {
      "text" : "EqualPayNow",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719913575104516097",
  "text" : "\"The gap is even wider for women of color.\" \u2014@POTUS on #EqualPayDay  \n\nIt's time for #EqualPayNow. https:\/\/t.co\/esbDHrQPA9",
  "id" : 719913575104516097,
  "created_at" : "2016-04-12 15:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719912939189334017\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/88QpFbQG2D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2k8yOUEAAGj1x.jpg",
      "id_str" : "719912879630061568",
      "id" : 719912879630061568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2k8yOUEAAGj1x.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/88QpFbQG2D"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719912939189334017",
  "text" : "\u201CYour work should be equally valued and rewarded\u2014whether you\u2019re a man or a woman.\" \u2014@POTUS on #EqualPayDay https:\/\/t.co\/88QpFbQG2D",
  "id" : 719912939189334017,
  "created_at" : "2016-04-12 15:39:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/719912639304962050\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/bXlQ91iB5k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2kj7FUIAAVugA.jpg",
      "id_str" : "719912452511506432",
      "id" : 719912452511506432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2kj7FUIAAVugA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bXlQ91iB5k"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719912639304962050",
  "text" : "\u201CEqual pay for equal work should be a fundamental principle of our economy.\u201D \u2014@POTUS on #EqualPayDay https:\/\/t.co\/bXlQ91iB5k",
  "id" : 719912639304962050,
  "created_at" : "2016-04-12 15:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719912366838845440",
  "text" : "\u201CWhat better place to commemorate this day than here at this house, where some of our country\u2019s most important history took place.\u201D  \u2014@POTUS",
  "id" : 719912366838845440,
  "created_at" : "2016-04-12 15:37:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719912290322116608",
  "text" : "\u201CToday is #EqualPayDay which means a woman has to work about this far into 2016 just to earn what a man earned in 2015.\u201D \u2014@POTUS",
  "id" : 719912290322116608,
  "created_at" : "2016-04-12 15:37:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/smysRLLTLS",
      "expanded_url" : "http:\/\/go.wh.gov\/Belmont-Paul",
      "display_url" : "go.wh.gov\/Belmont-Paul"
    } ]
  },
  "geo" : { },
  "id_str" : "719912051217428480",
  "text" : "Happening now: Watch @POTUS speak at the newly-designated Belmont-Paul Women's Equality National Monument: https:\/\/t.co\/smysRLLTLS",
  "id" : 719912051217428480,
  "created_at" : "2016-04-12 15:36:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 20, 29 ],
      "id_str" : "376502929",
      "id" : 376502929
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719911300944543744\/video\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/k7qsEJFHts",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719909683524308992\/pu\/img\/gXz5H2fHon5kdCH9.jpg",
      "id_str" : "719909683524308992",
      "id" : 719909683524308992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719909683524308992\/pu\/img\/gXz5H2fHon5kdCH9.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/k7qsEJFHts"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719911300944543744",
  "text" : "Add \"WhiteHouse\" on @Snapchat to watch @POTUS designate a new national monument to honor women's equality. https:\/\/t.co\/k7qsEJFHts",
  "id" : 719911300944543744,
  "created_at" : "2016-04-12 15:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719908474579062785\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/yGcP6oGQDz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2gqoIWcAApaZB.jpg",
      "id_str" : "719908169636540416",
      "id" : 719908169636540416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2gqoIWcAApaZB.jpg",
      "sizes" : [ {
        "h" : 488,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1180
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yGcP6oGQDz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/jArlheWm4j",
      "expanded_url" : "http:\/\/go.wh.gov\/AmK2xY",
      "display_url" : "go.wh.gov\/AmK2xY"
    } ]
  },
  "geo" : { },
  "id_str" : "719908474579062785",
  "text" : "These women picketed for the right to vote. Today, @POTUS will preserve their stories: https:\/\/t.co\/jArlheWm4j https:\/\/t.co\/yGcP6oGQDz",
  "id" : 719908474579062785,
  "created_at" : "2016-04-12 15:22:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719899636060659714",
  "text" : "RT @POTUS: Proud to designate the Belmont-Paul national monument for women's equality. Let's keep up their fight with #EqualPay for women t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719899559988740096",
    "text" : "Proud to designate the Belmont-Paul national monument for women's equality. Let's keep up their fight with #EqualPay for women today.",
    "id" : 719899559988740096,
    "created_at" : "2016-04-12 14:46:44 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 719899636060659714,
  "created_at" : "2016-04-12 14:47:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719897243566755840\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/qAbfyVTeq7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2POacW4AAVudE.jpg",
      "id_str" : "719888993228349440",
      "id" : 719888993228349440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2POacW4AAVudE.jpg",
      "sizes" : [ {
        "h" : 589,
        "resize" : "fit",
        "w" : 885
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 885
      } ],
      "display_url" : "pic.twitter.com\/qAbfyVTeq7"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719897243566755840\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/qAbfyVTeq7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2QmDvW8AEwwMA.jpg",
      "id_str" : "719890498962518017",
      "id" : 719890498962518017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2QmDvW8AEwwMA.jpg",
      "sizes" : [ {
        "h" : 738,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1081,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qAbfyVTeq7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/smysRM3uDq",
      "expanded_url" : "http:\/\/go.wh.gov\/Belmont-Paul",
      "display_url" : "go.wh.gov\/Belmont-Paul"
    } ]
  },
  "geo" : { },
  "id_str" : "719897243566755840",
  "text" : "Get a behind-the-scenes look at the newest national monument honoring women's equality: https:\/\/t.co\/smysRM3uDq https:\/\/t.co\/qAbfyVTeq7",
  "id" : 719897243566755840,
  "created_at" : "2016-04-12 14:37:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719882839924154368\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/4gI708PYKh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf2I2h8W4AAl2Gd.jpg",
      "id_str" : "719881985854988288",
      "id" : 719881985854988288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf2I2h8W4AAl2Gd.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1190
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4gI708PYKh"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 3, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/smysRM3uDq",
      "expanded_url" : "http:\/\/go.wh.gov\/Belmont-Paul",
      "display_url" : "go.wh.gov\/Belmont-Paul"
    } ]
  },
  "geo" : { },
  "id_str" : "719882839924154368",
  "text" : "On #EqualPayDay, @POTUS will designate a new national monument honoring women\u2019s equality: https:\/\/t.co\/smysRM3uDq https:\/\/t.co\/4gI708PYKh",
  "id" : 719882839924154368,
  "created_at" : "2016-04-12 13:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 63, 70 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JackieRobinsonPBS",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/9VmCz4PsLx",
      "expanded_url" : "http:\/\/kenburns.com\/films\/jackie-robinson",
      "display_url" : "kenburns.com\/films\/jackie-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719690940571611136",
  "text" : "Jackie Robinson's story is an American story. Watch @POTUS and @FLOTUS honor him on #JackieRobinsonPBS at 9pm ET: https:\/\/t.co\/9VmCz4PsLx",
  "id" : 719690940571611136,
  "created_at" : "2016-04-12 00:57:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNews",
      "screen_name" : "DNews",
      "indices" : [ 3, 9 ],
      "id_str" : "2881481254",
      "id" : 2881481254
    }, {
      "name" : "Science Channel",
      "screen_name" : "ScienceChannel",
      "indices" : [ 51, 66 ],
      "id_str" : "16895274",
      "id" : 16895274
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DNews\/status\/719652256035962881\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/XMu4oB8GD9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfy36c_UkAEi6jv.jpg",
      "id_str" : "719652255314513921",
      "id" : 719652255314513921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfy36c_UkAEi6jv.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 901
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 901
      } ],
      "display_url" : "pic.twitter.com\/XMu4oB8GD9"
    } ],
    "hashtags" : [ {
      "text" : "ObamaOnDNews",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/OApTsJH79w",
      "expanded_url" : "http:\/\/bit.ly\/1qKZN5K",
      "display_url" : "bit.ly\/1qKZN5K"
    } ]
  },
  "geo" : { },
  "id_str" : "719687272875077633",
  "text" : "RT @DNews: Watch President Obama Host DNews on the @ScienceChannel: https:\/\/t.co\/OApTsJH79w #ObamaOnDNews https:\/\/t.co\/XMu4oB8GD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science Channel",
        "screen_name" : "ScienceChannel",
        "indices" : [ 40, 55 ],
        "id_str" : "16895274",
        "id" : 16895274
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DNews\/status\/719652256035962881\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/XMu4oB8GD9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfy36c_UkAEi6jv.jpg",
        "id_str" : "719652255314513921",
        "id" : 719652255314513921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfy36c_UkAEi6jv.jpg",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 901
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 901
        } ],
        "display_url" : "pic.twitter.com\/XMu4oB8GD9"
      } ],
      "hashtags" : [ {
        "text" : "ObamaOnDNews",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/OApTsJH79w",
        "expanded_url" : "http:\/\/bit.ly\/1qKZN5K",
        "display_url" : "bit.ly\/1qKZN5K"
      } ]
    },
    "geo" : { },
    "id_str" : "719652256035962881",
    "text" : "Watch President Obama Host DNews on the @ScienceChannel: https:\/\/t.co\/OApTsJH79w #ObamaOnDNews https:\/\/t.co\/XMu4oB8GD9",
    "id" : 719652256035962881,
    "created_at" : "2016-04-11 22:24:02 +0000",
    "user" : {
      "name" : "Seeker",
      "screen_name" : "Seeker",
      "protected" : false,
      "id_str" : "16438248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789540319658475520\/EnANLPy2_normal.jpg",
      "id" : 16438248,
      "verified" : true
    }
  },
  "id" : 719687272875077633,
  "created_at" : "2016-04-12 00:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Vlef4TrB3B",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/04\/11\/fact-sheet-white-house-launches-fair-chance-business-pledge",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719683012846170112",
  "text" : "RT @vj44: Thanks to all of the companies who've pledged to give returning citizens a fair chance for employment. https:\/\/t.co\/Vlef4TrB3B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/Vlef4TrB3B",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/04\/11\/fact-sheet-white-house-launches-fair-chance-business-pledge",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719664667031904256",
    "text" : "Thanks to all of the companies who've pledged to give returning citizens a fair chance for employment. https:\/\/t.co\/Vlef4TrB3B",
    "id" : 719664667031904256,
    "created_at" : "2016-04-11 23:13:22 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 719683012846170112,
  "created_at" : "2016-04-12 00:26:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat'l Woman's Party",
      "screen_name" : "SBHMuseum",
      "indices" : [ 3, 13 ],
      "id_str" : "4826383490",
      "id" : 4826383490
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/4iw3KnmVq3",
      "expanded_url" : "http:\/\/ow.ly\/10yeKh",
      "display_url" : "ow.ly\/10yeKh"
    } ]
  },
  "geo" : { },
  "id_str" : "719672113293041668",
  "text" : "RT @SBHMuseum: Honored that @POTUS will proclaim Belmont-Paul Women\u2019s Equality National Monument tmrw. https:\/\/t.co\/4iw3KnmVq3 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SBHMuseum\/status\/719670076530692096\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/F4ZJtC3fC0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfzIHvzWIAATyUA.jpg",
        "id_str" : "719670075888902144",
        "id" : 719670075888902144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfzIHvzWIAATyUA.jpg",
        "sizes" : [ {
          "h" : 850,
          "resize" : "fit",
          "w" : 725
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 725
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 703,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/F4ZJtC3fC0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/4iw3KnmVq3",
        "expanded_url" : "http:\/\/ow.ly\/10yeKh",
        "display_url" : "ow.ly\/10yeKh"
      } ]
    },
    "geo" : { },
    "id_str" : "719670076530692096",
    "text" : "Honored that @POTUS will proclaim Belmont-Paul Women\u2019s Equality National Monument tmrw. https:\/\/t.co\/4iw3KnmVq3 https:\/\/t.co\/F4ZJtC3fC0",
    "id" : 719670076530692096,
    "created_at" : "2016-04-11 23:34:51 +0000",
    "user" : {
      "name" : "Nat'l Woman's Party",
      "screen_name" : "NatlWomansParty",
      "protected" : false,
      "id_str" : "171899574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2205491207\/stained_glass_normal.jpg",
      "id" : 171899574,
      "verified" : false
    }
  },
  "id" : 719672113293041668,
  "created_at" : "2016-04-11 23:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/719653163020603392\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/EEXoL7I27H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfy4pJ-UYAEqQHF.jpg",
      "id_str" : "719653057663885313",
      "id" : 719653057663885313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfy4pJ-UYAEqQHF.jpg",
      "sizes" : [ {
        "h" : 1286,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 754,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1884,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EEXoL7I27H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/O7DbjzSZZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/tMKa9p",
      "display_url" : "go.wh.gov\/tMKa9p"
    } ]
  },
  "geo" : { },
  "id_str" : "719653163020603392",
  "text" : "BREAKING: @POTUS will designate a new national monument honoring women\u2019s equality \u2192 https:\/\/t.co\/O7DbjzSZZ3 https:\/\/t.co\/EEXoL7I27H",
  "id" : 719653163020603392,
  "created_at" : "2016-04-11 22:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 3, 16 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FairChancePledge",
      "indices" : [ 27, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/MATuwfmpyL",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/criminal-justice\/business-pledge",
      "display_url" : "whitehouse.gov\/issues\/crimina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719645933412044800",
  "text" : "RT @LorettaLynch: With the #FairChancePledge we\u2019re eliminating barriers &amp; creating pathways for second chances https:\/\/t.co\/MATuwfmpyL http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LorettaLynch\/status\/719634403748667392\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/P8CvxynUDu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfynrS1WsAAZqBq.jpg",
        "id_str" : "719634402704273408",
        "id" : 719634402704273408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfynrS1WsAAZqBq.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/P8CvxynUDu"
      } ],
      "hashtags" : [ {
        "text" : "FairChancePledge",
        "indices" : [ 9, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/MATuwfmpyL",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/criminal-justice\/business-pledge",
        "display_url" : "whitehouse.gov\/issues\/crimina\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719634403748667392",
    "text" : "With the #FairChancePledge we\u2019re eliminating barriers &amp; creating pathways for second chances https:\/\/t.co\/MATuwfmpyL https:\/\/t.co\/P8CvxynUDu",
    "id" : 719634403748667392,
    "created_at" : "2016-04-11 21:13:06 +0000",
    "user" : {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "protected" : false,
      "id_str" : "3290070855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657296962052468736\/BBNYJ8rH_normal.jpg",
      "id" : 3290070855,
      "verified" : true
    }
  },
  "id" : 719645933412044800,
  "created_at" : "2016-04-11 21:58:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Brown",
      "screen_name" : "JerryBrownGov",
      "indices" : [ 48, 62 ],
      "id_str" : "19418459",
      "id" : 19418459
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/719643618365943809\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/e4mm0Vyz9i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfyv6xrUMAA-UmP.jpg",
      "id_str" : "719643464774725632",
      "id" : 719643464774725632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfyv6xrUMAA-UmP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e4mm0Vyz9i"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719643618365943809",
  "text" : "\"I applaud the California State Legislature and @JerryBrownGov for expanding paid family leave\" \u2014@POTUS #LeadOnLeave https:\/\/t.co\/e4mm0Vyz9i",
  "id" : 719643618365943809,
  "created_at" : "2016-04-11 21:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "indices" : [ 3, 12 ],
      "id_str" : "113439399",
      "id" : 113439399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/e5ngUjLyiu",
      "expanded_url" : "http:\/\/1.usa.gov\/1S1tCFE",
      "display_url" : "1.usa.gov\/1S1tCFE"
    } ]
  },
  "geo" : { },
  "id_str" : "719638042739388416",
  "text" : "RT @smrtgrls: Wed. April 13th is the #WHScienceFair! Tune in between 1PM - 3PM ET. To do your own project \uD83D\uDC49https:\/\/t.co\/e5ngUjLyiu https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/smrtgrls\/status\/719625591893266432\/video\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Ewq5njg4qH",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719625330957258753\/pu\/img\/weq19mWvwi_RUgtz.jpg",
        "id_str" : "719625330957258753",
        "id" : 719625330957258753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719625330957258753\/pu\/img\/weq19mWvwi_RUgtz.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Ewq5njg4qH"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 23, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/e5ngUjLyiu",
        "expanded_url" : "http:\/\/1.usa.gov\/1S1tCFE",
        "display_url" : "1.usa.gov\/1S1tCFE"
      } ]
    },
    "geo" : { },
    "id_str" : "719625591893266432",
    "text" : "Wed. April 13th is the #WHScienceFair! Tune in between 1PM - 3PM ET. To do your own project \uD83D\uDC49https:\/\/t.co\/e5ngUjLyiu https:\/\/t.co\/Ewq5njg4qH",
    "id" : 719625591893266432,
    "created_at" : "2016-04-11 20:38:05 +0000",
    "user" : {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "protected" : false,
      "id_str" : "113439399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700467562413297664\/0qESscTd_normal.png",
      "id" : 113439399,
      "verified" : true
    }
  },
  "id" : 719638042739388416,
  "created_at" : "2016-04-11 21:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719623911445569541\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/AOPSCzWsGz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfyeHmBVIAABFO5.jpg",
      "id_str" : "719623893774835712",
      "id" : 719623893774835712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfyeHmBVIAABFO5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AOPSCzWsGz"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Af9tq6zOuU",
      "expanded_url" : "http:\/\/go.wh.gov\/sz6CfF",
      "display_url" : "go.wh.gov\/sz6CfF"
    } ]
  },
  "geo" : { },
  "id_str" : "719623911445569541",
  "text" : ".@POTUS is calling on Congress to support emergency funding to fight the #Zika virus: https:\/\/t.co\/Af9tq6zOuU https:\/\/t.co\/AOPSCzWsGz",
  "id" : 719623911445569541,
  "created_at" : "2016-04-11 20:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/719601890485411840\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VxJIdq0xGa",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfyKFHoWsAAttGn.jpg",
      "id_str" : "719601861024722944",
      "id" : 719601861024722944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfyKFHoWsAAttGn.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VxJIdq0xGa"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/oGZgAE60JR",
      "expanded_url" : "http:\/\/go.wh.gov\/JYSz9X",
      "display_url" : "go.wh.gov\/JYSz9X"
    } ]
  },
  "geo" : { },
  "id_str" : "719601890485411840",
  "text" : "We have advance warning that #Zika will be arriving in this country. Why Congress must act: https:\/\/t.co\/oGZgAE60JR https:\/\/t.co\/VxJIdq0xGa",
  "id" : 719601890485411840,
  "created_at" : "2016-04-11 19:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 39, 43 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jWy19UQOI8",
      "expanded_url" : "http:\/\/snpy.tv\/1S1fpIT",
      "display_url" : "snpy.tv\/1S1fpIT"
    } ]
  },
  "geo" : { },
  "id_str" : "719593360537862144",
  "text" : "\"I don't have what I need right now.\" \u2014@NIH's Dr. Fauci on why Congress must fund the U.S. response to #Zika virus. https:\/\/t.co\/jWy19UQOI8",
  "id" : 719593360537862144,
  "created_at" : "2016-04-11 18:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 3, 7 ],
      "id_str" : "15134240",
      "id" : 15134240
    }, {
      "name" : "Eric Dishman",
      "screen_name" : "ericdishman",
      "indices" : [ 22, 34 ],
      "id_str" : "20922949",
      "id" : 20922949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NIH",
      "indices" : [ 9, 13 ]
    }, {
      "text" : "PMINetwork",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "NIH",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "PrecisionMedicine",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719577117529346048",
  "text" : "RT @NIH: #NIH selects @ericdishman as director of #PMINetwork to lead #NIH efforts to build 1M+ #PrecisionMedicine study: https:\/\/t.co\/H6MQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Dishman",
        "screen_name" : "ericdishman",
        "indices" : [ 13, 25 ],
        "id_str" : "20922949",
        "id" : 20922949
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NIH",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "PMINetwork",
        "indices" : [ 41, 52 ]
      }, {
        "text" : "NIH",
        "indices" : [ 61, 65 ]
      }, {
        "text" : "PrecisionMedicine",
        "indices" : [ 87, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/H6MQzPqAba",
        "expanded_url" : "http:\/\/1.usa.gov\/1SJqP3R",
        "display_url" : "1.usa.gov\/1SJqP3R"
      } ]
    },
    "geo" : { },
    "id_str" : "719543068815450113",
    "text" : "#NIH selects @ericdishman as director of #PMINetwork to lead #NIH efforts to build 1M+ #PrecisionMedicine study: https:\/\/t.co\/H6MQzPqAba",
    "id" : 719543068815450113,
    "created_at" : "2016-04-11 15:10:10 +0000",
    "user" : {
      "name" : "NIH",
      "screen_name" : "NIH",
      "protected" : false,
      "id_str" : "15134240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3443048571\/ef5062acfce64a7aef1d75b4934fbee6_normal.png",
      "id" : 15134240,
      "verified" : true
    }
  },
  "id" : 719577117529346048,
  "created_at" : "2016-04-11 17:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719567007725797376",
  "text" : "RT @SCOTUSnom: ICYMI: @POTUS discusses what his hope is in the Senate regarding his nominee, Judge Garland. \n\n(Hint: #DoYourJob) https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNewsSunday\/status\/719150241077796865\/video\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/9ChKctkVBX",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719149664507863041\/pu\/img\/K-Q0bZPKs1ZEtJnY.jpg",
        "id_str" : "719149664507863041",
        "id" : 719149664507863041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/719149664507863041\/pu\/img\/K-Q0bZPKs1ZEtJnY.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9ChKctkVBX"
      } ],
      "hashtags" : [ {
        "text" : "DoYourJob",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719550121709424640",
    "text" : "ICYMI: @POTUS discusses what his hope is in the Senate regarding his nominee, Judge Garland. \n\n(Hint: #DoYourJob) https:\/\/t.co\/9ChKctkVBX",
    "id" : 719550121709424640,
    "created_at" : "2016-04-11 15:38:12 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 719567007725797376,
  "created_at" : "2016-04-11 16:45:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 3, 7 ],
      "id_str" : "2367911",
      "id" : 2367911
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IamMBK",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/h4MtVJ4UFq",
      "expanded_url" : "http:\/\/on.mtv.com\/22noTms",
      "display_url" : "on.mtv.com\/22noTms"
    } ]
  },
  "geo" : { },
  "id_str" : "719352774090235904",
  "text" : "RT @MTV: Join @POTUS in ensuring a brighter future for America's young boys and men of color: https:\/\/t.co\/h4MtVJ4UFq #IamMBK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IamMBK",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/h4MtVJ4UFq",
        "expanded_url" : "http:\/\/on.mtv.com\/22noTms",
        "display_url" : "on.mtv.com\/22noTms"
      } ]
    },
    "geo" : { },
    "id_str" : "719352597413511168",
    "text" : "Join @POTUS in ensuring a brighter future for America's young boys and men of color: https:\/\/t.co\/h4MtVJ4UFq #IamMBK",
    "id" : 719352597413511168,
    "created_at" : "2016-04-11 02:33:18 +0000",
    "user" : {
      "name" : "MTV",
      "screen_name" : "MTV",
      "protected" : false,
      "id_str" : "2367911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796753394778144768\/IUKITJH1_normal.jpg",
      "id" : 2367911,
      "verified" : true
    }
  },
  "id" : 719352774090235904,
  "created_at" : "2016-04-11 02:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/TEL7ngAkmf",
      "expanded_url" : "http:\/\/snpy.tv\/23mHN2O",
      "display_url" : "snpy.tv\/23mHN2O"
    } ]
  },
  "geo" : { },
  "id_str" : "719272529609629697",
  "text" : "Go behind the scenes with @POTUS and @FLOTUS in this edition of #WestWingWeek: https:\/\/t.co\/TEL7ngAkmf",
  "id" : 719272529609629697,
  "created_at" : "2016-04-10 21:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/719257676853608449\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/YIXMKlCdtA",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CftDXboWcAAzIVH.jpg",
      "id_str" : "719242635328778240",
      "id" : 719242635328778240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CftDXboWcAAzIVH.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YIXMKlCdtA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/CyspbJcXpS",
      "expanded_url" : "http:\/\/go.wh.gov\/zQiStB",
      "display_url" : "go.wh.gov\/zQiStB"
    } ]
  },
  "geo" : { },
  "id_str" : "719257676853608449",
  "text" : "Saving for retirement? \nHere's how @POTUS is helping to protect your savings: https:\/\/t.co\/CyspbJcXpS https:\/\/t.co\/YIXMKlCdtA",
  "id" : 719257676853608449,
  "created_at" : "2016-04-10 20:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SZCYnfeKwA",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "719248612153163777",
  "text" : "When you retire, you might be missing out on tens of thousands of dollars. \n \nHere's what @POTUS is doing about it: https:\/\/t.co\/SZCYnfeKwA",
  "id" : 719248612153163777,
  "created_at" : "2016-04-10 19:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SZCYnfeKwA",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "719242186542288896",
  "text" : "\"These steps build on the work we\u2019ve already done to make our tax code fairer &amp; consumer protections stronger.\" https:\/\/t.co\/SZCYnfeKwA",
  "id" : 719242186542288896,
  "created_at" : "2016-04-10 19:14:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The HistoryMakers",
      "screen_name" : "TheHstryMakers",
      "indices" : [ 44, 59 ],
      "id_str" : "145688496",
      "id" : 145688496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719205691089645569",
  "text" : "RT @vj44: An honor to be home in Chicago w\/ @TheHstryMakers, an organization that collects African American oral history https:\/\/t.co\/xbKfQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The HistoryMakers",
        "screen_name" : "TheHstryMakers",
        "indices" : [ 34, 49 ],
        "id_str" : "145688496",
        "id" : 145688496
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/719169538411986944\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/xbKfQav0T6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfsA3VUXIAAK8oF.jpg",
        "id_str" : "719169516111077376",
        "id" : 719169516111077376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfsA3VUXIAAK8oF.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xbKfQav0T6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719169538411986944",
    "text" : "An honor to be home in Chicago w\/ @TheHstryMakers, an organization that collects African American oral history https:\/\/t.co\/xbKfQav0T6",
    "id" : 719169538411986944,
    "created_at" : "2016-04-10 14:25:54 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 719205691089645569,
  "created_at" : "2016-04-10 16:49:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveYourSavings",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SZCYneX9F2",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "719203500169830402",
  "text" : "\"This new rule will boost working folks\u2019 retirement savings by billions of dollars a year\"\u2014@POTUS #SaveYourSavings   https:\/\/t.co\/SZCYneX9F2",
  "id" : 719203500169830402,
  "created_at" : "2016-04-10 16:40:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 5, 11 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/SZCYneX9F2",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "718878846930567168",
  "text" : "\"The @USDOL just finalized a rule to crack down on these kinds of conflicts of interest.\" \u2014@POTUS https:\/\/t.co\/SZCYneX9F2",
  "id" : 718878846930567168,
  "created_at" : "2016-04-09 19:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/SZCYneX9F2",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "718861795180572673",
  "text" : "RT if you agree with @POTUS: Let's build an economy where everyone gets a fair shot and plays by the same rules. https:\/\/t.co\/SZCYneX9F2",
  "id" : 718861795180572673,
  "created_at" : "2016-04-09 18:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718840934696267776\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GdOHLC5zCU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfnAxd3UkAAxKfJ.jpg",
      "id_str" : "718817571605090304",
      "id" : 718817571605090304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfnAxd3UkAAxKfJ.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GdOHLC5zCU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/CCUAJuKp7i",
      "expanded_url" : "http:\/\/go.wh.gov\/Nu9sm3",
      "display_url" : "go.wh.gov\/Nu9sm3"
    } ]
  },
  "geo" : { },
  "id_str" : "718840934696267776",
  "text" : "Here's how @POTUS is making sure big companies don't stick the rest of us with the tab \u2192 https:\/\/t.co\/CCUAJuKp7i https:\/\/t.co\/GdOHLC5zCU",
  "id" : 718840934696267776,
  "created_at" : "2016-04-09 16:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveYourSavings",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/SZCYnfeKwA",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "718834650194415617",
  "text" : "Watch @POTUS talk about how he's helping to protect Americans' financial futures. #SaveYourSavings https:\/\/t.co\/SZCYnfeKwA",
  "id" : 718834650194415617,
  "created_at" : "2016-04-09 16:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/SZCYneX9F2",
      "expanded_url" : "http:\/\/go.wh.gov\/fqjixU",
      "display_url" : "go.wh.gov\/fqjixU"
    } ]
  },
  "geo" : { },
  "id_str" : "718816508017831937",
  "text" : "Here's how @POTUS is taking action to ensure everyone plays by the same rules. https:\/\/t.co\/SZCYneX9F2",
  "id" : 718816508017831937,
  "created_at" : "2016-04-09 15:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718581686842368000",
  "text" : "RT @elonmusk: @POTUS Thanks on behalf of an amazing team at SpaceX!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "718579793919238144",
    "geo" : { },
    "id_str" : "718580558180261888",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS Thanks on behalf of an amazing team at SpaceX!",
    "id" : 718580558180261888,
    "in_reply_to_status_id" : 718579793919238144,
    "created_at" : "2016-04-08 23:25:30 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 718581686842368000,
  "created_at" : "2016-04-08 23:29:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718580408020033536",
  "text" : "RT @POTUS: Congrats SpaceX on landing a rocket at sea. It's because of innovators like you &amp; NASA that America continues to lead in space e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718579793919238144",
    "text" : "Congrats SpaceX on landing a rocket at sea. It's because of innovators like you &amp; NASA that America continues to lead in space exploration.",
    "id" : 718579793919238144,
    "created_at" : "2016-04-08 23:22:28 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 718580408020033536,
  "created_at" : "2016-04-08 23:24:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 92, 95 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "CU Boulder",
      "screen_name" : "CUBoulder",
      "indices" : [ 99, 109 ],
      "id_str" : "741150194",
      "id" : 741150194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718571025001123840",
  "text" : "RT @VPLive: \"Your generation is rapidly making us more generous. More open. More decent.\" - @VP at @CUBoulder #ItsOnUs https:\/\/t.co\/NppgQuF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 80, 83 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "CU Boulder",
        "screen_name" : "CUBoulder",
        "indices" : [ 87, 97 ],
        "id_str" : "741150194",
        "id" : 741150194
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VPLive\/status\/718565322069032960\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/NppgQuFeZ0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfjbWkgUkAAHPU2.jpg",
        "id_str" : "718565321368440832",
        "id" : 718565321368440832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfjbWkgUkAAHPU2.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NppgQuFeZ0"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718565322069032960",
    "text" : "\"Your generation is rapidly making us more generous. More open. More decent.\" - @VP at @CUBoulder #ItsOnUs https:\/\/t.co\/NppgQuFeZ0",
    "id" : 718565322069032960,
    "created_at" : "2016-04-08 22:24:57 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 718571025001123840,
  "created_at" : "2016-04-08 22:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 26, 33 ],
      "id_str" : "34743251",
      "id" : 34743251
    }, {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 45, 54 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 103, 117 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dragon",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/TCJCQljJBZ",
      "expanded_url" : "http:\/\/snpy.tv\/1V9tslL",
      "display_url" : "snpy.tv\/1V9tslL"
    } ]
  },
  "geo" : { },
  "id_str" : "718550704634245121",
  "text" : "RT @NASA: Congrats to the @SpaceX team &amp; @ElonMusk! Way to stick the landing &amp; send #Dragon to @Space_Station. https:\/\/t.co\/TCJCQljJBZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 16, 23 ],
        "id_str" : "34743251",
        "id" : 34743251
      }, {
        "name" : "Elon Musk",
        "screen_name" : "elonmusk",
        "indices" : [ 35, 44 ],
        "id_str" : "44196397",
        "id" : 44196397
      }, {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 93, 107 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dragon",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/TCJCQljJBZ",
        "expanded_url" : "http:\/\/snpy.tv\/1V9tslL",
        "display_url" : "snpy.tv\/1V9tslL"
      } ]
    },
    "geo" : { },
    "id_str" : "718545613051158529",
    "text" : "Congrats to the @SpaceX team &amp; @ElonMusk! Way to stick the landing &amp; send #Dragon to @Space_Station. https:\/\/t.co\/TCJCQljJBZ",
    "id" : 718545613051158529,
    "created_at" : "2016-04-08 21:06:38 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 718550704634245121,
  "created_at" : "2016-04-08 21:26:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/718536653162328066\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/MfoEY1EpIH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfjBLdHXIAEkFcj.jpg",
      "id_str" : "718536543103819777",
      "id" : 718536543103819777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfjBLdHXIAEkFcj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MfoEY1EpIH"
    } ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718536653162328066",
  "text" : "Reminder: \nPresidents don\u2019t stop working in the final year of their terms.\nNeither should a Senator. #DoYourJob https:\/\/t.co\/MfoEY1EpIH",
  "id" : 718536653162328066,
  "created_at" : "2016-04-08 20:31:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/1I4aNkiDaj",
      "expanded_url" : "http:\/\/thehill.com\/policy\/healthcare\/275651-rubio-breaks-with-gop-backs-obama-zika-request",
      "display_url" : "thehill.com\/policy\/healthc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718535047041675265",
  "text" : "RT @PressSec: Funding our efforts to fight #Zika shouldn't be partisan \u2192 https:\/\/t.co\/1I4aNkiDaj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 29, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/1I4aNkiDaj",
        "expanded_url" : "http:\/\/thehill.com\/policy\/healthcare\/275651-rubio-breaks-with-gop-backs-obama-zika-request",
        "display_url" : "thehill.com\/policy\/healthc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718534786835357696",
    "text" : "Funding our efforts to fight #Zika shouldn't be partisan \u2192 https:\/\/t.co\/1I4aNkiDaj",
    "id" : 718534786835357696,
    "created_at" : "2016-04-08 20:23:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 718535047041675265,
  "created_at" : "2016-04-08 20:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718514857537052673\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/wYDMG5t261",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfitXTZUEAAyzmv.jpg",
      "id_str" : "718514756420636672",
      "id" : 718514756420636672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfitXTZUEAAyzmv.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wYDMG5t261"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "718514857537052673",
  "text" : "1 in 3 U.S. Presidents have had a Supreme Court nominee confirmed in an election year \u2192 https:\/\/t.co\/O5iYU1cW6b https:\/\/t.co\/wYDMG5t261",
  "id" : 718514857537052673,
  "created_at" : "2016-04-08 19:04:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UChicago",
      "screen_name" : "UChicago",
      "indices" : [ 3, 12 ],
      "id_str" : "131144285",
      "id" : 131144285
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 55, 67 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UChicago\/status\/718483111810621440\/video\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/jyclyzsoGE",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/718475876443230212\/pu\/img\/bu4BqjDdEZcbnIku.jpg",
      "id_str" : "718475876443230212",
      "id" : 718475876443230212,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/718475876443230212\/pu\/img\/bu4BqjDdEZcbnIku.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jyclyzsoGE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Rfo9FCHHhS",
      "expanded_url" : "http:\/\/bit.ly\/1RJ6tLp",
      "display_url" : "bit.ly\/1RJ6tLp"
    } ]
  },
  "geo" : { },
  "id_str" : "718484755554123777",
  "text" : "RT @UChicago: Inside President Barack Obama's visit to @UChicagoLaw yesterday: https:\/\/t.co\/Rfo9FCHHhS https:\/\/t.co\/jyclyzsoGE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UChicago Law School",
        "screen_name" : "UChicagoLaw",
        "indices" : [ 41, 53 ],
        "id_str" : "14869449",
        "id" : 14869449
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UChicago\/status\/718483111810621440\/video\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/jyclyzsoGE",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/718475876443230212\/pu\/img\/bu4BqjDdEZcbnIku.jpg",
        "id_str" : "718475876443230212",
        "id" : 718475876443230212,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/718475876443230212\/pu\/img\/bu4BqjDdEZcbnIku.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jyclyzsoGE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/Rfo9FCHHhS",
        "expanded_url" : "http:\/\/bit.ly\/1RJ6tLp",
        "display_url" : "bit.ly\/1RJ6tLp"
      } ]
    },
    "geo" : { },
    "id_str" : "718483111810621440",
    "text" : "Inside President Barack Obama's visit to @UChicagoLaw yesterday: https:\/\/t.co\/Rfo9FCHHhS https:\/\/t.co\/jyclyzsoGE",
    "id" : 718483111810621440,
    "created_at" : "2016-04-08 16:58:17 +0000",
    "user" : {
      "name" : "UChicago",
      "screen_name" : "UChicago",
      "protected" : false,
      "id_str" : "131144285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695736402382864384\/fSxfSN3P_normal.jpg",
      "id" : 131144285,
      "verified" : true
    }
  },
  "id" : 718484755554123777,
  "created_at" : "2016-04-08 17:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Idol",
      "screen_name" : "AmericanIdol",
      "indices" : [ 3, 16 ],
      "id_str" : "62988756",
      "id" : 62988756
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IdolFinale",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "ObamaOnIdol",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/hdRiC1mh3b",
      "expanded_url" : "http:\/\/vote.gov",
      "display_url" : "vote.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "718228321524432898",
  "text" : "RT @AmericanIdol: Check out a special #IdolFinale message from @POTUS! Then, register to vote at https:\/\/t.co\/hdRiC1mh3b. #ObamaOnIdol\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 45, 51 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IdolFinale",
        "indices" : [ 20, 31 ]
      }, {
        "text" : "ObamaOnIdol",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/hdRiC1mh3b",
        "expanded_url" : "http:\/\/vote.gov",
        "display_url" : "vote.gov"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ButQIsh3l1",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/3cc0c43b-c4fa-4398-8a04-dec4c5c7c73b",
        "display_url" : "amp.twimg.com\/v\/3cc0c43b-c4f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718227182670065664",
    "text" : "Check out a special #IdolFinale message from @POTUS! Then, register to vote at https:\/\/t.co\/hdRiC1mh3b. #ObamaOnIdol\nhttps:\/\/t.co\/ButQIsh3l1",
    "id" : 718227182670065664,
    "created_at" : "2016-04-08 00:01:19 +0000",
    "user" : {
      "name" : "American Idol",
      "screen_name" : "AmericanIdol",
      "protected" : false,
      "id_str" : "62988756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672134207276236801\/BQTNwXaL_normal.png",
      "id" : 62988756,
      "verified" : true
    }
  },
  "id" : 718228321524432898,
  "created_at" : "2016-04-08 00:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/GhYz0uRpQI",
      "expanded_url" : "http:\/\/wapo.st\/1RPztOd",
      "display_url" : "wapo.st\/1RPztOd"
    } ]
  },
  "geo" : { },
  "id_str" : "718222541618356224",
  "text" : "RT @SCOTUSnom: \u201CHe deserves the job.\u201D 5th grader Vernell on his mentor and #SCOTUS nominee Judge Garland. https:\/\/t.co\/GhYz0uRpQI https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/718211938467983360\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/PrYqPMoKIX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfeWblMUAAED20o.jpg",
        "id_str" : "718208066173272065",
        "id" : 718208066173272065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfeWblMUAAED20o.jpg",
        "sizes" : [ {
          "h" : 820,
          "resize" : "fit",
          "w" : 1144
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PrYqPMoKIX"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/GhYz0uRpQI",
        "expanded_url" : "http:\/\/wapo.st\/1RPztOd",
        "display_url" : "wapo.st\/1RPztOd"
      } ]
    },
    "geo" : { },
    "id_str" : "718211938467983360",
    "text" : "\u201CHe deserves the job.\u201D 5th grader Vernell on his mentor and #SCOTUS nominee Judge Garland. https:\/\/t.co\/GhYz0uRpQI https:\/\/t.co\/PrYqPMoKIX",
    "id" : 718211938467983360,
    "created_at" : "2016-04-07 23:00:44 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 718222541618356224,
  "created_at" : "2016-04-07 23:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 89, 101 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718186138045964288",
  "text" : "\"The most important office in a democracy is the office of citizen.\" \u2014@POTUS to students @UChicagoLaw #SCOTUS",
  "id" : 718186138045964288,
  "created_at" : "2016-04-07 21:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/KaT1lIUv4S",
      "expanded_url" : "http:\/\/snpy.tv\/1V0e23r",
      "display_url" : "snpy.tv\/1V0e23r"
    } ]
  },
  "geo" : { },
  "id_str" : "718182627379974145",
  "text" : "\"I have transformed the federal courts from a diversity standpoint.\" \u2014@POTUS on #SCOTUS https:\/\/t.co\/KaT1lIUv4S",
  "id" : 718182627379974145,
  "created_at" : "2016-04-07 21:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 102, 114 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/718181105032015872\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/4GqOLVu1sP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfd9dMRW4AAJ9g2.jpg",
      "id_str" : "718180606052589568",
      "id" : 718180606052589568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfd9dMRW4AAJ9g2.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4GqOLVu1sP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718181105032015872",
  "text" : "\"We have not just federal laws but state laws that unabashedly discourage people from voting\" \u2014@POTUS @UChicagoLaw https:\/\/t.co\/4GqOLVu1sP",
  "id" : 718181105032015872,
  "created_at" : "2016-04-07 20:58:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Miko",
      "screen_name" : "senate_gops",
      "indices" : [ 64, 76 ],
      "id_str" : "720304525333008384",
      "id" : 720304525333008384
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/KF1TbDoF1w",
      "expanded_url" : "http:\/\/snpy.tv\/23fWwN1",
      "display_url" : "snpy.tv\/23fWwN1"
    } ]
  },
  "geo" : { },
  "id_str" : "718180129252499456",
  "text" : "That corrodes the ability of the courts to function\" \u2014@POTUS on @Senate_GOPs' obstruction of #SCOTUS nomination  https:\/\/t.co\/KF1TbDoF1w",
  "id" : 718180129252499456,
  "created_at" : "2016-04-07 20:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718177110477639680\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/poVl7ythNf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfd6M7gW4AER5ZT.jpg",
      "id_str" : "718177028139311105",
      "id" : 718177028139311105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfd6M7gW4AER5ZT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/poVl7ythNf"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/faxe80zhBD",
      "expanded_url" : "http:\/\/wh.gov\/SCOTUS",
      "display_url" : "wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "718177110477639680",
  "text" : "\u201CWhat\u2019s not acceptable is not giving him a vote. Not giving him a hearing\" \u2014@POTUS: https:\/\/t.co\/faxe80zhBD #SCOTUS https:\/\/t.co\/poVl7ythNf",
  "id" : 718177110477639680,
  "created_at" : "2016-04-07 20:42:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718175008686669824\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/9s7H2Utbh0",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cfd4SBQWcAII_69.jpg",
      "id_str" : "718174916558876674",
      "id" : 718174916558876674,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cfd4SBQWcAII_69.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9s7H2Utbh0"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/O5iYU0VkHB",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "718175008686669824",
  "text" : "14 presidents.\n19 Supreme Court nominations.\nAll in presidential election years \u2192 https:\/\/t.co\/O5iYU0VkHB #SCOTUS https:\/\/t.co\/9s7H2Utbh0",
  "id" : 718175008686669824,
  "created_at" : "2016-04-07 20:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 64, 76 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718174005283282944\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/VrrpjUCe5t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfd3WRRW8AEb3Q7.jpg",
      "id_str" : "718173890065920001",
      "id" : 718173890065920001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfd3WRRW8AEb3Q7.jpg",
      "sizes" : [ {
        "h" : 603,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 490
      } ],
      "display_url" : "pic.twitter.com\/VrrpjUCe5t"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/sKzUwBYsit",
      "expanded_url" : "http:\/\/go.wh.gov\/KR8tNr",
      "display_url" : "go.wh.gov\/KR8tNr"
    } ]
  },
  "geo" : { },
  "id_str" : "718174005283282944",
  "text" : "Take a front row seat as @POTUS leads a conversation on #SCOTUS @UChicagoLaw: https:\/\/t.co\/sKzUwBYsit https:\/\/t.co\/VrrpjUCe5t",
  "id" : 718174005283282944,
  "created_at" : "2016-04-07 20:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718171642011078657",
  "text" : "RT @SCOTUSnom: .@POTUS shares a story of Judge Garland's stirring, impromptu defense of the 1st Amendment...when he was 18. #SCOTUS https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LxnzS8Cvvh",
        "expanded_url" : "http:\/\/snpy.tv\/1V07v8K",
        "display_url" : "snpy.tv\/1V07v8K"
      } ]
    },
    "geo" : { },
    "id_str" : "718170930858430464",
    "text" : ".@POTUS shares a story of Judge Garland's stirring, impromptu defense of the 1st Amendment...when he was 18. #SCOTUS https:\/\/t.co\/LxnzS8Cvvh",
    "id" : 718170930858430464,
    "created_at" : "2016-04-07 20:17:47 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 718171642011078657,
  "created_at" : "2016-04-07 20:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 65, 75 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/k4wbqSFyFR",
      "expanded_url" : "http:\/\/snpy.tv\/23fPXtK",
      "display_url" : "snpy.tv\/23fPXtK"
    } ]
  },
  "geo" : { },
  "id_str" : "718170546450468864",
  "text" : ".@POTUS on why it's the Senate's constitutional duty to give his @SCOTUSnom a hearing and a vote. https:\/\/t.co\/k4wbqSFyFR",
  "id" : 718170546450468864,
  "created_at" : "2016-04-07 20:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/EnlqWxOhtA",
      "expanded_url" : "http:\/\/snpy.tv\/1V05ycw",
      "display_url" : "snpy.tv\/1V05ycw"
    } ]
  },
  "geo" : { },
  "id_str" : "718168276140957696",
  "text" : "RT @SCOTUSnom: .@POTUS on the current broken process of appointing judges to America's judicial branch. #SCOTUS https:\/\/t.co\/EnlqWxOhtA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/EnlqWxOhtA",
        "expanded_url" : "http:\/\/snpy.tv\/1V05ycw",
        "display_url" : "snpy.tv\/1V05ycw"
      } ]
    },
    "geo" : { },
    "id_str" : "718167069661900800",
    "text" : ".@POTUS on the current broken process of appointing judges to America's judicial branch. #SCOTUS https:\/\/t.co\/EnlqWxOhtA",
    "id" : 718167069661900800,
    "created_at" : "2016-04-07 20:02:26 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 718168276140957696,
  "created_at" : "2016-04-07 20:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/faxe80zhBD",
      "expanded_url" : "http:\/\/wh.gov\/SCOTUS",
      "display_url" : "wh.gov\/SCOTUS"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Q9xPmXwwAR",
      "expanded_url" : "http:\/\/snpy.tv\/25NQPEF",
      "display_url" : "snpy.tv\/25NQPEF"
    } ]
  },
  "geo" : { },
  "id_str" : "718167141573402625",
  "text" : "Watch @POTUS talk about why his #SCOTUS nominee Merrick Garland is indisputably qualified: https:\/\/t.co\/faxe80zhBD https:\/\/t.co\/Q9xPmXwwAR",
  "id" : 718167141573402625,
  "created_at" : "2016-04-07 20:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "DoYourJob",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718166224081960961",
  "text" : "RT @SCOTUSnom: \"Why is it so hard for this guy to get a hearing and a vote?\" \u2014@POTUS on GOP obstruction of #SCOTUS nom. #DoYourJob https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 63, 69 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 92, 99 ]
      }, {
        "text" : "DoYourJob",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/dDKgyXwlOC",
        "expanded_url" : "http:\/\/snpy.tv\/25NQPEF",
        "display_url" : "snpy.tv\/25NQPEF"
      } ]
    },
    "in_reply_to_status_id_str" : "718164970802819072",
    "geo" : { },
    "id_str" : "718166120184676353",
    "in_reply_to_user_id" : 708072909114318848,
    "text" : "\"Why is it so hard for this guy to get a hearing and a vote?\" \u2014@POTUS on GOP obstruction of #SCOTUS nom. #DoYourJob https:\/\/t.co\/dDKgyXwlOC",
    "id" : 718166120184676353,
    "in_reply_to_status_id" : 718164970802819072,
    "created_at" : "2016-04-07 19:58:40 +0000",
    "in_reply_to_screen_name" : "SCOTUSnom",
    "in_reply_to_user_id_str" : "708072909114318848",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 718166224081960961,
  "created_at" : "2016-04-07 19:59:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 90, 100 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718165620748062720\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/3AHiV5W6Yj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfdvxf_WwAATBXn.jpg",
      "id_str" : "718165561780387840",
      "id" : 718165561780387840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfdvxf_WwAATBXn.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3AHiV5W6Yj"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718165620748062720",
  "text" : "\"Merrick Garland is an extraordinary jurist who is indisputably qualified\" \u2014@POTUS on his @SCOTUSnom #SCOTUS https:\/\/t.co\/3AHiV5W6Yj",
  "id" : 718165620748062720,
  "created_at" : "2016-04-07 19:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718165034761846787",
  "text" : "RT @SCOTUSnom: \"Merrick Garland is an extraordinary jurist who is indisputably qualified to serve on the Supreme Court.\" \u2014@POTUS on Chief J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 107, 113 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718164970802819072",
    "text" : "\"Merrick Garland is an extraordinary jurist who is indisputably qualified to serve on the Supreme Court.\" \u2014@POTUS on Chief Judge Garland.",
    "id" : 718164970802819072,
    "created_at" : "2016-04-07 19:54:06 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 718165034761846787,
  "created_at" : "2016-04-07 19:54:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 90, 102 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "718163288736079876",
  "text" : "Happening now: Tune in for a lesson on the importance of #SCOTUS from Professor @POTUS at @UChicagoLaw \u2192 https:\/\/t.co\/O5iYU1cW6b",
  "id" : 718163288736079876,
  "created_at" : "2016-04-07 19:47:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718151804895248384\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bC321IDLhn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfdjM60VAAAqkUp.jpg",
      "id_str" : "718151739187200000",
      "id" : 718151739187200000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfdjM60VAAAqkUp.jpg",
      "sizes" : [ {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1794,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bC321IDLhn"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 77, 84 ]
    }, {
      "text" : "TBT",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/I1ZMZzOBzw",
      "expanded_url" : "http:\/\/go.wh.gov\/Bh6C75",
      "display_url" : "go.wh.gov\/Bh6C75"
    } ]
  },
  "geo" : { },
  "id_str" : "718151804895248384",
  "text" : ".@POTUS taught constitutional law for over 10 years. He's back today to talk #SCOTUS \u2192  https:\/\/t.co\/I1ZMZzOBzw #TBT https:\/\/t.co\/bC321IDLhn",
  "id" : 718151804895248384,
  "created_at" : "2016-04-07 19:01:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 28, 40 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718146305734750208\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5c3drrlIBE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfdeBBgW8AAaMHn.jpg",
      "id_str" : "718146037265920000",
      "id" : 718146037265920000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfdeBBgW8AAaMHn.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2382,
        "resize" : "fit",
        "w" : 3512
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5c3drrlIBE"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "TBT",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/O5iYU0VkHB",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "718146305734750208",
  "text" : "Professor @POTUS is back at @UChicagoLaw to talk about #SCOTUS. Tune in at 3:30 pm ET \u2192 https:\/\/t.co\/O5iYU0VkHB #TBT https:\/\/t.co\/5c3drrlIBE",
  "id" : 718146305734750208,
  "created_at" : "2016-04-07 18:39:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/OI0bmvoium",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "718143781556490240",
  "text" : "RT @SCOTUSnom: Tune in at 3:30pm ET for a lesson on the importance of #SCOTUS from Professor @POTUS: https:\/\/t.co\/OI0bmvoium https:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 78, 84 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/718143339795755008\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/HD6h2sj8E1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfdayeJWIAAeosY.jpg",
        "id_str" : "718142488721104896",
        "id" : 718142488721104896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfdayeJWIAAeosY.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HD6h2sj8E1"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 55, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/OI0bmvoium",
        "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
        "display_url" : "go.wh.gov\/SCOTUS"
      } ]
    },
    "geo" : { },
    "id_str" : "718143339795755008",
    "text" : "Tune in at 3:30pm ET for a lesson on the importance of #SCOTUS from Professor @POTUS: https:\/\/t.co\/OI0bmvoium https:\/\/t.co\/HD6h2sj8E1",
    "id" : 718143339795755008,
    "created_at" : "2016-04-07 18:28:09 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 718143781556490240,
  "created_at" : "2016-04-07 18:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 89, 101 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/EwhnTeDi32",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "718137548694953985",
  "text" : "RT @vj44: Have Qs on #SCOTUS? Ask here &amp; tune in at 3:30pm ET when @POTUS returns to @UChicagoLaw https:\/\/t.co\/EwhnTeDi32 https:\/\/t.co\/VMgt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 61, 67 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "UChicago Law School",
        "screen_name" : "UChicagoLaw",
        "indices" : [ 79, 91 ],
        "id_str" : "14869449",
        "id" : 14869449
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/718129097872904192\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/VMgtyp48xh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfdOlhiWsAILT_7.jpg",
        "id_str" : "718129072153473026",
        "id" : 718129072153473026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfdOlhiWsAILT_7.jpg",
        "sizes" : [ {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1281,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/VMgtyp48xh"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/EwhnTeDi32",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "718129097872904192",
    "text" : "Have Qs on #SCOTUS? Ask here &amp; tune in at 3:30pm ET when @POTUS returns to @UChicagoLaw https:\/\/t.co\/EwhnTeDi32 https:\/\/t.co\/VMgtyp48xh",
    "id" : 718129097872904192,
    "created_at" : "2016-04-07 17:31:33 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 718137548694953985,
  "created_at" : "2016-04-07 18:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718124278193852417\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fW0rZT9Y3w",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfdKBxoUEAEXf65.jpg",
      "id_str" : "718124059951632385",
      "id" : 718124059951632385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfdKBxoUEAEXf65.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fW0rZT9Y3w"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 64, 69 ]
    }, {
      "text" : "WorldHealthDay",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Af9tq6id6k",
      "expanded_url" : "http:\/\/go.wh.gov\/sz6CfF",
      "display_url" : "go.wh.gov\/sz6CfF"
    } ]
  },
  "geo" : { },
  "id_str" : "718124278193852417",
  "text" : "Here's why @POTUS is asking Congress for funding to address the #Zika virus: https:\/\/t.co\/Af9tq6id6k #WorldHealthDay https:\/\/t.co\/fW0rZT9Y3w",
  "id" : 718124278193852417,
  "created_at" : "2016-04-07 17:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718112921633603585",
  "text" : "RT @VP: I get asked a lot how I got so engaged in #ItsOnUs, and the issue of violence against women. Here's the answer: https:\/\/t.co\/aTuUHG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 42, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/aTuUHGPLHM",
        "expanded_url" : "http:\/\/go.wh.gov\/VP-ItsOnUs-FB",
        "display_url" : "go.wh.gov\/VP-ItsOnUs-FB"
      } ]
    },
    "geo" : { },
    "id_str" : "718108380485849088",
    "text" : "I get asked a lot how I got so engaged in #ItsOnUs, and the issue of violence against women. Here's the answer: https:\/\/t.co\/aTuUHGPLHM",
    "id" : 718108380485849088,
    "created_at" : "2016-04-07 16:09:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 718112921633603585,
  "created_at" : "2016-04-07 16:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/tFQP2AZnZf",
      "expanded_url" : "http:\/\/vice.com\/read\/undocumented-college-students-share-how-obama-changed-their-lives",
      "display_url" : "vice.com\/read\/undocumen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718110259143909376",
  "text" : "RT @lacasablanca: \"If you want to talk about how DACA affects the lives of DREAMers, it changed my life...\"\u2192 https:\/\/t.co\/tFQP2AZnZf https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/718108300949065729\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ore35yKEwh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfc7sRNWsAIvinj.jpg",
        "id_str" : "718108297308581890",
        "id" : 718108297308581890,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfc7sRNWsAIvinj.jpg",
        "sizes" : [ {
          "h" : 136,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ore35yKEwh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/tFQP2AZnZf",
        "expanded_url" : "http:\/\/vice.com\/read\/undocumented-college-students-share-how-obama-changed-their-lives",
        "display_url" : "vice.com\/read\/undocumen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718108300949065729",
    "text" : "\"If you want to talk about how DACA affects the lives of DREAMers, it changed my life...\"\u2192 https:\/\/t.co\/tFQP2AZnZf https:\/\/t.co\/ore35yKEwh",
    "id" : 718108300949065729,
    "created_at" : "2016-04-07 16:08:55 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 718110259143909376,
  "created_at" : "2016-04-07 16:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 70, 82 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/718104887846903809\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5m0v0NLg9N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfc4eIwUkAAE4OS.jpg",
      "id_str" : "718104755986272256",
      "id" : 718104755986272256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfc4eIwUkAAE4OS.jpg",
      "sizes" : [ {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1794,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5m0v0NLg9N"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/I1ZMZzOBzw",
      "expanded_url" : "http:\/\/go.wh.gov\/Bh6C75",
      "display_url" : "go.wh.gov\/Bh6C75"
    } ]
  },
  "geo" : { },
  "id_str" : "718104887846903809",
  "text" : "\"Before he was President, he was a law professor. My professor\" \u2014Dan, @UChicagoLaw '00 Grad: https:\/\/t.co\/I1ZMZzOBzw https:\/\/t.co\/5m0v0NLg9N",
  "id" : 718104887846903809,
  "created_at" : "2016-04-07 15:55:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 21, 33 ],
      "id_str" : "14869449",
      "id" : 14869449
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717861124813643776",
  "text" : "RT @vj44: Heading to @UChicagoLaw tomorrow for @POTUS to talk with students on the Supreme Court\nGot Qs? Ask with #SCOTUS\nI'll be answering\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UChicago Law School",
        "screen_name" : "UChicagoLaw",
        "indices" : [ 11, 23 ],
        "id_str" : "14869449",
        "id" : 14869449
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 37, 43 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717859563618320389",
    "text" : "Heading to @UChicagoLaw tomorrow for @POTUS to talk with students on the Supreme Court\nGot Qs? Ask with #SCOTUS\nI'll be answering all day",
    "id" : 717859563618320389,
    "created_at" : "2016-04-06 23:40:31 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 717861124813643776,
  "created_at" : "2016-04-06 23:46:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 80, 87 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717857277236142080\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/nDRu8bu12K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfZXSuNUsAEkELn.jpg",
      "id_str" : "717857169765347329",
      "id" : 717857169765347329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfZXSuNUsAEkELn.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/nDRu8bu12K"
    } ],
    "hashtags" : [ {
      "text" : "Nowruz",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/dMv2EXhDQN",
      "expanded_url" : "http:\/\/go.wh.gov\/GGSpYo",
      "display_url" : "go.wh.gov\/GGSpYo"
    } ]
  },
  "geo" : { },
  "id_str" : "717857277236142080",
  "text" : "\"Our diversity has been &amp; will always be our greatest source of strength.\" \u2014@FLOTUS: https:\/\/t.co\/dMv2EXhDQN #Nowruz https:\/\/t.co\/nDRu8bu12K",
  "id" : 717857277236142080,
  "created_at" : "2016-04-06 23:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717839339712065537\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/UlxMyktiIY",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfZGutCUMAA2MEg.jpg",
      "id_str" : "717838958789406720",
      "id" : 717838958789406720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfZGutCUMAA2MEg.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UlxMyktiIY"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/oGZgADOpSj",
      "expanded_url" : "http:\/\/go.wh.gov\/JYSz9X",
      "display_url" : "go.wh.gov\/JYSz9X"
    } ]
  },
  "geo" : { },
  "id_str" : "717839339712065537",
  "text" : "There's no excuse for Congress's failure to join @POTUS in taking action to combat #Zika: https:\/\/t.co\/oGZgADOpSj https:\/\/t.co\/UlxMyktiIY",
  "id" : 717839339712065537,
  "created_at" : "2016-04-06 22:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/4eP9xU7QrX",
      "expanded_url" : "http:\/\/www.snappytv.com\/tc\/1674258",
      "display_url" : "snappytv.com\/tc\/1674258"
    } ]
  },
  "geo" : { },
  "id_str" : "717825894212042754",
  "text" : "RT @PressSec: The Administration continues to take proactive steps to fight #Zika &amp; now Congress should do the same https:\/\/t.co\/4eP9xU7QrX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 62, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/4eP9xU7QrX",
        "expanded_url" : "http:\/\/www.snappytv.com\/tc\/1674258",
        "display_url" : "snappytv.com\/tc\/1674258"
      } ]
    },
    "geo" : { },
    "id_str" : "717819936593223680",
    "text" : "The Administration continues to take proactive steps to fight #Zika &amp; now Congress should do the same https:\/\/t.co\/4eP9xU7QrX",
    "id" : 717819936593223680,
    "created_at" : "2016-04-06 21:03:03 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 717825894212042754,
  "created_at" : "2016-04-06 21:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717824978541002754\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0rRUbhs3TE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfY49P1VIAAAAgr.jpg",
      "id_str" : "717823815485562880",
      "id" : 717823815485562880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfY49P1VIAAAAgr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0rRUbhs3TE"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/oGZgADOpSj",
      "expanded_url" : "http:\/\/go.wh.gov\/JYSz9X",
      "display_url" : "go.wh.gov\/JYSz9X"
    } ]
  },
  "geo" : { },
  "id_str" : "717824978541002754",
  "text" : "We have a rare chance to protect Americans from the #Zika epidemic. \nCongress needs to act \u2192 https:\/\/t.co\/oGZgADOpSj https:\/\/t.co\/0rRUbhs3TE",
  "id" : 717824978541002754,
  "created_at" : "2016-04-06 21:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/717811489554481153\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/4oHmOYN7kL",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfYttsdUAAAtVoi.jpg",
      "id_str" : "717811453663641600",
      "id" : 717811453663641600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfYttsdUAAAtVoi.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4oHmOYN7kL"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/oGZgADOpSj",
      "expanded_url" : "http:\/\/go.wh.gov\/JYSz9X",
      "display_url" : "go.wh.gov\/JYSz9X"
    } ]
  },
  "geo" : { },
  "id_str" : "717811489554481153",
  "text" : "Why Congress needs to act now on @POTUS's request for funding to combat #Zika\u2014in one chart: https:\/\/t.co\/oGZgADOpSj https:\/\/t.co\/4oHmOYN7kL",
  "id" : 717811489554481153,
  "created_at" : "2016-04-06 20:29:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoAnn Jenkins",
      "screen_name" : "JoAnn_Jenkins",
      "indices" : [ 3, 17 ],
      "id_str" : "339679000",
      "id" : 339679000
    }, {
      "name" : "AARP",
      "screen_name" : "AARP",
      "indices" : [ 58, 63 ],
      "id_str" : "80628196",
      "id" : 80628196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "consumers",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "retirement",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/CyOPuq76q7",
      "expanded_url" : "http:\/\/bit.ly\/1oCcP3H",
      "display_url" : "bit.ly\/1oCcP3H"
    } ]
  },
  "geo" : { },
  "id_str" : "717788107601551361",
  "text" : "RT @JoAnn_Jenkins: A huge victory for #consumers today as @AARP backed rule on #retirement savings advice finalized https:\/\/t.co\/CyOPuq76q7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AARP",
        "screen_name" : "AARP",
        "indices" : [ 39, 44 ],
        "id_str" : "80628196",
        "id" : 80628196
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "consumers",
        "indices" : [ 19, 29 ]
      }, {
        "text" : "retirement",
        "indices" : [ 60, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/CyOPuq76q7",
        "expanded_url" : "http:\/\/bit.ly\/1oCcP3H",
        "display_url" : "bit.ly\/1oCcP3H"
      } ]
    },
    "geo" : { },
    "id_str" : "717758407885905920",
    "text" : "A huge victory for #consumers today as @AARP backed rule on #retirement savings advice finalized https:\/\/t.co\/CyOPuq76q7",
    "id" : 717758407885905920,
    "created_at" : "2016-04-06 16:58:34 +0000",
    "user" : {
      "name" : "JoAnn Jenkins",
      "screen_name" : "JoAnn_Jenkins",
      "protected" : false,
      "id_str" : "339679000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730456869848887298\/U1jlm2vy_normal.jpg",
      "id" : 339679000,
      "verified" : false
    }
  },
  "id" : 717788107601551361,
  "created_at" : "2016-04-06 18:56:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717780281684598784\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/acmB6bapgM",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfYQ5ihUUAAPEVE.jpg",
      "id_str" : "717779771317309440",
      "id" : 717779771317309440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfYQ5ihUUAAPEVE.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/acmB6bapgM"
    } ],
    "hashtags" : [ {
      "text" : "SaveYourSavings",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/QQDCietdmk",
      "expanded_url" : "http:\/\/dol.gov\/SaveYourSavings",
      "display_url" : "dol.gov\/SaveYourSavings"
    } ]
  },
  "geo" : { },
  "id_str" : "717780281684598784",
  "text" : "Saving for retirement? \nHere's how we're helping to protect your savings: https:\/\/t.co\/QQDCietdmk #SaveYourSavings https:\/\/t.co\/acmB6bapgM",
  "id" : 717780281684598784,
  "created_at" : "2016-04-06 18:25:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717776476360339457",
  "text" : "RT @NSC44: \u201CWe are working to make sure that we\u2019re accelerating the campaign against ISIL.\u201D-@POTUS mtg w\/ Combatant Commanders https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 81, 87 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/717760812476026882\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/OODnvnHmuN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfX_niNUkAI5DAf.jpg",
        "id_str" : "717760770298122242",
        "id" : 717760770298122242,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfX_niNUkAI5DAf.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OODnvnHmuN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717760812476026882",
    "text" : "\u201CWe are working to make sure that we\u2019re accelerating the campaign against ISIL.\u201D-@POTUS mtg w\/ Combatant Commanders https:\/\/t.co\/OODnvnHmuN",
    "id" : 717760812476026882,
    "created_at" : "2016-04-06 17:08:07 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 717776476360339457,
  "created_at" : "2016-04-06 18:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 18, 24 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveYourSavings",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717762528458227713",
  "text" : "RT @NancyPelosi: .@USDOL's new rule on retirement savings will enhance the security of hard-working Americans. #SaveYourSavings https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Labor Department",
        "screen_name" : "USDOL",
        "indices" : [ 1, 7 ],
        "id_str" : "20179628",
        "id" : 20179628
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaveYourSavings",
        "indices" : [ 94, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/i8TTmvcDew",
        "expanded_url" : "http:\/\/goo.gl\/mrz2Pc",
        "display_url" : "goo.gl\/mrz2Pc"
      } ]
    },
    "geo" : { },
    "id_str" : "717753803152494592",
    "text" : ".@USDOL's new rule on retirement savings will enhance the security of hard-working Americans. #SaveYourSavings https:\/\/t.co\/i8TTmvcDew",
    "id" : 717753803152494592,
    "created_at" : "2016-04-06 16:40:16 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 717762528458227713,
  "created_at" : "2016-04-06 17:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 1, 7 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717760125101060096\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/iZEFk2EvD4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfX_AhGXIAIFggy.jpg",
      "id_str" : "717760099985596418",
      "id" : 717760099985596418,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfX_AhGXIAIFggy.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iZEFk2EvD4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/yTAmcnwGC0",
      "expanded_url" : "http:\/\/go.wh.gov\/WbPUhp",
      "display_url" : "go.wh.gov\/WbPUhp"
    } ]
  },
  "geo" : { },
  "id_str" : "717760125101060096",
  "text" : ".@USDOL's updated rule will ensure retirement advisers are working in your best interest \u2192 https:\/\/t.co\/yTAmcnwGC0 https:\/\/t.co\/iZEFk2EvD4",
  "id" : 717760125101060096,
  "created_at" : "2016-04-06 17:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 3, 13 ],
      "id_str" : "970207298",
      "id" : 970207298
    }, {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 33, 39 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveYourSavings",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717748276230008833",
  "text" : "RT @SenWarren: Great news: Today @USDOL is announcing a strong new conflict of interest rule so advisers put clients first. #SaveYourSavings",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Labor Department",
        "screen_name" : "USDOL",
        "indices" : [ 18, 24 ],
        "id_str" : "20179628",
        "id" : 20179628
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaveYourSavings",
        "indices" : [ 109, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717736954276745216",
    "text" : "Great news: Today @USDOL is announcing a strong new conflict of interest rule so advisers put clients first. #SaveYourSavings",
    "id" : 717736954276745216,
    "created_at" : "2016-04-06 15:33:19 +0000",
    "user" : {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "protected" : false,
      "id_str" : "970207298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722044174799777792\/bXaodRhx_normal.jpg",
      "id" : 970207298,
      "verified" : true
    }
  },
  "id" : 717748276230008833,
  "created_at" : "2016-04-06 16:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Donovan",
      "screen_name" : "ShaunOMB",
      "indices" : [ 3, 12 ],
      "id_str" : "2207588833",
      "id" : 2207588833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717744793829376000",
  "text" : "RT @ShaunOMB: Congress needs to act quickly on the emergency request for Zika to ensure we have funds to stay ahead of the disease https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/PBmnDH0hTU",
        "expanded_url" : "http:\/\/1.usa.gov\/1V9puJk",
        "display_url" : "1.usa.gov\/1V9puJk"
      } ]
    },
    "geo" : { },
    "id_str" : "717738774923313152",
    "text" : "Congress needs to act quickly on the emergency request for Zika to ensure we have funds to stay ahead of the disease https:\/\/t.co\/PBmnDH0hTU",
    "id" : 717738774923313152,
    "created_at" : "2016-04-06 15:40:33 +0000",
    "user" : {
      "name" : "Shaun Donovan",
      "screen_name" : "ShaunOMB",
      "protected" : false,
      "id_str" : "2207588833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000771300655\/430835535c9ab3f854683bc176cc0a65_normal.jpeg",
      "id" : 2207588833,
      "verified" : true
    }
  },
  "id" : 717744793829376000,
  "created_at" : "2016-04-06 16:04:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retirement",
      "indices" : [ 60, 71 ]
    }, {
      "text" : "SaveYourSavings",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5xdvlzYi0a",
      "expanded_url" : "http:\/\/www.dol.gov\/saveyoursavings",
      "display_url" : "dol.gov\/saveyoursavings"
    } ]
  },
  "geo" : { },
  "id_str" : "717726247158022144",
  "text" : "RT @USDOL: BREAKING: Today we\u2019ll publish a rule to increase #retirement protections and help you #SaveYourSavings. https:\/\/t.co\/5xdvlzYi0a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "retirement",
        "indices" : [ 49, 60 ]
      }, {
        "text" : "SaveYourSavings",
        "indices" : [ 86, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/5xdvlzYi0a",
        "expanded_url" : "http:\/\/www.dol.gov\/saveyoursavings",
        "display_url" : "dol.gov\/saveyoursavings"
      } ]
    },
    "geo" : { },
    "id_str" : "717653353405222912",
    "text" : "BREAKING: Today we\u2019ll publish a rule to increase #retirement protections and help you #SaveYourSavings. https:\/\/t.co\/5xdvlzYi0a",
    "id" : 717653353405222912,
    "created_at" : "2016-04-06 10:01:07 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 717726247158022144,
  "created_at" : "2016-04-06 14:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PublicHealthWeek",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/qNVi1MuRH2",
      "expanded_url" : "http:\/\/go.wh.gov\/C7XWRe",
      "display_url" : "go.wh.gov\/C7XWRe"
    } ]
  },
  "geo" : { },
  "id_str" : "717724651686912002",
  "text" : "RT @FactsOnClimate: Climate change can seriously impact your health. How to be prepared \u2192 https:\/\/t.co\/qNVi1MuRH2 #PublicHealthWeek https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/717724239210483716\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/ZHMUDwiZZg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfXeZFvUAAAu2LX.jpg",
        "id_str" : "717724238254178304",
        "id" : 717724238254178304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfXeZFvUAAAu2LX.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZHMUDwiZZg"
      } ],
      "hashtags" : [ {
        "text" : "PublicHealthWeek",
        "indices" : [ 94, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/qNVi1MuRH2",
        "expanded_url" : "http:\/\/go.wh.gov\/C7XWRe",
        "display_url" : "go.wh.gov\/C7XWRe"
      } ]
    },
    "geo" : { },
    "id_str" : "717724239210483716",
    "text" : "Climate change can seriously impact your health. How to be prepared \u2192 https:\/\/t.co\/qNVi1MuRH2 #PublicHealthWeek https:\/\/t.co\/ZHMUDwiZZg",
    "id" : 717724239210483716,
    "created_at" : "2016-04-06 14:42:47 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 717724651686912002,
  "created_at" : "2016-04-06 14:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaughtersandSons",
      "indices" : [ 62, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717524521687859201",
  "text" : "RT @vj44: The @WhiteHouse is inviting local youth to Take Our #DaughtersandSons to Work Day. Ask your employer to do the same! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DaughtersandSons",
        "indices" : [ 52, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1GblfUFhCt",
        "expanded_url" : "http:\/\/1.usa.gov\/1N50sn5",
        "display_url" : "1.usa.gov\/1N50sn5"
      } ]
    },
    "geo" : { },
    "id_str" : "717401966662524929",
    "text" : "The @WhiteHouse is inviting local youth to Take Our #DaughtersandSons to Work Day. Ask your employer to do the same! https:\/\/t.co\/1GblfUFhCt",
    "id" : 717401966662524929,
    "created_at" : "2016-04-05 17:22:12 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 717524521687859201,
  "created_at" : "2016-04-06 01:29:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 48, 59 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/717470644703666176\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oCRajAvKJf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfTxMt8UUAEyYUA.jpg",
      "id_str" : "717463441452060673",
      "id" : 717463441452060673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfTxMt8UUAEyYUA.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/oCRajAvKJf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/JtayLqShfh",
      "expanded_url" : "http:\/\/go.wh.gov\/DZrJbX",
      "display_url" : "go.wh.gov\/DZrJbX"
    } ]
  },
  "geo" : { },
  "id_str" : "717470644703666176",
  "text" : "Here's why you should care about new actions by @USTreasury to make our tax system fairer: https:\/\/t.co\/JtayLqShfh https:\/\/t.co\/oCRajAvKJf",
  "id" : 717470644703666176,
  "created_at" : "2016-04-05 21:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/JO8R1vVdwd",
      "expanded_url" : "http:\/\/snpy.tv\/1q3H2ti",
      "display_url" : "snpy.tv\/1q3H2ti"
    } ]
  },
  "geo" : { },
  "id_str" : "717463317128749056",
  "text" : "Today, @POTUS called on Congress to close wasteful loopholes that let the wealthy avoid paying their fair share. https:\/\/t.co\/JO8R1vVdwd",
  "id" : 717463317128749056,
  "created_at" : "2016-04-05 21:25:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717444795572981760",
  "text" : "RT @SCOTUSnom: GOP Senator after meeting Judge Garland: I'm \"more convinced than ever that the process should proceed\" \u2192 https:\/\/t.co\/spLzX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoYourJob",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/spLzXTf6tF",
        "expanded_url" : "http:\/\/wapo.st\/1PScT5g",
        "display_url" : "wapo.st\/1PScT5g"
      } ]
    },
    "geo" : { },
    "id_str" : "717441455980032000",
    "text" : "GOP Senator after meeting Judge Garland: I'm \"more convinced than ever that the process should proceed\" \u2192 https:\/\/t.co\/spLzXTf6tF #DoYourJob",
    "id" : 717441455980032000,
    "created_at" : "2016-04-05 19:59:07 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 717444795572981760,
  "created_at" : "2016-04-05 20:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JO8R1vDCEF",
      "expanded_url" : "http:\/\/snpy.tv\/1q3H2ti",
      "display_url" : "snpy.tv\/1q3H2ti"
    } ]
  },
  "geo" : { },
  "id_str" : "717396245795512325",
  "text" : "\"We should keep building an economy where everybody has a fair shot, and everybody plays by the same rules.\" \u2014@POTUS https:\/\/t.co\/JO8R1vDCEF",
  "id" : 717396245795512325,
  "created_at" : "2016-04-05 16:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/1yeF6gVwqT",
      "expanded_url" : "http:\/\/snpy.tv\/1UTlrl2",
      "display_url" : "snpy.tv\/1UTlrl2"
    } ]
  },
  "geo" : { },
  "id_str" : "717392881481154560",
  "text" : "Here's what we're doing to make sure big corporations are paying their fair share of taxes. https:\/\/t.co\/1yeF6gVwqT",
  "id" : 717392881481154560,
  "created_at" : "2016-04-05 16:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/1yeF6gVwqT",
      "expanded_url" : "http:\/\/snpy.tv\/1UTlrl2",
      "display_url" : "snpy.tv\/1UTlrl2"
    } ]
  },
  "geo" : { },
  "id_str" : "717390788846428160",
  "text" : "Corporate tax inversions \"sticks the rest of us with the tab.\" \nWatch @POTUS on new steps to prevent loopholes. https:\/\/t.co\/1yeF6gVwqT",
  "id" : 717390788846428160,
  "created_at" : "2016-04-05 16:37:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/717387278738264064\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/p8UU7dY0Qn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSrvYsWQAIX0ll.jpg",
      "id_str" : "717387071229411330",
      "id" : 717387071229411330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSrvYsWQAIX0ll.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/p8UU7dY0Qn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717387278738264064",
  "text" : "\"A lot of these loopholes come at the expense of middle class families.\" \u2014@POTUS on preventing corporate inversions https:\/\/t.co\/p8UU7dY0Qn",
  "id" : 717387278738264064,
  "created_at" : "2016-04-05 16:23:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 1, 12 ],
      "id_str" : "120176950",
      "id" : 120176950
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717386443044225024",
  "text" : "\"@USTreasury has taken new action to prevent more corporations from taking advantage of one of the most insidious tax loopholes\" \u2014@POTUS",
  "id" : 717386443044225024,
  "created_at" : "2016-04-05 16:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717385975136018434",
  "text" : "\"I\u2019ve been pushing for years to eliminate the injustices in our tax system.\" \u2014@POTUS on making our tax code fairer",
  "id" : 717385975136018434,
  "created_at" : "2016-04-05 16:18:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/adHQAdmECL",
      "expanded_url" : "http:\/\/go.wh.gov\/DZrJbX",
      "display_url" : "go.wh.gov\/DZrJbX"
    } ]
  },
  "geo" : { },
  "id_str" : "717385252377747456",
  "text" : "RT @WHLive: Happening now: Watch @POTUS deliver a statement on new steps to prevent corporate inversions \u2192 https:\/\/t.co\/adHQAdmECL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/adHQAdmECL",
        "expanded_url" : "http:\/\/go.wh.gov\/DZrJbX",
        "display_url" : "go.wh.gov\/DZrJbX"
      } ]
    },
    "geo" : { },
    "id_str" : "717385170538536960",
    "text" : "Happening now: Watch @POTUS deliver a statement on new steps to prevent corporate inversions \u2192 https:\/\/t.co\/adHQAdmECL",
    "id" : 717385170538536960,
    "created_at" : "2016-04-05 16:15:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 717385252377747456,
  "created_at" : "2016-04-05 16:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717375769425608705\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OL6LwBXiun",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSgxpWUIAAoEAq.jpg",
      "id_str" : "717375015432232960",
      "id" : 717375015432232960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSgxpWUIAAoEAq.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/OL6LwBXiun"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/JtayLqAGnJ",
      "expanded_url" : "http:\/\/go.wh.gov\/DZrJbX",
      "display_url" : "go.wh.gov\/DZrJbX"
    } ]
  },
  "geo" : { },
  "id_str" : "717375769425608705",
  "text" : "At 12:15pm ET, @POTUS delivers a statement on the new steps to prevent corporate inversions: https:\/\/t.co\/JtayLqAGnJ https:\/\/t.co\/OL6LwBXiun",
  "id" : 717375769425608705,
  "created_at" : "2016-04-05 15:38:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717123163419713538",
  "text" : "RT @repjohnlewis: 48 years ago, as I mourned the loss of Dr. King, I watched Sen. Kennedy pour out his heart and his soul to America. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/cuQPaDt4Je",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=j6mxL2cqxrA",
        "display_url" : "youtube.com\/watch?v=j6mxL2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717062220551741440",
    "text" : "48 years ago, as I mourned the loss of Dr. King, I watched Sen. Kennedy pour out his heart and his soul to America. https:\/\/t.co\/cuQPaDt4Je",
    "id" : 717062220551741440,
    "created_at" : "2016-04-04 18:52:10 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 717123163419713538,
  "created_at" : "2016-04-04 22:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717118705830862848\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/CALE62Yhgk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfO3qH9VIAA-oe5.jpg",
      "id_str" : "717118700000714752",
      "id" : 717118700000714752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfO3qH9VIAA-oe5.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CALE62Yhgk"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717118705830862848",
  "text" : "It's time for Congress to act to expand access to paid leave for all America's workers. #LeadOnLeave https:\/\/t.co\/CALE62Yhgk",
  "id" : 717118705830862848,
  "created_at" : "2016-04-04 22:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 11, 16 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/dMLwzPcbxj",
      "expanded_url" : "http:\/\/t.ted.com\/nohnelq",
      "display_url" : "t.ted.com\/nohnelq"
    } ]
  },
  "geo" : { },
  "id_str" : "717112945151377408",
  "text" : "Here's how @USDS is transforming the way government delivers services to Americans across the country: https:\/\/t.co\/dMLwzPcbxj",
  "id" : 717112945151377408,
  "created_at" : "2016-04-04 22:13:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/717096125312999424\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/DqJTIqTmA9",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfObH8tUkAAJ7Fm.jpg",
      "id_str" : "717087326539649024",
      "id" : 717087326539649024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfObH8tUkAAJ7Fm.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DqJTIqTmA9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/uN5R2KwBtP",
      "expanded_url" : "http:\/\/go.wh.gov\/pkfBzB",
      "display_url" : "go.wh.gov\/pkfBzB"
    } ]
  },
  "geo" : { },
  "id_str" : "717105268056842242",
  "text" : "It's time to #ActOnClimate. \n\nHere's what climate change means for your health &amp; family: https:\/\/t.co\/uN5R2KwBtP https:\/\/t.co\/DqJTIqTmA9",
  "id" : 717105268056842242,
  "created_at" : "2016-04-04 21:43:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 3, 12 ],
      "id_str" : "15492359",
      "id" : 15492359
    }, {
      "name" : "Haley van Dyck",
      "screen_name" : "haleyvandyck",
      "indices" : [ 102, 115 ],
      "id_str" : "15771056",
      "id" : 15771056
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TEDTalks\/status\/717042566722633728\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Tgkytwcdea",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNyainUYAAaViz.jpg",
      "id_str" : "717042565975924736",
      "id" : 717042565975924736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNyainUYAAaViz.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1620,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Tgkytwcdea"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/P970vdMguz",
      "expanded_url" : "http:\/\/t.ted.com\/nohnelq",
      "display_url" : "t.ted.com\/nohnelq"
    } ]
  },
  "geo" : { },
  "id_str" : "717095419185115140",
  "text" : "RT @TEDTalks: This tech team is saving government millions of dollars a year: https:\/\/t.co\/P970vdMguz @haleyvandyck https:\/\/t.co\/Tgkytwcdea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Haley van Dyck",
        "screen_name" : "haleyvandyck",
        "indices" : [ 88, 101 ],
        "id_str" : "15771056",
        "id" : 15771056
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TEDTalks\/status\/717042566722633728\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/Tgkytwcdea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNyainUYAAaViz.jpg",
        "id_str" : "717042565975924736",
        "id" : 717042565975924736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNyainUYAAaViz.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1620,
          "resize" : "fit",
          "w" : 2880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Tgkytwcdea"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/P970vdMguz",
        "expanded_url" : "http:\/\/t.ted.com\/nohnelq",
        "display_url" : "t.ted.com\/nohnelq"
      } ]
    },
    "geo" : { },
    "id_str" : "717042566722633728",
    "text" : "This tech team is saving government millions of dollars a year: https:\/\/t.co\/P970vdMguz @haleyvandyck https:\/\/t.co\/Tgkytwcdea",
    "id" : 717042566722633728,
    "created_at" : "2016-04-04 17:34:04 +0000",
    "user" : {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "protected" : false,
      "id_str" : "15492359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615531317489303552\/pWXT4Dol_normal.png",
      "id" : 15492359,
      "verified" : true
    }
  },
  "id" : 717095419185115140,
  "created_at" : "2016-04-04 21:04:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/oN8ZOXI2qP",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/04\/04\/fact-sheet-what-climate-change-means-your-health-and-family",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717092675674091521",
  "text" : "RT @Deese44: Just in: new report on what climate change means for your health &amp; why we must #ActOnClimate https:\/\/t.co\/oN8ZOXI2qP https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/717090542287327232\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/N0KCi5H1OX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOeDFrUYAA5DSJ.jpg",
        "id_str" : "717090541582704640",
        "id" : 717090541582704640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOeDFrUYAA5DSJ.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N0KCi5H1OX"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 83, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/oN8ZOXI2qP",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/04\/04\/fact-sheet-what-climate-change-means-your-health-and-family",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717090542287327232",
    "text" : "Just in: new report on what climate change means for your health &amp; why we must #ActOnClimate https:\/\/t.co\/oN8ZOXI2qP https:\/\/t.co\/N0KCi5H1OX",
    "id" : 717090542287327232,
    "created_at" : "2016-04-04 20:44:42 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 717092675674091521,
  "created_at" : "2016-04-04 20:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717089490087591936\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YO9FQNC0t5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOcM0GUEAAKIrF.jpg",
      "id_str" : "717088509639528448",
      "id" : 717088509639528448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOcM0GUEAAKIrF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YO9FQNC0t5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/f4tZvJK31D",
      "expanded_url" : "http:\/\/go.wh.gov\/r6jG2K",
      "display_url" : "go.wh.gov\/r6jG2K"
    } ]
  },
  "geo" : { },
  "id_str" : "717089490087591936",
  "text" : "\"Workers will no longer be earning a wage that keeps too many families in poverty.\" \u2014@POTUS: https:\/\/t.co\/f4tZvJK31D https:\/\/t.co\/YO9FQNC0t5",
  "id" : 717089490087591936,
  "created_at" : "2016-04-04 20:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 55, 67 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717082452645117952",
  "text" : "RT @SCOTUSnom: This Thursday, @POTUS will head back to @UChicagoLaw where he taught constitutional law. Here's why. #SCOTUS https:\/\/t.co\/6l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "UChicago Law School",
        "screen_name" : "UChicagoLaw",
        "indices" : [ 40, 52 ],
        "id_str" : "14869449",
        "id" : 14869449
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/6lfuBhPJrX",
        "expanded_url" : "http:\/\/snpy.tv\/1RJ7gss",
        "display_url" : "snpy.tv\/1RJ7gss"
      } ]
    },
    "geo" : { },
    "id_str" : "717057789370114048",
    "text" : "This Thursday, @POTUS will head back to @UChicagoLaw where he taught constitutional law. Here's why. #SCOTUS https:\/\/t.co\/6lfuBhPJrX",
    "id" : 717057789370114048,
    "created_at" : "2016-04-04 18:34:33 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 717082452645117952,
  "created_at" : "2016-04-04 20:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717071110706102272",
  "text" : "RT @FactsOnClimate: Warmer temperatures are projected to lead to earlier annual onset of Lyme disease cases. Get the facts \u2192 https:\/\/t.co\/h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/h6gqMCqAIu",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/04\/04\/fact-sheet-what-climate-change-means-your-health-and-family",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717065269013655552",
    "text" : "Warmer temperatures are projected to lead to earlier annual onset of Lyme disease cases. Get the facts \u2192 https:\/\/t.co\/h6gqMCqAIu",
    "id" : 717065269013655552,
    "created_at" : "2016-04-04 19:04:17 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 717071110706102272,
  "created_at" : "2016-04-04 19:27:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717069070093320192\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/81LUpJ4D8C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOKAaVVAAA4zFO.jpg",
      "id_str" : "717068505355452416",
      "id" : 717068505355452416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOKAaVVAAA4zFO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/81LUpJ4D8C"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/uN5R2Kf05f",
      "expanded_url" : "http:\/\/go.wh.gov\/pkfBzB",
      "display_url" : "go.wh.gov\/pkfBzB"
    } ]
  },
  "geo" : { },
  "id_str" : "717069070093320192",
  "text" : "Every person is vulnerable to health impacts of climate change. Get the facts: https:\/\/t.co\/uN5R2Kf05f #ActOnClimate https:\/\/t.co\/81LUpJ4D8C",
  "id" : 717069070093320192,
  "created_at" : "2016-04-04 19:19:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "globalchange.gov",
      "screen_name" : "usgcrp",
      "indices" : [ 39, 46 ],
      "id_str" : "495300028",
      "id" : 495300028
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 57, 71 ]
    }, {
      "text" : "NCAhealth",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/WpXVp5ffFX",
      "expanded_url" : "https:\/\/health2016.globalchange.gov\/",
      "display_url" : "health2016.globalchange.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "717067783033344000",
  "text" : "RT @NASA: Our scientists contribute to @USGCRP report on #ClimateChange &amp; US health impact https:\/\/t.co\/WpXVp5ffFX #NCAhealth https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "globalchange.gov",
        "screen_name" : "usgcrp",
        "indices" : [ 29, 36 ],
        "id_str" : "495300028",
        "id" : 495300028
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/717033671425916929\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/oDHS4tJvrE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNqUwKWsAAeKAN.jpg",
        "id_str" : "717033670440300544",
        "id" : 717033670440300544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNqUwKWsAAeKAN.jpg",
        "sizes" : [ {
          "h" : 567,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oDHS4tJvrE"
      } ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 47, 61 ]
      }, {
        "text" : "NCAhealth",
        "indices" : [ 109, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/WpXVp5ffFX",
        "expanded_url" : "https:\/\/health2016.globalchange.gov\/",
        "display_url" : "health2016.globalchange.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "717033671425916929",
    "text" : "Our scientists contribute to @USGCRP report on #ClimateChange &amp; US health impact https:\/\/t.co\/WpXVp5ffFX #NCAhealth https:\/\/t.co\/oDHS4tJvrE",
    "id" : 717033671425916929,
    "created_at" : "2016-04-04 16:58:43 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 717067783033344000,
  "created_at" : "2016-04-04 19:14:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 26, 37 ],
      "id_str" : "232268199",
      "id" : 232268199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717066252527624192",
  "text" : "RT @vj44: Congratulations @NYGovCuomo on passing paid leave in New York \u2013 a huge step forward in supporting working families https:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Cuomo",
        "screen_name" : "NYGovCuomo",
        "indices" : [ 16, 27 ],
        "id_str" : "232268199",
        "id" : 232268199
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/DU4c2PaYna",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/04\/04\/email-valerie-jarrett-important-step-forward-working-families",
        "display_url" : "whitehouse.gov\/blog\/2016\/04\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717058492645969920",
    "text" : "Congratulations @NYGovCuomo on passing paid leave in New York \u2013 a huge step forward in supporting working families https:\/\/t.co\/DU4c2PaYna",
    "id" : 717058492645969920,
    "created_at" : "2016-04-04 18:37:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 717066252527624192,
  "created_at" : "2016-04-04 19:08:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717063349247184896\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/qKVxkRw8OT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOFI1hWIAAehkR.jpg",
      "id_str" : "717063152534429696",
      "id" : 717063152534429696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOFI1hWIAAehkR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qKVxkRw8OT"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717063349247184896",
  "text" : "New York just took the #LeadOnLeave. Now it's time for Congress to do the same for every worker in America. https:\/\/t.co\/qKVxkRw8OT",
  "id" : 717063349247184896,
  "created_at" : "2016-04-04 18:56:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/717036475397890048\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0ogayndTNk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNskqDWEAE6Elg.jpg",
      "id_str" : "717036142701449217",
      "id" : 717036142701449217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNskqDWEAE6Elg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0ogayndTNk"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ihEnU1JopM",
      "expanded_url" : "http:\/\/go.wh.gov\/55LC1M",
      "display_url" : "go.wh.gov\/55LC1M"
    } ]
  },
  "geo" : { },
  "id_str" : "717036475397890048",
  "text" : "#LeadOnLeave \u2713\n#RaiseTheWage \u2713\n\nNew York just took a historic step for working families: https:\/\/t.co\/ihEnU1JopM https:\/\/t.co\/0ogayndTNk",
  "id" : 717036475397890048,
  "created_at" : "2016-04-04 17:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 3, 14 ],
      "id_str" : "232268199",
      "id" : 232268199
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717032651941666816",
  "text" : "RT @NYGovCuomo: Thank you @POTUS for your unrelenting commitment to family leave. As NY goes, so do we hope goes the nation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "717026378739290112",
    "geo" : { },
    "id_str" : "717026762387886080",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Thank you @POTUS for your unrelenting commitment to family leave. As NY goes, so do we hope goes the nation.",
    "id" : 717026762387886080,
    "in_reply_to_status_id" : 717026378739290112,
    "created_at" : "2016-04-04 16:31:16 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "protected" : false,
      "id_str" : "232268199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788019377870348288\/83Xj5Zh3_normal.jpg",
      "id" : 232268199,
      "verified" : true
    }
  },
  "id" : 717032651941666816,
  "created_at" : "2016-04-04 16:54:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 107, 118 ],
      "id_str" : "232268199",
      "id" : 232268199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717026541746712576",
  "text" : "RT @POTUS: Nobody should have to choose between losing a paycheck &amp; caring for their family. I applaud @NYGovCuomo for taking a big step on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Cuomo",
        "screen_name" : "NYGovCuomo",
        "indices" : [ 96, 107 ],
        "id_str" : "232268199",
        "id" : 232268199
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717026378739290112",
    "text" : "Nobody should have to choose between losing a paycheck &amp; caring for their family. I applaud @NYGovCuomo for taking a big step on paid leave.",
    "id" : 717026378739290112,
    "created_at" : "2016-04-04 16:29:45 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 717026541746712576,
  "created_at" : "2016-04-04 16:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717018786830880768",
  "text" : "RT @repjohnlewis: 48 yrs ago today, my friend, my brother, Dr. Martin Luther King, Jr. was shot and killed in Memphis, TN. The light of his\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717004180829954048",
    "text" : "48 yrs ago today, my friend, my brother, Dr. Martin Luther King, Jr. was shot and killed in Memphis, TN. The light of his life still shines.",
    "id" : 717004180829954048,
    "created_at" : "2016-04-04 15:01:32 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 717018786830880768,
  "created_at" : "2016-04-04 15:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 35, 45 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "NSS 2016",
      "screen_name" : "NSS2016",
      "indices" : [ 92, 100 ],
      "id_str" : "710514912607531008",
      "id" : 710514912607531008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/DEhBRflukg",
      "expanded_url" : "https:\/\/www.instagram.com\/whitehouse\/",
      "display_url" : "instagram.com\/whitehouse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "717008325024428032",
  "text" : "RT @NSC44: Check out @WhiteHouse\u2019s @Instagram for behind-the-scenes photos from last week\u2019s @NSS2016 \u2192 https:\/\/t.co\/DEhBRflukg https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 24, 34 ],
        "id_str" : "180505807",
        "id" : 180505807
      }, {
        "name" : "NSS 2016",
        "screen_name" : "NSS2016",
        "indices" : [ 81, 89 ],
        "id_str" : "710514912607531008",
        "id" : 710514912607531008
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/717004990863294464\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/wnFaLi1elC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNQNc2UkAArj8x.jpg",
        "id_str" : "717004957694595072",
        "id" : 717004957694595072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNQNc2UkAArj8x.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/wnFaLi1elC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/DEhBRflukg",
        "expanded_url" : "https:\/\/www.instagram.com\/whitehouse\/",
        "display_url" : "instagram.com\/whitehouse\/"
      } ]
    },
    "geo" : { },
    "id_str" : "717004990863294464",
    "text" : "Check out @WhiteHouse\u2019s @Instagram for behind-the-scenes photos from last week\u2019s @NSS2016 \u2192 https:\/\/t.co\/DEhBRflukg https:\/\/t.co\/wnFaLi1elC",
    "id" : 717004990863294464,
    "created_at" : "2016-04-04 15:04:45 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 717008325024428032,
  "created_at" : "2016-04-04 15:18:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeningDay",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/HFDdJ7NJVI",
      "expanded_url" : "http:\/\/go.wh.gov\/5mXhgP",
      "display_url" : "go.wh.gov\/5mXhgP"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9WRIijSiEm",
      "expanded_url" : "http:\/\/snpy.tv\/1S6Zet0",
      "display_url" : "snpy.tv\/1S6Zet0"
    } ]
  },
  "geo" : { },
  "id_str" : "716722900192112640",
  "text" : "\"Today is #OpeningDay\u2014a day that brings back a lot of memories of my father Jackie Robinson\" https:\/\/t.co\/HFDdJ7NJVI https:\/\/t.co\/9WRIijSiEm",
  "id" : 716722900192112640,
  "created_at" : "2016-04-03 20:23:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecurity",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Gh0tbI4inU",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716708630024708097",
  "text" : "\"More of the world\u2019s nuclear material is secure. It\u2019s harder for terrorists to get at it.\" \u2014@POTUS #NuclearSecurity https:\/\/t.co\/Gh0tbI4inU",
  "id" : 716708630024708097,
  "created_at" : "2016-04-03 19:27:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Gh0tbI4inU",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716693528416399360",
  "text" : "\"We\u2019re going to keep doing everything in our power to keep our nation safe and strong and free.\" \u2014@POTUS: https:\/\/t.co\/Gh0tbI4inU",
  "id" : 716693528416399360,
  "created_at" : "2016-04-03 18:27:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Gh0tbI4inU",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716678176974327812",
  "text" : "\"During our summit, we focused on ways to step up our efforts to disrupt terrorist attacks.\" \u2014@POTUS: https:\/\/t.co\/Gh0tbI4inU",
  "id" : 716678176974327812,
  "created_at" : "2016-04-03 17:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Gh0tbIlTMu",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716663218576433152",
  "text" : "\"Our coalition continues to take out its leaders, including those planning terrorist attacks.\" \u2014@POTUS on ISIL: https:\/\/t.co\/Gh0tbIlTMu",
  "id" : 716663218576433152,
  "created_at" : "2016-04-03 16:26:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/SRPnGzC9dM",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    }, {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mvzL7hzR6O",
      "expanded_url" : "https:\/\/twitter.com\/marchmadness\/status\/716379907001954304",
      "display_url" : "twitter.com\/marchmadness\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716402460638756865",
  "text" : "RT @VPLive: Join the @VP by taking the #ItsOnUs pledge: https:\/\/t.co\/SRPnGzC9dM https:\/\/t.co\/mvzL7hzR6O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 9, 12 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 27, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/SRPnGzC9dM",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      }, {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/mvzL7hzR6O",
        "expanded_url" : "https:\/\/twitter.com\/marchmadness\/status\/716379907001954304",
        "display_url" : "twitter.com\/marchmadness\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716383407228469248",
    "text" : "Join the @VP by taking the #ItsOnUs pledge: https:\/\/t.co\/SRPnGzC9dM https:\/\/t.co\/mvzL7hzR6O",
    "id" : 716383407228469248,
    "created_at" : "2016-04-02 21:54:48 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 716402460638756865,
  "created_at" : "2016-04-02 23:10:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Gh0tbI4inU",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716325586033979393",
  "text" : "\"In Syria and Iraq, ISIL continues to lose ground. Our coalition continues to take out its leaders\" \u2014@POTUS: https:\/\/t.co\/Gh0tbI4inU",
  "id" : 716325586033979393,
  "created_at" : "2016-04-02 18:05:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Gh0tbI4inU",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716310230477352960",
  "text" : "\"We pledged...to prevent the world\u2019s most deadly networks from obtaining the world\u2019s most deadly weapons.\" \u2014@POTUS: https:\/\/t.co\/Gh0tbI4inU",
  "id" : 716310230477352960,
  "created_at" : "2016-04-02 17:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Gh0tbI4inU",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716295131033243648",
  "text" : "\"Working with other nations, we have removed or secured enough nuclear material for more than 150 nuclear weapons.\" https:\/\/t.co\/Gh0tbI4inU",
  "id" : 716295131033243648,
  "created_at" : "2016-04-02 16:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Gh0tbIlTMu",
      "expanded_url" : "http:\/\/go.wh.gov\/uBtd5C",
      "display_url" : "go.wh.gov\/uBtd5C"
    } ]
  },
  "geo" : { },
  "id_str" : "716279976505565184",
  "text" : "\"We\u2019ve been leading a global effort to secure the world\u2019s nuclear materials.\" \u2014@POTUS: https:\/\/t.co\/Gh0tbIlTMu",
  "id" : 716279976505565184,
  "created_at" : "2016-04-02 15:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/716046265528651776\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/eVYrYQJKw5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_ashiUkAA0vd7.jpg",
      "id_str" : "716031324226621440",
      "id" : 716031324226621440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_ashiUkAA0vd7.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eVYrYQJKw5"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/wOaqhTlWjQ",
      "expanded_url" : "http:\/\/go.wh.gov\/MarchJobs",
      "display_url" : "go.wh.gov\/MarchJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "716046265528651776",
  "text" : "Since 2007, women\u2019s weekly earnings have grown at a faster pace than men's: https:\/\/t.co\/wOaqhTlWjQ #EqualPay https:\/\/t.co\/eVYrYQJKw5",
  "id" : 716046265528651776,
  "created_at" : "2016-04-01 23:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/716034567258382337\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/84q6rIPrnZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_dZw7UUAAuoBD.jpg",
      "id_str" : "716034300475363328",
      "id" : 716034300475363328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_dZw7UUAAuoBD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/84q6rIPrnZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/xEvDVbpDI6",
      "expanded_url" : "http:\/\/go.wh.gov\/RWkQQi",
      "display_url" : "go.wh.gov\/RWkQQi"
    } ]
  },
  "geo" : { },
  "id_str" : "716034567258382337",
  "text" : "Our textiles industry used to be a poster child for job loss\u2014now it's making a comeback: https:\/\/t.co\/xEvDVbpDI6 https:\/\/t.co\/84q6rIPrnZ",
  "id" : 716034567258382337,
  "created_at" : "2016-04-01 22:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecurity",
      "indices" : [ 58, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/QyBNjAvu7G",
      "expanded_url" : "http:\/\/go.wh.gov\/sFUjVG",
      "display_url" : "go.wh.gov\/sFUjVG"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/fDU0niiIVo",
      "expanded_url" : "http:\/\/snpy.tv\/1St4V4G",
      "display_url" : "snpy.tv\/1St4V4G"
    } ]
  },
  "geo" : { },
  "id_str" : "716028784697278466",
  "text" : "Watch @POTUS discuss the important progress we've made on #NuclearSecurity: https:\/\/t.co\/QyBNjAvu7G  https:\/\/t.co\/fDU0niiIVo",
  "id" : 716028784697278466,
  "created_at" : "2016-04-01 22:25:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NSS2016",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716028011926130689",
  "text" : "RT @NSC44: \"Together, we've removed the world's most deadly materials from nuclear facilities around the world\"-@POTUS #NSS2016\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 101, 107 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NSS2016",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/K84ahNVXd5",
        "expanded_url" : "http:\/\/snpy.tv\/1PLtRCg",
        "display_url" : "snpy.tv\/1PLtRCg"
      } ]
    },
    "geo" : { },
    "id_str" : "716027728579854336",
    "text" : "\"Together, we've removed the world's most deadly materials from nuclear facilities around the world\"-@POTUS #NSS2016\nhttps:\/\/t.co\/K84ahNVXd5",
    "id" : 716027728579854336,
    "created_at" : "2016-04-01 22:21:28 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 716028011926130689,
  "created_at" : "2016-04-01 22:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/716025553787162624\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ohxrEwE1gc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_VSidVAAE_i-P.jpg",
      "id_str" : "716025380239376385",
      "id" : 716025380239376385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_VSidVAAE_i-P.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/ohxrEwE1gc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716025553787162624",
  "text" : "\"More than 50 nations...have taken concrete steps to enhance security at their nuclear facilities\" \u2014@POTUS https:\/\/t.co\/ohxrEwE1gc",
  "id" : 716025553787162624,
  "created_at" : "2016-04-01 22:12:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 105, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/QyBNjAvu7G",
      "expanded_url" : "http:\/\/go.wh.gov\/sFUjVG",
      "display_url" : "go.wh.gov\/sFUjVG"
    } ]
  },
  "geo" : { },
  "id_str" : "716025306818158594",
  "text" : "\"We\u2019ve eliminated some 138 tons of our surplus highly enriched uranium\" \u2014@POTUS: https:\/\/t.co\/QyBNjAvu7G #NuclearSecuritySummit",
  "id" : 716025306818158594,
  "created_at" : "2016-04-01 22:11:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716024790004408321",
  "text" : "\u201CTogether, we\u2019ve removed the world\u2019s most deadly materials from nuclear facilities around the world.\u201D \u2014@POTUS at the #NuclearSecuritySummit",
  "id" : 716024790004408321,
  "created_at" : "2016-04-01 22:09:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 69, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/QyBNjAvu7G",
      "expanded_url" : "http:\/\/go.wh.gov\/sFUjVG",
      "display_url" : "go.wh.gov\/sFUjVG"
    } ]
  },
  "geo" : { },
  "id_str" : "716017999862505472",
  "text" : "Tune in at 5:45pm ET as @POTUS holds a press conference to close the #NuclearSecuritySummit: https:\/\/t.co\/QyBNjAvu7G",
  "id" : 716017999862505472,
  "created_at" : "2016-04-01 21:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cameron",
      "screen_name" : "David_Cameron",
      "indices" : [ 62, 76 ],
      "id_str" : "103065157",
      "id" : 103065157
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 93, 103 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecurity",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/7qx3q9VkJn",
      "expanded_url" : "http:\/\/snpy.tv\/22WnglB",
      "display_url" : "snpy.tv\/22WnglB"
    } ]
  },
  "geo" : { },
  "id_str" : "716009120654958592",
  "text" : "\"Presidents &amp; prime ministers can learn from each other\" \u2014@David_Cameron\nWatch him &amp; @FHollande on #NuclearSecurity: https:\/\/t.co\/7qx3q9VkJn",
  "id" : 716009120654958592,
  "created_at" : "2016-04-01 21:07:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/8nwrPM7FJx",
      "expanded_url" : "http:\/\/snpy.tv\/22Wh64K",
      "display_url" : "snpy.tv\/22Wh64K"
    } ]
  },
  "geo" : { },
  "id_str" : "715998148334850048",
  "text" : "\"Our people do share common aspirations: to live in security and peace, and to be free from fear.\" \u2014@POTUS https:\/\/t.co\/8nwrPM7FJx",
  "id" : 715998148334850048,
  "created_at" : "2016-04-01 20:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715994660443963394",
  "text" : "\"We have to do even more to prevent the flow of foreign terrorist fighters...we all have a role to play\" \u2014@POTUS to global leaders",
  "id" : 715994660443963394,
  "created_at" : "2016-04-01 20:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/715991114013130752\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/gazYS16NKj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce-2GQOW8AAQmvO.jpg",
      "id_str" : "715991084325859328",
      "id" : 715991084325859328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce-2GQOW8AAQmvO.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gazYS16NKj"
    } ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 59, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Aq2W0mrTKk",
      "expanded_url" : "http:\/\/go.wh.gov\/Bt61cw",
      "display_url" : "go.wh.gov\/Bt61cw"
    } ]
  },
  "geo" : { },
  "id_str" : "715991114013130752",
  "text" : "Happening now: @POTUS speaks at the closing session of the #NuclearSecuritySummit: https:\/\/t.co\/Aq2W0mrTKk https:\/\/t.co\/gazYS16NKj",
  "id" : 715991114013130752,
  "created_at" : "2016-04-01 19:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 16, 30 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715986479714009090",
  "text" : "RT @Denis44: PM @leehsienloong's interview shows how world looks 2 U.S. 4 leadership. We must pass TPP 2 write global trade rules https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lee Hsien Loong",
        "screen_name" : "leehsienloong",
        "indices" : [ 3, 17 ],
        "id_str" : "34568673",
        "id" : 34568673
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/MIVjdxK6BM",
        "expanded_url" : "http:\/\/on.wsj.com\/1M4jGOJ",
        "display_url" : "on.wsj.com\/1M4jGOJ"
      } ]
    },
    "geo" : { },
    "id_str" : "715982715930148864",
    "text" : "PM @leehsienloong's interview shows how world looks 2 U.S. 4 leadership. We must pass TPP 2 write global trade rules https:\/\/t.co\/MIVjdxK6BM",
    "id" : 715982715930148864,
    "created_at" : "2016-04-01 19:22:36 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 715986479714009090,
  "created_at" : "2016-04-01 19:37:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecurity",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/VhmOze1P5M",
      "expanded_url" : "http:\/\/snpy.tv\/25AQFR7",
      "display_url" : "snpy.tv\/25AQFR7"
    } ]
  },
  "geo" : { },
  "id_str" : "715969438739136512",
  "text" : "\"We cannot be complacent. We have to build on our progress.\" \u2014@POTUS to global leaders on #NuclearSecurity: https:\/\/t.co\/VhmOze1P5M",
  "id" : 715969438739136512,
  "created_at" : "2016-04-01 18:29:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/715952101306851330\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/A2VmMGTS5I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce-SbZpWAAA30ff.jpg",
      "id_str" : "715951865213616128",
      "id" : 715951865213616128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce-SbZpWAAA30ff.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/A2VmMGTS5I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wOaqhT4lsi",
      "expanded_url" : "http:\/\/go.wh.gov\/MarchJobs",
      "display_url" : "go.wh.gov\/MarchJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "715952101306851330",
  "text" : "FACT: American businesses have added 14.4 million jobs over 73 straight months of growth \u2192 https:\/\/t.co\/wOaqhT4lsi https:\/\/t.co\/A2VmMGTS5I",
  "id" : 715952101306851330,
  "created_at" : "2016-04-01 17:20:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715922426463436801",
  "text" : "\"Working together, our nations have made it harder for terrorists to get their hands on nuclear material.\" \u2014@POTUS #NuclearSecuritySummit",
  "id" : 715922426463436801,
  "created_at" : "2016-04-01 15:23:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715922036120494080",
  "text" : "\"102 nations have now ratified a key treaty\u2014the Convention on the Physical Protection of Nuclear Material.\" \u2014@POTUS #NuclearSecuritySummit",
  "id" : 715922036120494080,
  "created_at" : "2016-04-01 15:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 87, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/steUN0Bmft",
      "expanded_url" : "http:\/\/go.wh.gov\/FEvFJn",
      "display_url" : "go.wh.gov\/FEvFJn"
    } ]
  },
  "geo" : { },
  "id_str" : "715921684763701249",
  "text" : "\"We\u2019ve made significant progress.\" \u2014@POTUS alongside more than 50 world leaders at the #NuclearSecuritySummit: https:\/\/t.co\/steUN0Bmft",
  "id" : 715921684763701249,
  "created_at" : "2016-04-01 15:20:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 110, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715921351341694977",
  "text" : "\u201COur nations committed ourselves to action\u2026steps to secure the world\u2019s vulnerable nuclear materials.\u201D \u2014@POTUS #NuclearSecuritySummit",
  "id" : 715921351341694977,
  "created_at" : "2016-04-01 15:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuclearSecuritySummit",
      "indices" : [ 43, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/steUN0Bmft",
      "expanded_url" : "http:\/\/go.wh.gov\/FEvFJn",
      "display_url" : "go.wh.gov\/FEvFJn"
    } ]
  },
  "geo" : { },
  "id_str" : "715920992359608320",
  "text" : "Happening now: @POTUS gives remarks at the #NuclearSecuritySummit \u2192 https:\/\/t.co\/steUN0Bmft",
  "id" : 715920992359608320,
  "created_at" : "2016-04-01 15:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/715919115181883392\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/tTk7x19Gdl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce90N4cUkAAUn9k.jpg",
      "id_str" : "715918647613493248",
      "id" : 715918647613493248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce90N4cUkAAUn9k.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/tTk7x19Gdl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/wOaqhTlWjQ",
      "expanded_url" : "http:\/\/go.wh.gov\/MarchJobs",
      "display_url" : "go.wh.gov\/MarchJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "715919115181883392",
  "text" : "Here's what the longest streak of private-sector job growth on record looks like \u2192 https:\/\/t.co\/wOaqhTlWjQ https:\/\/t.co\/tTk7x19Gdl",
  "id" : 715919115181883392,
  "created_at" : "2016-04-01 15:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715910483212169216",
  "text" : "RT @CEAChair: Since 2007 women\u2019s usual weekly earnings have risen faster than men\u2019s, narrowing pay gap, but more work remains. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/715895696088571904\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/JEkEubfN0E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce9fV4lUsAAkpE9.png",
        "id_str" : "715895695346020352",
        "id" : 715895695346020352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce9fV4lUsAAkpE9.png",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 823,
          "resize" : "fit",
          "w" : 1133
        } ],
        "display_url" : "pic.twitter.com\/JEkEubfN0E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715895696088571904",
    "text" : "Since 2007 women\u2019s usual weekly earnings have risen faster than men\u2019s, narrowing pay gap, but more work remains. https:\/\/t.co\/JEkEubfN0E",
    "id" : 715895696088571904,
    "created_at" : "2016-04-01 13:36:49 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 715910483212169216,
  "created_at" : "2016-04-01 14:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/715905159780544512\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/nRxsG9qsNW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce9novGWAAABX6_.jpg",
      "id_str" : "715904815310700544",
      "id" : 715904815310700544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce9novGWAAABX6_.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/nRxsG9qsNW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wOaqhT4lsi",
      "expanded_url" : "http:\/\/go.wh.gov\/MarchJobs",
      "display_url" : "go.wh.gov\/MarchJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "715905159780544512",
  "text" : "Our businesses have added 14.4 million jobs over the past 73 months\u2014the longest streak ever: https:\/\/t.co\/wOaqhT4lsi https:\/\/t.co\/nRxsG9qsNW",
  "id" : 715905159780544512,
  "created_at" : "2016-04-01 14:14:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UChicago Law School",
      "screen_name" : "UChicagoLaw",
      "indices" : [ 72, 84 ],
      "id_str" : "14869449",
      "id" : 14869449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715875835383775232",
  "text" : "RT @SCOTUSnom: BREAKING: Next Thursday, Professor @POTUS will return to @UChicagoLaw to discuss the #SCOTUS nomination process \u2192 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 35, 41 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "UChicago Law School",
        "screen_name" : "UChicagoLaw",
        "indices" : [ 57, 69 ],
        "id_str" : "14869449",
        "id" : 14869449
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fTBGOe8CTQ",
        "expanded_url" : "http:\/\/bit.ly\/1UHr05W",
        "display_url" : "bit.ly\/1UHr05W"
      } ]
    },
    "geo" : { },
    "id_str" : "715875131080347648",
    "text" : "BREAKING: Next Thursday, Professor @POTUS will return to @UChicagoLaw to discuss the #SCOTUS nomination process \u2192 https:\/\/t.co\/fTBGOe8CTQ",
    "id" : 715875131080347648,
    "created_at" : "2016-04-01 12:15:06 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 715875835383775232,
  "created_at" : "2016-04-01 12:17:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]