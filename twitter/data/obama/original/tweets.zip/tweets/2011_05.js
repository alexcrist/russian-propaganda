Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75681937947242496",
  "text" : "The President in #Joplin: \"An example of what the American spirit is all about\" http:\/\/wh.gov\/CLN Pic: http:\/\/twitpic.com\/5571ub",
  "id" : 75681937947242496,
  "created_at" : "2011-05-31 21:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 62, 74 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75677573836840960",
  "text" : "President Obama nominates John Bryson to be our nation\u2019s next @CommerceGov Secretary: http:\/\/wh.gov\/CeH",
  "id" : 75677573836840960,
  "created_at" : "2011-05-31 21:38:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75611256039550977",
  "text" : "Starting: President Obama Announces Intent to Nominate John Bryson as U.S. Department of Commerce Secretary. Watch live: http:\/\/wh.gov\/live",
  "id" : 75611256039550977,
  "created_at" : "2011-05-31 17:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75583052679614465",
  "text" : "RT @pfeiffer44: President Obama will make a personnel announcement in the Rose Garden at 1:15 PM today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75576193964969985",
    "text" : "President Obama will make a personnel announcement in the Rose Garden at 1:15 PM today",
    "id" : 75576193964969985,
    "created_at" : "2011-05-31 14:55:43 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 75583052679614465,
  "created_at" : "2011-05-31 15:22:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75406214783172609",
  "text" : "\"Honor their sacrifice\" -President Obama on #MemorialDay http:\/\/www.wh.gov\/CMO",
  "id" : 75406214783172609,
  "created_at" : "2011-05-31 03:40:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75380151302627328",
  "text" : "Deadline tonight: Nominate an everyday hero for the Presidential Citizens Medal by 11:59 PM ET. Full criteria: http:\/\/wh.gov\/Ccq",
  "id" : 75380151302627328,
  "created_at" : "2011-05-31 01:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/zCUj31e",
      "expanded_url" : "http:\/\/yfrog.com\/h213931168j",
      "display_url" : "yfrog.com\/h213931168j"
    } ]
  },
  "geo" : { },
  "id_str" : "75336334264373248",
  "text" : "Photo: President Obama places a wreath at the Tomb of the Unknown Soldier at Arlington Nat'l Cemetery http:\/\/t.co\/zCUj31e",
  "id" : 75336334264373248,
  "created_at" : "2011-05-30 23:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75271496783757312",
  "text" : "\"That\u2019s what we memorialize today. That spirit that says, send me, no matter the mission\" -Obama @ Arlington: http:\/\/wh.gov\/CMq",
  "id" : 75271496783757312,
  "created_at" : "2011-05-30 18:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75267546898640896",
  "text" : "RT @JoiningForces: This #MemorialDay, honor those who have served & sacrificed so much by supporting our military families: http:\/\/wh.go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDay",
        "indices" : [ 5, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75266366520836096",
    "text" : "This #MemorialDay, honor those who have served & sacrificed so much by supporting our military families: http:\/\/wh.gov\/CMi",
    "id" : 75266366520836096,
    "created_at" : "2011-05-30 18:24:34 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 75267546898640896,
  "created_at" : "2011-05-30 18:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74897972554502144",
  "text" : "Who inspires you through service? Last chance to nominate someone you know for the 2011 Citizens Medal: http:\/\/wh.gov\/lFj",
  "id" : 74897972554502144,
  "created_at" : "2011-05-29 18:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74875593170223106",
  "text" : "President Obama heads to #Joplin to visit w\/ those who lost so much in the deadly, historic tornadoes & speak at a memorial service.",
  "id" : 74875593170223106,
  "created_at" : "2011-05-29 16:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrysler",
      "screen_name" : "Chrysler",
      "indices" : [ 61, 70 ],
      "id_str" : "119159695",
      "id" : 119159695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74503116803940352",
  "text" : "Weekly Address: VP Biden on the American auto comeback after @Chrysler pays back loans: http:\/\/1.usa.gov\/j1maf7",
  "id" : 74503116803940352,
  "created_at" : "2011-05-28 15:51:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74161122453880833",
  "text" : "RT @DeptVetAffairs: A powerful Memorial Day piece by @AlexHortonVA: http:\/\/go.usa.gov\/Dg6",
  "id" : 74161122453880833,
  "created_at" : "2011-05-27 17:12:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrysler",
      "screen_name" : "Chrysler",
      "indices" : [ 31, 40 ],
      "id_str" : "119159695",
      "id" : 119159695
    }, {
      "name" : "USTreasuryDept",
      "screen_name" : "USTreasuryDept",
      "indices" : [ 57, 72 ],
      "id_str" : "2484739350",
      "id" : 2484739350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74144523088957440",
  "text" : "Big week for US auto industry: @Chrysler repaid loans to @USTreasuryDept 6yrs early, over $10B back to taxpayers http:\/\/wh.gov\/CHE",
  "id" : 74144523088957440,
  "created_at" : "2011-05-27 16:06:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74107105400991744",
  "text" : "Your West Wing Week: President Obama travels to Europe in \"A Homecoming of Sorts\" Video: http:\/\/bit.ly\/jx1Eld",
  "id" : 74107105400991744,
  "created_at" : "2011-05-27 13:38:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73895184110338048",
  "text" : "President Obama meets with G-8 leaders in Deauville, France. See the day in photos: http:\/\/wh.gov\/CHx",
  "id" : 73895184110338048,
  "created_at" : "2011-05-26 23:35:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73808899718914048",
  "text" : "5 days left to submit a nomination for the Citizens Medal, recognizing Americans committed to service: http:\/\/wh.gov\/lFj",
  "id" : 73808899718914048,
  "created_at" : "2011-05-26 17:53:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 80, 84 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73779551758589953",
  "text" : "A 21st century regulatory system that's simpler, smarter & more cost-effective. @wsj op-ed: http:\/\/on.wsj.com\/lNvxpI",
  "id" : 73779551758589953,
  "created_at" : "2011-05-26 15:56:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Parliament",
      "screen_name" : "UKParliament",
      "indices" : [ 54, 67 ],
      "id_str" : "6467332",
      "id" : 6467332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73482922023333888",
  "text" : "\"The time for our leadership is now\" -President Obama @UKParliament in London: http:\/\/wh.gov\/C7B",
  "id" : 73482922023333888,
  "created_at" : "2011-05-25 20:17:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73411684965953538",
  "text" : "New fuel economy labels empower car buyers w\/ better information on what they'll spend or save on fuel costs: http:\/\/wh.gov\/CGO",
  "id" : 73411684965953538,
  "created_at" : "2011-05-25 15:34:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72780143105540096",
  "text" : "RT @jesseclee44: Great shot of crowd in Dublin looking for Obama\u2019s missing apostrophe, courtesy of WH photog Lawrence Jackson  http:\/\/tw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72776842070855680",
    "text" : "Great shot of crowd in Dublin looking for Obama\u2019s missing apostrophe, courtesy of WH photog Lawrence Jackson  http:\/\/twitpic.com\/51nk44",
    "id" : 72776842070855680,
    "created_at" : "2011-05-23 21:32:05 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 72780143105540096,
  "created_at" : "2011-05-23 21:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72762483403792384",
  "text" : "Who inspires you through service? Just 1 week left to nominate someone you know for the President's Citizens Medal: http:\/\/wh.gov\/lFj",
  "id" : 72762483403792384,
  "created_at" : "2011-05-23 20:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72700218910580736",
  "text" : "RT @OzarksRedCross: Shelter is open: Campus of MO SO State Univ. at the Legget and Platt Athletic Center - 3950 Newman Rd Joplin, Mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72522446573543424",
    "text" : "Shelter is open: Campus of MO SO State Univ. at the Legget and Platt Athletic Center - 3950 Newman Rd Joplin, Mo",
    "id" : 72522446573543424,
    "created_at" : "2011-05-23 04:41:13 +0000",
    "user" : {
      "name" : "SOMO Red Cross",
      "screen_name" : "SOMORedCross",
      "protected" : false,
      "id_str" : "15623301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684780896742805505\/g-N_xELn_normal.jpg",
      "id" : 15623301,
      "verified" : false
    }
  },
  "id" : 72700218910580736,
  "created_at" : "2011-05-23 16:27:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72699827741392896",
  "text" : "12:30EDT: President Obama speaks at an Irish Celebration in Dublin, watch live: http:\/\/wh.gov\/live",
  "id" : 72699827741392896,
  "created_at" : "2011-05-23 16:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dwd",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72697607578857473",
  "text" : "RT @RayLaHood: \u201CNo one expected I would live\u201D  Survivor talks of distracted driving crash that killed her parents #dwd http:\/\/bit.ly\/k9f1it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dwd",
        "indices" : [ 99, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "72694653715091456",
    "text" : "\u201CNo one expected I would live\u201D  Survivor talks of distracted driving crash that killed her parents #dwd http:\/\/bit.ly\/k9f1it",
    "id" : 72694653715091456,
    "created_at" : "2011-05-23 16:05:30 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 72697607578857473,
  "created_at" : "2011-05-23 16:17:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72677126553341952",
  "text" : "Deepest Condolences for Missouri and the Midwest: President Obama calls MO Gov, read his statement: http:\/\/wh.gov\/CVL",
  "id" : 72677126553341952,
  "created_at" : "2011-05-23 14:55:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71651931071844352",
  "text" : "Now: President Obama thanks the CIA & intelligence community for their work. Watch: http:\/\/wh.gov\/live",
  "id" : 71651931071844352,
  "created_at" : "2011-05-20 19:02:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71586235436634112",
  "text" : "Brand new West Wing Week: \"The Commencement at Booker T\" http:\/\/is.gd\/DgEpnt",
  "id" : 71586235436634112,
  "created_at" : "2011-05-20 14:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71386257476960256",
  "text" : "RT @TIME: Obama's team wants Twitter to know they're listening | http:\/\/ti.me\/mPO37Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71384657479999489",
    "text" : "Obama's team wants Twitter to know they're listening | http:\/\/ti.me\/mPO37Y",
    "id" : 71384657479999489,
    "created_at" : "2011-05-20 01:20:03 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 71386257476960256,
  "created_at" : "2011-05-20 01:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71295612842295296",
  "text" : "Obama\u2019s Council on Jobs & Competitiveness on why we need a 21st century #immigration policy: http:\/\/reut.rs\/lmo1IU",
  "id" : 71295612842295296,
  "created_at" : "2011-05-19 19:26:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71277944328294401",
  "text" : "President Obama's full remarks: \"A Moment of Opportunity\" in the Middle East & North Africa http:\/\/wh.gov\/CPw #MEspeech",
  "id" : 71277944328294401,
  "created_at" : "2011-05-19 18:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 38, 46 ],
      "id_str" : "778057",
      "id" : 778057
    }, {
      "name" : "Marc Lynch",
      "screen_name" : "abuaardvark",
      "indices" : [ 66, 78 ],
      "id_str" : "18267544",
      "id" : 18267544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71259248188862464",
  "text" : "Stick around for a live chat w\/ NPR's @acarvin & Foreign Policy's @abuaardvark: http:\/\/wh.gov\/live Ask Qs using #MEspeech",
  "id" : 71259248188862464,
  "created_at" : "2011-05-19 17:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71256178092548096",
  "text" : "Obama on Israel\/Palestine: \u201Ccasting off the burdens of the past, the drive for a lasting peace\u2026is more urgent than ever\u201D #MEspeech",
  "id" : 71256178092548096,
  "created_at" : "2011-05-19 16:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71255281111285760",
  "text" : "Obama:\u201Csupport positive change in the region...through our efforts to advance economic development for nations that transition to democracy\u201D",
  "id" : 71255281111285760,
  "created_at" : "2011-05-19 16:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71253834885898240",
  "text" : "Obama: \u201CWhat we will oppose is an attempt by any group to restrict the rights of others\u2026minorities\u2026religion\u2026women\u201D #MEspeech",
  "id" : 71253834885898240,
  "created_at" : "2011-05-19 16:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71253476520361984",
  "text" : "Obama:\u201CWe will support open access to the Internet & the right of journalists to be heard\u2026big news organization or a lone blogger\u201D #MEspeech",
  "id" : 71253476520361984,
  "created_at" : "2011-05-19 16:38:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71252445522690048",
  "text" : "Obama: \u201Cour friends in the region have not all reacted to the demands for change\u2026 w\/ the principles that I have outlined\u2026Yemen\u2026Bahrain\u201D",
  "id" : 71252445522690048,
  "created_at" : "2011-05-19 16:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71252077464129536",
  "text" : "Obama: \u201Chypocrisy of the Iranian regime\u2026says it stands for the rights of protesters abroad yet represses its own people at home\u201D #MEspeech",
  "id" : 71252077464129536,
  "created_at" : "2011-05-19 16:33:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71251816138018816",
  "text" : "Obama: \u201CThe Syrian people have shown their courage in demanding\u2026democracy. President Assad\u2026can lead that transition, or get out of the way\u201D",
  "id" : 71251816138018816,
  "created_at" : "2011-05-19 16:32:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71251618779242497",
  "text" : "Obama: \u201Ctime is working against Gaddafi. He does not have control\u2026The opposition is organizing a legitimate and credible Interim Council\u201D",
  "id" : 71251618779242497,
  "created_at" : "2011-05-19 16:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71251114691002368",
  "text" : "Obama: \u201Cit will be the policy of the US to promote reform across the region & to support transitions to democracy\u201D #MEspeech",
  "id" : 71251114691002368,
  "created_at" : "2011-05-19 16:29:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71250642785677313",
  "text" : "Obama: \u201Chumility\u2026it\u2019s not America that put people into the streets of Tunis and Cairo \u2013 it was the people themselves\u201D #MEspeech",
  "id" : 71250642785677313,
  "created_at" : "2011-05-19 16:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71250486644310016",
  "text" : "Obama: We will \u201Cshow that America values the dignity of the street vendor in Tunisia more than the raw power of the dictator\u201D #MEspeech",
  "id" : 71250486644310016,
  "created_at" : "2011-05-19 16:26:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71249980790292480",
  "text" : "Obama: \"the moral force of non-violence the people of the region have achieved more change in 6 months than terrorists have...in decades\"",
  "id" : 71249980790292480,
  "created_at" : "2011-05-19 16:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71249300012802048",
  "text" : "Obama: \u201CCell phones & social networks allow young people to connect and organize like never before\u2026a new generation has emerged\u201D #MEspeech",
  "id" : 71249300012802048,
  "created_at" : "2011-05-19 16:22:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71248489023156224",
  "text" : "Obama: \u201CThere are times\u2026the actions of ordinary citizens spark movements for change because they speak to a longing for freedom\u201D #MEspeech",
  "id" : 71248489023156224,
  "created_at" : "2011-05-19 16:18:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71248073870934018",
  "text" : "Obama on bin Laden: \u201Che rejected democracy\u2026even before his death, al Qaeda was losing its struggle for relevance\u201D #MEspeech",
  "id" : 71248073870934018,
  "created_at" : "2011-05-19 16:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71237967544451073",
  "text" : "Soon: President Obama Speaks on the Middle East & North Africa, US Policy in the Region. Watch: http:\/\/wh.gov\/live #MEspeech",
  "id" : 71237967544451073,
  "created_at" : "2011-05-19 15:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EDF Texas",
      "screen_name" : "EDFtx",
      "indices" : [ 3, 9 ],
      "id_str" : "22542765",
      "id" : 22542765
    }, {
      "name" : "Brewster McCracken",
      "screen_name" : "bmccracken",
      "indices" : [ 27, 38 ],
      "id_str" : "19278242",
      "id" : 19278242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71233913313431552",
  "text" : "RT @EDFtx: Cool news about @bmccracken of @pecanstproject going to the @whitehouse with other TX #SmarGrid folks to talk shop: http:\/\/co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brewster McCracken",
        "screen_name" : "bmccracken",
        "indices" : [ 16, 27 ],
        "id_str" : "19278242",
        "id" : 19278242
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 60, 71 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmarGrid",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "71233076629475328",
    "text" : "Cool news about @bmccracken of @pecanstproject going to the @whitehouse with other TX #SmarGrid folks to talk shop: http:\/\/cot.ag\/iP85bx",
    "id" : 71233076629475328,
    "created_at" : "2011-05-19 15:17:43 +0000",
    "user" : {
      "name" : "EDF Texas",
      "screen_name" : "EDFtx",
      "protected" : false,
      "id_str" : "22542765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463350238728556544\/aJHv_1yh_normal.png",
      "id" : 22542765,
      "verified" : false
    }
  },
  "id" : 71233913313431552,
  "created_at" : "2011-05-19 15:21:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71205785354518528",
  "text" : "11:40EDT: The President speaks on the Middle East & North Africa, U.S. policy in region. Watch: http:\/\/wh.gov\/live #MEspeech",
  "id" : 71205785354518528,
  "created_at" : "2011-05-19 13:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "U.S. Coast Guard",
      "screen_name" : "uscoastguard",
      "indices" : [ 42, 55 ],
      "id_str" : "17409240",
      "id" : 17409240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70981725760651264",
  "text" : "RT @JoiningForces: President Obama speaks @uscoastguard Academy Commencement: http:\/\/wh.gov\/CUn Photo:  http:\/\/twitpic.com\/4zem5l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Coast Guard",
        "screen_name" : "uscoastguard",
        "indices" : [ 23, 36 ],
        "id_str" : "17409240",
        "id" : 17409240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70967641128435712",
    "text" : "President Obama speaks @uscoastguard Academy Commencement: http:\/\/wh.gov\/CUn Photo:  http:\/\/twitpic.com\/4zem5l",
    "id" : 70967641128435712,
    "created_at" : "2011-05-18 21:42:58 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 70981725760651264,
  "created_at" : "2011-05-18 22:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 1, 8 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70974646454992897",
  "text" : ".@Energy & @ESAGov on the need for energy independence & what the Administration is doing about it http:\/\/go.usa.gov\/jEe http:\/\/is.gd\/3F7s6u",
  "id" : 70974646454992897,
  "created_at" : "2011-05-18 22:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70964476953899008",
  "text" : "RT @twitter: The world feels so much smaller when you can participate in a live event right from your couch. Here's one: http:\/\/t.co\/6L3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MEspeech",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 127 ],
        "url" : "http:\/\/t.co\/6L3GLPo",
        "expanded_url" : "http:\/\/n.pr\/kVl9nC",
        "display_url" : "n.pr\/kVl9nC"
      } ]
    },
    "geo" : { },
    "id_str" : "70943739882913792",
    "text" : "The world feels so much smaller when you can participate in a live event right from your couch. Here's one: http:\/\/t.co\/6L3GLPo #MEspeech",
    "id" : 70943739882913792,
    "created_at" : "2011-05-18 20:08:00 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767879603977191425\/29zfZY6I_normal.jpg",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 70964476953899008,
  "created_at" : "2011-05-18 21:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 3, 11 ],
      "id_str" : "778057",
      "id" : 778057
    }, {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 29, 37 ],
      "id_str" : "778057",
      "id" : 778057
    }, {
      "name" : "Marc Lynch",
      "screen_name" : "abuaardvark",
      "indices" : [ 55, 67 ],
      "id_str" : "18267544",
      "id" : 18267544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEspeech",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70914069858750464",
  "text" : "RT @acarvin: Please join me (@acarvin) and Marc Lynch (@abuaardvark) Thursday for a tweet chat during Obama's #MEspeech: http:\/\/n.pr\/kVl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Carvin",
        "screen_name" : "acarvin",
        "indices" : [ 16, 24 ],
        "id_str" : "778057",
        "id" : 778057
      }, {
        "name" : "Marc Lynch",
        "screen_name" : "abuaardvark",
        "indices" : [ 42, 54 ],
        "id_str" : "18267544",
        "id" : 18267544
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MEspeech",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70909209314734080",
    "text" : "Please join me (@acarvin) and Marc Lynch (@abuaardvark) Thursday for a tweet chat during Obama's #MEspeech: http:\/\/n.pr\/kVl9nC Pls RT",
    "id" : 70909209314734080,
    "created_at" : "2011-05-18 17:50:47 +0000",
    "user" : {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "protected" : false,
      "id_str" : "778057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795623889372057600\/lYoWIKW1_normal.jpg",
      "id" : 778057,
      "verified" : true
    }
  },
  "id" : 70914069858750464,
  "created_at" : "2011-05-18 18:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70844925058621442",
  "text" : "On tap: 11:30EDT the President gives commencement speech at US Coast Guard Academy, watch: http:\/\/wh.gov\/live",
  "id" : 70844925058621442,
  "created_at" : "2011-05-18 13:35:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 51, 58 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70611873652936704",
  "text" : "6:30EDT: Young Entrepreneur Summit (YES) in NYC w\/ @SBAgov & Kalpen Modi. Watch\/discuss via Facebook http:\/\/bit.ly\/tCHXt",
  "id" : 70611873652936704,
  "created_at" : "2011-05-17 22:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70574333327712257",
  "text" : "The Truth About #HCR Waivers: Protecting Coverage for Millions of Americans http:\/\/wh.gov\/CnD",
  "id" : 70574333327712257,
  "created_at" : "2011-05-17 19:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70552759727955969",
  "text" : "Ahead of the Jewish American Heritage Month Event, the Maccabeats perform here at the WH at 2:15. Watch: http:\/\/wh.gov\/live",
  "id" : 70552759727955969,
  "created_at" : "2011-05-17 18:14:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 59, 66 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70516902669197312",
  "text" : "6:30EDT Tonight: Young Entrepreneur Summit (YES) in NYC w\/ @SBAgov & Kalpen Modi. Watch\/chat via Facebook http:\/\/bit.ly\/tCHXt",
  "id" : 70516902669197312,
  "created_at" : "2011-05-17 15:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A C Wharton, Jr",
      "screen_name" : "MayorACWharton",
      "indices" : [ 28, 43 ],
      "id_str" : "16193455",
      "id" : 16193455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70240025132011520",
  "text" : "Photo: President listens to @MayorACWharton at meeting w\/ officials & families affected by floods in Memphis  http:\/\/twitpic.com\/4ylh0u",
  "id" : 70240025132011520,
  "created_at" : "2011-05-16 21:31:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70181289227075584",
  "text" : "Obama: \"Yes, you\u2019ve always been underdogs...that also means that whatever you accomplish in your lives, you\u2019ll have earned it.\"",
  "id" : 70181289227075584,
  "created_at" : "2011-05-16 17:38:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70179812500717568",
  "text" : "Obama: \u201C\u2026it helps you imagine what it would be like to walk in somebody else\u2019s shoes, to know their struggles\u201D",
  "id" : 70179812500717568,
  "created_at" : "2011-05-16 17:32:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70179784650526722",
  "text" : "Obama: \u201Cwith the right education, both at home and at school, you can learn how to be a better human being\u2026.\u201D",
  "id" : 70179784650526722,
  "created_at" : "2011-05-16 17:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70179032347586560",
  "text" : "Obama: \"I\u2019m so blessed that [my family] kept pushing...my teachers kept pushing.  Because education made all the difference in my life.\"",
  "id" : 70179032347586560,
  "created_at" : "2011-05-16 17:29:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70177687527899137",
  "text" : "Obama: \"some people say that schools like BTW just aren\u2019t supposed to succeed \u2026every single one of you stood up and said, 'Yes we can.'\"",
  "id" : 70177687527899137,
  "created_at" : "2011-05-16 17:23:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70175810509742080",
  "text" : "Now: Obama\u2019s commencement address at Booker T. Washington HS, Commencement Challenge winner. Watch: http:\/\/wh.gov\/live",
  "id" : 70175810509742080,
  "created_at" : "2011-05-16 17:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70123741698461697",
  "text" : "RT @NASA: See today's launch of Space Shuttle Endeavour: http:\/\/go.nasa.gov\/iqRlP8 [VIDEO]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "70117310509236225",
    "text" : "See today's launch of Space Shuttle Endeavour: http:\/\/go.nasa.gov\/iqRlP8 [VIDEO]",
    "id" : 70117310509236225,
    "created_at" : "2011-05-16 13:24:04 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 70123741698461697,
  "created_at" : "2011-05-16 13:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70123162016292864",
  "text" : "President Obama asks for your nominations for the Citizens Medal for exemplary deeds of service http:\/\/wh.gov\/C5o",
  "id" : 70123162016292864,
  "created_at" : "2011-05-16 13:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70117561030803456",
  "text" : "On tap: President in Memphis, meets w\/ families hurt by flooding & volunteers, Commence Challenge Address at Booker T Wash HS",
  "id" : 70117561030803456,
  "created_at" : "2011-05-16 13:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 1, 11 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69151213320552448",
  "text" : ".@petesouza rolls out new behind-the-scenes photos from April and discusses a couple of his favorites: http:\/\/wh.gov\/CI6",
  "id" : 69151213320552448,
  "created_at" : "2011-05-13 21:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69060895686410240",
  "text" : "Fresh West Wing Week: \"On the Border\" http:\/\/wh.gov\/CXB  #immigration",
  "id" : 69060895686410240,
  "created_at" : "2011-05-13 15:26:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69060629155164162",
  "text" : "RT @CFPB: How are we going to design a single, simpler mortgage disclosure form? We explain, on the blog: http:\/\/go.usa.gov\/jgR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69054559313596416",
    "text" : "How are we going to design a single, simpler mortgage disclosure form? We explain, on the blog: http:\/\/go.usa.gov\/jgR",
    "id" : 69054559313596416,
    "created_at" : "2011-05-13 15:01:04 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 69060629155164162,
  "created_at" : "2011-05-13 15:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68720702806704128",
  "text" : "RT @pfeiffer44: POTUS has asked Congress to allow FBI Director Robert Mueller to stay 2 years past his 10 year term \/\/ http:\/\/wh.gov\/C9N",
  "id" : 68720702806704128,
  "created_at" : "2011-05-12 16:54:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68669014951469056",
  "text" : "On tap: National Hispanic Prayer Breakfast; Meet w\/ Senate GOP; Honor TOP COPS; Meet with CBC",
  "id" : 68669014951469056,
  "created_at" : "2011-05-12 13:29:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee Mann",
      "screen_name" : "aimeemann",
      "indices" : [ 67, 77 ],
      "id_str" : "21193261",
      "id" : 21193261
    }, {
      "name" : "Steve Martin",
      "screen_name" : "SteveMartinToGo",
      "indices" : [ 78, 94 ],
      "id_str" : "14824849",
      "id" : 14824849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68453513470021632",
  "text" : "Happening Now: An Evening of Poetry feat. Billy Collins, Rita Dove @aimeemann @SteveMartinToGo & more http:\/\/www.wh.gov\/live",
  "id" : 68453513470021632,
  "created_at" : "2011-05-11 23:12:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68426154821951488",
  "text" : "More statements of support for President Obama\u2019s commitment to fix our broken #immigration system: http:\/\/wh.gov\/C0s",
  "id" : 68426154821951488,
  "created_at" : "2011-05-11 21:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68398731476738048",
  "text" : "Thanks for all the Qs on #immigration reform: http:\/\/twitpic.com\/4wcs2x Keep the convo going here & more ways to join: http:\/\/wh.gov\/3Ay",
  "id" : 68398731476738048,
  "created_at" : "2011-05-11 19:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AVANCE",
      "screen_name" : "AVANCEinc",
      "indices" : [ 1, 11 ],
      "id_str" : "36380516",
      "id" : 36380516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68390561127731201",
  "geo" : { },
  "id_str" : "68392973016113152",
  "in_reply_to_user_id" : 36380516,
  "text" : ".@AVANCEinc: Great Q! We need a debate on what will be most effective in fixing what's broken. Border enforcement alone won't do it.",
  "id" : 68392973016113152,
  "in_reply_to_status_id" : 68390561127731201,
  "created_at" : "2011-05-11 19:12:10 +0000",
  "in_reply_to_screen_name" : "AVANCEinc",
  "in_reply_to_user_id_str" : "36380516",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hispanic Nashville",
      "screen_name" : "muybna",
      "indices" : [ 1, 8 ],
      "id_str" : "21084028",
      "id" : 21084028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68390619294343168",
  "geo" : { },
  "id_str" : "68392304867684353",
  "in_reply_to_user_id" : 21084028,
  "text" : ".@muybna: Can't deport 10 million people, so this is a 1-time opening to pay taxes & fine, learn English, get on the right side of the law.",
  "id" : 68392304867684353,
  "in_reply_to_status_id" : 68390619294343168,
  "created_at" : "2011-05-11 19:09:30 +0000",
  "in_reply_to_screen_name" : "muybna",
  "in_reply_to_user_id_str" : "21084028",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Waseem Chachar",
      "screen_name" : "wchachar",
      "indices" : [ 1, 10 ],
      "id_str" : "275991356",
      "id" : 275991356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 12, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68370622102773760",
  "geo" : { },
  "id_str" : "68391289728679936",
  "in_reply_to_user_id" : 275991356,
  "text" : ".@wchachar: #immigration reforms have always been bipartisan, public officials need to fix what's broken. This fight is not a waste of time.",
  "id" : 68391289728679936,
  "in_reply_to_status_id" : 68370622102773760,
  "created_at" : "2011-05-11 19:05:28 +0000",
  "in_reply_to_screen_name" : "wchachar",
  "in_reply_to_user_id_str" : "275991356",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_ron",
      "screen_name" : "RonArevalo",
      "indices" : [ 1, 12 ],
      "id_str" : "76703201",
      "id" : 76703201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68370231634051073",
  "geo" : { },
  "id_str" : "68390317082165248",
  "in_reply_to_user_id" : 76703201,
  "text" : ".@RonArevalo: Hopefully as soon as possible, but this is up to Congress. That's why Prez is engaging business, faith & other new partners.",
  "id" : 68390317082165248,
  "in_reply_to_status_id" : 68370231634051073,
  "created_at" : "2011-05-11 19:01:36 +0000",
  "in_reply_to_screen_name" : "RonArevalo",
  "in_reply_to_user_id_str" : "76703201",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omar Jorge",
      "screen_name" : "omarjorge",
      "indices" : [ 1, 11 ],
      "id_str" : "18443860",
      "id" : 18443860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68376404202504192",
  "geo" : { },
  "id_str" : "68389313762705408",
  "in_reply_to_user_id" : 18443860,
  "text" : ".@omarjorge: In a democracy the Prez can't just bypass Congress even when he disagrees with the policy. So we need to elevate the debate.",
  "id" : 68389313762705408,
  "in_reply_to_status_id" : 68376404202504192,
  "created_at" : "2011-05-11 18:57:37 +0000",
  "in_reply_to_screen_name" : "omarjorge",
  "in_reply_to_user_id_str" : "18443860",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Sarsour",
      "screen_name" : "lsarsour",
      "indices" : [ 1, 10 ],
      "id_str" : "27187343",
      "id" : 27187343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68387157554888704",
  "geo" : { },
  "id_str" : "68388464420335616",
  "in_reply_to_user_id" : 27187343,
  "text" : ".@lsarsour: we did what was asked on the border, published a policy blueprint: http:\/\/wh.gov\/CkP, engaging new voices to elevate the debate",
  "id" : 68388464420335616,
  "in_reply_to_status_id" : 68387157554888704,
  "created_at" : "2011-05-11 18:54:15 +0000",
  "in_reply_to_screen_name" : "lsarsour",
  "in_reply_to_user_id_str" : "27187343",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68387462652764160",
  "text" : ".@GnosticRose: We do! This DHS has a strategy, measuring results, making adjustments to maximize impact. http:\/\/1.usa.gov\/ilmLIV",
  "id" : 68387462652764160,
  "created_at" : "2011-05-11 18:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus",
      "screen_name" : "RoojC",
      "indices" : [ 1, 7 ],
      "id_str" : "17539599",
      "id" : 17539599
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMAct",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68371046448902144",
  "geo" : { },
  "id_str" : "68386401279938560",
  "in_reply_to_user_id" : 17539599,
  "text" : ".@RoojC We gave the #DREAMAct full support in Dec. and that will continue. DREAM was reintroduced today!",
  "id" : 68386401279938560,
  "in_reply_to_status_id" : 68371046448902144,
  "created_at" : "2011-05-11 18:46:03 +0000",
  "in_reply_to_screen_name" : "RoojC",
  "in_reply_to_user_id_str" : "17539599",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 45, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68385660351942656",
  "text" : "Happening now: Cecilia Munoz, top advisor on #immigration policy, is here responding to your questions. Keep them coming.",
  "id" : 68385660351942656,
  "created_at" : "2011-05-11 18:43:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 31, 43 ]
    }, {
      "text" : "immigration",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68369189664067584",
  "text" : "2:30 ET: Cecilia Munoz, senior #immigration policy advisor, is taking your questions. Send q's on #immigration reform our way.",
  "id" : 68369189664067584,
  "created_at" : "2011-05-11 17:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68331316604698624",
  "text" : "Join the conversation on how we can fix our #immigration system for America's 21st century economy: http:\/\/wh.gov\/C0y",
  "id" : 68331316604698624,
  "created_at" : "2011-05-11 15:07:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 35, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68087453268979712",
  "text" : "The President on fixing our broken #immigration system: E Pluribus, Unum. Remarks: http:\/\/wh.gov\/CkM http:\/\/twitpic.com\/4w1anv",
  "id" : 68087453268979712,
  "created_at" : "2011-05-10 22:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 25, 37 ]
    }, {
      "text" : "DreamAct",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68041696562253824",
  "text" : "RT @pfeiffer44: POTUS in #immigration reform speech: We Must Pass the #DreamAct",
  "id" : 68041696562253824,
  "created_at" : "2011-05-10 19:56:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68037217813147648",
  "text" : "RT @pfeiffer44: POTUS: #immigration reform is an \"economic imperative\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 7, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "68036093542539264",
    "text" : "POTUS: #immigration reform is an \"economic imperative\"",
    "id" : 68036093542539264,
    "created_at" : "2011-05-10 19:34:03 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 68037217813147648,
  "created_at" : "2011-05-10 19:38:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68033591141089280",
  "text" : "Now: President Obama speaking on creating a 21st century #immigration system, watch: http:\/\/wh.gov\/live",
  "id" : 68033591141089280,
  "created_at" : "2011-05-10 19:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68033290048774146",
  "text" : "Just Released: The President\u2019s Blueprint for Building a 21st Century #Immigration System: http:\/\/wh.gov\/CkP",
  "id" : 68033290048774146,
  "created_at" : "2011-05-10 19:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 12, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68031122503766016",
  "text" : "Just before #immigration speech, Obama touring a cargo inspection facility at Bridge of the Americas Port of Entry, El Paso.",
  "id" : 68031122503766016,
  "created_at" : "2011-05-10 19:14:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felipe Matos",
      "screen_name" : "fmatos007",
      "indices" : [ 40, 50 ],
      "id_str" : "82619991",
      "id" : 82619991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68028340090576897",
  "geo" : { },
  "id_str" : "68028719066914816",
  "in_reply_to_user_id" : 82619991,
  "text" : "Live in 25 mins @ http:\/\/WH.gov\/live RT @fmatos007: how can I watch the president's speech about #immigration?",
  "id" : 68028719066914816,
  "in_reply_to_status_id" : 68028340090576897,
  "created_at" : "2011-05-10 19:04:45 +0000",
  "in_reply_to_screen_name" : "fmatos007",
  "in_reply_to_user_id_str" : "82619991",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "immigration",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68023013580357633",
  "text" : "Obama speaks on fixing the broken #immigration system at 3:30 ET. Use #immigration to discuss now, during & after.",
  "id" : 68023013580357633,
  "created_at" : "2011-05-10 18:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67993302351355904",
  "text" : "Congrats to Booker T. Washington HS in Memphis for winning Commencement Challenge. Watch their video: http:\/\/wh.gov\/aMp",
  "id" : 67993302351355904,
  "created_at" : "2011-05-10 16:44:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RealPro",
      "screen_name" : "RealPro4Real",
      "indices" : [ 48, 61 ],
      "id_str" : "191005840",
      "id" : 191005840
    }, {
      "name" : "Will Ehrenfeld",
      "screen_name" : "WillEhrenfeld",
      "indices" : [ 62, 76 ],
      "id_str" : "21681127",
      "id" : 21681127
    }, {
      "name" : "Rosa Alvarez",
      "screen_name" : "RosaATX",
      "indices" : [ 77, 85 ],
      "id_str" : "222592731",
      "id" : 222592731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67983463764078592",
  "text" : "Join the conversation on #immigration reform w\/ @RealPro4Real @WillEhrenfeld @RosaATX & lots more. We're listening.",
  "id" : 67983463764078592,
  "created_at" : "2011-05-10 16:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 3, 7 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "localalerts",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67971800688111617",
  "text" : "RT @FCC: Genachowski on PLAN and #localalerts : \"new tech and service makes mobile devices into emergency alert devices\" http:\/\/fcc.us\/i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "localalerts",
        "indices" : [ 24, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67970951576420353",
    "text" : "Genachowski on PLAN and #localalerts : \"new tech and service makes mobile devices into emergency alert devices\" http:\/\/fcc.us\/iicMQA",
    "id" : 67970951576420353,
    "created_at" : "2011-05-10 15:15:12 +0000",
    "user" : {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "protected" : false,
      "id_str" : "66369206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303190571\/twitter_fcc_icon_normal.png",
      "id" : 66369206,
      "verified" : true
    }
  },
  "id" : 67971800688111617,
  "created_at" : "2011-05-10 15:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67963422138044416",
  "text" : "Get involved in a dialogue on immigration: use #immigration here, Advise the Advisor, host a roundtable: http:\/\/wh.gov\/CkW",
  "id" : 67963422138044416,
  "created_at" : "2011-05-10 14:45:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67949185583955968",
  "text" : "Photo of the Day: First Lady Michelle Obama in Pit Crew Challenge at WH fitness event on South Lawn  http:\/\/twitpic.com\/4vvqzy",
  "id" : 67949185583955968,
  "created_at" : "2011-05-10 13:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67943596225073152",
  "text" : "3:30 ET: The President speaks on fixing the broken immigration system in El Paso. Use #immigration to discuss now, during & after.",
  "id" : 67943596225073152,
  "created_at" : "2011-05-10 13:26:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Longoria Baston",
      "screen_name" : "EvaLongoria",
      "indices" : [ 25, 37 ],
      "id_str" : "110827653",
      "id" : 110827653
    }, {
      "name" : "Arnold",
      "screen_name" : "Schwarzenegger",
      "indices" : [ 43, 58 ],
      "id_str" : "12044602",
      "id" : 12044602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67693654243938304",
  "text" : "In case you missed it -- @EvaLongoria, Gov @Schwarzenegger & more on #immigration reform. Videos: http:\/\/bit.ly\/jnRS15",
  "id" : 67693654243938304,
  "created_at" : "2011-05-09 20:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "rail",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "hsr",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67627621554454528",
  "text" : "RT @RayLaHood: Latest awards bring US closer to Pres #Obama's vision of national high-speed #rail network. #hsr http:\/\/bit.ly\/lgmvCu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 38, 44 ]
      }, {
        "text" : "rail",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "hsr",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "67603229571166208",
    "text" : "Latest awards bring US closer to Pres #Obama's vision of national high-speed #rail network. #hsr http:\/\/bit.ly\/lgmvCu",
    "id" : 67603229571166208,
    "created_at" : "2011-05-09 14:54:00 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 67627621554454528,
  "created_at" : "2011-05-09 16:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67621579781177344",
  "text" : "Tomorrow, President Obama will discuss immigration reform in El Paso, Texas. Use #immigration to discuss now, during & after.",
  "id" : 67621579781177344,
  "created_at" : "2011-05-09 16:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS News",
      "screen_name" : "theearlyshow",
      "indices" : [ 3, 16 ],
      "id_str" : "419117523",
      "id" : 419117523
    }, {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 30, 38 ],
      "id_str" : "15012486",
      "id" : 15012486
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 92, 104 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67598161593630720",
  "text" : "RT @theearlyshow: This Thurs, @CBSNews will conduct a special town hall on the economy with @BarackObama. Have a Q? Tweet them with the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBS News",
        "screen_name" : "CBSNews",
        "indices" : [ 12, 20 ],
        "id_str" : "15012486",
        "id" : 15012486
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 74, 86 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CBSTownHall",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66522301700653056",
    "text" : "This Thurs, @CBSNews will conduct a special town hall on the economy with @BarackObama. Have a Q? Tweet them with the hashtag #CBSTownHall",
    "id" : 66522301700653056,
    "created_at" : "2011-05-06 15:18:47 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 67598161593630720,
  "created_at" : "2011-05-09 14:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67364357180370944",
  "text" : "Video: Emilio Estefan on the American dream & fixing the #immigration system. http:\/\/twitpic.com\/4va2aq",
  "id" : 67364357180370944,
  "created_at" : "2011-05-08 23:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zaddier Molina",
      "screen_name" : "jdrch",
      "indices" : [ 66, 72 ],
      "id_str" : "67136173",
      "id" : 67136173
    }, {
      "name" : "Tommy Thomason",
      "screen_name" : "Sillmyril",
      "indices" : [ 73, 83 ],
      "id_str" : "17089137",
      "id" : 17089137
    }, {
      "name" : "Mr. Young",
      "screen_name" : "MrYoungTeacher",
      "indices" : [ 84, 99 ],
      "id_str" : "415267763",
      "id" : 415267763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67323754505699328",
  "text" : "President Obama speaks on #immigration reform in El Paso on Tues. @jdrch @Sillmyril @mryoungteacher & lots more discussing now.",
  "id" : 67323754505699328,
  "created_at" : "2011-05-08 20:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67320869931859969",
  "text" : "Why is fixing our broken immigration system important to you? Share your thoughts with #immigration.",
  "id" : 67320869931859969,
  "created_at" : "2011-05-08 20:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67311765972729856",
  "text" : "Happy Mother's Day! Proclamation: http:\/\/www.wh.gov\/CWt Celebration w\/ the First Lady & military moms: http:\/\/wh.gov\/CZS",
  "id" : 67311765972729856,
  "created_at" : "2011-05-08 19:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eddie Piolin Sotelo",
      "screen_name" : "ElshowdePiolin",
      "indices" : [ 18, 33 ],
      "id_str" : "34487633",
      "id" : 34487633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67282677123907584",
  "text" : "Video: Radio host @ElshowdePiolin speaks from experience on the importance of #immigration reform. http:\/\/twitpic.com\/4v67bh",
  "id" : 67282677123907584,
  "created_at" : "2011-05-08 17:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67048472137830401",
  "text" : ".@TXSusanB When Dreamers get legal status, they become eligible to work & workers pay taxes. Report: http:\/\/1.usa.gov\/fk6B3N",
  "id" : 67048472137830401,
  "created_at" : "2011-05-08 02:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "LisaMoose",
      "indices" : [ 1, 11 ],
      "id_str" : "7012262",
      "id" : 7012262
    }, {
      "name" : "Dakota FUCK TRUMP",
      "screen_name" : "doodlebug0",
      "indices" : [ 12, 23 ],
      "id_str" : "32921077",
      "id" : 32921077
    }, {
      "name" : "Gustavo",
      "screen_name" : "inniscor",
      "indices" : [ 24, 33 ],
      "id_str" : "16412859",
      "id" : 16412859
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 57, 69 ]
    }, {
      "text" : "immigration",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67011589257166848",
  "text" : ".@LisaMoose @doodlebug0 @inniscor & lots more discussing #immigration reform. Obama #immigration speech on Tues.",
  "id" : 67011589257166848,
  "created_at" : "2011-05-07 23:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DreamAct",
      "indices" : [ 4, 13 ]
    }, {
      "text" : "immigration",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67008008131055618",
  "text" : "The #DreamAct would reduce the deficit by $1.4 billion in the next 10 years. Share thoughts on #immigration reform.",
  "id" : 67008008131055618,
  "created_at" : "2011-05-07 23:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silvia Marques",
      "screen_name" : "silviamarques",
      "indices" : [ 49, 63 ],
      "id_str" : "18024647",
      "id" : 18024647
    }, {
      "name" : "Michael Gillooly",
      "screen_name" : "MikeGillooly",
      "indices" : [ 64, 77 ],
      "id_str" : "116082887",
      "id" : 116082887
    }, {
      "name" : "Nasty AZ Woman",
      "screen_name" : "MrsAZIndependnt",
      "indices" : [ 78, 94 ],
      "id_str" : "280697481",
      "id" : 280697481
    }, {
      "name" : "whit Fit",
      "screen_name" : "Giggles2Go",
      "indices" : [ 95, 106 ],
      "id_str" : "1676446176",
      "id" : 1676446176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66990728538112000",
  "text" : "Cont. the discussion on #immigration reform, see @silviamarques @MikeGillooly @MrsAZIndependnt @Giggles2Go & lots more",
  "id" : 66990728538112000,
  "created_at" : "2011-05-07 22:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66972078796062720",
  "text" : "Today, there are over 20k border patrol agents -- double the number in 2004. Send thoughts on #immigration reform our way.",
  "id" : 66972078796062720,
  "created_at" : "2011-05-07 21:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Longoria Baston",
      "screen_name" : "EvaLongoria",
      "indices" : [ 7, 19 ],
      "id_str" : "110827653",
      "id" : 110827653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66938293757026304",
  "text" : "Video: @EvaLongoria on contributions of immigrants to our country & the need for #immigration reform http:\/\/twitpic.com\/4uouxf",
  "id" : 66938293757026304,
  "created_at" : "2011-05-07 18:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#CIR",
      "screen_name" : "1040NR",
      "indices" : [ 82, 89 ],
      "id_str" : "63362582",
      "id" : 63362582
    }, {
      "name" : "Natali Fani-Gonzalez",
      "screen_name" : "natalifani",
      "indices" : [ 90, 101 ],
      "id_str" : "66509258",
      "id" : 66509258
    }, {
      "name" : "Nathan",
      "screen_name" : "caption1",
      "indices" : [ 102, 111 ],
      "id_str" : "48099949",
      "id" : 48099949
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 6, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66911653240909824",
  "text" : "Obama #immigration speech on Tues in Texas, lots of ppl discussing the issue, see @1040NR @natalifani @caption1 many more",
  "id" : 66911653240909824,
  "created_at" : "2011-05-07 17:05:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arnold",
      "screen_name" : "Schwarzenegger",
      "indices" : [ 11, 26 ],
      "id_str" : "12044602",
      "id" : 12044602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "CIR",
      "indices" : [ 82, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66871959736156160",
  "text" : "Video: Gov @Schwarzenegger on comprehensive #immigration reform. Why do you think #CIR is important? http:\/\/twitpic.com\/4ulaal",
  "id" : 66871959736156160,
  "created_at" : "2011-05-07 14:28:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66664911421444097",
  "text" : "Photo of the Day: President Obama & the VP shake hands with the troops at Fort Campbell, KY  http:\/\/twitpic.com\/4ubmkw",
  "id" : 66664911421444097,
  "created_at" : "2011-05-07 00:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66660424338247680",
  "text" : "The President at Fort Campbell: \"...But so does every person who wears America\u2019s uniform.\" Remarks\/photos: http:\/\/wh.gov\/CZE",
  "id" : 66660424338247680,
  "created_at" : "2011-05-07 00:27:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66660180833746945",
  "text" : "President at Fort Campbell \"These Americans deserve credit for one of the greatest intelligence military operations in our nation\u2019s history\"",
  "id" : 66660180833746945,
  "created_at" : "2011-05-07 00:26:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chakazoid",
      "screen_name" : "deltforce1",
      "indices" : [ 73, 84 ],
      "id_str" : "145542747",
      "id" : 145542747
    }, {
      "name" : "Laci Green",
      "screen_name" : "gogreen18",
      "indices" : [ 85, 95 ],
      "id_str" : "15081340",
      "id" : 15081340
    }, {
      "name" : "Edgar Galindo",
      "screen_name" : "egalindo9",
      "indices" : [ 96, 106 ],
      "id_str" : "272133530",
      "id" : 272133530
    }, {
      "name" : "karinchu",
      "screen_name" : "karinchu",
      "indices" : [ 107, 116 ],
      "id_str" : "16623113",
      "id" : 16623113
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66602602653167616",
  "text" : "Lots of folks discussing #immigration reform, Obama speech on Tues., see @deltforce1 @gogreen18 @egalindo9 @karinchu lots more",
  "id" : 66602602653167616,
  "created_at" : "2011-05-06 20:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 28, 40 ]
    }, {
      "text" : "immigration",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66582234869665792",
  "text" : "Why do you think fixing our #immigration system is important? Send your reasons our way w\/ #immigration.",
  "id" : 66582234869665792,
  "created_at" : "2011-05-06 19:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66576130131501056",
  "text" : "Obama on gas prices, in speech & infographic formats. Full-size: http:\/\/wh.gov\/CWG Tweet-size:  http:\/\/twitpic.com\/4u83cy",
  "id" : 66576130131501056,
  "created_at" : "2011-05-06 18:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66533197755858944",
  "text" : "12:15: President Obama speaks at a plant for hybrid vehicle transmissions in Indiana on jobs & gas prices http:\/\/wh.gov\/live",
  "id" : 66533197755858944,
  "created_at" : "2011-05-06 16:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66520567842471936",
  "text" : "New West Wing Week: Behind the scenes video during an epic week, from Alabama to NYC http:\/\/wh.gov\/CWO",
  "id" : 66520567842471936,
  "created_at" : "2011-05-06 15:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66516183393898496",
  "text" : "New photo gallery: President Obama in NYC http:\/\/wh.gov\/CD7 One for Twitpic:  http:\/\/twitpic.com\/4u59nx",
  "id" : 66516183393898496,
  "created_at" : "2011-05-06 14:54:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 28, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66502862183727106",
  "text" : "Austan Goolsbee on new jobs #s: private sector payrolls up by 268K in April, strongest month in 5 years http:\/\/wh.gov\/CWW",
  "id" : 66502862183727106,
  "created_at" : "2011-05-06 14:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66487390868475904",
  "text" : "BREAKING: Obama immigration reform speech Tues in El Paso. Use #immigration to share thoughts now, during, after.",
  "id" : 66487390868475904,
  "created_at" : "2011-05-06 13:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66174556385189888",
  "text" : "President Obama w\/ NYC firefighters at Engine 54\/Ladder 4\/Battalion 9: \"When we say we will never forget, we mean what we say\"",
  "id" : 66174556385189888,
  "created_at" : "2011-05-05 16:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66138298065752064",
  "text" : "RT @pfeiffer44: POTUS heads to NYC today to lay a wreath at the 9\/11 Memorial and meet with 9\/11 family members",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "66095769270235136",
    "text" : "POTUS heads to NYC today to lay a wreath at the 9\/11 Memorial and meet with 9\/11 family members",
    "id" : 66095769270235136,
    "created_at" : "2011-05-05 11:03:54 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 66138298065752064,
  "created_at" : "2011-05-05 13:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65899034111516672",
  "text" : "President Obama welcomes the Wounded Warrior Project's Soldier Ride: http:\/\/wh.gov\/Cb5  Photo:  http:\/\/twitpic.com\/4tesk0",
  "id" : 65899034111516672,
  "created_at" : "2011-05-04 22:02:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65859053414391808",
  "text" : "Happening Now: President Obama welcomes the Wounded Warrior Project\u2019s Soldier Ride: http:\/\/www.wh.gov\/live",
  "id" : 65859053414391808,
  "created_at" : "2011-05-04 19:23:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 22, 31 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65837885185728512",
  "text" : "Today\u2019s briefing with @PressSec Jay Carney about to start at 2:00, watch live: http:\/\/wh.gov\/live",
  "id" : 65837885185728512,
  "created_at" : "2011-05-04 17:59:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 79, 88 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65785189326008321",
  "text" : "Video: First Lady & a lot of kids doing the Beyonce \u201CMove Your Body\u201D dance for @letsmove. Intense. Seriously. http:\/\/wh.gov\/C26",
  "id" : 65785189326008321,
  "created_at" : "2011-05-04 14:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankateacher",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65533366484738048",
  "text" : "Director of Speechwriting Jon Favreau: Thank You Mr. Jones: http:\/\/wh.gov\/C2m #thankateacher",
  "id" : 65533366484738048,
  "created_at" : "2011-05-03 21:49:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankateacher",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65455834594942976",
  "text" : "Dr. Jill Biden: Thank You Mrs. Helwig: http:\/\/wh.gov\/C4o #thankateacher",
  "id" : 65455834594942976,
  "created_at" : "2011-05-03 16:41:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65437230327541760",
  "text" : "11:45EDT: President Obama presents the National Teacher of the Year Award, watch live: http:\/\/wh.gov\/live",
  "id" : 65437230327541760,
  "created_at" : "2011-05-03 15:27:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 91, 99 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankaTeacher",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65415659735101442",
  "text" : "Thank a teacher on Nat'l Teacher Appreciation Day: http:\/\/wh.gov\/C4v #ThankaTeacher Follow @usedgov",
  "id" : 65415659735101442,
  "created_at" : "2011-05-03 14:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65172812528226305",
  "text" : "Full photo gallery: President Obama, May 1, 2011 http:\/\/wh.gov\/CgZ",
  "id" : 65172812528226305,
  "created_at" : "2011-05-02 21:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65170895773245440",
  "text" : "The President, VP, national security team get updated on mission against Osama bin Laden in the Sit Room, 5\/1\/11  http:\/\/twitpic.com\/4si89t",
  "id" : 65170895773245440,
  "created_at" : "2011-05-02 21:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65085484845629440",
  "text" : "President Obama: \"there's nothing we can\u2019t do\u2026that patriotism\u2014in the crowds\u2026here outside the WH, at Ground Zero in NY & across the country\"",
  "id" : 65085484845629440,
  "created_at" : "2011-05-02 16:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65083934052069376",
  "text" : "As we honor those who are serving today, also remember those in the past; Medal of Honor for 2 Korean War heroes who made ultimate sacrifice",
  "id" : 65083934052069376,
  "created_at" : "2011-05-02 16:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65076298481025024",
  "text" : "11:55EDT: President Obama awards the Medal of Honor to Anthony T. Kaho\u2019ohanohano & Henry Svehla, watch: http:\/\/wh.gov\/live",
  "id" : 65076298481025024,
  "created_at" : "2011-05-02 15:32:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64940243563982849",
  "text" : "More details: Transcript of press briefing by Senior Administra\u200Btion Officials on the killing of Osama bin Laden http:\/\/wh.\u200Bgov\/CrN",
  "id" : 64940243563982849,
  "created_at" : "2011-05-02 06:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64912524407078912",
  "text" : "President Obama on the death of Osama bin Laden, full video: http:\/\/wh.gov\/CrK",
  "id" : 64912524407078912,
  "created_at" : "2011-05-02 04:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64908656222810112",
  "text" : "President Obama on the death of Osama bin Laden, full transcript: http:\/\/wh.\u200Bgov\/CrK",
  "id" : 64908656222810112,
  "created_at" : "2011-05-02 04:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64898010643042304",
  "text" : "Obama: \u201CTonight, let us think back to the same sense of unity that prevailed on 9\/11\u2026this\u2026is a testament to the greatness of our country\u201D",
  "id" : 64898010643042304,
  "created_at" : "2011-05-02 03:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64897795018067969",
  "text" : "Obama: \u201CFinally, let me say to the families who lost loved ones on 9\/11, that we have never forgotten your loss\u201D",
  "id" : 64897795018067969,
  "created_at" : "2011-05-02 03:43:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64897711387836417",
  "text" : "Obama: \u201CWe give thanks for the men who carried out this operation\u201D",
  "id" : 64897711387836417,
  "created_at" : "2011-05-02 03:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64897114781659137",
  "text" : "Obama: \u201Cthe US is not \u2013 and never will be \u2013 at war with Islam\u2026Bin Laden was not a Muslim leader; he was a mass murderer of Muslims\u201D",
  "id" : 64897114781659137,
  "created_at" : "2011-05-02 03:40:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64897020523053056",
  "text" : "Obama: \u201Chis death does not mark the end of our effort\u2026 We must \u2013 and we will - remain vigilant at home and abroad.\u201D",
  "id" : 64897020523053056,
  "created_at" : "2011-05-02 03:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64896891338489856",
  "text" : "Obama: \"at my direction, the US launched a targeted operation\u2026No Americans were harmed\u2026After a firefight, they killed Osama bin Laden\u201D",
  "id" : 64896891338489856,
  "created_at" : "2011-05-02 03:39:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64896609015697408",
  "text" : "Obama: \"Shortly after taking office, I directed\u2026the director of the CIA, to make the killing or capture of bin Laden the top priority...\"",
  "id" : 64896609015697408,
  "created_at" : "2011-05-02 03:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64896268702461952",
  "text" : "Obama:On 9\/11 \u201Cno matter where we came from, what God we prayed to, or what race or ethnicity we were we were united as one American family\"",
  "id" : 64896268702461952,
  "created_at" : "2011-05-02 03:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64895811951136768",
  "text" : "President Obama: \"I can report to the American people and to the world, that the US has conducted an operation that killed Osama bin Laden\u201D",
  "id" : 64895811951136768,
  "created_at" : "2011-05-02 03:35:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64895704031707136",
  "text" : "President Obama speaking now, watch: http:\/\/wh.gov\/live",
  "id" : 64895704031707136,
  "created_at" : "2011-05-02 03:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64877330794946560",
  "text" : "RT @pfeiffer44: POTUS to address the nation tonight at 10:30 PM Eastern Time \/\/ Watch live: http:\/\/wh.gov\/live",
  "id" : 64877330794946560,
  "created_at" : "2011-05-02 02:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]