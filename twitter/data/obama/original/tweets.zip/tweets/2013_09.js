Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/384883257117908993\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/pKNek0ub1f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVdhSHICMAAnCtp.jpg",
      "id_str" : "384883256941752320",
      "id" : 384883256941752320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVdhSHICMAAnCtp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pKNek0ub1f"
    } ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 99, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384883257117908993",
  "text" : "President Obama signs a bill to maintain pay &amp; allowances for members of the Armed Forces in a #GovernmentShutdown: http:\/\/t.co\/pKNek0ub1f",
  "id" : 384883257117908993,
  "created_at" : "2013-10-01 03:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384870989772754944",
  "text" : "RT @arneduncan: I invite lawmakers holding up the budget to visit preschools with me &amp; see teamwork, listening, fair play &amp; compassion in a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384865268624666624",
    "text" : "I invite lawmakers holding up the budget to visit preschools with me &amp; see teamwork, listening, fair play &amp; compassion in action.",
    "id" : 384865268624666624,
    "created_at" : "2013-10-01 02:20:05 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 384870989772754944,
  "created_at" : "2013-10-01 02:42:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/384866019681898496\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/gTJuV8jeGq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVdRmxXCEAAA-UF.jpg",
      "id_str" : "384866019690287104",
      "id" : 384866019690287104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVdRmxXCEAAA-UF.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/gTJuV8jeGq"
    } ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384866019681898496",
  "text" : "It's time to stop playing political games and pass a clean budget that avoids a government #shutdown: http:\/\/t.co\/gTJuV8jeGq",
  "id" : 384866019681898496,
  "created_at" : "2013-10-01 02:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "governmentshutdown",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384848037526269952",
  "text" : "It's time for Congress to do the right thing for our country and pass a budget that prevents a #governmentshutdown. \u2014bo",
  "id" : 384848037526269952,
  "created_at" : "2013-10-01 01:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/29Xf7rwiou",
      "expanded_url" : "http:\/\/go.wh.gov\/aZHbvM",
      "display_url" : "go.wh.gov\/aZHbvM"
    } ]
  },
  "geo" : { },
  "id_str" : "384840094852448256",
  "text" : "\"Congress needs to keep our government open, needs to pay our bills on time.\" \u2014President Obama: http:\/\/t.co\/29Xf7rwiou #Shutdown",
  "id" : 384840094852448256,
  "created_at" : "2013-10-01 00:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384833802574368768",
  "text" : "RT if you agree: It's time to stop playing political games with our economy and pass a budget that protects the middle class. #Shutdown",
  "id" : 384833802574368768,
  "created_at" : "2013-10-01 00:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/dXxCF37LI8",
      "expanded_url" : "http:\/\/go.wh.gov\/uzTQfg",
      "display_url" : "go.wh.gov\/uzTQfg"
    } ]
  },
  "geo" : { },
  "id_str" : "384827451747995648",
  "text" : "President Obama has made clear that Congress has two jobs to do:\n1. Pay the bills on time\n2. Pass a budget on time \u2014&gt; http:\/\/t.co\/dXxCF37LI8",
  "id" : 384827451747995648,
  "created_at" : "2013-09-30 23:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384818703029641220",
  "text" : "FACT: The House GOP plan to force a government #shutdown would close our national parks and the Smithsonian museums.",
  "id" : 384818703029641220,
  "created_at" : "2013-09-30 23:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384813816850051073",
  "text" : "FACT: The House Republican funding bill would deny women access to birth control and family planning services. #Shutdown",
  "id" : 384813816850051073,
  "created_at" : "2013-09-30 22:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384804878591082496",
  "text" : "RT @Simas44: Pres. Obama: One faction of one party, in one house of Congress, in one branch of government doesn\u2019t get to shut down the enti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "384801894327001088",
    "text" : "Pres. Obama: One faction of one party, in one house of Congress, in one branch of government doesn\u2019t get to shut down the entire government.",
    "id" : 384801894327001088,
    "created_at" : "2013-09-30 22:08:15 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 384804878591082496,
  "created_at" : "2013-09-30 22:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384788721368723456",
  "text" : "President Obama to the House GOP: \"You don't get to extract a ransom for doing your job.\" #Shutdown",
  "id" : 384788721368723456,
  "created_at" : "2013-09-30 21:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384788243943677953",
  "text" : "Obama: \"Congress needs to keep our government open...pay our bills on time &amp; never, ever threaten the full faith and credit of the U.S.\"",
  "id" : 384788243943677953,
  "created_at" : "2013-09-30 21:14:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "384787233112219648",
  "text" : "Obama: \"Tomorrow, tens of millions of Americans will be able to visit http:\/\/t.co\/GNfbftrfo3 to shop for affordable health coverage.\"",
  "id" : 384787233112219648,
  "created_at" : "2013-09-30 21:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 116, 126 ]
    }, {
      "text" : "Shutdown",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384786947136167936",
  "text" : "Obama: \"An important part of the Affordable Care Act takes effect tomorrow, no matter what Congress decides today.\" #Obamacare #Shutdown",
  "id" : 384786947136167936,
  "created_at" : "2013-09-30 21:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384786614083264512",
  "text" : "Obama: \"Putting the American people\u2019s hard-earned progress at risk is the height of irresponsibility...it doesn\u2019t have to happen.\" #Shutdown",
  "id" : 384786614083264512,
  "created_at" : "2013-09-30 21:07:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384785815089328128",
  "text" : "Obama: \"If you\u2019re on Social Security, you will keep receiving your checks. If you\u2019re on Medicare, your doctor will still see you.\" #Shutdown",
  "id" : 384785815089328128,
  "created_at" : "2013-09-30 21:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384785615830544384",
  "text" : "Obama: \"If...Congress does not fulfill its responsibility to pass a budget today, much of the U.S. government will be forced to #shutdown.\"",
  "id" : 384785615830544384,
  "created_at" : "2013-09-30 21:03:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "384785137604378624",
  "text" : "Right now: President Obama delivers a statement from the White House Briefing Room. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 384785137604378624,
  "created_at" : "2013-09-30 21:01:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384779640654417922",
  "text" : "FACT: House Republicans would rather #shutdown the government than help millions of Americans afford health insurance.",
  "id" : 384779640654417922,
  "created_at" : "2013-09-30 20:39:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384777676742877184",
  "text" : "FACT: If House Republicans force a government #shutdown, it could cost our economy $10 billion per week.",
  "id" : 384777676742877184,
  "created_at" : "2013-09-30 20:32:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "384774480083443712",
  "text" : "At 4:45pm ET, President Obama delivers a statement from the White House Briefing Room. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 384774480083443712,
  "created_at" : "2013-09-30 20:19:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384773290058715136",
  "text" : "As members of Congress, the House GOP has 2 jobs: Pass a budget that doesn't hurt the middle class &amp; pay our country's bills. #Shutdown",
  "id" : 384773290058715136,
  "created_at" : "2013-09-30 20:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384770094074568704",
  "text" : "If GOP leaders in the House allowed a vote on a clean funding bill right now, it would pass and prevent a government #shutdown.",
  "id" : 384770094074568704,
  "created_at" : "2013-09-30 20:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Los Angeles Times",
      "screen_name" : "latimes",
      "indices" : [ 90, 98 ],
      "id_str" : "16664681",
      "id" : 16664681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7jFj26vCZQ",
      "expanded_url" : "http:\/\/lat.ms\/16ur0OR",
      "display_url" : "lat.ms\/16ur0OR"
    } ]
  },
  "geo" : { },
  "id_str" : "384758476850741248",
  "text" : "\"Starting Oct. 1st, millions of Californians can start signing up for health insurance.\" \u2014@LATimes: http:\/\/t.co\/7jFj26vCZQ #GetCovered",
  "id" : 384758476850741248,
  "created_at" : "2013-09-30 19:15:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 1, 9 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/BmVDw66xLY",
      "expanded_url" : "http:\/\/nyti.ms\/178MxtU",
      "display_url" : "nyti.ms\/178MxtU"
    } ]
  },
  "geo" : { },
  "id_str" : "384746237561303040",
  "text" : ".@NYTimes: Starting tomorrow, you can \"compare health insurance plans &amp; then buy...coverage on the spot.\" http:\/\/t.co\/BmVDw66xLY #GetCovered",
  "id" : 384746237561303040,
  "created_at" : "2013-09-30 18:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gUcxQNWZQh",
      "expanded_url" : "http:\/\/go.wh.gov\/Wh4Y2P",
      "display_url" : "go.wh.gov\/Wh4Y2P"
    } ]
  },
  "geo" : { },
  "id_str" : "384738182702452736",
  "text" : "Here's how you can help get the word out about why it's important to #GetCovered starting tomorrow \u2014&gt; http:\/\/t.co\/gUcxQNWZQh #Obamacare",
  "id" : 384738182702452736,
  "created_at" : "2013-09-30 17:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/wh6d6zyfcH",
      "expanded_url" : "http:\/\/go.wh.gov\/ZvyhVv",
      "display_url" : "go.wh.gov\/ZvyhVv"
    } ]
  },
  "geo" : { },
  "id_str" : "384713005314748416",
  "text" : "Worth a RT: Thanks to #Obamacare, signing up for health insurance just got 17 pages easier \u2014&gt; http:\/\/t.co\/wh6d6zyfcH #GetCovered",
  "id" : 384713005314748416,
  "created_at" : "2013-09-30 16:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384705456599355392",
  "text" : "FACT: 83% of uninsured Americans say they'll sign up for health insurance during the 6-month #Obamacare enrollment period. #GetCovered",
  "id" : 384705456599355392,
  "created_at" : "2013-09-30 15:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 121, 132 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/eTAkGcTbAW",
      "expanded_url" : "http:\/\/hc.gov\/CZco9T",
      "display_url" : "hc.gov\/CZco9T"
    } ]
  },
  "geo" : { },
  "id_str" : "384698163690348544",
  "text" : "Starting tomorrow, uninsured Americans can sign up for quality, affordable health insurance \u2014&gt; http:\/\/t.co\/eTAkGcTbAW #GetCovered #Obamacare",
  "id" : 384698163690348544,
  "created_at" : "2013-09-30 15:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Jennifer Hudson",
      "screen_name" : "IAMJHUD",
      "indices" : [ 35, 43 ],
      "id_str" : "33990291",
      "id" : 33990291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/mDuF3Va8v0",
      "expanded_url" : "http:\/\/goo.gl\/ffZdzL",
      "display_url" : "goo.gl\/ffZdzL"
    } ]
  },
  "geo" : { },
  "id_str" : "384686962705055745",
  "text" : "RT @vj44: Watch our #ACA gladiator @IAMJHUD take the \u201Cscandalous\u201D out of #Obamacare. #GetCovered http:\/\/t.co\/mDuF3Va8v0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Hudson",
        "screen_name" : "IAMJHUD",
        "indices" : [ 25, 33 ],
        "id_str" : "33990291",
        "id" : 33990291
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 63, 73 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 75, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/mDuF3Va8v0",
        "expanded_url" : "http:\/\/goo.gl\/ffZdzL",
        "display_url" : "goo.gl\/ffZdzL"
      } ]
    },
    "geo" : { },
    "id_str" : "384665305735118848",
    "text" : "Watch our #ACA gladiator @IAMJHUD take the \u201Cscandalous\u201D out of #Obamacare. #GetCovered http:\/\/t.co\/mDuF3Va8v0",
    "id" : 384665305735118848,
    "created_at" : "2013-09-30 13:05:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 384686962705055745,
  "created_at" : "2013-09-30 14:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7JJJlItC9s",
      "expanded_url" : "http:\/\/bit.ly\/1dQUyFB",
      "display_url" : "bit.ly\/1dQUyFB"
    } ]
  },
  "geo" : { },
  "id_str" : "384438381242888192",
  "text" : "RT @petesouza: New photo: President Obama meets with his senior staff to discuss a potential government shutdown: http:\/\/t.co\/7JJJlItC9s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/7JJJlItC9s",
        "expanded_url" : "http:\/\/bit.ly\/1dQUyFB",
        "display_url" : "bit.ly\/1dQUyFB"
      } ]
    },
    "geo" : { },
    "id_str" : "384432566704414720",
    "text" : "New photo: President Obama meets with his senior staff to discuss a potential government shutdown: http:\/\/t.co\/7JJJlItC9s",
    "id" : 384432566704414720,
    "created_at" : "2013-09-29 21:40:40 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 384438381242888192,
  "created_at" : "2013-09-29 22:03:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/u8zHNpfn37",
      "expanded_url" : "http:\/\/go.wh.gov\/fRFwJ3",
      "display_url" : "go.wh.gov\/fRFwJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "384078813199466496",
  "text" : "President Obama: \"I will not negotiate over Congress\u2019 responsibility to pay the bills it has already racked up.\" http:\/\/t.co\/u8zHNpfn37",
  "id" : 384078813199466496,
  "created_at" : "2013-09-28 22:14:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/QDdXWzZksp",
      "expanded_url" : "http:\/\/go.wh.gov\/ZpJbAE",
      "display_url" : "go.wh.gov\/ZpJbAE"
    } ]
  },
  "geo" : { },
  "id_str" : "384068791551807488",
  "text" : "Statement from @PressSec: \"Today Republicans in the House of Representatives moved to shut down the government.\" http:\/\/t.co\/QDdXWzZksp",
  "id" : 384068791551807488,
  "created_at" : "2013-09-28 21:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 13, 24 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/u8zHNpfn37",
      "expanded_url" : "http:\/\/go.wh.gov\/fRFwJ3",
      "display_url" : "go.wh.gov\/fRFwJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "384026215087996928",
  "text" : "On Tuesday, \"#GetCovered at http:\/\/t.co\/GNfbftrfo3 and spread the word.\" \u2014Obama in his Weekly Address: http:\/\/t.co\/u8zHNpfn37 #Obamacare",
  "id" : 384026215087996928,
  "created_at" : "2013-09-28 18:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/u8zHNpfn37",
      "expanded_url" : "http:\/\/go.wh.gov\/fRFwJ3",
      "display_url" : "go.wh.gov\/fRFwJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "383987868005195776",
  "text" : "President Obama's Weekly Address: Averting a government shutdown and expanding access to affordable healthcare --&gt; http:\/\/t.co\/u8zHNpfn37",
  "id" : 383987868005195776,
  "created_at" : "2013-09-28 16:13:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383735591223193600\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1XpOk3eLgd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVNNfKfIIAAjaMb.jpg",
      "id_str" : "383735591042818048",
      "id" : 383735591042818048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVNNfKfIIAAjaMb.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1XpOk3eLgd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383735591223193600",
  "text" : "RT if you agree: It's time to pay our bills on time and pass a budget that doesn't hurt the middle class. http:\/\/t.co\/1XpOk3eLgd",
  "id" : 383735591223193600,
  "created_at" : "2013-09-27 23:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hassan Rouhani",
      "screen_name" : "HassanRouhani",
      "indices" : [ 3, 17 ],
      "id_str" : "1404590618",
      "id" : 1404590618
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 58, 70 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rouhani",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "UNGA",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383725367367696384",
  "text" : "RT @HassanRouhani: After historic phone conversation with @BarackObama, President #Rouhani in plane abt to depart for Tehran. #UNGA http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 39, 51 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HassanRouhani\/status\/383689140174200832\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/TFtLWxbbaV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVMjPXiCIAEs0dy.jpg",
        "id_str" : "383689140178395137",
        "id" : 383689140178395137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVMjPXiCIAEs0dy.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TFtLWxbbaV"
      } ],
      "hashtags" : [ {
        "text" : "Rouhani",
        "indices" : [ 63, 71 ]
      }, {
        "text" : "UNGA",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383689140174200832",
    "text" : "After historic phone conversation with @BarackObama, President #Rouhani in plane abt to depart for Tehran. #UNGA http:\/\/t.co\/TFtLWxbbaV",
    "id" : 383689140174200832,
    "created_at" : "2013-09-27 20:26:34 +0000",
    "user" : {
      "name" : "Hassan Rouhani",
      "screen_name" : "HassanRouhani",
      "protected" : false,
      "id_str" : "1404590618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000377057530\/44d936e3df3d0d23f365d1795a8caa88_normal.jpeg",
      "id" : 1404590618,
      "verified" : false
    }
  },
  "id" : 383725367367696384,
  "created_at" : "2013-09-27 22:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nskOKPq3L7",
      "expanded_url" : "http:\/\/go.wh.gov\/h3UeZo",
      "display_url" : "go.wh.gov\/h3UeZo"
    } ]
  },
  "geo" : { },
  "id_str" : "383706676638928896",
  "text" : "Obama: \"I will not negotiate over Congress\u2019 responsibility to pay the bills that have already been racked up.\" Watch: http:\/\/t.co\/nskOKPq3L7",
  "id" : 383706676638928896,
  "created_at" : "2013-09-27 21:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383703275670753280\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/qghFAUCIA7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVMwGKXCUAAhy3O.jpg",
      "id_str" : "383703275674947584",
      "id" : 383703275674947584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVMwGKXCUAAhy3O.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qghFAUCIA7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383703275670753280",
  "text" : "Historic phone call in the Oval Office: President Obama speaks with Iranian President Hassan Rouhani. http:\/\/t.co\/qghFAUCIA7",
  "id" : 383703275670753280,
  "created_at" : "2013-09-27 21:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383681779120340993",
  "text" : "Obama: \"My message to Congress is this: Do not shut down the government. Don\u2019t shut down the economy. Pass a budget on time.\" #EnoughAlready",
  "id" : 383681779120340993,
  "created_at" : "2013-09-27 19:57:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383681208158150656",
  "text" : "Obama: \"Nobody gets to hurt our economy and millions of innocent people just because there are a couple laws you don\u2019t like.\" #EnoughAlready",
  "id" : 383681208158150656,
  "created_at" : "2013-09-27 19:55:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383681018525265921",
  "text" : "President Obama: \"I will not negotiate over Congress\u2019 responsibility to pay the bills that have already been racked up.\" #EnoughAlready",
  "id" : 383681018525265921,
  "created_at" : "2013-09-27 19:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383680699724611584",
  "text" : "\"It would have a profound destabilizing effect on the economy.\" \u2014Obama on the House GOP threat to default on our debt #EnoughAlready",
  "id" : 383680699724611584,
  "created_at" : "2013-09-27 19:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383680306265325568",
  "text" : "\"Any Republican Congressmen who are watching right now, I\u2019d encourage you to think about who you\u2019re hurting.\" \u2014Obama #EnoughAlready",
  "id" : 383680306265325568,
  "created_at" : "2013-09-27 19:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383679724989317120",
  "text" : "\"That\u2019s not going to happen.\" \u2014President Obama on the House GOP demand to shut down the government if we don't gut #Obamacare",
  "id" : 383679724989317120,
  "created_at" : "2013-09-27 19:49:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383679262282100736",
  "text" : "President Obama: \"If Congress chooses not to pass a budget by Monday\u2014the end of the fiscal year\u2014they will shut down the government.\"",
  "id" : 383679262282100736,
  "created_at" : "2013-09-27 19:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383679004009443328",
  "text" : "Obama: \"We have a responsibility to pursue diplomacy and...we have a unique opportunity to make progress with the new leadership in Tehran.\"",
  "id" : 383679004009443328,
  "created_at" : "2013-09-27 19:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383678436662734848",
  "text" : "Obama on Iran: \"While there will surely be important obstacles moving forward...I believe that we can reach a comprehensive solution.\"",
  "id" : 383678436662734848,
  "created_at" : "2013-09-27 19:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383678061146677248",
  "text" : "President Obama: \"Just now, I spoke on the phone with President Rouhani of the Islamic Republic of Iran.\"",
  "id" : 383678061146677248,
  "created_at" : "2013-09-27 19:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "383677937880297473",
  "text" : "Right now: President Obama delivers a statement from the White House Briefing Room. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 383677937880297473,
  "created_at" : "2013-09-27 19:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "383667911270739969",
  "text" : "President Obama will make a statement in the White House Briefing Room at 3:30pm ET. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 383667911270739969,
  "created_at" : "2013-09-27 19:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GottaShareEmAll",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/OtXB6lhzYv",
      "expanded_url" : "http:\/\/go.wh.gov\/2Egj3g",
      "display_url" : "go.wh.gov\/2Egj3g"
    } ]
  },
  "geo" : { },
  "id_str" : "383663822990356481",
  "text" : "Love graphics on health care, clean energy, the economy, and more? Here's the place for you \u2014&gt; http:\/\/t.co\/OtXB6lhzYv #GottaShareEmAll",
  "id" : 383663822990356481,
  "created_at" : "2013-09-27 18:45:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383655790491348992",
  "text" : "RT @Racusen44: More ways #Obamacare is helping Americans #GetCovered -- this time, good news for 200,000 uninsured Arkansans: http:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 10, 20 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/wqd7kYrXW9",
        "expanded_url" : "http:\/\/1.usa.gov\/16PDbjq",
        "display_url" : "1.usa.gov\/16PDbjq"
      } ]
    },
    "geo" : { },
    "id_str" : "383645086749179904",
    "text" : "More ways #Obamacare is helping Americans #GetCovered -- this time, good news for 200,000 uninsured Arkansans: http:\/\/t.co\/wqd7kYrXW9",
    "id" : 383645086749179904,
    "created_at" : "2013-09-27 17:31:31 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 383655790491348992,
  "created_at" : "2013-09-27 18:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383651054639779840",
  "text" : "RT @PAniskoff44: If you care about healthcare, education, immigration, economy or energy, check out this new page &amp; share or RT: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/9bCcPccO5V",
        "expanded_url" : "http:\/\/1.usa.gov\/19FVdGU",
        "display_url" : "1.usa.gov\/19FVdGU"
      } ]
    },
    "geo" : { },
    "id_str" : "383645910351106048",
    "text" : "If you care about healthcare, education, immigration, economy or energy, check out this new page &amp; share or RT: http:\/\/t.co\/9bCcPccO5V",
    "id" : 383645910351106048,
    "created_at" : "2013-09-27 17:34:47 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 383651054639779840,
  "created_at" : "2013-09-27 17:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383643726209241089\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/OB9gQ61s8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVL576dCIAI31kG.jpg",
      "id_str" : "383643725978542082",
      "id" : 383643725978542082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVL576dCIAI31kG.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OB9gQ61s8I"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MPcqjhZ4Q1",
      "expanded_url" : "http:\/\/go.wh.gov\/ayyfoQ",
      "display_url" : "go.wh.gov\/ayyfoQ"
    } ]
  },
  "geo" : { },
  "id_str" : "383643726209241089",
  "text" : "Worth sharing: Get the facts on how #Obamacare helps you and your family \u2014&gt; http:\/\/t.co\/MPcqjhZ4Q1 #GetCovered http:\/\/t.co\/OB9gQ61s8I",
  "id" : 383643726209241089,
  "created_at" : "2013-09-27 17:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xfkE20czUU",
      "expanded_url" : "http:\/\/sgfnow.co\/14NZyrQ",
      "display_url" : "sgfnow.co\/14NZyrQ"
    } ]
  },
  "geo" : { },
  "id_str" : "383634879272861696",
  "text" : "\u201CThe exchanges are there, people need insurance.\u201D \u2014Sen. Roy Blunt on why Missourians should #GetCovered: http:\/\/t.co\/xfkE20czUU #Obamacare",
  "id" : 383634879272861696,
  "created_at" : "2013-09-27 16:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383625741788672000\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/VMk9w5zq4Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVLplGJCcAAso0d.jpg",
      "id_str" : "383625741792866304",
      "id" : 383625741792866304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVLplGJCcAAso0d.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VMk9w5zq4Y"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383625741788672000",
  "text" : "Nobody in America should go broke because they get sick. #Obamacare will help make sure that doesn't happen: http:\/\/t.co\/VMk9w5zq4Y",
  "id" : 383625741788672000,
  "created_at" : "2013-09-27 16:14:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 44, 60 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/4WmFmm16UG",
      "expanded_url" : "http:\/\/nyti.ms\/18ts9SI",
      "display_url" : "nyti.ms\/18ts9SI"
    } ]
  },
  "geo" : { },
  "id_str" : "383614749381898240",
  "text" : "\"My state needs #Obamacare. Now.\" \u2014Kentucky @GovSteveBeshear in his must-read OpEd: http:\/\/t.co\/4WmFmm16UG #GetCovered",
  "id" : 383614749381898240,
  "created_at" : "2013-09-27 15:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/yptn9SD9XH",
      "expanded_url" : "http:\/\/go.wh.gov\/Tcpiye",
      "display_url" : "go.wh.gov\/Tcpiye"
    } ]
  },
  "geo" : { },
  "id_str" : "383605917712777218",
  "text" : "RT to share this animated video on how #Obamacare helps you and your family \u2014&gt; http:\/\/t.co\/yptn9SD9XH #GetCovered",
  "id" : 383605917712777218,
  "created_at" : "2013-09-27 14:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/yptn9SD9XH",
      "expanded_url" : "http:\/\/go.wh.gov\/Tcpiye",
      "display_url" : "go.wh.gov\/Tcpiye"
    } ]
  },
  "geo" : { },
  "id_str" : "383586433778200577",
  "text" : "Whether you need health coverage or have it already, watch how #Obamacare helps you \u2014&gt; http:\/\/t.co\/yptn9SD9XH #GetCovered",
  "id" : 383586433778200577,
  "created_at" : "2013-09-27 13:38:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Jonathan Cohn",
      "screen_name" : "CitizenCohn",
      "indices" : [ 111, 123 ],
      "id_str" : "21634627",
      "id" : 21634627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383580840191467520",
  "text" : "RT @Simas44: Worth a RT. Why the ACA will improve the lives of millions and was worth the wait. Must read from @CitizenCohn  http:\/\/t.co\/HA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Cohn",
        "screen_name" : "CitizenCohn",
        "indices" : [ 98, 110 ],
        "id_str" : "21634627",
        "id" : 21634627
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/HAm6v0KEQj",
        "expanded_url" : "http:\/\/on.tnr.com\/16v7q51",
        "display_url" : "on.tnr.com\/16v7q51"
      } ]
    },
    "geo" : { },
    "id_str" : "383513647550451713",
    "text" : "Worth a RT. Why the ACA will improve the lives of millions and was worth the wait. Must read from @CitizenCohn  http:\/\/t.co\/HAm6v0KEQj",
    "id" : 383513647550451713,
    "created_at" : "2013-09-27 08:49:13 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 383580840191467520,
  "created_at" : "2013-09-27 13:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383373977973846016\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7TVL6cgEDV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVIEmg3CcAAxfBh.jpg",
      "id_str" : "383373977982234624",
      "id" : 383373977982234624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVIEmg3CcAAxfBh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/7TVL6cgEDV"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383373977973846016",
  "text" : "RT if you agree: It's time to help our fellow Americans #GetCovered\u2014not deny health care to millions. #Obamacare, http:\/\/t.co\/7TVL6cgEDV",
  "id" : 383373977973846016,
  "created_at" : "2013-09-26 23:34:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/MhRpHWqwZH",
      "expanded_url" : "http:\/\/bit.ly\/19KwFeN",
      "display_url" : "bit.ly\/19KwFeN"
    } ]
  },
  "geo" : { },
  "id_str" : "383363967894044673",
  "text" : "\"Thank you,\" the President signed to Stephon\u2026for a second time \u2014&gt; http:\/\/t.co\/MhRpHWqwZH",
  "id" : 383363967894044673,
  "created_at" : "2013-09-26 22:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383330426908983297",
  "text" : "RT @lacasablanca: A6: Under #Obamacare 10.2 million uninsured Latinos will have the opportunity 2 buy affordable health insurance, this is \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 10, 20 ]
      }, {
        "text" : "OurSalud",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383326249521000448",
    "text" : "A6: Under #Obamacare 10.2 million uninsured Latinos will have the opportunity 2 buy affordable health insurance, this is HUGE! #OurSalud",
    "id" : 383326249521000448,
    "created_at" : "2013-09-26 20:24:34 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 383330426908983297,
  "created_at" : "2013-09-26 20:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 89, 100 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COflood",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vI7vd8A0GD",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/09\/26\/vice-president-biden-tours-flood-affected-areas-colorado",
      "display_url" : "whitehouse.gov\/blog\/2013\/09\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383323450435047425",
  "text" : "RT @VP: VP Biden toured #COflood damage on Monday \u2013 watch the video recap &amp; read the @whitehouse blog post here: http:\/\/t.co\/vI7vd8A0GD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 81, 92 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COflood",
        "indices" : [ 16, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/vI7vd8A0GD",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/09\/26\/vice-president-biden-tours-flood-affected-areas-colorado",
        "display_url" : "whitehouse.gov\/blog\/2013\/09\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383269813587410945",
    "text" : "VP Biden toured #COflood damage on Monday \u2013 watch the video recap &amp; read the @whitehouse blog post here: http:\/\/t.co\/vI7vd8A0GD",
    "id" : 383269813587410945,
    "created_at" : "2013-09-26 16:40:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 383323450435047425,
  "created_at" : "2013-09-26 20:13:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383312658134343680\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2QU6z7marx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVHM1OHCIAAPjhH.jpg",
      "id_str" : "383312657995931648",
      "id" : 383312657995931648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVHM1OHCIAAPjhH.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/2QU6z7marx"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/PgabSIFP1m",
      "expanded_url" : "http:\/\/go.wh.gov\/74A7RS",
      "display_url" : "go.wh.gov\/74A7RS"
    } ]
  },
  "geo" : { },
  "id_str" : "383312658134343680",
  "text" : "RT if you agree: Nobody in America should go broke just because they get sick. http:\/\/t.co\/PgabSIFP1m #Obamacare, http:\/\/t.co\/2QU6z7marx",
  "id" : 383312658134343680,
  "created_at" : "2013-09-26 19:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383301249824616448\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/AHnjO1mtws",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVHCdLACIAADMIr.jpg",
      "id_str" : "383301249728126976",
      "id" : 383301249728126976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVHCdLACIAADMIr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/AHnjO1mtws"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/8dwzC5HBq3",
      "expanded_url" : "http:\/\/go.wh.gov\/HWvwEq",
      "display_url" : "go.wh.gov\/HWvwEq"
    } ]
  },
  "geo" : { },
  "id_str" : "383301249824616448",
  "text" : "On Tuesday, working families making $50,000 can #GetCovered for less than $100\/month \u2014&gt; http:\/\/t.co\/8dwzC5HBq3, http:\/\/t.co\/AHnjO1mtws",
  "id" : 383301249824616448,
  "created_at" : "2013-09-26 18:45:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adorable Care Act",
      "screen_name" : "AdorableCareAct",
      "indices" : [ 3, 19 ],
      "id_str" : "1886578915",
      "id" : 1886578915
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AdorableCareAct\/status\/383035148188385280\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/dtxAx7yKuB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVDQcA6CAAAhPnI.jpg",
      "id_str" : "383035148024807424",
      "id" : 383035148024807424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVDQcA6CAAAhPnI.jpg",
      "sizes" : [ {
        "h" : 742,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dtxAx7yKuB"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/oB4N8EhEuV",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "383292281656061952",
  "text" : "RT @AdorableCareAct: Get your ducks in a row\u2014visit http:\/\/t.co\/oB4N8EhEuV to #GetCovered starting Oct 1! http:\/\/t.co\/dtxAx7yKuB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AdorableCareAct\/status\/383035148188385280\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/dtxAx7yKuB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVDQcA6CAAAhPnI.jpg",
        "id_str" : "383035148024807424",
        "id" : 383035148024807424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVDQcA6CAAAhPnI.jpg",
        "sizes" : [ {
          "h" : 742,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 742,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dtxAx7yKuB"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 56, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/oB4N8EhEuV",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "383035148188385280",
    "text" : "Get your ducks in a row\u2014visit http:\/\/t.co\/oB4N8EhEuV to #GetCovered starting Oct 1! http:\/\/t.co\/dtxAx7yKuB",
    "id" : 383035148188385280,
    "created_at" : "2013-09-26 01:07:50 +0000",
    "user" : {
      "name" : "Adorable Care Act",
      "screen_name" : "AdorableCareAct",
      "protected" : false,
      "id_str" : "1886578915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463741009185079296\/-4wn6nF0_normal.jpeg",
      "id" : 1886578915,
      "verified" : false
    }
  },
  "id" : 383292281656061952,
  "created_at" : "2013-09-26 18:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383284869381357568\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4WHzlY2wC4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVGzjs5CQAA0Wmj.jpg",
      "id_str" : "383284869230379008",
      "id" : 383284869230379008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVGzjs5CQAA0Wmj.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4WHzlY2wC4"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GWYufFQtF1",
      "expanded_url" : "http:\/\/go.wh.gov\/JMugms",
      "display_url" : "go.wh.gov\/JMugms"
    } ]
  },
  "geo" : { },
  "id_str" : "383284869381357568",
  "text" : "Thanks to #Obamacare, a 27-year-old making $25,000 can #GetCovered for less than $100\/month: http:\/\/t.co\/GWYufFQtF1, http:\/\/t.co\/4WHzlY2wC4",
  "id" : 383284869381357568,
  "created_at" : "2013-09-26 17:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adorable Care Act",
      "screen_name" : "AdorableCareAct",
      "indices" : [ 99, 115 ],
      "id_str" : "1886578915",
      "id" : 1886578915
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/383273773824086017\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ToSlV7fz0l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVGpd3TCEAER-qH.jpg",
      "id_str" : "383273773828280321",
      "id" : 383273773828280321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVGpd3TCEAER-qH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ToSlV7fz0l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383273773824086017",
  "text" : "Take it from this guy: Insurance companies can no longer put lifetime limits on your coverage (h\/t @AdorableCareAct) http:\/\/t.co\/ToSlV7fz0l",
  "id" : 383273773824086017,
  "created_at" : "2013-09-26 16:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 60, 71 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "383255584302067712",
  "text" : "President Obama: \u201CLet\u2019s help make sure our fellow Americans #GetCovered.\u201D http:\/\/t.co\/GNfbftrfo3 #Obamacare",
  "id" : 383255584302067712,
  "created_at" : "2013-09-26 15:43:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnoughAlready",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383254083949170688",
  "text" : "President Obama: \"I won\u2019t negotiate on anything when it comes to the full faith and credit of the United States of America.\" #EnoughAlready",
  "id" : 383254083949170688,
  "created_at" : "2013-09-26 15:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383253907704528896",
  "text" : "RT @WHLive: Obama: \"We are not a deadbeat nation. We don\u2019t run out on our tab. We are the world\u2019s bedrock investment...you don't mess with \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383253871713210368",
    "text" : "Obama: \"We are not a deadbeat nation. We don\u2019t run out on our tab. We are the world\u2019s bedrock investment...you don't mess with that.\"",
    "id" : 383253871713210368,
    "created_at" : "2013-09-26 15:36:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 383253907704528896,
  "created_at" : "2013-09-26 15:37:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383253584986398722",
  "text" : "Obama: \"As for not letting America pay its bills...no Congress before this one has ever been irresponsible enough to threaten default.\"",
  "id" : 383253584986398722,
  "created_at" : "2013-09-26 15:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383251977502588928",
  "text" : "Obama: \"Republicans\u2019 biggest fear is not that the Affordable Care Act will fail\u2014it\u2019s that the Affordable Care Act will succeed.\" #Obamacare",
  "id" : 383251977502588928,
  "created_at" : "2013-09-26 15:29:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "383251016897933312",
  "text" : "Obama: \"Tell your friends, tell your classmates, and tell your family members about their new health care choices.\" http:\/\/t.co\/GNfbftrfo3",
  "id" : 383251016897933312,
  "created_at" : "2013-09-26 15:25:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383250595366178816",
  "text" : "President Obama on #Obamacare: \"Not only will it help lower costs for businesses, but it will free up entrepreneurship in this country.\"",
  "id" : 383250595366178816,
  "created_at" : "2013-09-26 15:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383249382453157889",
  "text" : "\"Since I signed the Affordable Care Act into law, we\u2019ve seen the slowest growth in health care costs on record.\" \u2014President Obama #Obamacare",
  "id" : 383249382453157889,
  "created_at" : "2013-09-26 15:19:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383248914687590401",
  "text" : "President Obama: \"All told, nearly 6 in 10 Americans without health insurance today will be able to #GetCovered for $100 or less.\"",
  "id" : 383248914687590401,
  "created_at" : "2013-09-26 15:17:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 106, 116 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383248506611195904",
  "text" : "President Obama: \u201CThink about that: Good health insurance for the cost of your cell phone bill, or less.\u201D #Obamacare #GetCovered",
  "id" : 383248506611195904,
  "created_at" : "2013-09-26 15:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383248216306622465",
  "text" : "Obama: \"Here in Maryland, an average 25 year-old making $25,000 a year could get covered for as little as $80 a month.\" #GetCovered",
  "id" : 383248216306622465,
  "created_at" : "2013-09-26 15:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 103, 113 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383247735782006785",
  "text" : "President Obama: \"If you\u2019re a young adult or an entrepreneur striking out on your own\u2014you\u2019re covered.\" #Obamacare #GetCovered",
  "id" : 383247735782006785,
  "created_at" : "2013-09-26 15:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383247159400734721",
  "text" : "President Obama: \"If you couldn\u2019t afford coverage for your child because he has asthma\u2014he\u2019s covered.\" #Obamacare",
  "id" : 383247159400734721,
  "created_at" : "2013-09-26 15:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383246853233336321",
  "text" : "\"You\u2019ve got new choices, new competition, and many of you will have cheaper prices.\" \u2014President Obama on the #Obamacare marketplaces",
  "id" : 383246853233336321,
  "created_at" : "2013-09-26 15:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "383246553181208576",
  "text" : "Obama: \"On Tuesday, every American can visit http:\/\/t.co\/GNfbftrfo3 to find what\u2019s called the health insurance marketplace.\" #GetCovered",
  "id" : 383246553181208576,
  "created_at" : "2013-09-26 15:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FactsOnly",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383245769639067648",
  "text" : "President Obama: \"On January 1st, [insurance companies] won\u2019t be able to charge women more just because they're women.\" #FactsOnly",
  "id" : 383245769639067648,
  "created_at" : "2013-09-26 15:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 23, 27 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383245365111033856",
  "text" : "Obama: \"Because of the #ACA, 3 million young adults under age 26 have gained coverage by staying on their parents\u2019 plan.\" #Obamacare",
  "id" : 383245365111033856,
  "created_at" : "2013-09-26 15:03:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383245189214502912",
  "text" : "Obama: \"Because of the #ACA, more than 100 million Americans have gotten free preventive care like mammograms...with no copays.\"",
  "id" : 383245189214502912,
  "created_at" : "2013-09-26 15:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383244627190353920",
  "text" : "Obama: \"On Oct 1st, millions of Americans who don\u2019t have health insurance...will finally be able to buy quality affordable health insurance\"",
  "id" : 383244627190353920,
  "created_at" : "2013-09-26 15:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383244340455170049\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/fuISaDCQfe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVGOsmwCYAIwTbk.jpg",
      "id_str" : "383244340270620674",
      "id" : 383244340270620674,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVGOsmwCYAIwTbk.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fuISaDCQfe"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383244340455170049",
  "text" : "Obama: \"The #ACA passed both houses of Congress. I signed it into law. The Supreme Court ruled it Constitutional.\" http:\/\/t.co\/fuISaDCQfe",
  "id" : 383244340455170049,
  "created_at" : "2013-09-26 14:59:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383243977706586112",
  "text" : "President Obama: \"In the United States of America, health care is not a privilege for a fortunate few\u2014it is a right.\" #Obamacare",
  "id" : 383243977706586112,
  "created_at" : "2013-09-26 14:57:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383243739935678464",
  "text" : "\"In the wealthiest nation on Earth, no one should go broke just because they get sick.\" \u2014President Obama on why he fought to pass #Obamacare",
  "id" : 383243739935678464,
  "created_at" : "2013-09-26 14:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383243625322139648",
  "text" : "President Obama: \"I remembered the fear Michelle and I felt when Sasha was a few months old, and she got meningitis.\" #Obamacare",
  "id" : 383243625322139648,
  "created_at" : "2013-09-26 14:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383243501300772864",
  "text" : "President Obama: \"I remembered my mother worrying about how she was going to deal with her finances when she got very sick.\" #Obamacare",
  "id" : 383243501300772864,
  "created_at" : "2013-09-26 14:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383243081044078592",
  "text" : "Obama: \"For a long time, America was the only advanced economy in the world where health care was not a right, but a privilege.\" #Obamacare",
  "id" : 383243081044078592,
  "created_at" : "2013-09-26 14:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 90, 100 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QAhRVNnBbz",
      "expanded_url" : "http:\/\/go.wh.gov\/FRw5vS",
      "display_url" : "go.wh.gov\/FRw5vS"
    } ]
  },
  "geo" : { },
  "id_str" : "383242466209431552",
  "text" : "Right now: President Obama speaks on the Affordable Care Act \u2014&gt; http:\/\/t.co\/QAhRVNnBbz #Obamacare #GetCovered",
  "id" : 383242466209431552,
  "created_at" : "2013-09-26 14:51:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/QAhRVNnBbz",
      "expanded_url" : "http:\/\/go.wh.gov\/FRw5vS",
      "display_url" : "go.wh.gov\/FRw5vS"
    } ]
  },
  "geo" : { },
  "id_str" : "383238109724307457",
  "text" : "Don't miss President Obama's speech on the Affordable Care Act at 11am ET \u2014&gt; http:\/\/t.co\/QAhRVNnBbz #GetCovered #Obamacare",
  "id" : 383238109724307457,
  "created_at" : "2013-09-26 14:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383226896986546176",
  "text" : "RT @Jordan44: News you can use! ---&gt; Strong opposition to GOP using shutdown threats to get their way (80% oppose, even 75% of Repubs!!) in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383211199028293632",
    "text" : "News you can use! ---&gt; Strong opposition to GOP using shutdown threats to get their way (80% oppose, even 75% of Repubs!!) in NYT\/CBS poll",
    "id" : 383211199028293632,
    "created_at" : "2013-09-26 12:47:24 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 383226896986546176,
  "created_at" : "2013-09-26 13:49:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 93, 98 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 105, 112 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383222841967001600",
  "text" : "RT @Cabinet: Obama agencies working together to save lives. Amazing new lifesaving tool from @NASA &amp; @DHSgov. WATCH: ---&gt; http:\/\/t.co\/aTcHF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 80, 85 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 92, 99 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/aTcHFTuN0D",
        "expanded_url" : "http:\/\/www.jpl.nasa.gov\/video\/index.php?id=1252",
        "display_url" : "jpl.nasa.gov\/video\/index.ph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383222038627745792",
    "text" : "Obama agencies working together to save lives. Amazing new lifesaving tool from @NASA &amp; @DHSgov. WATCH: ---&gt; http:\/\/t.co\/aTcHFTuN0D \u2026",
    "id" : 383222038627745792,
    "created_at" : "2013-09-26 13:30:28 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 383222841967001600,
  "created_at" : "2013-09-26 13:33:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 96, 106 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/iCQP2fda0n",
      "expanded_url" : "http:\/\/go.wh.gov\/5JGVdb",
      "display_url" : "go.wh.gov\/5JGVdb"
    } ]
  },
  "geo" : { },
  "id_str" : "383014074000216065",
  "text" : "High-quality, affordable health care for less than your cell phone bill: http:\/\/t.co\/iCQP2fda0n #Obamacare #GetCovered",
  "id" : 383014074000216065,
  "created_at" : "2013-09-25 23:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adorable Care Act",
      "screen_name" : "AdorableCareAct",
      "indices" : [ 99, 115 ],
      "id_str" : "1886578915",
      "id" : 1886578915
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/383001224334671875\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/abIY3BP3yO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVCxlZWCAAA_TEr.jpg",
      "id_str" : "383001224343060480",
      "id" : 383001224343060480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVCxlZWCAAA_TEr.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1021
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1021
      } ],
      "display_url" : "pic.twitter.com\/abIY3BP3yO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "383001224334671875",
  "text" : "Don't be a sad panda: You can get affordable health coverage in 5 days http:\/\/t.co\/GNfbftrfo3 (h\/t @AdorableCareAct) http:\/\/t.co\/abIY3BP3yO",
  "id" : 383001224334671875,
  "created_at" : "2013-09-25 22:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 88, 100 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/5IIMt1zkzy",
      "expanded_url" : "http:\/\/goo.gl\/IEnSIu",
      "display_url" : "goo.gl\/IEnSIu"
    } ]
  },
  "geo" : { },
  "id_str" : "382976247120146432",
  "text" : "RT @kerrywashington: An affordable new way to get healthcare opens 10\/1 thanks to Pres. @barackobama. Check out --&gt; http:\/\/t.co\/5IIMt1zkzy \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 67, 79 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/5IIMt1zkzy",
        "expanded_url" : "http:\/\/goo.gl\/IEnSIu",
        "display_url" : "goo.gl\/IEnSIu"
      } ]
    },
    "geo" : { },
    "id_str" : "382946459672674304",
    "text" : "An affordable new way to get healthcare opens 10\/1 thanks to Pres. @barackobama. Check out --&gt; http:\/\/t.co\/5IIMt1zkzy + #GetCovered.",
    "id" : 382946459672674304,
    "created_at" : "2013-09-25 19:15:25 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 382976247120146432,
  "created_at" : "2013-09-25 21:13:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Benjamin",
      "screen_name" : "SquarePeg_Dem",
      "indices" : [ 1, 15 ],
      "id_str" : "2171643931",
      "id" : 2171643931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/mzMjiX1rXm",
      "expanded_url" : "https:\/\/www.healthcare.gov\/marketplace\/individual\/#state=new-york",
      "display_url" : "healthcare.gov\/marketplace\/in\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "382947108606967808",
  "geo" : { },
  "id_str" : "382971504570269697",
  "in_reply_to_user_id" : 983419375,
  "text" : ".@SquarePeg_Dem Glad you asked, Michael. On Tues, here's where you can sign up for the plan that's right for you \u2014&gt; https:\/\/t.co\/mzMjiX1rXm",
  "id" : 382971504570269697,
  "in_reply_to_status_id" : 382947108606967808,
  "created_at" : "2013-09-25 20:54:56 +0000",
  "in_reply_to_screen_name" : "SquarePegDem",
  "in_reply_to_user_id_str" : "983419375",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eGkhNYSSxI",
      "expanded_url" : "http:\/\/apne.ws\/1dJtCaV",
      "display_url" : "apne.ws\/1dJtCaV"
    } ]
  },
  "geo" : { },
  "id_str" : "382953639779659777",
  "text" : "RT @Jordan44: Worth a RT: Some big CA news as bill to #raisethewage is signed ----&gt; http:\/\/t.co\/eGkhNYSSxI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 40, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/eGkhNYSSxI",
        "expanded_url" : "http:\/\/apne.ws\/1dJtCaV",
        "display_url" : "apne.ws\/1dJtCaV"
      } ]
    },
    "geo" : { },
    "id_str" : "382937097294077952",
    "text" : "Worth a RT: Some big CA news as bill to #raisethewage is signed ----&gt; http:\/\/t.co\/eGkhNYSSxI",
    "id" : 382937097294077952,
    "created_at" : "2013-09-25 18:38:13 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 382953639779659777,
  "created_at" : "2013-09-25 19:43:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthCareIsComing",
      "indices" : [ 122, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/M7U1eNvdvY",
      "expanded_url" : "http:\/\/at.wh.gov\/pd8be",
      "display_url" : "at.wh.gov\/pd8be"
    } ]
  },
  "geo" : { },
  "id_str" : "382942775915724800",
  "text" : "Starting Tuesday, 6 in 10 uninsured Americans can get health coverage for $100\/month or less \u2014&gt; http:\/\/t.co\/M7U1eNvdvY #HealthCareIsComing",
  "id" : 382942775915724800,
  "created_at" : "2013-09-25 19:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechvsTrafficking",
      "indices" : [ 99, 117 ]
    }, {
      "text" : "EndTrafficking",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/pXnWN3iOnY",
      "expanded_url" : "http:\/\/wh.gov\/lTc5e",
      "display_url" : "wh.gov\/lTc5e"
    } ]
  },
  "geo" : { },
  "id_str" : "382938762226847744",
  "text" : "RT @todd_park: Renewing the call to action to end human trafficking --&gt; http:\/\/t.co\/pXnWN3iOnY  #TechvsTrafficking #EndTrafficking",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TechvsTrafficking",
        "indices" : [ 84, 102 ]
      }, {
        "text" : "EndTrafficking",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/pXnWN3iOnY",
        "expanded_url" : "http:\/\/wh.gov\/lTc5e",
        "display_url" : "wh.gov\/lTc5e"
      } ]
    },
    "geo" : { },
    "id_str" : "382928853385371648",
    "text" : "Renewing the call to action to end human trafficking --&gt; http:\/\/t.co\/pXnWN3iOnY  #TechvsTrafficking #EndTrafficking",
    "id" : 382928853385371648,
    "created_at" : "2013-09-25 18:05:27 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 382938762226847744,
  "created_at" : "2013-09-25 18:44:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miami Herald",
      "screen_name" : "MiamiHerald",
      "indices" : [ 4, 16 ],
      "id_str" : "14085040",
      "id" : 14085040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/nTjBtKhQtJ",
      "expanded_url" : "http:\/\/hrld.us\/18Zd89m",
      "display_url" : "hrld.us\/18Zd89m"
    } ]
  },
  "geo" : { },
  "id_str" : "382931439601217536",
  "text" : "The @MiamiHerald on #Obamacare in Florida: \"More options &amp; lower premiums for consumers than originally projected \u2014&gt; http:\/\/t.co\/nTjBtKhQtJ",
  "id" : 382931439601217536,
  "created_at" : "2013-09-25 18:15:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382920121741611008\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/lfmtFJIbAp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVBn0l-CIAAyG4g.jpg",
      "id_str" : "382920121569648640",
      "id" : 382920121569648640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVBn0l-CIAAyG4g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/lfmtFJIbAp"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382920121741611008",
  "text" : "FACT: Thanks to #Obamacare, working families making $50,000 can get health insurance for less than $100\/month. http:\/\/t.co\/lfmtFJIbAp",
  "id" : 382920121741611008,
  "created_at" : "2013-09-25 17:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382912471524048897",
  "text" : "RT @jesseclee44: Wonder how Republicans would have reacted in 2007 if Pelosi told Bush she'd only allow debt ceiling hike with Affordable C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382907962978623488",
    "text" : "Wonder how Republicans would have reacted in 2007 if Pelosi told Bush she'd only allow debt ceiling hike with Affordable Care Act attached.",
    "id" : 382907962978623488,
    "created_at" : "2013-09-25 16:42:27 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 382912471524048897,
  "created_at" : "2013-09-25 17:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382908965543112704",
  "text" : "RT @Racusen44: What local media is covering: new data showing #ACA premiums will be affordable for consumers in their states --&gt; http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 47, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kw6wIgsuih",
        "expanded_url" : "http:\/\/www.politico.com\/blogs\/media\/2013\/09\/local-dailies-focus-less-on-cruz-more-on-obamacare-173492.html",
        "display_url" : "politico.com\/blogs\/media\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382895399888908289",
    "text" : "What local media is covering: new data showing #ACA premiums will be affordable for consumers in their states --&gt; http:\/\/t.co\/kw6wIgsuih",
    "id" : 382895399888908289,
    "created_at" : "2013-09-25 15:52:31 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 382908965543112704,
  "created_at" : "2013-09-25 16:46:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dallas Morning News",
      "screen_name" : "dallasnews",
      "indices" : [ 22, 33 ],
      "id_str" : "15679641",
      "id" : 15679641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4oZ9F0HVzD",
      "expanded_url" : "http:\/\/share.d-news.co\/4E66waE",
      "display_url" : "share.d-news.co\/4E66waE"
    } ]
  },
  "geo" : { },
  "id_str" : "382905517070249985",
  "text" : "Worth a read from the @DallasNews: #Obamacare premiums in Texas projected to be lower than expected \u2014&gt; http:\/\/t.co\/4oZ9F0HVzD #GetCovered",
  "id" : 382905517070249985,
  "created_at" : "2013-09-25 16:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 80, 91 ],
      "id_str" : "19247844",
      "id" : 19247844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 121, 132 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/An36OanFRY",
      "expanded_url" : "http:\/\/glmr.me\/15pNCPw",
      "display_url" : "glmr.me\/15pNCPw"
    } ]
  },
  "geo" : { },
  "id_str" : "382894948623724544",
  "text" : "Worth sharing: 5 things you need to know NOW about the Affordable Care Act from @GlamourMag \u2014&gt; http:\/\/t.co\/An36OanFRY #GetCovered #Obamacare",
  "id" : 382894948623724544,
  "created_at" : "2013-09-25 15:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382890439314907136",
  "text" : "RT @lacasablanca: In celebration of Hispanic Heritage Month, learn about the benefits of #Obamacare for young Latinos --&gt; http:\/\/t.co\/v9HQC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 71, 81 ]
      }, {
        "text" : "OurSalud",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/v9HQCK5Cfd",
        "expanded_url" : "http:\/\/at.wh.gov\/pcoup",
        "display_url" : "at.wh.gov\/pcoup"
      } ]
    },
    "geo" : { },
    "id_str" : "382885455496507394",
    "text" : "In celebration of Hispanic Heritage Month, learn about the benefits of #Obamacare for young Latinos --&gt; http:\/\/t.co\/v9HQCK5Cfd #OurSalud",
    "id" : 382885455496507394,
    "created_at" : "2013-09-25 15:13:00 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 382890439314907136,
  "created_at" : "2013-09-25 15:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382882731480199168\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VutUKKbtrv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVBF0NECMAATVkR.jpg",
      "id_str" : "382882731488587776",
      "id" : 382882731488587776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVBF0NECMAATVkR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VutUKKbtrv"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/xyXehcRJCX",
      "expanded_url" : "http:\/\/at.wh.gov\/pczfA",
      "display_url" : "at.wh.gov\/pczfA"
    } ]
  },
  "geo" : { },
  "id_str" : "382882731480199168",
  "text" : "RT to share how #Obamacare is making health insurance more affordable for young adults \u2014&gt; http:\/\/t.co\/xyXehcRJCX, http:\/\/t.co\/VutUKKbtrv",
  "id" : 382882731480199168,
  "created_at" : "2013-09-25 15:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qjKcu4Mztx",
      "expanded_url" : "http:\/\/at.wh.gov\/pckpO",
      "display_url" : "at.wh.gov\/pckpO"
    } ]
  },
  "geo" : { },
  "id_str" : "382875940742656000",
  "text" : "NEW REPORT: 95% of uninsured Americans will see lower than expected health care premiums with #Obamacare \u2014&gt; http:\/\/t.co\/qjKcu4Mztx",
  "id" : 382875940742656000,
  "created_at" : "2013-09-25 14:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382676634643353600\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/0fPnrKfq1k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU-KXygCUAAz56s.jpg",
      "id_str" : "382676634647547904",
      "id" : 382676634647547904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU-KXygCUAAz56s.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0fPnrKfq1k"
    } ],
    "hashtags" : [ {
      "text" : "CGI2013",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382676634643353600",
  "text" : "44 and 42 backstage at #CGI2013: http:\/\/t.co\/0fPnrKfq1k",
  "id" : 382676634643353600,
  "created_at" : "2013-09-25 01:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeDCListen",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382660657859928064",
  "text" : "#MakeDCListen to the 105 million Americans who can receive preventive care at no extra cost thanks to #Obamacare.",
  "id" : 382660657859928064,
  "created_at" : "2013-09-25 00:19:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeDCListen",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382650878726901761",
  "text" : "#MakeDCListen to the 6.3 million seniors who are paying less for prescription drugs thanks to #Obamacare.",
  "id" : 382650878726901761,
  "created_at" : "2013-09-24 23:40:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 44, 59 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2013",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382640231859494912",
  "text" : "RT @billclinton: Backstage at #CGI2013 with @HillaryClinton &amp; President Obama. Great discussion today on health care and the economy. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 27, 42 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/billclinton\/status\/382631951149957120\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/0IKUvr6DK7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BU9hu3hCAAM5Mzc.jpg",
        "id_str" : "382631951154151427",
        "id" : 382631951154151427,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU9hu3hCAAM5Mzc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0IKUvr6DK7"
      } ],
      "hashtags" : [ {
        "text" : "CGI2013",
        "indices" : [ 13, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382631951149957120",
    "text" : "Backstage at #CGI2013 with @HillaryClinton &amp; President Obama. Great discussion today on health care and the economy. http:\/\/t.co\/0IKUvr6DK7",
    "id" : 382631951149957120,
    "created_at" : "2013-09-24 22:25:40 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 382640231859494912,
  "created_at" : "2013-09-24 22:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382623808311414784",
  "text" : "President Obama on #Obamacare: \"It is a net reduction of our deficit\u2026if they repealed the law, it would add to the deficit.\"",
  "id" : 382623808311414784,
  "created_at" : "2013-09-24 21:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 96, 108 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382622265956769792",
  "text" : "\"In virtually every state, the average prices of insurance are coming in lower than expected.\" \u2014@BillClinton on the #Obamacare marketplaces",
  "id" : 382622265956769792,
  "created_at" : "2013-09-24 21:47:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382617536396664832",
  "text" : "Obama: \"When people...can get high-quality affordable health insurance for less than their cell phone bill, they're going to sign up.\"",
  "id" : 382617536396664832,
  "created_at" : "2013-09-24 21:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "382616563066470400",
  "text" : "Obama: \"On Oct. 1st, open enrollment begins. All these folks can start signing up for the marketplace.\" http:\/\/t.co\/GNfbftrfo3 #Obamacare",
  "id" : 382616563066470400,
  "created_at" : "2013-09-24 21:24:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382614560374411264",
  "text" : "Obama: \"We said to insurance companies, you've got to use at least 80% of your premium on actual health care\u2014not admin costs &amp; CEO bonuses.\"",
  "id" : 382614560374411264,
  "created_at" : "2013-09-24 21:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 37, 49 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "CGI2013",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/kW4LyAvnQO",
      "expanded_url" : "http:\/\/wh.gov\/CGI2013",
      "display_url" : "wh.gov\/CGI2013"
    } ]
  },
  "geo" : { },
  "id_str" : "382610682039902208",
  "text" : "Happening now: President Obama joins @BillClinton for a conversation on the benefits of #Obamacare \u2014&gt; http:\/\/t.co\/kW4LyAvnQO #CGI2013",
  "id" : 382610682039902208,
  "created_at" : "2013-09-24 21:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeDCListen",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382608049908617216",
  "text" : "#MakeDCListen to the millions of Americans with pre-existing conditions who won't be denied coverage thanks to #Obamacare.",
  "id" : 382608049908617216,
  "created_at" : "2013-09-24 20:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeDCListen",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382606793618124800",
  "text" : "#MakeDCListen to the 3.1 million young adults who can stay on their parents' health insurance plans thanks to #Obamacare.",
  "id" : 382606793618124800,
  "created_at" : "2013-09-24 20:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeDCListen",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382604321545678849",
  "text" : "#MakeDCListen to millions of American women who won't be charged more than men for the same coverage thanks to #Obamacare.",
  "id" : 382604321545678849,
  "created_at" : "2013-09-24 20:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382584102097936384\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8vaahScuJC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU82NrXCYAE_yHe.jpg",
      "id_str" : "382584101955330049",
      "id" : 382584101955330049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU82NrXCYAE_yHe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/8vaahScuJC"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 68, 79 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382584102097936384",
  "text" : "FACT: In 1 week, nearly 6 in 10 uninsured Americans will be able to #GetCovered for $100\/month or less. #Obamacare, http:\/\/t.co\/8vaahScuJC",
  "id" : 382584102097936384,
  "created_at" : "2013-09-24 19:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DefundObamacare",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382570082464829440",
  "text" : "#DefundObamacare if you believe women should be charged more than men for the same health coverage. #EnoughAlready",
  "id" : 382570082464829440,
  "created_at" : "2013-09-24 18:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "382564308594343936",
  "text" : "One week from today, millions of uninsured Americans can sign up for affordable health insurance \u2014&gt; http:\/\/t.co\/GNfbftrfo3 #Obamacare",
  "id" : 382564308594343936,
  "created_at" : "2013-09-24 17:56:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/vO4k1IhkoP",
      "expanded_url" : "http:\/\/wh.gov\/l2SSl",
      "display_url" : "wh.gov\/l2SSl"
    } ]
  },
  "geo" : { },
  "id_str" : "382550808794902528",
  "text" : "Great news: The Senate just confirmed the 1st openly gay judge to a U.S. Court of Appeals \u2014&gt; http:\/\/t.co\/vO4k1IhkoP #Equality",
  "id" : 382550808794902528,
  "created_at" : "2013-09-24 17:03:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382547284409323520",
  "text" : "RT @Schultz44: Senate just confirmed the 1st openly gay appellate judge in history. Latest in long list of this Prez's barrier-breaking jud\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382542701570187265",
    "text" : "Senate just confirmed the 1st openly gay appellate judge in history. Latest in long list of this Prez's barrier-breaking judicial nominees.",
    "id" : 382542701570187265,
    "created_at" : "2013-09-24 16:31:02 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 382547284409323520,
  "created_at" : "2013-09-24 16:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382537137070940160\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/wpYSomJr3B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU8Lf9kCIAAJOKf.jpg",
      "id_str" : "382537137079328768",
      "id" : 382537137079328768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU8Lf9kCIAAJOKf.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/wpYSomJr3B"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382537137070940160",
  "text" : "RT to share what #Obamacare benefits the House GOP is trying to take away from millions of Americans: http:\/\/t.co\/wpYSomJr3B",
  "id" : 382537137070940160,
  "created_at" : "2013-09-24 16:08:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    }, {
      "name" : "joanna coles",
      "screen_name" : "JoannaColes",
      "indices" : [ 20, 32 ],
      "id_str" : "20117790",
      "id" : 20117790
    }, {
      "name" : "Cosmopolitan",
      "screen_name" : "Cosmopolitan",
      "indices" : [ 117, 130 ],
      "id_str" : "23482952",
      "id" : 23482952
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 135, 140 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/apnYDoNgya",
      "expanded_url" : "http:\/\/www.cosmopolitan.com\/celebrity\/exclusive\/8-ways-women-benefit-from-obamacare",
      "display_url" : "cosmopolitan.com\/celebrity\/excl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382533795502518272",
  "text" : "RT @HealthCareTara: @JoannaColes Love these!  8 Ways Young Women Benefit From Obamacare http:\/\/t.co\/apnYDoNgya \u2026 via @Cosmopolitan CC: @vj44",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "joanna coles",
        "screen_name" : "JoannaColes",
        "indices" : [ 0, 12 ],
        "id_str" : "20117790",
        "id" : 20117790
      }, {
        "name" : "Cosmopolitan",
        "screen_name" : "Cosmopolitan",
        "indices" : [ 97, 110 ],
        "id_str" : "23482952",
        "id" : 23482952
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 115, 120 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/apnYDoNgya",
        "expanded_url" : "http:\/\/www.cosmopolitan.com\/celebrity\/exclusive\/8-ways-women-benefit-from-obamacare",
        "display_url" : "cosmopolitan.com\/celebrity\/excl\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "382512997882531840",
    "geo" : { },
    "id_str" : "382516720973279232",
    "in_reply_to_user_id" : 20117790,
    "text" : "@JoannaColes Love these!  8 Ways Young Women Benefit From Obamacare http:\/\/t.co\/apnYDoNgya \u2026 via @Cosmopolitan CC: @vj44",
    "id" : 382516720973279232,
    "in_reply_to_status_id" : 382512997882531840,
    "created_at" : "2013-09-24 14:47:47 +0000",
    "in_reply_to_screen_name" : "JoannaColes",
    "in_reply_to_user_id_str" : "20117790",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 382533795502518272,
  "created_at" : "2013-09-24 15:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "CNBC",
      "screen_name" : "CNBC",
      "indices" : [ 43, 48 ],
      "id_str" : "20402945",
      "id" : 20402945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382528274359808001",
  "text" : "RT @jearnest44: Bush OMB Dir. Nussle tells @CNBC that GOP budget brinkmanship abt politics NOT \"a positive plan to actually save the econom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNBC",
        "screen_name" : "CNBC",
        "indices" : [ 27, 32 ],
        "id_str" : "20402945",
        "id" : 20402945
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382525651443404801",
    "text" : "Bush OMB Dir. Nussle tells @CNBC that GOP budget brinkmanship abt politics NOT \"a positive plan to actually save the economy or create jobs\"",
    "id" : 382525651443404801,
    "created_at" : "2013-09-24 15:23:16 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 382528274359808001,
  "created_at" : "2013-09-24 15:33:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382518378151149569",
  "text" : "Obama: \"We are ready to meet tomorrow\u2019s challenges with you\u2014firm in the belief that all men and women are in fact created equal.\" #UNGA",
  "id" : 382518378151149569,
  "created_at" : "2013-09-24 14:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382517511180132353",
  "text" : "Obama: \"A child born anywhere on Earth today can do things that 60 years ago would have been out of reach for the mass of humanity.\" #UNGA",
  "id" : 382517511180132353,
  "created_at" : "2013-09-24 14:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382516369771622400",
  "text" : "Obama: \"We stand ready to do our part to prevent mass atrocities &amp; protect human rights. But we cannot &amp; should not bear that burden alone.\"",
  "id" : 382516369771622400,
  "created_at" : "2013-09-24 14:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382514319901986816",
  "text" : "\"Just as the Palestinian people must not be displaced, the state of Israel is here to stay.\" \u2014President Obama on a two-state solution #UNGA",
  "id" : 382514319901986816,
  "created_at" : "2013-09-24 14:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382513255521845248",
  "text" : "President Obama on Iran: \"I firmly believe the diplomatic path must be tested.\"",
  "id" : 382513255521845248,
  "created_at" : "2013-09-24 14:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382512891238174720",
  "text" : "President Obama: \"We are encouraged that President Rouhani received from the Iranian people a mandate to pursue a more moderate course.\"",
  "id" : 382512891238174720,
  "created_at" : "2013-09-24 14:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382512709817737216",
  "text" : "RT @WHLive: President Obama: \"We insist that the Iranian government meet its responsibilities under the Nuclear Non-Proliferation Treaty.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382512656671731713",
    "text" : "President Obama: \"We insist that the Iranian government meet its responsibilities under the Nuclear Non-Proliferation Treaty.\" #UNGA",
    "id" : 382512656671731713,
    "created_at" : "2013-09-24 14:31:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 382512709817737216,
  "created_at" : "2013-09-24 14:31:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382512118819352576",
  "text" : "Obama: \"America\u2019s diplomatic efforts will focus on two particular issues: Iran\u2019s pursuit of nuclear weapons, and the Arab-Israeli conflict.\"",
  "id" : 382512118819352576,
  "created_at" : "2013-09-24 14:29:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 123, 129 ]
    }, {
      "text" : "UNGA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382510814474674176",
  "text" : "Obama: \"If we succeed, it will send a powerful message that the use of chemical weapons has no place in the 21st century.\" #Syria #UNGA",
  "id" : 382510814474674176,
  "created_at" : "2013-09-24 14:24:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 120, 126 ]
    }, {
      "text" : "UNGA",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382510470143307777",
  "text" : "Obama: \"There must be a strong Security Council Resolution to verify that the Assad regime is keeping its commitments.\" #Syria #UNGA",
  "id" : 382510470143307777,
  "created_at" : "2013-09-24 14:22:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382510210440392706",
  "text" : "RT @WHLive: Obama: \"However, as I\u2019ve discussed with President Putin for over a year...my preference has always been a diplomatic resolution\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382510133286166529",
    "text" : "Obama: \"However, as I\u2019ve discussed with President Putin for over a year...my preference has always been a diplomatic resolution.\" #Syria",
    "id" : 382510133286166529,
    "created_at" : "2013-09-24 14:21:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 382510210440392706,
  "created_at" : "2013-09-24 14:21:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 69, 72 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382509999710146560",
  "text" : "President Obama on #Syria: \"Without a credible military threat, the [@UN] Security Council had demonstrated no inclination to act at all.\"",
  "id" : 382509999710146560,
  "created_at" : "2013-09-24 14:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382509866004144129",
  "text" : "Obama: \"It is an insult to...the legitimacy of this institution to suggest that anyone other than the regime carried out this attack\" #Syria",
  "id" : 382509866004144129,
  "created_at" : "2013-09-24 14:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "Syria",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382509680196468739",
  "text" : "RT @WHLive: President Obama: \"The evidence is overwhelming that the Assad regime used such weapons on August 21st.\" #UNGA #Syria",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 104, 109 ]
      }, {
        "text" : "Syria",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382509655458451458",
    "text" : "President Obama: \"The evidence is overwhelming that the Assad regime used such weapons on August 21st.\" #UNGA #Syria",
    "id" : 382509655458451458,
    "created_at" : "2013-09-24 14:19:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 382509680196468739,
  "created_at" : "2013-09-24 14:19:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "Syria",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382509523555979265",
  "text" : "President Obama: \"The ban against the use of chemical weapons, even in war, has been agreed to by 98% of humanity.\" #UNGA #Syria",
  "id" : 382509523555979265,
  "created_at" : "2013-09-24 14:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382509324930514944",
  "text" : "Obama: \"With respect to #Syria, we believe that as a starting point, the international community must enforce the ban on chemical weapons.\"",
  "id" : 382509324930514944,
  "created_at" : "2013-09-24 14:18:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382508202547359745",
  "text" : "President Obama: \"Today, all of our troops have left Iraq. Next year, an international coalition will end its war in Afghanistan.\" #UNGA",
  "id" : 382508202547359745,
  "created_at" : "2013-09-24 14:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382508071118839808",
  "text" : "Obama: \"We still have work to do together to assure that our citizens can access the opportunities that they need to thrive.\" #UNGA",
  "id" : 382508071118839808,
  "created_at" : "2013-09-24 14:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 45, 48 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "382507271650951168",
  "text" : "Happening now: President Obama addresses the @UN General Assembly \u2014&gt; http:\/\/t.co\/KvadYk9atb #UNGA",
  "id" : 382507271650951168,
  "created_at" : "2013-09-24 14:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 45, 48 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "382503266933690368",
  "text" : "Starting soon: President Obama addresses the @UN General Assembly. Watch here at 10:10am ET \u2014&gt; http:\/\/t.co\/KvadYk9atb #UNGA",
  "id" : 382503266933690368,
  "created_at" : "2013-09-24 13:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DefundObamacare",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382499385470226432",
  "text" : "#DefundObamacare if you want to prevent millions of uninsured Americans from getting affordable health insurance. #EnoughAlready",
  "id" : 382499385470226432,
  "created_at" : "2013-09-24 13:38:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382298024912756736\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/1NfH0iJRVt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU4yBzXCIAAzokH.jpg",
      "id_str" : "382298024921145344",
      "id" : 382298024921145344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU4yBzXCIAAzokH.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1NfH0iJRVt"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/CCCCcHoJTl",
      "expanded_url" : "http:\/\/at.wh.gov\/p91g0",
      "display_url" : "at.wh.gov\/p91g0"
    } ]
  },
  "geo" : { },
  "id_str" : "382298024912756736",
  "text" : "Never bet against the American worker: http:\/\/t.co\/CCCCcHoJTl #MadeInAmerica, http:\/\/t.co\/1NfH0iJRVt",
  "id" : 382298024912756736,
  "created_at" : "2013-09-24 00:18:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382274594251345921",
  "text" : "FACT: 100 days from now, insurance companies won't be able to limit your lifetime coverage for essential health benefits. #Obamacare",
  "id" : 382274594251345921,
  "created_at" : "2013-09-23 22:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382267046840369152",
  "text" : "FACT: In 100 days, health insurance companies won't be able to deny you coverage if you have a pre-existing condition. #Obamacare",
  "id" : 382267046840369152,
  "created_at" : "2013-09-23 22:15:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FvoMPCnw63",
      "expanded_url" : "http:\/\/wh.gov\/l2Hm4",
      "display_url" : "wh.gov\/l2Hm4"
    } ]
  },
  "geo" : { },
  "id_str" : "382259100198764544",
  "text" : "In one week, millions of uninsured Americans can sign up for affordable health care. In 100 days, they'll be covered: http:\/\/t.co\/FvoMPCnw63",
  "id" : 382259100198764544,
  "created_at" : "2013-09-23 21:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecKerry",
      "indices" : [ 15, 24 ]
    }, {
      "text" : "Instagram",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/z1D405wnGB",
      "expanded_url" : "http:\/\/instagram.com\/statedept",
      "display_url" : "instagram.com\/statedept"
    } ]
  },
  "geo" : { },
  "id_str" : "382243235940151296",
  "text" : "RT @StateDept: #SecKerry: \"Finally, the State Department is on #Instagram!\"  Follow us around the world at http:\/\/t.co\/z1D405wnGB.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecKerry",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "Instagram",
        "indices" : [ 48, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/z1D405wnGB",
        "expanded_url" : "http:\/\/instagram.com\/statedept",
        "display_url" : "instagram.com\/statedept"
      } ]
    },
    "geo" : { },
    "id_str" : "382234711759650816",
    "text" : "#SecKerry: \"Finally, the State Department is on #Instagram!\"  Follow us around the world at http:\/\/t.co\/z1D405wnGB.",
    "id" : 382234711759650816,
    "created_at" : "2013-09-23 20:07:11 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 382243235940151296,
  "created_at" : "2013-09-23 20:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 127, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/bM4eGoQacd",
      "expanded_url" : "http:\/\/urbn.is\/1aZCbgx",
      "display_url" : "urbn.is\/1aZCbgx"
    } ]
  },
  "geo" : { },
  "id_str" : "382233076857708544",
  "text" : "The GOP plan to delay #Obamacare would raise premiums and decrease coverage by 11 million in 2014 \u2014&gt; http:\/\/t.co\/bM4eGoQacd #EnoughAlready",
  "id" : 382233076857708544,
  "created_at" : "2013-09-23 20:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Lowrey",
      "screen_name" : "AnnieLowrey",
      "indices" : [ 3, 15 ],
      "id_str" : "37281592",
      "id" : 37281592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382223223191904256",
  "text" : "RT @AnnieLowrey: Delaying the individual mandate by a year would raise premiums, decrease coverage by 11 million in 2014: http:\/\/t.co\/7kWbk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/7kWbkFRqJi",
        "expanded_url" : "http:\/\/www.urban.org\/UploadedPDF\/412902-Delaying-the-Individual-Mandate-Would-Disrupt-Overall-Implementation-of-the-Affordable-Care-Act.pdf",
        "display_url" : "urban.org\/UploadedPDF\/41\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382215410860306432",
    "text" : "Delaying the individual mandate by a year would raise premiums, decrease coverage by 11 million in 2014: http:\/\/t.co\/7kWbkFRqJi",
    "id" : 382215410860306432,
    "created_at" : "2013-09-23 18:50:29 +0000",
    "user" : {
      "name" : "Annie Lowrey",
      "screen_name" : "AnnieLowrey",
      "protected" : false,
      "id_str" : "37281592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546022287531454464\/jTRRNz_Q_normal.jpeg",
      "id" : 37281592,
      "verified" : true
    }
  },
  "id" : 382223223191904256,
  "created_at" : "2013-09-23 19:21:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/I77kduAfJn",
      "expanded_url" : "http:\/\/at.wh.gov\/p8ryc",
      "display_url" : "at.wh.gov\/p8ryc"
    } ]
  },
  "geo" : { },
  "id_str" : "382221744443891715",
  "text" : "Find out about your state's #Obamacare marketplace where you can compare your options &amp; #GetCovered starting Oct 1st: http:\/\/t.co\/I77kduAfJn",
  "id" : 382221744443891715,
  "created_at" : "2013-09-23 19:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382210812737093632\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/oEvMfGENg1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3itX_CIAEAZoY.jpg",
      "id_str" : "382210812556746753",
      "id" : 382210812556746753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3itX_CIAEAZoY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/oEvMfGENg1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382210812737093632",
  "text" : "The House GOP should stop trying to prevent millions from getting health insurance &amp; start helping the middle class: http:\/\/t.co\/oEvMfGENg1",
  "id" : 382210812737093632,
  "created_at" : "2013-09-23 18:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Yd5cuFy5q7",
      "expanded_url" : "http:\/\/wapo.st\/1fup6yK",
      "display_url" : "wapo.st\/1fup6yK"
    } ]
  },
  "geo" : { },
  "id_str" : "382196768701546496",
  "text" : "RT @jearnest44: Attn GOPers who want to cut spending: your plan to shutdown the govt costs more than $2B. http:\/\/t.co\/Yd5cuFy5q7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Yd5cuFy5q7",
        "expanded_url" : "http:\/\/wapo.st\/1fup6yK",
        "display_url" : "wapo.st\/1fup6yK"
      } ]
    },
    "geo" : { },
    "id_str" : "382187818178461696",
    "text" : "Attn GOPers who want to cut spending: your plan to shutdown the govt costs more than $2B. http:\/\/t.co\/Yd5cuFy5q7",
    "id" : 382187818178461696,
    "created_at" : "2013-09-23 17:00:51 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 382196768701546496,
  "created_at" : "2013-09-23 17:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/382187330603196416\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9uNiFwhr8Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU3NWi6CIAAjyMq.jpg",
      "id_str" : "382187330607390720",
      "id" : 382187330607390720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU3NWi6CIAAjyMq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/9uNiFwhr8Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "382187330603196416",
  "text" : "RT so your friends know where they can get affordable health insurance starting next Tuesday: http:\/\/t.co\/GNfbftrfo3 http:\/\/t.co\/9uNiFwhr8Q",
  "id" : 382187330603196416,
  "created_at" : "2013-09-23 16:58:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "382176012903006208",
  "text" : "\"We can't rest until every American knows the security of quality, affordable health care.\" \u2014Obama: http:\/\/t.co\/GNfbftrfo3 #GetCovered",
  "id" : 382176012903006208,
  "created_at" : "2013-09-23 16:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 90, 100 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/7CPzegiZGJ",
      "expanded_url" : "http:\/\/fw.to\/0OolpuW",
      "display_url" : "fw.to\/0OolpuW"
    } ]
  },
  "geo" : { },
  "id_str" : "382166150437556225",
  "text" : "Americans oppose the reckless House GOP plan to shut down the government unless we defund #Obamacare: http:\/\/t.co\/7CPzegiZGJ #EnoughAlready",
  "id" : 382166150437556225,
  "created_at" : "2013-09-23 15:34:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382148534469795842",
  "text" : "RT @Jordan44: More bad news for reckless GOP plan to push econ to the brink: only 19% support shutdown\/default over #Obamacare in CNBC poll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "382123722418946048",
    "text" : "More bad news for reckless GOP plan to push econ to the brink: only 19% support shutdown\/default over #Obamacare in CNBC poll",
    "id" : 382123722418946048,
    "created_at" : "2013-09-23 12:46:09 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 382148534469795842,
  "created_at" : "2013-09-23 14:24:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "381864653493518336",
  "text" : "At 5pm ET, President Obama speaks at the memorial service for victims of the Navy Yard shooting. Watch here \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 381864653493518336,
  "created_at" : "2013-09-22 19:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dUXV7eDLay",
      "expanded_url" : "http:\/\/at.wh.gov\/p4aNB",
      "display_url" : "at.wh.gov\/p4aNB"
    } ]
  },
  "geo" : { },
  "id_str" : "381447874908663808",
  "text" : "Obama: \"After 5 years spent digging out of crisis, the last thing we need is for Washington to manufacture another.\" http:\/\/t.co\/dUXV7eDLay",
  "id" : 381447874908663808,
  "created_at" : "2013-09-21 16:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/dUXV7eDLay",
      "expanded_url" : "http:\/\/at.wh.gov\/p4aNB",
      "display_url" : "at.wh.gov\/p4aNB"
    } ]
  },
  "geo" : { },
  "id_str" : "381417676213473282",
  "text" : "\"I will not negotiate over the full faith and credit of the United States.\" \u2014Obama on raising the debt ceiling: http:\/\/t.co\/dUXV7eDLay",
  "id" : 381417676213473282,
  "created_at" : "2013-09-21 14:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/381192373348208640\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/irdMpijVeq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUpEcaTCEAAMAuB.jpg",
      "id_str" : "381192373352402944",
      "id" : 381192373352402944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUpEcaTCEAAMAuB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/irdMpijVeq"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381192373348208640",
  "text" : "RT if you agree: It's time for Washington to focus on building #ABetterBargain for the middle class. http:\/\/t.co\/irdMpijVeq",
  "id" : 381192373348208640,
  "created_at" : "2013-09-20 23:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 7, 15 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 85, 95 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksMacon",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/zq8dKSQCWl",
      "expanded_url" : "http:\/\/wapo.st\/1bu8UgX",
      "display_url" : "wapo.st\/1bu8UgX"
    } ]
  },
  "geo" : { },
  "id_str" : "381186884644265985",
  "text" : "Follow @Macon44 for all things digital as he transitions from the White House to the @StateDept \u2014&gt; http:\/\/t.co\/zq8dKSQCWl #ThanksMacon",
  "id" : 381186884644265985,
  "created_at" : "2013-09-20 22:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 48, 59 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Int'l Info Programs",
      "screen_name" : "IIPState",
      "indices" : [ 130, 139 ],
      "id_str" : "258972713",
      "id" : 258972713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381186665554771968",
  "text" : "RT @macon44: Couldn't describe honor of serving @WhiteHouse in 140 chars (or 14,000!). Buckle up, b\/c this acct is coming w\/me to @IIPState\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 35, 46 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Int'l Info Programs",
        "screen_name" : "IIPState",
        "indices" : [ 117, 126 ],
        "id_str" : "258972713",
        "id" : 258972713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StayTuned",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381186486680305664",
    "text" : "Couldn't describe honor of serving @WhiteHouse in 140 chars (or 14,000!). Buckle up, b\/c this acct is coming w\/me to @IIPState #StayTuned",
    "id" : 381186486680305664,
    "created_at" : "2013-09-20 22:41:55 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 381186665554771968,
  "created_at" : "2013-09-20 22:42:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381122534306893824",
  "text" : "\"I will not negotiate over the full faith and credit of the United States.\" \u2014President Obama on raising the debt ceiling",
  "id" : 381122534306893824,
  "created_at" : "2013-09-20 18:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381122045267808257",
  "text" : "President Obama: \"The United States of America is not a deadbeat nation\u2026we don\u2019t run out on our tab. We are the world\u2019s bedrock investment.\"",
  "id" : 381122045267808257,
  "created_at" : "2013-09-20 18:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381121715301924864",
  "text" : "Obama on #Obamacare: \u201CThe guy who was running against me said he was going to repeal it. We won. The voters were pretty clear about this.\u201D",
  "id" : 381121715301924864,
  "created_at" : "2013-09-20 18:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381120965372952577",
  "text" : "President Obama on raising the debt ceiling: \"Once you've bought the truck, you can't say you're saving money by not paying the bills.\"",
  "id" : 381120965372952577,
  "created_at" : "2013-09-20 18:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381120118039654401",
  "text" : "Obama: \"Our deficits are now coming down so quickly that by the end of this year, we\u2019ll have cut them by more than half since I took office\"",
  "id" : 381120118039654401,
  "created_at" : "2013-09-20 18:18:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381118953520496641",
  "text" : "President Obama on Congress: \"They're focused on politics. They're focused on trying to mess with me. They're not focused on you.\"",
  "id" : 381118953520496641,
  "created_at" : "2013-09-20 18:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381117909356929024",
  "text" : "Obama: \"We need to work even harder to rebuild an economy that grows not from the top-down, but from the middle class out.\" #ABetterBargain",
  "id" : 381117909356929024,
  "created_at" : "2013-09-20 18:09:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381117506393354240",
  "text" : "Obama on Oct 1st: \"Millions of Americans who\u2019ve been locked out of the insurance market will finally be able to afford quality health care.\"",
  "id" : 381117506393354240,
  "created_at" : "2013-09-20 18:07:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381116697840603136",
  "text" : "Obama: \"Look at what\u2019s going on right here in this plant. The new F-150 is built tougher than ever and more fuel efficient.\" #MadeInAmerica",
  "id" : 381116697840603136,
  "created_at" : "2013-09-20 18:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381116372232568832",
  "text" : "President Obama: \"The American auto industry has come roaring back.\" #MadeInAmerica",
  "id" : 381116372232568832,
  "created_at" : "2013-09-20 18:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "381114492215513088",
  "text" : "Happening now: President Obama speaks at a Ford plant in Missouri on building #ABetterBargain for the middle class \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 381114492215513088,
  "created_at" : "2013-09-20 17:55:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381109386208227328",
  "text" : "Defund #Obamacare if you want more than 3.1 million young adults on their parents' plans to lose their health insurance. #EnoughAlready",
  "id" : 381109386208227328,
  "created_at" : "2013-09-20 17:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381106867692240896",
  "text" : "Defund #Obamacare if you want 105 million Americans to pay more for preventive care like mammograms and cancer screenings. #EnoughAlready",
  "id" : 381106867692240896,
  "created_at" : "2013-09-20 17:25:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381104353563508737",
  "text" : "Defund #Obamacare if you believe women should be charged more than men for the same health coverage. #EnoughAlready",
  "id" : 381104353563508737,
  "created_at" : "2013-09-20 17:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "EnoughAlready",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381101992027754496",
  "text" : "Defund #Obamacare if you want to prevent millions of uninsured Americans from getting affordable health insurance. #EnoughAlready",
  "id" : 381101992027754496,
  "created_at" : "2013-09-20 17:06:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "Noticias Telemundo",
      "screen_name" : "TelemundoNews",
      "indices" : [ 40, 54 ],
      "id_str" : "152142811",
      "id" : 152142811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381092319358771201",
  "text" : "RT @Cecilia44: As the President said on @TelemundoNews, if the Speaker brings up #immigration reform tomorrow, it passes. WIth or without g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Noticias Telemundo",
        "screen_name" : "TelemundoNews",
        "indices" : [ 25, 39 ],
        "id_str" : "152142811",
        "id" : 152142811
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 66, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381091086766071809",
    "text" : "As the President said on @TelemundoNews, if the Speaker brings up #immigration reform tomorrow, it passes. WIth or without gang of 7 bill.",
    "id" : 381091086766071809,
    "created_at" : "2013-09-20 16:22:50 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 381092319358771201,
  "created_at" : "2013-09-20 16:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "381091223378735106",
  "text" : "Don't miss Obama's 1:50pm ET speech at a Ford plant in Missouri on building #ABetterBargain for the middle class \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 381091223378735106,
  "created_at" : "2013-09-20 16:23:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381083628366614530",
  "text" : "RT @Jordan44: GOP obsessions to sabotage #Obamacare (23% approve in Pew) and shutdown govt to defund it (27% approve in WaPo\/ABC) had bruta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 27, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381081714879381504",
    "text" : "GOP obsessions to sabotage #Obamacare (23% approve in Pew) and shutdown govt to defund it (27% approve in WaPo\/ABC) had brutal polling week",
    "id" : 381081714879381504,
    "created_at" : "2013-09-20 15:45:35 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 381083628366614530,
  "created_at" : "2013-09-20 15:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 22, 30 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 129, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/oh9Va9xpuP",
      "expanded_url" : "https:\/\/vine.co\/v\/hvTpQaELLPH",
      "display_url" : "vine.co\/v\/hvTpQaELLPH"
    } ]
  },
  "geo" : { },
  "id_str" : "381078487936684033",
  "text" : "For our kids' health, @GinaEPA signed the proposed carbon pollution standards for new power plants \u2014&gt; https:\/\/t.co\/oh9Va9xpuP #ActOnClimate",
  "id" : 381078487936684033,
  "created_at" : "2013-09-20 15:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/381072892345069569\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZuR5p4HQKI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUnXxs4CMAA5g0f.jpg",
      "id_str" : "381072892349263872",
      "id" : 381072892349263872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUnXxs4CMAA5g0f.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/ZuR5p4HQKI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381072892345069569",
  "text" : "Alanah Poullard\u2014the 5-year-old daughter of a wounded warrior\u2014gets a written school excuse note from President Obama: http:\/\/t.co\/ZuR5p4HQKI",
  "id" : 381072892345069569,
  "created_at" : "2013-09-20 15:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "Fairness",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/NTtYveyEuO",
      "expanded_url" : "http:\/\/wh.gov\/gCN",
      "display_url" : "wh.gov\/gCN"
    } ]
  },
  "geo" : { },
  "id_str" : "381059757110353920",
  "text" : "RT @Inouye44: Two years ago today, \u2018Don\u2019t Ask, Don\u2019t Tell\u2019 was finally and formally repealed. http:\/\/t.co\/NTtYveyEuO #Equality #Fairness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Equality",
        "indices" : [ 103, 112 ]
      }, {
        "text" : "Fairness",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/NTtYveyEuO",
        "expanded_url" : "http:\/\/wh.gov\/gCN",
        "display_url" : "wh.gov\/gCN"
      } ]
    },
    "geo" : { },
    "id_str" : "381052895077990400",
    "text" : "Two years ago today, \u2018Don\u2019t Ask, Don\u2019t Tell\u2019 was finally and formally repealed. http:\/\/t.co\/NTtYveyEuO #Equality #Fairness",
    "id" : 381052895077990400,
    "created_at" : "2013-09-20 13:51:04 +0000",
    "user" : {
      "name" : "Shin Inouye",
      "screen_name" : "InouyeUSCIS",
      "protected" : false,
      "id_str" : "1702571186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667848615780446208\/1LoEXwfW_normal.jpg",
      "id" : 1702571186,
      "verified" : true
    }
  },
  "id" : 381059757110353920,
  "created_at" : "2013-09-20 14:18:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ZGL7Rd82mV",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/gina-mccarthy\/time-to-act-on-climate-change_b_3954969.html",
      "display_url" : "huffingtonpost.com\/gina-mccarthy\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381048465205112834",
  "text" : "RT @GinaEPA: Read my op-ed on why we must #ActOnClimate now for the health and well-being of our children: http:\/\/t.co\/ZGL7Rd82mV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 29, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ZGL7Rd82mV",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/gina-mccarthy\/time-to-act-on-climate-change_b_3954969.html",
        "display_url" : "huffingtonpost.com\/gina-mccarthy\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381025190236258304",
    "text" : "Read my op-ed on why we must #ActOnClimate now for the health and well-being of our children: http:\/\/t.co\/ZGL7Rd82mV",
    "id" : 381025190236258304,
    "created_at" : "2013-09-20 12:00:59 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 381048465205112834,
  "created_at" : "2013-09-20 13:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380847838113964032",
  "text" : "RT @jesseclee44: \"One of those people on food stamps could live a year on what this congressman spent on food &amp; lodging for six days\" http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/63sTcTMESB",
        "expanded_url" : "http:\/\/thelead.blogs.cnn.com\/2013\/09\/19\/congresswoman-outs-gop-saying-they-slash-food-stamps-while-dining-out\/",
        "display_url" : "thelead.blogs.cnn.com\/2013\/09\/19\/con\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380844643669536768",
    "text" : "\"One of those people on food stamps could live a year on what this congressman spent on food &amp; lodging for six days\" http:\/\/t.co\/63sTcTMESB",
    "id" : 380844643669536768,
    "created_at" : "2013-09-20 00:03:33 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 380847838113964032,
  "created_at" : "2013-09-20 00:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/uTXlPUyF8n",
      "expanded_url" : "http:\/\/at.wh.gov\/p2pLl",
      "display_url" : "at.wh.gov\/p2pLl"
    } ]
  },
  "geo" : { },
  "id_str" : "380843403463774208",
  "text" : "President Obama: \"America now exports more to the rest of the world than ever before.\" http:\/\/t.co\/uTXlPUyF8n #MadeInAmerica",
  "id" : 380843403463774208,
  "created_at" : "2013-09-19 23:58:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 36, 44 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Philip Rucker",
      "screen_name" : "PhilipRucker",
      "indices" : [ 110, 123 ],
      "id_str" : "59331128",
      "id" : 59331128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380837349875142656",
  "text" : "RT @jearnest44: We're going to miss @macon44 but he's got a cool and important new gig at the State Dept. per @philiprucker http:\/\/t.co\/qRQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 20, 28 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      }, {
        "name" : "Philip Rucker",
        "screen_name" : "PhilipRucker",
        "indices" : [ 94, 107 ],
        "id_str" : "59331128",
        "id" : 59331128
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/qRQFPa6Wel",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/politics\/obamas-digital-guru-to-revamp-digital-diplomacy-at-state-department\/2013\/09\/19\/9dee2e5e-212c-11e3-b73c-aab60bf735d0_story.html#",
        "display_url" : "washingtonpost.com\/politics\/obama\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380829867689771008",
    "text" : "We're going to miss @macon44 but he's got a cool and important new gig at the State Dept. per @philiprucker http:\/\/t.co\/qRQFPa6Wel",
    "id" : 380829867689771008,
    "created_at" : "2013-09-19 23:04:50 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 380837349875142656,
  "created_at" : "2013-09-19 23:34:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380822211612782592",
  "text" : "RT @Lehrich44: Guess the one thing House GOP can agree on is that we're helping too many hungry people put food on the table.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380821501601005568",
    "text" : "Guess the one thing House GOP can agree on is that we're helping too many hungry people put food on the table.",
    "id" : 380821501601005568,
    "created_at" : "2013-09-19 22:31:35 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 380822211612782592,
  "created_at" : "2013-09-19 22:34:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 19, 35 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/0rhI1KOBvP",
      "expanded_url" : "http:\/\/youtu.be\/RwlhUcSGqgs",
      "display_url" : "youtu.be\/RwlhUcSGqgs"
    } ]
  },
  "geo" : { },
  "id_str" : "380819357128855555",
  "text" : "RT @FLOTUS: Thanks @IAmKidPresident for inspiring teachers and students to make the world more awesome! http:\/\/t.co\/0rhI1KOBvP \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kid President",
        "screen_name" : "iamkidpresident",
        "indices" : [ 7, 23 ],
        "id_str" : "627799297",
        "id" : 627799297
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/0rhI1KOBvP",
        "expanded_url" : "http:\/\/youtu.be\/RwlhUcSGqgs",
        "display_url" : "youtu.be\/RwlhUcSGqgs"
      } ]
    },
    "geo" : { },
    "id_str" : "380801163592863745",
    "text" : "Thanks @IAmKidPresident for inspiring teachers and students to make the world more awesome! http:\/\/t.co\/0rhI1KOBvP \u2013mo",
    "id" : 380801163592863745,
    "created_at" : "2013-09-19 21:10:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 380819357128855555,
  "created_at" : "2013-09-19 22:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/GuzbTfS98j",
      "expanded_url" : "http:\/\/at.wh.gov\/p2bts",
      "display_url" : "at.wh.gov\/p2bts"
    } ]
  },
  "geo" : { },
  "id_str" : "380799467022082048",
  "text" : "On Oct 1, http:\/\/t.co\/GNfbftrfo3 will give Americans an easy new way to find affordable health insurance: http:\/\/t.co\/GuzbTfS98j #GetCovered",
  "id" : 380799467022082048,
  "created_at" : "2013-09-19 21:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 3, 14 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/380793532631355392\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KkVAZyAb30",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUjZsz3CUAAJLWu.jpg",
      "id_str" : "380793532371324928",
      "id" : 380793532371324928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUjZsz3CUAAJLWu.jpg",
      "sizes" : [ {
        "h" : 411,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1238,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1813,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KkVAZyAb30"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380797849530691584",
  "text" : "RT @USTreasury: #TBT President Reagan's Treasury Secretary on consequences of not raising the debt limit http:\/\/t.co\/KkVAZyAb30",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/380793532631355392\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/KkVAZyAb30",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUjZsz3CUAAJLWu.jpg",
        "id_str" : "380793532371324928",
        "id" : 380793532371324928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUjZsz3CUAAJLWu.jpg",
        "sizes" : [ {
          "h" : 411,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1238,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1813,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KkVAZyAb30"
      } ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380793532631355392",
    "text" : "#TBT President Reagan's Treasury Secretary on consequences of not raising the debt limit http:\/\/t.co\/KkVAZyAb30",
    "id" : 380793532631355392,
    "created_at" : "2013-09-19 20:40:27 +0000",
    "user" : {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "protected" : false,
      "id_str" : "120176950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461250108441370624\/-9PNMlfp_normal.jpeg",
      "id" : 120176950,
      "verified" : true
    }
  },
  "id" : 380797849530691584,
  "created_at" : "2013-09-19 20:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/TZ3aMXRV2O",
      "expanded_url" : "http:\/\/goo.gl\/QJ8hA2",
      "display_url" : "goo.gl\/QJ8hA2"
    } ]
  },
  "geo" : { },
  "id_str" : "380786823783411712",
  "text" : "RT @Cecilia44: Have to say, as a mom I don\u2019t much care for people trying to scam our kids into staying uninsured http:\/\/t.co\/TZ3aMXRV2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/TZ3aMXRV2O",
        "expanded_url" : "http:\/\/goo.gl\/QJ8hA2",
        "display_url" : "goo.gl\/QJ8hA2"
      } ]
    },
    "geo" : { },
    "id_str" : "380784692129038336",
    "text" : "Have to say, as a mom I don\u2019t much care for people trying to scam our kids into staying uninsured http:\/\/t.co\/TZ3aMXRV2O",
    "id" : 380784692129038336,
    "created_at" : "2013-09-19 20:05:19 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 380786823783411712,
  "created_at" : "2013-09-19 20:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 39, 51 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2013",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380766572979036161",
  "text" : "RT the news: President Obama will join @BillClinton for a conversation on health care at #CGI2013 on Tuesday. #Obamacare",
  "id" : 380766572979036161,
  "created_at" : "2013-09-19 18:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 28, 37 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 69, 81 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "CGI2013",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380751398880546817",
  "text" : "RT @Racusen44: #ACA news -- @PressSec just announced POTUS will join @billclinton for health care conversation at #CGI2013 on Tuesday in NYC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 13, 22 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "Bill Clinton",
        "screen_name" : "billclinton",
        "indices" : [ 54, 66 ],
        "id_str" : "1330457336",
        "id" : 1330457336
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "CGI2013",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380745606311862273",
    "text" : "#ACA news -- @PressSec just announced POTUS will join @billclinton for health care conversation at #CGI2013 on Tuesday in NYC",
    "id" : 380745606311862273,
    "created_at" : "2013-09-19 17:30:01 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 380751398880546817,
  "created_at" : "2013-09-19 17:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 94, 106 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/wHMYnYNgbu",
      "expanded_url" : "http:\/\/at.wh.gov\/oZOuu",
      "display_url" : "at.wh.gov\/oZOuu"
    } ]
  },
  "geo" : { },
  "id_str" : "380746325760827392",
  "text" : "\"We want to help create the environment within which businesses in this country can thrive.\" \u2014@CommerceSec: http:\/\/t.co\/wHMYnYNgbu",
  "id" : 380746325760827392,
  "created_at" : "2013-09-19 17:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380727289652051968",
  "text" : "RT @SenatorReid: Any bill that defunds Obamacare is dead on arrival in the Senate. Let's not waste everyone's time with that approach.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380725467856125952",
    "text" : "Any bill that defunds Obamacare is dead on arrival in the Senate. Let's not waste everyone's time with that approach.",
    "id" : 380725467856125952,
    "created_at" : "2013-09-19 16:09:59 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 380727289652051968,
  "created_at" : "2013-09-19 16:17:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DGBPnYGymu",
      "expanded_url" : "http:\/\/at.wh.gov\/p1tqn",
      "display_url" : "at.wh.gov\/p1tqn"
    } ]
  },
  "geo" : { },
  "id_str" : "380719307086233602",
  "text" : "\"Republicans in Congress are playing reckless political games with our economy\" \u2014@Brundage44 on the House GOP budget: http:\/\/t.co\/DGBPnYGymu",
  "id" : 380719307086233602,
  "created_at" : "2013-09-19 15:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380707935887695876\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/3xcx0loI5C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUiL2cKCIAAYxbd.png",
      "id_str" : "380707935900278784",
      "id" : 380707935900278784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUiL2cKCIAAYxbd.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 726
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 726
      } ],
      "display_url" : "pic.twitter.com\/3xcx0loI5C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380707935887695876",
  "text" : "The House GOP budget \"advances a narrow ideological agenda that threatens our economy.\" http:\/\/t.co\/3xcx0loI5C",
  "id" : 380707935887695876,
  "created_at" : "2013-09-19 15:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/t3p4MpdMak",
      "expanded_url" : "http:\/\/wapo.st\/1bs5wTx",
      "display_url" : "wapo.st\/1bs5wTx"
    } ]
  },
  "geo" : { },
  "id_str" : "380699612882796546",
  "text" : "Worth a read: President Obama began laying the groundwork to end #Syria's chemical-weapons capability in June 2012 \u2014&gt; http:\/\/t.co\/t3p4MpdMak",
  "id" : 380699612882796546,
  "created_at" : "2013-09-19 14:27:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380482424318095360\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/7iSPRrrPxE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUe-v8ECcAEixG2.jpg",
      "id_str" : "380482424322289665",
      "id" : 380482424322289665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUe-v8ECcAEixG2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/7iSPRrrPxE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/iWHPWKOojo",
      "expanded_url" : "http:\/\/at.wh.gov\/p0apP",
      "display_url" : "at.wh.gov\/p0apP"
    } ]
  },
  "geo" : { },
  "id_str" : "380482424318095360",
  "text" : "Worth a read: President Obama's remarks at today's Business Roundtable \u2014&gt; http:\/\/t.co\/iWHPWKOojo, http:\/\/t.co\/7iSPRrrPxE",
  "id" : 380482424318095360,
  "created_at" : "2013-09-19 00:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boys & Girls Clubs",
      "screen_name" : "BGCA_Clubs",
      "indices" : [ 55, 66 ],
      "id_str" : "28585586",
      "id" : 28585586
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380457915456294912\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/yw4EqDrCj0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUeodVdCEAAh8ic.jpg",
      "id_str" : "380457915464683520",
      "id" : 380457915464683520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUeodVdCEAAh8ic.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 746,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yw4EqDrCj0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380457915456294912",
  "text" : "Inside the Oval Office: President Obama meets with the @BGCA_Clubs 2013 Youth of the Year finalists \u2014&gt; http:\/\/t.co\/yw4EqDrCj0",
  "id" : 380457915456294912,
  "created_at" : "2013-09-18 22:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/FItAHJi4SY",
      "expanded_url" : "http:\/\/instagram.com\/p\/eaiqL0IaIg\/",
      "display_url" : "instagram.com\/p\/eaiqL0IaIg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "380447410981322753",
  "text" : "RT @NASA: Today's launch seen in false color Infrared: Orbital Sciences' Antares rocket, with the Cygnus cargo\u2026 http:\/\/t.co\/FItAHJi4SY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/FItAHJi4SY",
        "expanded_url" : "http:\/\/instagram.com\/p\/eaiqL0IaIg\/",
        "display_url" : "instagram.com\/p\/eaiqL0IaIg\/"
      } ]
    },
    "geo" : { },
    "id_str" : "380424783860879360",
    "text" : "Today's launch seen in false color Infrared: Orbital Sciences' Antares rocket, with the Cygnus cargo\u2026 http:\/\/t.co\/FItAHJi4SY",
    "id" : 380424783860879360,
    "created_at" : "2013-09-18 20:15:11 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 380447410981322753,
  "created_at" : "2013-09-18 21:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "indices" : [ 3, 17 ],
      "id_str" : "15568127",
      "id" : 15568127
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 118, 129 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380442967598567424",
  "text" : "RT @themotleyfool: 5 years after the financial crisis, what would you ask the President? Leave your questions for the @WhiteHouse here: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 99, 110 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FsD6v8GhYh",
        "expanded_url" : "http:\/\/mot.ly\/19eesqR",
        "display_url" : "mot.ly\/19eesqR"
      } ]
    },
    "geo" : { },
    "id_str" : "380385637896962050",
    "text" : "5 years after the financial crisis, what would you ask the President? Leave your questions for the @WhiteHouse here: http:\/\/t.co\/FsD6v8GhYh",
    "id" : 380385637896962050,
    "created_at" : "2013-09-18 17:39:37 +0000",
    "user" : {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "protected" : false,
      "id_str" : "15568127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563716194323025921\/OthWJnik_normal.png",
      "id" : 15568127,
      "verified" : true
    }
  },
  "id" : 380442967598567424,
  "created_at" : "2013-09-18 21:27:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380432183225106432\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/yOiInhrepo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUeRDg3CUAAAgD2.jpg",
      "id_str" : "380432183082504192",
      "id" : 380432183082504192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUeRDg3CUAAAgD2.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/yOiInhrepo"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380432183225106432",
  "text" : "RT if you agree: For the sake of our kids and the future of our planet, it's time to #ActOnClimate change. http:\/\/t.co\/yOiInhrepo",
  "id" : 380432183225106432,
  "created_at" : "2013-09-18 20:44:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 3, 14 ],
      "id_str" : "19611483",
      "id" : 19611483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AirForce",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380423679118569472",
  "text" : "RT @usairforce: Today, the 66th birthday of the #AirForce, we celebrate the men and women who carry our proud legacy forward! http:\/\/t.co\/6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AirForce",
        "indices" : [ 32, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/6uewAwW0p2",
        "expanded_url" : "http:\/\/1.usa.gov\/16lRCeY",
        "display_url" : "1.usa.gov\/16lRCeY"
      } ]
    },
    "geo" : { },
    "id_str" : "380338985899266048",
    "text" : "Today, the 66th birthday of the #AirForce, we celebrate the men and women who carry our proud legacy forward! http:\/\/t.co\/6uewAwW0p2",
    "id" : 380338985899266048,
    "created_at" : "2013-09-18 14:34:15 +0000",
    "user" : {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "protected" : false,
      "id_str" : "19611483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775317754924576768\/wYt0MjQN_normal.jpg",
      "id" : 19611483,
      "verified" : true
    }
  },
  "id" : 380423679118569472,
  "created_at" : "2013-09-18 20:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/M7vdmeV7Zk",
      "expanded_url" : "http:\/\/at.wh.gov\/oZ2X9",
      "display_url" : "at.wh.gov\/oZ2X9"
    } ]
  },
  "geo" : { },
  "id_str" : "380415821350051841",
  "text" : "FACT: The U.S. now produces enough wind energy to power more than 15 million homes every year \u2014&gt; http:\/\/t.co\/M7vdmeV7Zk\n#ActOnClimate",
  "id" : 380415821350051841,
  "created_at" : "2013-09-18 19:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380404197763452930",
  "text" : "RT @Jordan44: Entire GOP econ strategy based on an idea 73% of Americans say will hurt econ &amp; only 43% of people support ---&gt; http:\/\/t.co\/5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/5mGgCm8hKY",
        "expanded_url" : "http:\/\/bit.ly\/169VUvF",
        "display_url" : "bit.ly\/169VUvF"
      } ]
    },
    "geo" : { },
    "id_str" : "380398757830868992",
    "text" : "Entire GOP econ strategy based on an idea 73% of Americans say will hurt econ &amp; only 43% of people support ---&gt; http:\/\/t.co\/5mGgCm8hKY",
    "id" : 380398757830868992,
    "created_at" : "2013-09-18 18:31:45 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 380404197763452930,
  "created_at" : "2013-09-18 18:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Motley Fool",
      "screen_name" : "themotleyfool",
      "indices" : [ 69, 83 ],
      "id_str" : "15568127",
      "id" : 15568127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gIHhPJWpg2",
      "expanded_url" : "http:\/\/bit.ly\/17JS1L9",
      "display_url" : "bit.ly\/17JS1L9"
    } ]
  },
  "geo" : { },
  "id_str" : "380390885000609792",
  "text" : "5 years later, go inside Obama's response to the financial crisis on @TheMotleyFool\u2014then ask Q's for WH staff \u2014&gt; http:\/\/t.co\/gIHhPJWpg2",
  "id" : 380390885000609792,
  "created_at" : "2013-09-18 18:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 16, 25 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 30, 45 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380381774993321984",
  "text" : "RT @Lehrich44: .@PressSec: If @SpeakerBoehner would put the Senate comprehensive immigration bill on floor, it would pass and the President\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 15, 30 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380379417744134144",
    "text" : ".@PressSec: If @SpeakerBoehner would put the Senate comprehensive immigration bill on floor, it would pass and the President would sign it",
    "id" : 380379417744134144,
    "created_at" : "2013-09-18 17:14:54 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 380381774993321984,
  "created_at" : "2013-09-18 17:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 14, 23 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380375874731659267",
  "text" : "RT @Bobby44: .@PressSec: To honor the victims of Monday\u2019s horrific shooting at the Washington Navy Yard, POTUS will attend a memorial servi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380367498949840896",
    "text" : ".@PressSec: To honor the victims of Monday\u2019s horrific shooting at the Washington Navy Yard, POTUS will attend a memorial service on Sunday",
    "id" : 380367498949840896,
    "created_at" : "2013-09-18 16:27:33 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 380375874731659267,
  "created_at" : "2013-09-18 17:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380370748457496577",
  "text" : "FACT: Under President Obama, we've more than doubled the energy we produce from wind and solar sources. #ActOnClimate",
  "id" : 380370748457496577,
  "created_at" : "2013-09-18 16:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380365715863138304",
  "text" : "Thanks to Obama, our cars &amp; trucks will be twice as efficient by 2025\u2014saving the average driver more than $8,000 at the pump. #ActOnClimate",
  "id" : 380365715863138304,
  "created_at" : "2013-09-18 16:20:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/I5xtcij9tz",
      "expanded_url" : "http:\/\/at.wh.gov\/oZ2LJ",
      "display_url" : "at.wh.gov\/oZ2LJ"
    } ]
  },
  "geo" : { },
  "id_str" : "380359574177333249",
  "text" : "FACT: In 2012, U.S. carbon pollution fell to its lowest level in nearly 20 years \u2014&gt; http:\/\/t.co\/I5xtcij9tz #ActOnClimate",
  "id" : 380359574177333249,
  "created_at" : "2013-09-18 15:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380350698090545152\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Wkr8GfaFlP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUdG8doCQAA9lv2.jpg",
      "id_str" : "380350698094739456",
      "id" : 380350698094739456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUdG8doCQAA9lv2.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Wkr8GfaFlP"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380350698090545152",
  "text" : "We've seen 12 of the hottest years on record since 1998. It's time to #ActOnClimate change: http:\/\/t.co\/Wkr8GfaFlP",
  "id" : 380350698090545152,
  "created_at" : "2013-09-18 15:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380341909182365696\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/X6LNNeoVx5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUc-84aCQAAutqw.jpg",
      "id_str" : "380341909190754304",
      "id" : 380341909190754304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUc-84aCQAAutqw.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/X6LNNeoVx5"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 66, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/SndN5YXEag",
      "expanded_url" : "http:\/\/at.wh.gov\/oYYrO",
      "display_url" : "at.wh.gov\/oYYrO"
    } ]
  },
  "geo" : { },
  "id_str" : "380341909182365696",
  "text" : "Make sure your friends see this: Here's President Obama's plan to #ActOnClimate change \u2014&gt; http:\/\/t.co\/SndN5YXEag, http:\/\/t.co\/X6LNNeoVx5",
  "id" : 380341909182365696,
  "created_at" : "2013-09-18 14:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PromiseKept",
      "indices" : [ 132, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/qT1eyAZ1JO",
      "expanded_url" : "http:\/\/at.wh.gov\/oXZi1",
      "display_url" : "at.wh.gov\/oXZi1"
    } ]
  },
  "geo" : { },
  "id_str" : "380121043630686208",
  "text" : "Today, Obama extended minimum wage &amp; overtime protections to home health care workers like Pauline Beck: http:\/\/t.co\/qT1eyAZ1JO #PromiseKept",
  "id" : 380121043630686208,
  "created_at" : "2013-09-18 00:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380110380594241536\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Iy4UBRSacr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUZsYJNCIAAC5oz.jpg",
      "id_str" : "380110380602630144",
      "id" : 380110380602630144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUZsYJNCIAAC5oz.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Iy4UBRSacr"
    } ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 80, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380110380594241536",
  "text" : "President Obama receives an update from FBI Director Comey and AG Holder on the #NavyYardShooting investigation: http:\/\/t.co\/Iy4UBRSacr",
  "id" : 380110380594241536,
  "created_at" : "2013-09-17 23:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 3, 14 ],
      "id_str" : "5943942",
      "id" : 5943942
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoundCloud",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/IzLe9qGaSg",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/five-years-later",
      "display_url" : "whitehouse.gov\/five-years-lat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380104596556750849",
  "text" : "RT @SoundCloud: .@WhiteHouse shares progress made since the US financial crisis 5 years ago. Listen via #SoundCloud: http:\/\/t.co\/IzLe9qGaSg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoundCloud",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/IzLe9qGaSg",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/five-years-later",
        "display_url" : "whitehouse.gov\/five-years-lat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "380064084982386688",
    "text" : ".@WhiteHouse shares progress made since the US financial crisis 5 years ago. Listen via #SoundCloud: http:\/\/t.co\/IzLe9qGaSg",
    "id" : 380064084982386688,
    "created_at" : "2013-09-17 20:21:53 +0000",
    "user" : {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "protected" : false,
      "id_str" : "5943942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755119866839982080\/KzvZkveI_normal.jpg",
      "id" : 5943942,
      "verified" : true
    }
  },
  "id" : 380104596556750849,
  "created_at" : "2013-09-17 23:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380087351436775424\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/kqRtmWRoqp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUZXbqaCUAAuXJG.png",
      "id_str" : "380087351310962688",
      "id" : 380087351310962688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUZXbqaCUAAuXJG.png",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 592
      } ],
      "display_url" : "pic.twitter.com\/kqRtmWRoqp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/QR0GxLDtF5",
      "expanded_url" : "http:\/\/at.wh.gov\/oXoFi",
      "display_url" : "at.wh.gov\/oXoFi"
    } ]
  },
  "geo" : { },
  "id_str" : "380087351436775424",
  "text" : "FACT: Under Obama, the deficit is falling faster than any time since World War II \u2014&gt; http:\/\/t.co\/QR0GxLDtF5, http:\/\/t.co\/kqRtmWRoqp",
  "id" : 380087351436775424,
  "created_at" : "2013-09-17 21:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380083255401119746",
  "text" : "RT @vj44: Today POTUS called Pauline Beck to tell her the home care rule has been finalized\u2014in 07\u2019 he took a walk in her shoes http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Jq0tuYSXiX",
        "expanded_url" : "http:\/\/goo.gl\/Zqrn26",
        "display_url" : "goo.gl\/Zqrn26"
      } ]
    },
    "geo" : { },
    "id_str" : "380081958077747200",
    "text" : "Today POTUS called Pauline Beck to tell her the home care rule has been finalized\u2014in 07\u2019 he took a walk in her shoes http:\/\/t.co\/Jq0tuYSXiX",
    "id" : 380081958077747200,
    "created_at" : "2013-09-17 21:32:55 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 380083255401119746,
  "created_at" : "2013-09-17 21:38:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/B98oque0GI",
      "expanded_url" : "http:\/\/at.wh.gov\/oXkon",
      "display_url" : "at.wh.gov\/oXkon"
    } ]
  },
  "geo" : { },
  "id_str" : "380076300288811008",
  "text" : "Here's a behind-the-scenes account of President Obama's response to the financial crisis from his senior staff \u2014&gt; http:\/\/t.co\/B98oque0GI",
  "id" : 380076300288811008,
  "created_at" : "2013-09-17 21:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380068112357261312\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ITfLaHpRyO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUZF7y6CEAAvAjO.png",
      "id_str" : "380068112139161600",
      "id" : 380068112139161600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUZF7y6CEAAvAjO.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ITfLaHpRyO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380068112357261312",
  "text" : "FACT: Our auto industry is creating jobs at the fastest pace in 15 years. More than 340,000 new jobs since June '09: http:\/\/t.co\/ITfLaHpRyO",
  "id" : 380068112357261312,
  "created_at" : "2013-09-17 20:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380060130919723008",
  "text" : "FACT: Obama's efforts to stabilize our housing market have helped nearly 10 million people refinance or modify mortgages. #ABetterBargain",
  "id" : 380060130919723008,
  "created_at" : "2013-09-17 20:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/380051247023149056\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1Nv12M07xW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUY2mHfCUAAej4v.png",
      "id_str" : "380051247031537664",
      "id" : 380051247031537664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUY2mHfCUAAej4v.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1Nv12M07xW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380051247023149056",
  "text" : "FACT: Obama's response to the financial crisis stabilized our banking system while recovering taxpayer investments. http:\/\/t.co\/1Nv12M07xW",
  "id" : 380051247023149056,
  "created_at" : "2013-09-17 19:30:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/B98oque0GI",
      "expanded_url" : "http:\/\/at.wh.gov\/oXkon",
      "display_url" : "at.wh.gov\/oXkon"
    } ]
  },
  "geo" : { },
  "id_str" : "380046886805049346",
  "text" : "Worth a RT: Here's a look back at the progress we've made since the financial crisis hit 5 years ago \u2014&gt; http:\/\/t.co\/B98oque0GI",
  "id" : 380046886805049346,
  "created_at" : "2013-09-17 19:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/aJ7hc8YO8y",
      "expanded_url" : "http:\/\/www.usatoday.com\/story\/news\/politics\/2013\/09\/17\/100-dollar-premiums-exchanges\/2822979\/",
      "display_url" : "usatoday.com\/story\/news\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380029215430557696",
  "text" : "RT @Lehrich44: Can I interest you in health coverage for less than $100\/month? #Obamacare  --&gt; http:\/\/t.co\/aJ7hc8YO8y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/aJ7hc8YO8y",
        "expanded_url" : "http:\/\/www.usatoday.com\/story\/news\/politics\/2013\/09\/17\/100-dollar-premiums-exchanges\/2822979\/",
        "display_url" : "usatoday.com\/story\/news\/pol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379988006649614336",
    "text" : "Can I interest you in health coverage for less than $100\/month? #Obamacare  --&gt; http:\/\/t.co\/aJ7hc8YO8y",
    "id" : 379988006649614336,
    "created_at" : "2013-09-17 15:19:35 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 380029215430557696,
  "created_at" : "2013-09-17 18:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 116, 126 ]
    }, {
      "text" : "ACA",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380019023821291521",
  "text" : "RT @Sebelius: Big news! Nearly 6 in 10 uninsured Americans will #GetCovered for less than $100\/month starting Jan 1 #Obamacare #ACA http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Sebelius\/status\/379988651142180865\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/RimQkFIuPJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUX9qjqCcAAV6Wy.jpg",
        "id_str" : "379988651150569472",
        "id" : 379988651150569472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUX9qjqCcAAV6Wy.jpg",
        "sizes" : [ {
          "h" : 648,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/RimQkFIuPJ"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 50, 61 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "ACA",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379988651142180865",
    "text" : "Big news! Nearly 6 in 10 uninsured Americans will #GetCovered for less than $100\/month starting Jan 1 #Obamacare #ACA http:\/\/t.co\/RimQkFIuPJ",
    "id" : 379988651142180865,
    "created_at" : "2013-09-17 15:22:09 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 380019023821291521,
  "created_at" : "2013-09-17 17:22:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/Cdh3d7Apld",
      "expanded_url" : "http:\/\/at.wh.gov\/oXdds",
      "display_url" : "at.wh.gov\/oXdds"
    } ]
  },
  "geo" : { },
  "id_str" : "380013391781175296",
  "text" : "Nearly 6 in 10 uninsured Americans can #GetCovered next year for $100\/month or less. Find out if you're 1 of them \u2014&gt; http:\/\/t.co\/Cdh3d7Apld",
  "id" : 380013391781175296,
  "created_at" : "2013-09-17 17:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380006499004600320",
  "text" : "RT @Jordan44: For GOP, is yielding to this fringe viewpoint of undermining #Obamacare really worth recklessly hurting the economy? http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jordan44\/status\/380000763990138880\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FpLryJw0rD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUYIrniCYAAap6p.jpg",
        "id_str" : "380000763998527488",
        "id" : 380000763998527488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUYIrniCYAAap6p.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/FpLryJw0rD"
      } ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 61, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380000763990138880",
    "text" : "For GOP, is yielding to this fringe viewpoint of undermining #Obamacare really worth recklessly hurting the economy? http:\/\/t.co\/FpLryJw0rD",
    "id" : 380000763990138880,
    "created_at" : "2013-09-17 16:10:16 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 380006499004600320,
  "created_at" : "2013-09-17 16:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379998292190322689",
  "text" : "FACT: If every state expanded Medicaid access under #Obamacare, nearly 8 in 10 uninsured Americans could #GetCovered for $100\/month or less.",
  "id" : 379998292190322689,
  "created_at" : "2013-09-17 16:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379991286133972992",
  "text" : "FACT: 12.4 million Americans who are newly eligible for Medicaid &amp; CHIP can #GetCovered without having to pay insurance premiums. #Obamacare",
  "id" : 379991286133972992,
  "created_at" : "2013-09-17 15:32:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379985606576586752",
  "text" : "FACT: 10.8 million uninsured Americans could pay $100\/month or less next year for health insurance through the #Obamacare marketplace.",
  "id" : 379985606576586752,
  "created_at" : "2013-09-17 15:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/379973665837678592\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DJpkgTxKkp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUXwCTECAAIiKrk.jpg",
      "id_str" : "379973665850261506",
      "id" : 379973665850261506,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUXwCTECAAIiKrk.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DJpkgTxKkp"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379973665837678592",
  "text" : "RT the great news: Nearly 6 in 10 uninsured Americans can #GetCovered for $100\/month or less next year. #Obamacare, http:\/\/t.co\/DJpkgTxKkp",
  "id" : 379973665837678592,
  "created_at" : "2013-09-17 14:22:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/379766323191873537\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Sf7ltAU0pl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUUzdXgCAAAYANC.jpg",
      "id_str" : "379766323200262144",
      "id" : 379766323200262144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUUzdXgCAAAYANC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/Sf7ltAU0pl"
    } ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 85, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379766323191873537",
  "text" : "\"We will honor their service to the nation they helped to make great.\" \u2014Obama on the #NavyYardShooting victims: http:\/\/t.co\/Sf7ltAU0pl",
  "id" : 379766323191873537,
  "created_at" : "2013-09-17 00:38:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/4dtKbyAx5p",
      "expanded_url" : "http:\/\/at.wh.gov\/oVCn0",
      "display_url" : "at.wh.gov\/oVCn0"
    } ]
  },
  "geo" : { },
  "id_str" : "379754170409959424",
  "text" : "\"We send our thoughts and prayers to all at the Navy Yard who\u2019ve been touched by this tragedy.\" \u2014President Obama: http:\/\/t.co\/4dtKbyAx5p",
  "id" : 379754170409959424,
  "created_at" : "2013-09-16 23:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/379735195827843073\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/S6KAD2u7wo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUUXJgHIMAAcZ1G.jpg",
      "id_str" : "379735195588767744",
      "id" : 379735195588767744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUUXJgHIMAAcZ1G.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/S6KAD2u7wo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379749951384731648",
  "text" : "RT @petesouza: Lisa Monaco briefs Pres Obama on the shootings today at the Wash Navy Yard http:\/\/t.co\/S6KAD2u7wo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/379735195827843073\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/S6KAD2u7wo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BUUXJgHIMAAcZ1G.jpg",
        "id_str" : "379735195588767744",
        "id" : 379735195588767744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUUXJgHIMAAcZ1G.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/S6KAD2u7wo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379735195827843073",
    "text" : "Lisa Monaco briefs Pres Obama on the shootings today at the Wash Navy Yard http:\/\/t.co\/S6KAD2u7wo",
    "id" : 379735195827843073,
    "created_at" : "2013-09-16 22:35:00 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 379749951384731648,
  "created_at" : "2013-09-16 23:33:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 104, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AsNLPqHaZZ",
      "expanded_url" : "http:\/\/at.wh.gov\/oVBCt",
      "display_url" : "at.wh.gov\/oVBCt"
    } ]
  },
  "geo" : { },
  "id_str" : "379743047723917312",
  "text" : "President Obama: \"We stand with the families of those who\u2019ve been harmed.\" \u2014&gt; http:\/\/t.co\/AsNLPqHaZZ #NavyYardShooting",
  "id" : 379743047723917312,
  "created_at" : "2013-09-16 23:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379730261535367169",
  "text" : "President Obama has directed that flags be lowered to half-staff until sunset on Friday in honor of the victims of the #NavyYardShooting.",
  "id" : 379730261535367169,
  "created_at" : "2013-09-16 22:15:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 23, 30 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/7fA0EmIa50",
      "expanded_url" : "http:\/\/at.wh.gov\/oVvUY",
      "display_url" : "at.wh.gov\/oVvUY"
    } ]
  },
  "geo" : { },
  "id_str" : "379725021209702400",
  "text" : "President Obama called @USNavy Sec. Ray Mabus to express his condolences to the families of the #NavyYardShooting \u2014&gt; http:\/\/t.co\/7fA0EmIa50",
  "id" : 379725021209702400,
  "created_at" : "2013-09-16 21:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379644496704593920",
  "text" : "President Obama: \"We send our thoughts and prayers to all at the Navy Yard who\u2019ve been touched by this tragedy.\" #NavyYardShooting",
  "id" : 379644496704593920,
  "created_at" : "2013-09-16 16:34:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379644368417599488",
  "text" : "Obama: \"We will do everything in our power to make sure whoever carried out this cowardly act is held responsible.\" #NavyYardShooting",
  "id" : 379644368417599488,
  "created_at" : "2013-09-16 16:34:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 126, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379644176721129472",
  "text" : "\"These are men &amp; women were going to work, doing their job, protecting all of us.\" \u2014President Obama on the victims of the #NavyYardShooting",
  "id" : 379644176721129472,
  "created_at" : "2013-09-16 16:33:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavyYardShooting",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5VLMh3XgoL",
      "expanded_url" : "http:\/\/at.wh.gov\/oUEWr",
      "display_url" : "at.wh.gov\/oUEWr"
    } ]
  },
  "geo" : { },
  "id_str" : "379643822549897217",
  "text" : "Happening now: President Obama speaks on the situation at the Washington Navy Yard. Watch \u2014&gt; http:\/\/t.co\/5VLMh3XgoL #NavyYardShooting",
  "id" : 379643822549897217,
  "created_at" : "2013-09-16 16:31:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 127, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "379624790585135107",
  "text" : "At 11:40am ET, President Obama speaks on the five-year anniversary of the financial crisis. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb #ABetterBargain",
  "id" : 379624790585135107,
  "created_at" : "2013-09-16 15:16:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/vo48CpHap7",
      "expanded_url" : "http:\/\/at.wh.gov\/oS16z",
      "display_url" : "at.wh.gov\/oS16z"
    } ]
  },
  "geo" : { },
  "id_str" : "378960174691516416",
  "text" : "\"This framework provides the opportunity for the elimination of Syrian chemical weapons.\" \u2014President Obama: http:\/\/t.co\/vo48CpHap7 #Syria",
  "id" : 378960174691516416,
  "created_at" : "2013-09-14 19:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/vo48CpHap7",
      "expanded_url" : "http:\/\/at.wh.gov\/oS16z",
      "display_url" : "at.wh.gov\/oS16z"
    } ]
  },
  "geo" : { },
  "id_str" : "378949329471287296",
  "text" : "President Obama on the U.S.\u2014Russian agreement on a framework for elimination of Syrian chemical weapons \u2014&gt; http:\/\/t.co\/vo48CpHap7 #Syria",
  "id" : 378949329471287296,
  "created_at" : "2013-09-14 18:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 129, 132 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378944465739599872",
  "text" : "RT @Brundage44: 5 yrs after financial crisis hit, POTUS to address progress made, work left 2 do in Rose Garden event Monday via @AP  http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Associated Press",
        "screen_name" : "AP",
        "indices" : [ 113, 116 ],
        "id_str" : "51241574",
        "id" : 51241574
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/WEsIOAFLN7",
        "expanded_url" : "http:\/\/m.apnews.com\/ap\/db_268798\/contentdetail.htm?contentguid=xbhi34M3",
        "display_url" : "m.apnews.com\/ap\/db_268798\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378930054044336128",
    "text" : "5 yrs after financial crisis hit, POTUS to address progress made, work left 2 do in Rose Garden event Monday via @AP  http:\/\/t.co\/WEsIOAFLN7",
    "id" : 378930054044336128,
    "created_at" : "2013-09-14 17:15:39 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 378944465739599872,
  "created_at" : "2013-09-14 18:12:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 138, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/IwgD7fRbHW",
      "expanded_url" : "http:\/\/at.wh.gov\/oRaAs",
      "display_url" : "at.wh.gov\/oRaAs"
    } ]
  },
  "geo" : { },
  "id_str" : "378918646178775040",
  "text" : "\"We cannot risk poison gas becoming the new weapon of choice for terrorists &amp; tyrants the world over.\" \u2014Obama: http:\/\/t.co\/IwgD7fRbHW #Syria",
  "id" : 378918646178775040,
  "created_at" : "2013-09-14 16:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IwgD7fRbHW",
      "expanded_url" : "http:\/\/at.wh.gov\/oRaAs",
      "display_url" : "at.wh.gov\/oRaAs"
    } ]
  },
  "geo" : { },
  "id_str" : "378890116292300800",
  "text" : "\"We have a duty to preserve a world free from the fear of chemical weapons for our children.\" \u2014Obama on #Syria: http:\/\/t.co\/IwgD7fRbHW",
  "id" : 378890116292300800,
  "created_at" : "2013-09-14 14:36:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362997321270697984\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/c2lO3KnS5Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQmgI_UCIAEJ3UB.jpg",
      "id_str" : "362997321274892289",
      "id" : 362997321274892289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQmgI_UCIAEJ3UB.jpg",
      "sizes" : [ {
        "h" : 792,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/c2lO3KnS5Q"
    } ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378646359382847488",
  "text" : "RT @Jordan44: With CA set to #raisethewage, worth remembering how POTUS' plan could help millions more http:\/\/t.co\/c2lO3KnS5Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362997321270697984\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/c2lO3KnS5Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQmgI_UCIAEJ3UB.jpg",
        "id_str" : "362997321274892289",
        "id" : 362997321274892289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQmgI_UCIAEJ3UB.jpg",
        "sizes" : [ {
          "h" : 792,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 792
        } ],
        "display_url" : "pic.twitter.com\/c2lO3KnS5Q"
      } ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 15, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378627444657238016",
    "text" : "With CA set to #raisethewage, worth remembering how POTUS' plan could help millions more http:\/\/t.co\/c2lO3KnS5Q",
    "id" : 378627444657238016,
    "created_at" : "2013-09-13 21:13:12 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 378646359382847488,
  "created_at" : "2013-09-13 22:28:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/378640798675259393\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/l4BvTvlk4F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUEzzN8CUAAkBXu.jpg",
      "id_str" : "378640798683648000",
      "id" : 378640798683648000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUEzzN8CUAAkBXu.jpg",
      "sizes" : [ {
        "h" : 734,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/l4BvTvlk4F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378640798675259393",
  "text" : "Today, President Obama met with Sheikh Sabah Al-Ahmad Al-Jaber Al Sabah\u2014the Amir of Kuwait: http:\/\/t.co\/l4BvTvlk4F",
  "id" : 378640798675259393,
  "created_at" : "2013-09-13 22:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 7, 17 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    }, {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 19, 29 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    }, {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 36, 45 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 140, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378630670395781120",
  "text" : "Follow @Racusen44, @Rosholm44 &amp; @Jordan44 for the latest on White House policy announcements, POTUS travel, polling research, and more. #FF",
  "id" : 378630670395781120,
  "created_at" : "2013-09-13 21:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/vQqLobnvJr",
      "expanded_url" : "http:\/\/www.stripes.com\/1.241040",
      "display_url" : "stripes.com\/1.241040"
    } ]
  },
  "geo" : { },
  "id_str" : "378616463013060610",
  "text" : "RT @Inouye44: Nice story - Aviano pair is first same-sex AF couple to get Join Spouse assignment.  http:\/\/t.co\/vQqLobnvJr #LGBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 108, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/vQqLobnvJr",
        "expanded_url" : "http:\/\/www.stripes.com\/1.241040",
        "display_url" : "stripes.com\/1.241040"
      } ]
    },
    "geo" : { },
    "id_str" : "378601289258500096",
    "text" : "Nice story - Aviano pair is first same-sex AF couple to get Join Spouse assignment.  http:\/\/t.co\/vQqLobnvJr #LGBT",
    "id" : 378601289258500096,
    "created_at" : "2013-09-13 19:29:16 +0000",
    "user" : {
      "name" : "Shin Inouye",
      "screen_name" : "InouyeUSCIS",
      "protected" : false,
      "id_str" : "1702571186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667848615780446208\/1LoEXwfW_normal.jpg",
      "id" : 1702571186,
      "verified" : true
    }
  },
  "id" : 378616463013060610,
  "created_at" : "2013-09-13 20:29:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Greece",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "Syria",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378609571750637568",
  "text" : "RT @NSCPress: Update: #Greece has signed on to the Sept. 6 statement on #Syria. Total countries now at 36. See the full list here: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Greece",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "Syria",
        "indices" : [ 58, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/dBJOZf6GLp",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/09\/09\/statement-additional-countries-support-september-6-joint-statement-syria",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378590264874377217",
    "text" : "Update: #Greece has signed on to the Sept. 6 statement on #Syria. Total countries now at 36. See the full list here: http:\/\/t.co\/dBJOZf6GLp",
    "id" : 378590264874377217,
    "created_at" : "2013-09-13 18:45:27 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 378609571750637568,
  "created_at" : "2013-09-13 20:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    }, {
      "name" : "AARP",
      "screen_name" : "AARP",
      "indices" : [ 39, 44 ],
      "id_str" : "80628196",
      "id" : 80628196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378598842846834689",
  "text" : "RT @Racusen44: ICYMI: new e-cards from @AARP are a great example of creative ACA outreach to parents w\/ uninsured kids: http:\/\/t.co\/b9Tkihx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AARP",
        "screen_name" : "AARP",
        "indices" : [ 24, 29 ],
        "id_str" : "80628196",
        "id" : 80628196
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/b9TkihxGrg",
        "expanded_url" : "http:\/\/www.aarp.org\/health\/affordable-care-act\/mommeansit\/",
        "display_url" : "aarp.org\/health\/afforda\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378593373818347520",
    "text" : "ICYMI: new e-cards from @AARP are a great example of creative ACA outreach to parents w\/ uninsured kids: http:\/\/t.co\/b9TkihxGrg",
    "id" : 378593373818347520,
    "created_at" : "2013-09-13 18:57:48 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 378598842846834689,
  "created_at" : "2013-09-13 19:19:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 60, 65 ]
    }, {
      "text" : "1is2many",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378586093089607680",
  "text" : "RT @vj44: All violence against women is unacceptable\u2014RT for #VAWA, #1is2many &amp; help break the cycle of violence in this country http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 50, 55 ]
      }, {
        "text" : "1is2many",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/zufTZraeWp",
        "expanded_url" : "http:\/\/ow.ly\/oQGlZ",
        "display_url" : "ow.ly\/oQGlZ"
      } ]
    },
    "geo" : { },
    "id_str" : "378582349409046528",
    "text" : "All violence against women is unacceptable\u2014RT for #VAWA, #1is2many &amp; help break the cycle of violence in this country http:\/\/t.co\/zufTZraeWp",
    "id" : 378582349409046528,
    "created_at" : "2013-09-13 18:14:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 378586093089607680,
  "created_at" : "2013-09-13 18:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SrnGkI5ZB6",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/09\/13\/ending-violence-against-women-19-years-progress",
      "display_url" : "whitehouse.gov\/blog\/2013\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378581033760722944",
  "text" : "RT @VP: Worth a read: Lynn Rosenthal\u2019s blog post on the 19th anniversary of the Violence Against Women Act: http:\/\/t.co\/SrnGkI5ZB6  #VAWA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/SrnGkI5ZB6",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/09\/13\/ending-violence-against-women-19-years-progress",
        "display_url" : "whitehouse.gov\/blog\/2013\/09\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378578402443141120",
    "text" : "Worth a read: Lynn Rosenthal\u2019s blog post on the 19th anniversary of the Violence Against Women Act: http:\/\/t.co\/SrnGkI5ZB6  #VAWA",
    "id" : 378578402443141120,
    "created_at" : "2013-09-13 17:58:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 378581033760722944,
  "created_at" : "2013-09-13 18:08:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Indonesia",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "Brunei",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "Malaysia",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "Philippines",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378572065130835970",
  "text" : "RT @NSCPress: POTUS will travel to #Indonesia, #Brunei, #Malaysia &amp; #Philippines October 6-12 as part of ongoing commitment to engagement w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Indonesia",
        "indices" : [ 21, 31 ]
      }, {
        "text" : "Brunei",
        "indices" : [ 33, 40 ]
      }, {
        "text" : "Malaysia",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "Philippines",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378561821872893952",
    "text" : "POTUS will travel to #Indonesia, #Brunei, #Malaysia &amp; #Philippines October 6-12 as part of ongoing commitment to engagement w\/Asia Pacific.",
    "id" : 378561821872893952,
    "created_at" : "2013-09-13 16:52:26 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 378572065130835970,
  "created_at" : "2013-09-13 17:33:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Eva Longoria Baston",
      "screen_name" : "EvaLongoria",
      "indices" : [ 46, 58 ],
      "id_str" : "110827653",
      "id" : 110827653
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/378563490723540992\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7wj1bfGHgS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUDtfTXCMAEAlxn.jpg",
      "id_str" : "378563490727735297",
      "id" : 378563490727735297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUDtfTXCMAEAlxn.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7wj1bfGHgS"
    } ],
    "hashtags" : [ {
      "text" : "DrinkH2O",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/twiKqNHn4t",
      "expanded_url" : "http:\/\/YouAreWhatYouDrink.org\/",
      "display_url" : "YouAreWhatYouDrink.org"
    } ]
  },
  "geo" : { },
  "id_str" : "378563490723540992",
  "text" : "Raise your water glass and join @FLOTUS &amp; @EvaLongoria in a virtual cheers! http:\/\/t.co\/twiKqNHn4t #DrinkH2O, http:\/\/t.co\/7wj1bfGHgS",
  "id" : 378563490723540992,
  "created_at" : "2013-09-13 16:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/378555076312182784\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Epfp0UYdar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUDl1hQCMAATmnN.jpg",
      "id_str" : "378555076320571392",
      "id" : 378555076320571392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUDl1hQCMAATmnN.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Epfp0UYdar"
    } ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/l9YkKFs2Y5",
      "expanded_url" : "http:\/\/at.wh.gov\/oQzC1",
      "display_url" : "at.wh.gov\/oQzC1"
    } ]
  },
  "geo" : { },
  "id_str" : "378555076312182784",
  "text" : "Watch a recap of this week at the White House \u2014&gt; http:\/\/t.co\/l9YkKFs2Y5 #WestWingWeek, http:\/\/t.co\/Epfp0UYdar",
  "id" : 378555076312182784,
  "created_at" : "2013-09-13 16:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/9UWRBvxLuh",
      "expanded_url" : "http:\/\/wh.gov\/l2ako",
      "display_url" : "wh.gov\/l2ako"
    } ]
  },
  "geo" : { },
  "id_str" : "378540421070065664",
  "text" : "\"I\u2019m\u2026proud to name Jeff Zients as the next Director of the National Economic Council.\" \u2014President Obama: http:\/\/t.co\/9UWRBvxLuh",
  "id" : 378540421070065664,
  "created_at" : "2013-09-13 15:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378532960527331328",
  "text" : "RT @Simas44: This is worth a RT. Millions of these ACA stories are about to be told. Health care act a lifesaver to Indiana women. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/li95aqQqlQ",
        "expanded_url" : "http:\/\/bit.ly\/15YC4NR",
        "display_url" : "bit.ly\/15YC4NR"
      } ]
    },
    "geo" : { },
    "id_str" : "378531066899755008",
    "text" : "This is worth a RT. Millions of these ACA stories are about to be told. Health care act a lifesaver to Indiana women. http:\/\/t.co\/li95aqQqlQ",
    "id" : 378531066899755008,
    "created_at" : "2013-09-13 14:50:13 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 378532960527331328,
  "created_at" : "2013-09-13 14:57:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 29, 38 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 94, 101 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378528047042818048",
  "text" : "RT @Bobby44: West Wing Week: @PressSec Russian intro, POTUS address to the Nation, 9\/11 anny, @FLOTUS Drink Up, and much more http:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 16, 25 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 81, 88 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PDp8LqHKKF",
        "expanded_url" : "http:\/\/youtu.be\/fGtfuwXWhtI",
        "display_url" : "youtu.be\/fGtfuwXWhtI"
      } ]
    },
    "geo" : { },
    "id_str" : "378523094748385280",
    "text" : "West Wing Week: @PressSec Russian intro, POTUS address to the Nation, 9\/11 anny, @FLOTUS Drink Up, and much more http:\/\/t.co\/PDp8LqHKKF",
    "id" : 378523094748385280,
    "created_at" : "2013-09-13 14:18:33 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 378528047042818048,
  "created_at" : "2013-09-13 14:38:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/fSN6eZpbz9",
      "expanded_url" : "http:\/\/at.wh.gov\/oPkPQ",
      "display_url" : "at.wh.gov\/oPkPQ"
    } ]
  },
  "geo" : { },
  "id_str" : "378310876333236225",
  "text" : "In case you missed it, watch President Obama's address to the nation on why we need to act in #Syria \u2014&gt; http:\/\/t.co\/fSN6eZpbz9",
  "id" : 378310876333236225,
  "created_at" : "2013-09-13 00:15:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CB2up33IiI",
      "expanded_url" : "http:\/\/at.wh.gov\/oPkiI",
      "display_url" : "at.wh.gov\/oPkiI"
    } ]
  },
  "geo" : { },
  "id_str" : "378299552601632768",
  "text" : "\"Next month, people are going to be able to start signing up for health care\u2014in many cases for the 1st time.\" \u2014Obama: http:\/\/t.co\/CB2up33IiI",
  "id" : 378299552601632768,
  "created_at" : "2013-09-12 23:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378294697950605312",
  "text" : "RT @Jordan44: Critical context for upcoming fiscal debates: Budget Deficit on Track for Smallest Shortfall Since 2008 http:\/\/t.co\/apiBbFox7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 131, 135 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/apiBbFox7K",
        "expanded_url" : "http:\/\/on.wsj.com\/18XzCIq",
        "display_url" : "on.wsj.com\/18XzCIq"
      } ]
    },
    "geo" : { },
    "id_str" : "378292771179606016",
    "text" : "Critical context for upcoming fiscal debates: Budget Deficit on Track for Smallest Shortfall Since 2008 http:\/\/t.co\/apiBbFox7K via @WSJ",
    "id" : 378292771179606016,
    "created_at" : "2013-09-12 23:03:19 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 378294697950605312,
  "created_at" : "2013-09-12 23:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "throwbackthursday",
      "indices" : [ 95, 113 ]
    }, {
      "text" : "tbt",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378288741078425600",
  "text" : "RT @Cabinet: President Obama tours the Cabinet Room on his first day in office, Jan. 21, 2009. #throwbackthursday #tbt http:\/\/t.co\/jsfxwFD2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cabinet\/status\/378287730813173760\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/jsfxwFD2id",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BT_yr9qCAAAXvED.jpg",
        "id_str" : "378287730821562368",
        "id" : 378287730821562368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT_yr9qCAAAXvED.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jsfxwFD2id"
      } ],
      "hashtags" : [ {
        "text" : "throwbackthursday",
        "indices" : [ 82, 100 ]
      }, {
        "text" : "tbt",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378287730813173760",
    "text" : "President Obama tours the Cabinet Room on his first day in office, Jan. 21, 2009. #throwbackthursday #tbt http:\/\/t.co\/jsfxwFD2id",
    "id" : 378287730813173760,
    "created_at" : "2013-09-12 22:43:18 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 378288741078425600,
  "created_at" : "2013-09-12 22:47:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/PzToGuEbGQ",
      "expanded_url" : "http:\/\/dmreg.co\/16o7tga",
      "display_url" : "dmreg.co\/16o7tga"
    } ]
  },
  "geo" : { },
  "id_str" : "378278649859813376",
  "text" : "RT @Simas44: More good ACA news. Low rates and more competition coming to Iowa.  http:\/\/t.co\/PzToGuEbGQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/PzToGuEbGQ",
        "expanded_url" : "http:\/\/dmreg.co\/16o7tga",
        "display_url" : "dmreg.co\/16o7tga"
      } ]
    },
    "geo" : { },
    "id_str" : "378270264217194496",
    "text" : "More good ACA news. Low rates and more competition coming to Iowa.  http:\/\/t.co\/PzToGuEbGQ",
    "id" : 378270264217194496,
    "created_at" : "2013-09-12 21:33:53 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 378278649859813376,
  "created_at" : "2013-09-12 22:07:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Denali National Park",
      "screen_name" : "DenaliNPS",
      "indices" : [ 65, 75 ],
      "id_str" : "45943457",
      "id" : 45943457
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NorthernLights",
      "indices" : [ 18, 33 ]
    }, {
      "text" : "auroras",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "auroraborealis",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378268925726711809",
  "text" : "RT @Interior: The #NorthernLights put on a spectacular show over @DenaliNPS earlier this week. #auroras #auroraborealis http:\/\/t.co\/uyeUnlf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denali National Park",
        "screen_name" : "DenaliNPS",
        "indices" : [ 51, 61 ],
        "id_str" : "45943457",
        "id" : 45943457
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/378172207085924352\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/uyeUnlfO5c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BT-JnlNIEAEsEVW.jpg",
        "id_str" : "378172206817480705",
        "id" : 378172206817480705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT-JnlNIEAEsEVW.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uyeUnlfO5c"
      } ],
      "hashtags" : [ {
        "text" : "NorthernLights",
        "indices" : [ 4, 19 ]
      }, {
        "text" : "auroras",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "auroraborealis",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378172207085924352",
    "text" : "The #NorthernLights put on a spectacular show over @DenaliNPS earlier this week. #auroras #auroraborealis http:\/\/t.co\/uyeUnlfO5c",
    "id" : 378172207085924352,
    "created_at" : "2013-09-12 15:04:14 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 378268925726711809,
  "created_at" : "2013-09-12 21:28:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/378253868150173698\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/ldoJcsYdKf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT_T45ZCMAAKve1.jpg",
      "id_str" : "378253868154368000",
      "id" : 378253868154368000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT_T45ZCMAAKve1.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ldoJcsYdKf"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "378253868150173698",
  "text" : "We need to act in #Syria, because our ideals, principles &amp; national security are at stake: http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/ldoJcsYdKf",
  "id" : 378253868150173698,
  "created_at" : "2013-09-12 20:28:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/1afKQxcChq",
      "expanded_url" : "http:\/\/apne.ws\/9TdxDP",
      "display_url" : "apne.ws\/9TdxDP"
    } ]
  },
  "geo" : { },
  "id_str" : "378246621231718400",
  "text" : "RT @jesseclee44: AP: \"US budget deficit shrinks 35% from last year...on track to be the smallest in five years\" http:\/\/t.co\/1afKQxcChq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/1afKQxcChq",
        "expanded_url" : "http:\/\/apne.ws\/9TdxDP",
        "display_url" : "apne.ws\/9TdxDP"
      } ]
    },
    "geo" : { },
    "id_str" : "378231259442327552",
    "text" : "AP: \"US budget deficit shrinks 35% from last year...on track to be the smallest in five years\" http:\/\/t.co\/1afKQxcChq",
    "id" : 378231259442327552,
    "created_at" : "2013-09-12 18:58:54 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 378246621231718400,
  "created_at" : "2013-09-12 19:59:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/N4kPAcqPtZ",
      "expanded_url" : "http:\/\/at.wh.gov\/oOrDF",
      "display_url" : "at.wh.gov\/oOrDF"
    } ]
  },
  "geo" : { },
  "id_str" : "378240463850840064",
  "text" : "RT the good news: #Obamacare saved consumers $1.2 billion on health care premiums last year \u2014&gt; http:\/\/t.co\/N4kPAcqPtZ",
  "id" : 378240463850840064,
  "created_at" : "2013-09-12 19:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 14, 23 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378234046062399488",
  "text" : "RT @Bobby44: .@PressSec announced: On Wednesday at 10:45AM, POTUS will address business leaders at the quarterly meeting of the Business Ro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378216755291639808",
    "text" : ".@PressSec announced: On Wednesday at 10:45AM, POTUS will address business leaders at the quarterly meeting of the Business Roundtable",
    "id" : 378216755291639808,
    "created_at" : "2013-09-12 18:01:16 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 378234046062399488,
  "created_at" : "2013-09-12 19:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 51, 59 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/nXJRSwvNyL",
      "expanded_url" : "http:\/\/vine.co\/v\/h1Y3T3YQpVH",
      "display_url" : "vine.co\/v\/h1Y3T3YQpVH"
    } ]
  },
  "geo" : { },
  "id_str" : "378222992280387584",
  "text" : "Here's what it's like to walk into the White House @Cabinet Room \u2014&gt; http:\/\/t.co\/nXJRSwvNyL",
  "id" : 378222992280387584,
  "created_at" : "2013-09-12 18:26:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378216435786326017",
  "text" : "RT @Jordan44: Follow along for a glimpse into @WhiteHouse message strategy and the occasional public poll analysis.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378214342837022720",
    "text" : "Follow along for a glimpse into @WhiteHouse message strategy and the occasional public poll analysis.",
    "id" : 378214342837022720,
    "created_at" : "2013-09-12 17:51:40 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 378216435786326017,
  "created_at" : "2013-09-12 17:59:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/FKkcdThkAJ",
      "expanded_url" : "http:\/\/vine.co\/v\/h1Y39TE55YT",
      "display_url" : "vine.co\/v\/h1Y39TE55YT"
    } ]
  },
  "geo" : { },
  "id_str" : "378212104404094976",
  "text" : "RT @Cabinet: President Obama delivers opening remarks at today's Cabinet meeting: http:\/\/t.co\/FKkcdThkAJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/FKkcdThkAJ",
        "expanded_url" : "http:\/\/vine.co\/v\/h1Y39TE55YT",
        "display_url" : "vine.co\/v\/h1Y39TE55YT"
      } ]
    },
    "geo" : { },
    "id_str" : "378206755122995200",
    "text" : "President Obama delivers opening remarks at today's Cabinet meeting: http:\/\/t.co\/FKkcdThkAJ",
    "id" : 378206755122995200,
    "created_at" : "2013-09-12 17:21:31 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 378212104404094976,
  "created_at" : "2013-09-12 17:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Andrew Villegas",
      "screen_name" : "ReporterAndrew",
      "indices" : [ 50, 65 ],
      "id_str" : "15744171",
      "id" : 15744171
    }, {
      "name" : "D.C. United",
      "screen_name" : "dcunited",
      "indices" : [ 66, 75 ],
      "id_str" : "15997022",
      "id" : 15997022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exchange",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378202226029654016",
  "text" : "RT @Schultz44: Will help meet enrollment GOAL MT: @ReporterAndrew @dcunited teams w\/ DC insurance #exchange to get people enrolled http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Villegas",
        "screen_name" : "ReporterAndrew",
        "indices" : [ 35, 50 ],
        "id_str" : "15744171",
        "id" : 15744171
      }, {
        "name" : "D.C. United",
        "screen_name" : "dcunited",
        "indices" : [ 51, 60 ],
        "id_str" : "15997022",
        "id" : 15997022
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "exchange",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/J1TyzKV9Lr",
        "expanded_url" : "http:\/\/ow.ly\/oO5rF",
        "display_url" : "ow.ly\/oO5rF"
      } ]
    },
    "geo" : { },
    "id_str" : "378167720706969601",
    "text" : "Will help meet enrollment GOAL MT: @ReporterAndrew @dcunited teams w\/ DC insurance #exchange to get people enrolled http:\/\/t.co\/J1TyzKV9Lr",
    "id" : 378167720706969601,
    "created_at" : "2013-09-12 14:46:25 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 378202226029654016,
  "created_at" : "2013-09-12 17:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/N4kPAcqPtZ",
      "expanded_url" : "http:\/\/at.wh.gov\/oOrDF",
      "display_url" : "at.wh.gov\/oOrDF"
    } ]
  },
  "geo" : { },
  "id_str" : "378185820248625153",
  "text" : "FACT: #Obamacare saved 6.8 million consumers $1.2 billion on health insurance premiums last year \u2014&gt; http:\/\/t.co\/N4kPAcqPtZ",
  "id" : 378185820248625153,
  "created_at" : "2013-09-12 15:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "ACA",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/bncJGCviSK",
      "expanded_url" : "http:\/\/www.hhs.gov\/news\/press\/2013pres\/09\/20130912a.html",
      "display_url" : "hhs.gov\/news\/press\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378180651729436672",
  "text" : "RT @Sebelius: RT the good news!  #Obamacare saves consumers $1.2 billion nationwide. READ: http:\/\/t.co\/bncJGCviSK #ACA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 19, 29 ]
      }, {
        "text" : "ACA",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/bncJGCviSK",
        "expanded_url" : "http:\/\/www.hhs.gov\/news\/press\/2013pres\/09\/20130912a.html",
        "display_url" : "hhs.gov\/news\/press\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378174438656585728",
    "text" : "RT the good news!  #Obamacare saves consumers $1.2 billion nationwide. READ: http:\/\/t.co\/bncJGCviSK #ACA",
    "id" : 378174438656585728,
    "created_at" : "2013-09-12 15:13:06 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 378180651729436672,
  "created_at" : "2013-09-12 15:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 40, 48 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/378171290751754242\/photo\/1",
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/pAUFuIU7ky",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT-IyQoCYAEg5Og.png",
      "id_str" : "378171290760142849",
      "id" : 378171290760142849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT-IyQoCYAEg5Og.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/pAUFuIU7ky"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378171290751754242",
  "text" : "Right now: President Obama convenes his @Cabinet to discuss #Syria &amp; efforts to create jobs &amp; grow the middle class. http:\/\/t.co\/pAUFuIU7ky",
  "id" : 378171290751754242,
  "created_at" : "2013-09-12 15:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378166796601155584",
  "text" : "RT @Cabinet: Follow along for updates and the latest news from President Obama's Cabinet\u2014starting with this morning's 11am ET Cabinet meeti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378166701130403840",
    "text" : "Follow along for updates and the latest news from President Obama's Cabinet\u2014starting with this morning's 11am ET Cabinet meeting.",
    "id" : 378166701130403840,
    "created_at" : "2013-09-12 14:42:22 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 378166796601155584,
  "created_at" : "2013-09-12 14:42:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377948622920617984\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/q0Ha9cy5yv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT6-RRqIUAA5Qb4.jpg",
      "id_str" : "377948622752862208",
      "id" : 377948622752862208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT6-RRqIUAA5Qb4.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/q0Ha9cy5yv"
    } ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/izKjBfTqTV",
      "expanded_url" : "http:\/\/at.wh.gov\/oN6JW",
      "display_url" : "at.wh.gov\/oN6JW"
    } ]
  },
  "geo" : { },
  "id_str" : "377948622920617984",
  "text" : "Let's have the courage to carry on: http:\/\/t.co\/izKjBfTqTV #NeverForget, http:\/\/t.co\/q0Ha9cy5yv",
  "id" : 377948622920617984,
  "created_at" : "2013-09-12 00:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377936134858633216\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/F6vkieEokR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT6y6XmIcAA4Ory.jpg",
      "id_str" : "377936134581809152",
      "id" : 377936134581809152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT6y6XmIcAA4Ory.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/F6vkieEokR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377936134858633216",
  "text" : "President Obama greets families at the September 11th Observance Ceremony at the Pentagon \u2014&gt; http:\/\/t.co\/F6vkieEokR",
  "id" : 377936134858633216,
  "created_at" : "2013-09-11 23:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377925492923301888\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Dy57h0Y2rw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT6pO8WCAAA6gST.jpg",
      "id_str" : "377925492927496192",
      "id" : 377925492927496192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT6pO8WCAAA6gST.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Dy57h0Y2rw"
    } ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377925492923301888",
  "text" : "President Obama, Sec. Hagel &amp; General Dempsey mark the 12th anniversary of the 9\/11 terrorist attacks. #NeverForget, http:\/\/t.co\/Dy57h0Y2rw",
  "id" : 377925492923301888,
  "created_at" : "2013-09-11 22:43:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/FYMBCHsug3",
      "expanded_url" : "http:\/\/at.wh.gov\/oMZKj",
      "display_url" : "at.wh.gov\/oMZKj"
    } ]
  },
  "geo" : { },
  "id_str" : "377915018802503682",
  "text" : "Observing a moment of silence at the White House \u2014&gt; http:\/\/t.co\/FYMBCHsug3 #NeverForget",
  "id" : 377915018802503682,
  "created_at" : "2013-09-11 22:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377904270873726976",
  "text" : "RT @AmbassadorPower: Here in NY remembering lives lost, incredible bravery, and the exceptional ability of the United States to stand tall \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377900819083190272",
    "text" : "Here in NY remembering lives lost, incredible bravery, and the exceptional ability of the United States to stand tall in the face of terror.",
    "id" : 377900819083190272,
    "created_at" : "2013-09-11 21:05:50 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 377904270873726976,
  "created_at" : "2013-09-11 21:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food & Friends",
      "screen_name" : "foodandfriends",
      "indices" : [ 25, 40 ],
      "id_str" : "60956491",
      "id" : 60956491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911day",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/hgtymPfKKZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/eIbj4Jwiuh\/",
      "display_url" : "instagram.com\/p\/eIbj4Jwiuh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "377891460495855616",
  "text" : "President Obama stops by @FoodandFriends to mark the September 11th National Day of Service. Watch --&gt; http:\/\/t.co\/hgtymPfKKZ #911day",
  "id" : 377891460495855616,
  "created_at" : "2013-09-11 20:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911day",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "911serve",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377827418980892672",
  "text" : "RT @ServeDotGov: We remember 9\/11 through service, giving back to honor those we lost. Tell us why you serve on #911day w\/ #911serve.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "911day",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "911serve",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377765540095590400",
    "text" : "We remember 9\/11 through service, giving back to honor those we lost. Tell us why you serve on #911day w\/ #911serve.",
    "id" : 377765540095590400,
    "created_at" : "2013-09-11 12:08:17 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 377827418980892672,
  "created_at" : "2013-09-11 16:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377817066402615296\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/K4VUEXQx2q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT5GnsGCEAAFXJv.jpg",
      "id_str" : "377817066411003904",
      "id" : 377817066411003904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT5GnsGCEAAFXJv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/K4VUEXQx2q"
    } ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377817066402615296",
  "text" : "A moment of silence to mark the 12th anniversary of the 9\/11 terrorist attacks. #NeverForget, http:\/\/t.co\/K4VUEXQx2q",
  "id" : 377817066402615296,
  "created_at" : "2013-09-11 15:33:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Day",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SBliOt6bxx",
      "expanded_url" : "http:\/\/serve.gov",
      "display_url" : "serve.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "377804380839235584",
  "text" : "RT @JoiningForces: Honor #911Day by helping military families reconnect with their communities. Volunteer \u2014&gt; http:\/\/t.co\/SBliOt6bxx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "911Day",
        "indices" : [ 6, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/SBliOt6bxx",
        "expanded_url" : "http:\/\/serve.gov",
        "display_url" : "serve.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "377804276946731008",
    "text" : "Honor #911Day by helping military families reconnect with their communities. Volunteer \u2014&gt; http:\/\/t.co\/SBliOt6bxx",
    "id" : 377804276946731008,
    "created_at" : "2013-09-11 14:42:13 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 377804380839235584,
  "created_at" : "2013-09-11 14:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377789842148839424",
  "text" : "Obama: \"Let us have the courage\u2014like these survivors, like these families...to carry on, no matter how dark the night or difficult the day.\"",
  "id" : 377789842148839424,
  "created_at" : "2013-09-11 13:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377789233651810304",
  "text" : "Obama to 9\/11 survivors: \"Even more than memorials of stone and water, your lives are the greatest tribute to those we lost.\" #NeverForget",
  "id" : 377789233651810304,
  "created_at" : "2013-09-11 13:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377788514701959168",
  "text" : "President Obama on 9\/11: \"We pray for the memory of all those taken from us\u2014nearly 3,000 innocent souls.\" #NeverForget",
  "id" : 377788514701959168,
  "created_at" : "2013-09-11 13:39:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "377788045787168768",
  "text" : "Happening now: President Obama speaks at the 9\/11 Remembrance Ceremony at The Pentagon \u2014&gt; http:\/\/t.co\/b4tqL36eMn #NeverForget",
  "id" : 377788045787168768,
  "created_at" : "2013-09-11 13:37:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 43, 50 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 56, 59 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 65, 73 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377773572686901248",
  "text" : "At 8:46am ET, please join President Obama, @FLOTUS, the @VP, and @DrBiden in observing a moment of silence to mark the anniversary of 9\/11.",
  "id" : 377773572686901248,
  "created_at" : "2013-09-11 12:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 62, 69 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 75, 78 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 84, 92 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377763507930169344",
  "text" : "To mark the anniversary of 9\/11, please join President Obama, @FLOTUS, the @VP, and @DrBiden in observing a moment of silence at 8:46am ET.",
  "id" : 377763507930169344,
  "created_at" : "2013-09-11 12:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/IIVu2AipPs",
      "expanded_url" : "http:\/\/at.wh.gov\/oL1q1",
      "display_url" : "at.wh.gov\/oL1q1"
    } ]
  },
  "geo" : { },
  "id_str" : "377622324725301248",
  "text" : "Watch President Obama's address to the nation tonight on #Syria \u2014&gt; http:\/\/t.co\/IIVu2AipPs",
  "id" : 377622324725301248,
  "created_at" : "2013-09-11 02:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377616146066726912\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/ZOGB5bVcj8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT2P4lhCYAAArhd.jpg",
      "id_str" : "377616146075115520",
      "id" : 377616146075115520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT2P4lhCYAAArhd.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ZOGB5bVcj8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377616146066726912",
  "text" : "Our ideals, principles &amp; national security are at stake in Syria\u2014and that's why we must act: http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/ZOGB5bVcj8",
  "id" : 377616146066726912,
  "created_at" : "2013-09-11 02:14:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/qdqCcfN0gU",
      "expanded_url" : "http:\/\/at.wh.gov\/oKYiQ",
      "display_url" : "at.wh.gov\/oKYiQ"
    } ]
  },
  "geo" : { },
  "id_str" : "377608347257556992",
  "text" : "Obama: \"I\u2019d ask every member of Congress &amp; those of you watching at home tonight to watch those videos of the attack\" http:\/\/t.co\/qdqCcfN0gU",
  "id" : 377608347257556992,
  "created_at" : "2013-09-11 01:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377602036407091200",
  "text" : "Obama: \"When...we can stop children from being gassed to death and thereby make our own children safer over the long run...we should act.\"",
  "id" : 377602036407091200,
  "created_at" : "2013-09-11 01:18:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377601609275944961",
  "text" : "President Obama: \"Our ideals and principles, as well as our national security, are at stake in #Syria.\"",
  "id" : 377601609275944961,
  "created_at" : "2013-09-11 01:16:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377601280208031744",
  "text" : "President Obama: \"The burdens of leadership are often heavy, but the world is a better place because we have borne them.\" #Syria",
  "id" : 377601280208031744,
  "created_at" : "2013-09-11 01:15:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377601182463557632",
  "text" : "Obama: \"I have ordered our military to maintain their current posture to keep the pressure on Assad, and to be in a position to respond.\"",
  "id" : 377601182463557632,
  "created_at" : "2013-09-11 01:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 67, 70 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377601088657973248",
  "text" : "Obama: \"We will work together...to put forward a resolution at the @UN Security Council requiring Assad to give up his chemical weapons.\"",
  "id" : 377601088657973248,
  "created_at" : "2013-09-11 01:14:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377600916720869376",
  "text" : "Obama: \"I have...asked the leaders of Congress to postpone a vote to authorize the use of force while we pursue this diplomatic path\" #Syria",
  "id" : 377600916720869376,
  "created_at" : "2013-09-11 01:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377600793177649152",
  "text" : "Obama: \"The regime has now admitted...it has these weapons and...said they\u2019d join the Chemical Weapons Convention\u2014which prohibits their use\"",
  "id" : 377600793177649152,
  "created_at" : "2013-09-11 01:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377600697878859776",
  "text" : "President Obama: \"The Russian government has indicated a willingness to join...in pushing Assad to give up his chemical weapons.\" #Syria",
  "id" : 377600697878859776,
  "created_at" : "2013-09-11 01:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599980606722049",
  "text" : "Obama: \"The U.S. military doesn\u2019t do pin pricks. Even a limited strike will send a message to Assad that no other nation can deliver.\"",
  "id" : 377599980606722049,
  "created_at" : "2013-09-11 01:10:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599846980403200",
  "text" : "President Obama: \"I will not put American boots on the ground in #Syria. I will not pursue an open-ended action like Iraq or Afghanistan.\"",
  "id" : 377599846980403200,
  "created_at" : "2013-09-11 01:09:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599787597447168",
  "text" : "RT @WHLive: Obama: \"Let me answer some of the most important questions that I have heard from members of Congress &amp; that I have read in let\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 138, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377599672895823872",
    "text" : "Obama: \"Let me answer some of the most important questions that I have heard from members of Congress &amp; that I have read in letters.\" #Syria",
    "id" : 377599672895823872,
    "created_at" : "2013-09-11 01:09:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 377599787597447168,
  "created_at" : "2013-09-11 01:09:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599556327731203",
  "text" : "Obama: \"I have spent 4.5 years trying to end wars\u2014not start them. Our troops are out of Iraq. Our troops are coming home from Afghanistan.\"",
  "id" : 377599556327731203,
  "created_at" : "2013-09-11 01:08:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599481652338688",
  "text" : "Obama: \"After the terrible toll of Iraq &amp; Afghanistan, the idea of any military action\u2014no matter how limited\u2014is not going to be popular.\"",
  "id" : 377599481652338688,
  "created_at" : "2013-09-11 01:08:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599354183225344",
  "text" : "Obama: \"The purpose of this strike would be to deter Assad from using chemical weapons\u2014to degrade his regime\u2019s ability to use them.\" #Syria",
  "id" : 377599354183225344,
  "created_at" : "2013-09-11 01:07:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599260352462848",
  "text" : "Obama: \"It is in the national security interests of the United States to respond to the Assad regime\u2019s use of chemical weapons.\" #Syria",
  "id" : 377599260352462848,
  "created_at" : "2013-09-11 01:07:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377599154274308096",
  "text" : "Obama: \"A failure to stand against the use of chemical weapons would weaken prohibitions against other weapons of mass destruction.\" #Syria",
  "id" : 377599154274308096,
  "created_at" : "2013-09-11 01:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598914620190720",
  "text" : "President Obama: \"If we fail to act, the Assad regime will see no reason to stop using chemical weapons.\" #Syria",
  "id" : 377598914620190720,
  "created_at" : "2013-09-11 01:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598848840900608",
  "text" : "Obama: \"What happened to those people\u2014to those children\u2014is not only a violation of international law\u2014it\u2019s also a danger to our security.\"",
  "id" : 377598848840900608,
  "created_at" : "2013-09-11 01:05:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598748538318848",
  "text" : "Obama: \"When dictators commit atrocities\u2014they depend upon the world to look the other way until those horrifying pictures fade from memory.\"",
  "id" : 377598748538318848,
  "created_at" : "2013-09-11 01:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598491347800064",
  "text" : "President Obama: \"No one disputes that chemical weapons were used in #Syria.\"",
  "id" : 377598491347800064,
  "created_at" : "2013-09-11 01:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598354684801024",
  "text" : "President Obama on chemical weapons: \"The overwhelming majority of humanity has declared them off limits\u2014a crime against humanity.\" #Syria",
  "id" : 377598354684801024,
  "created_at" : "2013-09-11 01:03:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598235499433984",
  "text" : "President Obama: \"The images from this massacre are sickening. Men, women, children lying in rows, killed by poison gas.\" #Syria",
  "id" : 377598235499433984,
  "created_at" : "2013-09-11 01:03:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598152376729600",
  "text" : "President Obama: \"The situation profoundly changed though on August 21, when Assad\u2019s government gassed to death over 1,000 people.\" #Syria",
  "id" : 377598152376729600,
  "created_at" : "2013-09-11 01:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377598036454547456",
  "text" : "Obama: \"We cannot resolve somebody else\u2019s civil war through force, particularly after a decade of war in Iraq and Afghanistan.\" #Syria",
  "id" : 377598036454547456,
  "created_at" : "2013-09-11 01:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377597892384411648",
  "text" : "President Obama: \"My fellow Americans, tonight I want to talk to you about #Syria\u2014why it matters, and where we go from here.\"",
  "id" : 377597892384411648,
  "created_at" : "2013-09-11 01:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377597814114512896\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/u9Sol90eXd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT1_NglCUAAAmq4.png",
      "id_str" : "377597813829292032",
      "id" : 377597813829292032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT1_NglCUAAAmq4.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/u9Sol90eXd"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377597814114512896",
  "text" : "Happening now: President Obama addresses the nation on #Syria. Watch here \u2014&gt; http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/u9Sol90eXd",
  "id" : 377597814114512896,
  "created_at" : "2013-09-11 01:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377593956646649856",
  "text" : "RT @pfeiffer44: Getting ready to walk over to the East Wing for the President's Address to the Nation. Folks should tune in at 9 ET.Will be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377593536620675072",
    "text" : "Getting ready to walk over to the East Wing for the President's Address to the Nation. Folks should tune in at 9 ET.Will be worth a watch",
    "id" : 377593536620675072,
    "created_at" : "2013-09-11 00:44:49 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 377593956646649856,
  "created_at" : "2013-09-11 00:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377591500927807488\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/DNI2Ni7Bs4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT15eDOCMAE7QxO.jpg",
      "id_str" : "377591500936196097",
      "id" : 377591500936196097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT15eDOCMAE7QxO.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DNI2Ni7Bs4"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377591500927807488",
  "text" : "In 30 minutes, President Obama will address the nation on #Syria. Watch here \u2014&gt; http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/DNI2Ni7Bs4",
  "id" : 377591500927807488,
  "created_at" : "2013-09-11 00:36:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377538081911357441\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/YVEfgpUiSM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BT1I4p4CQAAiSdX.jpg",
      "id_str" : "377538081919746048",
      "id" : 377538081919746048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BT1I4p4CQAAiSdX.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/YVEfgpUiSM"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377538081911357441",
  "text" : "President Obama will address the nation on #Syria at 9pm ET. Watch here \u2014&gt; http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/YVEfgpUiSM",
  "id" : 377538081911357441,
  "created_at" : "2013-09-10 21:04:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/YirNoqPR4d",
      "expanded_url" : "http:\/\/at.wh.gov\/oKx00",
      "display_url" : "at.wh.gov\/oKx00"
    } ]
  },
  "geo" : { },
  "id_str" : "377527554120237056",
  "text" : "Today, 8 more countries joined the U.S. in support of a strong response to the use of chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/YirNoqPR4d",
  "id" : 377527554120237056,
  "created_at" : "2013-09-10 20:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 26, 36 ],
      "id_str" : "18814998",
      "id" : 18814998
    }, {
      "name" : "David Cameron",
      "screen_name" : "David_Cameron",
      "indices" : [ 43, 57 ],
      "id_str" : "103065157",
      "id" : 103065157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377502226467389440",
  "text" : "RT @NSCPress: POTUS &amp; @fhollande &amp; @David_Cameron agreed to work closely together to explore proposal to put all Syrian CW under internatio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fran\u00E7ois Hollande",
        "screen_name" : "fhollande",
        "indices" : [ 12, 22 ],
        "id_str" : "18814998",
        "id" : 18814998
      }, {
        "name" : "David Cameron",
        "screen_name" : "David_Cameron",
        "indices" : [ 29, 43 ],
        "id_str" : "103065157",
        "id" : 103065157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377497037442260992",
    "text" : "POTUS &amp; @fhollande &amp; @David_Cameron agreed to work closely together to explore proposal to put all Syrian CW under international control.",
    "id" : 377497037442260992,
    "created_at" : "2013-09-10 18:21:21 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 377502226467389440,
  "created_at" : "2013-09-10 18:41:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 19, 29 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 47, 59 ],
      "id_str" : "17004618",
      "id" : 17004618
    }, {
      "name" : "Lara Setrakian",
      "screen_name" : "Lara",
      "indices" : [ 65, 70 ],
      "id_str" : "21481343",
      "id" : 21481343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377494824808480768",
  "text" : "Starting now: Join @StateDept Secretary Kerry, @NickKristof, and @Lara for a Google+ Hangout on #Syria \u2014&gt; http:\/\/t.co\/9uaOryb8Rp",
  "id" : 377494824808480768,
  "created_at" : "2013-09-10 18:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 22, 34 ],
      "id_str" : "17004618",
      "id" : 17004618
    }, {
      "name" : "Lara Setrakian",
      "screen_name" : "Lara",
      "indices" : [ 40, 45 ],
      "id_str" : "21481343",
      "id" : 21481343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/rftlGBXX7U",
      "expanded_url" : "http:\/\/at.wh.gov\/oJN3Q",
      "display_url" : "at.wh.gov\/oJN3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "377476614939881473",
  "text" : "Join Secretary Kerry, @NickKristof, and @Lara for a Google+ Hangout on #Syria at 2pm ET \u2014&gt; http:\/\/t.co\/rftlGBXX7U",
  "id" : 377476614939881473,
  "created_at" : "2013-09-10 17:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377464822360596480",
  "text" : "RT @WhiteHouseCEQ: Avg fuel economy for new cars hits 24.9 mpg! With Admin's standards will reach 54.5 in 2025, save drivers $8K at pump ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/x3hnOtf4wt",
        "expanded_url" : "http:\/\/nyti.ms\/1b1oh02",
        "display_url" : "nyti.ms\/1b1oh02"
      } ]
    },
    "geo" : { },
    "id_str" : "377458214482100225",
    "text" : "Avg fuel economy for new cars hits 24.9 mpg! With Admin's standards will reach 54.5 in 2025, save drivers $8K at pump http:\/\/t.co\/x3hnOtf4wt",
    "id" : 377458214482100225,
    "created_at" : "2013-09-10 15:47:05 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 377464822360596480,
  "created_at" : "2013-09-10 16:13:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377458067069087744",
  "text" : "RT @Lehrich44: As POTUS heads to hill today, admin has now had #Syria discussions with at least 93 Senators and more than 350 House members",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 48, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377446614245191683",
    "text" : "As POTUS heads to hill today, admin has now had #Syria discussions with at least 93 Senators and more than 350 House members",
    "id" : 377446614245191683,
    "created_at" : "2013-09-10 15:01:00 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 377458067069087744,
  "created_at" : "2013-09-10 15:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377450277093117953\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/wJHvk1Y1P2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTz5BvcCEAAV_fc.jpg",
      "id_str" : "377450277101506560",
      "id" : 377450277101506560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTz5BvcCEAAV_fc.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/wJHvk1Y1P2"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377450277093117953",
  "text" : "Tonight at 9pm ET, President Obama will address the nation on #Syria. Tune in here \u2014&gt; http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/wJHvk1Y1P2",
  "id" : 377450277093117953,
  "created_at" : "2013-09-10 15:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377232899109425153\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/S7XuEnLFu3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTwzUrWCEAA1R8Y.jpg",
      "id_str" : "377232899117813760",
      "id" : 377232899117813760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTwzUrWCEAA1R8Y.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/S7XuEnLFu3"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377232899109425153",
  "text" : "The use of chemical weapons on innocent civilians cannot stand \u2014&gt; http:\/\/t.co\/9uaOryb8Rp #Syria, http:\/\/t.co\/S7XuEnLFu3",
  "id" : 377232899109425153,
  "created_at" : "2013-09-10 00:51:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377222262169952257",
  "text" : "President Obama will address the nation on #Syria tomorrow night at 9pm ET. Watch here \u2014&gt; http:\/\/t.co\/9uaOryb8Rp",
  "id" : 377222262169952257,
  "created_at" : "2013-09-10 00:09:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 16, 31 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 36, 51 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VYqKCwwO0y",
      "expanded_url" : "http:\/\/at.wh.gov\/oIuIU",
      "display_url" : "at.wh.gov\/oIuIU"
    } ]
  },
  "geo" : { },
  "id_str" : "377215229186146304",
  "text" : "Worth watching: @AmbassadorRice and @HillaryClinton on responding to the Assad regime's use of chemical weapons \u2014&gt; http:\/\/t.co\/VYqKCwwO0y",
  "id" : 377215229186146304,
  "created_at" : "2013-09-09 23:41:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 1, 16 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/eGEZFPAxVa",
      "expanded_url" : "http:\/\/at.wh.gov\/oIefv",
      "display_url" : "at.wh.gov\/oIefv"
    } ]
  },
  "geo" : { },
  "id_str" : "377205939117363201",
  "text" : ".@HillaryClinton on #Syria: \"It demands a strong response from the international community led by the United States.\" http:\/\/t.co\/eGEZFPAxVa",
  "id" : 377205939117363201,
  "created_at" : "2013-09-09 23:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 31, 43 ],
      "id_str" : "17004618",
      "id" : 17004618
    }, {
      "name" : "Lara Setrakian",
      "screen_name" : "Lara",
      "indices" : [ 48, 53 ],
      "id_str" : "21481343",
      "id" : 21481343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecKerry",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "Syria",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/q7jqrrhjx5",
      "expanded_url" : "http:\/\/goo.gl\/1wBfRB",
      "display_url" : "goo.gl\/1wBfRB"
    } ]
  },
  "geo" : { },
  "id_str" : "377200442368720896",
  "text" : "RT @StateDept: Join #SecKerry, @NickKristof and @Lara for a Google+ Hangout on #Syria at 2:00 PM ET September 10. http:\/\/t.co\/q7jqrrhjx5 #T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Kristof",
        "screen_name" : "NickKristof",
        "indices" : [ 16, 28 ],
        "id_str" : "17004618",
        "id" : 17004618
      }, {
        "name" : "Lara Setrakian",
        "screen_name" : "Lara",
        "indices" : [ 33, 38 ],
        "id_str" : "21481343",
        "id" : 21481343
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecKerry",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "Syria",
        "indices" : [ 64, 70 ]
      }, {
        "text" : "TalkSyria",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/q7jqrrhjx5",
        "expanded_url" : "http:\/\/goo.gl\/1wBfRB",
        "display_url" : "goo.gl\/1wBfRB"
      } ]
    },
    "geo" : { },
    "id_str" : "376817415272665088",
    "text" : "Join #SecKerry, @NickKristof and @Lara for a Google+ Hangout on #Syria at 2:00 PM ET September 10. http:\/\/t.co\/q7jqrrhjx5 #TalkSyria",
    "id" : 376817415272665088,
    "created_at" : "2013-09-08 21:20:47 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 377200442368720896,
  "created_at" : "2013-09-09 22:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 32, 47 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/eGEZFPAxVa",
      "expanded_url" : "http:\/\/at.wh.gov\/oIefv",
      "display_url" : "at.wh.gov\/oIefv"
    } ]
  },
  "geo" : { },
  "id_str" : "377177766984040448",
  "text" : "Watch former Secretary of State @HillaryClinton on the need to act in #Syria \u2014&gt; http:\/\/t.co\/eGEZFPAxVa",
  "id" : 377177766984040448,
  "created_at" : "2013-09-09 21:12:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377156847406305281",
  "text" : "RT @NSCPress: More countries are joining the U.S. in support of a strong international response to the Assad regime's use of CW: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/dBJOZf6GLp",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/09\/09\/statement-additional-countries-support-september-6-joint-statement-syria",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377153471729774592",
    "text" : "More countries are joining the U.S. in support of a strong international response to the Assad regime's use of CW: http:\/\/t.co\/dBJOZf6GLp",
    "id" : 377153471729774592,
    "created_at" : "2013-09-09 19:36:09 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 377156847406305281,
  "created_at" : "2013-09-09 19:49:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    }, {
      "name" : "Rite Aid",
      "screen_name" : "riteaid",
      "indices" : [ 29, 37 ],
      "id_str" : "133865373",
      "id" : 133865373
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377148146318458880",
  "text" : "RT @Racusen44: Big news from @riteaid today, which will join growing list of pharmacies helping inform consumers about #ObamaCare: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rite Aid",
        "screen_name" : "riteaid",
        "indices" : [ 14, 22 ],
        "id_str" : "133865373",
        "id" : 133865373
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/YbJc2KsDdx",
        "expanded_url" : "http:\/\/1.usa.gov\/15K3qaC",
        "display_url" : "1.usa.gov\/15K3qaC"
      } ]
    },
    "geo" : { },
    "id_str" : "377129809119166464",
    "text" : "Big news from @riteaid today, which will join growing list of pharmacies helping inform consumers about #ObamaCare: http:\/\/t.co\/YbJc2KsDdx",
    "id" : 377129809119166464,
    "created_at" : "2013-09-09 18:02:07 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 377148146318458880,
  "created_at" : "2013-09-09 19:14:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 135, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377124909131915266",
  "text" : "Rice: We \"can and must take action\u2014carefully, responsibly &amp; purposefully\u2014to reduce the chances of such an outrage happening again\" #Syria",
  "id" : 377124909131915266,
  "created_at" : "2013-09-09 17:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 113, 128 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377123919490060289",
  "text" : "\"We have seen what happens when the world fails to respond to horrific abuses on the scale we saw in Damascus.\" \u2014@AmbassadorRice on #Syria",
  "id" : 377123919490060289,
  "created_at" : "2013-09-09 17:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377123094147514368",
  "text" : "Rice: \"By allowing Assad to act with impunity, everything else becomes even harder\u2014from countering terrorism to defending human rights.\"",
  "id" : 377123094147514368,
  "created_at" : "2013-09-09 17:35:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377122438850416641",
  "text" : "Rice: Limited strikes \"will make clear to Assad and his allies\u2014Hezbollah &amp; Iran\u2014that they should not test the resolve of the United States.\"",
  "id" : 377122438850416641,
  "created_at" : "2013-09-09 17:32:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377121102121541633",
  "text" : "Rice: \"Our overarching goal is to end the underlying conflict through a negotiated, political transition in which Assad leaves power\" #Syria",
  "id" : 377121102121541633,
  "created_at" : "2013-09-09 17:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 94, 109 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377120047610601473",
  "text" : "\"Foreign policy experts from the left, right and center have strongly endorsed such action.\" \u2014@AmbassadorRice on limited strikes in #Syria",
  "id" : 377120047610601473,
  "created_at" : "2013-09-09 17:23:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 116, 131 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 4, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377119094245298176",
  "text" : "\"In #Syria, we have the undeniable proof that chemical weapons have already been unleashed with horrific results.\" \u2014@AmbassadorRice",
  "id" : 377119094245298176,
  "created_at" : "2013-09-09 17:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 95, 110 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377118698525310976",
  "text" : "\"This will not be Iraq or Afghanistan. There will be no American boots on the ground\u2014period.\" \u2014@AmbassadorRice on the need to act in #Syria",
  "id" : 377118698525310976,
  "created_at" : "2013-09-09 17:17:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377118317242089472",
  "text" : "Rice on #Syria: \"These would be limited strikes to deter the Syrian regime from using chemical weapons and degrade their ability to do.\"",
  "id" : 377118317242089472,
  "created_at" : "2013-09-09 17:16:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 138, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377116832043245568",
  "text" : "Rice: \"The reason Pres. Obama decided to pursue limited strikes is that we &amp; others have already exhausted a host of other measures.\" #Syria",
  "id" : 377116832043245568,
  "created_at" : "2013-09-09 17:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 121, 136 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377116183238938624",
  "text" : "\"Failing to respond brings us closer to the day when terrorists might gain and use chemical weapons against Americans.\" \u2014@AmbassadorRice",
  "id" : 377116183238938624,
  "created_at" : "2013-09-09 17:07:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 94, 109 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377115949024817152",
  "text" : "\"Failing to respond means more and more Syrians will die from Assad\u2019s poisonous stockpiles.\" \u2014@AmbassadorRice #Syria",
  "id" : 377115949024817152,
  "created_at" : "2013-09-09 17:07:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 95, 110 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377115674784432128",
  "text" : "\"The use of chemical weapons also directly threatens our closest ally in the region, Israel.\" \u2014@AmbassadorRice on #Syria",
  "id" : 377115674784432128,
  "created_at" : "2013-09-09 17:05:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377115243681308672",
  "text" : "Rice: \"The likelihood that, left unchecked, Assad will use these weapons again &amp; again takes the Syrian conflict to an entirely new level.\"",
  "id" : 377115243681308672,
  "created_at" : "2013-09-09 17:04:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 82, 97 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 1, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377114583405563904",
  "text" : "\"#Syria's use of chemical weapons is a serious threat to our national security.\" \u2014@AmbassadorRice",
  "id" : 377114583405563904,
  "created_at" : "2013-09-09 17:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 15, 30 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377113245472919555",
  "text" : "Happening now: @AmbassadorRice speaks on holding the Assad regime accountable for using chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/9uaOryb8Rp",
  "id" : 377113245472919555,
  "created_at" : "2013-09-09 16:56:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Bill Scher",
      "screen_name" : "billscher",
      "indices" : [ 32, 42 ],
      "id_str" : "14246055",
      "id" : 14246055
    }, {
      "name" : "Rep. Keith Ellison",
      "screen_name" : "keithellison",
      "indices" : [ 61, 74 ],
      "id_str" : "14135426",
      "id" : 14135426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377111179044208640",
  "text" : "RT @jesseclee44: Thoughtful. MT @billscher: ProgCauc CoChair @KeithEllison: \"responsibility to protect civilian pops. from genocide\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Scher",
        "screen_name" : "billscher",
        "indices" : [ 15, 25 ],
        "id_str" : "14246055",
        "id" : 14246055
      }, {
        "name" : "Rep. Keith Ellison",
        "screen_name" : "keithellison",
        "indices" : [ 44, 57 ],
        "id_str" : "14135426",
        "id" : 14135426
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/elMqsN9gAg",
        "expanded_url" : "http:\/\/cbsloc.al\/18Jdliy",
        "display_url" : "cbsloc.al\/18Jdliy"
      } ]
    },
    "geo" : { },
    "id_str" : "377109389296955392",
    "text" : "Thoughtful. MT @billscher: ProgCauc CoChair @KeithEllison: \"responsibility to protect civilian pops. from genocide\" http:\/\/t.co\/elMqsN9gAg",
    "id" : 377109389296955392,
    "created_at" : "2013-09-09 16:40:59 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 377111179044208640,
  "created_at" : "2013-09-09 16:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 21, 36 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/377106942734245891\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/TKBJnUtZJ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTvAxChCAAAk4kH.jpg",
      "id_str" : "377106942537105408",
      "id" : 377106942537105408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTvAxChCAAAk4kH.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/TKBJnUtZJ5"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377106942734245891",
  "text" : "Starting soon: Watch @AmbassadorRice speak on the need to act in #Syria at 12:30pm ET \u2014&gt; http:\/\/t.co\/9uaOryb8Rp, http:\/\/t.co\/TKBJnUtZJ5",
  "id" : 377106942734245891,
  "created_at" : "2013-09-09 16:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Port of Baltimore",
      "screen_name" : "portofbalt",
      "indices" : [ 69, 80 ],
      "id_str" : "208668757",
      "id" : 208668757
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 126, 132 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infrastructure",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/R4gj9lPica",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "377092791542611969",
  "text" : "RT @VP: LISTEN LIVE: http:\/\/t.co\/R4gj9lPica - VP speaking shortly at @portofbalt on importance of #infrastructure investment. @USDOT #TIGER\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Port of Baltimore",
        "screen_name" : "portofbalt",
        "indices" : [ 61, 72 ],
        "id_str" : "208668757",
        "id" : 208668757
      }, {
        "name" : "TransportationGov",
        "screen_name" : "USDOT",
        "indices" : [ 118, 124 ],
        "id_str" : "393562221",
        "id" : 393562221
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "infrastructure",
        "indices" : [ 90, 105 ]
      }, {
        "text" : "TIGER13",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/R4gj9lPica",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "377091572765962241",
    "text" : "LISTEN LIVE: http:\/\/t.co\/R4gj9lPica - VP speaking shortly at @portofbalt on importance of #infrastructure investment. @USDOT #TIGER13",
    "id" : 377091572765962241,
    "created_at" : "2013-09-09 15:30:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 377092791542611969,
  "created_at" : "2013-09-09 15:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 15, 30 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "377080233800634369",
  "text" : "At 12:30pm ET, @AmbassadorRice speaks on holding the Assad regime accountable for using chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/9uaOryb8Rp",
  "id" : 377080233800634369,
  "created_at" : "2013-09-09 14:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377072209321152512",
  "text" : "RT @jearnest44: Congress back in DC today facing one central q: Should there be consequences for a regime using chemical weapons against ch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377037951496388608",
    "text" : "Congress back in DC today facing one central q: Should there be consequences for a regime using chemical weapons against children? #Syria",
    "id" : 377037951496388608,
    "created_at" : "2013-09-09 11:57:07 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 377072209321152512,
  "created_at" : "2013-09-09 14:13:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/376866051541069824\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Bu3cpdN60U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTrlrVqCcAA-bVj.jpg",
      "id_str" : "376866051549458432",
      "id" : 376866051549458432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTrlrVqCcAA-bVj.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Bu3cpdN60U"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/h8Sf00OMvN",
      "expanded_url" : "http:\/\/at.wh.gov\/oG6sD",
      "display_url" : "at.wh.gov\/oG6sD"
    } ]
  },
  "geo" : { },
  "id_str" : "376866051541069824",
  "text" : "It's time to hold the Assad regime accountable for its use of chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/h8Sf00OMvN http:\/\/t.co\/Bu3cpdN60U",
  "id" : 376866051541069824,
  "created_at" : "2013-09-09 00:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zsLlCOKBWy",
      "expanded_url" : "http:\/\/youtu.be\/uCrCujWIgUY",
      "display_url" : "youtu.be\/uCrCujWIgUY"
    } ]
  },
  "geo" : { },
  "id_str" : "376427286830276608",
  "text" : "\"We cannot turn a blind eye to images like the ones we\u2019ve seen out of #Syria\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/zsLlCOKBWy",
  "id" : 376427286830276608,
  "created_at" : "2013-09-07 19:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/zsLlCOKBWy",
      "expanded_url" : "http:\/\/youtu.be\/uCrCujWIgUY",
      "display_url" : "youtu.be\/uCrCujWIgUY"
    } ]
  },
  "geo" : { },
  "id_str" : "376359276841025536",
  "text" : "President Obama: \"We can\u2019t ignore chemical weapons attacks like this\u2014even if they happen halfway around the world.\" http:\/\/t.co\/zsLlCOKBWy",
  "id" : 376359276841025536,
  "created_at" : "2013-09-07 15:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/376338996931985409\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/5ibnk5f6sf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTkGUuOCAAAuNNi.jpg",
      "id_str" : "376338996936179712",
      "id" : 376338996936179712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTkGUuOCAAAuNNi.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/5ibnk5f6sf"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 61, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/YUp26GA3jM",
      "expanded_url" : "http:\/\/youtu.be\/uCrCujWIgUY",
      "display_url" : "youtu.be\/uCrCujWIgUY"
    } ]
  },
  "geo" : { },
  "id_str" : "376338996931985409",
  "text" : "Watch President Obama's Weekly Address on the need to act in #Syria \u2014&gt; http:\/\/t.co\/YUp26GA3jM http:\/\/t.co\/5ibnk5f6sf",
  "id" : 376338996931985409,
  "created_at" : "2013-09-07 13:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 93, 109 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/GP1itDCS3B",
      "expanded_url" : "http:\/\/at.wh.gov\/oE3hJ",
      "display_url" : "at.wh.gov\/oE3hJ"
    } ]
  },
  "geo" : { },
  "id_str" : "376111019921133568",
  "text" : "\"If we cannot summon the courage to act...our ability to lead in the world is compromised.\" \u2014@AmbassadorPower: http:\/\/t.co\/GP1itDCS3B #Syria",
  "id" : 376111019921133568,
  "created_at" : "2013-09-06 22:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376101025695817730",
  "text" : "RT @Schultz44: Stay tuned for more details, but on Monday, White House National Security Adviser Susan Rice will give a speech at @NewAmeri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New America",
        "screen_name" : "NewAmerica",
        "indices" : [ 115, 126 ],
        "id_str" : "7091082",
        "id" : 7091082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376100616134610944",
    "text" : "Stay tuned for more details, but on Monday, White House National Security Adviser Susan Rice will give a speech at @NewAmerica Foundation.",
    "id" : 376100616134610944,
    "created_at" : "2013-09-06 21:52:29 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 376101025695817730,
  "created_at" : "2013-09-06 21:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/f4fWBQ0jqs",
      "expanded_url" : "http:\/\/bit.ly\/13oyxKY",
      "display_url" : "bit.ly\/13oyxKY"
    } ]
  },
  "geo" : { },
  "id_str" : "376098337255985152",
  "text" : "RT @Simas44: More good ACA premium news. MN unveils low ACA rates. As low as $90 per month, BEFORE any tax credit. http:\/\/t.co\/f4fWBQ0jqs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/f4fWBQ0jqs",
        "expanded_url" : "http:\/\/bit.ly\/13oyxKY",
        "display_url" : "bit.ly\/13oyxKY"
      } ]
    },
    "geo" : { },
    "id_str" : "376075935671267328",
    "text" : "More good ACA premium news. MN unveils low ACA rates. As low as $90 per month, BEFORE any tax credit. http:\/\/t.co\/f4fWBQ0jqs",
    "id" : 376075935671267328,
    "created_at" : "2013-09-06 20:14:24 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 376098337255985152,
  "created_at" : "2013-09-06 21:43:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 1, 17 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/pQfaFm1sXp",
      "expanded_url" : "http:\/\/at.wh.gov\/oDQ91",
      "display_url" : "at.wh.gov\/oDQ91"
    } ]
  },
  "geo" : { },
  "id_str" : "376078100318023680",
  "text" : ".@AmbassadorPower on why we need to respond to the Assad regime's use of chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/pQfaFm1sXp",
  "id" : 376078100318023680,
  "created_at" : "2013-09-06 20:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 6, 9 ],
      "id_str" : "14159148",
      "id" : 14159148
    }, {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 95, 111 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376051979593588736",
  "text" : "\u201CThe [@UN] Security Council the world needs to deal with this crisis is not the one we have.\u201D \u2014@AmbassadorPower #Syria",
  "id" : 376051979593588736,
  "created_at" : "2013-09-06 18:39:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 39, 55 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376051259079278593",
  "text" : "\u201CWe have exhausted the alternatives.\u201D \u2014@AmbassadorPower on the need for a military response to the use of chemical weapons in #Syria",
  "id" : 376051259079278593,
  "created_at" : "2013-09-06 18:36:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 12, 28 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/9uaOryb8Rp",
      "expanded_url" : "http:\/\/wh.gov\/syria",
      "display_url" : "wh.gov\/syria"
    } ]
  },
  "geo" : { },
  "id_str" : "376048158301622272",
  "text" : "Watch live: @AmbassadorPower speaks on the need to respond to the use of chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/9uaOryb8Rp",
  "id" : 376048158301622272,
  "created_at" : "2013-09-06 18:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 22, 38 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "376038855121453056",
  "text" : "Tune in at 2pm ET for @AmbassadorPower's speech on responding to the use of chemical weapons in #Syria: http:\/\/t.co\/KvadYk9atb",
  "id" : 376038855121453056,
  "created_at" : "2013-09-06 17:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POLITICO",
      "screen_name" : "politico",
      "indices" : [ 121, 130 ],
      "id_str" : "9300262",
      "id" : 9300262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/DhTc5zQJgp",
      "expanded_url" : "http:\/\/ow.ly\/oDrYz",
      "display_url" : "ow.ly\/oDrYz"
    } ]
  },
  "geo" : { },
  "id_str" : "376031960935587840",
  "text" : "Former Secretary of State Madeleine Albright to Congress: Authorize Obama's Syria plan \u2014&gt; http:\/\/t.co\/DhTc5zQJgp (via @Politico)",
  "id" : 376031960935587840,
  "created_at" : "2013-09-06 17:19:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/1smn8J3HSE",
      "expanded_url" : "http:\/\/at.wh.gov\/oDlik",
      "display_url" : "at.wh.gov\/oDlik"
    } ]
  },
  "geo" : { },
  "id_str" : "376019731817320448",
  "text" : "Joint statement on #Syria: \"We condemn in the strongest terms the horrific chemical weapons attack.\" http:\/\/t.co\/1smn8J3HSE",
  "id" : 376019731817320448,
  "created_at" : "2013-09-06 16:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "Syria",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376011880625500160",
  "text" : "RT @NSCPress: In his #G20 press conference, the President announced that he will address the American people on #Syria from the White House\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "G20",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "Syria",
        "indices" : [ 98, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375987449928761344",
    "text" : "In his #G20 press conference, the President announced that he will address the American people on #Syria from the White House on Tuesday.",
    "id" : 375987449928761344,
    "created_at" : "2013-09-06 14:22:48 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 376011880625500160,
  "created_at" : "2013-09-06 15:59:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375999818721554433\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/CcrJvLf0Qs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTfR188CcAElguF.jpg",
      "id_str" : "375999818729943041",
      "id" : 375999818729943041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTfR188CcAElguF.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/CcrJvLf0Qs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375999818721554433",
  "text" : "RT the news: Our economy has added 7.5 million private-sector jobs over the last 42 months. More work to do: http:\/\/t.co\/CcrJvLf0Qs",
  "id" : 375999818721554433,
  "created_at" : "2013-09-06 15:11:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375990495345774592",
  "text" : "\"Over 1,400 people were gassed. Over 400 of them were children.\" \u2014President Obama on the need to respond to chemical weapons use in #Syria",
  "id" : 375990495345774592,
  "created_at" : "2013-09-06 14:34:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375989330214256640",
  "text" : "\"If we are serious about upholding a ban on chemical weapons use, then an international response is required.\" \u2014President Obama on #Syria",
  "id" : 375989330214256640,
  "created_at" : "2013-09-06 14:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "375980848614735872",
  "text" : "Tune in now for President Obama's press conference at the G-20: http:\/\/t.co\/b4tqL36eMn",
  "id" : 375980848614735872,
  "created_at" : "2013-09-06 13:56:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375734032530567168",
  "text" : "RT @Simas44: Really great news about the affordable choices people will have under ACA with plans under $100 per month.  http:\/\/t.co\/4Zkmay\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/4Zkmay84li",
        "expanded_url" : "http:\/\/on.msnbc.com\/162RwvJ",
        "display_url" : "on.msnbc.com\/162RwvJ"
      } ]
    },
    "geo" : { },
    "id_str" : "375733212019830784",
    "text" : "Really great news about the affordable choices people will have under ACA with plans under $100 per month.  http:\/\/t.co\/4Zkmay84li",
    "id" : 375733212019830784,
    "created_at" : "2013-09-05 21:32:33 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 375734032530567168,
  "created_at" : "2013-09-05 21:35:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375717463578521600\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/tp51tjVmxV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTbRCuDCMAAvg7Q.jpg",
      "id_str" : "375717463582715904",
      "id" : 375717463582715904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTbRCuDCMAAvg7Q.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/tp51tjVmxV"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/nnA24wf42l",
      "expanded_url" : "http:\/\/at.wh.gov\/oBAh3",
      "display_url" : "at.wh.gov\/oBAh3"
    } ]
  },
  "geo" : { },
  "id_str" : "375717463578521600",
  "text" : "President Obama on the need to respond to the Assad regime's chemical weapons use in #Syria: http:\/\/t.co\/nnA24wf42l, http:\/\/t.co\/tp51tjVmxV",
  "id" : 375717463578521600,
  "created_at" : "2013-09-05 20:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 16, 32 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/GsgzYgrxDp",
      "expanded_url" : "http:\/\/www.americanprogress.org\/press\/advisory\/2013\/09\/05\/73541\/advisory-ambassador-samantha-power-to-address-the-need-for-action-in-syria\/",
      "display_url" : "americanprogress.org\/press\/advisory\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375705467437056000",
  "text" : "RT @Lehrich44: .@AmbassadorPower to address need for Syria action at CAP tomorrow http:\/\/t.co\/GsgzYgrxDp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Samantha Power",
        "screen_name" : "AmbassadorPower",
        "indices" : [ 1, 17 ],
        "id_str" : "1615463502",
        "id" : 1615463502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/GsgzYgrxDp",
        "expanded_url" : "http:\/\/www.americanprogress.org\/press\/advisory\/2013\/09\/05\/73541\/advisory-ambassador-samantha-power-to-address-the-need-for-action-in-syria\/",
        "display_url" : "americanprogress.org\/press\/advisory\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375703375104335872",
    "text" : ".@AmbassadorPower to address need for Syria action at CAP tomorrow http:\/\/t.co\/GsgzYgrxDp",
    "id" : 375703375104335872,
    "created_at" : "2013-09-05 19:33:59 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 375705467437056000,
  "created_at" : "2013-09-05 19:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 117, 133 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375669990319353856",
  "text" : "\"This is the world's red line...98% of the world's population\u2026agree that the use of chemical weapons is abhorrent.\" \u2014@AmbassadorPower #Syria",
  "id" : 375669990319353856,
  "created_at" : "2013-09-05 17:21:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 15, 31 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/qRdwu3UdJA",
      "expanded_url" : "http:\/\/webtv.un.org",
      "display_url" : "webtv.un.org"
    } ]
  },
  "geo" : { },
  "id_str" : "375667787068239872",
  "text" : "Happening now: @AmbassadorPower speaks on the situation in #Syria. Watch \u2014&gt; http:\/\/t.co\/qRdwu3UdJA",
  "id" : 375667787068239872,
  "created_at" : "2013-09-05 17:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "indices" : [ 3, 8 ],
      "id_str" : "249677516",
      "id" : 249677516
    }, {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 16, 32 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/XCgJ0snXhA",
      "expanded_url" : "http:\/\/webtv.un.org",
      "display_url" : "webtv.un.org"
    } ]
  },
  "geo" : { },
  "id_str" : "375664006821720064",
  "text" : "RT @USUN: Watch @AmbassadorPower speak on #Syria around 1pm ET via http:\/\/t.co\/XCgJ0snXhA.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Samantha Power",
        "screen_name" : "AmbassadorPower",
        "indices" : [ 6, 22 ],
        "id_str" : "1615463502",
        "id" : 1615463502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 32, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/XCgJ0snXhA",
        "expanded_url" : "http:\/\/webtv.un.org",
        "display_url" : "webtv.un.org"
      } ]
    },
    "geo" : { },
    "id_str" : "375657613511241728",
    "text" : "Watch @AmbassadorPower speak on #Syria around 1pm ET via http:\/\/t.co\/XCgJ0snXhA.",
    "id" : 375657613511241728,
    "created_at" : "2013-09-05 16:32:09 +0000",
    "user" : {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "protected" : false,
      "id_str" : "249677516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616236749149241345\/Dm-anuiC_normal.jpg",
      "id" : 249677516,
      "verified" : true
    }
  },
  "id" : 375664006821720064,
  "created_at" : "2013-09-05 16:57:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 13, 25 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375653545887809536\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/kpfRWpjOLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTaW6OHCQAEwCbK.jpg",
      "id_str" : "375653545896198145",
      "id" : 375653545896198145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTaW6OHCQAEwCbK.jpg",
      "sizes" : [ {
        "h" : 848,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 727,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/kpfRWpjOLA"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AXdkzYW2iw",
      "expanded_url" : "http:\/\/at.wh.gov\/oB0UY",
      "display_url" : "at.wh.gov\/oB0UY"
    } ]
  },
  "geo" : { },
  "id_str" : "375653545887809536",
  "text" : "ICYMI, watch @BillClinton's speech on the importance of implementing #Obamacare: http:\/\/t.co\/AXdkzYW2iw, http:\/\/t.co\/kpfRWpjOLA",
  "id" : 375653545887809536,
  "created_at" : "2013-09-05 16:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/tkjctUrxLz",
      "expanded_url" : "http:\/\/at.wh.gov\/oARTg",
      "display_url" : "at.wh.gov\/oARTg"
    } ]
  },
  "geo" : { },
  "id_str" : "375640228498640896",
  "text" : "Get the latest on President Obama's response to the Assad regime's use of chemical weapons in #Syria \u2014&gt; http:\/\/t.co\/tkjctUrxLz",
  "id" : 375640228498640896,
  "created_at" : "2013-09-05 15:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 1, 10 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375390574708133888\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2qv9qF7ZcR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTWnvSICEAAAGu3.png",
      "id_str" : "375390574716522496",
      "id" : 375390574716522496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTWnvSICEAAAGu3.png",
      "sizes" : [ {
        "h" : 267,
        "resize" : "fit",
        "w" : 645
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 645
      } ],
      "display_url" : "pic.twitter.com\/2qv9qF7ZcR"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375390574708133888",
  "text" : ".@PressSec on passage of the Senate Foreign Relations Committee's resolution authorizing military action in #Syria: http:\/\/t.co\/2qv9qF7ZcR",
  "id" : 375390574708133888,
  "created_at" : "2013-09-04 22:51:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eSgvGKZDVg",
      "expanded_url" : "http:\/\/at.wh.gov\/oz7GI",
      "display_url" : "at.wh.gov\/oz7GI"
    } ]
  },
  "geo" : { },
  "id_str" : "375377975681622016",
  "text" : "\"Shanah Tovah!\" \u2014President Obama wishes the Jewish community in America and around the world a happy Rosh Hashanah: http:\/\/t.co\/eSgvGKZDVg",
  "id" : 375377975681622016,
  "created_at" : "2013-09-04 22:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375348641126711296\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/aWEDcTlFEq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTWBmaWIcAA9SQo.jpg",
      "id_str" : "375348640862466048",
      "id" : 375348640862466048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTWBmaWIcAA9SQo.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aWEDcTlFEq"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375348641126711296",
  "text" : "POTUS checks out a vehicle powered by fuel cells at the Royal Institute of Technology in Sweden. #ActOnClimate, http:\/\/t.co\/aWEDcTlFEq",
  "id" : 375348641126711296,
  "created_at" : "2013-09-04 20:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375337531220713472\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/raKQHsib0U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTV3fvaIcAAmlQJ.jpg",
      "id_str" : "375337531141025792",
      "id" : 375337531141025792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTV3fvaIcAAmlQJ.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/raKQHsib0U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375337531220713472",
  "text" : "President Obama at the Great Synagogue in Stockholm, Sweden: http:\/\/t.co\/raKQHsib0U",
  "id" : 375337531220713472,
  "created_at" : "2013-09-04 19:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/YcIGMTfqCz",
      "expanded_url" : "http:\/\/at.wh.gov\/oz3eQ",
      "display_url" : "at.wh.gov\/oz3eQ"
    } ]
  },
  "geo" : { },
  "id_str" : "375329278520340480",
  "text" : "Get the facts on what the U.S. &amp; Sweden are doing to promote clean energy and #ActOnClimate \u2014&gt; http:\/\/t.co\/YcIGMTfqCz",
  "id" : 375329278520340480,
  "created_at" : "2013-09-04 18:47:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375315540794806273",
  "text" : "RT @Simas44: Michigan expands Medicaid &amp; gives hundreds of thousands of residents the peace of mind knowing they're covered. #ACA http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/kEyKu2FT1m",
        "expanded_url" : "http:\/\/reut.rs\/18AT0Le",
        "display_url" : "reut.rs\/18AT0Le"
      } ]
    },
    "geo" : { },
    "id_str" : "375262461646999552",
    "text" : "Michigan expands Medicaid &amp; gives hundreds of thousands of residents the peace of mind knowing they're covered. #ACA http:\/\/t.co\/kEyKu2FT1m",
    "id" : 375262461646999552,
    "created_at" : "2013-09-04 14:21:57 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 375315540794806273,
  "created_at" : "2013-09-04 17:52:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/375302570660474881\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/rjLzRX0ao0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTVXswxCcAAAvYw.jpg",
      "id_str" : "375302570471747584",
      "id" : 375302570471747584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTVXswxCcAAAvYw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rjLzRX0ao0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/uobgqeLAab",
      "expanded_url" : "http:\/\/at.wh.gov\/oyOvt",
      "display_url" : "at.wh.gov\/oyOvt"
    } ]
  },
  "geo" : { },
  "id_str" : "375302570660474881",
  "text" : "President Obama is wheels down for his trip to Sweden and the G-20 \u2014&gt; http:\/\/t.co\/uobgqeLAab, http:\/\/t.co\/rjLzRX0ao0",
  "id" : 375302570660474881,
  "created_at" : "2013-09-04 17:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375295679960072193",
  "text" : "RT @HealthCareTara: \u201CThe health of our people - security &amp; stability of our families &amp; the strength of our economy- all riding on getting a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375294463989387265",
    "text" : "\u201CThe health of our people - security &amp; stability of our families &amp; the strength of our economy- all riding on getting affordable HC right.\"",
    "id" : 375294463989387265,
    "created_at" : "2013-09-04 16:29:07 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 375295679960072193,
  "created_at" : "2013-09-04 16:33:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 106, 118 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375293410703179776",
  "text" : "\"This law's already done a lot of good...it has lots of opportunities for states to innovate.\" \u2014President @BillClinton on #Obamacare",
  "id" : 375293410703179776,
  "created_at" : "2013-09-04 16:24:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 10, 22 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375288740039512064",
  "text" : "President @BillClinton: Health care spending has seen \"the smallest increase in 50 years\" since #Obamacare became law.",
  "id" : 375288740039512064,
  "created_at" : "2013-09-04 16:06:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 10, 22 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375286664819920896",
  "text" : "President @BillClinton: \"105 million Americans have seen the lifetime limits on their insurance abolished.\" #ThanksObamacare",
  "id" : 375286664819920896,
  "created_at" : "2013-09-04 15:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 109, 121 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375285552586567680",
  "text" : "\"17 million children can no longer be denied coverage or charged higher rates for pre-existing conditions.\" \u2014@BillClinton #ThanksObamacare",
  "id" : 375285552586567680,
  "created_at" : "2013-09-04 15:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 80, 92 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375284773456863233",
  "text" : "\"It is the law\u2014and we've all got an interest in faithfully executing the law.\" \u2014@BillClinton on the importance of implementing #Obamacare",
  "id" : 375284773456863233,
  "created_at" : "2013-09-04 15:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 32, 44 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/bOUcRCDMYA",
      "expanded_url" : "http:\/\/at.wh.gov\/oyuet",
      "display_url" : "at.wh.gov\/oyuet"
    } ]
  },
  "geo" : { },
  "id_str" : "375280810645291008",
  "text" : "Happening now: Former President @BillClinton\u2014aka the Secretary of Explaining Stuff\u2014speaks on #Obamacare \u2014&gt; http:\/\/t.co\/bOUcRCDMYA",
  "id" : 375280810645291008,
  "created_at" : "2013-09-04 15:34:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "Athena Jones",
      "screen_name" : "AthenaCNN",
      "indices" : [ 59, 69 ],
      "id_str" : "57751453",
      "id" : 57751453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375272397269528577",
  "text" : "RT @Lehrich44: Needless to say, you should watch this (via @AthenaCNN) -- \u2018Secretary of Explaining Stuff\u2019 to sell Obamacare --&gt; http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Athena Jones",
        "screen_name" : "AthenaCNN",
        "indices" : [ 44, 54 ],
        "id_str" : "57751453",
        "id" : 57751453
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Yd5hcaX9Wk",
        "expanded_url" : "http:\/\/politicalticker.blogs.cnn.com\/2013\/09\/04\/secretary-of-explaining-stuff-to-sell-obamacare\/",
        "display_url" : "politicalticker.blogs.cnn.com\/2013\/09\/04\/sec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375271326459518976",
    "text" : "Needless to say, you should watch this (via @AthenaCNN) -- \u2018Secretary of Explaining Stuff\u2019 to sell Obamacare --&gt; http:\/\/t.co\/Yd5hcaX9Wk",
    "id" : 375271326459518976,
    "created_at" : "2013-09-04 14:57:11 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 375272397269528577,
  "created_at" : "2013-09-04 15:01:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375270974674837504",
  "text" : "RT @rhodes44: POTUS in Stockholm: \"I didnt set a red line, the world set a red line\" - govts representing 98 percent of world's population \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "375244665219321857",
    "text" : "POTUS in Stockholm: \"I didnt set a red line, the world set a red line\" - govts representing 98 percent of world's population banned CW use",
    "id" : 375244665219321857,
    "created_at" : "2013-09-04 13:11:14 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 375270974674837504,
  "created_at" : "2013-09-04 14:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 40, 52 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/gdrnBOjLFt",
      "expanded_url" : "http:\/\/at.wh.gov\/oym9Z",
      "display_url" : "at.wh.gov\/oym9Z"
    } ]
  },
  "geo" : { },
  "id_str" : "375264850605137920",
  "text" : "Tune in at 11am ET for former President @BillClinton's speech on health care policy and the benefits of #Obamacare \u2014&gt; http:\/\/t.co\/gdrnBOjLFt",
  "id" : 375264850605137920,
  "created_at" : "2013-09-04 14:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375258009015820291",
  "text" : "RT @HealthCareTara: What do CVS, Giant Food and the Baltimore Ravens have in common?  They're all helping uninsured in MD get covered:http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/oE313ZKHsF",
        "expanded_url" : "http:\/\/1.usa.gov\/18oTXY2",
        "display_url" : "1.usa.gov\/18oTXY2"
      } ]
    },
    "geo" : { },
    "id_str" : "375248462498918400",
    "text" : "What do CVS, Giant Food and the Baltimore Ravens have in common?  They're all helping uninsured in MD get covered:http:\/\/t.co\/oE313ZKHsF",
    "id" : 375248462498918400,
    "created_at" : "2013-09-04 13:26:19 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 375258009015820291,
  "created_at" : "2013-09-04 14:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "375247716076376065",
  "text" : "Happening now: President Obama and the Prime Minister of Sweden hold a press conference. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 375247716076376065,
  "created_at" : "2013-09-04 13:23:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/YS5KMXhzXo",
      "expanded_url" : "http:\/\/at.wh.gov\/ox8eU",
      "display_url" : "at.wh.gov\/ox8eU"
    } ]
  },
  "geo" : { },
  "id_str" : "375038226613805057",
  "text" : "Here's where you can get the latest on President Obama's trip to Sweden and the G-20 \u2014&gt; http:\/\/t.co\/YS5KMXhzXo",
  "id" : 375038226613805057,
  "created_at" : "2013-09-03 23:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 42, 54 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/pdkXe85yxe",
      "expanded_url" : "http:\/\/wh.gov\/Clinton-ACA-Speech",
      "display_url" : "wh.gov\/Clinton-ACA-Sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375023530816966656",
  "text" : "Tune in tomorrow at 11am ET for President @BillClinton's speech on health care policy &amp; the benefits of #Obamacare \u2014&gt; http:\/\/t.co\/pdkXe85yxe",
  "id" : 375023530816966656,
  "created_at" : "2013-09-03 22:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/DpYr8Lr5ci",
      "expanded_url" : "http:\/\/at.wh.gov\/owZOK",
      "display_url" : "at.wh.gov\/owZOK"
    } ]
  },
  "geo" : { },
  "id_str" : "375003235406196736",
  "text" : "President Obama met with Congressional leaders this morning on the situation in #Syria. Watch \u2014&gt; http:\/\/t.co\/DpYr8Lr5ci",
  "id" : 375003235406196736,
  "created_at" : "2013-09-03 21:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Lewis",
      "screen_name" : "KLewis44",
      "indices" : [ 3, 12 ],
      "id_str" : "1639207880",
      "id" : 1639207880
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374995195344846848",
  "text" : "RT @KLewis44: FACT: Thanks to #Obamacare, 6.8 million African Americans may be eligible for quality health care coverage. http:\/\/t.co\/c1kH5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KLewis44\/status\/374983683054137345\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/c1kH59Kecy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTQ1rEmCcAAJ0bA.jpg",
        "id_str" : "374983683062525952",
        "id" : 374983683062525952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTQ1rEmCcAAJ0bA.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/c1kH59Kecy"
      } ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 16, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374983683054137345",
    "text" : "FACT: Thanks to #Obamacare, 6.8 million African Americans may be eligible for quality health care coverage. http:\/\/t.co\/c1kH59Kecy",
    "id" : 374983683054137345,
    "created_at" : "2013-09-03 19:54:11 +0000",
    "user" : {
      "name" : "Kevin Lewis",
      "screen_name" : "KLewis44",
      "protected" : false,
      "id_str" : "1639207880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711839771438354432\/NXZNoswc_normal.jpg",
      "id" : 1639207880,
      "verified" : true
    }
  },
  "id" : 374995195344846848,
  "created_at" : "2013-09-03 20:39:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374961861734588416",
  "text" : "RT @vj44: Starting today, DOD extends benefits to legally married same-sex military spouses. RT for fairness &amp; equality for ALL military fa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374957345387728896",
    "text" : "Starting today, DOD extends benefits to legally married same-sex military spouses. RT for fairness &amp; equality for ALL military families!",
    "id" : 374957345387728896,
    "created_at" : "2013-09-03 18:09:32 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 374961861734588416,
  "created_at" : "2013-09-03 18:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/7ATSq3HDTz",
      "expanded_url" : "http:\/\/at.wh.gov\/owsN1",
      "display_url" : "at.wh.gov\/owsN1"
    } ]
  },
  "geo" : { },
  "id_str" : "374947626203901952",
  "text" : "In case you missed it, all legal same-sex couples will now be recognized for federal tax purposes: http:\/\/t.co\/7ATSq3HDTz #MarriageEquality",
  "id" : 374947626203901952,
  "created_at" : "2013-09-03 17:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374932527594479616",
  "text" : "\"What we are envisioning is something limited. It is something proportional. It will degrade Assad\u2019s capabilities\" \u2014President Obama on Syria",
  "id" : 374932527594479616,
  "created_at" : "2013-09-03 16:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374930009338556416",
  "text" : "President Obama on #Syria: \"We will be much more effective\u2014we will be stronger\u2014if we take action together as one nation.\"",
  "id" : 374930009338556416,
  "created_at" : "2013-09-03 16:20:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/6BjIQ3hUMt",
      "expanded_url" : "http:\/\/at.wh.gov\/owhEA",
      "display_url" : "at.wh.gov\/owhEA"
    } ]
  },
  "geo" : { },
  "id_str" : "374927803893813248",
  "text" : "President Obama's statement on #Syria before meeting with members of Congress this morning \u2014&gt; http:\/\/t.co\/6BjIQ3hUMt",
  "id" : 374927803893813248,
  "created_at" : "2013-09-03 16:12:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/gU2OuSg9A7",
      "expanded_url" : "http:\/\/go.usa.gov\/DggF",
      "display_url" : "go.usa.gov\/DggF"
    } ]
  },
  "geo" : { },
  "id_str" : "374903941772750848",
  "text" : "RT @HHSGov: RT &amp; help 18.6 million uninsured women get ready for Oct 1 &amp; the start of open enrollment. http:\/\/t.co\/gU2OuSg9A7 http:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/374901728270749696\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/ciGHqXxsRG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTPrIrOCEAA5X0q.jpg",
        "id_str" : "374901728274944000",
        "id" : 374901728274944000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTPrIrOCEAA5X0q.jpg",
        "sizes" : [ {
          "h" : 473,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ciGHqXxsRG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/gU2OuSg9A7",
        "expanded_url" : "http:\/\/go.usa.gov\/DggF",
        "display_url" : "go.usa.gov\/DggF"
      } ]
    },
    "geo" : { },
    "id_str" : "374901728270749696",
    "text" : "RT &amp; help 18.6 million uninsured women get ready for Oct 1 &amp; the start of open enrollment. http:\/\/t.co\/gU2OuSg9A7 http:\/\/t.co\/ciGHqXxsRG",
    "id" : 374901728270749696,
    "created_at" : "2013-09-03 14:28:32 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 374903941772750848,
  "created_at" : "2013-09-03 14:37:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ras2cjCoQF",
      "expanded_url" : "http:\/\/at.wh.gov\/ou7q2",
      "display_url" : "at.wh.gov\/ou7q2"
    } ]
  },
  "geo" : { },
  "id_str" : "374585052212232192",
  "text" : "\"Nobody who works full-time should have to raise their children in poverty.\" \u2014President Obama: http:\/\/t.co\/ras2cjCoQF #LaborDay",
  "id" : 374585052212232192,
  "created_at" : "2013-09-02 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/OHQ1iw30Vp",
      "expanded_url" : "http:\/\/at.wh.gov\/ou7q2",
      "display_url" : "at.wh.gov\/ou7q2"
    } ]
  },
  "geo" : { },
  "id_str" : "374563937179537409",
  "text" : "\"This is a day that belongs to you\u2014the working men and women of America.\" \u2014President Obama on #LaborDay: http:\/\/t.co\/OHQ1iw30Vp",
  "id" : 374563937179537409,
  "created_at" : "2013-09-02 16:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]