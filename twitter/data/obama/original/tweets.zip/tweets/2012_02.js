Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCampusChallenge",
      "indices" : [ 34, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/J7xFDswI",
      "expanded_url" : "http:\/\/ow.ly\/9ngrZ",
      "display_url" : "ow.ly\/9ngrZ"
    } ]
  },
  "geo" : { },
  "id_str" : "175052900568010752",
  "text" : "Have you voted yet? Check out the #WHCampusChallenge & vote for your favorites: http:\/\/t.co\/J7xFDswI",
  "id" : 175052900568010752,
  "created_at" : "2012-03-01 03:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/175035845626167297\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/qQ5OSmu7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am3aLJnCAAE1Prz.jpg",
      "id_str" : "175035845630361601",
      "id" : 175035845630361601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am3aLJnCAAE1Prz.jpg",
      "sizes" : [ {
        "h" : 795,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qQ5OSmu7"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175035845626167297",
  "text" : "\"As your Commander in Chief, I could not be more proud of you\" -President Obama to Iraq war #veterans: http:\/\/t.co\/qQ5OSmu7",
  "id" : 175035845626167297,
  "created_at" : "2012-03-01 01:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175030408117891072",
  "text" : "\"After nearly 9 yrs of war in Iraq, tonight is an opportunity to express our #gratitude & to say, once more, welcome home\" -President Obama",
  "id" : 175030408117891072,
  "created_at" : "2012-03-01 01:31:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 120, 127 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "175029575686946816",
  "text" : "Happening now: President Obama speaks at a dinner honoring #Iraq war veterans. Watch live: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 175029575686946816,
  "created_at" : "2012-03-01 01:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "175024014853537792",
  "text" : "Happening now: President Obama & The First Lady Honor Armed Forces who served in #Iraq. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 175024014853537792,
  "created_at" : "2012-03-01 01:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 6, 9 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "TheNatlGuard",
      "screen_name" : "TheNatlGuard",
      "indices" : [ 24, 37 ],
      "id_str" : "586631873",
      "id" : 586631873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/kHBUCFKX",
      "expanded_url" : "http:\/\/ow.ly\/9nfFD",
      "display_url" : "ow.ly\/9nfFD"
    } ]
  },
  "geo" : { },
  "id_str" : "175002583633625090",
  "text" : "Today @VP Biden thanked @TheNatlGuard officers from every state for their service #AtTheWH: http:\/\/t.co\/kHBUCFKX",
  "id" : 175002583633625090,
  "created_at" : "2012-02-29 23:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheNatlGuard",
      "screen_name" : "TheNatlGuard",
      "indices" : [ 3, 16 ],
      "id_str" : "586631873",
      "id" : 586631873
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 109, 120 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Photos",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "NationalGuard",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174983914987859968",
  "text" : "RT @TheNatlGuard: #Photos of the 8 #NationalGuard members selected for tonight's event before they go to the @WhiteHouse http:\/\/t.co\/RUL ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 91, 102 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Photos",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "NationalGuard",
        "indices" : [ 17, 31 ]
      }, {
        "text" : "Gratitude",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/RULSPxTo",
        "expanded_url" : "http:\/\/owl.li\/9n79a",
        "display_url" : "owl.li\/9n79a"
      } ]
    },
    "geo" : { },
    "id_str" : "174973428552581122",
    "text" : "#Photos of the 8 #NationalGuard members selected for tonight's event before they go to the @WhiteHouse http:\/\/t.co\/RULSPxTo #Gratitude",
    "id" : 174973428552581122,
    "created_at" : "2012-02-29 21:44:50 +0000",
    "user" : {
      "name" : "National Guard",
      "screen_name" : "USNationalGuard",
      "protected" : false,
      "id_str" : "31310158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/392853927\/NGB-Clr_normal.jpg",
      "id" : 31310158,
      "verified" : true
    }
  },
  "id" : 174983914987859968,
  "created_at" : "2012-02-29 22:26:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 91, 105 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 40, 50 ]
    }, {
      "text" : "troops",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/Zazd8wDZ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/joiningforces\/message",
      "display_url" : "whitehouse.gov\/joiningforces\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174983648733433857",
  "text" : "RT @DeptofDefense: Want to express your #gratitude? Send a mssg to the #troops through the @JoiningForces site: http:\/\/t.co\/Zazd8wDZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 72, 86 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gratitude",
        "indices" : [ 21, 31 ]
      }, {
        "text" : "troops",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Zazd8wDZ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/joiningforces\/message",
        "display_url" : "whitehouse.gov\/joiningforces\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "174966502909419520",
    "text" : "Want to express your #gratitude? Send a mssg to the #troops through the @JoiningForces site: http:\/\/t.co\/Zazd8wDZ",
    "id" : 174966502909419520,
    "created_at" : "2012-02-29 21:17:19 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 174983648733433857,
  "created_at" : "2012-02-29 22:25:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "gratitude",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/a4SdV6Sh",
      "expanded_url" : "http:\/\/ow.ly\/9naR8",
      "display_url" : "ow.ly\/9naR8"
    }, {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "174983352925958144",
  "text" : "Tonight, the President honors #Iraq vets w\/ a #gratitude dinner at the @whitehouse http:\/\/t.co\/a4SdV6Sh Watch @ 8:20ET http:\/\/t.co\/u95y7hhB",
  "id" : 174983352925958144,
  "created_at" : "2012-02-29 22:24:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 12, 23 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/04k5Y5aH",
      "expanded_url" : "http:\/\/ow.ly\/9n8uS",
      "display_url" : "ow.ly\/9n8uS"
    } ]
  },
  "geo" : { },
  "id_str" : "174975974566412288",
  "text" : "FACT CHECK: @pfeiffer44 on an all-of-the-above approach to American #energy: http:\/\/t.co\/04k5Y5aH",
  "id" : 174975974566412288,
  "created_at" : "2012-02-29 21:54:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/174961152374210560\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/7e32d2RH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am2WPblCAAAIivb.jpg",
      "id_str" : "174961152382599168",
      "id" : 174961152382599168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am2WPblCAAAIivb.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1247,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7e32d2RH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174961152374210560",
  "text" : "Photo of the Day: President Obama talks about the American auto industry's comeback @ the United Auto Workers Conf: http:\/\/t.co\/7e32d2RH",
  "id" : 174961152374210560,
  "created_at" : "2012-02-29 20:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 120, 129 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174921607972794368",
  "text" : "RT @JoiningForces: First Lady Michelle Obama to announce travel industry to hire 3,000 military #veterans & spouses via @iVillage: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 101, 110 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/DTEaCNl1",
        "expanded_url" : "http:\/\/ow.ly\/9mPt3",
        "display_url" : "ow.ly\/9mPt3"
      } ]
    },
    "geo" : { },
    "id_str" : "174921346143371266",
    "text" : "First Lady Michelle Obama to announce travel industry to hire 3,000 military #veterans & spouses via @iVillage: http:\/\/t.co\/DTEaCNl1",
    "id" : 174921346143371266,
    "created_at" : "2012-02-29 18:17:53 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 174921607972794368,
  "created_at" : "2012-02-29 18:18:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UAW",
      "screen_name" : "UAW",
      "indices" : [ 74, 78 ],
      "id_str" : "15854702",
      "id" : 15854702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/aVUP9C5j",
      "expanded_url" : "http:\/\/youtu.be\/il6KmXwZO2o",
      "display_url" : "youtu.be\/il6KmXwZO2o"
    } ]
  },
  "geo" : { },
  "id_str" : "174638667393015808",
  "text" : "\"America always wins when the playing field is level\" -President Obama to @UAW Conf. Watch: http:\/\/t.co\/aVUP9C5j",
  "id" : 174638667393015808,
  "created_at" : "2012-02-28 23:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/mIscE5OQ",
      "expanded_url" : "http:\/\/ow.ly\/i\/tZ5M",
      "display_url" : "ow.ly\/i\/tZ5M"
    } ]
  },
  "geo" : { },
  "id_str" : "174591229881888769",
  "text" : "RT @HUDNews: SC2 Twitter Townhall happening now. Send in your questions or responses to questions already answered. http:\/\/t.co\/mIscE5OQ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/mIscE5OQ",
        "expanded_url" : "http:\/\/ow.ly\/i\/tZ5M",
        "display_url" : "ow.ly\/i\/tZ5M"
      } ]
    },
    "geo" : { },
    "id_str" : "174590470188564480",
    "text" : "SC2 Twitter Townhall happening now. Send in your questions or responses to questions already answered. http:\/\/t.co\/mIscE5OQ @AskSOHUD",
    "id" : 174590470188564480,
    "created_at" : "2012-02-28 20:23:06 +0000",
    "user" : {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "protected" : false,
      "id_str" : "19948202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000438958545\/e9038252f910c840e582818a63dd9908_normal.jpeg",
      "id" : 19948202,
      "verified" : true
    }
  },
  "id" : 174591229881888769,
  "created_at" : "2012-02-28 20:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/b6GD533O",
      "expanded_url" : "http:\/\/ow.ly\/9llKE",
      "display_url" : "ow.ly\/9llKE"
    } ]
  },
  "geo" : { },
  "id_str" : "174565981895659520",
  "text" : "President Obama honors unsung heroes at the @whitehouse during Black History Month. Watch: http:\/\/t.co\/b6GD533O",
  "id" : 174565981895659520,
  "created_at" : "2012-02-28 18:45:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/XfipPIBL",
      "expanded_url" : "http:\/\/bit.ly\/AmBYZF",
      "display_url" : "bit.ly\/AmBYZF"
    } ]
  },
  "geo" : { },
  "id_str" : "174506401639575552",
  "text" : "RT @petesouza: New behind-the-scenes photos of potus from January: http:\/\/t.co\/XfipPIBL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/XfipPIBL",
        "expanded_url" : "http:\/\/bit.ly\/AmBYZF",
        "display_url" : "bit.ly\/AmBYZF"
      } ]
    },
    "geo" : { },
    "id_str" : "174496921392648193",
    "text" : "New behind-the-scenes photos of potus from January: http:\/\/t.co\/XfipPIBL",
    "id" : 174496921392648193,
    "created_at" : "2012-02-28 14:11:22 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 174506401639575552,
  "created_at" : "2012-02-28 14:49:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Jagger",
      "screen_name" : "MickJagger",
      "indices" : [ 54, 65 ],
      "id_str" : "234053160",
      "id" : 234053160
    }, {
      "name" : "Jeff Beck",
      "screen_name" : "jeffbeckmusic",
      "indices" : [ 66, 80 ],
      "id_str" : "116589491",
      "id" : 116589491
    }, {
      "name" : "Keb' Mo'",
      "screen_name" : "kebmomusic",
      "indices" : [ 81, 92 ],
      "id_str" : "20190447",
      "id" : 20190447
    }, {
      "name" : "Tedeschi Trucks Band",
      "screen_name" : "DerekAndSusan",
      "indices" : [ 93, 107 ],
      "id_str" : "87754597",
      "id" : 87754597
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/PvGjQRQs",
      "expanded_url" : "http:\/\/youtu.be\/7VohfbM7aOk",
      "display_url" : "youtu.be\/7VohfbM7aOk"
    } ]
  },
  "geo" : { },
  "id_str" : "174299688965636096",
  "text" : "Go behind-the-scenes @ Red, White & Blues #AtTheWH w\/ @mickjagger @jeffbeckmusic @kebmomusic @DerekAndSusan & more: http:\/\/t.co\/PvGjQRQs",
  "id" : 174299688965636096,
  "created_at" : "2012-02-28 01:07:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 65, 73 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAP44",
      "indices" : [ 14, 20 ]
    }, {
      "text" : "regs",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174262856198520832",
  "text" : "RT @OMBPress: #SAP44: Admin strongly opposes HR2117; wld nullify @usedgov #regs that help ensure integrity of fin assistance programs ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 51, 59 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAP44",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "regs",
        "indices" : [ 60, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/ExDiJrKj",
        "expanded_url" : "http:\/\/1.usa.gov\/xSq7Zk",
        "display_url" : "1.usa.gov\/xSq7Zk"
      } ]
    },
    "geo" : { },
    "id_str" : "174257612676808704",
    "text" : "#SAP44: Admin strongly opposes HR2117; wld nullify @usedgov #regs that help ensure integrity of fin assistance programs http:\/\/t.co\/ExDiJrKj",
    "id" : 174257612676808704,
    "created_at" : "2012-02-27 22:20:27 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 174262856198520832,
  "created_at" : "2012-02-27 22:41:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Keb' Mo'",
      "screen_name" : "kebmomusic",
      "indices" : [ 37, 48 ],
      "id_str" : "20190447",
      "id" : 20190447
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 113, 117 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PBSipwh",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/32T4ofJR",
      "expanded_url" : "http:\/\/youtu.be\/NZyt6ogwbcw",
      "display_url" : "youtu.be\/NZyt6ogwbcw"
    } ]
  },
  "geo" : { },
  "id_str" : "174257130784821249",
  "text" : "Go backstage at the @whitehouse with @kebmomusic: http:\/\/t.co\/32T4ofJR Watch #PBSipwh Red, White & Blues show on @PBS tonight @ 9ET",
  "id" : 174257130784821249,
  "created_at" : "2012-02-27 22:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV Issues",
      "screen_name" : "MTVAct",
      "indices" : [ 3, 10 ],
      "id_str" : "3028398526",
      "id" : 3028398526
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "mtvU",
      "screen_name" : "mtvU",
      "indices" : [ 122, 127 ],
      "id_str" : "18333645",
      "id" : 18333645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/eNOgGIiE",
      "expanded_url" : "http:\/\/on.mtv.com\/z1weBs",
      "display_url" : "on.mtv.com\/z1weBs"
    } ]
  },
  "geo" : { },
  "id_str" : "174236282287964160",
  "text" : "RT @MTVact: 15 college change-makers, but only YOUR top 5 head to the @whitehouse. Did you vote yet? http:\/\/t.co\/eNOgGIiE @mtvU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 58, 69 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "mtvU",
        "screen_name" : "mtvU",
        "indices" : [ 110, 115 ],
        "id_str" : "18333645",
        "id" : 18333645
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/eNOgGIiE",
        "expanded_url" : "http:\/\/on.mtv.com\/z1weBs",
        "display_url" : "on.mtv.com\/z1weBs"
      } ]
    },
    "geo" : { },
    "id_str" : "174221693068386305",
    "text" : "15 college change-makers, but only YOUR top 5 head to the @whitehouse. Did you vote yet? http:\/\/t.co\/eNOgGIiE @mtvU",
    "id" : 174221693068386305,
    "created_at" : "2012-02-27 19:57:43 +0000",
    "user" : {
      "name" : "MTV Politics",
      "screen_name" : "MTVPolitics",
      "protected" : false,
      "id_str" : "208697224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712634534743973890\/rv61pNvM_normal.jpg",
      "id" : 208697224,
      "verified" : true
    }
  },
  "id" : 174236282287964160,
  "created_at" : "2012-02-27 20:55:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/W2e4pAjT",
      "expanded_url" : "http:\/\/ow.ly\/9jT7U",
      "display_url" : "ow.ly\/9jT7U"
    } ]
  },
  "geo" : { },
  "id_str" : "174218144502652928",
  "text" : "\"Invest more in #education & invest more in our children & their future\u201D -President Obama to governors http:\/\/t.co\/W2e4pAjT",
  "id" : 174218144502652928,
  "created_at" : "2012-02-27 19:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174184396860043264",
  "text" : "RT @VP: \"Dating violence remains a very real problem in our country-especially on college campuses\"-VP; check out full op-ed http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/JiMdLMX6",
        "expanded_url" : "http:\/\/1.usa.gov\/wbI5Qk",
        "display_url" : "1.usa.gov\/wbI5Qk"
      } ]
    },
    "geo" : { },
    "id_str" : "174171992436641793",
    "text" : "\"Dating violence remains a very real problem in our country-especially on college campuses\"-VP; check out full op-ed http:\/\/t.co\/JiMdLMX6",
    "id" : 174171992436641793,
    "created_at" : "2012-02-27 16:40:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 174184396860043264,
  "created_at" : "2012-02-27 17:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milspouse",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/j5nwaFk5",
      "expanded_url" : "http:\/\/ow.ly\/9jD3N",
      "display_url" : "ow.ly\/9jD3N"
    } ]
  },
  "geo" : { },
  "id_str" : "174178171766317056",
  "text" : "RT @JoiningForces: First Lady & Dr. Biden urge action from state governors on #milspouse hiring: http:\/\/t.co\/j5nwaFk5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "milspouse",
        "indices" : [ 59, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/j5nwaFk5",
        "expanded_url" : "http:\/\/ow.ly\/9jD3N",
        "display_url" : "ow.ly\/9jD3N"
      } ]
    },
    "geo" : { },
    "id_str" : "174178089985769472",
    "text" : "First Lady & Dr. Biden urge action from state governors on #milspouse hiring: http:\/\/t.co\/j5nwaFk5",
    "id" : 174178089985769472,
    "created_at" : "2012-02-27 17:04:27 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 174178171766317056,
  "created_at" : "2012-02-27 17:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecDonovan",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "AskSOHUD",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/X0MOSUuK",
      "expanded_url" : "http:\/\/ow.ly\/9fqsh",
      "display_url" : "ow.ly\/9fqsh"
    } ]
  },
  "geo" : { },
  "id_str" : "174169713713221632",
  "text" : "RT @HUDNews: Join #SecDonovan tmrw @ 3 EST for a Twitter town hall to discuss the SC2 Fellows Program http:\/\/t.co\/X0MOSUuK #AskSOHUD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecDonovan",
        "indices" : [ 5, 16 ]
      }, {
        "text" : "AskSOHUD",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/X0MOSUuK",
        "expanded_url" : "http:\/\/ow.ly\/9fqsh",
        "display_url" : "ow.ly\/9fqsh"
      } ]
    },
    "geo" : { },
    "id_str" : "174162422611976193",
    "text" : "Join #SecDonovan tmrw @ 3 EST for a Twitter town hall to discuss the SC2 Fellows Program http:\/\/t.co\/X0MOSUuK #AskSOHUD",
    "id" : 174162422611976193,
    "created_at" : "2012-02-27 16:02:11 +0000",
    "user" : {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "protected" : false,
      "id_str" : "19948202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000438958545\/e9038252f910c840e582818a63dd9908_normal.jpeg",
      "id" : 19948202,
      "verified" : true
    }
  },
  "id" : 174169713713221632,
  "created_at" : "2012-02-27 16:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/OLd04yPK",
      "expanded_url" : "http:\/\/bit.ly\/wsTtWI",
      "display_url" : "bit.ly\/wsTtWI"
    } ]
  },
  "geo" : { },
  "id_str" : "174167540279427074",
  "text" : "RT @jesseclee44: GOP rhetoric shifts from \"Obama blocking all domestic energy\" to \"Yes there's an energy boom, BUT...\" http:\/\/t.co\/OLd04yPK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/OLd04yPK",
        "expanded_url" : "http:\/\/bit.ly\/wsTtWI",
        "display_url" : "bit.ly\/wsTtWI"
      } ]
    },
    "geo" : { },
    "id_str" : "174163942363508736",
    "text" : "GOP rhetoric shifts from \"Obama blocking all domestic energy\" to \"Yes there's an energy boom, BUT...\" http:\/\/t.co\/OLd04yPK",
    "id" : 174163942363508736,
    "created_at" : "2012-02-27 16:08:14 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 174167540279427074,
  "created_at" : "2012-02-27 16:22:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Jagger",
      "screen_name" : "MickJagger",
      "indices" : [ 3, 14 ],
      "id_str" : "234053160",
      "id" : 234053160
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Buddy Guy",
      "screen_name" : "TheRealBuddyGuy",
      "indices" : [ 50, 66 ],
      "id_str" : "34955691",
      "id" : 34955691
    }, {
      "name" : "Jeff Beck",
      "screen_name" : "jeffbeckmusic",
      "indices" : [ 67, 81 ],
      "id_str" : "116589491",
      "id" : 116589491
    }, {
      "name" : "Tedeschi Trucks Band",
      "screen_name" : "DerekAndSusan",
      "indices" : [ 82, 96 ],
      "id_str" : "87754597",
      "id" : 87754597
    }, {
      "name" : "Booker T. Jones",
      "screen_name" : "BookerTJones",
      "indices" : [ 97, 110 ],
      "id_str" : "52483243",
      "id" : 52483243
    }, {
      "name" : "Keb' Mo'",
      "screen_name" : "kebmomusic",
      "indices" : [ 111, 122 ],
      "id_str" : "20190447",
      "id" : 20190447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174163783382614018",
  "text" : "RT @MickJagger: Catch me playing @whitehouse with @TheRealBuddyGuy @jeffbeckmusic @DerekAndSusan @BookerTJones @kebmomusic on PBS at 9pm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Buddy Guy",
        "screen_name" : "TheRealBuddyGuy",
        "indices" : [ 34, 50 ],
        "id_str" : "34955691",
        "id" : 34955691
      }, {
        "name" : "Jeff Beck",
        "screen_name" : "jeffbeckmusic",
        "indices" : [ 51, 65 ],
        "id_str" : "116589491",
        "id" : 116589491
      }, {
        "name" : "Tedeschi Trucks Band",
        "screen_name" : "DerekAndSusan",
        "indices" : [ 66, 80 ],
        "id_str" : "87754597",
        "id" : 87754597
      }, {
        "name" : "Booker T. Jones",
        "screen_name" : "BookerTJones",
        "indices" : [ 81, 94 ],
        "id_str" : "52483243",
        "id" : 52483243
      }, {
        "name" : "Keb' Mo'",
        "screen_name" : "kebmomusic",
        "indices" : [ 95, 106 ],
        "id_str" : "20190447",
        "id" : 20190447
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PBSipwh",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174130777838206977",
    "text" : "Catch me playing @whitehouse with @TheRealBuddyGuy @jeffbeckmusic @DerekAndSusan @BookerTJones @kebmomusic on PBS at 9pm EST #PBSipwh",
    "id" : 174130777838206977,
    "created_at" : "2012-02-27 13:56:27 +0000",
    "user" : {
      "name" : "Mick Jagger",
      "screen_name" : "MickJagger",
      "protected" : false,
      "id_str" : "234053160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784555827860504577\/R_spEEyw_normal.jpg",
      "id" : 234053160,
      "verified" : true
    }
  },
  "id" : 174163783382614018,
  "created_at" : "2012-02-27 16:07:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 107, 118 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ZNipDsB7",
      "expanded_url" : "http:\/\/youtu.be\/MgJ5QGkP2nw",
      "display_url" : "youtu.be\/MgJ5QGkP2nw"
    } ]
  },
  "geo" : { },
  "id_str" : "174148377204891648",
  "text" : "Congrats to Oscar winner Meryl Streep. Go behind-the-scenes w\/ her @ the 2011 Kennedy Center Honors at the @whitehouse http:\/\/t.co\/ZNipDsB7",
  "id" : 174148377204891648,
  "created_at" : "2012-02-27 15:06:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/174138704305197056\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/zl1sLllJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmqqOpxCEAAgV_6.jpg",
      "id_str" : "174138704313585664",
      "id" : 174138704313585664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmqqOpxCEAAgV_6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/zl1sLllJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/hGfiSEwp",
      "expanded_url" : "http:\/\/wh.gov\/86W",
      "display_url" : "wh.gov\/86W"
    } ]
  },
  "geo" : { },
  "id_str" : "174138704305197056",
  "text" : "By the numbers: $4 billion: http:\/\/t.co\/hGfiSEwp Oil companies receive $4B every year in taxpayer-funded subsidies: http:\/\/t.co\/zl1sLllJ",
  "id" : 174138704305197056,
  "created_at" : "2012-02-27 14:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Va6WRNPC",
      "expanded_url" : "http:\/\/ow.ly\/9hNsZ",
      "display_url" : "ow.ly\/9hNsZ"
    } ]
  },
  "geo" : { },
  "id_str" : "173417835534618625",
  "text" : "\"4 billion of your tax dollars subsidize the oil industry every year...It\u2019s outrageous & it has to stop\" -Pres Obama: http:\/\/t.co\/Va6WRNPC",
  "id" : 173417835534618625,
  "created_at" : "2012-02-25 14:43:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tedeschi Trucks Band",
      "screen_name" : "DerekAndSusan",
      "indices" : [ 3, 17 ],
      "id_str" : "87754597",
      "id" : 87754597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/hUNV22pM",
      "expanded_url" : "http:\/\/youtu.be\/d5r2s4vr3kM",
      "display_url" : "youtu.be\/d5r2s4vr3kM"
    } ]
  },
  "geo" : { },
  "id_str" : "173186898943156224",
  "text" : "RT @DerekAndSusan: Watch Derek and Susan perform an acoustic \"Rollin and Tumblin\" backstage at the White House:  http:\/\/t.co\/hUNV22pM @P ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PBS",
        "screen_name" : "PBS",
        "indices" : [ 115, 119 ],
        "id_str" : "12133382",
        "id" : 12133382
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 120, 131 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/hUNV22pM",
        "expanded_url" : "http:\/\/youtu.be\/d5r2s4vr3kM",
        "display_url" : "youtu.be\/d5r2s4vr3kM"
      } ]
    },
    "geo" : { },
    "id_str" : "173164197142728704",
    "text" : "Watch Derek and Susan perform an acoustic \"Rollin and Tumblin\" backstage at the White House:  http:\/\/t.co\/hUNV22pM @PBS @WhiteHouse",
    "id" : 173164197142728704,
    "created_at" : "2012-02-24 21:55:36 +0000",
    "user" : {
      "name" : "Tedeschi Trucks Band",
      "screen_name" : "DerekAndSusan",
      "protected" : false,
      "id_str" : "87754597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666702632090738688\/QMTrSbN8_normal.jpg",
      "id" : 87754597,
      "verified" : true
    }
  },
  "id" : 173186898943156224,
  "created_at" : "2012-02-24 23:25:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCampusChallenge",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/4KOMbUrL",
      "expanded_url" : "http:\/\/ow.ly\/9hgdw",
      "display_url" : "ow.ly\/9hgdw"
    } ]
  },
  "geo" : { },
  "id_str" : "173151052605038593",
  "text" : "Announcing the #WHCampusChallenge finalists! Vote for your favorites & spread the word: http:\/\/t.co\/4KOMbUrL",
  "id" : 173151052605038593,
  "created_at" : "2012-02-24 21:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 9, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173124620889755648",
  "text" : "Obama in #SOTU: \"We should support...every risk-taker & entrepreneur who aspires to become the next Steve Jobs\" Happy Birthday Steve Jobs",
  "id" : 173124620889755648,
  "created_at" : "2012-02-24 19:18:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 34, 45 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/uQ02muHF",
      "expanded_url" : "http:\/\/youtu.be\/C7i0VUNIWwI",
      "display_url" : "youtu.be\/C7i0VUNIWwI"
    } ]
  },
  "geo" : { },
  "id_str" : "173051483368075265",
  "text" : "\"Hi. My name\u2019s Barack Obama & I\u2019m @jearnest44's understudy\" -The President in the 100th episode of West Wing Week: http:\/\/t.co\/uQ02muHF",
  "id" : 173051483368075265,
  "created_at" : "2012-02-24 14:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/172818846019895296\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/RjRFCagA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmX50yfCQAEQJBb.jpg",
      "id_str" : "172818846024089601",
      "id" : 172818846024089601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmX50yfCQAEQJBb.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/RjRFCagA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/7eZ34WF9",
      "expanded_url" : "http:\/\/wh.gov\/8fK",
      "display_url" : "wh.gov\/8fK"
    } ]
  },
  "geo" : { },
  "id_str" : "172818846019895296",
  "text" : "Obama Admin calls for a consumer Privacy Bill of Rights for the digital age: http:\/\/t.co\/7eZ34WF9 Check it out: http:\/\/t.co\/RjRFCagA",
  "id" : 172818846019895296,
  "created_at" : "2012-02-23 23:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172810876074733568",
  "text" : "RT @PressSec: Fact: POTUS' historic fuel efficiency stndrds, done w\/o Congress, will save more oil than would flow thru Keystone pipelin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172797997632061441",
    "text" : "Fact: POTUS' historic fuel efficiency stndrds, done w\/o Congress, will save more oil than would flow thru Keystone pipeline in 45 years.",
    "id" : 172797997632061441,
    "created_at" : "2012-02-23 21:40:27 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 172810876074733568,
  "created_at" : "2012-02-23 22:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Navroop Mitter",
      "screen_name" : "NavroopMitter",
      "indices" : [ 3, 17 ],
      "id_str" : "350878989",
      "id" : 350878989
    }, {
      "name" : "ABC News Politics",
      "screen_name" : "ABCPolitics",
      "indices" : [ 22, 34 ],
      "id_str" : "16815644",
      "id" : 16815644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172792979923283969",
  "text" : "RT @navroopmitter: RT @abcpolitics: The Man in the Pink Turban: Navroop Mitter Stood Out Behind President Obama at White House Event htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News Politics",
        "screen_name" : "ABCPolitics",
        "indices" : [ 3, 15 ],
        "id_str" : "16815644",
        "id" : 16815644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/l54zNXSj",
        "expanded_url" : "http:\/\/abcn.ws\/zRBqL2",
        "display_url" : "abcn.ws\/zRBqL2"
      } ]
    },
    "geo" : { },
    "id_str" : "172779040795660289",
    "text" : "RT @abcpolitics: The Man in the Pink Turban: Navroop Mitter Stood Out Behind President Obama at White House Event http:\/\/t.co\/l54zNXSj",
    "id" : 172779040795660289,
    "created_at" : "2012-02-23 20:25:08 +0000",
    "user" : {
      "name" : "Navroop Mitter",
      "screen_name" : "NavroopMitter",
      "protected" : false,
      "id_str" : "350878989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687863161819631616\/Ffjp3Ap2_normal.jpg",
      "id" : 350878989,
      "verified" : false
    }
  },
  "id" : 172792979923283969,
  "created_at" : "2012-02-23 21:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/AMVWMGUT",
      "expanded_url" : "http:\/\/abcn.ws\/z9jugD",
      "display_url" : "abcn.ws\/z9jugD"
    } ]
  },
  "geo" : { },
  "id_str" : "172791139391377409",
  "text" : "RT @macon44: The Man in the Pink Turban http:\/\/t.co\/AMVWMGUT #40dollars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 48, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/AMVWMGUT",
        "expanded_url" : "http:\/\/abcn.ws\/z9jugD",
        "display_url" : "abcn.ws\/z9jugD"
      } ]
    },
    "geo" : { },
    "id_str" : "172789156781629440",
    "text" : "The Man in the Pink Turban http:\/\/t.co\/AMVWMGUT #40dollars",
    "id" : 172789156781629440,
    "created_at" : "2012-02-23 21:05:19 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 172791139391377409,
  "created_at" : "2012-02-23 21:13:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172766986256912384",
  "text" : "RT @WHLive: Obama: Anyone who tells you we can drill our way out of this problem doesn\u2019t know what they\u2019re talking about or isn\u2019t tellin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172766944758472704",
    "text" : "Obama: Anyone who tells you we can drill our way out of this problem doesn\u2019t know what they\u2019re talking about or isn\u2019t telling you the truth",
    "id" : 172766944758472704,
    "created_at" : "2012-02-23 19:37:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 172766986256912384,
  "created_at" : "2012-02-23 19:37:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172764269572653056",
  "text" : "Happening now: President Obama speaks on American #energy & an America built to last in Miami. Watch: http:\/\/t.co\/QDIpMRKE",
  "id" : 172764269572653056,
  "created_at" : "2012-02-23 19:26:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "University of Miami",
      "screen_name" : "univmiami",
      "indices" : [ 59, 69 ],
      "id_str" : "15585350",
      "id" : 15585350
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 107, 114 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172756683905433600",
  "text" : "Live @ 2:30ET: President Obama talks about American energy @univmiami. Watch: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 172756683905433600,
  "created_at" : "2012-02-23 18:56:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George K. Heartwell",
      "screen_name" : "MayorHeartwell",
      "indices" : [ 3, 18 ],
      "id_str" : "342863158",
      "id" : 342863158
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 123, 134 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/pgOPLHMw",
      "expanded_url" : "http:\/\/1.usa.gov\/xGy2q9",
      "display_url" : "1.usa.gov\/xGy2q9"
    } ]
  },
  "geo" : { },
  "id_str" : "172737851140747264",
  "text" : "RT @MayorHeartwell: Mayor Heartwell: Why the President\u2019s Budget is Good for Cities | The White House: http:\/\/t.co\/pgOPLHMw @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/pgOPLHMw",
        "expanded_url" : "http:\/\/1.usa.gov\/xGy2q9",
        "display_url" : "1.usa.gov\/xGy2q9"
      } ]
    },
    "geo" : { },
    "id_str" : "172403474347200512",
    "text" : "Mayor Heartwell: Why the President\u2019s Budget is Good for Cities | The White House: http:\/\/t.co\/pgOPLHMw @whitehouse",
    "id" : 172403474347200512,
    "created_at" : "2012-02-22 19:32:46 +0000",
    "user" : {
      "name" : "George K. Heartwell",
      "screen_name" : "MayorHeartwell",
      "protected" : false,
      "id_str" : "342863158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1462345100\/48977_1009339266_5813_n_normal.jpg",
      "id" : 342863158,
      "verified" : false
    }
  },
  "id" : 172737851140747264,
  "created_at" : "2012-02-23 17:41:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172721933006274560",
  "text" : "RT @HHSGov: More Americans who were previously denied coverage due to a pre-existing condition can now get the care they need http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/NJpouU92",
        "expanded_url" : "http:\/\/1.usa.gov\/Aj8AHH",
        "display_url" : "1.usa.gov\/Aj8AHH"
      } ]
    },
    "geo" : { },
    "id_str" : "172721245018783744",
    "text" : "More Americans who were previously denied coverage due to a pre-existing condition can now get the care they need http:\/\/t.co\/NJpouU92",
    "id" : 172721245018783744,
    "created_at" : "2012-02-23 16:35:28 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 172721933006274560,
  "created_at" : "2012-02-23 16:38:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 8, 22 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCtour",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172712490877198336",
  "text" : "Dr. B & @HildaSolisDOL are highlighting community college & industry partnerships. Tell us about partnerships in your community w\/ #CCtour",
  "id" : 172712490877198336,
  "created_at" : "2012-02-23 16:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 22, 36 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    }, {
      "name" : "BCTC",
      "screen_name" : "BluegrassCTC",
      "indices" : [ 53, 66 ],
      "id_str" : "63217188",
      "id" : 63217188
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/172683914652041216\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/MBLkfTBL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmV_Gv_CQAACHvN.jpg",
      "id_str" : "172683914660429824",
      "id" : 172683914660429824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmV_Gv_CQAACHvN.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MBLkfTBL"
    } ],
    "hashtags" : [ {
      "text" : "CCTour",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172708715747749888",
  "text" : "RT @VP: PHOTO: Dr B & @HildaSolisDOL have arrived at @BluegrassCTC for the first stop on Day 2 of the #CCTour http:\/\/t.co\/MBLkfTBL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Immediate Capital",
        "screen_name" : "HildaSolisDOL",
        "indices" : [ 14, 28 ],
        "id_str" : "2187968017",
        "id" : 2187968017
      }, {
        "name" : "BCTC",
        "screen_name" : "BluegrassCTC",
        "indices" : [ 45, 58 ],
        "id_str" : "63217188",
        "id" : 63217188
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/172683914652041216\/photo\/1",
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/MBLkfTBL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AmV_Gv_CQAACHvN.jpg",
        "id_str" : "172683914660429824",
        "id" : 172683914660429824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmV_Gv_CQAACHvN.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MBLkfTBL"
      } ],
      "hashtags" : [ {
        "text" : "CCTour",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172683914652041216",
    "text" : "PHOTO: Dr B & @HildaSolisDOL have arrived at @BluegrassCTC for the first stop on Day 2 of the #CCTour http:\/\/t.co\/MBLkfTBL",
    "id" : 172683914652041216,
    "created_at" : "2012-02-23 14:07:09 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 172708715747749888,
  "created_at" : "2012-02-23 15:45:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/KF5KFJtP",
      "expanded_url" : "http:\/\/ow.ly\/9fd29",
      "display_url" : "ow.ly\/9fd29"
    } ]
  },
  "geo" : { },
  "id_str" : "172702029620318208",
  "text" : "Today, Obama Administration unveils a blueprint for a \u201CPrivacy Bill of Rights\u201D to protect consumers online: http:\/\/t.co\/KF5KFJtP",
  "id" : 172702029620318208,
  "created_at" : "2012-02-23 15:19:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/I1Ja8DS7",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/2UfuO6Hv",
      "expanded_url" : "http:\/\/wh.gov\/8y5",
      "display_url" : "wh.gov\/8y5"
    } ]
  },
  "geo" : { },
  "id_str" : "172484517112721408",
  "text" : "Pres Obama said if the payroll tax cut bill isn't on http:\/\/t.co\/I1Ja8DS7, it hasn't happened. Here it is: http:\/\/t.co\/2UfuO6Hv #40dollars",
  "id" : 172484517112721408,
  "created_at" : "2012-02-23 00:54:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smithsonian",
      "screen_name" : "smithsonian",
      "indices" : [ 11, 23 ],
      "id_str" : "14199378",
      "id" : 14199378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "groundbreaking2012",
      "indices" : [ 78, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/S2CAJy19",
      "expanded_url" : "http:\/\/youtu.be\/D5QBN8bsmOk",
      "display_url" : "youtu.be\/D5QBN8bsmOk"
    } ]
  },
  "geo" : { },
  "id_str" : "172475736609923072",
  "text" : "Inside the @Smithsonian National Museum of African American History & Culture #groundbreaking2012: http:\/\/t.co\/S2CAJy19",
  "id" : 172475736609923072,
  "created_at" : "2012-02-23 00:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172452386080698368",
  "text" : "RT @PressSec: POTUS' business tax reform plan \"simplifies the code, eliminates loopholes & subsidies, & promotes job creation.\" http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/lBQ1kKzU",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/02\/22\/statement-president",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172450021629902848",
    "text" : "POTUS' business tax reform plan \"simplifies the code, eliminates loopholes & subsidies, & promotes job creation.\" http:\/\/t.co\/lBQ1kKzU",
    "id" : 172450021629902848,
    "created_at" : "2012-02-22 22:37:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 172452386080698368,
  "created_at" : "2012-02-22 22:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 16, 30 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    }, {
      "name" : "Sinclair College",
      "screen_name" : "SinclairCC",
      "indices" : [ 105, 116 ],
      "id_str" : "27928544",
      "id" : 27928544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCTour",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172415276153962497",
  "text" : "RT @VP: Dr. B & @HildaSolisDOL tour DG Medical in Centerville to learn more about their partnership with @SinclairCC #CCTour http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Immediate Capital",
        "screen_name" : "HildaSolisDOL",
        "indices" : [ 8, 22 ],
        "id_str" : "2187968017",
        "id" : 2187968017
      }, {
        "name" : "Sinclair College",
        "screen_name" : "SinclairCC",
        "indices" : [ 97, 108 ],
        "id_str" : "27928544",
        "id" : 27928544
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/172414465185296384\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/7neVy8lQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AmSKCugCMAAxdaK.jpg",
        "id_str" : "172414465193684992",
        "id" : 172414465193684992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmSKCugCMAAxdaK.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/7neVy8lQ"
      } ],
      "hashtags" : [ {
        "text" : "CCTour",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172414465185296384",
    "text" : "Dr. B & @HildaSolisDOL tour DG Medical in Centerville to learn more about their partnership with @SinclairCC #CCTour http:\/\/t.co\/7neVy8lQ",
    "id" : 172414465185296384,
    "created_at" : "2012-02-22 20:16:28 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 172415276153962497,
  "created_at" : "2012-02-22 20:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 28, 40 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "BusinessUSA",
      "screen_name" : "BizUSAgov",
      "indices" : [ 43, 53 ],
      "id_str" : "481519707",
      "id" : 481519707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biz",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/NQuBFa7D",
      "expanded_url" : "http:\/\/wh.gov\/8EY",
      "display_url" : "wh.gov\/8EY"
    } ]
  },
  "geo" : { },
  "id_str" : "172397325430423553",
  "text" : "Calling all app developers: @CommerceGov & @BizUSAgov launch $10,000 app challenge to connect #biz with government: http:\/\/t.co\/NQuBFa7D",
  "id" : 172397325430423553,
  "created_at" : "2012-02-22 19:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Jennifer Bendery",
      "screen_name" : "jbendery",
      "indices" : [ 51, 60 ],
      "id_str" : "15837659",
      "id" : 15837659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172383594705203201",
  "text" : "RT @jesseclee44: Best presents are always PDFs. RT @jbendery: Like Xmas all over again! Obama framework for corporate tax reform is OUT  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Bendery",
        "screen_name" : "jbendery",
        "indices" : [ 34, 43 ],
        "id_str" : "15837659",
        "id" : 15837659
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/als6iLjq",
        "expanded_url" : "http:\/\/1.usa.gov\/z1JNVr",
        "display_url" : "1.usa.gov\/z1JNVr"
      } ]
    },
    "geo" : { },
    "id_str" : "172380779022790656",
    "text" : "Best presents are always PDFs. RT @jbendery: Like Xmas all over again! Obama framework for corporate tax reform is OUT http:\/\/t.co\/als6iLjq",
    "id" : 172380779022790656,
    "created_at" : "2012-02-22 18:02:35 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 172383594705203201,
  "created_at" : "2012-02-22 18:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/FUJZpZHm",
      "expanded_url" : "http:\/\/www.consumerfinance.gov\/live-from-new-york-city\/",
      "display_url" : "consumerfinance.gov\/live-from-new-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172360568487936000",
  "text" : "RT @CFPB: Director Cordray is speaking LIVE in NYC about our new checking account initiatives. Watch it here now: http:\/\/t.co\/FUJZpZHm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/FUJZpZHm",
        "expanded_url" : "http:\/\/www.consumerfinance.gov\/live-from-new-york-city\/",
        "display_url" : "consumerfinance.gov\/live-from-new-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172358683005693953",
    "text" : "Director Cordray is speaking LIVE in NYC about our new checking account initiatives. Watch it here now: http:\/\/t.co\/FUJZpZHm",
    "id" : 172358683005693953,
    "created_at" : "2012-02-22 16:34:46 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 172360568487936000,
  "created_at" : "2012-02-22 16:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smithsonian",
      "screen_name" : "smithsonian",
      "indices" : [ 40, 52 ],
      "id_str" : "14199378",
      "id" : 14199378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "groundbreaking2012",
      "indices" : [ 93, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/l63vjbJG",
      "expanded_url" : "http:\/\/ow.ly\/9dHS6",
      "display_url" : "ow.ly\/9dHS6"
    } ]
  },
  "geo" : { },
  "id_str" : "172355354057912320",
  "text" : "Happening now: Pres Obama speaks at the @Smithsonian Natl Museum of African American History #groundbreaking2012: http:\/\/t.co\/l63vjbJG",
  "id" : 172355354057912320,
  "created_at" : "2012-02-22 16:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smithsonian",
      "screen_name" : "smithsonian",
      "indices" : [ 80, 92 ],
      "id_str" : "14199378",
      "id" : 14199378
    }, {
      "name" : "Smithsonian NMAAHC",
      "screen_name" : "NMAAHC",
      "indices" : [ 93, 100 ],
      "id_str" : "36972997",
      "id" : 36972997
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "groundbreaking2012",
      "indices" : [ 43, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/t8Gegqei",
      "expanded_url" : "http:\/\/ow.ly\/9dDhE",
      "display_url" : "ow.ly\/9dDhE"
    } ]
  },
  "geo" : { },
  "id_str" : "172326220485238786",
  "text" : "Live @ 10ET: President Obama speaks at the #groundbreaking2012 ceremony for the @Smithsonian @NMAAHC. Watch: http:\/\/t.co\/t8Gegqei",
  "id" : 172326220485238786,
  "created_at" : "2012-02-22 14:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Siegel",
      "screen_name" : "TommySiegel",
      "indices" : [ 3, 15 ],
      "id_str" : "449546974",
      "id" : 449546974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172140766955700224",
  "text" : "RT @TommySiegel: There's like a billion famous people playing sick blues solos at the White House right now.  I can get behind this. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/HqwCsBqz",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172140264033488896",
    "text" : "There's like a billion famous people playing sick blues solos at the White House right now.  I can get behind this. http:\/\/t.co\/HqwCsBqz",
    "id" : 172140264033488896,
    "created_at" : "2012-02-22 02:06:51 +0000",
    "user" : {
      "name" : "Tommy Siegel",
      "screen_name" : "TommySiegel",
      "protected" : false,
      "id_str" : "449546974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566857092360077312\/IU9XZjfG_normal.jpeg",
      "id" : 449546974,
      "verified" : true
    }
  },
  "id" : 172140766955700224,
  "created_at" : "2012-02-22 02:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cawdron",
      "screen_name" : "PeterCawdron",
      "indices" : [ 3, 16 ],
      "id_str" : "379463959",
      "id" : 379463959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172140348544520192",
  "text" : "RT @PeterCawdron: Jeff Beck is on stage at the Whitehouse, Jagger's jumping up on stage, Obama is in the front row... here comes BB King ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/xZQmV7qM",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172140105149067264",
    "text" : "Jeff Beck is on stage at the Whitehouse, Jagger's jumping up on stage, Obama is in the front row... here comes BB King!\nhttp:\/\/t.co\/xZQmV7qM",
    "id" : 172140105149067264,
    "created_at" : "2012-02-22 02:06:13 +0000",
    "user" : {
      "name" : "Peter Cawdron",
      "screen_name" : "PeterCawdron",
      "protected" : false,
      "id_str" : "379463959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1614490618\/pcawdron_normal.jpg",
      "id" : 379463959,
      "verified" : false
    }
  },
  "id" : 172140348544520192,
  "created_at" : "2012-02-22 02:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "digiruben",
      "screen_name" : "digiruben",
      "indices" : [ 3, 13 ],
      "id_str" : "62003514",
      "id" : 62003514
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/nEhme9M5",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172137685186641920",
  "text" : "RT @digiruben: @whitehouse Blues All Stars about to kill it on http:\/\/t.co\/nEhme9M5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/nEhme9M5",
        "expanded_url" : "http:\/\/whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172137539929505792",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Blues All Stars about to kill it on http:\/\/t.co\/nEhme9M5",
    "id" : 172137539929505792,
    "created_at" : "2012-02-22 01:56:02 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "digiruben",
      "screen_name" : "digiruben",
      "protected" : false,
      "id_str" : "62003514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792501897072668672\/619aMIiH_normal.jpg",
      "id" : 62003514,
      "verified" : false
    }
  },
  "id" : 172137685186641920,
  "created_at" : "2012-02-22 01:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Williams",
      "screen_name" : "IAM4DUKE",
      "indices" : [ 3, 12 ],
      "id_str" : "26911815",
      "id" : 26911815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172136495937880066",
  "text" : "RT @IAM4DUKE: Derek Trucks\/Susan Tedeschi w\/ Warren Haynes blistering Etta James \"I'd Rather Go Blind\" live from the White House. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/rIulFNf9",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172135975529627648",
    "text" : "Derek Trucks\/Susan Tedeschi w\/ Warren Haynes blistering Etta James \"I'd Rather Go Blind\" live from the White House. http:\/\/t.co\/rIulFNf9",
    "id" : 172135975529627648,
    "created_at" : "2012-02-22 01:49:49 +0000",
    "user" : {
      "name" : "Mary Williams",
      "screen_name" : "IAM4DUKE",
      "protected" : false,
      "id_str" : "26911815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792159755859001344\/F3my39Q5_normal.jpg",
      "id" : 26911815,
      "verified" : false
    }
  },
  "id" : 172136495937880066,
  "created_at" : "2012-02-22 01:51:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Probst",
      "screen_name" : "Probstisms",
      "indices" : [ 3, 14 ],
      "id_str" : "13096452",
      "id" : 13096452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/h8GcLKR7",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172135269867335680",
  "text" : "RT @Probstisms: Hurry, get to http:\/\/t.co\/h8GcLKR7!  Derek Trucks, Warren Hayes, Susan Tedeschi!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http:\/\/t.co\/h8GcLKR7",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172134803322318848",
    "text" : "Hurry, get to http:\/\/t.co\/h8GcLKR7!  Derek Trucks, Warren Hayes, Susan Tedeschi!!!",
    "id" : 172134803322318848,
    "created_at" : "2012-02-22 01:45:09 +0000",
    "user" : {
      "name" : "Tim Probst",
      "screen_name" : "Probstisms",
      "protected" : false,
      "id_str" : "13096452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536596038329458688\/SsHTzO0j_normal.jpeg",
      "id" : 13096452,
      "verified" : false
    }
  },
  "id" : 172135269867335680,
  "created_at" : "2012-02-22 01:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/hhi4kUMJ",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172134247073710080",
  "text" : "RT @kaipluskim: Live at the Whitehouse - KEB MO !!  http:\/\/t.co\/hhi4kUMJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/hhi4kUMJ",
        "expanded_url" : "http:\/\/whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172133398830260224",
    "text" : "Live at the Whitehouse - KEB MO !!  http:\/\/t.co\/hhi4kUMJ",
    "id" : 172133398830260224,
    "created_at" : "2012-02-22 01:39:35 +0000",
    "user" : {
      "name" : "Champagne Fondu",
      "screen_name" : "TheSwissK",
      "protected" : false,
      "id_str" : "66952587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765862721321574400\/e-pZ7aHs_normal.jpg",
      "id" : 66952587,
      "verified" : false
    }
  },
  "id" : 172134247073710080,
  "created_at" : "2012-02-22 01:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Anderson-Lehman",
      "screen_name" : "sanderleh",
      "indices" : [ 3, 13 ],
      "id_str" : "52480207",
      "id" : 52480207
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172126977371811841",
  "text" : "RT @sanderleh: The President's face throughout the performance is priceless. Great music has that effect on people @whitehouse http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 100, 111 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/JcbQut5i",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
        "display_url" : "WhiteHouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172126565117861888",
    "text" : "The President's face throughout the performance is priceless. Great music has that effect on people @whitehouse http:\/\/t.co\/JcbQut5i",
    "id" : 172126565117861888,
    "created_at" : "2012-02-22 01:12:25 +0000",
    "user" : {
      "name" : "Sam Anderson-Lehman",
      "screen_name" : "sanderleh",
      "protected" : false,
      "id_str" : "52480207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3550488979\/3f1b04d9866868de3989408b561685d0_normal.jpeg",
      "id" : 52480207,
      "verified" : false
    }
  },
  "id" : 172126977371811841,
  "created_at" : "2012-02-22 01:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I'mSTILLWithHer",
      "screen_name" : "stefsstuff",
      "indices" : [ 3, 14 ],
      "id_str" : "16209626",
      "id" : 16209626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JeffBeck",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "MickJagger",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/559qJFXs",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172126142155857921",
  "text" : "RT @stefsstuff: Wow #JeffBeck & #MickJagger performing @ for the President. NOW http:\/\/t.co\/559qJFXs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JeffBeck",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "MickJagger",
        "indices" : [ 16, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/559qJFXs",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172125842116321280",
    "text" : "Wow #JeffBeck & #MickJagger performing @ for the President. NOW http:\/\/t.co\/559qJFXs",
    "id" : 172125842116321280,
    "created_at" : "2012-02-22 01:09:33 +0000",
    "user" : {
      "name" : "I'mSTILLWithHer",
      "screen_name" : "stefsstuff",
      "protected" : false,
      "id_str" : "16209626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635938714280050688\/1RpWsYOl_normal.jpg",
      "id" : 16209626,
      "verified" : false
    }
  },
  "id" : 172126142155857921,
  "created_at" : "2012-02-22 01:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/8TODyicw",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
      "display_url" : "WhiteHouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172124623004123136",
  "text" : "Wait, did Mick Jagger just take the stage @WhiteHouse? Don't miss: http:\/\/t.co\/8TODyicw",
  "id" : 172124623004123136,
  "created_at" : "2012-02-22 01:04:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HurtsSoGood",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/8TODyicw",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
      "display_url" : "WhiteHouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172123257334538240",
  "text" : "Don't miss the blues Jeff Beck is playing right now http:\/\/t.co\/8TODyicw #HurtsSoGood",
  "id" : 172123257334538240,
  "created_at" : "2012-02-22 00:59:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 3, 13 ],
      "id_str" : "1175221",
      "id" : 1175221
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/mzyVvP2D",
      "expanded_url" : "http:\/\/1.usa.gov\/19NzSg",
      "display_url" : "1.usa.gov\/19NzSg"
    } ]
  },
  "geo" : { },
  "id_str" : "172122865993383936",
  "text" : "RT @digiphile: Just heard a great song by Trombone Shorty, playing the @WhiteHouse: http:\/\/t.co\/mzyVvP2D  We're streaming the blues whil ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/mzyVvP2D",
        "expanded_url" : "http:\/\/1.usa.gov\/19NzSg",
        "display_url" : "1.usa.gov\/19NzSg"
      } ]
    },
    "geo" : { },
    "id_str" : "172122236008927233",
    "text" : "Just heard a great song by Trombone Shorty, playing the @WhiteHouse: http:\/\/t.co\/mzyVvP2D  We're streaming the blues while we cook in DC.",
    "id" : 172122236008927233,
    "created_at" : "2012-02-22 00:55:13 +0000",
    "user" : {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "protected" : false,
      "id_str" : "1175221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787135485361684480\/smcj17ad_normal.jpg",
      "id" : 1175221,
      "verified" : true
    }
  },
  "id" : 172122865993383936,
  "created_at" : "2012-02-22 00:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Working Class Heroes",
      "screen_name" : "WCHeroes",
      "indices" : [ 3, 12 ],
      "id_str" : "422113547",
      "id" : 422113547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/X5rqXTNd",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172122467551289344",
  "text" : "RT @WCHeroes: http:\/\/t.co\/X5rqXTNd tremendous LIVE streaming concert from the WhiteHouse .... NOW! Blues extraordinaire! Check it out!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/X5rqXTNd",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172121553260118017",
    "text" : "http:\/\/t.co\/X5rqXTNd tremendous LIVE streaming concert from the WhiteHouse .... NOW! Blues extraordinaire! Check it out!",
    "id" : 172121553260118017,
    "created_at" : "2012-02-22 00:52:30 +0000",
    "user" : {
      "name" : "Working Class Heroes",
      "screen_name" : "WCHeroes",
      "protected" : false,
      "id_str" : "422113547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1806866751\/WCHfavepic_normal.jpg",
      "id" : 422113547,
      "verified" : false
    }
  },
  "id" : 172122467551289344,
  "created_at" : "2012-02-22 00:56:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpokaneChica",
      "screen_name" : "SpokaneChica",
      "indices" : [ 3, 16 ],
      "id_str" : "419178728",
      "id" : 419178728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/ACVQziXl",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172122306951385088",
  "text" : "RT @SpokaneChica: Wow. Buddy Guy & Jeff Beck together @ The Whitehouse. Outstanding!!!! http:\/\/t.co\/ACVQziXl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/ACVQziXl",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172121686764830723",
    "text" : "Wow. Buddy Guy & Jeff Beck together @ The Whitehouse. Outstanding!!!! http:\/\/t.co\/ACVQziXl",
    "id" : 172121686764830723,
    "created_at" : "2012-02-22 00:53:02 +0000",
    "user" : {
      "name" : "SpokaneChica",
      "screen_name" : "SpokaneChica",
      "protected" : false,
      "id_str" : "419178728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520424306681995264\/yrXu_i7e_normal.jpeg",
      "id" : 419178728,
      "verified" : false
    }
  },
  "id" : 172122306951385088,
  "created_at" : "2012-02-22 00:55:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Mathieu",
      "screen_name" : "JoeMathieuWBZ",
      "indices" : [ 3, 17 ],
      "id_str" : "288175280",
      "id" : 288175280
    }, {
      "name" : "Buddy Guy",
      "screen_name" : "TheRealBuddyGuy",
      "indices" : [ 35, 51 ],
      "id_str" : "34955691",
      "id" : 34955691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172121757111689217",
  "text" : "RT @JoeMathieuWBZ: How cool to see @therealbuddyguy and the Great Jeff Beck play inside the White House. It's live here: http:\/\/t.co\/Bd0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buddy Guy",
        "screen_name" : "TheRealBuddyGuy",
        "indices" : [ 16, 32 ],
        "id_str" : "34955691",
        "id" : 34955691
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/Bd043QHu",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172121597166096384",
    "text" : "How cool to see @therealbuddyguy and the Great Jeff Beck play inside the White House. It's live here: http:\/\/t.co\/Bd043QHu",
    "id" : 172121597166096384,
    "created_at" : "2012-02-22 00:52:41 +0000",
    "user" : {
      "name" : "Joe Mathieu",
      "screen_name" : "JoeMathieuWBZ",
      "protected" : false,
      "id_str" : "288175280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1326229733\/JoeMatheu_HeadShot_-_smaller_normal.jpg",
      "id" : 288175280,
      "verified" : true
    }
  },
  "id" : 172121757111689217,
  "created_at" : "2012-02-22 00:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Pavlidis",
      "screen_name" : "harrypav",
      "indices" : [ 3, 12 ],
      "id_str" : "18279744",
      "id" : 18279744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/cLMA91av",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172121246014771201",
  "text" : "RT @harrypav: Blues? Yes. BB King and many others: White House Video: http:\/\/t.co\/cLMA91av",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/cLMA91av",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172117807025238016",
    "text" : "Blues? Yes. BB King and many others: White House Video: http:\/\/t.co\/cLMA91av",
    "id" : 172117807025238016,
    "created_at" : "2012-02-22 00:37:37 +0000",
    "user" : {
      "name" : "Harry Pavlidis",
      "screen_name" : "harrypav",
      "protected" : false,
      "id_str" : "18279744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766326341268496384\/7vFNcsRA_normal.jpg",
      "id" : 18279744,
      "verified" : false
    }
  },
  "id" : 172121246014771201,
  "created_at" : "2012-02-22 00:51:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "robertdonovan",
      "screen_name" : "robertdonovan",
      "indices" : [ 3, 17 ],
      "id_str" : "16563725",
      "id" : 16563725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/liNBoFUF",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172120729482047489",
  "text" : "RT @robertdonovan: Some blues \/ funk live from the White Huse right now http:\/\/t.co\/liNBoFUF Trombone shorty on right now",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/liNBoFUF",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "172120143697154048",
    "text" : "Some blues \/ funk live from the White Huse right now http:\/\/t.co\/liNBoFUF Trombone shorty on right now",
    "id" : 172120143697154048,
    "created_at" : "2012-02-22 00:46:54 +0000",
    "user" : {
      "name" : "robertdonovan",
      "screen_name" : "robertdonovan",
      "protected" : false,
      "id_str" : "16563725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220908546\/164537_1810005012914_1323647766_1963859_5759083_n_normal.jpg",
      "id" : 16563725,
      "verified" : false
    }
  },
  "id" : 172120729482047489,
  "created_at" : "2012-02-22 00:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Warren Haynes",
      "screen_name" : "thewarrenhaynes",
      "indices" : [ 3, 19 ],
      "id_str" : "285765523",
      "id" : 285765523
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 123, 127 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/fXOiMJte",
      "expanded_url" : "http:\/\/1.usa.gov\/wd0Yg7",
      "display_url" : "1.usa.gov\/wd0Yg7"
    } ]
  },
  "geo" : { },
  "id_str" : "172120662893273088",
  "text" : "RT @thewarrenhaynes: Catch Warren on \"Red White & Blues\" streaming LIVE @ 7:15pm tonight at http:\/\/t.co\/fXOiMJte - Airs on @PBS  on 2\/27 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PBS",
        "screen_name" : "PBS",
        "indices" : [ 102, 106 ],
        "id_str" : "12133382",
        "id" : 12133382
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PBSipwh",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/fXOiMJte",
        "expanded_url" : "http:\/\/1.usa.gov\/wd0Yg7",
        "display_url" : "1.usa.gov\/wd0Yg7"
      } ]
    },
    "geo" : { },
    "id_str" : "172089392196890624",
    "text" : "Catch Warren on \"Red White & Blues\" streaming LIVE @ 7:15pm tonight at http:\/\/t.co\/fXOiMJte - Airs on @PBS  on 2\/27 at 9pm ET #PBSipwh",
    "id" : 172089392196890624,
    "created_at" : "2012-02-21 22:44:43 +0000",
    "user" : {
      "name" : "Warren Haynes",
      "screen_name" : "thewarrenhaynes",
      "protected" : false,
      "id_str" : "285765523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600697165095251969\/bQmvHqYw_normal.jpg",
      "id" : 285765523,
      "verified" : true
    }
  },
  "id" : 172120662893273088,
  "created_at" : "2012-02-22 00:48:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "172108546970894338",
  "text" : "Happening @ 7:15ET: The President & First Lady host \"In Performance #AtTheWH: Red, White & Blues\" Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 172108546970894338,
  "created_at" : "2012-02-22 00:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 17, 31 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCtour",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/rWMzsBUm",
      "expanded_url" : "http:\/\/wh.gov\/8NC",
      "display_url" : "wh.gov\/8NC"
    } ]
  },
  "geo" : { },
  "id_str" : "172081778977280000",
  "text" : "Dr. Jill Biden & @hildasolisdol kick off the Community College to Career Bus Tour & want to hear from you: http:\/\/t.co\/rWMzsBUm #CCtour",
  "id" : 172081778977280000,
  "created_at" : "2012-02-21 22:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172037849980473344",
  "text" : "President Obama to Congress: \"Don\u2019t stop here...Keep taking the action that people are calling for to keep this economy growing\" #40dollars",
  "id" : 172037849980473344,
  "created_at" : "2012-02-21 19:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 56, 66 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/uvRzRODu",
      "expanded_url" : "http:\/\/go.usa.gov\/UiQ",
      "display_url" : "go.usa.gov\/UiQ"
    } ]
  },
  "geo" : { },
  "id_str" : "172015064465940482",
  "text" : "RT @StateDept: Starting Soon! #SecClinton addresses the @StateDept Global Business Conference. Watch here: http:\/\/t.co\/uvRzRODu #EconDip ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 41, 51 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 15, 26 ]
      }, {
        "text" : "EconDiplomacy",
        "indices" : [ 113, 127 ]
      }, {
        "text" : "SGBC",
        "indices" : [ 128, 133 ]
      }, {
        "text" : "jobs",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/uvRzRODu",
        "expanded_url" : "http:\/\/go.usa.gov\/UiQ",
        "display_url" : "go.usa.gov\/UiQ"
      } ]
    },
    "geo" : { },
    "id_str" : "172012674337619969",
    "text" : "Starting Soon! #SecClinton addresses the @StateDept Global Business Conference. Watch here: http:\/\/t.co\/uvRzRODu #EconDiplomacy #SGBC #jobs",
    "id" : 172012674337619969,
    "created_at" : "2012-02-21 17:39:52 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 172015064465940482,
  "created_at" : "2012-02-21 17:49:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171999027766894593",
  "text" : "RT @WHLive: Obama: Congress needs to pass my plan to help responsible homeowners save about $3,000 a year by refinancing at historically ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171998983084969984",
    "text" : "Obama: Congress needs to pass my plan to help responsible homeowners save about $3,000 a year by refinancing at historically low rates.",
    "id" : 171998983084969984,
    "created_at" : "2012-02-21 16:45:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 171999027766894593,
  "created_at" : "2012-02-21 16:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171998640385179648",
  "text" : "RT @WHLive: Obama: Congress did the right thing here. They listened to the voices of the American people. #40dollars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171998591307616257",
    "text" : "Obama: Congress did the right thing here. They listened to the voices of the American people. #40dollars",
    "id" : 171998591307616257,
    "created_at" : "2012-02-21 16:43:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 171998640385179648,
  "created_at" : "2012-02-21 16:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 98, 105 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "171997976108072960",
  "text" : "Happening now: President Obama Hosts a Payroll Tax Cut event. Watch: http:\/\/t.co\/QDIpMRKE Follow: @WHLive",
  "id" : 171997976108072960,
  "created_at" : "2012-02-21 16:41:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 132, 139 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "171995528987541504",
  "text" : "Live @ 11:35ET: Pres Obama speaks on the payroll tax cut w\/ folks that shared #40dollars stories. Watch http:\/\/t.co\/u95y7hhB Follow @WHLive",
  "id" : 171995528987541504,
  "created_at" : "2012-02-21 16:31:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Xm1vLi3R",
      "expanded_url" : "http:\/\/ow.ly\/9cedX",
      "display_url" : "ow.ly\/9cedX"
    } ]
  },
  "geo" : { },
  "id_str" : "171979565646876672",
  "text" : "Today, the President joins Americans that shared #40dollars stories. Watch: @ 11:30ET http:\/\/t.co\/u95y7hhB Slideshow: http:\/\/t.co\/Xm1vLi3R",
  "id" : 171979565646876672,
  "created_at" : "2012-02-21 15:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/171704950743764992\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/qdWmBQTC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmIEvjOCEAAaA_R.jpg",
      "id_str" : "171704950747959296",
      "id" : 171704950747959296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmIEvjOCEAAaA_R.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qdWmBQTC"
    } ],
    "hashtags" : [ {
      "text" : "Boeing",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171704950743764992",
  "text" : "Photo of the Day: At #Boeing in Everett, WA, President Obama talks increasing US exports & checks out a 787 Dreamliner: http:\/\/t.co\/qdWmBQTC",
  "id" : 171704950743764992,
  "created_at" : "2012-02-20 21:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 31, 41 ]
    }, {
      "text" : "AtTheWH",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/n1Hl3nRv",
      "expanded_url" : "http:\/\/wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "171244658041700352",
  "text" : "Last chance to sign up for the #WHTweetup: Welcome UK Prime Minister for an Official Visit #AtTheWH. Apply: http:\/\/t.co\/n1Hl3nRv",
  "id" : 171244658041700352,
  "created_at" : "2012-02-19 14:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/kTqrd1qM",
      "expanded_url" : "http:\/\/goo.gl\/fb\/rXfJx",
      "display_url" : "goo.gl\/fb\/rXfJx"
    } ]
  },
  "geo" : { },
  "id_str" : "171242313442533377",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: Weekly Address: Continuing to Strengthen American Manufacturing http:\/\/t.co\/kTqrd1qM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/kTqrd1qM",
        "expanded_url" : "http:\/\/goo.gl\/fb\/rXfJx",
        "display_url" : "goo.gl\/fb\/rXfJx"
      } ]
    },
    "geo" : { },
    "id_str" : "170833691931705345",
    "text" : "http:\/\/t.co\/HxTO58SB: Weekly Address: Continuing to Strengthen American Manufacturing http:\/\/t.co\/kTqrd1qM",
    "id" : 170833691931705345,
    "created_at" : "2012-02-18 11:35:00 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 171242313442533377,
  "created_at" : "2012-02-19 14:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Idaho",
      "indices" : [ 19, 25 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 47, 61 ]
    }, {
      "text" : "HireAVet",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/YsmfQ4qd",
      "expanded_url" : "http:\/\/wh.gov\/0UM",
      "display_url" : "wh.gov\/0UM"
    } ]
  },
  "geo" : { },
  "id_str" : "170636078108254208",
  "text" : "RT @JoiningForces: #Idaho billboard company is #JoiningForces to raise awareness: http:\/\/t.co\/YsmfQ4qd Have a look at the #HireAVet sign ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JoiningForces\/status\/170635934675644418\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/OqHxHB52",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Al44eoDCMAA3qM0.jpg",
        "id_str" : "170635934684033024",
        "id" : 170635934684033024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Al44eoDCMAA3qM0.jpg",
        "sizes" : [ {
          "h" : 301,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OqHxHB52"
      } ],
      "hashtags" : [ {
        "text" : "Idaho",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 28, 42 ]
      }, {
        "text" : "HireAVet",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/YsmfQ4qd",
        "expanded_url" : "http:\/\/wh.gov\/0UM",
        "display_url" : "wh.gov\/0UM"
      } ]
    },
    "geo" : { },
    "id_str" : "170635934675644418",
    "text" : "#Idaho billboard company is #JoiningForces to raise awareness: http:\/\/t.co\/YsmfQ4qd Have a look at the #HireAVet sign: http:\/\/t.co\/OqHxHB52",
    "id" : 170635934675644418,
    "created_at" : "2012-02-17 22:29:12 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 170636078108254208,
  "created_at" : "2012-02-17 22:29:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 52, 64 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/n1Hl3nRv",
      "expanded_url" : "http:\/\/wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "170620265343094784",
  "text" : "Want to come to the WH to welcome UK Prime Minister @Number10gov for an Official Visit? Apply for the next #WHTweetup: http:\/\/t.co\/n1Hl3nRv",
  "id" : 170620265343094784,
  "created_at" : "2012-02-17 21:26:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven VanRoekel",
      "screen_name" : "stevenvDC",
      "indices" : [ 3, 13 ],
      "id_str" : "26390322",
      "id" : 26390322
    }, {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 96, 105 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/EbrmlJnU",
      "expanded_url" : "http:\/\/business.usa.gov",
      "display_url" : "business.usa.gov"
    }, {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/cqFQt79X",
      "expanded_url" : "http:\/\/1.usa.gov\/AmUkip",
      "display_url" : "1.usa.gov\/AmUkip"
    } ]
  },
  "geo" : { },
  "id_str" : "170616629464530945",
  "text" : "RT @stevenvDC: My blog on today's public launch of http:\/\/t.co\/EbrmlJnU at http:\/\/t.co\/cqFQt79X @OMBPress",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OMBPress",
        "screen_name" : "OMBPress",
        "indices" : [ 81, 90 ],
        "id_str" : "337742544",
        "id" : 337742544
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/EbrmlJnU",
        "expanded_url" : "http:\/\/business.usa.gov",
        "display_url" : "business.usa.gov"
      }, {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/cqFQt79X",
        "expanded_url" : "http:\/\/1.usa.gov\/AmUkip",
        "display_url" : "1.usa.gov\/AmUkip"
      } ]
    },
    "geo" : { },
    "id_str" : "170607228154417152",
    "text" : "My blog on today's public launch of http:\/\/t.co\/EbrmlJnU at http:\/\/t.co\/cqFQt79X @OMBPress",
    "id" : 170607228154417152,
    "created_at" : "2012-02-17 20:35:07 +0000",
    "user" : {
      "name" : "Steven VanRoekel",
      "screen_name" : "stevenvDC",
      "protected" : false,
      "id_str" : "26390322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637435481\/8b47f7521e20a93de456cb4b945e05ed_normal.png",
      "id" : 26390322,
      "verified" : true
    }
  },
  "id" : 170616629464530945,
  "created_at" : "2012-02-17 21:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/170606956099284992\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/Vib8oD50",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Al4eH2bCMAAQw_l.jpg",
      "id_str" : "170606956103479296",
      "id" : 170606956103479296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Al4eH2bCMAAQw_l.jpg",
      "sizes" : [ {
        "h" : 1427,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1427,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Vib8oD50"
    } ],
    "hashtags" : [ {
      "text" : "Boeing",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/CDxrR4LS",
      "expanded_url" : "http:\/\/wh.gov\/8rL",
      "display_url" : "wh.gov\/8rL"
    } ]
  },
  "geo" : { },
  "id_str" : "170606956099284992",
  "text" : "Infographic: Exporting the #Boeing Dreamliner. Full size: http:\/\/t.co\/CDxrR4LS Twitter size: http:\/\/t.co\/Vib8oD50",
  "id" : 170606956099284992,
  "created_at" : "2012-02-17 20:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boeing Airplanes",
      "screen_name" : "BoeingAirplanes",
      "indices" : [ 3, 19 ],
      "id_str" : "22090282",
      "id" : 22090282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaWA",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "Boeing",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170606744731533312",
  "text" : "RT @BoeingAirplanes: Photo: Pres. Barack Obama speaking in front of a line of future Boeing 787 Dreamliners. #ObamaWA #Boeing http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoeingAirplanes\/status\/170602034347782144\/photo\/1",
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/IC9HTnzZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Al4ZpXfCMAEbdBQ.jpg",
        "id_str" : "170602034356170753",
        "id" : 170602034356170753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Al4ZpXfCMAEbdBQ.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1154,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IC9HTnzZ"
      } ],
      "hashtags" : [ {
        "text" : "ObamaWA",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "Boeing",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170602034347782144",
    "text" : "Photo: Pres. Barack Obama speaking in front of a line of future Boeing 787 Dreamliners. #ObamaWA #Boeing http:\/\/t.co\/IC9HTnzZ",
    "id" : 170602034347782144,
    "created_at" : "2012-02-17 20:14:30 +0000",
    "user" : {
      "name" : "Boeing Airplanes",
      "screen_name" : "BoeingAirplanes",
      "protected" : false,
      "id_str" : "22090282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512272574068162561\/4mk91UzF_normal.jpeg",
      "id" : 22090282,
      "verified" : true
    }
  },
  "id" : 170606744731533312,
  "created_at" : "2012-02-17 20:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170600826736349184",
  "text" : "RT @WHLive: Obama: We have to renew the values that have always made this country great: Hard work.  Fair play. Shared responsibility.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170600777558138880",
    "text" : "Obama: We have to renew the values that have always made this country great: Hard work.  Fair play. Shared responsibility.",
    "id" : 170600777558138880,
    "created_at" : "2012-02-17 20:09:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 170600826736349184,
  "created_at" : "2012-02-17 20:09:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170597111346364416",
  "text" : "RT @WHLive: Obama: Congress did the right thing & voted to make sure that taxes won\u2019t go up on middle-class families at the end of this  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170596938469736449",
    "text" : "Obama: Congress did the right thing & voted to make sure that taxes won\u2019t go up on middle-class families at the end of this month #40dollars",
    "id" : 170596938469736449,
    "created_at" : "2012-02-17 19:54:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 170597111346364416,
  "created_at" : "2012-02-17 19:54:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 127, 134 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "170595867424854017",
  "text" : "Happening now: President Obama speaks @ Boeing Production Facility\nin Everett, Washington. Watch: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 170595867424854017,
  "created_at" : "2012-02-17 19:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/uME185IJ",
      "expanded_url" : "http:\/\/youtu.be\/IyI22mih47s",
      "display_url" : "youtu.be\/IyI22mih47s"
    } ]
  },
  "geo" : { },
  "id_str" : "170574954029514754",
  "text" : "Thank you. You spoke out, Congress acted & soon I'll sign the payroll tax cut extension into law. -bo #40dollars http:\/\/t.co\/uME185IJ",
  "id" : 170574954029514754,
  "created_at" : "2012-02-17 18:26:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 53, 63 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/s7xzzBSJ",
      "expanded_url" : "http:\/\/goo.gl\/azXvT",
      "display_url" : "goo.gl\/azXvT"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/weaLALpl",
      "expanded_url" : "http:\/\/go.usa.gov\/QMF",
      "display_url" : "go.usa.gov\/QMF"
    } ]
  },
  "geo" : { },
  "id_str" : "170539970539433986",
  "text" : "RT @StateDept: If you're on Google+, you can now add @StateDept to your circles: http:\/\/t.co\/s7xzzBSJ | More: http:\/\/t.co\/weaLALpl #Open ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 38, 48 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenGov",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "Gov20",
        "indices" : [ 125, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/s7xzzBSJ",
        "expanded_url" : "http:\/\/goo.gl\/azXvT",
        "display_url" : "goo.gl\/azXvT"
      }, {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/weaLALpl",
        "expanded_url" : "http:\/\/go.usa.gov\/QMF",
        "display_url" : "go.usa.gov\/QMF"
      } ]
    },
    "geo" : { },
    "id_str" : "170538434597892097",
    "text" : "If you're on Google+, you can now add @StateDept to your circles: http:\/\/t.co\/s7xzzBSJ | More: http:\/\/t.co\/weaLALpl #OpenGov #Gov20",
    "id" : 170538434597892097,
    "created_at" : "2012-02-17 16:01:45 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 170539970539433986,
  "created_at" : "2012-02-17 16:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Z8Rr0ilY",
      "expanded_url" : "http:\/\/bit.ly\/xkolPv",
      "display_url" : "bit.ly\/xkolPv"
    } ]
  },
  "geo" : { },
  "id_str" : "170528129926967297",
  "text" : "RT @jesseclee44: Moving story, inspirational woman: \"Cayucos' Jodi Fisher meets President in San Francisco\" http:\/\/t.co\/Z8Rr0ilY Photo:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/170527449862512641\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/pLPXW9KA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Al3Vz-nCIAIQTe1.jpg",
        "id_str" : "170527449866706946",
        "id" : 170527449866706946,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Al3Vz-nCIAIQTe1.jpg",
        "sizes" : [ {
          "h" : 573,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 421
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 421
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 421
        } ],
        "display_url" : "pic.twitter.com\/pLPXW9KA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/Z8Rr0ilY",
        "expanded_url" : "http:\/\/bit.ly\/xkolPv",
        "display_url" : "bit.ly\/xkolPv"
      } ]
    },
    "geo" : { },
    "id_str" : "170527449862512641",
    "text" : "Moving story, inspirational woman: \"Cayucos' Jodi Fisher meets President in San Francisco\" http:\/\/t.co\/Z8Rr0ilY Photo: http:\/\/t.co\/pLPXW9KA",
    "id" : 170527449862512641,
    "created_at" : "2012-02-17 15:18:07 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 170528129926967297,
  "created_at" : "2012-02-17 15:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/slTABJOs",
      "expanded_url" : "http:\/\/youtu.be\/cgueu-XmOJw",
      "display_url" : "youtu.be\/cgueu-XmOJw"
    } ]
  },
  "geo" : { },
  "id_str" : "170527657967108096",
  "text" : "Have a look at West Wing Week, your guide to everything that's happening at 1600 Pennsylvania Ave: http:\/\/t.co\/slTABJOs",
  "id" : 170527657967108096,
  "created_at" : "2012-02-17 15:18:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/2xkd039U",
      "expanded_url" : "http:\/\/youtu.be\/q7Cz6Hp2qKY",
      "display_url" : "youtu.be\/q7Cz6Hp2qKY"
    } ]
  },
  "geo" : { },
  "id_str" : "170235760635674625",
  "text" : "w\/Congress moving to extend payroll tax cut, Deese explains why it's important to get this done http:\/\/t.co\/2xkd039U #40dollars",
  "id" : 170235760635674625,
  "created_at" : "2012-02-16 19:59:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/170184000516788226\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/p1qKAArU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlydcmHCEAEpnMP.jpg",
      "id_str" : "170184000525176833",
      "id" : 170184000525176833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlydcmHCEAEpnMP.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 674
      } ],
      "display_url" : "pic.twitter.com\/p1qKAArU"
    } ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "170184000516788226",
  "text" : "Are you watching this? The First Lady & Bo surprise visitors in the Blue Room #AtTheWH: http:\/\/t.co\/u95y7hhB http:\/\/t.co\/p1qKAArU",
  "id" : 170184000516788226,
  "created_at" : "2012-02-16 16:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Borde",
      "screen_name" : "crys78",
      "indices" : [ 3, 10 ],
      "id_str" : "16699210",
      "id" : 16699210
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 34, 41 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Michelle Obama",
      "screen_name" : "MichelleObama",
      "indices" : [ 45, 59 ],
      "id_str" : "409486555",
      "id" : 409486555
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 109, 120 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170178099365945345",
  "text" : "RT @crys78: Loving live feed from @WHLive of @michelleobama and Bo surprising visitors right now touring the @WhiteHouse. Video: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 22, 29 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Michelle Obama",
        "screen_name" : "MichelleObama",
        "indices" : [ 33, 47 ],
        "id_str" : "409486555",
        "id" : 409486555
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 97, 108 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/vhXdIJEJ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live?utm_source=021612",
        "display_url" : "whitehouse.gov\/live?utm_sourc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170177871397126145",
    "text" : "Loving live feed from @WHLive of @michelleobama and Bo surprising visitors right now touring the @WhiteHouse. Video: http:\/\/t.co\/vhXdIJEJ",
    "id" : 170177871397126145,
    "created_at" : "2012-02-16 16:09:00 +0000",
    "user" : {
      "name" : "Crystal Borde",
      "screen_name" : "crys78",
      "protected" : false,
      "id_str" : "16699210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588326949321252864\/57UV_865_normal.jpg",
      "id" : 16699210,
      "verified" : false
    }
  },
  "id" : 170178099365945345,
  "created_at" : "2012-02-16 16:09:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bo",
      "indices" : [ 105, 108 ]
    }, {
      "text" : "BirthdayHugs",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "170175320534679553",
  "text" : "Just started: First Lady Michelle Obama surprises @WhiteHouse visitors. Watch live: http:\/\/t.co\/u95y7hhB #Bo #BirthdayHugs",
  "id" : 170175320534679553,
  "created_at" : "2012-02-16 15:58:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 10, 21 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "170172715137892352",
  "text" : "Surprise! @WhiteHouse\u2019s biggest celebrity (our dog Bo) & I are about to greet folks on their tours. Watch it live: http:\/\/t.co\/u95y7hhB -mo",
  "id" : 170172715137892352,
  "created_at" : "2012-02-16 15:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lu",
      "screen_name" : "ChrisLu44",
      "indices" : [ 3, 13 ],
      "id_str" : "461697741",
      "id" : 461697741
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 36, 45 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Jeremy Lin",
      "screen_name" : "JLin7",
      "indices" : [ 53, 59 ],
      "id_str" : "170424259",
      "id" : 170424259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/CkCWK9sV",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/02\/15\/press-gaggle-press-secretary-jay-carney-en-route-milwaukee-wi-21512",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170166388470710272",
  "text" : "RT @ChrisLu44: WH Press Secretary ( @PressSec ) says @jlin7 is a \"great story\" that \"transcends the sport itself\" http:\/\/t.co\/CkCWK9sV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 21, 30 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "Jeremy Lin",
        "screen_name" : "JLin7",
        "indices" : [ 38, 44 ],
        "id_str" : "170424259",
        "id" : 170424259
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/CkCWK9sV",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/02\/15\/press-gaggle-press-secretary-jay-carney-en-route-milwaukee-wi-21512",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169926808425345024",
    "text" : "WH Press Secretary ( @PressSec ) says @jlin7 is a \"great story\" that \"transcends the sport itself\" http:\/\/t.co\/CkCWK9sV",
    "id" : 169926808425345024,
    "created_at" : "2012-02-15 23:31:22 +0000",
    "user" : {
      "name" : "Chris Lu",
      "screen_name" : "ChrisLu44",
      "protected" : false,
      "id_str" : "461697741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739167604514934784\/as9mVLOb_normal.jpg",
      "id" : 461697741,
      "verified" : true
    }
  },
  "id" : 170166388470710272,
  "created_at" : "2012-02-16 15:23:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 93, 104 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/qhYt1HDm",
      "expanded_url" : "http:\/\/bit.ly\/xA72yS",
      "display_url" : "bit.ly\/xA72yS"
    } ]
  },
  "geo" : { },
  "id_str" : "170165152589692928",
  "text" : "RT @RayLaHood: Champions for Change are rebuilding America; great to honor them yesterday at @whitehouse http:\/\/t.co\/qhYt1HDm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 78, 89 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/qhYt1HDm",
        "expanded_url" : "http:\/\/bit.ly\/xA72yS",
        "display_url" : "bit.ly\/xA72yS"
      } ]
    },
    "geo" : { },
    "id_str" : "170163577234259968",
    "text" : "Champions for Change are rebuilding America; great to honor them yesterday at @whitehouse http:\/\/t.co\/qhYt1HDm",
    "id" : 170163577234259968,
    "created_at" : "2012-02-16 15:12:12 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 170165152589692928,
  "created_at" : "2012-02-16 15:18:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/cswk3miN",
      "expanded_url" : "http:\/\/ow.ly\/i\/sJg7",
      "display_url" : "ow.ly\/i\/sJg7"
    }, {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/1amE0hhJ",
      "expanded_url" : "http:\/\/ow.ly\/96hkE",
      "display_url" : "ow.ly\/96hkE"
    } ]
  },
  "geo" : { },
  "id_str" : "169998445246038018",
  "text" : "By the Numbers: 86 million: http:\/\/t.co\/cswk3miN Provisions in the Affordable Care Act helped 86 million people: http:\/\/t.co\/1amE0hhJ #hcr",
  "id" : 169998445246038018,
  "created_at" : "2012-02-16 04:16:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicolas Sarkozy",
      "screen_name" : "NicolasSarkozy",
      "indices" : [ 19, 34 ],
      "id_str" : "490126636",
      "id" : 490126636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/169931564854153216\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/dPIxOqa8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Alu325_CEAAWs3k.jpg",
      "id_str" : "169931564862541824",
      "id" : 169931564862541824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Alu325_CEAAWs3k.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dPIxOqa8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169931564854153216",
  "text" : "Welcome to Twitter @NicolasSarkozy. Here's a pic of President Obama mtg with President Sarkozy in the Oval Office: http:\/\/t.co\/dPIxOqa8",
  "id" : 169931564854153216,
  "created_at" : "2012-02-15 23:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Walker",
      "screen_name" : "GovWalker",
      "indices" : [ 3, 13 ],
      "id_str" : "213795411",
      "id" : 213795411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169923105031069696",
  "text" : "RT @GovWalker: I appreciate the President's visit to Master Lock as it highlights our #1 industry in WI: manufacturing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169854821036335105",
    "text" : "I appreciate the President's visit to Master Lock as it highlights our #1 industry in WI: manufacturing.",
    "id" : 169854821036335105,
    "created_at" : "2012-02-15 18:45:19 +0000",
    "user" : {
      "name" : "Governor Walker",
      "screen_name" : "GovWalker",
      "protected" : false,
      "id_str" : "213795411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561234118864670720\/gasKlzlk_normal.jpeg",
      "id" : 213795411,
      "verified" : true
    }
  },
  "id" : 169923105031069696,
  "created_at" : "2012-02-15 23:16:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/BTsjAgrO",
      "expanded_url" : "http:\/\/ow.ly\/963Ee",
      "display_url" : "ow.ly\/963Ee"
    } ]
  },
  "geo" : { },
  "id_str" : "169922664004194304",
  "text" : "RT @JoiningForces: First Lady & Dr. Biden urge state action to support military spouses with state licenses: http:\/\/t.co\/BTsjAgrO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/BTsjAgrO",
        "expanded_url" : "http:\/\/ow.ly\/963Ee",
        "display_url" : "ow.ly\/963Ee"
      } ]
    },
    "geo" : { },
    "id_str" : "169916460037193728",
    "text" : "First Lady & Dr. Biden urge state action to support military spouses with state licenses: http:\/\/t.co\/BTsjAgrO",
    "id" : 169916460037193728,
    "created_at" : "2012-02-15 22:50:15 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 169922664004194304,
  "created_at" : "2012-02-15 23:14:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INsourcing",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/MEu665xd",
      "expanded_url" : "http:\/\/ow.ly\/963tO",
      "display_url" : "ow.ly\/963tO"
    } ]
  },
  "geo" : { },
  "id_str" : "169915828823785474",
  "text" : "\"It's time to...start rewarding companies that are creating jobs right here in the US\" -President Obama on #INsourcing http:\/\/t.co\/MEu665xd",
  "id" : 169915828823785474,
  "created_at" : "2012-02-15 22:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169881181897240577",
  "text" : "RT @JoiningForces: Happening now: The First Lady and Dr. Jill Biden unveil a new report on military spouse employment. Watch live: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/s0r4L0gl",
        "expanded_url" : "http:\/\/ow.ly\/95L8Z",
        "display_url" : "ow.ly\/95L8Z"
      } ]
    },
    "geo" : { },
    "id_str" : "169880351928365056",
    "text" : "Happening now: The First Lady and Dr. Jill Biden unveil a new report on military spouse employment. Watch live: http:\/\/t.co\/s0r4L0gl",
    "id" : 169880351928365056,
    "created_at" : "2012-02-15 20:26:46 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 169881181897240577,
  "created_at" : "2012-02-15 20:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master Lock Co",
      "screen_name" : "MasterLockCo",
      "indices" : [ 3, 16 ],
      "id_str" : "1241556030",
      "id" : 1241556030
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 70, 82 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHatML",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/RdJuJ90D",
      "expanded_url" : "http:\/\/yfrog.com\/h3rawzoj",
      "display_url" : "yfrog.com\/h3rawzoj"
    } ]
  },
  "geo" : { },
  "id_str" : "169856550297538560",
  "text" : "RT @MasterLockCo: Plant employee DiAndre Jackson introduces President @BarackObama at our Milwaukee plant. #WHatML http:\/\/t.co\/RdJuJ90D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 52, 64 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHatML",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/RdJuJ90D",
        "expanded_url" : "http:\/\/yfrog.com\/h3rawzoj",
        "display_url" : "yfrog.com\/h3rawzoj"
      } ]
    },
    "geo" : { },
    "id_str" : "169856433549082625",
    "text" : "Plant employee DiAndre Jackson introduces President @BarackObama at our Milwaukee plant. #WHatML http:\/\/t.co\/RdJuJ90D",
    "id" : 169856433549082625,
    "created_at" : "2012-02-15 18:51:44 +0000",
    "user" : {
      "name" : "Master Lock Company",
      "screen_name" : "MasterLockUS",
      "protected" : false,
      "id_str" : "87013627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3339748818\/cf0cb2c92d394adb067cf1a86f2af347_normal.jpeg",
      "id" : 87013627,
      "verified" : false
    }
  },
  "id" : 169856550297538560,
  "created_at" : "2012-02-15 18:52:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/SZg8g5Y0",
      "expanded_url" : "http:\/\/ow.ly\/95L8Z",
      "display_url" : "ow.ly\/95L8Z"
    } ]
  },
  "geo" : { },
  "id_str" : "169856203860615168",
  "text" : "Happening now: President Obama talks about #insourcing & an America built to last in Wisconsin. Watch live: http:\/\/t.co\/SZg8g5Y0",
  "id" : 169856203860615168,
  "created_at" : "2012-02-15 18:50:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Catherine",
      "screen_name" : "theotherbroad",
      "indices" : [ 6, 20 ],
      "id_str" : "29307526",
      "id" : 29307526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/uME185IJ",
      "expanded_url" : "http:\/\/youtu.be\/IyI22mih47s",
      "display_url" : "youtu.be\/IyI22mih47s"
    } ]
  },
  "geo" : { },
  "id_str" : "169837485160009728",
  "text" : "Megan @theotherbroad is one of the Americans that shared their #40dollars story & ended up at the White House. Watch: http:\/\/t.co\/uME185IJ",
  "id" : 169837485160009728,
  "created_at" : "2012-02-15 17:36:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master Lock Co",
      "screen_name" : "MasterLockCo",
      "indices" : [ 119, 132 ],
      "id_str" : "1241556030",
      "id" : 1241556030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INsourcing",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169813960743329792",
  "text" : "Today, President Obama heads to Milwaukee to talk about #INsourcing & the importance of companies investing in America @MasterLockCo",
  "id" : 169813960743329792,
  "created_at" : "2012-02-15 16:02:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master Lock Co",
      "screen_name" : "MasterLockCo",
      "indices" : [ 3, 16 ],
      "id_str" : "1241556030",
      "id" : 1241556030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169809262854414337",
  "text" : "RT @MasterLockCo: Our factory in Milwaukee, WI is set to host President Obama today....we are very excited to see the President... http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/FY8UmNPX",
        "expanded_url" : "http:\/\/fb.me\/1HjDN6BTJ",
        "display_url" : "fb.me\/1HjDN6BTJ"
      } ]
    },
    "geo" : { },
    "id_str" : "169788884568375296",
    "text" : "Our factory in Milwaukee, WI is set to host President Obama today....we are very excited to see the President... http:\/\/t.co\/FY8UmNPX",
    "id" : 169788884568375296,
    "created_at" : "2012-02-15 14:23:19 +0000",
    "user" : {
      "name" : "Master Lock Company",
      "screen_name" : "MasterLockUS",
      "protected" : false,
      "id_str" : "87013627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3339748818\/cf0cb2c92d394adb067cf1a86f2af347_normal.jpeg",
      "id" : 87013627,
      "verified" : false
    }
  },
  "id" : 169809262854414337,
  "created_at" : "2012-02-15 15:44:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/6Otnt8Gm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=IyI22mih47s",
      "display_url" : "youtube.com\/watch?v=IyI22m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169570736762130434",
  "text" : "Couldn't have said it better ourselves: #40dollars, in your words: http:\/\/t.co\/6Otnt8Gm",
  "id" : 169570736762130434,
  "created_at" : "2012-02-14 23:56:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sara k",
      "screen_name" : "livefromtexas",
      "indices" : [ 3, 17 ],
      "id_str" : "26675899",
      "id" : 26675899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "earinfections",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169548641298694144",
  "text" : "RT @livefromtexas: #40dollars is a sick child copay for each of my kids. #earinfections",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "earinfections",
        "indices" : [ 54, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169547847572795393",
    "text" : "#40dollars is a sick child copay for each of my kids. #earinfections",
    "id" : 169547847572795393,
    "created_at" : "2012-02-14 22:25:31 +0000",
    "user" : {
      "name" : "sara k",
      "screen_name" : "livefromtexas",
      "protected" : false,
      "id_str" : "26675899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466872408\/twitter1_normal.jpg",
      "id" : 26675899,
      "verified" : false
    }
  },
  "id" : 169548641298694144,
  "created_at" : "2012-02-14 22:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B.Nathan",
      "screen_name" : "B_Nathan",
      "indices" : [ 3, 12 ],
      "id_str" : "44170874",
      "id" : 44170874
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 86, 98 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169530868023562240",
  "text" : "RT @B_Nathan: #40dollars , that's funds for my text books they are already over $100! @BarackObama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 72, 84 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169530723781455872",
    "text" : "#40dollars , that's funds for my text books they are already over $100! @BarackObama",
    "id" : 169530723781455872,
    "created_at" : "2012-02-14 21:17:28 +0000",
    "user" : {
      "name" : "B.Nathan",
      "screen_name" : "B_Nathan",
      "protected" : false,
      "id_str" : "44170874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668109662215016448\/T9UPGMRW_normal.jpg",
      "id" : 44170874,
      "verified" : false
    }
  },
  "id" : 169530868023562240,
  "created_at" : "2012-02-14 21:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Ewin Turner",
      "screen_name" : "AEwinTurner",
      "indices" : [ 3, 15 ],
      "id_str" : "16656218",
      "id" : 16656218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169526541640933377",
  "text" : "RT @AEwinTurner: #40dollars covers incidental expenses for my son who is away at college. I deposited it in his account just last Friday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169526220449529856",
    "text" : "#40dollars covers incidental expenses for my son who is away at college. I deposited it in his account just last Friday.",
    "id" : 169526220449529856,
    "created_at" : "2012-02-14 20:59:35 +0000",
    "user" : {
      "name" : "Andrea Ewin Turner",
      "screen_name" : "AEwinTurner",
      "protected" : false,
      "id_str" : "16656218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478653608628453378\/aBRgdkHU_normal.jpeg",
      "id" : 16656218,
      "verified" : false
    }
  },
  "id" : 169526541640933377,
  "created_at" : "2012-02-14 21:00:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Turner",
      "screen_name" : "Tesse_Jurner",
      "indices" : [ 3, 16 ],
      "id_str" : "339120878",
      "id" : 339120878
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 18, 30 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169521043487199232",
  "text" : "RT @Tesse_Jurner: @BarackObama #40dollars contributes to my insurance, gas, car payments, phone bills, soon student loans, etc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "169458415058436096",
    "geo" : { },
    "id_str" : "169520893331116036",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama #40dollars contributes to my insurance, gas, car payments, phone bills, soon student loans, etc",
    "id" : 169520893331116036,
    "in_reply_to_status_id" : 169458415058436096,
    "created_at" : "2012-02-14 20:38:25 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Jesse Turner",
      "screen_name" : "Tesse_Jurner",
      "protected" : false,
      "id_str" : "339120878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787140364394258436\/ca24e_M6_normal.jpg",
      "id" : 339120878,
      "verified" : false
    }
  },
  "id" : 169521043487199232,
  "created_at" : "2012-02-14 20:39:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Root",
      "screen_name" : "elizabeth_root",
      "indices" : [ 3, 18 ],
      "id_str" : "779334499758907392",
      "id" : 779334499758907392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169512443540803585",
  "text" : "RT @Elizabeth_Root: #40dollars means the difference between paying my bills or going to collections. Why does congress do this to hard w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169512251726905344",
    "text" : "#40dollars means the difference between paying my bills or going to collections. Why does congress do this to hard working people?",
    "id" : 169512251726905344,
    "created_at" : "2012-02-14 20:04:04 +0000",
    "user" : {
      "name" : "Liz",
      "screen_name" : "Honey_Bee_85",
      "protected" : false,
      "id_str" : "183875877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000144507139\/4134185a9c91b79d6504e09887630c05_normal.jpeg",
      "id" : 183875877,
      "verified" : false
    }
  },
  "id" : 169512443540803585,
  "created_at" : "2012-02-14 20:04:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle P",
      "screen_name" : "alternakiddy",
      "indices" : [ 3, 16 ],
      "id_str" : "47806778",
      "id" : 47806778
    }, {
      "name" : "Citymeals on Wheels",
      "screen_name" : "Citymeals",
      "indices" : [ 48, 58 ],
      "id_str" : "36430363",
      "id" : 36430363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169506766898470912",
  "text" : "RT @alternakiddy: #40dollars means you can help @Citymeals provide 6 hot meals for our elderly neighbors in NYC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Citymeals on Wheels",
        "screen_name" : "Citymeals",
        "indices" : [ 30, 40 ],
        "id_str" : "36430363",
        "id" : 36430363
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169506315482308609",
    "text" : "#40dollars means you can help @Citymeals provide 6 hot meals for our elderly neighbors in NYC",
    "id" : 169506315482308609,
    "created_at" : "2012-02-14 19:40:29 +0000",
    "user" : {
      "name" : "Danielle P",
      "screen_name" : "alternakiddy",
      "protected" : false,
      "id_str" : "47806778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1827027673\/mini_me_normal.jpg",
      "id" : 47806778,
      "verified" : false
    }
  },
  "id" : 169506766898470912,
  "created_at" : "2012-02-14 19:42:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucia compher",
      "screen_name" : "Bellalucia1969",
      "indices" : [ 3, 18 ],
      "id_str" : "185020765",
      "id" : 185020765
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169506565408292864",
  "text" : "RT @Bellalucia1969: @whitehouse #40dollars is half of what it cost for 1 Rx in a month!- mother without insurance",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169506271672811520",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is half of what it cost for 1 Rx in a month!- mother without insurance",
    "id" : 169506271672811520,
    "created_at" : "2012-02-14 19:40:19 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Lucia compher",
      "screen_name" : "Bellalucia1969",
      "protected" : false,
      "id_str" : "185020765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1924842819\/image_normal.jpg",
      "id" : 185020765,
      "verified" : false
    }
  },
  "id" : 169506565408292864,
  "created_at" : "2012-02-14 19:41:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Gregory",
      "screen_name" : "Jenn_Gregory",
      "indices" : [ 3, 16 ],
      "id_str" : "391806506",
      "id" : 391806506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169499326232539136",
  "text" : "RT @jenn_gregory: #40dollars means I can put gas in my car for spring break...to go see my parents.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169498690636095488",
    "text" : "#40dollars means I can put gas in my car for spring break...to go see my parents.",
    "id" : 169498690636095488,
    "created_at" : "2012-02-14 19:10:11 +0000",
    "user" : {
      "name" : "Jenn Gregory",
      "screen_name" : "MightyJenn",
      "protected" : false,
      "id_str" : "187024345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778979778799951872\/Sd4rngDC_normal.jpg",
      "id" : 187024345,
      "verified" : false
    }
  },
  "id" : 169499326232539136,
  "created_at" : "2012-02-14 19:12:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenna Neroon",
      "screen_name" : "ravennaneroon",
      "indices" : [ 3, 17 ],
      "id_str" : "284334032",
      "id" : 284334032
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 19, 31 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169495146205949953",
  "text" : "RT @ravennaneroon: @BarackObama #40dollars is a week of food for my 3 year-old daughter.  Or a tank and a half for gas so I can go to wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "169458415058436096",
    "geo" : { },
    "id_str" : "169494978781904896",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama #40dollars is a week of food for my 3 year-old daughter.  Or a tank and a half for gas so I can go to work to support her.",
    "id" : 169494978781904896,
    "in_reply_to_status_id" : 169458415058436096,
    "created_at" : "2012-02-14 18:55:26 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Ravenna Neroon",
      "screen_name" : "ravennaneroon",
      "protected" : false,
      "id_str" : "284334032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000149392705\/47c1d8b585d65f8062ea84689f047d27_normal.jpeg",
      "id" : 284334032,
      "verified" : false
    }
  },
  "id" : 169495146205949953,
  "created_at" : "2012-02-14 18:56:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renae Douglas",
      "screen_name" : "RenaeDouglas",
      "indices" : [ 3, 16 ],
      "id_str" : "116818424",
      "id" : 116818424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169494401222049792",
  "text" : "RT @RenaeDouglas: What would #40dollars mean to us? Buying insulin for my diabetic husband. Feeding my kids fruits and veggies rather th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 11, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169494198695903234",
    "text" : "What would #40dollars mean to us? Buying insulin for my diabetic husband. Feeding my kids fruits and veggies rather than Hamburger Helper",
    "id" : 169494198695903234,
    "created_at" : "2012-02-14 18:52:20 +0000",
    "user" : {
      "name" : "Renae Douglas",
      "screen_name" : "RenaeDouglas",
      "protected" : false,
      "id_str" : "116818424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1718821650\/me_normal.jpg",
      "id" : 116818424,
      "verified" : false
    }
  },
  "id" : 169494401222049792,
  "created_at" : "2012-02-14 18:53:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uenotaylor",
      "screen_name" : "uenotaylor",
      "indices" : [ 3, 14 ],
      "id_str" : "17144994",
      "id" : 17144994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169494241096114176",
  "text" : "RT @uenotaylor: #40dollars means the co-pay to the insurance we pay monthly  for my husband's medicine he takes to control his Multiple  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169490844531965952",
    "text" : "#40dollars means the co-pay to the insurance we pay monthly  for my husband's medicine he takes to control his Multiple Sclerosis",
    "id" : 169490844531965952,
    "created_at" : "2012-02-14 18:39:00 +0000",
    "user" : {
      "name" : "uenotaylor",
      "screen_name" : "uenotaylor",
      "protected" : false,
      "id_str" : "17144994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1209710346\/P7270371_normal.JPG",
      "id" : 17144994,
      "verified" : false
    }
  },
  "id" : 169494241096114176,
  "created_at" : "2012-02-14 18:52:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/PgtqZyno",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TelUwfGyFnI",
      "display_url" : "youtube.com\/watch?v=TelUwf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169489585330585601",
  "text" : "\"I\u2019m asking the American people to keep their stories coming...If you tweet it, use the hashtag #40dollars\" -Pres Obama http:\/\/t.co\/PgtqZyno",
  "id" : 169489585330585601,
  "created_at" : "2012-02-14 18:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Bader",
      "screen_name" : "stephpbader",
      "indices" : [ 3, 15 ],
      "id_str" : "372561994",
      "id" : 372561994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169483104564690946",
  "text" : "RT @stephpbader: #40dollars means I can continue to buy trade books and other materials for engaging classroom activities for my 4th gra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169482864063283200",
    "text" : "#40dollars means I can continue to buy trade books and other materials for engaging classroom activities for my 4th graders.",
    "id" : 169482864063283200,
    "created_at" : "2012-02-14 18:07:18 +0000",
    "user" : {
      "name" : "Stephanie Bader",
      "screen_name" : "stephpbader",
      "protected" : false,
      "id_str" : "372561994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1547221169\/me_normal.jpg",
      "id" : 372561994,
      "verified" : false
    }
  },
  "id" : 169483104564690946,
  "created_at" : "2012-02-14 18:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami",
      "screen_name" : "tamalouska",
      "indices" : [ 3, 14 ],
      "id_str" : "15034684",
      "id" : 15034684
    }, {
      "name" : "Heidi Middleton",
      "screen_name" : "heidimid22",
      "indices" : [ 16, 27 ],
      "id_str" : "56397544",
      "id" : 56397544
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169481343477096448",
  "text" : "RT @tamalouska: @heidimid22 @whitehouse Recent college grads aren't the only ones struggling - #40dollars means a lot to MANY walks of life!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heidi Middleton",
        "screen_name" : "heidimid22",
        "indices" : [ 0, 11 ],
        "id_str" : "56397544",
        "id" : 56397544
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 12, 23 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 79, 89 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "169474566618492929",
    "geo" : { },
    "id_str" : "169480260247764992",
    "in_reply_to_user_id" : 56397544,
    "text" : "@heidimid22 @whitehouse Recent college grads aren't the only ones struggling - #40dollars means a lot to MANY walks of life!",
    "id" : 169480260247764992,
    "in_reply_to_status_id" : 169474566618492929,
    "created_at" : "2012-02-14 17:56:57 +0000",
    "in_reply_to_screen_name" : "heidimid22",
    "in_reply_to_user_id_str" : "56397544",
    "user" : {
      "name" : "Tami",
      "screen_name" : "tamalouska",
      "protected" : false,
      "id_str" : "15034684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788730344631439360\/4LZY7P2r_normal.jpg",
      "id" : 15034684,
      "verified" : false
    }
  },
  "id" : 169481343477096448,
  "created_at" : "2012-02-14 18:01:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Portillo",
      "screen_name" : "LuckyFridge",
      "indices" : [ 3, 15 ],
      "id_str" : "47880480",
      "id" : 47880480
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169481242247577600",
  "text" : "RT @LuckyFridge: @whitehouse #40dollars is gas for a week to and from work and school",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169480923346255873",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is gas for a week to and from work and school",
    "id" : 169480923346255873,
    "created_at" : "2012-02-14 17:59:35 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Rudy Portillo",
      "screen_name" : "LuckyFridge",
      "protected" : false,
      "id_str" : "47880480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766451057257873408\/2H6LDQu3_normal.jpg",
      "id" : 47880480,
      "verified" : false
    }
  },
  "id" : 169481242247577600,
  "created_at" : "2012-02-14 18:00:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Quinn",
      "screen_name" : "Quinion",
      "indices" : [ 3, 11 ],
      "id_str" : "6239752",
      "id" : 6239752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169481169900019715",
  "text" : "RT @Quinion: #40dollars let's me go on an extra date with my wonderful girlfriend. Happy Valentines day!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169452149472903168",
    "text" : "#40dollars let's me go on an extra date with my wonderful girlfriend. Happy Valentines day!",
    "id" : 169452149472903168,
    "created_at" : "2012-02-14 16:05:15 +0000",
    "user" : {
      "name" : "Alex Quinn",
      "screen_name" : "Quinion",
      "protected" : false,
      "id_str" : "6239752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000587921493\/dbc8c23918903905892ece9fb1d5ed93_normal.jpeg",
      "id" : 6239752,
      "verified" : false
    }
  },
  "id" : 169481169900019715,
  "created_at" : "2012-02-14 18:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Conover",
      "screen_name" : "michael_conover",
      "indices" : [ 0, 16 ],
      "id_str" : "379005746",
      "id" : 379005746
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/wODcKgLq",
      "expanded_url" : "http:\/\/sfy.co\/ZVu",
      "display_url" : "sfy.co\/ZVu"
    } ]
  },
  "geo" : { },
  "id_str" : "169469994999095299",
  "in_reply_to_user_id" : 379005746,
  "text" : "@michael_conover Thanks for making your voice heard & sharing what #40dollars means to you. Let's keep it going: http:\/\/t.co\/wODcKgLq",
  "id" : 169469994999095299,
  "created_at" : "2012-02-14 17:16:10 +0000",
  "in_reply_to_screen_name" : "michael_conover",
  "in_reply_to_user_id_str" : "379005746",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Harris",
      "screen_name" : "Isadelia530",
      "indices" : [ 0, 12 ],
      "id_str" : "214340933",
      "id" : 214340933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/wODcKgLq",
      "expanded_url" : "http:\/\/sfy.co\/ZVu",
      "display_url" : "sfy.co\/ZVu"
    } ]
  },
  "geo" : { },
  "id_str" : "169469995024265216",
  "in_reply_to_user_id" : 214340933,
  "text" : "@Isadelia530 Thanks for making your voice heard & sharing what #40dollars means to you. Let's keep it going: http:\/\/t.co\/wODcKgLq",
  "id" : 169469995024265216,
  "created_at" : "2012-02-14 17:16:10 +0000",
  "in_reply_to_screen_name" : "Isadelia530",
  "in_reply_to_user_id_str" : "214340933",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Purpose With a Past",
      "screen_name" : "PurposeWithPast",
      "indices" : [ 0, 16 ],
      "id_str" : "198391819",
      "id" : 198391819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/wODcKgLq",
      "expanded_url" : "http:\/\/sfy.co\/ZVu",
      "display_url" : "sfy.co\/ZVu"
    } ]
  },
  "geo" : { },
  "id_str" : "169469995129126912",
  "in_reply_to_user_id" : 198391819,
  "text" : "@PurposeWithPast Thanks for making your voice heard & sharing what #40dollars means to you. Let's keep it going: http:\/\/t.co\/wODcKgLq",
  "id" : 169469995129126912,
  "created_at" : "2012-02-14 17:16:10 +0000",
  "in_reply_to_screen_name" : "PurposeWithPast",
  "in_reply_to_user_id_str" : "198391819",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Lisa",
      "screen_name" : "k0828",
      "indices" : [ 0, 6 ],
      "id_str" : "53438432",
      "id" : 53438432
    }, {
      "name" : "Joey",
      "screen_name" : "awakndreamng",
      "indices" : [ 7, 20 ],
      "id_str" : "23354352",
      "id" : 23354352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/wODcKgLq",
      "expanded_url" : "http:\/\/sfy.co\/ZVu",
      "display_url" : "sfy.co\/ZVu"
    } ]
  },
  "geo" : { },
  "id_str" : "169469995250749440",
  "in_reply_to_user_id" : 53438432,
  "text" : "@k0828 @awakndreamng Thanks for making your voice heard & sharing what #40dollars means to you. Let's keep it going: http:\/\/t.co\/wODcKgLq",
  "id" : 169469995250749440,
  "created_at" : "2012-02-14 17:16:10 +0000",
  "in_reply_to_screen_name" : "k0828",
  "in_reply_to_user_id_str" : "53438432",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori JS",
      "screen_name" : "NcrediBelle",
      "indices" : [ 0, 12 ],
      "id_str" : "260365185",
      "id" : 260365185
    }, {
      "name" : "Mel Montanez",
      "screen_name" : "melmo1123",
      "indices" : [ 13, 23 ],
      "id_str" : "50254880",
      "id" : 50254880
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/wODcKgLq",
      "expanded_url" : "http:\/\/sfy.co\/ZVu",
      "display_url" : "sfy.co\/ZVu"
    } ]
  },
  "geo" : { },
  "id_str" : "169469996102197248",
  "in_reply_to_user_id" : 260365185,
  "text" : "@NcrediBelle @melmo1123 Thanks for making your voice heard & sharing what #40dollars means to you. Let's keep it going: http:\/\/t.co\/wODcKgLq",
  "id" : 169469996102197248,
  "created_at" : "2012-02-14 17:16:10 +0000",
  "in_reply_to_screen_name" : "NcrediBelle",
  "in_reply_to_user_id_str" : "260365185",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse McElwain",
      "screen_name" : "theMachanic",
      "indices" : [ 3, 15 ],
      "id_str" : "220717700",
      "id" : 220717700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169468156333666304",
  "text" : "RT @theMachanic: #40dollars doesn't mean that much to me, though it does to millions, and THAT means a lot to me!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169467142113210369",
    "text" : "#40dollars doesn't mean that much to me, though it does to millions, and THAT means a lot to me!",
    "id" : 169467142113210369,
    "created_at" : "2012-02-14 17:04:49 +0000",
    "user" : {
      "name" : "Jesse McElwain",
      "screen_name" : "theMachanic",
      "protected" : false,
      "id_str" : "220717700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658704951477014528\/wFW4DyL4_normal.jpg",
      "id" : 220717700,
      "verified" : false
    }
  },
  "id" : 169468156333666304,
  "created_at" : "2012-02-14 17:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quintetta S",
      "screen_name" : "TruQutieQ",
      "indices" : [ 3, 13 ],
      "id_str" : "67511770",
      "id" : 67511770
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 15, 27 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169462099024683009",
  "text" : "RT @TruQutieQ: @BarackObama #40dollars a check is gas to keep getting to work, money for groceries and lunch for my son. School shoes, u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "169458415058436096",
    "geo" : { },
    "id_str" : "169461572836659202",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama #40dollars a check is gas to keep getting to work, money for groceries and lunch for my son. School shoes, uniforms, EVERYTHING",
    "id" : 169461572836659202,
    "in_reply_to_status_id" : 169458415058436096,
    "created_at" : "2012-02-14 16:42:42 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Quintetta S",
      "screen_name" : "TruQutieQ",
      "protected" : false,
      "id_str" : "67511770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000174140170\/696592bd38b3b3098303982d04281468_normal.jpeg",
      "id" : 67511770,
      "verified" : false
    }
  },
  "id" : 169462099024683009,
  "created_at" : "2012-02-14 16:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "40dollars",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/RQv8BOFn",
      "expanded_url" : "http:\/\/youtu.be\/V72hLwHcRd0",
      "display_url" : "youtu.be\/V72hLwHcRd0"
    } ]
  },
  "geo" : { },
  "id_str" : "169454792521957376",
  "text" : "Why is #40dollars trending? Watch: http:\/\/t.co\/RQv8BOFn & tell us what #40dollars means to you.",
  "id" : 169454792521957376,
  "created_at" : "2012-02-14 16:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca R B",
      "screen_name" : "QueenBianca",
      "indices" : [ 3, 15 ],
      "id_str" : "524289160",
      "id" : 524289160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169452480365727744",
  "text" : "RT @QueenBianca: #40dollars less per paycheck is gas for my car, food on my table and a roof over my head. Come on Congress, help me out!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169451962654404608",
    "text" : "#40dollars less per paycheck is gas for my car, food on my table and a roof over my head. Come on Congress, help me out!",
    "id" : 169451962654404608,
    "created_at" : "2012-02-14 16:04:30 +0000",
    "user" : {
      "name" : "Bianca L.",
      "screen_name" : "MochaCheeks",
      "protected" : false,
      "id_str" : "41748917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572820570687057920\/u871uqgX_normal.jpeg",
      "id" : 41748917,
      "verified" : false
    }
  },
  "id" : 169452480365727744,
  "created_at" : "2012-02-14 16:06:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scarebaby",
      "screen_name" : "scarebaby",
      "indices" : [ 3, 13 ],
      "id_str" : "21025406",
      "id" : 21025406
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169452223737245696",
  "text" : "RT @scarebaby: $40 a month means I can pay my internet bill and keep my tiny small business alive.  #40dollars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169451421505306624",
    "text" : "$40 a month means I can pay my internet bill and keep my tiny small business alive.  #40dollars",
    "id" : 169451421505306624,
    "created_at" : "2012-02-14 16:02:21 +0000",
    "user" : {
      "name" : "Scarebaby",
      "screen_name" : "scarebaby",
      "protected" : false,
      "id_str" : "21025406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3414460205\/659d8fbae4c37ec4918e331d1b0f4b1a_normal.jpeg",
      "id" : 21025406,
      "verified" : false
    }
  },
  "id" : 169452223737245696,
  "created_at" : "2012-02-14 16:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169451578540044289",
  "text" : "\"I\u2019m asking the American people to keep their stories coming. Tell us what $40 means to you...use the hashtag #40dollars\u201D -President Obama",
  "id" : 169451578540044289,
  "created_at" : "2012-02-14 16:02:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169450377798893568",
  "text" : "RT @WHLive: Obama: Congress needs to extend that tax cut \u2013 along w\/ a vital insurance lifeline for folks who lost their jobs to the rece ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169450335822295040",
    "text" : "Obama: Congress needs to extend that tax cut \u2013 along w\/ a vital insurance lifeline for folks who lost their jobs to the recession #40dollars",
    "id" : 169450335822295040,
    "created_at" : "2012-02-14 15:58:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 169450377798893568,
  "created_at" : "2012-02-14 15:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 132, 139 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "169449387368521728",
  "text" : "Now: Obama speaks on extending the payroll tax cut w\/ folks that shared their #40dollars story. Watch: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 169449387368521728,
  "created_at" : "2012-02-14 15:54:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sloane Yerger",
      "screen_name" : "SloaneYerger",
      "indices" : [ 3, 16 ],
      "id_str" : "313466228",
      "id" : 313466228
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169436712936800256",
  "text" : "RT @SloaneYerger: @whitehouse #40dollars is money to go into my college savings. An education so I can have a good job in the future.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169435810255486976",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars is money to go into my college savings. An education so I can have a good job in the future.",
    "id" : 169435810255486976,
    "created_at" : "2012-02-14 15:00:19 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Sloane Yerger",
      "screen_name" : "SloaneYerger",
      "protected" : false,
      "id_str" : "313466228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719031318877569024\/i_H5sAKO_normal.jpg",
      "id" : 313466228,
      "verified" : false
    }
  },
  "id" : 169436712936800256,
  "created_at" : "2012-02-14 15:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Purpose With a Past",
      "screen_name" : "PurposeWithPast",
      "indices" : [ 3, 19 ],
      "id_str" : "198391819",
      "id" : 198391819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169432929850757121",
  "text" : "RT @PurposeWithPast: #40dollars is lunch for my daughter. Will get my husband back and forth to work for a week. Is groceries, medicines ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169432515831013377",
    "text" : "#40dollars is lunch for my daughter. Will get my husband back and forth to work for a week. Is groceries, medicines, necessities.",
    "id" : 169432515831013377,
    "created_at" : "2012-02-14 14:47:14 +0000",
    "user" : {
      "name" : "Purpose With a Past",
      "screen_name" : "PurposeWithPast",
      "protected" : false,
      "id_str" : "198391819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1137325014\/cab_normal.jpg",
      "id" : 198391819,
      "verified" : false
    }
  },
  "id" : 169432929850757121,
  "created_at" : "2012-02-14 14:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey",
      "screen_name" : "awakndreamng",
      "indices" : [ 3, 16 ],
      "id_str" : "23354352",
      "id" : 23354352
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169430791875600385",
  "text" : "RT @awakndreamng: @whitehouse #40dollars a paycheck is the difference between me working one job or two to pay my bills every month.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169430559188205570",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars a paycheck is the difference between me working one job or two to pay my bills every month.",
    "id" : 169430559188205570,
    "created_at" : "2012-02-14 14:39:27 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Joey",
      "screen_name" : "awakndreamng",
      "protected" : false,
      "id_str" : "23354352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744914576525901824\/BcS148ns_normal.jpg",
      "id" : 23354352,
      "verified" : false
    }
  },
  "id" : 169430791875600385,
  "created_at" : "2012-02-14 14:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Strang",
      "screen_name" : "Carol7658",
      "indices" : [ 3, 13 ],
      "id_str" : "187663896",
      "id" : 187663896
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169393487878422528",
  "text" : "RT @Carol7658: @whitehouse since my health care costs doubled this year alot. Every dollar counts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "169385560664842241",
    "geo" : { },
    "id_str" : "169393126249738240",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse since my health care costs doubled this year alot. Every dollar counts.",
    "id" : 169393126249738240,
    "in_reply_to_status_id" : 169385560664842241,
    "created_at" : "2012-02-14 12:10:43 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Carol Strang",
      "screen_name" : "Carol7658",
      "protected" : false,
      "id_str" : "187663896",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
      "id" : 187663896,
      "verified" : false
    }
  },
  "id" : 169393487878422528,
  "created_at" : "2012-02-14 12:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Conover",
      "screen_name" : "michael_conover",
      "indices" : [ 3, 19 ],
      "id_str" : "379005746",
      "id" : 379005746
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 57, 68 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169393130012028928",
  "text" : "RT @michael_conover: Not Affording some student loans. \n\u201C@whitehouse: What would #40dollars less a paycheck mean to you? http:\/\/t.co\/vVp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 36, 47 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/vVpoSxvc",
        "expanded_url" : "http:\/\/youtu.be\/V72hLwHcRd0",
        "display_url" : "youtu.be\/V72hLwHcRd0"
      } ]
    },
    "geo" : { },
    "id_str" : "169390516717359104",
    "text" : "Not Affording some student loans. \n\u201C@whitehouse: What would #40dollars less a paycheck mean to you? http:\/\/t.co\/vVpoSxvc\u201D",
    "id" : 169390516717359104,
    "created_at" : "2012-02-14 12:00:20 +0000",
    "user" : {
      "name" : "Mike Conover",
      "screen_name" : "michael_conover",
      "protected" : false,
      "id_str" : "379005746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766339173167009792\/pryzrQN6_normal.jpg",
      "id" : 379005746,
      "verified" : false
    }
  },
  "id" : 169393130012028928,
  "created_at" : "2012-02-14 12:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Harris",
      "screen_name" : "Isadelia530",
      "indices" : [ 3, 15 ],
      "id_str" : "214340933",
      "id" : 214340933
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169393050295083010",
  "text" : "RT @Isadelia530: @whitehouse #40dollars less a paycheck would mean fewer fresh fruits and vegetables when grocery shopping. Eating healt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169391967590035456",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #40dollars less a paycheck would mean fewer fresh fruits and vegetables when grocery shopping. Eating healthy is expensive!",
    "id" : 169391967590035456,
    "created_at" : "2012-02-14 12:06:06 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Stephanie Harris",
      "screen_name" : "Isadelia530",
      "protected" : false,
      "id_str" : "214340933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725783943509737472\/yOgbXmA1_normal.jpg",
      "id" : 214340933,
      "verified" : false
    }
  },
  "id" : 169393050295083010,
  "created_at" : "2012-02-14 12:10:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/RQv8BOFn",
      "expanded_url" : "http:\/\/youtu.be\/V72hLwHcRd0",
      "display_url" : "youtu.be\/V72hLwHcRd0"
    } ]
  },
  "geo" : { },
  "id_str" : "169385560664842241",
  "text" : "What would #40dollars less a paycheck mean to you? http:\/\/t.co\/RQv8BOFn",
  "id" : 169385560664842241,
  "created_at" : "2012-02-14 11:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/Dx6VAUNm",
      "expanded_url" : "http:\/\/1.usa.gov\/AddyGb",
      "display_url" : "1.usa.gov\/AddyGb"
    } ]
  },
  "geo" : { },
  "id_str" : "169231720548274176",
  "text" : "RT @petesouza: Photo of the day: nice light today in the Oval Office  http:\/\/t.co\/Dx6VAUNm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/Dx6VAUNm",
        "expanded_url" : "http:\/\/1.usa.gov\/AddyGb",
        "display_url" : "1.usa.gov\/AddyGb"
      } ]
    },
    "geo" : { },
    "id_str" : "169213959692488704",
    "text" : "Photo of the day: nice light today in the Oval Office  http:\/\/t.co\/Dx6VAUNm",
    "id" : 169213959692488704,
    "created_at" : "2012-02-14 00:18:46 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 169231720548274176,
  "created_at" : "2012-02-14 01:29:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "2013Budget",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/2rHgWMot",
      "expanded_url" : "http:\/\/sfy.co\/ZQ2",
      "display_url" : "sfy.co\/ZQ2"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/2NdtHJo5",
      "expanded_url" : "http:\/\/www.slideshare.net\/whitehouse\/the-presidents-budget-for-fiscal-year-2013",
      "display_url" : "slideshare.net\/whitehouse\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169227110605533184",
  "text" : "Missed today's #WHChat on the President's #2013Budget? Full Q&A here: http:\/\/t.co\/2rHgWMot Full budget here: http:\/\/t.co\/2NdtHJo5",
  "id" : 169227110605533184,
  "created_at" : "2012-02-14 01:11:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/169205321414344705\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/H7KmdRQ2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlkjV-WCAAAsjEs.jpg",
      "id_str" : "169205321422733312",
      "id" : 169205321422733312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlkjV-WCAAAsjEs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/H7KmdRQ2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/mCeqOS9O",
      "expanded_url" : "http:\/\/wh.gov\/0mT",
      "display_url" : "wh.gov\/0mT"
    } ]
  },
  "geo" : { },
  "id_str" : "169205321414344705",
  "text" : "By the numbers: 2 million workers:  http:\/\/t.co\/mCeqOS9O The President announces the Community College to Career Fund: http:\/\/t.co\/H7KmdRQ2",
  "id" : 169205321414344705,
  "created_at" : "2012-02-13 23:44:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "\uC7A5\uB3D9\uC6B0 | RP",
      "screen_name" : "jangdino",
      "indices" : [ 15, 24 ],
      "id_str" : "3300870837",
      "id" : 3300870837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169194927786426368",
  "text" : "RT @OMBPress: .@JanGDino: yes #2013Budget invests in clean energy goal = double share of clean energy sources by 2035 http:\/\/t.co\/yzBj3N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\uC7A5\uB3D9\uC6B0 | RP",
        "screen_name" : "jangdino",
        "indices" : [ 1, 10 ],
        "id_str" : "3300870837",
        "id" : 3300870837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2013Budget",
        "indices" : [ 16, 27 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/yzBj3NN5",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/omb\/factsheet\/creating-the-clean-energy-of-tomorrow-and-protecting-the-environment",
        "display_url" : "whitehouse.gov\/omb\/factsheet\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169194720566845441",
    "text" : ".@JanGDino: yes #2013Budget invests in clean energy goal = double share of clean energy sources by 2035 http:\/\/t.co\/yzBj3NN5 #WHChat",
    "id" : 169194720566845441,
    "created_at" : "2012-02-13 23:02:19 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 169194927786426368,
  "created_at" : "2012-02-13 23:03:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Coach Chris",
      "screen_name" : "CoachChris_BC",
      "indices" : [ 15, 29 ],
      "id_str" : "457671982",
      "id" : 457671982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169193743222702080",
  "text" : "RT @ombpress: .@CoachChris_BC: #2013Budget = $50B upfront & $476B over 6 yrs for roads rails runways to rebuild US #WHChat",
  "id" : 169193743222702080,
  "created_at" : "2012-02-13 22:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Coach Chris",
      "screen_name" : "CoachChris_BC",
      "indices" : [ 15, 29 ],
      "id_str" : "457671982",
      "id" : 457671982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/CRXqCiVS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/omb\/factsheet\/an-economy-built-to-last-and-a-21st-century-infrastructure",
      "display_url" : "whitehouse.gov\/omb\/factsheet\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169192438651551745",
  "text" : "RT @OMBPress: .@CoachChris_BC: #2013Budget = $50B upfront & $476B over 6 yrs for roads rails runways to rebuild US http:\/\/t.co\/CRXqCiVS  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coach Chris",
        "screen_name" : "CoachChris_BC",
        "indices" : [ 1, 15 ],
        "id_str" : "457671982",
        "id" : 457671982
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2013Budget",
        "indices" : [ 17, 28 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/CRXqCiVS",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/omb\/factsheet\/an-economy-built-to-last-and-a-21st-century-infrastructure",
        "display_url" : "whitehouse.gov\/omb\/factsheet\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169192365112832000",
    "text" : ".@CoachChris_BC: #2013Budget = $50B upfront & $476B over 6 yrs for roads rails runways to rebuild US http:\/\/t.co\/CRXqCiVS #WHChat",
    "id" : 169192365112832000,
    "created_at" : "2012-02-13 22:52:57 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 169192438651551745,
  "created_at" : "2012-02-13 22:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 112, 123 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169187678208798721",
  "text" : "RT @OMBPress: Hi everyone - this is Heather Higginbottom - ready to answer your questions about the President's #2013Budget. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2013Budget",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169187242135400448",
    "text" : "Hi everyone - this is Heather Higginbottom - ready to answer your questions about the President's #2013Budget. #WHChat",
    "id" : 169187242135400448,
    "created_at" : "2012-02-13 22:32:36 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 169187678208798721,
  "created_at" : "2012-02-13 22:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/BWQAsLq3",
      "expanded_url" : "http:\/\/ow.ly\/92RNh",
      "display_url" : "ow.ly\/92RNh"
    } ]
  },
  "geo" : { },
  "id_str" : "169160022197149696",
  "text" : "Check out an overview of the President's #2013Budget: http:\/\/t.co\/BWQAsLq3 Have Qs? Ask now: #WHChat & join Office Hours live @ 5:30ET",
  "id" : 169160022197149696,
  "created_at" : "2012-02-13 20:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 18, 27 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169159442225569792",
  "text" : "RT @jesseclee44: .@presssec on Senate bills giving employers right to deny women access to preventive services including contraception:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169154172179062784",
    "text" : ".@presssec on Senate bills giving employers right to deny women access to preventive services including contraception: \"dangerous and wrong\"",
    "id" : 169154172179062784,
    "created_at" : "2012-02-13 20:21:12 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 169159442225569792,
  "created_at" : "2012-02-13 20:42:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "169131861942079490",
  "text" : "Happening now: President Obama Awards the 2011 National Medal of Arts & National Humanities Medal. Watch: http:\/\/t.co\/QDIpMRKE",
  "id" : 169131861942079490,
  "created_at" : "2012-02-13 18:52:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/2NdtHJo5",
      "expanded_url" : "http:\/\/www.slideshare.net\/whitehouse\/the-presidents-budget-for-fiscal-year-2013",
      "display_url" : "slideshare.net\/whitehouse\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169131483431313409",
  "text" : "\"We've got to do everything in our power to keep this recovery on track\" -President Obama on his #2013Budget: http:\/\/t.co\/2NdtHJo5",
  "id" : 169131483431313409,
  "created_at" : "2012-02-13 18:51:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DOE Press Staff",
      "screen_name" : "EnergyPressSec",
      "indices" : [ 3, 18 ],
      "id_str" : "413223602",
      "id" : 413223602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 46, 53 ]
    }, {
      "text" : "Budget",
      "indices" : [ 54, 61 ]
    }, {
      "text" : "CleanEnergy",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169115478290206720",
  "text" : "RT @EnergyPressSec: Sec Chu: President\u2019s 2013 #Energy #Budget makes critical investments in innovation, #CleanEnergy, and #NationalSecur ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Energy",
        "indices" : [ 26, 33 ]
      }, {
        "text" : "Budget",
        "indices" : [ 34, 41 ]
      }, {
        "text" : "CleanEnergy",
        "indices" : [ 84, 96 ]
      }, {
        "text" : "NationalSecurity",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/lf0KmvyH",
        "expanded_url" : "http:\/\/energy.gov\/articles\/chu-president-s-2013-energy-budget-makes-critical-investments-innovation-clean-energy-and",
        "display_url" : "energy.gov\/articles\/chu-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169108961402957825",
    "text" : "Sec Chu: President\u2019s 2013 #Energy #Budget makes critical investments in innovation, #CleanEnergy, and #NationalSecurity http:\/\/t.co\/lf0KmvyH",
    "id" : 169108961402957825,
    "created_at" : "2012-02-13 17:21:32 +0000",
    "user" : {
      "name" : "DOE Press Staff",
      "screen_name" : "EnergyPressSec",
      "protected" : false,
      "id_str" : "413223602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1640557206\/New_DOE_Seal_Color_normal.png",
      "id" : 413223602,
      "verified" : true
    }
  },
  "id" : 169115478290206720,
  "created_at" : "2012-02-13 17:47:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169096466139316225",
  "text" : "RT @WHLive: Obama: Warren Buffett pays a lower tax rate than his secretary...Is that fair? Does that make any sense?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169096423575523328",
    "text" : "Obama: Warren Buffett pays a lower tax rate than his secretary...Is that fair? Does that make any sense?",
    "id" : 169096423575523328,
    "created_at" : "2012-02-13 16:31:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 169096466139316225,
  "created_at" : "2012-02-13 16:31:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169094690619146242",
  "text" : "RT @WHLive: Obama: Higher #education can\u2019t be a luxury \u2013 it\u2019s an economic imperative that every family in America should be able to afford.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 14, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169094618737147904",
    "text" : "Obama: Higher #education can\u2019t be a luxury \u2013 it\u2019s an economic imperative that every family in America should be able to afford.",
    "id" : 169094618737147904,
    "created_at" : "2012-02-13 16:24:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 169094690619146242,
  "created_at" : "2012-02-13 16:24:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/dfhGiWbU",
      "expanded_url" : "http:\/\/ht.ly\/92tYe",
      "display_url" : "ht.ly\/92tYe"
    } ]
  },
  "geo" : { },
  "id_str" : "169094673900634113",
  "text" : "RT @OMBPress: Introducing the President's 2013 Budget: http:\/\/t.co\/dfhGiWbU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/dfhGiWbU",
        "expanded_url" : "http:\/\/ht.ly\/92tYe",
        "display_url" : "ht.ly\/92tYe"
      } ]
    },
    "geo" : { },
    "id_str" : "169094638148390914",
    "text" : "Introducing the President's 2013 Budget: http:\/\/t.co\/dfhGiWbU",
    "id" : 169094638148390914,
    "created_at" : "2012-02-13 16:24:38 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 169094673900634113,
  "created_at" : "2012-02-13 16:24:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169093230904881152",
  "text" : "RT @WHLive: Obama: By reducing our deficit in the long-term, we\u2019ll be able to invest in the things that will help our economy grow right ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169093194406039552",
    "text" : "Obama: By reducing our deficit in the long-term, we\u2019ll be able to invest in the things that will help our economy grow right now.",
    "id" : 169093194406039552,
    "created_at" : "2012-02-13 16:18:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 169093230904881152,
  "created_at" : "2012-02-13 16:19:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "169090887958278145",
  "text" : "Happening now: President Obama speaks on the FY #2013Budget @ Northern Virginia Community College. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 169090887958278145,
  "created_at" : "2012-02-13 16:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 122, 130 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169090096946089985",
  "text" : "RT @pfeiffer44: In the budget, POTUS proposes taxing dividends for the wealthiest at the same rate as ordinary income Via @nytimes http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 106, 114 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/232bsoBu",
        "expanded_url" : "http:\/\/nyti.ms\/wDJ9cg",
        "display_url" : "nyti.ms\/wDJ9cg"
      } ]
    },
    "geo" : { },
    "id_str" : "169088905952501760",
    "text" : "In the budget, POTUS proposes taxing dividends for the wealthiest at the same rate as ordinary income Via @nytimes http:\/\/t.co\/232bsoBu",
    "id" : 169088905952501760,
    "created_at" : "2012-02-13 16:01:51 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 169090096946089985,
  "created_at" : "2012-02-13 16:06:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2013Budget",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169076065732530176",
  "text" : "WH Office Hours: OMB Deputy Director Heather Higginbottom answers your ?s on the President's #2013Budget today @ 5:30ET. Ask now: #WHChat",
  "id" : 169076065732530176,
  "created_at" : "2012-02-13 15:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/hZ41pI1V",
      "expanded_url" : "http:\/\/ow.ly\/90KAh",
      "display_url" : "ow.ly\/90KAh"
    } ]
  },
  "geo" : { },
  "id_str" : "168353406048673792",
  "text" : "WEEKLY ADDRESS: Obama urges Congress to extend the payroll tax cut to prevent a tax hike on 160 million Americans: http:\/\/t.co\/hZ41pI1V",
  "id" : 168353406048673792,
  "created_at" : "2012-02-11 15:19:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168129748126535680",
  "text" : "RT @letsmove: To celebrate the 2nd anniversary of #LetsMove, First Lady Michelle Obama is hitting the road. Check out the gallery: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 36, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/9PoBTINu",
        "expanded_url" : "http:\/\/ow.ly\/90pTg",
        "display_url" : "ow.ly\/90pTg"
      } ]
    },
    "geo" : { },
    "id_str" : "168129685220376576",
    "text" : "To celebrate the 2nd anniversary of #LetsMove, First Lady Michelle Obama is hitting the road. Check out the gallery: http:\/\/t.co\/9PoBTINu",
    "id" : 168129685220376576,
    "created_at" : "2012-02-11 00:30:15 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 168129748126535680,
  "created_at" : "2012-02-11 00:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 4, 15 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 16, 24 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/5hHXggI6",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse",
      "display_url" : "youtube.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "168115359805739009",
  "text" : "The @whitehouse @youtube channel has a new look! Check it out & subscribe for updates with the latest WH videos: http:\/\/t.co\/5hHXggI6",
  "id" : 168115359805739009,
  "created_at" : "2012-02-10 23:33:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 1, 12 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstflickrphoto",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/GpR2gRGD",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/3483994905\/in\/photostream",
      "display_url" : "flickr.com\/photos\/whiteho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168092363896520704",
  "text" : ".@whitehouse's #firstflickrphoto: President Obama photographed by daughter Malia at the WH before Inaugural Ball: http:\/\/t.co\/GpR2gRGD",
  "id" : 168092363896520704,
  "created_at" : "2012-02-10 22:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 38, 44 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168075204843671553",
  "text" : "RT @letsmove: We're on our way to the @webMD town hall where First Lady Michelle Obama will be talking about raising healthy kids #letsm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WebMD",
        "screen_name" : "WebMD",
        "indices" : [ 24, 30 ],
        "id_str" : "25928253",
        "id" : 25928253
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "letsmove",
        "indices" : [ 116, 125 ]
      }, {
        "text" : "webmdTH",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168071466091417600",
    "text" : "We're on our way to the @webMD town hall where First Lady Michelle Obama will be talking about raising healthy kids #letsmove #webmdTH",
    "id" : 168071466091417600,
    "created_at" : "2012-02-10 20:38:54 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 168075204843671553,
  "created_at" : "2012-02-10 20:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/M8ceuDhd",
      "expanded_url" : "http:\/\/youtu.be\/7w3sTfiNis0",
      "display_url" : "youtu.be\/7w3sTfiNis0"
    } ]
  },
  "geo" : { },
  "id_str" : "168069920326811649",
  "text" : "Meet the 2012 #WHScienceFair participants: http:\/\/t.co\/M8ceuDhd",
  "id" : 168069920326811649,
  "created_at" : "2012-02-10 20:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/kfIkncDQ",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/post-partisan\/post\/dionne-obama-contraception-compromise-women-white-house-does-the-right-thing\/2012\/02\/10\/gIQAcCWK4Q_blog.html",
      "display_url" : "washingtonpost.com\/blogs\/post-par\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168045286374129664",
  "text" : "RT @jearnest44: EJ Dionne: Obama does right thing on contraception  http:\/\/t.co\/kfIkncDQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/kfIkncDQ",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/post-partisan\/post\/dionne-obama-contraception-compromise-women-white-house-does-the-right-thing\/2012\/02\/10\/gIQAcCWK4Q_blog.html",
        "display_url" : "washingtonpost.com\/blogs\/post-par\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "168044910019215360",
    "text" : "EJ Dionne: Obama does right thing on contraception  http:\/\/t.co\/kfIkncDQ",
    "id" : 168044910019215360,
    "created_at" : "2012-02-10 18:53:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 168045286374129664,
  "created_at" : "2012-02-10 18:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/NgStBTGq",
      "expanded_url" : "http:\/\/ow.ly\/9026G",
      "display_url" : "ow.ly\/9026G"
    } ]
  },
  "geo" : { },
  "id_str" : "168043448845348864",
  "text" : "\"No woman\u2019s health should depend on who she is or where she works or how much money she makes\" -President Obama http:\/\/t.co\/NgStBTGq",
  "id" : 168043448845348864,
  "created_at" : "2012-02-10 18:47:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168021914495885312",
  "text" : "RT @WHLive: Obama: Religious liberty will be protected, and a law that requires free preventive care will not discriminate against women.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168021866668228608",
    "text" : "Obama: Religious liberty will be protected, and a law that requires free preventive care will not discriminate against women.",
    "id" : 168021866668228608,
    "created_at" : "2012-02-10 17:21:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 168021914495885312,
  "created_at" : "2012-02-10 17:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168021036552556544",
  "text" : "RT @WHLive: \"Every woman should be in control of the decisions that affect her own health\" -President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168020970429349888",
    "text" : "\"Every woman should be in control of the decisions that affect her own health\" -President Obama",
    "id" : 168020970429349888,
    "created_at" : "2012-02-10 17:18:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 168021036552556544,
  "created_at" : "2012-02-10 17:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 123, 130 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "168020404030554113",
  "text" : "Happening now: The President delivers a statement on women's preventive services. Watch live: http:\/\/t.co\/QDIpMRKE Follow: @WHLive",
  "id" : 168020404030554113,
  "created_at" : "2012-02-10 17:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/rCah8SbX",
      "expanded_url" : "http:\/\/ow.ly\/8ZPSz",
      "display_url" : "ow.ly\/8ZPSz"
    } ]
  },
  "geo" : { },
  "id_str" : "168012281832157184",
  "text" : "Today, President Obama will announce a policy that accommodates religious liberty while protecting the health of women: http:\/\/t.co\/rCah8SbX",
  "id" : 168012281832157184,
  "created_at" : "2012-02-10 16:43:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/fz7TM27X",
      "expanded_url" : "http:\/\/youtu.be\/_zkDqefRuFY",
      "display_url" : "youtu.be\/_zkDqefRuFY"
    } ]
  },
  "geo" : { },
  "id_str" : "168006326763536384",
  "text" : "Today is Friday & that means West Wing Week day! Have a look behind-the-scenes this week: http:\/\/t.co\/fz7TM27X",
  "id" : 168006326763536384,
  "created_at" : "2012-02-10 16:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "167999168646889473",
  "text" : "RT @WHLive: Happening @ 12:15ET: President Obama delivers a statement in the Press Briefing Room. Watch live: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "167998693813927937",
    "text" : "Happening @ 12:15ET: President Obama delivers a statement in the Press Briefing Room. Watch live: http:\/\/t.co\/g5ih2w0F",
    "id" : 167998693813927937,
    "created_at" : "2012-02-10 15:49:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 167999168646889473,
  "created_at" : "2012-02-10 15:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/BhrCaknm",
      "expanded_url" : "http:\/\/ow.ly\/8YXtf",
      "display_url" : "ow.ly\/8YXtf"
    } ]
  },
  "geo" : { },
  "id_str" : "167754543910756352",
  "text" : "What do you want to know about waivers, flexibility & reforming No Child Left Behind? Here's everything: http:\/\/t.co\/BhrCaknm",
  "id" : 167754543910756352,
  "created_at" : "2012-02-09 23:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/167731525255835649\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/BsZ9ZQdh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlPm7v0CMAATBBo.jpg",
      "id_str" : "167731525264224256",
      "id" : 167731525264224256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlPm7v0CMAATBBo.jpg",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BsZ9ZQdh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/PSiHage7",
      "expanded_url" : "http:\/\/wh.gov\/0g4",
      "display_url" : "wh.gov\/0g4"
    } ]
  },
  "geo" : { },
  "id_str" : "167731525255835649",
  "text" : "From the Archives: Snowmageddon at the @WhiteHouse & Bo in the snow: http:\/\/t.co\/PSiHage7: http:\/\/t.co\/BsZ9ZQdh",
  "id" : 167731525255835649,
  "created_at" : "2012-02-09 22:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167714562450272257",
  "text" : "RT @letsmove: America's military again leads by example: new standards to bring more fruits, veggies & whole grains to 1100 dining facil ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "letsmove",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167711983800565760",
    "text" : "America's military again leads by example: new standards to bring more fruits, veggies & whole grains to 1100 dining facilities. #letsmove",
    "id" : 167711983800565760,
    "created_at" : "2012-02-09 20:50:27 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 167714562450272257,
  "created_at" : "2012-02-09 21:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/i8gQ6c1H",
      "expanded_url" : "http:\/\/ow.ly\/8YHZ1",
      "display_url" : "ow.ly\/8YHZ1"
    } ]
  },
  "geo" : { },
  "id_str" : "167698750364594176",
  "text" : "We Can\u2019t Wait: Obama Administration proposes a historic $156 million investment to combat Alzheimer's disease: http:\/\/t.co\/i8gQ6c1H",
  "id" : 167698750364594176,
  "created_at" : "2012-02-09 19:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCLB",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/dbONzHBt",
      "expanded_url" : "http:\/\/wh.gov\/\/live",
      "display_url" : "wh.gov\/\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "167683691433312256",
  "text" : "Happening now: President Obama speaks on providing state flexibility under No Child Left Behind #NCLB. Watch live: http:\/\/t.co\/dbONzHBt",
  "id" : 167683691433312256,
  "created_at" : "2012-02-09 18:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167680073799970819",
  "text" : "RT @jearnest44: Historic effort to stand up to banks and stand up for homeowners.  AP header, \"Obama: deal turns page on reckless era\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/qKnGK3Kd",
        "expanded_url" : "http:\/\/hosted.ap.org\/dynamic\/stories\/U\/US_MORTGAGE_SETTLEMENT_OBAMA?SITE=NCAGW&SECTION=HOME&TEMPLATE=DEFAULT",
        "display_url" : "hosted.ap.org\/dynamic\/storie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "167670206225842178",
    "text" : "Historic effort to stand up to banks and stand up for homeowners.  AP header, \"Obama: deal turns page on reckless era\" http:\/\/t.co\/qKnGK3Kd",
    "id" : 167670206225842178,
    "created_at" : "2012-02-09 18:04:26 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 167680073799970819,
  "created_at" : "2012-02-09 18:43:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/167668016639778817\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/oIBrmHwn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlOtLDxCIAEljwq.jpg",
      "id_str" : "167668016643973121",
      "id" : 167668016643973121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlOtLDxCIAEljwq.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/oIBrmHwn"
    } ],
    "hashtags" : [ {
      "text" : "letsmove",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167679465122570240",
  "text" : "RT @letsmove: Not your typical fruitcake! Check out the birthday cake Iowa created for #letsmove http:\/\/t.co\/oIBrmHwn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/167668016639778817\/photo\/1",
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/oIBrmHwn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AlOtLDxCIAEljwq.jpg",
        "id_str" : "167668016643973121",
        "id" : 167668016643973121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlOtLDxCIAEljwq.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/oIBrmHwn"
      } ],
      "hashtags" : [ {
        "text" : "letsmove",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167668016639778817",
    "text" : "Not your typical fruitcake! Check out the birthday cake Iowa created for #letsmove http:\/\/t.co\/oIBrmHwn",
    "id" : 167668016639778817,
    "created_at" : "2012-02-09 17:55:45 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 167679465122570240,
  "created_at" : "2012-02-09 18:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "167661207036235776",
  "text" : "Happening now: President Obama speaks on the housing settlement. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 167661207036235776,
  "created_at" : "2012-02-09 17:28:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "167627077405769728",
  "text" : "RT @whlive: Happening @ 12:15ET: President Obama delivers remarks on the housing settlement. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 167627077405769728,
  "created_at" : "2012-02-09 15:13:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 3, 9 ],
      "id_str" : "25928253",
      "id" : 25928253
    }, {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 12, 18 ],
      "id_str" : "25928253",
      "id" : 25928253
    }, {
      "name" : "Michelle Obama",
      "screen_name" : "MichelleObama",
      "indices" : [ 21, 35 ],
      "id_str" : "409486555",
      "id" : 409486555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webmdTH",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167339274335813632",
  "text" : "RT @WebMD: .@WebMD & @MichelleObama want  your ?'s on making healthy changes for your family.  Submit using #webmdTH  http:\/\/t.co\/EV0xgE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WebMD",
        "screen_name" : "WebMD",
        "indices" : [ 1, 7 ],
        "id_str" : "25928253",
        "id" : 25928253
      }, {
        "name" : "Michelle Obama",
        "screen_name" : "MichelleObama",
        "indices" : [ 10, 24 ],
        "id_str" : "409486555",
        "id" : 409486555
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webmdTH",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "letsmove",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/EV0xgE2D",
        "expanded_url" : "http:\/\/bit.ly\/yaGpnB",
        "display_url" : "bit.ly\/yaGpnB"
      } ]
    },
    "geo" : { },
    "id_str" : "167279154214080513",
    "text" : ".@WebMD & @MichelleObama want  your ?'s on making healthy changes for your family.  Submit using #webmdTH  http:\/\/t.co\/EV0xgE2D #letsmove",
    "id" : 167279154214080513,
    "created_at" : "2012-02-08 16:10:32 +0000",
    "user" : {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "protected" : false,
      "id_str" : "25928253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771386734760386562\/-cRW6ixT_normal.jpg",
      "id" : 25928253,
      "verified" : true
    }
  },
  "id" : 167339274335813632,
  "created_at" : "2012-02-08 20:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 113, 125 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167324612844195840",
  "text" : "RT @letsmove: Hula-hoop, dodgeball & a potato sack race? Who wins a fitness competition between the First Lady & @JimmyFallon? Watch: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jimmy fallon",
        "screen_name" : "jimmyfallon",
        "indices" : [ 99, 111 ],
        "id_str" : "15485441",
        "id" : 15485441
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/3aR6uClY",
        "expanded_url" : "http:\/\/ow.ly\/8WYRZ",
        "display_url" : "ow.ly\/8WYRZ"
      } ]
    },
    "geo" : { },
    "id_str" : "167298575045361664",
    "text" : "Hula-hoop, dodgeball & a potato sack race? Who wins a fitness competition between the First Lady & @JimmyFallon? Watch: http:\/\/t.co\/3aR6uClY",
    "id" : 167298575045361664,
    "created_at" : "2012-02-08 17:27:43 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 167324612844195840,
  "created_at" : "2012-02-08 19:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 73, 81 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "167259059895025665",
  "text" : "Have a Q on technology in global develpoment? Join us for a live chat w\/ @rajshah today at 11 am on http:\/\/t.co\/u95y7hhB. Ask using #WHChat.",
  "id" : 167259059895025665,
  "created_at" : "2012-02-08 14:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Zjb2kGsF",
      "expanded_url" : "http:\/\/youtu.be\/Reimvk8D2Ho",
      "display_url" : "youtu.be\/Reimvk8D2Ho"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/NiuHcSPc",
      "expanded_url" : "http:\/\/bit.ly\/xBFMeO",
      "display_url" : "bit.ly\/xBFMeO"
    } ]
  },
  "geo" : { },
  "id_str" : "167258581819867136",
  "text" : "RT @macon44: POTUS: \"Actually, I'm going to keep your card - Just in case.\" Watch: http:\/\/t.co\/Zjb2kGsF Make: http:\/\/t.co\/NiuHcSPc @doct ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 118, 127 ],
        "id_str" : "2729061",
        "id" : 2729061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "makerfaire",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/Zjb2kGsF",
        "expanded_url" : "http:\/\/youtu.be\/Reimvk8D2Ho",
        "display_url" : "youtu.be\/Reimvk8D2Ho"
      }, {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/NiuHcSPc",
        "expanded_url" : "http:\/\/bit.ly\/xBFMeO",
        "display_url" : "bit.ly\/xBFMeO"
      } ]
    },
    "geo" : { },
    "id_str" : "167253198363570177",
    "text" : "POTUS: \"Actually, I'm going to keep your card - Just in case.\" Watch: http:\/\/t.co\/Zjb2kGsF Make: http:\/\/t.co\/NiuHcSPc @doctorow #makerfaire",
    "id" : 167253198363570177,
    "created_at" : "2012-02-08 14:27:24 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 167258581819867136,
  "created_at" : "2012-02-08 14:48:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/dXk6bcN6",
      "expanded_url" : "http:\/\/youtu.be\/Reimvk8D2Ho",
      "display_url" : "youtu.be\/Reimvk8D2Ho"
    } ]
  },
  "geo" : { },
  "id_str" : "167027831107366912",
  "text" : "WATCH: President Obama launches marshmallow in the State Dining Room @ the #WHScienceFair: http:\/\/t.co\/dXk6bcN6",
  "id" : 167027831107366912,
  "created_at" : "2012-02-07 23:31:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 84, 98 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 99, 109 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 112, 127 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 19, 33 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167025616925896705",
  "text" : "RT @WHLive: Missed #WHScienceFair Office Hours? Check out the #WHChat with Bill Nye @TheScienceGuy @neiltyson & @whitehouseostp: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Nye",
        "screen_name" : "thescienceguy",
        "indices" : [ 72, 86 ],
        "id_str" : "3028904482",
        "id" : 3028904482
      }, {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 87, 97 ],
        "id_str" : "19725644",
        "id" : 19725644
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 100, 115 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 7, 21 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/pP2w0MQV",
        "expanded_url" : "http:\/\/sfy.co\/YQY",
        "display_url" : "sfy.co\/YQY"
      } ]
    },
    "geo" : { },
    "id_str" : "167025563876343809",
    "text" : "Missed #WHScienceFair Office Hours? Check out the #WHChat with Bill Nye @TheScienceGuy @neiltyson & @whitehouseostp: http:\/\/t.co\/pP2w0MQV",
    "id" : 167025563876343809,
    "created_at" : "2012-02-07 23:22:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 167025616925896705,
  "created_at" : "2012-02-07 23:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 29, 39 ],
      "id_str" : "321466257",
      "id" : 321466257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/167019841998438400\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/a7sxWGLi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlFfqVFCQAA9CJY.jpg",
      "id_str" : "167019842006827008",
      "id" : 167019842006827008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlFfqVFCQAA9CJY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a7sxWGLi"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/qOPidsnA",
      "expanded_url" : "http:\/\/wh.gov\/0qf",
      "display_url" : "wh.gov\/0qf"
    } ]
  },
  "geo" : { },
  "id_str" : "167019841998438400",
  "text" : "Photo: President Obama demos @Joey_Hudy's Extreme Marshmallow Cannon @ the #WHScienceFair http:\/\/t.co\/qOPidsnA http:\/\/t.co\/a7sxWGLi",
  "id" : 167019841998438400,
  "created_at" : "2012-02-07 23:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/WjoZPgV6",
      "expanded_url" : "http:\/\/ow.ly\/8VWAY",
      "display_url" : "ow.ly\/8VWAY"
    } ]
  },
  "geo" : { },
  "id_str" : "167011097969307648",
  "text" : "Valerie Jarrett, Senior Advisor to President Obama, commemorates National Black #HIV\/AIDS Awareness Day: http:\/\/t.co\/WjoZPgV6",
  "id" : 167011097969307648,
  "created_at" : "2012-02-07 22:25:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AIDS.gov",
      "screen_name" : "AIDSgov",
      "indices" : [ 3, 11 ],
      "id_str" : "15368404",
      "id" : 15368404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "NBHAAD",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/6iUPeiDx",
      "expanded_url" : "http:\/\/go.usa.gov\/QaC",
      "display_url" : "go.usa.gov\/QaC"
    } ]
  },
  "geo" : { },
  "id_str" : "167010454319792128",
  "text" : "RT @AIDSgov: Today is National Black HIV\/AIDS Awareness Day. Know your status. Find a nearby #HIV testing site http:\/\/t.co\/6iUPeiDx #NBHAAD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HIV",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "NBHAAD",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/6iUPeiDx",
        "expanded_url" : "http:\/\/go.usa.gov\/QaC",
        "display_url" : "go.usa.gov\/QaC"
      } ]
    },
    "geo" : { },
    "id_str" : "166870084315398145",
    "text" : "Today is National Black HIV\/AIDS Awareness Day. Know your status. Find a nearby #HIV testing site http:\/\/t.co\/6iUPeiDx #NBHAAD",
    "id" : 166870084315398145,
    "created_at" : "2012-02-07 13:05:03 +0000",
    "user" : {
      "name" : "AIDS.gov",
      "screen_name" : "AIDSgov",
      "protected" : false,
      "id_str" : "15368404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685838626563854337\/oPTossXw_normal.png",
      "id" : 15368404,
      "verified" : true
    }
  },
  "id" : 167010454319792128,
  "created_at" : "2012-02-07 22:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 42, 54 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/166998092380516352\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Q7bwoshU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlFL4VcCMAAGIYO.jpg",
      "id_str" : "166998092388904960",
      "id" : 166998092388904960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlFL4VcCMAAGIYO.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Q7bwoshU"
    } ],
    "hashtags" : [ {
      "text" : "FallonTonight",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166999148141346817",
  "text" : "RT @letsmove: Don't miss the First Lady & @JimmyFallon go head-to-head in a fitness challenge on #FallonTonight: http:\/\/t.co\/Q7bwoshU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jimmy fallon",
        "screen_name" : "jimmyfallon",
        "indices" : [ 28, 40 ],
        "id_str" : "15485441",
        "id" : 15485441
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/166998092380516352\/photo\/1",
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/Q7bwoshU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AlFL4VcCMAAGIYO.jpg",
        "id_str" : "166998092388904960",
        "id" : 166998092388904960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlFL4VcCMAAGIYO.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Q7bwoshU"
      } ],
      "hashtags" : [ {
        "text" : "FallonTonight",
        "indices" : [ 83, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166998092380516352",
    "text" : "Don't miss the First Lady & @JimmyFallon go head-to-head in a fitness challenge on #FallonTonight: http:\/\/t.co\/Q7bwoshU",
    "id" : 166998092380516352,
    "created_at" : "2012-02-07 21:33:43 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 166999148141346817,
  "created_at" : "2012-02-07 21:37:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 21, 35 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 38, 48 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/I3pC1IOf",
      "expanded_url" : "http:\/\/ow.ly\/i\/rSii",
      "display_url" : "ow.ly\/i\/rSii"
    } ]
  },
  "geo" : { },
  "id_str" : "166977923209900032",
  "text" : "RT @WHLive: Bill Nye @thescienceguy & @neiltyson still tweeting away during WH Office Hours: http:\/\/t.co\/I3pC1IOf #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Nye",
        "screen_name" : "thescienceguy",
        "indices" : [ 9, 23 ],
        "id_str" : "3028904482",
        "id" : 3028904482
      }, {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 26, 36 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 102, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/I3pC1IOf",
        "expanded_url" : "http:\/\/ow.ly\/i\/rSii",
        "display_url" : "ow.ly\/i\/rSii"
      } ]
    },
    "geo" : { },
    "id_str" : "166976606122946560",
    "text" : "Bill Nye @thescienceguy & @neiltyson still tweeting away during WH Office Hours: http:\/\/t.co\/I3pC1IOf #whchat",
    "id" : 166976606122946560,
    "created_at" : "2012-02-07 20:08:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 166977923209900032,
  "created_at" : "2012-02-07 20:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 9, 23 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 24, 34 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 50, 65 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/166970196354015232\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/fBdvGyc5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlEygkpCIAE-vCM.jpg",
      "id_str" : "166970196362403841",
      "id" : 166970196362403841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlEygkpCIAE-vCM.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fBdvGyc5"
    } ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 94, 108 ]
    }, {
      "text" : "AWESOME",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166970196354015232",
  "text" : "Bill Nye @TheScienceGuy @neiltyson & Tom Kalil of @whitehouseostp taking your Qs now! #WHChat #WHScienceFair #AWESOME http:\/\/t.co\/fBdvGyc5",
  "id" : 166970196354015232,
  "created_at" : "2012-02-07 19:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Bill Lancaster",
      "screen_name" : "Kraegarth",
      "indices" : [ 24, 34 ],
      "id_str" : "63588700",
      "id" : 63588700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166965759698939905",
  "text" : "RT @whitehouseostp: Hey @kraegarth, we need to celebrate science and math, recruit another excellent 100K teachers.  See http:\/\/t.co\/T7l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Lancaster",
        "screen_name" : "Kraegarth",
        "indices" : [ 4, 14 ],
        "id_str" : "63588700",
        "id" : 63588700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/T7lApxFy",
        "expanded_url" : "http:\/\/wh.gov\/stem",
        "display_url" : "wh.gov\/stem"
      } ]
    },
    "geo" : { },
    "id_str" : "166964777791401985",
    "text" : "Hey @kraegarth, we need to celebrate science and math, recruit another excellent 100K teachers.  See http:\/\/t.co\/T7lApxFy",
    "id" : 166964777791401985,
    "created_at" : "2012-02-07 19:21:19 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 166965759698939905,
  "created_at" : "2012-02-07 19:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "One Giant Leap Blog",
      "screen_name" : "LeapOfAwesome",
      "indices" : [ 23, 37 ],
      "id_str" : "219189217",
      "id" : 219189217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166965733304176640",
  "text" : "RT @TheScienceGuy: Hey @leapofawesome, right now, the key seems to be algebra. If we can do a better job teaching algebra, we could enga ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One Giant Leap Blog",
        "screen_name" : "LeapOfAwesome",
        "indices" : [ 4, 18 ],
        "id_str" : "219189217",
        "id" : 219189217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166964329718099969",
    "text" : "Hey @leapofawesome, right now, the key seems to be algebra. If we can do a better job teaching algebra, we could engage many more sci kids.",
    "id" : 166964329718099969,
    "created_at" : "2012-02-07 19:19:32 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 166965733304176640,
  "created_at" : "2012-02-07 19:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 24, 38 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 39, 49 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 65, 80 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 105, 119 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166961934778892288",
  "text" : "Happening now: Bill Nye @TheScienceGuy @neiltyson & Tom Kalil of @whitehouseostp answer your Qs on #STEM #WHScienceFair. Ask with #WHChat",
  "id" : 166961934778892288,
  "created_at" : "2012-02-07 19:10:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166961691685437442",
  "text" : "RT @TheScienceGuy: Hey, hey Bill Nye here. I'm sitting in The White House Office Digital Strategy. Got a question on Science Ed? Tweet i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 123, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166959586048344064",
    "text" : "Hey, hey Bill Nye here. I'm sitting in The White House Office Digital Strategy. Got a question on Science Ed? Tweet it in. #WHChat",
    "id" : 166959586048344064,
    "created_at" : "2012-02-07 19:00:41 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 166961691685437442,
  "created_at" : "2012-02-07 19:09:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 42, 56 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 57, 67 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 83, 98 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166950364044734464",
  "text" : "RT @WHLive: WH Office Hrs @ 2ET: Bill Nye @TheScienceGuy @neiltyson & Tom Kalil of @whitehouseostp answer your Qs on #STEM #WHScienceFai ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Nye",
        "screen_name" : "thescienceguy",
        "indices" : [ 30, 44 ],
        "id_str" : "3028904482",
        "id" : 3028904482
      }, {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 45, 55 ],
        "id_str" : "19725644",
        "id" : 19725644
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 71, 86 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 105, 110 ]
      }, {
        "text" : "WHScienceFair",
        "indices" : [ 111, 125 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166950073652092928",
    "text" : "WH Office Hrs @ 2ET: Bill Nye @TheScienceGuy @neiltyson & Tom Kalil of @whitehouseostp answer your Qs on #STEM #WHScienceFair. Ask: #WHChat",
    "id" : 166950073652092928,
    "created_at" : "2012-02-07 18:22:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 166950364044734464,
  "created_at" : "2012-02-07 18:24:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 19, 33 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 36, 50 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "STEM",
      "indices" : [ 114, 119 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/QSeHb1ay",
      "expanded_url" : "http:\/\/wh.gov\/kur",
      "display_url" : "wh.gov\/kur"
    } ]
  },
  "geo" : { },
  "id_str" : "166936065981153280",
  "text" : "Check out Bill Nye @TheScienceGuy's #WHScienceFair blog: http:\/\/t.co\/QSeHb1ay & join him for a #WHChat @ 2ET. Ask #STEM Qs now with #WHChat",
  "id" : 166936065981153280,
  "created_at" : "2012-02-07 17:27:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Triangle Coalition",
      "screen_name" : "TriCoalition",
      "indices" : [ 3, 16 ],
      "id_str" : "111053392",
      "id" : 111053392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166932492786470912",
  "text" : "RT @TriCoalition: Pres. Obama calls for 1 Million new #STEM grads, 100K new STEM teachers in next 10yrs! #WHScienceFair",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 36, 41 ]
      }, {
        "text" : "WHScienceFair",
        "indices" : [ 87, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166932053827387392",
    "text" : "Pres. Obama calls for 1 Million new #STEM grads, 100K new STEM teachers in next 10yrs! #WHScienceFair",
    "id" : 166932053827387392,
    "created_at" : "2012-02-07 17:11:17 +0000",
    "user" : {
      "name" : "Triangle Coalition",
      "screen_name" : "TriCoalition",
      "protected" : false,
      "id_str" : "111053392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000059091264\/c50146bc95ab2235e25fb28513ab5527_normal.png",
      "id" : 111053392,
      "verified" : false
    }
  },
  "id" : 166932492786470912,
  "created_at" : "2012-02-07 17:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166931099413524481",
  "text" : "RT @whitehouseostp: President Obama: \"I\u2019m proud of you. Keep up the good work.  And don\u2019t let any of those robots wander too far.\" #WHSc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 111, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166931036561879040",
    "text" : "President Obama: \"I\u2019m proud of you. Keep up the good work.  And don\u2019t let any of those robots wander too far.\" #WHScienceFair",
    "id" : 166931036561879040,
    "created_at" : "2012-02-07 17:07:15 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 166931099413524481,
  "created_at" : "2012-02-07 17:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166929901444800512",
  "text" : "RT @WHLive: \"It\u2019s young people like you who make me so confident that America\u2019s best days are still to come\" -The President to students  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166929866355253248",
    "text" : "\"It\u2019s young people like you who make me so confident that America\u2019s best days are still to come\" -The President to students @ #WHScienceFair",
    "id" : 166929866355253248,
    "created_at" : "2012-02-07 17:02:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 166929901444800512,
  "created_at" : "2012-02-07 17:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "166927977152655360",
  "text" : "\"It\u2019s not every day you have robots running all over your house.\" -President Obama @ the #WHScienceFair. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 166927977152655360,
  "created_at" : "2012-02-07 16:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "166927689377251328",
  "text" : "RT @WHLive: Happening now: President Obama speaks at the #WHScienceFair. Watch live: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 45, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "166927553087545344",
    "text" : "Happening now: President Obama speaks at the #WHScienceFair. Watch live: http:\/\/t.co\/g5ih2w0F",
    "id" : 166927553087545344,
    "created_at" : "2012-02-07 16:53:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 166927689377251328,
  "created_at" : "2012-02-07 16:53:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Leland Melvin",
      "screen_name" : "Astro_Flow",
      "indices" : [ 42, 53 ],
      "id_str" : "86336234",
      "id" : 86336234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166922006984527872",
  "text" : "RT @NASA: Astronaut and former NFL player @astro_flow views a unique student #WHScienceFair project that detects concussions. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leland Melvin",
        "screen_name" : "Astro_Flow",
        "indices" : [ 32, 43 ],
        "id_str" : "86336234",
        "id" : 86336234
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/166915344387145728\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/Mkx1Ys4w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AlEAnxICAAAUFhR.jpg",
        "id_str" : "166915344391340032",
        "id" : 166915344391340032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlEAnxICAAAUFhR.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Mkx1Ys4w"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 67, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166915344387145728",
    "text" : "Astronaut and former NFL player @astro_flow views a unique student #WHScienceFair project that detects concussions. http:\/\/t.co\/Mkx1Ys4w",
    "id" : 166915344387145728,
    "created_at" : "2012-02-07 16:04:54 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 166922006984527872,
  "created_at" : "2012-02-07 16:31:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 3, 13 ],
      "id_str" : "321466257",
      "id" : 321466257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "make",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "youngmakers",
      "indices" : [ 87, 99 ]
    }, {
      "text" : "hackerspace",
      "indices" : [ 100, 112 ]
    }, {
      "text" : "sciencefair",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166920984186716161",
  "text" : "RT @Joey_Hudy: I set up at the white house today and meet some really cool kids! #make #youngmakers #hackerspace #sciencefair http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joey_Hudy\/status\/166673621710934019\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/tILLMC5z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AlAkxqACEAAznNS.jpg",
        "id_str" : "166673621719322624",
        "id" : 166673621719322624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlAkxqACEAAznNS.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tILLMC5z"
      } ],
      "hashtags" : [ {
        "text" : "make",
        "indices" : [ 66, 71 ]
      }, {
        "text" : "youngmakers",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "hackerspace",
        "indices" : [ 85, 97 ]
      }, {
        "text" : "sciencefair",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166673621710934019",
    "text" : "I set up at the white house today and meet some really cool kids! #make #youngmakers #hackerspace #sciencefair http:\/\/t.co\/tILLMC5z",
    "id" : 166673621710934019,
    "created_at" : "2012-02-07 00:04:23 +0000",
    "user" : {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "protected" : false,
      "id_str" : "321466257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517291421586710528\/NAQCKPN5_normal.jpeg",
      "id" : 321466257,
      "verified" : false
    }
  },
  "id" : 166920984186716161,
  "created_at" : "2012-02-07 16:27:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/FlIEZnDb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "166916422587531264",
  "text" : "RT @whitehouseostp: The President just helped shoot a marshmallow out of an air cannon at the #WHScienceFair http:\/\/t.co\/FlIEZnDb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/FlIEZnDb",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "166915475899559936",
    "text" : "The President just helped shoot a marshmallow out of an air cannon at the #WHScienceFair http:\/\/t.co\/FlIEZnDb",
    "id" : 166915475899559936,
    "created_at" : "2012-02-07 16:05:25 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 166916422587531264,
  "created_at" : "2012-02-07 16:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Heinecke",
      "screen_name" : "KitchPantrySci",
      "indices" : [ 3, 18 ],
      "id_str" : "77800503",
      "id" : 77800503
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 112, 123 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 91, 105 ]
    }, {
      "text" : "STEM",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/78ZlFf9e",
      "expanded_url" : "http:\/\/tinyurl.com\/66kmbfh",
      "display_url" : "tinyurl.com\/66kmbfh"
    } ]
  },
  "geo" : { },
  "id_str" : "166915932688613378",
  "text" : "RT @KitchPantrySci: My kids love extracting DNA at the kitchen table! http:\/\/t.co\/78ZlFf9e\n#WHScienceFair #STEM @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 92, 103 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 71, 85 ]
      }, {
        "text" : "STEM",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/78ZlFf9e",
        "expanded_url" : "http:\/\/tinyurl.com\/66kmbfh",
        "display_url" : "tinyurl.com\/66kmbfh"
      } ]
    },
    "geo" : { },
    "id_str" : "166915581067526144",
    "text" : "My kids love extracting DNA at the kitchen table! http:\/\/t.co\/78ZlFf9e\n#WHScienceFair #STEM @whitehouse",
    "id" : 166915581067526144,
    "created_at" : "2012-02-07 16:05:50 +0000",
    "user" : {
      "name" : "Liz Heinecke",
      "screen_name" : "KitchPantrySci",
      "protected" : false,
      "id_str" : "77800503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649218519595266049\/X1VvM_hz_normal.jpg",
      "id" : 77800503,
      "verified" : false
    }
  },
  "id" : 166915932688613378,
  "created_at" : "2012-02-07 16:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/166913043756875776\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Q2LZWMq5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlD-h2nCAAE_O6A.jpg",
      "id_str" : "166913043761070081",
      "id" : 166913043761070081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlD-h2nCAAE_O6A.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Q2LZWMq5"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166914265385672706",
  "text" : "RT @NASA: Students using data from www.globe.gov explore how cloud cover affects surface temperature: #WHScienceFair http:\/\/t.co\/Q2LZWMq5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/166913043756875776\/photo\/1",
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/Q2LZWMq5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AlD-h2nCAAE_O6A.jpg",
        "id_str" : "166913043761070081",
        "id" : 166913043761070081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlD-h2nCAAE_O6A.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Q2LZWMq5"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166913043756875776",
    "text" : "Students using data from www.globe.gov explore how cloud cover affects surface temperature: #WHScienceFair http:\/\/t.co\/Q2LZWMq5",
    "id" : 166913043756875776,
    "created_at" : "2012-02-07 15:55:46 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 166914265385672706,
  "created_at" : "2012-02-07 16:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "166913903572430849",
  "text" : "RT @WHLive: Watch now: President Obama tours #WHScienceFair projects: http:\/\/t.co\/xrOHuqTm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 33, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "166913841828069378",
    "text" : "Watch now: President Obama tours #WHScienceFair projects: http:\/\/t.co\/xrOHuqTm",
    "id" : 166913841828069378,
    "created_at" : "2012-02-07 15:58:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 166913903572430849,
  "created_at" : "2012-02-07 15:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/166906997273395201\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/xlHZpwgn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlD5B5tCAAApN2O.jpg",
      "id_str" : "166906997277589504",
      "id" : 166906997277589504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlD5B5tCAAApN2O.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xlHZpwgn"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166906997273395201",
  "text" : "What's your favorite science fair project? Use #WHScienceFair to tell us about it & share photos http:\/\/t.co\/xlHZpwgn",
  "id" : 166906997273395201,
  "created_at" : "2012-02-07 15:31:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 114, 128 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 23, 37 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166903452037939202",
  "text" : "RT @ks44: Today is the #WHScienceFair! Join us: Share favorite science fair projects & join #WHChat with Bill Nye @TheScienceGuy http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Nye",
        "screen_name" : "thescienceguy",
        "indices" : [ 104, 118 ],
        "id_str" : "3028904482",
        "id" : 3028904482
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 13, 27 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/muutLeWa",
        "expanded_url" : "http:\/\/ow.ly\/8ViBH",
        "display_url" : "ow.ly\/8ViBH"
      } ]
    },
    "geo" : { },
    "id_str" : "166903373877100547",
    "text" : "Today is the #WHScienceFair! Join us: Share favorite science fair projects & join #WHChat with Bill Nye @TheScienceGuy http:\/\/t.co\/muutLeWa",
    "id" : 166903373877100547,
    "created_at" : "2012-02-07 15:17:19 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 166903452037939202,
  "created_at" : "2012-02-07 15:17:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheScienceGuy\/status\/166899451259133952\/photo\/1",
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/F4yfAW4D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlDyKqnCIAAL3D5.jpg",
      "id_str" : "166899451263328256",
      "id" : 166899451263328256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlDyKqnCIAAL3D5.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com\/F4yfAW4D"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166902392867139585",
  "text" : "RT @TheScienceGuy: We're talkin' #WHScienceFair http:\/\/t.co\/F4yfAW4D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheScienceGuy\/status\/166899451259133952\/photo\/1",
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/F4yfAW4D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AlDyKqnCIAAL3D5.jpg",
        "id_str" : "166899451263328256",
        "id" : 166899451263328256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlDyKqnCIAAL3D5.jpg",
        "sizes" : [ {
          "h" : 648,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 484
        } ],
        "display_url" : "pic.twitter.com\/F4yfAW4D"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 14, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166899451259133952",
    "text" : "We're talkin' #WHScienceFair http:\/\/t.co\/F4yfAW4D",
    "id" : 166899451259133952,
    "created_at" : "2012-02-07 15:01:45 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 166902392867139585,
  "created_at" : "2012-02-07 15:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166653020770283521",
  "text" : "RT @aneeshchopra: Presidential advisor Valerie Jarrett @whitehouse inspires participation in the \"equal pay apps\" competition http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 37, 48 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/tMWmU5mm",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/02\/06\/securing-equal-pay-there-should-be-app",
        "display_url" : "whitehouse.gov\/blog\/2012\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166649519067504641",
    "text" : "Presidential advisor Valerie Jarrett @whitehouse inspires participation in the \"equal pay apps\" competition http:\/\/t.co\/tMWmU5mm",
    "id" : 166649519067504641,
    "created_at" : "2012-02-06 22:28:36 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 166653020770283521,
  "created_at" : "2012-02-06 22:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "State Representative",
      "screen_name" : "eddiewashington",
      "indices" : [ 3, 19 ],
      "id_str" : "88728010",
      "id" : 88728010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166623356261629952",
  "text" : "RT @eddiewashington: Seniors Seeing the Savings from the Affordable Care Act: \n\tLast week, several announcements from the Department ... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/VF2QT0eq",
        "expanded_url" : "http:\/\/1.usa.gov\/zawa3u",
        "display_url" : "1.usa.gov\/zawa3u"
      } ]
    },
    "geo" : { },
    "id_str" : "166622340464123904",
    "text" : "Seniors Seeing the Savings from the Affordable Care Act: \n\tLast week, several announcements from the Department ... http:\/\/t.co\/VF2QT0eq",
    "id" : 166622340464123904,
    "created_at" : "2012-02-06 20:40:36 +0000",
    "user" : {
      "name" : "State Representative",
      "screen_name" : "eddiewashington",
      "protected" : false,
      "id_str" : "88728010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518370701\/EddieWashington_normal.jpg",
      "id" : 88728010,
      "verified" : false
    }
  },
  "id" : 166623356261629952,
  "created_at" : "2012-02-06 20:44:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 33, 44 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "About Foursquare",
      "screen_name" : "aboutfoursquare",
      "indices" : [ 102, 118 ],
      "id_str" : "133741129",
      "id" : 133741129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/CoLP9yZr",
      "expanded_url" : "http:\/\/aboutfoursquare.com\/foursquares-crowd-sourced-us-travel-guide\/",
      "display_url" : "aboutfoursquare.com\/foursquares-cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166622797290946560",
  "text" : "RT @macon44: #VisitUS continues! @Foursquare's crowd-sourced US travel guide http:\/\/t.co\/CoLP9yZr via @aboutfoursquare Backstory: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Foursquare",
        "screen_name" : "Foursquare",
        "indices" : [ 20, 31 ],
        "id_str" : "14120151",
        "id" : 14120151
      }, {
        "name" : "About Foursquare",
        "screen_name" : "aboutfoursquare",
        "indices" : [ 89, 105 ],
        "id_str" : "133741129",
        "id" : 133741129
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/CoLP9yZr",
        "expanded_url" : "http:\/\/aboutfoursquare.com\/foursquares-crowd-sourced-us-travel-guide\/",
        "display_url" : "aboutfoursquare.com\/foursquares-cr\u2026"
      }, {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/SK6xDHvS",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/01\/22\/visitus-americans-share-what-makes-their-hometown-great-place-visit",
        "display_url" : "whitehouse.gov\/blog\/2012\/01\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166622571998085120",
    "text" : "#VisitUS continues! @Foursquare's crowd-sourced US travel guide http:\/\/t.co\/CoLP9yZr via @aboutfoursquare Backstory: http:\/\/t.co\/SK6xDHvS",
    "id" : 166622571998085120,
    "created_at" : "2012-02-06 20:41:31 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 166622797290946560,
  "created_at" : "2012-02-06 20:42:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "John Holdsclaw IV",
      "screen_name" : "jholdsclaw",
      "indices" : [ 15, 26 ],
      "id_str" : "20414528",
      "id" : 20414528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166621528358797313",
  "text" : "RT @letsmove: .@jholdsclaw Everyone has a stake in overcoming these challenges.  We need to think outside the box and engage the entire  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Holdsclaw IV",
        "screen_name" : "jholdsclaw",
        "indices" : [ 1, 12 ],
        "id_str" : "20414528",
        "id" : 20414528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166620837946986496",
    "text" : ".@jholdsclaw Everyone has a stake in overcoming these challenges.  We need to think outside the box and engage the entire community #WHChat",
    "id" : 166620837946986496,
    "created_at" : "2012-02-06 20:34:38 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 166621528358797313,
  "created_at" : "2012-02-06 20:37:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Holdsclaw IV",
      "screen_name" : "jholdsclaw",
      "indices" : [ 3, 14 ],
      "id_str" : "20414528",
      "id" : 20414528
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 16, 25 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "\u0413\u0430\u043B\u0438\u0435\u0432 \u0418\u043B\u0438\u0439",
      "screen_name" : "innovate4impact",
      "indices" : [ 60, 76 ],
      "id_str" : "2835185981",
      "id" : 2835185981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreshFood",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166619128969433088",
  "text" : "RT @jholdsclaw: @LetsMove how can community based orgs like @innovate4impact support work of FLOTUS and increase access to #FreshFood =  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 0, 9 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "\u0413\u0430\u043B\u0438\u0435\u0432 \u0418\u043B\u0438\u0439",
        "screen_name" : "innovate4impact",
        "indices" : [ 44, 60 ],
        "id_str" : "2835185981",
        "id" : 2835185981
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreshFood",
        "indices" : [ 107, 117 ]
      }, {
        "text" : "HealthyKids",
        "indices" : [ 120, 132 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166617166299402240",
    "in_reply_to_user_id" : 36719281,
    "text" : "@LetsMove how can community based orgs like @innovate4impact support work of FLOTUS and increase access to #FreshFood = #HealthyKids #WHChat",
    "id" : 166617166299402240,
    "created_at" : "2012-02-06 20:20:02 +0000",
    "in_reply_to_screen_name" : "letsmove",
    "in_reply_to_user_id_str" : "36719281",
    "user" : {
      "name" : "John Holdsclaw IV",
      "screen_name" : "jholdsclaw",
      "protected" : false,
      "id_str" : "20414528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696748333088505856\/CUr9-Lct_normal.jpg",
      "id" : 20414528,
      "verified" : false
    }
  },
  "id" : 166619128969433088,
  "created_at" : "2012-02-06 20:27:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Dan McKenna",
      "screen_name" : "danmcken",
      "indices" : [ 15, 24 ],
      "id_str" : "277737903",
      "id" : 277737903
    }, {
      "name" : "BravoTopChef",
      "screen_name" : "BravoTopChef",
      "indices" : [ 98, 111 ],
      "id_str" : "17219499",
      "id" : 17219499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166610554549571584",
  "text" : "RT @letsmove: .@danmcken Of course! Stay tuned, 2\/10 FLOTUS to make announcement on chefs move at @BravoTopChef event in Dallas  #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan McKenna",
        "screen_name" : "danmcken",
        "indices" : [ 1, 10 ],
        "id_str" : "277737903",
        "id" : 277737903
      }, {
        "name" : "BravoTopChef",
        "screen_name" : "BravoTopChef",
        "indices" : [ 84, 97 ],
        "id_str" : "17219499",
        "id" : 17219499
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166610505597849600",
    "text" : ".@danmcken Of course! Stay tuned, 2\/10 FLOTUS to make announcement on chefs move at @BravoTopChef event in Dallas  #WHChat",
    "id" : 166610505597849600,
    "created_at" : "2012-02-06 19:53:34 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 166610554549571584,
  "created_at" : "2012-02-06 19:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan McKenna",
      "screen_name" : "danmcken",
      "indices" : [ 3, 12 ],
      "id_str" : "277737903",
      "id" : 277737903
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 33, 42 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "pha",
      "screen_name" : "pha",
      "indices" : [ 43, 47 ],
      "id_str" : "4169511",
      "id" : 4169511
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 48, 53 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166610487189061632",
  "text" : "RT @danmcken: Hi, Sam.  How does @letsmove @pha @usda plan to ensure continuity in the Chefs Move program over the long term? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 19, 28 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "pha",
        "screen_name" : "pha",
        "indices" : [ 29, 33 ],
        "id_str" : "4169511",
        "id" : 4169511
      }, {
        "name" : "Dept. of Agriculture",
        "screen_name" : "USDA",
        "indices" : [ 34, 39 ],
        "id_str" : "61853389",
        "id" : 61853389
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "166606145367187456",
    "geo" : { },
    "id_str" : "166606769701928961",
    "in_reply_to_user_id" : 36719281,
    "text" : "Hi, Sam.  How does @letsmove @pha @usda plan to ensure continuity in the Chefs Move program over the long term? #WHChat",
    "id" : 166606769701928961,
    "in_reply_to_status_id" : 166606145367187456,
    "created_at" : "2012-02-06 19:38:43 +0000",
    "in_reply_to_screen_name" : "letsmove",
    "in_reply_to_user_id_str" : "36719281",
    "user" : {
      "name" : "Dan McKenna",
      "screen_name" : "danmcken",
      "protected" : false,
      "id_str" : "277737903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1301426311\/dano_bw_profile_pic_normal.jpg",
      "id" : 277737903,
      "verified" : false
    }
  },
  "id" : 166610487189061632,
  "created_at" : "2012-02-06 19:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 15, 24 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166607866306895873",
  "text" : "Happening now: @LetsMove Office Hours with Sam Kass. Ask your Qs about the First Lady's initiative now with #WHChat",
  "id" : 166607866306895873,
  "created_at" : "2012-02-06 19:43:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Medicare",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "HCR",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/jJrUeO7r",
      "expanded_url" : "http:\/\/ow.ly\/8Ucjk",
      "display_url" : "ow.ly\/8Ucjk"
    } ]
  },
  "geo" : { },
  "id_str" : "166599747459743744",
  "text" : "In 2011, nearly 3.6M people with #Medicare saved $2.1B on prescription drugs thanks to the Affordable Care Act: http:\/\/t.co\/jJrUeO7r #HCR",
  "id" : 166599747459743744,
  "created_at" : "2012-02-06 19:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "indices" : [ 3, 15 ],
      "id_str" : "15327996",
      "id" : 15327996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166595711247450113",
  "text" : "RT @BFriedmanDC: President & First Lady will host a White House dinner for 200 troops honoring those who served in Iraq. Will take place ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166595495513432064",
    "text" : "President & First Lady will host a White House dinner for 200 troops honoring those who served in Iraq. Will take place Feb. 29.",
    "id" : 166595495513432064,
    "created_at" : "2012-02-06 18:53:55 +0000",
    "user" : {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "protected" : false,
      "id_str" : "15327996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649427993161433088\/nzkLsEDl_normal.jpg",
      "id" : 15327996,
      "verified" : true
    }
  },
  "id" : 166595711247450113,
  "created_at" : "2012-02-06 18:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166553174138830849",
  "text" : "RT @letsmove: WH Office Hours: #LetsMove 2nd Anniversary with Sam Kass. Ask your questions now with #WHChat & join live at 2:30ET http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 17, 26 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/UCXZb1QV",
        "expanded_url" : "http:\/\/ow.ly\/8TRYy",
        "display_url" : "ow.ly\/8TRYy"
      } ]
    },
    "geo" : { },
    "id_str" : "166553103699677185",
    "text" : "WH Office Hours: #LetsMove 2nd Anniversary with Sam Kass. Ask your questions now with #WHChat & join live at 2:30ET http:\/\/t.co\/UCXZb1QV",
    "id" : 166553103699677185,
    "created_at" : "2012-02-06 16:05:28 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 166553174138830849,
  "created_at" : "2012-02-06 16:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/jHyIJazM",
      "expanded_url" : "http:\/\/ow.ly\/8Seca",
      "display_url" : "ow.ly\/8Seca"
    } ]
  },
  "geo" : { },
  "id_str" : "165808538000691201",
  "text" : "WEEKLY ADDRESS: It\u2019s time for Congress to act to help responsible homeowners: http:\/\/t.co\/jHyIJazM",
  "id" : 165808538000691201,
  "created_at" : "2012-02-04 14:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/34rmxfIx",
      "expanded_url" : "http:\/\/goo.gl\/fb\/pLDxk",
      "display_url" : "goo.gl\/fb\/pLDxk"
    } ]
  },
  "geo" : { },
  "id_str" : "165804596751642624",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: Weekly Address: It\u2019s Time for Congress to Act to Help Responsible Homeowners http:\/\/t.co\/34rmxfIx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/34rmxfIx",
        "expanded_url" : "http:\/\/goo.gl\/fb\/pLDxk",
        "display_url" : "goo.gl\/fb\/pLDxk"
      } ]
    },
    "geo" : { },
    "id_str" : "165758621588791296",
    "text" : "http:\/\/t.co\/HxTO58SB: Weekly Address: It\u2019s Time for Congress to Act to Help Responsible Homeowners http:\/\/t.co\/34rmxfIx",
    "id" : 165758621588791296,
    "created_at" : "2012-02-04 11:28:29 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 165804596751642624,
  "created_at" : "2012-02-04 14:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/JUCkXCd2",
      "expanded_url" : "http:\/\/ow.ly\/8ROBu",
      "display_url" : "ow.ly\/8ROBu"
    } ]
  },
  "geo" : { },
  "id_str" : "165574288072638465",
  "text" : "Creating a Veterans Job Corps: President Obama makes a new push to help #veterans build the lives the deserve: http:\/\/t.co\/JUCkXCd2",
  "id" : 165574288072638465,
  "created_at" : "2012-02-03 23:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/165532877822492673\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/5dwsXlZH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkwXRn2CAAAAvvc.jpg",
      "id_str" : "165532877826686976",
      "id" : 165532877826686976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkwXRn2CAAAAvvc.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/5dwsXlZH"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165532877822492673",
  "text" : "In January, American businesses added 257,000 #jobs. The economy has added 3.7 million jobs over the last 23 months: http:\/\/t.co\/5dwsXlZH",
  "id" : 165532877822492673,
  "created_at" : "2012-02-03 20:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedTailsMovie",
      "screen_name" : "RedTailsMovie",
      "indices" : [ 76, 90 ],
      "id_str" : "1347929647",
      "id" : 1347929647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/HkKqo3Vx",
      "expanded_url" : "http:\/\/youtu.be\/NNpSwVBeXtI",
      "display_url" : "youtu.be\/NNpSwVBeXtI"
    } ]
  },
  "geo" : { },
  "id_str" : "165497296790896641",
  "text" : "Watch: President Obama invites Tuskegee Airmen to the White House to screen @redtailsmovie with @JrCubaGooding: http:\/\/t.co\/HkKqo3Vx",
  "id" : 165497296790896641,
  "created_at" : "2012-02-03 18:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHhangout",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165491588884205569",
  "text" : "RT @ks44: We just passed 100k followers on the White House Google+ page! Follow for a behind-the-scenes look, #WHhangout & more: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHhangout",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/dPMbc4nN",
        "expanded_url" : "http:\/\/ow.ly\/8Roc1",
        "display_url" : "ow.ly\/8Roc1"
      } ]
    },
    "geo" : { },
    "id_str" : "165491468864192514",
    "text" : "We just passed 100k followers on the White House Google+ page! Follow for a behind-the-scenes look, #WHhangout & more: http:\/\/t.co\/dPMbc4nN",
    "id" : 165491468864192514,
    "created_at" : "2012-02-03 17:46:55 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 165491588884205569,
  "created_at" : "2012-02-03 17:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "Peter Cook",
      "screen_name" : "PentagonPresSec",
      "indices" : [ 83, 99 ],
      "id_str" : "335996055",
      "id" : 335996055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoD",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165455918895599616",
  "text" : "RT @DeptofDefense: #DoD is happy to announce our first ever Twitter Town Hall with @PentagonPresSec on Mon, Feb. 6 at 3:30 p.m. EST. Sen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Cook",
        "screen_name" : "PentagonPresSec",
        "indices" : [ 64, 80 ],
        "id_str" : "335996055",
        "id" : 335996055
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoD",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "AskDoD",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165187694681534465",
    "text" : "#DoD is happy to announce our first ever Twitter Town Hall with @PentagonPresSec on Mon, Feb. 6 at 3:30 p.m. EST. Send ?s with #AskDoD",
    "id" : 165187694681534465,
    "created_at" : "2012-02-02 21:39:50 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 165455918895599616,
  "created_at" : "2012-02-03 15:25:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/165453522723291138\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/qFfCYyw2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkvPGjECQAAGykm.jpg",
      "id_str" : "165453522727485440",
      "id" : 165453522727485440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkvPGjECQAAGykm.jpg",
      "sizes" : [ {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/qFfCYyw2"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165453522723291138",
  "text" : "New #jobs chart: Economy continues to heal, 3.7 million jobs added over 23 months: http:\/\/t.co\/qFfCYyw2",
  "id" : 165453522723291138,
  "created_at" : "2012-02-03 15:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165442468928688129",
  "text" : "RT @pfeiffer44: President Obama heads to a local firehouse today to lay out the details of his plans to help returning vets find jobs ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/3jEzbY9K",
        "expanded_url" : "http:\/\/usat.ly\/A5kL22",
        "display_url" : "usat.ly\/A5kL22"
      } ]
    },
    "geo" : { },
    "id_str" : "165411745081466880",
    "text" : "President Obama heads to a local firehouse today to lay out the details of his plans to help returning vets find jobs http:\/\/t.co\/3jEzbY9K",
    "id" : 165411745081466880,
    "created_at" : "2012-02-03 12:30:07 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 165442468928688129,
  "created_at" : "2012-02-03 14:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 49, 62 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 63, 73 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartupAmerica",
      "indices" : [ 11, 26 ]
    }, {
      "text" : "WHhangout",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/ljS04hor",
      "expanded_url" : "http:\/\/youtu.be\/MaF6fFlNX6s",
      "display_url" : "youtu.be\/MaF6fFlNX6s"
    } ]
  },
  "geo" : { },
  "id_str" : "165439593922048000",
  "text" : "Missed the #StartupAmerica White House Hangout w @aneeshchopra @stevecase & Gene Sperling? Full video here: http:\/\/t.co\/ljS04hor #WHhangout",
  "id" : 165439593922048000,
  "created_at" : "2012-02-03 14:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 20, 32 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/TyGVhDka",
      "expanded_url" : "http:\/\/ow.ly\/8QraH",
      "display_url" : "ow.ly\/8QraH"
    } ]
  },
  "geo" : { },
  "id_str" : "165242796150751232",
  "text" : "A Conversation with @WeThePeople about #Immigration Policy: http:\/\/t.co\/TyGVhDka",
  "id" : 165242796150751232,
  "created_at" : "2012-02-03 01:18:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 76, 86 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Mike Krieger",
      "screen_name" : "mikeyk",
      "indices" : [ 117, 124 ],
      "id_str" : "12831",
      "id" : 12831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHhangout",
      "indices" : [ 54, 64 ]
    }, {
      "text" : "StartupAmerica",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165228901944147968",
  "text" : "RT @aneeshchopra: Thanks for participating in today's #WHhangout w\/Gene and @SteveCase on #StartupAmerica - \"Be Like @Mikeyk\" - an #open ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 58, 68 ],
        "id_str" : "6708952",
        "id" : 6708952
      }, {
        "name" : "Mike Krieger",
        "screen_name" : "mikeyk",
        "indices" : [ 99, 106 ],
        "id_str" : "12831",
        "id" : 12831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHhangout",
        "indices" : [ 36, 46 ]
      }, {
        "text" : "StartupAmerica",
        "indices" : [ 72, 87 ]
      }, {
        "text" : "opengov",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165221097619456000",
    "text" : "Thanks for participating in today's #WHhangout w\/Gene and @SteveCase on #StartupAmerica - \"Be Like @Mikeyk\" - an #opengov innovator",
    "id" : 165221097619456000,
    "created_at" : "2012-02-02 23:52:33 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 165228901944147968,
  "created_at" : "2012-02-03 00:23:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 50, 63 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 108, 119 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHhangout",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165228789192867841",
  "text" : "RT @SteveCase: Thanks to everybody who joined me, @AneeshChopra & Gene Sperling at #WHhangout discussion at @WhiteHouse about #StartupAm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 35, 48 ],
        "id_str" : "121539516",
        "id" : 121539516
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 93, 104 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHhangout",
        "indices" : [ 68, 78 ]
      }, {
        "text" : "StartupAmerica",
        "indices" : [ 111, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165219675456806912",
    "text" : "Thanks to everybody who joined me, @AneeshChopra & Gene Sperling at #WHhangout discussion at @WhiteHouse about #StartupAmerica",
    "id" : 165219675456806912,
    "created_at" : "2012-02-02 23:46:54 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 165228789192867841,
  "created_at" : "2012-02-03 00:23:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165215256954675200",
  "text" : "RT @jesseclee44: Obama applauds Senate on STOCK Act: \"more work to be done, like prohibiting elected officials from owning stocks in ind ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165213601970405376",
    "text" : "Obama applauds Senate on STOCK Act: \"more work to be done, like prohibiting elected officials from owning stocks in industries they impact\"",
    "id" : 165213601970405376,
    "created_at" : "2012-02-02 23:22:46 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 165215256954675200,
  "created_at" : "2012-02-02 23:29:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lon Seidman",
      "screen_name" : "lonseidman",
      "indices" : [ 3, 14 ],
      "id_str" : "3086071",
      "id" : 3086071
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 80, 95 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/eXyDxGcf",
      "expanded_url" : "http:\/\/whitehouse.gov\/live\/",
      "display_url" : "whitehouse.gov\/live\/"
    } ]
  },
  "geo" : { },
  "id_str" : "165214758943997953",
  "text" : "RT @lonseidman: Watching the @whitehouse Google hangout on entrepreneurship and @startupamerica http:\/\/t.co\/eXyDxGcf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 64, 79 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/eXyDxGcf",
        "expanded_url" : "http:\/\/whitehouse.gov\/live\/",
        "display_url" : "whitehouse.gov\/live\/"
      } ]
    },
    "geo" : { },
    "id_str" : "165214222307954688",
    "text" : "Watching the @whitehouse Google hangout on entrepreneurship and @startupamerica http:\/\/t.co\/eXyDxGcf",
    "id" : 165214222307954688,
    "created_at" : "2012-02-02 23:25:14 +0000",
    "user" : {
      "name" : "Lon Seidman",
      "screen_name" : "lonseidman",
      "protected" : false,
      "id_str" : "3086071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523856387\/2767835697_290f14ebbc_o_normal.jpg",
      "id" : 3086071,
      "verified" : false
    }
  },
  "id" : 165214758943997953,
  "created_at" : "2012-02-02 23:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Fretwell",
      "screen_name" : "lukefretwell",
      "indices" : [ 3, 16 ],
      "id_str" : "1980171",
      "id" : 1980171
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 35, 46 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 60, 73 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 75, 85 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 87, 96 ],
      "id_str" : "14278978",
      "id" : 14278978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/eA2heduu",
      "expanded_url" : "http:\/\/1.usa.gov\/a6JWsN",
      "display_url" : "1.usa.gov\/a6JWsN"
    } ]
  },
  "geo" : { },
  "id_str" : "165214629063163904",
  "text" : "RT @lukefretwell: Just tuning into @whitehouse G+ Hangout w\/@aneeshchopra, @stevecase, @ericries, others: http:\/\/t.co\/eA2heduu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 42, 55 ],
        "id_str" : "121539516",
        "id" : 121539516
      }, {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 57, 67 ],
        "id_str" : "6708952",
        "id" : 6708952
      }, {
        "name" : "Eric Ries",
        "screen_name" : "ericries",
        "indices" : [ 69, 78 ],
        "id_str" : "14278978",
        "id" : 14278978
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/eA2heduu",
        "expanded_url" : "http:\/\/1.usa.gov\/a6JWsN",
        "display_url" : "1.usa.gov\/a6JWsN"
      } ]
    },
    "geo" : { },
    "id_str" : "165213441831862272",
    "text" : "Just tuning into @whitehouse G+ Hangout w\/@aneeshchopra, @stevecase, @ericries, others: http:\/\/t.co\/eA2heduu",
    "id" : 165213441831862272,
    "created_at" : "2012-02-02 23:22:08 +0000",
    "user" : {
      "name" : "Luke Fretwell",
      "screen_name" : "lukefretwell",
      "protected" : false,
      "id_str" : "1980171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502213695686983680\/LmKBjvRv_normal.jpeg",
      "id" : 1980171,
      "verified" : false
    }
  },
  "id" : 165214629063163904,
  "created_at" : "2012-02-02 23:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Cheney",
      "screen_name" : "alexandracheney",
      "indices" : [ 0, 16 ],
      "id_str" : "16048133",
      "id" : 16048133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165212720692604928",
  "geo" : { },
  "id_str" : "165213054563389440",
  "in_reply_to_user_id" : 16048133,
  "text" : "@alexandracheney You are! Bring it!",
  "id" : 165213054563389440,
  "in_reply_to_status_id" : 165212720692604928,
  "created_at" : "2012-02-02 23:20:36 +0000",
  "in_reply_to_screen_name" : "alexandracheney",
  "in_reply_to_user_id_str" : "16048133",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 3, 12 ],
      "id_str" : "14278978",
      "id" : 14278978
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165212563058081792",
  "text" : "RT @ericries: Going to join the @whitehouse Hangout with @anneshchopra @stevecase & friends @startupamerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 57, 67 ],
        "id_str" : "6708952",
        "id" : 6708952
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 78, 93 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165202127675867137",
    "text" : "Going to join the @whitehouse Hangout with @anneshchopra @stevecase & friends @startupamerica",
    "id" : 165202127675867137,
    "created_at" : "2012-02-02 22:37:11 +0000",
    "user" : {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "protected" : false,
      "id_str" : "14278978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769304611\/image1327092761_normal.png",
      "id" : 14278978,
      "verified" : true
    }
  },
  "id" : 165212563058081792,
  "created_at" : "2012-02-02 23:18:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Boonn",
      "screen_name" : "wboonn",
      "indices" : [ 3, 10 ],
      "id_str" : "15259356",
      "id" : 15259356
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 57, 72 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 123, 135 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneurs",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/AzTHb5Tb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "165212499644391424",
  "text" : "RT @wboonn: LIVE NOW: Q&A w\/ @WhiteHouse officials about @StartupAmerica, resource for #entrepreneurs http:\/\/t.co\/AzTHb5Tb @BarackObama  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 45, 60 ],
        "id_str" : "211921304",
        "id" : 211921304
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 111, 123 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 124, 134 ],
        "id_str" : "6708952",
        "id" : 6708952
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "entrepreneurs",
        "indices" : [ 75, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/AzTHb5Tb",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "165204454180790272",
    "text" : "LIVE NOW: Q&A w\/ @WhiteHouse officials about @StartupAmerica, resource for #entrepreneurs http:\/\/t.co\/AzTHb5Tb @BarackObama @SteveCase",
    "id" : 165204454180790272,
    "created_at" : "2012-02-02 22:46:25 +0000",
    "user" : {
      "name" : "William Boonn",
      "screen_name" : "wboonn",
      "protected" : false,
      "id_str" : "15259356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000748418291\/61ba75aff09780e686795e857bcf2e23_normal.jpeg",
      "id" : 15259356,
      "verified" : false
    }
  },
  "id" : 165212499644391424,
  "created_at" : "2012-02-02 23:18:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eliana Murillo",
      "screen_name" : "Eliana_Murillo",
      "indices" : [ 3, 18 ],
      "id_str" : "176493107",
      "id" : 176493107
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startup",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "latism",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "tech",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/VVXh1QLv",
      "expanded_url" : "http:\/\/goo.gl\/03glK",
      "display_url" : "goo.gl\/03glK"
    } ]
  },
  "geo" : { },
  "id_str" : "165212482628091904",
  "text" : "RT @Eliana_Murillo: @whitehouse using g+ hangout now to discuss #startup america http:\/\/t.co\/VVXh1QLv #latism #smallbiz #tech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "startup",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "latism",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 90, 99 ]
      }, {
        "text" : "tech",
        "indices" : [ 100, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/VVXh1QLv",
        "expanded_url" : "http:\/\/goo.gl\/03glK",
        "display_url" : "goo.gl\/03glK"
      } ]
    },
    "geo" : { },
    "id_str" : "165205621543677952",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse using g+ hangout now to discuss #startup america http:\/\/t.co\/VVXh1QLv #latism #smallbiz #tech",
    "id" : 165205621543677952,
    "created_at" : "2012-02-02 22:51:04 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Eliana Murillo",
      "screen_name" : "Eliana_Murillo",
      "protected" : false,
      "id_str" : "176493107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723535187213058049\/RIa5gh53_normal.jpg",
      "id" : 176493107,
      "verified" : false
    }
  },
  "id" : 165212482628091904,
  "created_at" : "2012-02-02 23:18:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SnappyTV",
      "screen_name" : "SnappyTV",
      "indices" : [ 3, 12 ],
      "id_str" : "196471681",
      "id" : 196471681
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 75, 90 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHLive",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/btQXGN8c",
      "expanded_url" : "http:\/\/snpy.tv\/xCnLe4",
      "display_url" : "snpy.tv\/xCnLe4"
    } ]
  },
  "geo" : { },
  "id_str" : "165212447857324032",
  "text" : "RT @SnappyTV: @whitehouse Watch instant highlights of the #WHLive Hangout. @Startupamerica - http:\/\/t.co\/btQXGN8c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 61, 76 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHLive",
        "indices" : [ 44, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/btQXGN8c",
        "expanded_url" : "http:\/\/snpy.tv\/xCnLe4",
        "display_url" : "snpy.tv\/xCnLe4"
      } ]
    },
    "geo" : { },
    "id_str" : "165206028084973569",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Watch instant highlights of the #WHLive Hangout. @Startupamerica - http:\/\/t.co\/btQXGN8c",
    "id" : 165206028084973569,
    "created_at" : "2012-02-02 22:52:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "SnappyTV",
      "screen_name" : "SnappyTV",
      "protected" : false,
      "id_str" : "196471681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431130013992112129\/VwPmRS-1_normal.png",
      "id" : 196471681,
      "verified" : true
    }
  },
  "id" : 165212447857324032,
  "created_at" : "2012-02-02 23:18:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 74, 89 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 90, 103 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 104, 114 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165205755119681536",
  "text" : "RT @macon44: Never done something like this before: check out WH.gov\/live @startupamerica @aneeshchopra @SteveCase",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 61, 76 ],
        "id_str" : "211921304",
        "id" : 211921304
      }, {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 77, 90 ],
        "id_str" : "121539516",
        "id" : 121539516
      }, {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 91, 101 ],
        "id_str" : "6708952",
        "id" : 6708952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165205120848625664",
    "text" : "Never done something like this before: check out WH.gov\/live @startupamerica @aneeshchopra @SteveCase",
    "id" : 165205120848625664,
    "created_at" : "2012-02-02 22:49:04 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 165205755119681536,
  "created_at" : "2012-02-02 22:51:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/F3ZH4hKZ",
      "expanded_url" : "http:\/\/on.doi.gov\/dST8Od",
      "display_url" : "on.doi.gov\/dST8Od"
    } ]
  },
  "geo" : { },
  "id_str" : "165173716936966144",
  "text" : "RT @Interior: Salazar will answer your Q's about America's #energy future Friday @ 12:30 EDT. http:\/\/t.co\/F3ZH4hKZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/F3ZH4hKZ",
        "expanded_url" : "http:\/\/on.doi.gov\/dST8Od",
        "display_url" : "on.doi.gov\/dST8Od"
      } ]
    },
    "geo" : { },
    "id_str" : "164797951078699009",
    "text" : "Salazar will answer your Q's about America's #energy future Friday @ 12:30 EDT. http:\/\/t.co\/F3ZH4hKZ",
    "id" : 164797951078699009,
    "created_at" : "2012-02-01 19:51:07 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 165173716936966144,
  "created_at" : "2012-02-02 20:44:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 27, 37 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 38, 51 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupamerica",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/RolZAGHA",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/02\/01\/white-house-hangout-startup-america",
      "display_url" : "whitehouse.gov\/blog\/2012\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165144899832909824",
  "text" : "White House Hangout today: @stevecase @aneeshchopra & Gene Sperling answer your Qs on #startupamerica. Join live: http:\/\/t.co\/RolZAGHA",
  "id" : 165144899832909824,
  "created_at" : "2012-02-02 18:49:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 32, 43 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/5dbYYUe9",
      "expanded_url" : "http:\/\/ow.ly\/8PVWi",
      "display_url" : "ow.ly\/8PVWi"
    } ]
  },
  "geo" : { },
  "id_str" : "165132893058904064",
  "text" : "Helping Responsible Homeowners: @jearnest44 brings you the regional roundup: http:\/\/t.co\/5dbYYUe9",
  "id" : 165132893058904064,
  "created_at" : "2012-02-02 18:02:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165124899386568706",
  "text" : "RT @jesseclee44: 28 states already require insurance to cover contraception, some w\/ same religious employer exemptions, others w\/ none  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/oNLOkoqe",
        "expanded_url" : "http:\/\/wh.gov\/kkP",
        "display_url" : "wh.gov\/kkP"
      } ]
    },
    "geo" : { },
    "id_str" : "165123664432472064",
    "text" : "28 states already require insurance to cover contraception, some w\/ same religious employer exemptions, others w\/ none http:\/\/t.co\/oNLOkoqe",
    "id" : 165123664432472064,
    "created_at" : "2012-02-02 17:25:24 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 165124899386568706,
  "created_at" : "2012-02-02 17:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165123833936887808",
  "text" : "RT @HHSGov: 3.6 million seniors saved 2.1b on RX drugs in 2011. Suzanne & William from FL are two of them. Read more: http:\/\/t.co\/djeETm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThanksHCR",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/djeETm3I",
        "expanded_url" : "http:\/\/1.usa.gov\/z0X8Tv",
        "display_url" : "1.usa.gov\/z0X8Tv"
      } ]
    },
    "geo" : { },
    "id_str" : "165117173285662720",
    "text" : "3.6 million seniors saved 2.1b on RX drugs in 2011. Suzanne & William from FL are two of them. Read more: http:\/\/t.co\/djeETm3I #ThanksHCR",
    "id" : 165117173285662720,
    "created_at" : "2012-02-02 16:59:36 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 165123833936887808,
  "created_at" : "2012-02-02 17:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamahangout",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165110180978229248",
  "text" : "RT @macon44: Following up on #obamahangout, NEC Dir Sperling USCTO Chopra & Startup America's Steve Case hang @ 5:30pmET http:\/\/t.co\/18o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "obamahangout",
        "indices" : [ 16, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/18oCDrjW",
        "expanded_url" : "http:\/\/1.usa.gov\/zGQ9U7",
        "display_url" : "1.usa.gov\/zGQ9U7"
      } ]
    },
    "geo" : { },
    "id_str" : "165078653988904960",
    "text" : "Following up on #obamahangout, NEC Dir Sperling USCTO Chopra & Startup America's Steve Case hang @ 5:30pmET http:\/\/t.co\/18oCDrjW",
    "id" : 165078653988904960,
    "created_at" : "2012-02-02 14:26:32 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 165110180978229248,
  "created_at" : "2012-02-02 16:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Ef8Ec3SG",
      "expanded_url" : "http:\/\/ow.ly\/8PMrA",
      "display_url" : "ow.ly\/8PMrA"
    } ]
  },
  "geo" : { },
  "id_str" : "165109973548941312",
  "text" : "President Obama talks about ways to help homeowners: http:\/\/t.co\/Ef8Ec3SG",
  "id" : 165109973548941312,
  "created_at" : "2012-02-02 16:30:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "165078483628867584",
  "text" : "Happening now: President Obama Speaks at the National Prayer Breakfast. Watch: http:\/\/t.co\/hhNoX4fh",
  "id" : 165078483628867584,
  "created_at" : "2012-02-02 14:25:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 26, 36 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 55, 68 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHhangout",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "StartupAmerica",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/WB9RTp8F",
      "expanded_url" : "http:\/\/owl.li\/8OPS4",
      "display_url" : "owl.li\/8OPS4"
    } ]
  },
  "geo" : { },
  "id_str" : "164886007886520320",
  "text" : "RT @SBAgov: #WHhangout w\/ @SteveCase + Gene Sperling & @aneeshchopra tomorrow! Click http:\/\/t.co\/WB9RTp8F to submit your #StartupAmerica Qs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 14, 24 ],
        "id_str" : "6708952",
        "id" : 6708952
      }, {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 43, 56 ],
        "id_str" : "121539516",
        "id" : 121539516
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHhangout",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "StartupAmerica",
        "indices" : [ 109, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/WB9RTp8F",
        "expanded_url" : "http:\/\/owl.li\/8OPS4",
        "display_url" : "owl.li\/8OPS4"
      } ]
    },
    "geo" : { },
    "id_str" : "164850545700503552",
    "text" : "#WHhangout w\/ @SteveCase + Gene Sperling & @aneeshchopra tomorrow! Click http:\/\/t.co\/WB9RTp8F to submit your #StartupAmerica Qs",
    "id" : 164850545700503552,
    "created_at" : "2012-02-01 23:20:07 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 164886007886520320,
  "created_at" : "2012-02-02 01:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 7, 17 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 71, 84 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHhangout",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/YolWcTEb",
      "expanded_url" : "http:\/\/youtu.be\/QyAdY-BN3t8?t=25s",
      "display_url" : "youtu.be\/QyAdY-BN3t8?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164883430771924992",
  "text" : "Watch: @stevecase on Startup America: http:\/\/t.co\/YolWcTEb Join Steve, @aneeshchopra & Gene Sperling for a #WHhangout via Google+ on 2\/2",
  "id" : 164883430771924992,
  "created_at" : "2012-02-02 01:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Pd2xM7Z2",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/02\/01\/health-reform-preventive-services-and-religious-institutions",
      "display_url" : "whitehouse.gov\/blog\/2012\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164861076004020225",
  "text" : "RT @jesseclee44: Cecilia Mu\u00F1oz on the WH blog: Health Reform, Preventive Services, and Religious Institutions http:\/\/t.co\/Pd2xM7Z2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Pd2xM7Z2",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/02\/01\/health-reform-preventive-services-and-religious-institutions",
        "display_url" : "whitehouse.gov\/blog\/2012\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164859075140648962",
    "text" : "Cecilia Mu\u00F1oz on the WH blog: Health Reform, Preventive Services, and Religious Institutions http:\/\/t.co\/Pd2xM7Z2",
    "id" : 164859075140648962,
    "created_at" : "2012-02-01 23:54:01 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 164861076004020225,
  "created_at" : "2012-02-02 00:01:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 30, 40 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 43, 56 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 69, 84 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHhangout",
      "indices" : [ 4, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/zoY7HK1Y",
      "expanded_url" : "http:\/\/ow.ly\/8Oykk",
      "display_url" : "ow.ly\/8Oykk"
    } ]
  },
  "geo" : { },
  "id_str" : "164790991491043329",
  "text" : "New #WHhangout: Gene Sperling @stevecase & @aneeshchopra answer your @startupamerica questions live via Google+ on 2\/2: http:\/\/t.co\/zoY7HK1Y",
  "id" : 164790991491043329,
  "created_at" : "2012-02-01 19:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164784140816875520",
  "text" : "RT @pfeiffer44: The draft simplified simplified mortgage disclosure that President Obama held up today can be found here. http:\/\/t.co\/js ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/jshxDHu3",
        "expanded_url" : "http:\/\/1.usa.gov\/xdZNQR",
        "display_url" : "1.usa.gov\/xdZNQR"
      } ]
    },
    "geo" : { },
    "id_str" : "164752717380718593",
    "text" : "The draft simplified simplified mortgage disclosure that President Obama held up today can be found here. http:\/\/t.co\/jshxDHu3",
    "id" : 164752717380718593,
    "created_at" : "2012-02-01 16:51:23 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 164784140816875520,
  "created_at" : "2012-02-01 18:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 1, 6 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/m3Ia2lx9",
      "expanded_url" : "http:\/\/ow.ly\/8Ook9",
      "display_url" : "ow.ly\/8Ook9"
    } ]
  },
  "geo" : { },
  "id_str" : "164763852309921792",
  "text" : ".@CFPB Director Richard Cordray's responds to administration housing announcement: http:\/\/t.co\/m3Ia2lx9",
  "id" : 164763852309921792,
  "created_at" : "2012-02-01 17:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164751273277661186",
  "text" : "RT @VP: \"Because of you workers on this floor, America is coming back. You\u2019re bringing us back\"-VP @ American Seating Co in Grand Rapids ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Michigan",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164749955012116481",
    "text" : "\"Because of you workers on this floor, America is coming back. You\u2019re bringing us back\"-VP @ American Seating Co in Grand Rapids, #Michigan",
    "id" : 164749955012116481,
    "created_at" : "2012-02-01 16:40:24 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 164751273277661186,
  "created_at" : "2012-02-01 16:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164750007046635521",
  "text" : "RT @VP: \"The most important thing we can do to help? Education...62% of all the jobs in the next 10 yrs are going to require a degree\"-VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164749555815038978",
    "text" : "\"The most important thing we can do to help? Education...62% of all the jobs in the next 10 yrs are going to require a degree\"-VP",
    "id" : 164749555815038978,
    "created_at" : "2012-02-01 16:38:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 164750007046635521,
  "created_at" : "2012-02-01 16:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164722386690781185",
  "text" : "RT @jesseclee44: Fact sheet on Obama\u2019s plan to help responsible homeowners & the housing market, how it will affect real families http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/AppwPIek",
        "expanded_url" : "http:\/\/wh.gov\/kZp",
        "display_url" : "wh.gov\/kZp"
      } ]
    },
    "geo" : { },
    "id_str" : "164721299221004288",
    "text" : "Fact sheet on Obama\u2019s plan to help responsible homeowners & the housing market, how it will affect real families http:\/\/t.co\/AppwPIek",
    "id" : 164721299221004288,
    "created_at" : "2012-02-01 14:46:32 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 164722386690781185,
  "created_at" : "2012-02-01 14:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164710351034781696",
  "text" : "RT @pfeiffer44: President Obama heads to Northern Virginia today to talk about new efforts to help responsible homeowners",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164687082525167616",
    "text" : "President Obama heads to Northern Virginia today to talk about new efforts to help responsible homeowners",
    "id" : 164687082525167616,
    "created_at" : "2012-02-01 12:30:34 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 164710351034781696,
  "created_at" : "2012-02-01 14:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]