Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/SlujGc9abI",
      "expanded_url" : "http:\/\/youtu.be\/knRgWvrznFQ",
      "display_url" : "youtu.be\/knRgWvrznFQ"
    } ]
  },
  "geo" : { },
  "id_str" : "494980527087439872",
  "text" : "President Obama.\nMom and pop shops.\nAnd a stroll down Main Street.\nWatch \u2192 http:\/\/t.co\/SlujGc9abI",
  "id" : 494980527087439872,
  "created_at" : "2014-07-31 22:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EbOgDG6jUp",
      "expanded_url" : "http:\/\/go.wh.gov\/fkCdbk",
      "display_url" : "go.wh.gov\/fkCdbk"
    } ]
  },
  "geo" : { },
  "id_str" : "494958708213153792",
  "text" : "Ice tea \u2714\nOatmeal raisin cookies \u2714\nVintage watches \u2714\nTake a walk down Main St. with President Obama in Parkville, MO: http:\/\/t.co\/EbOgDG6jUp",
  "id" : 494958708213153792,
  "created_at" : "2014-07-31 21:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/LoSIWlx6cG",
      "expanded_url" : "http:\/\/bit.ly\/1oeSBFh",
      "display_url" : "bit.ly\/1oeSBFh"
    } ]
  },
  "geo" : { },
  "id_str" : "494950340035239936",
  "text" : "Good news: CA will see low health insurance rate increases in 2015 thanks in part to the Affordable Care Act \u2192 http:\/\/t.co\/LoSIWlx6cG",
  "id" : 494950340035239936,
  "created_at" : "2014-07-31 20:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494934606521851905",
  "text" : "RT @WHLive: \"There's no better feeling on Earth than\u2026knowing that you played a small part in helping a family succeed.\" \u2014President Obama at\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 128, 135 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494934551123492864",
    "text" : "\"There's no better feeling on Earth than\u2026knowing that you played a small part in helping a family succeed.\" \u2014President Obama at @HUDGov",
    "id" : 494934551123492864,
    "created_at" : "2014-07-31 19:56:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494934606521851905,
  "created_at" : "2014-07-31 19:56:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 85, 92 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494933437720322048",
  "text" : "RT @WHLive: \"Home prices, homes sales and construction, all up.\" \u2014President Obama at @HUDGov on the progress our housing market has made",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 73, 80 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494933411895984128",
    "text" : "\"Home prices, homes sales and construction, all up.\" \u2014President Obama at @HUDGov on the progress our housing market has made",
    "id" : 494933411895984128,
    "created_at" : "2014-07-31 19:51:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494933437720322048,
  "created_at" : "2014-07-31 19:51:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 53, 60 ],
      "id_str" : "19948202",
      "id" : 19948202
    }, {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 66, 82 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/LptqBPR63Y",
      "expanded_url" : "http:\/\/go.wh.gov\/F8XEgf",
      "display_url" : "go.wh.gov\/F8XEgf"
    } ]
  },
  "geo" : { },
  "id_str" : "494931730961563648",
  "text" : "RT @WHLive: Happening now: President Obama speaks at @HUDGov with @SecretaryCastro. Watch \u2192 http:\/\/t.co\/LptqBPR63Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 41, 48 ],
        "id_str" : "19948202",
        "id" : 19948202
      }, {
        "name" : "Juli\u00E1n Castro",
        "screen_name" : "SecretaryCastro",
        "indices" : [ 54, 70 ],
        "id_str" : "2695663285",
        "id" : 2695663285
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/LptqBPR63Y",
        "expanded_url" : "http:\/\/go.wh.gov\/F8XEgf",
        "display_url" : "go.wh.gov\/F8XEgf"
      } ]
    },
    "geo" : { },
    "id_str" : "494931698690580480",
    "text" : "Happening now: President Obama speaks at @HUDGov with @SecretaryCastro. Watch \u2192 http:\/\/t.co\/LptqBPR63Y",
    "id" : 494931698690580480,
    "created_at" : "2014-07-31 19:44:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494931730961563648,
  "created_at" : "2014-07-31 19:44:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494910535725375490",
  "text" : "RT @pfeiffer44: And by pulling their own bill, the House GOP once again proves why the President must act on his own to solve problems",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494909676711325697",
    "text" : "And by pulling their own bill, the House GOP once again proves why the President must act on his own to solve problems",
    "id" : 494909676711325697,
    "created_at" : "2014-07-31 18:17:16 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 494910535725375490,
  "created_at" : "2014-07-31 18:20:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 70, 77 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494908173732814848",
  "text" : "RT @SecretaryCastro: Look forward to welcoming President Obama to the @HUDgov headquarters today. Can\u2019t wait for him to meet our great empl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 49, 56 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494880026081624064",
    "text" : "Look forward to welcoming President Obama to the @HUDgov headquarters today. Can\u2019t wait for him to meet our great employees.",
    "id" : 494880026081624064,
    "created_at" : "2014-07-31 16:19:27 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 494908173732814848,
  "created_at" : "2014-07-31 18:11:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceFairness",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/y4ehtHvRUm",
      "expanded_url" : "http:\/\/go.wh.gov\/kXZdMw",
      "display_url" : "go.wh.gov\/kXZdMw"
    } ]
  },
  "geo" : { },
  "id_str" : "494902847348436992",
  "text" : "\"Our tax dollars shouldn\u2019t go to companies that violate workplace laws.\" \u2014President Obama: http:\/\/t.co\/y4ehtHvRUm #WorkplaceFairness",
  "id" : 494902847348436992,
  "created_at" : "2014-07-31 17:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494902199219392512\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/caVtEWnmGO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt4-7XeIQAADvtS.jpg",
      "id_str" : "494902198690922496",
      "id" : 494902198690922496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt4-7XeIQAADvtS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/caVtEWnmGO"
    } ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494902199219392512",
  "text" : "\"Think about how much further along we\u2019d be if Congress would do its job.\" \u2014President Obama #DoYourJobHouseGOP http:\/\/t.co\/caVtEWnmGO",
  "id" : 494902199219392512,
  "created_at" : "2014-07-31 17:47:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/494901930993254400\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/G6AWmMDQK3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt4-rvFIIAML1Cn.jpg",
      "id_str" : "494901930150600707",
      "id" : 494901930150600707,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt4-rvFIIAML1Cn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G6AWmMDQK3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494901930993254400",
  "text" : "\"We acted to give millions of Americans the chance to cap their student loan payments at 10% of their income\" \u2014Obama http:\/\/t.co\/G6AWmMDQK3",
  "id" : 494901930993254400,
  "created_at" : "2014-07-31 17:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494901651095191553\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/tPA4yiLVku",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt4-bcyIIAAf9Nq.jpg",
      "id_str" : "494901650361163776",
      "id" : 494901650361163776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt4-bcyIIAAf9Nq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tPA4yiLVku"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 21, 34 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494901651095191553",
  "text" : "\"I believe that when #WomenSucceed, America succeeds.\" \u2014President Obama on fighting for #EqualPay for women http:\/\/t.co\/tPA4yiLVku",
  "id" : 494901651095191553,
  "created_at" : "2014-07-31 17:45:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494901503447302145",
  "text" : "RT @WHLive: \"This year, we\u2019ve made sure more women have the protections they need to fight for fair pay in the workplace\" \u2014Obama #EqualPay \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 117, 126 ]
      }, {
        "text" : "WomenSucceed",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494901425978097666",
    "text" : "\"This year, we\u2019ve made sure more women have the protections they need to fight for fair pay in the workplace\" \u2014Obama #EqualPay #WomenSucceed",
    "id" : 494901425978097666,
    "created_at" : "2014-07-31 17:44:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494901503447302145,
  "created_at" : "2014-07-31 17:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494901164161654784",
  "text" : "#OpportunityForAll = \"Making sure the young dad on the factory floor has a shot to make it to the corner suite.\" \u2014President Obama",
  "id" : 494901164161654784,
  "created_at" : "2014-07-31 17:43:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494900713584353280\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/B2Ou5aR2q1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt49k5IIcAAueUm.jpg",
      "id_str" : "494900713076846592",
      "id" : 494900713076846592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt49k5IIcAAueUm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/B2Ou5aR2q1"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494900713584353280",
  "text" : "President Obama: \"Our businesses have created nearly 10 million new jobs over the past 52 months.\" #ActOnJobs http:\/\/t.co\/B2Ou5aR2q1",
  "id" : 494900713584353280,
  "created_at" : "2014-07-31 17:41:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceFairness",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494900586400067586",
  "text" : "RT @WHLive: Watch live: President Obama acts to help more Americans get the fair pay and #WorkplaceFairness they deserve: http:\/\/t.co\/6bgkg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkplaceFairness",
        "indices" : [ 77, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/6bgkgblK0d",
        "expanded_url" : "http:\/\/go.wh.gov\/ZWvCbT",
        "display_url" : "go.wh.gov\/ZWvCbT"
      } ]
    },
    "geo" : { },
    "id_str" : "494900555248979968",
    "text" : "Watch live: President Obama acts to help more Americans get the fair pay and #WorkplaceFairness they deserve: http:\/\/t.co\/6bgkgblK0d",
    "id" : 494900555248979968,
    "created_at" : "2014-07-31 17:41:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494900586400067586,
  "created_at" : "2014-07-31 17:41:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceFairness",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/oXKC2SwB7l",
      "expanded_url" : "http:\/\/go.wh.gov\/ZWvCbT",
      "display_url" : "go.wh.gov\/ZWvCbT"
    } ]
  },
  "geo" : { },
  "id_str" : "494893909844447233",
  "text" : "At 1:20pm ET, watch President Obama act to help more Americans get the fair pay and #WorkplaceFairness they deserve: http:\/\/t.co\/oXKC2SwB7l",
  "id" : 494893909844447233,
  "created_at" : "2014-07-31 17:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BornIn88",
      "indices" : [ 10, 19 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 87, 98 ]
    }, {
      "text" : "TBT",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/whMQDqVLdh",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "494880571857059841",
  "text" : "RT @vj44: #BornIn88? You may not rock shoulder pads like me at 26\u2014but you should still #GetCovered http:\/\/t.co\/whMQDqVLdh #TBT http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/494879367114555392\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/UkpdTgyI9F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt4qKTGCUAAO_gh.jpg",
        "id_str" : "494879365469982720",
        "id" : 494879365469982720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt4qKTGCUAAO_gh.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UkpdTgyI9F"
      } ],
      "hashtags" : [ {
        "text" : "BornIn88",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 77, 88 ]
      }, {
        "text" : "TBT",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/whMQDqVLdh",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "494879367114555392",
    "text" : "#BornIn88? You may not rock shoulder pads like me at 26\u2014but you should still #GetCovered http:\/\/t.co\/whMQDqVLdh #TBT http:\/\/t.co\/UkpdTgyI9F",
    "id" : 494879367114555392,
    "created_at" : "2014-07-31 16:16:50 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 494880571857059841,
  "created_at" : "2014-07-31 16:21:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bornin88",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 108, 119 ]
    }, {
      "text" : "TBT",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494872325062656000",
  "text" : "RT @VP: Short sleeve button-downs are coming back but health care has always been in style. #Bornin88? Then #GetCovered. #TBT http:\/\/t.co\/X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/494866872194441217\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/XeMmUPC2Go",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt4eyrwCMAIb2qP.png",
        "id_str" : "494866865143820290",
        "id" : 494866865143820290,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt4eyrwCMAIb2qP.png",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XeMmUPC2Go"
      } ],
      "hashtags" : [ {
        "text" : "Bornin88",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 100, 111 ]
      }, {
        "text" : "TBT",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494866872194441217",
    "text" : "Short sleeve button-downs are coming back but health care has always been in style. #Bornin88? Then #GetCovered. #TBT http:\/\/t.co\/XeMmUPC2Go",
    "id" : 494866872194441217,
    "created_at" : "2014-07-31 15:27:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 494872325062656000,
  "created_at" : "2014-07-31 15:48:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceFairness",
      "indices" : [ 81, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/y4ehtHvRUm",
      "expanded_url" : "http:\/\/go.wh.gov\/kXZdMw",
      "display_url" : "go.wh.gov\/kXZdMw"
    } ]
  },
  "geo" : { },
  "id_str" : "494864334850637824",
  "text" : "President Obama's acting to help more hardworking Americans get the fair pay and #WorkplaceFairness they deserve \u2192 http:\/\/t.co\/y4ehtHvRUm",
  "id" : 494864334850637824,
  "created_at" : "2014-07-31 15:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 60, 67 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SecretaryCastro\/status\/494832115532701696\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/gwcsUEz4lG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt3_L2EIcAEZenN.jpg",
      "id_str" : "494832113037111297",
      "id" : 494832113037111297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt3_L2EIcAEZenN.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gwcsUEz4lG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494856730778423296",
  "text" : "RT @SecretaryCastro: Done deal. Ready to get to work as the @HUDgov Secretary! http:\/\/t.co\/gwcsUEz4lG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 39, 46 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryCastro\/status\/494832115532701696\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/gwcsUEz4lG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt3_L2EIcAEZenN.jpg",
        "id_str" : "494832113037111297",
        "id" : 494832113037111297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt3_L2EIcAEZenN.jpg",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/gwcsUEz4lG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494832115532701696",
    "text" : "Done deal. Ready to get to work as the @HUDgov Secretary! http:\/\/t.co\/gwcsUEz4lG",
    "id" : 494832115532701696,
    "created_at" : "2014-07-31 13:09:04 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 494856730778423296,
  "created_at" : "2014-07-31 14:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceFairness",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/y4ehtHvRUm",
      "expanded_url" : "http:\/\/go.wh.gov\/kXZdMw",
      "display_url" : "go.wh.gov\/kXZdMw"
    } ]
  },
  "geo" : { },
  "id_str" : "494853861971333121",
  "text" : "Taxpayer $ shouldn't reward corporations that break the law, so President Obama is taking action: http:\/\/t.co\/y4ehtHvRUm #WorkplaceFairness",
  "id" : 494853861971333121,
  "created_at" : "2014-07-31 14:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 109, 120 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/FsgJfPEISF",
      "expanded_url" : "http:\/\/go.wh.gov\/BC3USQ",
      "display_url" : "go.wh.gov\/BC3USQ"
    } ]
  },
  "geo" : { },
  "id_str" : "494840696914714625",
  "text" : "\"The President is not going to back away from his efforts...to solve problems &amp; help American families\" \u2014@Pfeiffer44: http:\/\/t.co\/FsgJfPEISF",
  "id" : 494840696914714625,
  "created_at" : "2014-07-31 13:43:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parkville Coffee",
      "screen_name" : "ParkvilleCoffee",
      "indices" : [ 3, 19 ],
      "id_str" : "123283210",
      "id" : 123283210
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ParkvilleCoffee\/status\/494540131018092544\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/rpwiLbQcrX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btz1oF5CcAAUAWg.jpg",
      "id_str" : "494540128228896768",
      "id" : 494540128228896768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btz1oF5CcAAUAWg.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rpwiLbQcrX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494634470642040834",
  "text" : "RT @ParkvilleCoffee: President Obama enjoying the coffeehouse! http:\/\/t.co\/rpwiLbQcrX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ParkvilleCoffee\/status\/494540131018092544\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/rpwiLbQcrX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Btz1oF5CcAAUAWg.jpg",
        "id_str" : "494540128228896768",
        "id" : 494540128228896768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btz1oF5CcAAUAWg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rpwiLbQcrX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494540131018092544",
    "text" : "President Obama enjoying the coffeehouse! http:\/\/t.co\/rpwiLbQcrX",
    "id" : 494540131018092544,
    "created_at" : "2014-07-30 17:48:50 +0000",
    "user" : {
      "name" : "Parkville Coffee",
      "screen_name" : "ParkvilleCoffee",
      "protected" : false,
      "id_str" : "123283210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719268561655623680\/nZxgmwS__normal.jpg",
      "id" : 123283210,
      "verified" : false
    }
  },
  "id" : 494634470642040834,
  "created_at" : "2014-07-31 00:03:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 75, 86 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/OYGfnDLLpV",
      "expanded_url" : "http:\/\/go.wh.gov\/BC3USQ",
      "display_url" : "go.wh.gov\/BC3USQ"
    } ]
  },
  "geo" : { },
  "id_str" : "494629746215763969",
  "text" : "\"Instead of doing their job, they are suing the President for doing his.\" \u2014@Pfeiffer44: http:\/\/t.co\/OYGfnDLLpV #DoYourJobHouseGOP",
  "id" : 494629746215763969,
  "created_at" : "2014-07-30 23:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/494625096947212288\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/fN4SlT0KZg",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bt1C5x2CEAABygk.png",
      "id_str" : "494625094480564224",
      "id" : 494625094480564224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bt1C5x2CEAABygk.png",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fN4SlT0KZg"
    } ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494625096947212288",
  "text" : "It's time for the House GOP to join President Obama &amp; help expand opportunity for more Americans. #DoYourJobHouseGOP http:\/\/t.co\/fN4SlT0KZg",
  "id" : 494625096947212288,
  "created_at" : "2014-07-30 23:26:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/y7BxdjBXLO",
      "expanded_url" : "http:\/\/youtu.be\/XUEQJ6anUCc",
      "display_url" : "youtu.be\/XUEQJ6anUCc"
    } ]
  },
  "geo" : { },
  "id_str" : "494592050822533120",
  "text" : "\"Cynicism didn\u2019t put a man on the moon. Cynicism didn\u2019t win women the right to vote.\" \u2014Obama in Kansas City today: http:\/\/t.co\/y7BxdjBXLO",
  "id" : 494592050822533120,
  "created_at" : "2014-07-30 21:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494588090217160704\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/UirfzkZ0uA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt0hP0gIcAAjQt2.jpg",
      "id_str" : "494588089755791360",
      "id" : 494588089755791360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt0hP0gIcAAjQt2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UirfzkZ0uA"
    } ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494588090217160704",
  "text" : "Don't sue, vote to raise the minimum wage so nobody who works full-time has to live in poverty. #DoYourJobHouseGOP http:\/\/t.co\/UirfzkZ0uA",
  "id" : 494588090217160704,
  "created_at" : "2014-07-30 20:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Marc Veasey",
      "screen_name" : "RepVeasey",
      "indices" : [ 3, 13 ],
      "id_str" : "1074129612",
      "id" : 1074129612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494586318093950978",
  "text" : "RT @RepVeasey: Instead of wasting taxpayer dollars on this lawsuit against the President, the GOP should pass the Fair Minimum Wage Act! #D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 122, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494585096347717634",
    "text" : "Instead of wasting taxpayer dollars on this lawsuit against the President, the GOP should pass the Fair Minimum Wage Act! #DoYourJobHouseGOP",
    "id" : 494585096347717634,
    "created_at" : "2014-07-30 20:47:30 +0000",
    "user" : {
      "name" : "Rep. Marc Veasey",
      "screen_name" : "RepVeasey",
      "protected" : false,
      "id_str" : "1074129612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761614028418457600\/j7lOtIzH_normal.jpg",
      "id" : 1074129612,
      "verified" : true
    }
  },
  "id" : 494586318093950978,
  "created_at" : "2014-07-30 20:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "ImmigrationReform",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494582935559749634",
  "text" : "RT @VP: Here's a refresher on the GOP's priorities: \n\u25A1  #EqualPay for women\n\u25A1  Pass #ImmigrationReform \n\u2713 Sue President Obama \n\n#DoYourJobH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 48, 57 ]
      }, {
        "text" : "ImmigrationReform",
        "indices" : [ 76, 94 ]
      }, {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 120, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494582268266950659",
    "text" : "Here's a refresher on the GOP's priorities: \n\u25A1  #EqualPay for women\n\u25A1  Pass #ImmigrationReform \n\u2713 Sue President Obama \n\n#DoYourJobHouseGOP",
    "id" : 494582268266950659,
    "created_at" : "2014-07-30 20:36:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 494582935559749634,
  "created_at" : "2014-07-30 20:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Mike Honda",
      "screen_name" : "RepMikeHonda",
      "indices" : [ 3, 16 ],
      "id_str" : "16583468",
      "id" : 16583468
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RepMikeHonda\/status\/494580237498200064\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/JRp90yHAgY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt0aGmrIEAADwBy.png",
      "id_str" : "494580234843590656",
      "id" : 494580234843590656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt0aGmrIEAADwBy.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JRp90yHAgY"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494580735970275328",
  "text" : "RT @RepMikeHonda: Don't sue, vote to help ensure #EqualPay for women. #DoYourJobHouseGOP http:\/\/t.co\/JRp90yHAgY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepMikeHonda\/status\/494580237498200064\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/JRp90yHAgY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt0aGmrIEAADwBy.png",
        "id_str" : "494580234843590656",
        "id" : 494580234843590656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt0aGmrIEAADwBy.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JRp90yHAgY"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 31, 40 ]
      }, {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 52, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494580237498200064",
    "text" : "Don't sue, vote to help ensure #EqualPay for women. #DoYourJobHouseGOP http:\/\/t.co\/JRp90yHAgY",
    "id" : 494580237498200064,
    "created_at" : "2014-07-30 20:28:12 +0000",
    "user" : {
      "name" : "Rep. Mike Honda",
      "screen_name" : "RepMikeHonda",
      "protected" : false,
      "id_str" : "16583468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769096967167287296\/9OweC5mk_normal.jpg",
      "id" : 16583468,
      "verified" : true
    }
  },
  "id" : 494580735970275328,
  "created_at" : "2014-07-30 20:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494578476339302400\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vvxzFj43yo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt0YgMOIAAAFLjE.jpg",
      "id_str" : "494578475395973120",
      "id" : 494578475395973120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt0YgMOIAAAFLjE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vvxzFj43yo"
    } ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494578476339302400",
  "text" : "Instead of acting to help millions of Americans, House Republicans are suing the President today. #DoYourJobHouseGOP http:\/\/t.co\/vvxzFj43yo",
  "id" : 494578476339302400,
  "created_at" : "2014-07-30 20:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494577948129636352",
  "text" : "RT @NancyPelosi: #DoYourJobHouseGOP Instead of playing political games with a taxpayer funded lawsuit, join Dems to jumpstart economy. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xyuZr4R2Wd",
        "expanded_url" : "http:\/\/dems.gov\/jumpstart",
        "display_url" : "dems.gov\/jumpstart"
      } ]
    },
    "geo" : { },
    "id_str" : "494577029547696128",
    "text" : "#DoYourJobHouseGOP Instead of playing political games with a taxpayer funded lawsuit, join Dems to jumpstart economy. http:\/\/t.co\/xyuZr4R2Wd",
    "id" : 494577029547696128,
    "created_at" : "2014-07-30 20:15:27 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 494577948129636352,
  "created_at" : "2014-07-30 20:19:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Congressmember Bass",
      "screen_name" : "RepKarenBass",
      "indices" : [ 3, 16 ],
      "id_str" : "239949176",
      "id" : 239949176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 107, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494576551254425600",
  "text" : "RT @RepKarenBass: Congress has too much work left to do to focus on a ridiculous lawsuit. RT if you agree. #DoYourJobHouseGOP http:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepKarenBass\/status\/494575553081389056\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/BfeVvSzu5S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt0V2CRIIAAxC_F.jpg",
        "id_str" : "494575552146448384",
        "id" : 494575552146448384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt0V2CRIIAAxC_F.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BfeVvSzu5S"
      } ],
      "hashtags" : [ {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 89, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494575553081389056",
    "text" : "Congress has too much work left to do to focus on a ridiculous lawsuit. RT if you agree. #DoYourJobHouseGOP http:\/\/t.co\/BfeVvSzu5S",
    "id" : 494575553081389056,
    "created_at" : "2014-07-30 20:09:35 +0000",
    "user" : {
      "name" : "Congressmember Bass",
      "screen_name" : "RepKarenBass",
      "protected" : false,
      "id_str" : "239949176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605458297475317761\/P1AjUUex_normal.jpg",
      "id" : 239949176,
      "verified" : true
    }
  },
  "id" : 494576551254425600,
  "created_at" : "2014-07-30 20:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Schakowsky",
      "screen_name" : "janschakowsky",
      "indices" : [ 3, 17 ],
      "id_str" : "24195214",
      "id" : 24195214
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 36, 51 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "middleclassfirst",
      "indices" : [ 75, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494576172743659520",
  "text" : "RT @janschakowsky: RT if you agree. @SpeakerBoehner should join Ds to pass #middleclassfirst agenda instead of wasting taxpayer $ on lawsui\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 17, 32 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "middleclassfirst",
        "indices" : [ 56, 73 ]
      }, {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 122, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494574484083724288",
    "text" : "RT if you agree. @SpeakerBoehner should join Ds to pass #middleclassfirst agenda instead of wasting taxpayer $ on lawsuit #DoYourJobHouseGOP",
    "id" : 494574484083724288,
    "created_at" : "2014-07-30 20:05:20 +0000",
    "user" : {
      "name" : "Jan Schakowsky",
      "screen_name" : "janschakowsky",
      "protected" : false,
      "id_str" : "24195214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778943630123958276\/Tg3a8mgI_normal.jpg",
      "id" : 24195214,
      "verified" : true
    }
  },
  "id" : 494576172743659520,
  "created_at" : "2014-07-30 20:12:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494567840394268672\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8znaLJWwma",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt0O1IRIYAA0bv7.jpg",
      "id_str" : "494567839995813888",
      "id" : 494567839995813888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt0O1IRIYAA0bv7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/8znaLJWwma"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/j7RkVTgQiP",
      "expanded_url" : "http:\/\/go.wh.gov\/UAhRam",
      "display_url" : "go.wh.gov\/UAhRam"
    } ]
  },
  "geo" : { },
  "id_str" : "494567840394268672",
  "text" : "Happy 49th birthday to Medicare and Medicaid! http:\/\/t.co\/j7RkVTgQiP http:\/\/t.co\/8znaLJWwma",
  "id" : 494567840394268672,
  "created_at" : "2014-07-30 19:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494547169610067968\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dzmZT3yxXq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btz8B7fIAAAp2jk.jpg",
      "id_str" : "494547169182220288",
      "id" : 494547169182220288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btz8B7fIAAAp2jk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dzmZT3yxXq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/IToblufvUi",
      "expanded_url" : "http:\/\/go.wh.gov\/BaV3N4",
      "display_url" : "go.wh.gov\/BaV3N4"
    } ]
  },
  "geo" : { },
  "id_str" : "494547169610067968",
  "text" : "FACT: Growth in consumer spending and business investment picked up last quarter \u2192 http:\/\/t.co\/IToblufvUi http:\/\/t.co\/dzmZT3yxXq",
  "id" : 494547169610067968,
  "created_at" : "2014-07-30 18:16:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494523641561108480",
  "text" : "\u201CI believe in an optimistic America. You don\u2019t have time to be cynical. Hope is a better choice.\u201D \u2014President Obama #OpportunityForAll",
  "id" : 494523641561108480,
  "created_at" : "2014-07-30 16:43:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494522837831790592",
  "text" : "\"Cynicism didn\u2019t put a man on the moon. Cynicism has never won a war. Cynicism didn\u2019t get women the right to vote.\" \u2014President Obama",
  "id" : 494522837831790592,
  "created_at" : "2014-07-30 16:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494522561796268032",
  "text" : "\"Let\u2019s make sure that anybody who\u2019s working full-time doesn\u2019t have to live in poverty.\" \u2014President Obama #RaiseTheWage",
  "id" : 494522561796268032,
  "created_at" : "2014-07-30 16:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494522189782450176",
  "text" : "\"Instead tax breaks for folks who don\u2019t need them, let\u2019s give more tax breaks to help working families.\" \u2014President Obama",
  "id" : 494522189782450176,
  "created_at" : "2014-07-30 16:37:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494522123625705472",
  "text" : "RT @pfeiffer44: POTUS just pointed out that the House GOP is going to vote today to bill YOU the American taxpayer for their pointless poli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494521874554949633",
    "text" : "POTUS just pointed out that the House GOP is going to vote today to bill YOU the American taxpayer for their pointless political lawsuit",
    "id" : 494521874554949633,
    "created_at" : "2014-07-30 16:36:17 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 494522123625705472,
  "created_at" : "2014-07-30 16:37:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494521195573035009",
  "text" : "\"Instead of suing me for doing my job, I want Congress to do its job and make life a little better for...Americans.\" \u2014President Obama",
  "id" : 494521195573035009,
  "created_at" : "2014-07-30 16:33:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494520532604575744",
  "text" : "\u201CDo not boo, vote! Booing doesn\u2019t help\u2014voting helps.\u201D \u2014Obama after telling the crowd about the House GOP's plan to sue him for doing his job",
  "id" : 494520532604575744,
  "created_at" : "2014-07-30 16:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494520094253654017",
  "text" : "\u201CStop being mad all the time. Stop just hatin\u2019 all the time\u2026let\u2019s get some work done together.\u201D \u2014President Obama to Republicans in Congress",
  "id" : 494520094253654017,
  "created_at" : "2014-07-30 16:29:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494519774026944512\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/LXc8tKHV3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtzjHSrIIAASH6U.jpg",
      "id_str" : "494519773515227136",
      "id" : 494519773515227136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtzjHSrIIAASH6U.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LXc8tKHV3m"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494519774026944512",
  "text" : "\u201CAmerica deserves a raise, and it\u2019s good for everyone.\u201D \u2014President Obama #RaiseTheWage http:\/\/t.co\/LXc8tKHV3m",
  "id" : 494519774026944512,
  "created_at" : "2014-07-30 16:27:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 89, 102 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494519613439623168",
  "text" : "\u201CI want my daughters to have the same opportunities as anybody\u2019s sons.\u201D \u2014President Obama #WomenSucceed #EqualPay",
  "id" : 494519613439623168,
  "created_at" : "2014-07-30 16:27:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494519183712190464\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/c0YnW71dqg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btzik7jIgAAdXGJ.jpg",
      "id_str" : "494519183192129536",
      "id" : 494519183192129536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btzik7jIgAAdXGJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c0YnW71dqg"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494519183712190464",
  "text" : "\"I believe that when women succeed, America succeeds.\" \u2014Obama on why Congress should help ensure #EqualPay for women http:\/\/t.co\/c0YnW71dqg",
  "id" : 494519183712190464,
  "created_at" : "2014-07-30 16:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494518826697256960",
  "text" : "RT @WHLive: \"They said 'no' to raising the minimum wage. They said 'no' to fair pay for women.\" \u2014President Obama on Republicans in Congress",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494518805000126464",
    "text" : "\"They said 'no' to raising the minimum wage. They said 'no' to fair pay for women.\" \u2014President Obama on Republicans in Congress",
    "id" : 494518805000126464,
    "created_at" : "2014-07-30 16:24:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494518826697256960,
  "created_at" : "2014-07-30 16:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494517815182110723",
  "text" : "\"You\u2019re doing your job. Imagine how much farther along we'd be if Congress was doing its job, too.\" \u2014President Obama in Kansas City",
  "id" : 494517815182110723,
  "created_at" : "2014-07-30 16:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494517402269679616",
  "text" : "\"What I really want is somebody who has worked for 20, 30 years being able to retire with some digity and respect.\" \u2014President Obama",
  "id" : 494517402269679616,
  "created_at" : "2014-07-30 16:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494516509235224576\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/yIMxZlatlF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtzgJOHIMAE2H5C.jpg",
      "id_str" : "494516508115349505",
      "id" : 494516508115349505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtzgJOHIMAE2H5C.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yIMxZlatlF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494516509235224576",
  "text" : "\"We have fought back...our businesses have added nearly 10 million new jobs over the past 52 months.\" \u2014Obama http:\/\/t.co\/yIMxZlatlF",
  "id" : 494516509235224576,
  "created_at" : "2014-07-30 16:14:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494516251407163392",
  "text" : "\u201CThat\u2019s why I ran for President in the first place.\u201D \u2014Obama on fighting for folks who work hard and just want a chance to get ahead",
  "id" : 494516251407163392,
  "created_at" : "2014-07-30 16:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494515595573198849",
  "text" : "\"Last week, a young girl wrote to ask why there aren\u2019t women on our currency, and then she gave me a long list.\" \u2014Obama #WomenSucceed",
  "id" : 494515595573198849,
  "created_at" : "2014-07-30 16:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494515344707698688",
  "text" : "\"Every night, I read ten letters...folks tell me their stories\u2014and their hopes and their worries.\" \u2014President Obama",
  "id" : 494515344707698688,
  "created_at" : "2014-07-30 16:10:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/eebWwiFkoL",
      "expanded_url" : "http:\/\/go.wh.gov\/Ux52PU",
      "display_url" : "go.wh.gov\/Ux52PU"
    } ]
  },
  "geo" : { },
  "id_str" : "494514470816083968",
  "text" : "Happening now: President Obama speaks in Kansas City on expanding opportunity for more Americans \u2192 http:\/\/t.co\/eebWwiFkoL",
  "id" : 494514470816083968,
  "created_at" : "2014-07-30 16:06:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/eebWwiFkoL",
      "expanded_url" : "http:\/\/go.wh.gov\/Ux52PU",
      "display_url" : "go.wh.gov\/Ux52PU"
    } ]
  },
  "geo" : { },
  "id_str" : "494511283602214913",
  "text" : "Watch President Obama speak at 12pm ET in Kansas City on expanding opportunity for more Americans: http:\/\/t.co\/eebWwiFkoL #OpportunityForAll",
  "id" : 494511283602214913,
  "created_at" : "2014-07-30 15:54:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494504169622208512",
  "text" : "RT @PressSec: We've got a half hour before POTUS speaks in KC, my hometown. That's as good an excuse as any to take a few q's.  Fire away! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494503789580537856",
    "text" : "We've got a half hour before POTUS speaks in KC, my hometown. That's as good an excuse as any to take a few q's.  Fire away! #AskPressSec",
    "id" : 494503789580537856,
    "created_at" : "2014-07-30 15:24:25 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 494504169622208512,
  "created_at" : "2014-07-30 15:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494502928577990656",
  "text" : "RT @vj44: \"When girls aren\u2019t educated, that doesnt just limit their prospects\u2026it limits the prospects of their families and countries as we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 133, 140 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "494500725074829315",
    "text" : "\"When girls aren\u2019t educated, that doesnt just limit their prospects\u2026it limits the prospects of their families and countries as well\" @FLOTUS",
    "id" : 494500725074829315,
    "created_at" : "2014-07-30 15:12:14 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 494502928577990656,
  "created_at" : "2014-07-30 15:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/494478116241145858\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/jhXHmTuKzO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bty9OcKCIAI6mfB.jpg",
      "id_str" : "494478114878005250",
      "id" : 494478114878005250,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bty9OcKCIAI6mfB.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 911
      } ],
      "display_url" : "pic.twitter.com\/jhXHmTuKzO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/IToblufvUi",
      "expanded_url" : "http:\/\/go.wh.gov\/BaV3N4",
      "display_url" : "go.wh.gov\/BaV3N4"
    } ]
  },
  "geo" : { },
  "id_str" : "494495722201710592",
  "text" : "Good news: Our economy grew at a 4% rate last quarter, but there's more work to do \u2192 http:\/\/t.co\/IToblufvUi http:\/\/t.co\/jhXHmTuKzO",
  "id" : 494495722201710592,
  "created_at" : "2014-07-30 14:52:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 115, 128 ]
    }, {
      "text" : "YALI2014",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/JMkJRHPCbg",
      "expanded_url" : "http:\/\/youtu.be\/TY0jH6dk-ew",
      "display_url" : "youtu.be\/TY0jH6dk-ew"
    } ]
  },
  "geo" : { },
  "id_str" : "494225343021346816",
  "text" : "\u201CIf you\u2019re a strong man, you should not feel threatened by strong women.\u201D \u2014President Obama: http:\/\/t.co\/JMkJRHPCbg #WomenSucceed #YALI2014",
  "id" : 494225343021346816,
  "created_at" : "2014-07-29 20:57:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 93, 108 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/494215593848238080\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3K25CEskuF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtvOdoHIgAAlp2B.png",
      "id_str" : "494215592506064896",
      "id" : 494215592506064896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtvOdoHIgAAlp2B.png",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 1018
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 104,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3K25CEskuF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494215593848238080",
  "text" : "\"I applaud the overwhelming bipartisan confirmation of Bob McDonald as our next Secretary of @DeptVetAffairs\" \u2014Obama http:\/\/t.co\/3K25CEskuF",
  "id" : 494215593848238080,
  "created_at" : "2014-07-29 20:19:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "494205486770978816",
  "text" : "Watch live: President Obama delivers a statement on the situation in Ukraine \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 494205486770978816,
  "created_at" : "2014-07-29 19:39:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "494191743588642816",
  "text" : "At 2:50pm ET, President Obama will deliver a statement on the situation in Ukraine. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 494191743588642816,
  "created_at" : "2014-07-29 18:44:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/GZ6F7BLcvq",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/the_cost_of_delaying_action_to_stem_climate_change.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494189406279200768",
  "text" : "RT @CEAChair: Here to answer questions on our new report on the cost of waiting to deal with climate change: http:\/\/t.co\/GZ6F7BLcvq #WhiteH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhiteHouseClimateChat",
        "indices" : [ 118, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/GZ6F7BLcvq",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/the_cost_of_delaying_action_to_stem_climate_change.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494189228390371328",
    "text" : "Here to answer questions on our new report on the cost of waiting to deal with climate change: http:\/\/t.co\/GZ6F7BLcvq #WhiteHouseClimateChat",
    "id" : 494189228390371328,
    "created_at" : "2014-07-29 18:34:28 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 494189406279200768,
  "created_at" : "2014-07-29 18:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 46, 55 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/494187421215768576\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w4T3SpFaFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btu010DIIAA44Zj.jpg",
      "id_str" : "494187420725026816",
      "id" : 494187420725026816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btu010DIIAA44Zj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w4T3SpFaFi"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 27, 40 ]
    }, {
      "text" : "WHClimateChat",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494187421215768576",
  "text" : "We can't afford to wait to #ActOnClimate.\nAsk @CEAChair your Q's on the impacts of delaying action w\/ #WHClimateChat. http:\/\/t.co\/w4T3SpFaFi",
  "id" : 494187421215768576,
  "created_at" : "2014-07-29 18:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/VcfiE8DFRE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/07\/29\/new-report-cost-delaying-action-stem-climate-change",
      "display_url" : "whitehouse.gov\/blog\/2014\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "494183587223064576",
  "text" : "RT @CEAChair: blog post on the Cost of Delaying Action to Stem Climate Change http:\/\/t.co\/VcfiE8DFRE; will answer your questions in 20 min \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHClimateChat",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/VcfiE8DFRE",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/07\/29\/new-report-cost-delaying-action-stem-climate-change",
        "display_url" : "whitehouse.gov\/blog\/2014\/07\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "494182717123067904",
    "text" : "blog post on the Cost of Delaying Action to Stem Climate Change http:\/\/t.co\/VcfiE8DFRE; will answer your questions in 20 min  #WHClimateChat",
    "id" : 494182717123067904,
    "created_at" : "2014-07-29 18:08:35 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 494183587223064576,
  "created_at" : "2014-07-29 18:12:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 12, 21 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494182704284725248",
  "text" : "RT @USDOL: .@LaborSec Perez gets a lesson in wind turbine safety at the Toledo Electrical Apprenticeship &amp; Training facility https:\/\/t.co\/G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 1, 10 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/GBHMBWraGY",
        "expanded_url" : "https:\/\/vine.co\/v\/MEKZ395aUqI",
        "display_url" : "vine.co\/v\/MEKZ395aUqI"
      } ]
    },
    "geo" : { },
    "id_str" : "494179410203795459",
    "text" : ".@LaborSec Perez gets a lesson in wind turbine safety at the Toledo Electrical Apprenticeship &amp; Training facility https:\/\/t.co\/GBHMBWraGY",
    "id" : 494179410203795459,
    "created_at" : "2014-07-29 17:55:27 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 494182704284725248,
  "created_at" : "2014-07-29 18:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 16, 25 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494171377461907456",
  "text" : "RT @WHLive: Ask @CEAChair your Q's on climate change &amp; the cost of inaction with #WHClimateChat.\nHe'll answer some at 2:30pm ET: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Furman",
        "screen_name" : "CEAChair",
        "indices" : [ 4, 13 ],
        "id_str" : "1861751828",
        "id" : 1861751828
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHClimateChat",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/SKou8JfYNH",
        "expanded_url" : "http:\/\/go.wh.gov\/eGS66h",
        "display_url" : "go.wh.gov\/eGS66h"
      } ]
    },
    "geo" : { },
    "id_str" : "494171352518373376",
    "text" : "Ask @CEAChair your Q's on climate change &amp; the cost of inaction with #WHClimateChat.\nHe'll answer some at 2:30pm ET: http:\/\/t.co\/SKou8JfYNH",
    "id" : 494171352518373376,
    "created_at" : "2014-07-29 17:23:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 494171377461907456,
  "created_at" : "2014-07-29 17:23:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 94, 103 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/BP9HvZukll",
      "expanded_url" : "http:\/\/youtu.be\/Be77opkMXHs",
      "display_url" : "youtu.be\/Be77opkMXHs"
    } ]
  },
  "geo" : { },
  "id_str" : "494152171378991104",
  "text" : "\"After reading your letter, the President said, 'you know what, I want to meet this woman.'\" \u2014@PressSec: http:\/\/t.co\/BP9HvZukll",
  "id" : 494152171378991104,
  "created_at" : "2014-07-29 16:07:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 19, 28 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/cUW6hcXdOa",
      "expanded_url" : "http:\/\/go.wh.gov\/eGS66h",
      "display_url" : "go.wh.gov\/eGS66h"
    } ]
  },
  "geo" : { },
  "id_str" : "494140482407374848",
  "text" : "At 2:30pm ET, join @CEAChair for a Q&amp;A on climate change and the cost of inaction. Ask your Q's using #WHClimateChat: http:\/\/t.co\/cUW6hcXdOa",
  "id" : 494140482407374848,
  "created_at" : "2014-07-29 15:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/CrvcUAdyzH",
      "expanded_url" : "http:\/\/nyti.ms\/1lN2IBl",
      "display_url" : "nyti.ms\/1lN2IBl"
    } ]
  },
  "geo" : { },
  "id_str" : "494136030296289280",
  "text" : "RT @vj44: Family-friendly policies would make our businesses more competitive and our workers more productive: http:\/\/t.co\/CrvcUAdyzH @Upsh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Upshot",
        "screen_name" : "UpshotNYT",
        "indices" : [ 124, 134 ],
        "id_str" : "16955870",
        "id" : 16955870
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/CrvcUAdyzH",
        "expanded_url" : "http:\/\/nyti.ms\/1lN2IBl",
        "display_url" : "nyti.ms\/1lN2IBl"
      } ]
    },
    "geo" : { },
    "id_str" : "494135360524283905",
    "text" : "Family-friendly policies would make our businesses more competitive and our workers more productive: http:\/\/t.co\/CrvcUAdyzH @UpshotNYT",
    "id" : 494135360524283905,
    "created_at" : "2014-07-29 15:00:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 494136030296289280,
  "created_at" : "2014-07-29 15:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 101, 110 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/BP9HvZukll",
      "expanded_url" : "http:\/\/youtu.be\/Be77opkMXHs",
      "display_url" : "youtu.be\/Be77opkMXHs"
    } ]
  },
  "geo" : { },
  "id_str" : "494131864391909376",
  "text" : "\"The President of the United States thought your letter was really good, and he wants to meet you.\" \u2014@PressSec: http:\/\/t.co\/BP9HvZukll",
  "id" : 494131864391909376,
  "created_at" : "2014-07-29 14:46:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/mgGtnrlxMw",
      "expanded_url" : "http:\/\/youtu.be\/Be77opkMXHs",
      "display_url" : "youtu.be\/Be77opkMXHs"
    } ]
  },
  "geo" : { },
  "id_str" : "494125285655064577",
  "text" : "\"People like you\u2026who have written letters just like this\u2026those are the people that the President's fighting for.\" http:\/\/t.co\/mgGtnrlxMw",
  "id" : 494125285655064577,
  "created_at" : "2014-07-29 14:20:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/493892813600616449\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Xo8lsT2jXr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btqo5XSIUAAmCpt.png",
      "id_str" : "493892812606558208",
      "id" : 493892812606558208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btqo5XSIUAAmCpt.png",
      "sizes" : [ {
        "h" : 218,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 1110
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Xo8lsT2jXr"
    } ],
    "hashtags" : [ {
      "text" : "EidMubarak",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493892813600616449",
  "text" : "\"We wish Muslims in the United States and around the world a blessed and joyous celebration.\" \u2014Obama on #EidMubarak http:\/\/t.co\/Xo8lsT2jXr",
  "id" : 493892813600616449,
  "created_at" : "2014-07-28 22:56:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/gfX7K60Y6c",
      "expanded_url" : "http:\/\/youtu.be\/FDUNjrwt6hs",
      "display_url" : "youtu.be\/FDUNjrwt6hs"
    } ]
  },
  "geo" : { },
  "id_str" : "493888580163756032",
  "text" : "\"The great thing about being young is you are not bound by the past, and you can shape the future.\" \u2014Obama: http:\/\/t.co\/gfX7K60Y6c\n#YALI2014",
  "id" : 493888580163756032,
  "created_at" : "2014-07-28 22:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493875664672817152",
  "text" : "RT @VP: Medicare is in better financial standing today thanks to the #ACA -- a win for seniors and American taxpayers. http:\/\/t.co\/83B6TVtx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/493834670736678912\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/83B6TVtxMY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Btp0AwLCMAEL88h.png",
        "id_str" : "493834665430495233",
        "id" : 493834665430495233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btp0AwLCMAEL88h.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/83B6TVtxMY"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 61, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493834670736678912",
    "text" : "Medicare is in better financial standing today thanks to the #ACA -- a win for seniors and American taxpayers. http:\/\/t.co\/83B6TVtxMY",
    "id" : 493834670736678912,
    "created_at" : "2014-07-28 19:05:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 493875664672817152,
  "created_at" : "2014-07-28 21:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BornIn88",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 108, 119 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/eXZq4FxW5d",
      "expanded_url" : "http:\/\/bzfd.it\/1oBDU17",
      "display_url" : "bzfd.it\/1oBDU17"
    } ]
  },
  "geo" : { },
  "id_str" : "493872482755948544",
  "text" : "26 life skills for everyone #BornIn88\u2014including getting affordable health insurance: http:\/\/t.co\/eXZq4FxW5d #GetCovered #ACAWorks",
  "id" : 493872482755948544,
  "created_at" : "2014-07-28 21:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493857486374723584",
  "text" : "RT @PressSec: Here's the graphic from today's briefing showing that Medicare is stronger due in no small part to #ACA. http:\/\/t.co\/0Fi2TlTr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/493857232208277504\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/0Fi2TlTrXd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtqIiMDCUAAqNO-.jpg",
        "id_str" : "493857230081380352",
        "id" : 493857230081380352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtqIiMDCUAAqNO-.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/0Fi2TlTrXd"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 99, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493857232208277504",
    "text" : "Here's the graphic from today's briefing showing that Medicare is stronger due in no small part to #ACA. http:\/\/t.co\/0Fi2TlTrXd",
    "id" : 493857232208277504,
    "created_at" : "2014-07-28 20:35:14 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 493857486374723584,
  "created_at" : "2014-07-28 20:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493839186420449281",
  "text" : "RT @WHLive: \"We rely on them constantly. We need them. Like medicine, they help us live.\" \u2014President Obama on the arts and humanities",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493839148797554689",
    "text" : "\"We rely on them constantly. We need them. Like medicine, they help us live.\" \u2014President Obama on the arts and humanities",
    "id" : 493839148797554689,
    "created_at" : "2014-07-28 19:23:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 493839186420449281,
  "created_at" : "2014-07-28 19:23:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "493838467634581504",
  "text" : "\"Your accomplishments have enriched our lives.\" \u2014Obama to recipients of the National Medals of Arts and Humanities: http:\/\/t.co\/b4tqL3oo0v",
  "id" : 493838467634581504,
  "created_at" : "2014-07-28 19:20:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493837799964307456",
  "text" : "RT @WHLive: \"It\u2019s been 200 years since Dolley Madison saved the portrait of George Washington...in this room from an advancing British army\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493837770897764352",
    "text" : "\"It\u2019s been 200 years since Dolley Madison saved the portrait of George Washington...in this room from an advancing British army.\" \u2014Obama",
    "id" : 493837770897764352,
    "created_at" : "2014-07-28 19:17:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 493837799964307456,
  "created_at" : "2014-07-28 19:18:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493835998808530945",
  "text" : "RT @WHLive: Starting soon: President Obama awards the 2013 National Medal of Arts and the National Medal of Humanities. Watch \u2192 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/XLhcoqMPWC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "493835964704636928",
    "text" : "Starting soon: President Obama awards the 2013 National Medal of Arts and the National Medal of Humanities. Watch \u2192 http:\/\/t.co\/XLhcoqMPWC",
    "id" : 493835964704636928,
    "created_at" : "2014-07-28 19:10:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 493835998808530945,
  "created_at" : "2014-07-28 19:10:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/493827620102873088\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5b965PmecB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Btptmm_IAAENZjF.jpg",
      "id_str" : "493827619218259969",
      "id" : 493827619218259969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Btptmm_IAAENZjF.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5b965PmecB"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/KbLYX4DsqM",
      "expanded_url" : "http:\/\/go.wh.gov\/TvGSfm",
      "display_url" : "go.wh.gov\/TvGSfm"
    } ]
  },
  "geo" : { },
  "id_str" : "493827620102873088",
  "text" : "Spread the word: Medicare is stronger thanks in part to the Affordable Care Act \u2192 http:\/\/t.co\/KbLYX4DsqM #ACAWorks http:\/\/t.co\/5b965PmecB",
  "id" : 493827620102873088,
  "created_at" : "2014-07-28 18:37:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493823151261122560",
  "text" : "RT @vj44: #YALI2014 reflects Madiba\u2019s belief in the endless heroism of youth. POTUS proudly announced its new name: the Mandela Washington \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YALI2014",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493789939432435712",
    "text" : "#YALI2014 reflects Madiba\u2019s belief in the endless heroism of youth. POTUS proudly announced its new name: the Mandela Washington Fellowship",
    "id" : 493789939432435712,
    "created_at" : "2014-07-28 16:07:50 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 493823151261122560,
  "created_at" : "2014-07-28 18:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/2blADd3EXR",
      "expanded_url" : "http:\/\/youtu.be\/-IWYl7ymaG8",
      "display_url" : "youtu.be\/-IWYl7ymaG8"
    } ]
  },
  "geo" : { },
  "id_str" : "493804072987009024",
  "text" : "\u201CYALI is about empowering people. It\u2019s about bringing people together.\u201D\n\nWatch \u2192 http:\/\/t.co\/2blADd3EXR #YALI2014",
  "id" : 493804072987009024,
  "created_at" : "2014-07-28 17:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493791525160386560",
  "text" : "\"The great thing about being young is you are not bound by the past, and you can shape the future.\" \u2014Obama to young leaders at #YALI2014",
  "id" : 493791525160386560,
  "created_at" : "2014-07-28 16:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 115, 128 ]
    }, {
      "text" : "YALI2014",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "493785924296540160",
  "text" : "\u201CIf you\u2019re a strong man, you should not feel threatened by strong women.\u201D \u2014President Obama: http:\/\/t.co\/b4tqL3oo0v #WomenSucceed #YALI2014",
  "id" : 493785924296540160,
  "created_at" : "2014-07-28 15:51:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493785105769713665",
  "text" : "\"If you educate and empower and respect a mother, then you are educating the children.\" \u2014President Obama on empowering women #YALI2014",
  "id" : 493785105769713665,
  "created_at" : "2014-07-28 15:48:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 109, 122 ]
    }, {
      "text" : "YALI2014",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493784355349995520",
  "text" : "\"One of the best measures of whether a country succeeds or not is how it treats its women.\" \u2014President Obama #WomenSucceed #YALI2014",
  "id" : 493784355349995520,
  "created_at" : "2014-07-28 15:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/493781506566131713\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jlJsCD3OBB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtpDqduIEAA55yc.png",
      "id_str" : "493781505962151936",
      "id" : 493781505962151936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtpDqduIEAA55yc.png",
      "sizes" : [ {
        "h" : 355,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jlJsCD3OBB"
    } ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493781506566131713",
  "text" : "\u201CIf you\u2019ve got a good idea, you should be able to test that idea and be judged on your own merits.\u201D \u2014Obama #YALI2014 http:\/\/t.co\/jlJsCD3OBB",
  "id" : 493781506566131713,
  "created_at" : "2014-07-28 15:34:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493779281789853697",
  "text" : "RT @WHLive: \"We want to help you give these women and girls the future they want and the dignity every woman deserves.\" \u2014Obama #WomenSuccee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 115, 128 ]
      }, {
        "text" : "YALI2014",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493779256653402112",
    "text" : "\"We want to help you give these women and girls the future they want and the dignity every woman deserves.\" \u2014Obama #WomenSucceed #YALI2014",
    "id" : 493779256653402112,
    "created_at" : "2014-07-28 15:25:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 493779281789853697,
  "created_at" : "2014-07-28 15:25:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493777809996009472",
  "text" : "\"We are proud to announce that the new name of this program is the Mandela Washington Fellowship for Young African Leaders\" \u2014Obama #YALI2014",
  "id" : 493777809996009472,
  "created_at" : "2014-07-28 15:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493777056204079105",
  "text" : "\"The spirit of [#YALI2014] reflects Madiba\u2019s optimism, his idealism, his belief in what he called 'the endless heroism of youth.'\" \u2014Obama",
  "id" : 493777056204079105,
  "created_at" : "2014-07-28 15:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493776726401363968",
  "text" : "RT @WHLive: \"I want everyone out there in the YALI Network to know that you\u2019re the foundation of our partnership with Africa\u2019s youth.\" \u2014Oba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YALI2014",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493776694545625088",
    "text" : "\"I want everyone out there in the YALI Network to know that you\u2019re the foundation of our partnership with Africa\u2019s youth.\" \u2014Obama #YALI2014",
    "id" : 493776694545625088,
    "created_at" : "2014-07-28 15:15:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 493776726401363968,
  "created_at" : "2014-07-28 15:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493776251547815936",
  "text" : "\"The security and prosperity...that we seek in the world cannot be achieved without a strong, prosperous and self-reliant Africa.\" \u2014Obama",
  "id" : 493776251547815936,
  "created_at" : "2014-07-28 15:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2014",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/mjvj6PoO34",
      "expanded_url" : "http:\/\/go.wh.gov\/K8n3Kn",
      "display_url" : "go.wh.gov\/K8n3Kn"
    } ]
  },
  "geo" : { },
  "id_str" : "493775413366489088",
  "text" : "Happening now: President Obama speaks at the Young African Leaders Summit. Watch \u2192 http:\/\/t.co\/mjvj6PoO34 #YALI2014",
  "id" : 493775413366489088,
  "created_at" : "2014-07-28 15:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/T5rlmZLKRD",
      "expanded_url" : "http:\/\/wapo.st\/1Anutu4",
      "display_url" : "wapo.st\/1Anutu4"
    } ]
  },
  "geo" : { },
  "id_str" : "493771650450468864",
  "text" : "Here's why it's time to close tax loopholes that some multinational corporations use to avoid paying taxes: http:\/\/t.co\/T5rlmZLKRD",
  "id" : 493771650450468864,
  "created_at" : "2014-07-28 14:55:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/T5rlmZLKRD",
      "expanded_url" : "http:\/\/wapo.st\/1Anutu4",
      "display_url" : "wapo.st\/1Anutu4"
    } ]
  },
  "geo" : { },
  "id_str" : "493763232742387713",
  "text" : "RT if you agree: \"Our tax system should not reward...companies for giving up their U.S. citizenship.\" \u2014Secretary Lew: http:\/\/t.co\/T5rlmZLKRD",
  "id" : 493763232742387713,
  "created_at" : "2014-07-28 14:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 111, 126 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/fto3RNrlJk",
      "expanded_url" : "http:\/\/wapo.st\/1Anutu4",
      "display_url" : "wapo.st\/1Anutu4"
    } ]
  },
  "geo" : { },
  "id_str" : "493751093114208256",
  "text" : "RT @pfeiffer44: Secretary Jack Lew on the need to close the inversions tax loophole http:\/\/t.co\/fto3RNrlJk via @washingtonpost",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 95, 110 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/fto3RNrlJk",
        "expanded_url" : "http:\/\/wapo.st\/1Anutu4",
        "display_url" : "wapo.st\/1Anutu4"
      } ]
    },
    "geo" : { },
    "id_str" : "493748270359793665",
    "text" : "Secretary Jack Lew on the need to close the inversions tax loophole http:\/\/t.co\/fto3RNrlJk via @washingtonpost",
    "id" : 493748270359793665,
    "created_at" : "2014-07-28 13:22:15 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 493751093114208256,
  "created_at" : "2014-07-28 13:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/4RPdDjgNP8",
      "expanded_url" : "http:\/\/go.wh.gov\/yXRbEe",
      "display_url" : "go.wh.gov\/yXRbEe"
    } ]
  },
  "geo" : { },
  "id_str" : "493521771425841154",
  "text" : "\"We can build up our middle class, hand down something better to our kids, and restore the American Dream.\" \u2014Obama: http:\/\/t.co\/4RPdDjgNP8",
  "id" : 493521771425841154,
  "created_at" : "2014-07-27 22:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/4RPdDjgNP8",
      "expanded_url" : "http:\/\/go.wh.gov\/yXRbEe",
      "display_url" : "go.wh.gov\/yXRbEe"
    } ]
  },
  "geo" : { },
  "id_str" : "493480967374262272",
  "text" : "\"Let\u2019s embrace an economic patriotism that says we rise or fall together, as one nation.\" \u2014Obama: http:\/\/t.co\/4RPdDjgNP8 #OpportunityForAll",
  "id" : 493480967374262272,
  "created_at" : "2014-07-27 19:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/4RPdDjgNP8",
      "expanded_url" : "http:\/\/go.wh.gov\/yXRbEe",
      "display_url" : "go.wh.gov\/yXRbEe"
    } ]
  },
  "geo" : { },
  "id_str" : "493434155485519873",
  "text" : "\"You don\u2019t get to pick which rules you play by, or which tax rate you pay &amp; neither should these companies.\" \u2014Obama: http:\/\/t.co\/4RPdDjgNP8",
  "id" : 493434155485519873,
  "created_at" : "2014-07-27 16:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 83, 98 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/WHAfLaN3l9",
      "expanded_url" : "http:\/\/wapo.st\/1pVewUX",
      "display_url" : "wapo.st\/1pVewUX"
    } ]
  },
  "geo" : { },
  "id_str" : "493176473495154688",
  "text" : "\u201CThe country as a whole will gain when males of color...realize their potential.\u201D \u2014@WashingtonPost: http:\/\/t.co\/WHAfLaN3l9 #MyBrothersKeeper",
  "id" : 493176473495154688,
  "created_at" : "2014-07-26 23:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bjJHWyLOOY",
      "expanded_url" : "http:\/\/go.wh.gov\/JqLePU",
      "display_url" : "go.wh.gov\/JqLePU"
    } ]
  },
  "geo" : { },
  "id_str" : "493161370259427328",
  "text" : "\u201CThe promise of America isn\u2019t confined to any one race, or class, or group.\u201D \u2014Obama on the #ADA's 24th anniversary:  http:\/\/t.co\/bjJHWyLOOY",
  "id" : 493161370259427328,
  "created_at" : "2014-07-26 22:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 72, 87 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 38, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/WHAfLaN3l9",
      "expanded_url" : "http:\/\/wapo.st\/1pVewUX",
      "display_url" : "wapo.st\/1pVewUX"
    } ]
  },
  "geo" : { },
  "id_str" : "493151280492081154",
  "text" : "Worth reading: \u201CMr. Obama\u2019s promising #MyBrothersKeeper initiative\u201D via @WashingtonPost \u2192 http:\/\/t.co\/WHAfLaN3l9",
  "id" : 493151280492081154,
  "created_at" : "2014-07-26 21:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/4RPdDjgNP8",
      "expanded_url" : "http:\/\/go.wh.gov\/yXRbEe",
      "display_url" : "go.wh.gov\/yXRbEe"
    } ]
  },
  "geo" : { },
  "id_str" : "493141971431481344",
  "text" : "\"When some companies cherry-pick their taxes, it damages the country\u2019s finances. It adds to the deficit.\" \u2014Obama: http:\/\/t.co\/4RPdDjgNP8",
  "id" : 493141971431481344,
  "created_at" : "2014-07-26 21:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/zLNYKs2jeg",
      "expanded_url" : "http:\/\/go.wh.gov\/ZQi4H7",
      "display_url" : "go.wh.gov\/ZQi4H7"
    } ]
  },
  "geo" : { },
  "id_str" : "493131201331216384",
  "text" : "Today marks 24 years of the #ADA, a landmark law that transformed American society for people with disabilities \u2192 http:\/\/t.co\/zLNYKs2jeg",
  "id" : 493131201331216384,
  "created_at" : "2014-07-26 20:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 16, 31 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 49, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493117140392611841",
  "text" : "RT @vj44: Great @washingtonpost editorial on how #MyBrothersKeeper helps boys &amp; young men of color and our country as a whole: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 6, 21 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 39, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/plEh5w36u0",
        "expanded_url" : "http:\/\/wapo.st\/1pVewUX",
        "display_url" : "wapo.st\/1pVewUX"
      } ]
    },
    "geo" : { },
    "id_str" : "493076195643117568",
    "text" : "Great @washingtonpost editorial on how #MyBrothersKeeper helps boys &amp; young men of color and our country as a whole: http:\/\/t.co\/plEh5w36u0",
    "id" : 493076195643117568,
    "created_at" : "2014-07-26 16:51:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 493117140392611841,
  "created_at" : "2014-07-26 19:34:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/4RPdDjgNP8",
      "expanded_url" : "http:\/\/go.wh.gov\/yXRbEe",
      "display_url" : "go.wh.gov\/yXRbEe"
    } ]
  },
  "geo" : { },
  "id_str" : "493078815732551682",
  "text" : "\"The unemployment rate is at its lowest point since Sept 2008\u2014the fastest 1-year drop in nearly 30 years.\" \u2014Obama: http:\/\/t.co\/4RPdDjgNP8",
  "id" : 493078815732551682,
  "created_at" : "2014-07-26 17:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492403848045395969\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/fBlz0jqyFM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtVesJBCMAAhlDz.jpg",
      "id_str" : "492403846694449152",
      "id" : 492403846694449152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtVesJBCMAAhlDz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fBlz0jqyFM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/4RPdDjgNP8",
      "expanded_url" : "http:\/\/go.wh.gov\/yXRbEe",
      "display_url" : "go.wh.gov\/yXRbEe"
    } ]
  },
  "geo" : { },
  "id_str" : "493017951453196288",
  "text" : "\"Our businesses have now added nearly 10 million new jobs over the past 52 months.\" \u2014Obama: http:\/\/t.co\/4RPdDjgNP8 http:\/\/t.co\/fBlz0jqyFM",
  "id" : 493017951453196288,
  "created_at" : "2014-07-26 13:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 48, 57 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492778099998986240\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YZyW2pgyci",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtazEevIgAATvZ1.jpg",
      "id_str" : "492778098795249664",
      "id" : 492778098795249664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtazEevIgAATvZ1.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YZyW2pgyci"
    } ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/1arPwZypFz",
      "expanded_url" : "http:\/\/go.wh.gov\/s1EcDF",
      "display_url" : "go.wh.gov\/s1EcDF"
    } ]
  },
  "geo" : { },
  "id_str" : "492778099998986240",
  "text" : "\"We need to help young people chart a course.\" \u2014@LaborSec on his day with Deric: http:\/\/t.co\/1arPwZypFz #ReadyToWork http:\/\/t.co\/YZyW2pgyci",
  "id" : 492778099998986240,
  "created_at" : "2014-07-25 21:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 30, 42 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492768352566525952",
  "text" : "RT @Lubin44: In response to a @WeThePeople petition &amp; Admin action, Congress voted today to allow consumers to unlock cell phones. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 17, 29 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Lubin44\/status\/492754117065211905\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/tmZgQNLKCY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtadQiUIIAALg97.png",
        "id_str" : "492754116658339840",
        "id" : 492754116658339840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtadQiUIIAALg97.png",
        "sizes" : [ {
          "h" : 147,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 663
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 663
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tmZgQNLKCY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492754117065211905",
    "text" : "In response to a @WeThePeople petition &amp; Admin action, Congress voted today to allow consumers to unlock cell phones. http:\/\/t.co\/tmZgQNLKCY",
    "id" : 492754117065211905,
    "created_at" : "2014-07-25 19:31:51 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 492768352566525952,
  "created_at" : "2014-07-25 20:28:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 29, 41 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492758804946100226\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/PzxkJUWNPn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtahhYCIgAAkSPy.png",
      "id_str" : "492758804002799616",
      "id" : 492758804002799616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtahhYCIgAAkSPy.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 1055
      }, {
        "h" : 109,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PzxkJUWNPn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492758804946100226",
  "text" : "You made your voice heard on @WeThePeople\u2014and now we have more flexibility and choice when it comes to cell phones. http:\/\/t.co\/PzxkJUWNPn",
  "id" : 492758804946100226,
  "created_at" : "2014-07-25 19:50:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Los Angeles 2015",
      "screen_name" : "losangeles2015",
      "indices" : [ 60, 75 ],
      "id_str" : "1732714819",
      "id" : 1732714819
    }, {
      "name" : "Special Olympics",
      "screen_name" : "SpecialOlympics",
      "indices" : [ 76, 92 ],
      "id_str" : "19598173",
      "id" : 19598173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheWorldIsComing",
      "indices" : [ 34, 51 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/JFtNopTNts",
      "expanded_url" : "http:\/\/www.la2015.org\/",
      "display_url" : "la2015.org"
    } ]
  },
  "geo" : { },
  "id_str" : "492746678588674048",
  "text" : "Get excited: One year from today, #TheWorldIsComing for the @LosAngeles2015 @SpecialOlympics World Games \u2192 http:\/\/t.co\/JFtNopTNts #GoTeamUSA",
  "id" : 492746678588674048,
  "created_at" : "2014-07-25 19:02:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skills",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492733805602820096",
  "text" : "RT @LaborSec: Excited to meet Deric, a great example of how job-driven training provides the #skills people need for jobs of today http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/492702664837566464\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/zPnMV9kGtT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtZudjyIUAAxzKq.jpg",
        "id_str" : "492702663344410624",
        "id" : 492702663344410624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtZudjyIUAAxzKq.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 2592
        } ],
        "display_url" : "pic.twitter.com\/zPnMV9kGtT"
      } ],
      "hashtags" : [ {
        "text" : "skills",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492702664837566464",
    "text" : "Excited to meet Deric, a great example of how job-driven training provides the #skills people need for jobs of today http:\/\/t.co\/zPnMV9kGtT",
    "id" : 492702664837566464,
    "created_at" : "2014-07-25 16:07:23 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 492733805602820096,
  "created_at" : "2014-07-25 18:11:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 51, 58 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceEquality",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492701425114574848",
  "text" : "RT @vj44: Today at 1 PM ET, I\u2019ll be answering your @Tumblr Q\u2019s about LGBT #WorkplaceEquality. Click here to get in on the fun http:\/\/t.co\/q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 41, 48 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkplaceEquality",
        "indices" : [ 64, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/qRS6zjpxG6",
        "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1MP0jIY",
        "display_url" : "tmblr.co\/ZE5Fby1MP0jIY"
      } ]
    },
    "geo" : { },
    "id_str" : "492701076416892929",
    "text" : "Today at 1 PM ET, I\u2019ll be answering your @Tumblr Q\u2019s about LGBT #WorkplaceEquality. Click here to get in on the fun http:\/\/t.co\/qRS6zjpxG6",
    "id" : 492701076416892929,
    "created_at" : "2014-07-25 16:01:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 492701425114574848,
  "created_at" : "2014-07-25 16:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492697074018701314\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lbn4Jsixyk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtZmnfsIIAAOOwi.jpg",
      "id_str" : "492694037951160320",
      "id" : 492694037951160320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtZmnfsIIAAOOwi.jpg",
      "sizes" : [ {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1516
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lbn4Jsixyk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/fET2QlpZFM",
      "expanded_url" : "http:\/\/go.wh.gov\/mfpAMd",
      "display_url" : "go.wh.gov\/mfpAMd"
    } ]
  },
  "geo" : { },
  "id_str" : "492697074018701314",
  "text" : "\"You are why I ran for President in the 1st place.\u201D \u2014Obama on meeting people who wrote to him: http:\/\/t.co\/fET2QlpZFM http:\/\/t.co\/lbn4Jsixyk",
  "id" : 492697074018701314,
  "created_at" : "2014-07-25 15:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/b4Kn6dVb4S",
      "expanded_url" : "http:\/\/go.wh.gov\/jedo6U",
      "display_url" : "go.wh.gov\/jedo6U"
    } ]
  },
  "geo" : { },
  "id_str" : "492689358349406209",
  "text" : "Most of our businesses play by the rules. It's time to prevent some multinational corporations from avoiding taxes \u2192 http:\/\/t.co\/b4Kn6dVb4S",
  "id" : 492689358349406209,
  "created_at" : "2014-07-25 15:14:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KagGDSqzts",
      "expanded_url" : "http:\/\/nyti.ms\/1nXaqbS",
      "display_url" : "nyti.ms\/1nXaqbS"
    } ]
  },
  "geo" : { },
  "id_str" : "492677948089331712",
  "text" : "President Obama's working to prevent large corporations from claiming they're based abroad to avoid paying taxes: http:\/\/t.co\/KagGDSqzts",
  "id" : 492677948089331712,
  "created_at" : "2014-07-25 14:29:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492674995525795840",
  "text" : "RT @jesseclee44: Staggering state-by-state breakdown of how much ACA repeal would jack up premium costs -- 322% nationally\u2026\n \nhttp:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/cU502m2wu4",
        "expanded_url" : "http:\/\/www.americanprogressaction.org\/issues\/healthcare\/news\/2014\/07\/25\/94510\/conservatives-want-you-to-pay-more-for-the-health-plan-you-like\/",
        "display_url" : "americanprogressaction.org\/issues\/healthc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492666402646798336",
    "text" : "Staggering state-by-state breakdown of how much ACA repeal would jack up premium costs -- 322% nationally\u2026\n \nhttp:\/\/t.co\/cU502m2wu4",
    "id" : 492666402646798336,
    "created_at" : "2014-07-25 13:43:18 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 492674995525795840,
  "created_at" : "2014-07-25 14:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492442944067358723\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/wM0qfQJNca",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtWCP2-CYAAi9ur.jpg",
      "id_str" : "492442943232303104",
      "id" : 492442943232303104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtWCP2-CYAAi9ur.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1336,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/wM0qfQJNca"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/fc1I1RqXEq",
      "expanded_url" : "http:\/\/go.wh.gov\/6DMC2Y",
      "display_url" : "go.wh.gov\/6DMC2Y"
    } ]
  },
  "geo" : { },
  "id_str" : "492442944067358723",
  "text" : "\"Cynicism has never won a war, or cured a disease, or started a business.\" \u2014President Obama: http:\/\/t.co\/fc1I1RqXEq http:\/\/t.co\/wM0qfQJNca",
  "id" : 492442944067358723,
  "created_at" : "2014-07-24 22:55:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "CNBC",
      "screen_name" : "CNBC",
      "indices" : [ 114, 119 ],
      "id_str" : "20402945",
      "id" : 20402945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/6oYtflBtJz",
      "expanded_url" : "http:\/\/fw.to\/IWTSONK",
      "display_url" : "fw.to\/IWTSONK"
    } ]
  },
  "geo" : { },
  "id_str" : "492427687534030848",
  "text" : "RT @DagVega44: President Obama: Tax reform must be simple &amp; fair. Watch this clip: http:\/\/t.co\/6oYtflBtJz via @CNBC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNBC",
        "screen_name" : "CNBC",
        "indices" : [ 99, 104 ],
        "id_str" : "20402945",
        "id" : 20402945
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/6oYtflBtJz",
        "expanded_url" : "http:\/\/fw.to\/IWTSONK",
        "display_url" : "fw.to\/IWTSONK"
      } ]
    },
    "geo" : { },
    "id_str" : "492427248398794752",
    "text" : "President Obama: Tax reform must be simple &amp; fair. Watch this clip: http:\/\/t.co\/6oYtflBtJz via @CNBC",
    "id" : 492427248398794752,
    "created_at" : "2014-07-24 21:52:59 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 492427687534030848,
  "created_at" : "2014-07-24 21:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 3, 10 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/jV76WAwHee",
      "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1MP0jIY",
      "display_url" : "tmblr.co\/ZE5Fby1MP0jIY"
    } ]
  },
  "geo" : { },
  "id_str" : "492418253562843136",
  "text" : "RT @tumblr: The White House Ask box is open again. http:\/\/t.co\/jV76WAwHee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/jV76WAwHee",
        "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1MP0jIY",
        "display_url" : "tmblr.co\/ZE5Fby1MP0jIY"
      } ]
    },
    "geo" : { },
    "id_str" : "492415569380245504",
    "text" : "The White House Ask box is open again. http:\/\/t.co\/jV76WAwHee",
    "id" : 492415569380245504,
    "created_at" : "2014-07-24 21:06:35 +0000",
    "user" : {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "protected" : false,
      "id_str" : "52484614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791014307089747968\/jqxriE5C_normal.jpg",
      "id" : 52484614,
      "verified" : true
    }
  },
  "id" : 492418253562843136,
  "created_at" : "2014-07-24 21:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492409039264161793",
  "text" : "\"Don\u2019t let the cynics get you down. Cynicism is a choice, and hope is a better choice.\" \u2014President Obama #OpportunityForAll",
  "id" : 492409039264161793,
  "created_at" : "2014-07-24 20:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492408746916986880",
  "text" : "\"Cynicism has never won a war, or cured a disease, or started a business, or fed a young mind.\" \u2014President Obama",
  "id" : 492408746916986880,
  "created_at" : "2014-07-24 20:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492408182980214784",
  "text" : "\"Rather than more tax breaks for millionaires, let\u2019s give more tax breaks to help working families pay for child care or college.\" \u2014Obama",
  "id" : 492408182980214784,
  "created_at" : "2014-07-24 20:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492407140288856065",
  "text" : "RT @WHLive: \"There\u2019s a small but growing group of big corporations are fleeing the country to get out of paying taxes.\" \u2014Obama: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/91rlt9Ywb6",
        "expanded_url" : "http:\/\/go.wh.gov\/jedo6U",
        "display_url" : "go.wh.gov\/jedo6U"
      } ]
    },
    "geo" : { },
    "id_str" : "492407103076986880",
    "text" : "\"There\u2019s a small but growing group of big corporations are fleeing the country to get out of paying taxes.\" \u2014Obama: http:\/\/t.co\/91rlt9Ywb6",
    "id" : 492407103076986880,
    "created_at" : "2014-07-24 20:32:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 492407140288856065,
  "created_at" : "2014-07-24 20:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/492406716764786688\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4EvpfuxlPY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtVhTKpCIAEtxNJ.jpg",
      "id_str" : "492406716168806401",
      "id" : 492406716168806401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtVhTKpCIAEtxNJ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4EvpfuxlPY"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    }, {
      "text" : "1010Now",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492406716764786688",
  "text" : "\"America deserves a raise. It\u2019ll be good for those workers and for business.\" \u2014President Obama #RaiseTheWage #1010Now http:\/\/t.co\/4EvpfuxlPY",
  "id" : 492406716764786688,
  "created_at" : "2014-07-24 20:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492406468592025600\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/9tzIx7fXmL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtVhEtbCYAAdPr_.jpg",
      "id_str" : "492406467807305728",
      "id" : 492406467807305728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtVhEtbCYAAdPr_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9tzIx7fXmL"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 6, 19 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492406468592025600",
  "text" : "\"When #WomenSucceed, America succeeds.\" \u2014Obama on why it's time to help ensure #EqualPay for women http:\/\/t.co\/9tzIx7fXmL",
  "id" : 492406468592025600,
  "created_at" : "2014-07-24 20:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492404887050002432",
  "text" : "RT @WHLive: \"I\u2019m here to focus on one thing we should be doing: Training more Americans to fill the jobs we\u2019re creating.\" \u2014Obama: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/S7nyiHvjH0",
        "expanded_url" : "http:\/\/wh.gov\/ready-to-work",
        "display_url" : "wh.gov\/ready-to-work"
      } ]
    },
    "geo" : { },
    "id_str" : "492404854560948224",
    "text" : "\"I\u2019m here to focus on one thing we should be doing: Training more Americans to fill the jobs we\u2019re creating.\" \u2014Obama: http:\/\/t.co\/S7nyiHvjH0",
    "id" : 492404854560948224,
    "created_at" : "2014-07-24 20:24:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 492404887050002432,
  "created_at" : "2014-07-24 20:24:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492404585475371008",
  "text" : "\"That\u2019s what\u2019s at stake right now\u2014making sure our economy works for every working American.\" \u2014President Obama #OpportunityForAll",
  "id" : 492404585475371008,
  "created_at" : "2014-07-24 20:22:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492403848045395969\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/fBlz0jqyFM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtVesJBCMAAhlDz.jpg",
      "id_str" : "492403846694449152",
      "id" : 492403846694449152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtVesJBCMAAhlDz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fBlz0jqyFM"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492403848045395969",
  "text" : "\"Our businesses have added nearly 10 million new jobs over the past 52 months.\" \u2014President Obama #ActOnJobs http:\/\/t.co\/fBlz0jqyFM",
  "id" : 492403848045395969,
  "created_at" : "2014-07-24 20:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492403657762435073",
  "text" : "\"I am here for...everybody who works their tail off, who does everything right, who believes in the American Dream.\" \u2014President Obama",
  "id" : 492403657762435073,
  "created_at" : "2014-07-24 20:19:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "492403122086903808",
  "text" : "Happening now: President Obama speaks on the economy in Los Angeles. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 492403122086903808,
  "created_at" : "2014-07-24 20:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4Kn6dVb4S",
      "expanded_url" : "http:\/\/go.wh.gov\/jedo6U",
      "display_url" : "go.wh.gov\/jedo6U"
    } ]
  },
  "geo" : { },
  "id_str" : "492389971303890944",
  "text" : "When large corporations claim they're based abroad, it:\n\u2191 our deficit\nCosts taxpayers $\nRT if you agree that's wrong: http:\/\/t.co\/b4Kn6dVb4S",
  "id" : 492389971303890944,
  "created_at" : "2014-07-24 19:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/b4Kn6dVb4S",
      "expanded_url" : "http:\/\/go.wh.gov\/jedo6U",
      "display_url" : "go.wh.gov\/jedo6U"
    } ]
  },
  "geo" : { },
  "id_str" : "492382536195375105",
  "text" : "You don't get to pick your tax rate.\nNeither should corporations.\nLet's make sure we all play by the same rules \u2192 http:\/\/t.co\/b4Kn6dVb4S",
  "id" : 492382536195375105,
  "created_at" : "2014-07-24 18:55:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vT02iY7rrY",
      "expanded_url" : "http:\/\/www.usda.gov\/wps\/portal\/usda\/usdamobile?contentid=2014\/07\/0158.xml&contentidonly=true",
      "display_url" : "usda.gov\/wps\/portal\/usd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492373008753774593",
  "text" : "RT @USDA: TODAY the @WhiteHouse Rural Council announced a $10B private fund for rural infrastructure improvements \u2192 http:\/\/t.co\/vT02iY7rrY \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RuralMade",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/vT02iY7rrY",
        "expanded_url" : "http:\/\/www.usda.gov\/wps\/portal\/usda\/usdamobile?contentid=2014\/07\/0158.xml&contentidonly=true",
        "display_url" : "usda.gov\/wps\/portal\/usd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492314029126197249",
    "text" : "TODAY the @WhiteHouse Rural Council announced a $10B private fund for rural infrastructure improvements \u2192 http:\/\/t.co\/vT02iY7rrY #RuralMade",
    "id" : 492314029126197249,
    "created_at" : "2014-07-24 14:23:05 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 492373008753774593,
  "created_at" : "2014-07-24 18:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 3, 14 ],
      "id_str" : "15693493",
      "id" : 15693493
    }, {
      "name" : "Kristen Bell",
      "screen_name" : "IMKristenBell",
      "indices" : [ 30, 44 ],
      "id_str" : "53297035",
      "id" : 53297035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/FAMQI61Q6r",
      "expanded_url" : "http:\/\/ow.ly\/3nxEOD",
      "display_url" : "ow.ly\/3nxEOD"
    } ]
  },
  "geo" : { },
  "id_str" : "492343648173170688",
  "text" : "RT @funnyordie: Mary Poppins (@IMKristenBell) sings a catchy new tune about raising the minimum wage: http:\/\/t.co\/FAMQI61Q6r http:\/\/t.co\/6F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kristen Bell",
        "screen_name" : "IMKristenBell",
        "indices" : [ 14, 28 ],
        "id_str" : "53297035",
        "id" : 53297035
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/funnyordie\/status\/492337690650505217\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/6FCqbOXvdx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUihSaCcAAXqcs.jpg",
        "id_str" : "492337689539014656",
        "id" : 492337689539014656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUihSaCcAAXqcs.jpg",
        "sizes" : [ {
          "h" : 262,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6FCqbOXvdx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/FAMQI61Q6r",
        "expanded_url" : "http:\/\/ow.ly\/3nxEOD",
        "display_url" : "ow.ly\/3nxEOD"
      } ]
    },
    "geo" : { },
    "id_str" : "492337690650505217",
    "text" : "Mary Poppins (@IMKristenBell) sings a catchy new tune about raising the minimum wage: http:\/\/t.co\/FAMQI61Q6r http:\/\/t.co\/6FCqbOXvdx",
    "id" : 492337690650505217,
    "created_at" : "2014-07-24 15:57:07 +0000",
    "user" : {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "protected" : false,
      "id_str" : "15693493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796062959185182720\/FN6QGp0H_normal.jpg",
      "id" : 15693493,
      "verified" : true
    }
  },
  "id" : 492343648173170688,
  "created_at" : "2014-07-24 16:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492335989734797312",
  "text" : "RT @CEABetsey: Minimum wage workers last got a raise 5 years ago today (7\/24\/09). It\u2019s long past time for another one.  #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492334666620624896",
    "text" : "Minimum wage workers last got a raise 5 years ago today (7\/24\/09). It\u2019s long past time for another one.  #RaiseTheWage",
    "id" : 492334666620624896,
    "created_at" : "2014-07-24 15:45:06 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 492335989734797312,
  "created_at" : "2014-07-24 15:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492332382184566784\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/IlstVdH6YW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUdsTyCQAEKZ1s.jpg",
      "id_str" : "492332381328523265",
      "id" : 492332381328523265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUdsTyCQAEKZ1s.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IlstVdH6YW"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 10, 14 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/YcNe1j6c8y",
      "expanded_url" : "http:\/\/1.usa.gov\/1nvW6v6",
      "display_url" : "1.usa.gov\/1nvW6v6"
    } ]
  },
  "geo" : { },
  "id_str" : "492332382184566784",
  "text" : "FACT: The #ACA has saved Americans $9 billion on their health insurance premiums \u2192 http:\/\/t.co\/YcNe1j6c8y #ACAWorks http:\/\/t.co\/IlstVdH6YW",
  "id" : 492332382184566784,
  "created_at" : "2014-07-24 15:36:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "indices" : [ 3, 17 ],
      "id_str" : "72198806",
      "id" : 72198806
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Now",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492321596145541121",
  "text" : "RT @SenGillibrand: #1010Now: because nobody working full time in America should be living in poverty. We've got to reward hard work again. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1010Now",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492311668240941057",
    "text" : "#1010Now: because nobody working full time in America should be living in poverty. We've got to reward hard work again. #RaiseTheWage",
    "id" : 492311668240941057,
    "created_at" : "2014-07-24 14:13:43 +0000",
    "user" : {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "protected" : false,
      "id_str" : "72198806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748266569323659264\/Kv9U6DgK_normal.jpg",
      "id" : 72198806,
      "verified" : true
    }
  },
  "id" : 492321596145541121,
  "created_at" : "2014-07-24 14:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 54, 67 ]
    }, {
      "text" : "1010Now",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Gte7dqyiAZ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HcM0PnS7EqI",
      "display_url" : "youtube.com\/watch?v=HcM0Pn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492316470018580480",
  "text" : "RT @USDOL: Momentum is building across the country to #RaiseTheWage. It\u2019s time for #1010Now --&gt; https:\/\/t.co\/Gte7dqyiAZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 43, 56 ]
      }, {
        "text" : "1010Now",
        "indices" : [ 72, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Gte7dqyiAZ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HcM0PnS7EqI",
        "display_url" : "youtube.com\/watch?v=HcM0Pn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "492310745296556035",
    "text" : "Momentum is building across the country to #RaiseTheWage. It\u2019s time for #1010Now --&gt; https:\/\/t.co\/Gte7dqyiAZ",
    "id" : 492310745296556035,
    "created_at" : "2014-07-24 14:10:03 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 492316470018580480,
  "created_at" : "2014-07-24 14:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/492311811774234624\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/GiF5skNBwm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUK--UCIAAHnYT.jpg",
      "id_str" : "492311811262128128",
      "id" : 492311811262128128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUK--UCIAAHnYT.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GiF5skNBwm"
    } ],
    "hashtags" : [ {
      "text" : "1010Now",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/fMEhvXfOhy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "492311811774234624",
  "text" : "RT if you agree: It's time to raise the minimum wage \u2192 http:\/\/t.co\/fMEhvXfOhy #1010Now #RaiseTheWage http:\/\/t.co\/GiF5skNBwm",
  "id" : 492311811774234624,
  "created_at" : "2014-07-24 14:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/492302733664608256\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Y5qSrDWyEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUCuUjCcAAf-4N.jpg",
      "id_str" : "492302729079844864",
      "id" : 492302729079844864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUCuUjCcAAf-4N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Y5qSrDWyEx"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492302733664608256",
  "text" : "Share the news: The Affordable Care Act is saving Americans billions on health insurance premiums. #ACAWorks http:\/\/t.co\/Y5qSrDWyEx",
  "id" : 492302733664608256,
  "created_at" : "2014-07-24 13:38:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 77, 80 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/2sRpy35VPF",
      "expanded_url" : "http:\/\/youtu.be\/5iap8kpHRsA",
      "display_url" : "youtu.be\/5iap8kpHRsA"
    } ]
  },
  "geo" : { },
  "id_str" : "492093086319665153",
  "text" : "\"27 nations in the world invest more in their infrastructure than the USA.\" \u2014@VP on the need to #RebuildAmerica: http:\/\/t.co\/2sRpy35VPF",
  "id" : 492093086319665153,
  "created_at" : "2014-07-23 23:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/492052309086851073\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Y2uKOR004d",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BtQe9xjIUAEcZyJ.png",
      "id_str" : "492052305911762945",
      "id" : 492052305911762945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BtQe9xjIUAEcZyJ.png",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/Y2uKOR004d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/51xlpwbjy2",
      "expanded_url" : "http:\/\/wapo.st\/1lwFVcO",
      "display_url" : "wapo.st\/1lwFVcO"
    } ]
  },
  "geo" : { },
  "id_str" : "492069333435441152",
  "text" : "RT @washingtonpost: Joe Biden and his white board are here.\n http:\/\/t.co\/51xlpwbjy2 http:\/\/t.co\/Y2uKOR004d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/492052309086851073\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/Y2uKOR004d",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BtQe9xjIUAEcZyJ.png",
        "id_str" : "492052305911762945",
        "id" : 492052305911762945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BtQe9xjIUAEcZyJ.png",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/Y2uKOR004d"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/51xlpwbjy2",
        "expanded_url" : "http:\/\/wapo.st\/1lwFVcO",
        "display_url" : "wapo.st\/1lwFVcO"
      } ]
    },
    "geo" : { },
    "id_str" : "492052309086851073",
    "text" : "Joe Biden and his white board are here.\n http:\/\/t.co\/51xlpwbjy2 http:\/\/t.co\/Y2uKOR004d",
    "id" : 492052309086851073,
    "created_at" : "2014-07-23 21:03:07 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753656134565785600\/iQ1GX-ov_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 492069333435441152,
  "created_at" : "2014-07-23 22:10:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 69, 72 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/oEi2B1x1Rc",
      "expanded_url" : "http:\/\/youtu.be\/5iap8kpHRsA",
      "display_url" : "youtu.be\/5iap8kpHRsA"
    } ]
  },
  "geo" : { },
  "id_str" : "492062968650399744",
  "text" : "\"Eisenhower, a Republican, he built the Interstate Highway System.\" \u2014@VP on why the GOP should help #RebuildAmerica: http:\/\/t.co\/oEi2B1x1Rc",
  "id" : 492062968650399744,
  "created_at" : "2014-07-23 21:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 86, 89 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/KwbUi816Tv",
      "expanded_url" : "http:\/\/go.wh.gov\/yqexq6",
      "display_url" : "go.wh.gov\/yqexq6"
    } ]
  },
  "geo" : { },
  "id_str" : "492038836424552448",
  "text" : "\"It's my turn to take the pen &amp; talk about something I feel passionately about.\" \u2014@VP on the need to #RebuildAmerica: http:\/\/t.co\/KwbUi816Tv",
  "id" : 492038836424552448,
  "created_at" : "2014-07-23 20:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 58, 61 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2sRpy35VPF",
      "expanded_url" : "http:\/\/youtu.be\/5iap8kpHRsA",
      "display_url" : "youtu.be\/5iap8kpHRsA"
    } ]
  },
  "geo" : { },
  "id_str" : "492013819271454722",
  "text" : "\"It's a simple proposition: We have to #RebuildAmerica.\" \u2014@VP Biden on why it's time to fix our roads and bridges: http:\/\/t.co\/2sRpy35VPF",
  "id" : 492013819271454722,
  "created_at" : "2014-07-23 18:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492006137508941826",
  "text" : "RT @VP: Take 5 minutes to learn about why it's time to #RebuildAmerica, courtesy of VP Biden, a white board and a marker \u2192 http:\/\/t.co\/sBuv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/sBuvscb0BL",
        "expanded_url" : "http:\/\/youtu.be\/5iap8kpHRsA",
        "display_url" : "youtu.be\/5iap8kpHRsA"
      } ]
    },
    "geo" : { },
    "id_str" : "492006093665865728",
    "text" : "Take 5 minutes to learn about why it's time to #RebuildAmerica, courtesy of VP Biden, a white board and a marker \u2192 http:\/\/t.co\/sBuvscb0BL",
    "id" : 492006093665865728,
    "created_at" : "2014-07-23 17:59:28 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 492006137508941826,
  "created_at" : "2014-07-23 17:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oEi2B1x1Rc",
      "expanded_url" : "http:\/\/youtu.be\/5iap8kpHRsA",
      "display_url" : "youtu.be\/5iap8kpHRsA"
    } ]
  },
  "geo" : { },
  "id_str" : "492003830201335808",
  "text" : ".@VP Biden \u2713\nA white board \u2713\nA marker \u2713\nAnd 5 minutes you need to watch on why it's time to #RebuildAmerica \u2192 http:\/\/t.co\/oEi2B1x1Rc",
  "id" : 492003830201335808,
  "created_at" : "2014-07-23 17:50:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491999417646718976\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/K9n8YAYu6f",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BtPu3KnCUAQqJPE.png",
      "id_str" : "491999415821815812",
      "id" : 491999415821815812,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BtPu3KnCUAQqJPE.png",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K9n8YAYu6f"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/C3gAm5827M",
      "expanded_url" : "http:\/\/go.wh.gov\/veVF9Q",
      "display_url" : "go.wh.gov\/veVF9Q"
    } ]
  },
  "geo" : { },
  "id_str" : "491999417646718976",
  "text" : "\"We want fewer young men in jail. We want more of them in college.\" \u2014Obama: http:\/\/t.co\/C3gAm5827M #MyBrothersKeeper http:\/\/t.co\/K9n8YAYu6f",
  "id" : 491999417646718976,
  "created_at" : "2014-07-23 17:32:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/491972463723814912\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6umAeKac90",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtPWWUKCcAEyCew.jpg",
      "id_str" : "491972463169794049",
      "id" : 491972463169794049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtPWWUKCcAEyCew.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/6umAeKac90"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/D0crzmXSuf",
      "expanded_url" : "http:\/\/go.wh.gov\/z9Sk8j",
      "display_url" : "go.wh.gov\/z9Sk8j"
    } ]
  },
  "geo" : { },
  "id_str" : "491972463723814912",
  "text" : "\"It is a win for American workers.\" \u2014President Obama on signing the Workforce Innovation Act: http:\/\/t.co\/D0crzmXSuf http:\/\/t.co\/6umAeKac90",
  "id" : 491972463723814912,
  "created_at" : "2014-07-23 15:45:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/6BRJuaRMq2",
      "expanded_url" : "http:\/\/go.wh.gov\/XQJP8b",
      "display_url" : "go.wh.gov\/XQJP8b"
    } ]
  },
  "geo" : { },
  "id_str" : "491959463515930624",
  "text" : "\"Neil, Buzz and Michael\u2026dared to push the very boundaries of space &amp; scientific discovery for all humankind.\" \u2014Obama: http:\/\/t.co\/6BRJuaRMq2",
  "id" : 491959463515930624,
  "created_at" : "2014-07-23 14:54:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/491733591282679808\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3zvKjvUFIm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtL9GG5CQAE0Qsa.png",
      "id_str" : "491733590707683329",
      "id" : 491733590707683329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtL9GG5CQAE0Qsa.png",
      "sizes" : [ {
        "h" : 123,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 1054
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3zvKjvUFIm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491733591282679808",
  "text" : "Here's the recap of President Obama's call with Prime Minister Rutte of the Netherlands on the situation in Ukraine. http:\/\/t.co\/3zvKjvUFIm",
  "id" : 491733591282679808,
  "created_at" : "2014-07-22 23:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491683759431749632\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YCpVh5wezX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLPxfqCIAAa08Y.jpg",
      "id_str" : "491683758555144192",
      "id" : 491683758555144192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLPxfqCIAAa08Y.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YCpVh5wezX"
    } ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/porCRjUMei",
      "expanded_url" : "http:\/\/go.wh.gov\/Cc49BB",
      "display_url" : "go.wh.gov\/Cc49BB"
    } ]
  },
  "geo" : { },
  "id_str" : "491683759431749632",
  "text" : "RT to spread the word about successful job-training programs around the country \u2192 http:\/\/t.co\/porCRjUMei #ReadyToWork http:\/\/t.co\/YCpVh5wezX",
  "id" : 491683759431749632,
  "created_at" : "2014-07-22 20:38:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491674223119581185",
  "text" : "RT @VP: Here's the skinny on the VP's skills report: \nPromote partnerships \u2713\nIncrease apprenticeships \u2713\nEmpower job seekers \u2713\nhttp:\/\/t.co\/Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Y7hMuksPNS",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/\/ready-to-work",
        "display_url" : "whitehouse.gov\/\/ready-to-work"
      } ]
    },
    "geo" : { },
    "id_str" : "491673615679881217",
    "text" : "Here's the skinny on the VP's skills report: \nPromote partnerships \u2713\nIncrease apprenticeships \u2713\nEmpower job seekers \u2713\nhttp:\/\/t.co\/Y7hMuksPNS",
    "id" : 491673615679881217,
    "created_at" : "2014-07-22 19:58:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 491674223119581185,
  "created_at" : "2014-07-22 20:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netherlands Embassy",
      "screen_name" : "NLintheUSA",
      "indices" : [ 95, 106 ],
      "id_str" : "108360875",
      "id" : 108360875
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491664281453076481\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/F3xx7523eI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtK-DlBCIAAu3zp.jpg",
      "id_str" : "491664278022135808",
      "id" : 491664278022135808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtK-DlBCIAAu3zp.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/F3xx7523eI"
    } ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491664281453076481",
  "text" : "\"We will not rest until we are certain that justice is done.\" \u2014President Obama on #MH17 at the @NLintheUSA http:\/\/t.co\/F3xx7523eI",
  "id" : 491664281453076481,
  "created_at" : "2014-07-22 19:21:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491650156761448448\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/OVwaxP1kgm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKxNimCMAAviF8.jpg",
      "id_str" : "491650155519553536",
      "id" : 491650155519553536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKxNimCMAAviF8.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1007,
        "resize" : "fit",
        "w" : 1520
      } ],
      "display_url" : "pic.twitter.com\/OVwaxP1kgm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491650156761448448",
  "text" : "\"Neil Armstrong, Buzz Aldrin and Michael Collins took the 1st small steps of our giant leap into the future.\" \u2014Obama http:\/\/t.co\/OVwaxP1kgm",
  "id" : 491650156761448448,
  "created_at" : "2014-07-22 18:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491643397489180672",
  "text" : "RT @AmbassadorPower: POTUS msg to Dutch ppl after signing condolence book: \"Will not rest until we're certain that justice is done.\" #MH17 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AmbassadorPower\/status\/491641265973235713\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BcmSqvqwJU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKpIArCMAAc2I1.jpg",
        "id_str" : "491641264421351424",
        "id" : 491641264421351424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKpIArCMAAc2I1.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/BcmSqvqwJU"
      } ],
      "hashtags" : [ {
        "text" : "MH17",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491641265973235713",
    "text" : "POTUS msg to Dutch ppl after signing condolence book: \"Will not rest until we're certain that justice is done.\" #MH17 http:\/\/t.co\/BcmSqvqwJU",
    "id" : 491641265973235713,
    "created_at" : "2014-07-22 17:49:46 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 491643397489180672,
  "created_at" : "2014-07-22 17:58:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Uqu9YhjA2V",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/ready-to-work?sid=1&sid=53278091",
      "display_url" : "whitehouse.gov\/ready-to-work?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491642014501335040",
  "text" : "RT @DrBiden: It\u2019s important students learn the skills in the classroom they need to succeed in the workplace. \u2013 Jill http:\/\/t.co\/Uqu9YhjA2V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReadyToWork",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Uqu9YhjA2V",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/ready-to-work?sid=1&sid=53278091",
        "display_url" : "whitehouse.gov\/ready-to-work?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "491625682079076353",
    "text" : "It\u2019s important students learn the skills in the classroom they need to succeed in the workplace. \u2013 Jill http:\/\/t.co\/Uqu9YhjA2V #ReadyToWork",
    "id" : 491625682079076353,
    "created_at" : "2014-07-22 16:47:51 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 491642014501335040,
  "created_at" : "2014-07-22 17:52:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491631111270055938\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2ua8fpcAaR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKf4_BCQAAIUSX.png",
      "id_str" : "491631110674071552",
      "id" : 491631110674071552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKf4_BCQAAIUSX.png",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 1082
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2ua8fpcAaR"
    } ],
    "hashtags" : [ {
      "text" : "Apollo45",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491631111270055938",
  "text" : "\"It was a seminal moment not just in our country\u2019s history, but the history of all humankind.\" \u2014Obama on #Apollo45 http:\/\/t.co\/2ua8fpcAaR",
  "id" : 491631111270055938,
  "created_at" : "2014-07-22 17:09:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491625541829922816",
  "text" : "\"America is full of...men and women who work very hard...and all they want in return is to see their hard work pay off.\" \u2014Obama #ReadyToWork",
  "id" : 491625541829922816,
  "created_at" : "2014-07-22 16:47:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491624849316405248",
  "text" : "\u201CLet\u2019s do this more often\u2026let\u2019s pass more bills that help create good jobs, strengthen the middle class.\u201D \u2014President Obama #ReadyToWork",
  "id" : 491624849316405248,
  "created_at" : "2014-07-22 16:44:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 120, 132 ]
    }, {
      "text" : "WIOA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491624298076184577",
  "text" : "President Obama: \"The bill I\u2019m signing today...will connect more ready-to-work Americans with ready-to-be-filled jobs.\" #ReadyToWork #WIOA",
  "id" : 491624298076184577,
  "created_at" : "2014-07-22 16:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491623181560868864",
  "text" : "\"This is not a win for Democrats or Republicans. It is a win for American workers.\" \u2014Obama on the Workforce Investment Act #ReadyToWork",
  "id" : 491623181560868864,
  "created_at" : "2014-07-22 16:37:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491622912110362624",
  "text" : "\u201CIf you\u2019re working hard, you should be able to get a job, and that job should pay well.\u201D \u2014President Obama #ReadyToWork",
  "id" : 491622912110362624,
  "created_at" : "2014-07-22 16:36:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491622565790875648\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/JQa0zgO3Vk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKYHjbCAAAESaI.jpg",
      "id_str" : "491622564871929856",
      "id" : 491622564871929856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKYHjbCAAAESaI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JQa0zgO3Vk"
    } ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491622565790875648",
  "text" : "\"Our businesses have added nearly 10 million new jobs over the past 52 months.\" \u2014President Obama #ReadyToWork http:\/\/t.co\/JQa0zgO3Vk",
  "id" : 491622565790875648,
  "created_at" : "2014-07-22 16:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491622366708256768",
  "text" : "\"It\u2019s helped millions of Americans earn the skills they needed to find a new job.\" \u2014Obama on the Workforce Investment Act #ReadyToWork",
  "id" : 491622366708256768,
  "created_at" : "2014-07-22 16:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491621487607308289",
  "text" : "RT @VP: \"To maintain our place in the world we need to keep the world\u2019s most skilled workforce right here in America.\" - VP Biden #ReadyToW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReadyToWork",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491621353150500865",
    "text" : "\"To maintain our place in the world we need to keep the world\u2019s most skilled workforce right here in America.\" - VP Biden #ReadyToWork",
    "id" : 491621353150500865,
    "created_at" : "2014-07-22 16:30:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 491621487607308289,
  "created_at" : "2014-07-22 16:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/sjc2qjrrEQ",
      "expanded_url" : "http:\/\/go.wh.gov\/Y8XMpK",
      "display_url" : "go.wh.gov\/Y8XMpK"
    } ]
  },
  "geo" : { },
  "id_str" : "491619595417964544",
  "text" : "RT @WHLive: The @VP introduces the President before he signs the Workforce Innovation &amp; Opportunity Act \u2192 http:\/\/t.co\/sjc2qjrrEQ http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 4, 7 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/491619561339232256\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/3ujm8QKoc4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKVYrfCUAAOoOf.png",
        "id_str" : "491619560559104000",
        "id" : 491619560559104000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKVYrfCUAAOoOf.png",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 676
        } ],
        "display_url" : "pic.twitter.com\/3ujm8QKoc4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/sjc2qjrrEQ",
        "expanded_url" : "http:\/\/go.wh.gov\/Y8XMpK",
        "display_url" : "go.wh.gov\/Y8XMpK"
      } ]
    },
    "geo" : { },
    "id_str" : "491619561339232256",
    "text" : "The @VP introduces the President before he signs the Workforce Innovation &amp; Opportunity Act \u2192 http:\/\/t.co\/sjc2qjrrEQ http:\/\/t.co\/3ujm8QKoc4",
    "id" : 491619561339232256,
    "created_at" : "2014-07-22 16:23:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 491619595417964544,
  "created_at" : "2014-07-22 16:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 132, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/TpVm0nKwsk",
      "expanded_url" : "http:\/\/go.wh.gov\/mxyHGD",
      "display_url" : "go.wh.gov\/mxyHGD"
    } ]
  },
  "geo" : { },
  "id_str" : "491616679844401153",
  "text" : "Starting soon: President Obama speaks before signing the Workforce Innovation &amp; Opportunity Act. Watch \u2192 http:\/\/t.co\/TpVm0nKwsk #ReadyToWork",
  "id" : 491616679844401153,
  "created_at" : "2014-07-22 16:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Buzz Aldrin",
      "screen_name" : "TheRealBuzz",
      "indices" : [ 73, 85 ],
      "id_str" : "46220856",
      "id" : 46220856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Apollo11",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491611157237489664",
  "text" : "RT @NASA: President Obama met with #Apollo11 astronauts Michael Collins, @TheRealBuzz, Carol Armstrong &amp; Admin. Bolden today http:\/\/t.co\/dn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buzz Aldrin",
        "screen_name" : "TheRealBuzz",
        "indices" : [ 63, 75 ],
        "id_str" : "46220856",
        "id" : 46220856
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/491608578093248512\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/dnMzjBUarq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKLZYMCcAEOu4x.jpg",
        "id_str" : "491608577442738177",
        "id" : 491608577442738177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKLZYMCcAEOu4x.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1026,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dnMzjBUarq"
      } ],
      "hashtags" : [ {
        "text" : "Apollo11",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491608578093248512",
    "text" : "President Obama met with #Apollo11 astronauts Michael Collins, @TheRealBuzz, Carol Armstrong &amp; Admin. Bolden today http:\/\/t.co\/dnMzjBUarq",
    "id" : 491608578093248512,
    "created_at" : "2014-07-22 15:39:53 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 491611157237489664,
  "created_at" : "2014-07-22 15:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491603585822511104\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qVvbvtKp3p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtKFnwWCQAAjz7P.jpg",
      "id_str" : "491602227375521792",
      "id" : 491602227375521792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtKFnwWCQAAjz7P.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/qVvbvtKp3p"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/VZkL65v7B0",
      "expanded_url" : "http:\/\/go.wh.gov\/Y8XMpK",
      "display_url" : "go.wh.gov\/Y8XMpK"
    } ]
  },
  "geo" : { },
  "id_str" : "491603585822511104",
  "text" : "It's time to equip more of our workers with the skills to compete in the 21st century economy: http:\/\/t.co\/VZkL65v7B0 http:\/\/t.co\/qVvbvtKp3p",
  "id" : 491603585822511104,
  "created_at" : "2014-07-22 15:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/tWyOoWVqEb",
      "expanded_url" : "http:\/\/go.wh.gov\/Y8XMpK",
      "display_url" : "go.wh.gov\/Y8XMpK"
    } ]
  },
  "geo" : { },
  "id_str" : "491595684127051776",
  "text" : "RT @VP: New report from the VP: Get the latest on how we can help more Americans find good jobs and careers \u2192 http:\/\/t.co\/tWyOoWVqEb #Ready\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReadyToWork",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/tWyOoWVqEb",
        "expanded_url" : "http:\/\/go.wh.gov\/Y8XMpK",
        "display_url" : "go.wh.gov\/Y8XMpK"
      } ]
    },
    "geo" : { },
    "id_str" : "491594911666696192",
    "text" : "New report from the VP: Get the latest on how we can help more Americans find good jobs and careers \u2192 http:\/\/t.co\/tWyOoWVqEb #ReadyToWork",
    "id" : 491594911666696192,
    "created_at" : "2014-07-22 14:45:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 491595684127051776,
  "created_at" : "2014-07-22 14:48:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 36, 39 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/22nraNThvF",
      "expanded_url" : "http:\/\/go.wh.gov\/Y8XMpK",
      "display_url" : "go.wh.gov\/Y8XMpK"
    } ]
  },
  "geo" : { },
  "id_str" : "491594529209090048",
  "text" : "Learn how President Obama &amp; the @VP are working to connect more Americans who are #ReadyToWork with available jobs \u2192 http:\/\/t.co\/22nraNThvF",
  "id" : 491594529209090048,
  "created_at" : "2014-07-22 14:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Paul",
      "screen_name" : "CP3",
      "indices" : [ 36, 40 ],
      "id_str" : "53853197",
      "id" : 53853197
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491379744186056705\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/pZGuVufHsj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtG7RfsCUAA5vyZ.jpg",
      "id_str" : "491379743598465024",
      "id" : 491379743598465024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtG7RfsCUAA5vyZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/pZGuVufHsj"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/JOBIeY0Ctg",
      "expanded_url" : "http:\/\/go.wh.gov\/QzLKep",
      "display_url" : "go.wh.gov\/QzLKep"
    } ]
  },
  "geo" : { },
  "id_str" : "491379744186056705",
  "text" : "President Obama gets an assist from @CP3 to help more young people succeed \u2192 http:\/\/t.co\/JOBIeY0Ctg #MyBrothersKeeper http:\/\/t.co\/pZGuVufHsj",
  "id" : 491379744186056705,
  "created_at" : "2014-07-22 00:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491372364614336513",
  "text" : "RT @arneduncan: Thrilled to see the opportunity for #MyBrothersKeeper to positively impact the lives of boys of color in our schools! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 36, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/MjFWZ63ONR",
        "expanded_url" : "http:\/\/ow.ly\/zqjzH",
        "display_url" : "ow.ly\/zqjzH"
      } ]
    },
    "geo" : { },
    "id_str" : "491361922689032192",
    "text" : "Thrilled to see the opportunity for #MyBrothersKeeper to positively impact the lives of boys of color in our schools! http:\/\/t.co\/MjFWZ63ONR",
    "id" : 491361922689032192,
    "created_at" : "2014-07-21 23:19:46 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 491372364614336513,
  "created_at" : "2014-07-22 00:01:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491338086270631936\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OQz3mhPGFV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtGVYrpCUAI2eaZ.jpg",
      "id_str" : "491338085624336386",
      "id" : 491338085624336386,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtGVYrpCUAI2eaZ.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OQz3mhPGFV"
    } ],
    "hashtags" : [ {
      "text" : "WorkplaceEquality",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bHOEtfChq4",
      "expanded_url" : "http:\/\/go.wh.gov\/Tpc8Gq",
      "display_url" : "go.wh.gov\/Tpc8Gq"
    } ]
  },
  "geo" : { },
  "id_str" : "491338086270631936",
  "text" : "\"We're on the right side of history.\" \u2014Obama on expanding #WorkplaceEquality for LGBT workers: http:\/\/t.co\/bHOEtfChq4 http:\/\/t.co\/OQz3mhPGFV",
  "id" : 491338086270631936,
  "created_at" : "2014-07-21 21:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 12, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491328803621179393",
  "text" : "RT @USArmy: #MedalOfHonor recipient SSG Ryan Pitts &amp; his wife Amy are celebrating their 2nd anniversary at the @WhiteHouse http:\/\/t.co\/8haG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USArmy\/status\/491325241751527425\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/8haGbYSeS3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtGJs_8IIAARjNt.jpg",
        "id_str" : "491325240530968576",
        "id" : 491325240530968576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtGJs_8IIAARjNt.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8haGbYSeS3"
      } ],
      "hashtags" : [ {
        "text" : "MedalOfHonor",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491325241751527425",
    "text" : "#MedalOfHonor recipient SSG Ryan Pitts &amp; his wife Amy are celebrating their 2nd anniversary at the @WhiteHouse http:\/\/t.co\/8haGbYSeS3",
    "id" : 491325241751527425,
    "created_at" : "2014-07-21 20:54:00 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 491328803621179393,
  "created_at" : "2014-07-21 21:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491301631863291904",
  "text" : "\"Today, we honor 9 American soldiers who made the ultimate sacrifice for us all.\" \u2014Obama on the Battle of Wanat in Afghanistan #MedalOfHonor",
  "id" : 491301631863291904,
  "created_at" : "2014-07-21 19:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491301001287462912",
  "text" : "\"Today, we also pay tribute to all who served with such valor...shielding their wounded buddies with their own bodies.\" \u2014Obama #MedalOfHonor",
  "id" : 491301001287462912,
  "created_at" : "2014-07-21 19:17:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USArmy",
      "indices" : [ 12, 19 ]
    }, {
      "text" : "SoldierForLife",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6F2A07Sa31",
      "expanded_url" : "http:\/\/instagram.com\/p\/qjc7oZnEr9\/",
      "display_url" : "instagram.com\/p\/qjc7oZnEr9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "491300030654185473",
  "text" : "RT @USArmy: #USArmy Staff Sgt. Ryan Pitts knew he wanted to be a Soldier when he was in kindergarten: http:\/\/t.co\/6F2A07Sa31 #SoldierForLife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USArmy",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "SoldierForLife",
        "indices" : [ 113, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/6F2A07Sa31",
        "expanded_url" : "http:\/\/instagram.com\/p\/qjc7oZnEr9\/",
        "display_url" : "instagram.com\/p\/qjc7oZnEr9\/"
      } ]
    },
    "geo" : { },
    "id_str" : "491299834444660736",
    "text" : "#USArmy Staff Sgt. Ryan Pitts knew he wanted to be a Soldier when he was in kindergarten: http:\/\/t.co\/6F2A07Sa31 #SoldierForLife",
    "id" : 491299834444660736,
    "created_at" : "2014-07-21 19:13:03 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 491300030654185473,
  "created_at" : "2014-07-21 19:13:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 39, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "491298925257969664",
  "text" : "Watch live: President Obama awards the #MedalOfHonor to Staff Sgt. Pitts for his service in Afghanistan \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 491298925257969664,
  "created_at" : "2014-07-21 19:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USArmy",
      "indices" : [ 12, 19 ]
    }, {
      "text" : "MedalOfHonor",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/fC0JBuwzNO",
      "expanded_url" : "http:\/\/go.usa.gov\/9bvT",
      "display_url" : "go.usa.gov\/9bvT"
    } ]
  },
  "geo" : { },
  "id_str" : "491296995764875264",
  "text" : "RT @USArmy: #USArmy Staff Sgt. Ryan Pitts is getting squared away for today's #MedalOfHonor ceremony.  http:\/\/t.co\/fC0JBuwzNO http:\/\/t.co\/W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USArmy\/status\/491263484404203520\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/WESjxGc1Eq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtFRh6kIMAAUZgV.jpg",
        "id_str" : "491263477458415616",
        "id" : 491263477458415616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtFRh6kIMAAUZgV.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WESjxGc1Eq"
      } ],
      "hashtags" : [ {
        "text" : "USArmy",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "MedalOfHonor",
        "indices" : [ 66, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/fC0JBuwzNO",
        "expanded_url" : "http:\/\/go.usa.gov\/9bvT",
        "display_url" : "go.usa.gov\/9bvT"
      } ]
    },
    "geo" : { },
    "id_str" : "491263484404203520",
    "text" : "#USArmy Staff Sgt. Ryan Pitts is getting squared away for today's #MedalOfHonor ceremony.  http:\/\/t.co\/fC0JBuwzNO http:\/\/t.co\/WESjxGc1Eq",
    "id" : 491263484404203520,
    "created_at" : "2014-07-21 16:48:36 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 491296995764875264,
  "created_at" : "2014-07-21 19:01:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 41, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "491295592082313216",
  "text" : "At 3:05pm ET, President Obama awards the #MedalOfHonor to Staff Sgt. Pitts for his service in Afghanistan. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 491295592082313216,
  "created_at" : "2014-07-21 18:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "indices" : [ 3, 16 ],
      "id_str" : "15846407",
      "id" : 15846407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ULQuMBzOaT",
      "expanded_url" : "http:\/\/go.wh.gov\/ueF1ok",
      "display_url" : "go.wh.gov\/ueF1ok"
    } ]
  },
  "geo" : { },
  "id_str" : "491293716649627648",
  "text" : "RT @TheEllenShow: Amen. RT The President is taking action to protect #LGBT workers from employment discrimination: http:\/\/t.co\/ULQuMBzOaT #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 51, 56 ]
      }, {
        "text" : "WorkplaceEquality",
        "indices" : [ 120, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/ULQuMBzOaT",
        "expanded_url" : "http:\/\/go.wh.gov\/ueF1ok",
        "display_url" : "go.wh.gov\/ueF1ok"
      } ]
    },
    "geo" : { },
    "id_str" : "491274615272914944",
    "text" : "Amen. RT The President is taking action to protect #LGBT workers from employment discrimination: http:\/\/t.co\/ULQuMBzOaT #WorkplaceEquality",
    "id" : 491274615272914944,
    "created_at" : "2014-07-21 17:32:50 +0000",
    "user" : {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "protected" : false,
      "id_str" : "15846407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789558314191425539\/X_imv1vL_normal.jpg",
      "id" : 15846407,
      "verified" : true
    }
  },
  "id" : 491293716649627648,
  "created_at" : "2014-07-21 18:48:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ksCMcx5xxZ",
      "expanded_url" : "http:\/\/youtu.be\/valZEKv5cBg",
      "display_url" : "youtu.be\/valZEKv5cBg"
    } ]
  },
  "geo" : { },
  "id_str" : "491270990782300160",
  "text" : "Watch President Obama's statement on the situations in Ukraine and Gaza \u2192 http:\/\/t.co\/ksCMcx5xxZ",
  "id" : 491270990782300160,
  "created_at" : "2014-07-21 17:18:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491262986464788480",
  "text" : "\u201CIf someone\u2019s putting time into you, you\u2019ve got to show appreciation for it and try your hardest to succeed.\u201D \u2014Obama #MyBrothersKeeper",
  "id" : 491262986464788480,
  "created_at" : "2014-07-21 16:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491262465418997760",
  "text" : "RT @vj44: \"Everything you do that is worthwhile will require work, including being a parent.\" -POTUS' advice on reaching your dreams #MyBro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491262216625074176",
    "text" : "\"Everything you do that is worthwhile will require work, including being a parent.\" -POTUS' advice on reaching your dreams #MyBrothersKeeper",
    "id" : 491262216625074176,
    "created_at" : "2014-07-21 16:43:34 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 491262465418997760,
  "created_at" : "2014-07-21 16:44:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Kl5KzBmgyT",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491260499498381312",
  "text" : "RT @WHLive: \u201CYou don\u2019t have to act a certain way to be authentic.\u201D \u2014Obama giving advice to young men of color: http:\/\/t.co\/Kl5KzBmgyT #MyBr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 122, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Kl5KzBmgyT",
        "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
        "display_url" : "wh.gov\/my-brothers-ke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "491260455395270656",
    "text" : "\u201CYou don\u2019t have to act a certain way to be authentic.\u201D \u2014Obama giving advice to young men of color: http:\/\/t.co\/Kl5KzBmgyT #MyBrothersKeeper",
    "id" : 491260455395270656,
    "created_at" : "2014-07-21 16:36:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 491260499498381312,
  "created_at" : "2014-07-21 16:36:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491258274432700416",
  "text" : "\u201CWhat makes this country great is, we may have different faiths, but we all come together as one American family.\u201D \u2014Obama #MyBrothersKeeper",
  "id" : 491258274432700416,
  "created_at" : "2014-07-21 16:27:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/491256438795546624\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/dOuHwkLzcN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtFLILBCIAEWS9Z.png",
      "id_str" : "491256438128254977",
      "id" : 491256438128254977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtFLILBCIAEWS9Z.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/dOuHwkLzcN"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 94, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/WhgjTirUjI",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491256438795546624",
  "text" : "\u201CThere is no greater joy than being in your children\u2019s lives.\u201D \u2014Obama: http:\/\/t.co\/WhgjTirUjI #MyBrothersKeeper http:\/\/t.co\/dOuHwkLzcN",
  "id" : 491256438795546624,
  "created_at" : "2014-07-21 16:20:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491255720646803458",
  "text" : "RT @WHLive: \u201CLoving your child. Being responsible for your child. Teaching them how to be honest.\u201D \u2014Obama answering a question on being a g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491255691739664384",
    "text" : "\u201CLoving your child. Being responsible for your child. Teaching them how to be honest.\u201D \u2014Obama answering a question on being a good dad",
    "id" : 491255691739664384,
    "created_at" : "2014-07-21 16:17:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 491255720646803458,
  "created_at" : "2014-07-21 16:17:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491255320355012608",
  "text" : "\u201CI had this mom who just loved me a lot\u2026to all the heroic single moms out there, we appreciate you.\u201D \u2014President Obama #MyBrothersKeeper",
  "id" : 491255320355012608,
  "created_at" : "2014-07-21 16:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 104, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/WhgjTirUjI",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491253266211418112",
  "text" : "\u201CAmerica will succeed if we\u2019re investing in our young people.\u201D \u2014President Obama: http:\/\/t.co\/WhgjTirUjI #MyBrothersKeeper",
  "id" : 491253266211418112,
  "created_at" : "2014-07-21 16:08:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WhgjTirUjI",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491251825786777600",
  "text" : "\u201CI\u2019m here for a simple reason\u2026I want to hear from many of you. The young people who are here today.\u201D \u2014Obama\nWatch \u2192 http:\/\/t.co\/WhgjTirUjI",
  "id" : 491251825786777600,
  "created_at" : "2014-07-21 16:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Chris Paul",
      "screen_name" : "CP3",
      "indices" : [ 24, 28 ],
      "id_str" : "53853197",
      "id" : 53853197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Kl5KzBmgyT",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491250884652040192",
  "text" : "RT @WHLive: Watch live: @CP3 introduces President Obama at a town hall on helping more young people succeed \u2192 http:\/\/t.co\/Kl5KzBmgyT #MyBro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Paul",
        "screen_name" : "CP3",
        "indices" : [ 12, 16 ],
        "id_str" : "53853197",
        "id" : 53853197
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 121, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Kl5KzBmgyT",
        "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
        "display_url" : "wh.gov\/my-brothers-ke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "491250850749485056",
    "text" : "Watch live: @CP3 introduces President Obama at a town hall on helping more young people succeed \u2192 http:\/\/t.co\/Kl5KzBmgyT #MyBrothersKeeper",
    "id" : 491250850749485056,
    "created_at" : "2014-07-21 15:58:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 491250884652040192,
  "created_at" : "2014-07-21 15:58:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/WhgjTirUjI",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "491249091528376321",
  "text" : "Starting soon, President Obama participates in a town hall on helping more young people succeed \u2192 http:\/\/t.co\/WhgjTirUjI #MyBrothersKeeper",
  "id" : 491249091528376321,
  "created_at" : "2014-07-21 15:51:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "491240155169042433",
  "text" : "Watch live: President Obama delivers a statement on the situation in Ukraine \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 491240155169042433,
  "created_at" : "2014-07-21 15:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491232605275455488",
  "text" : "\"We have an obligation to make sure the country we love remains a place where no matter...who you love, you can make it.\" \u2014President Obama",
  "id" : 491232605275455488,
  "created_at" : "2014-07-21 14:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceEquality",
      "indices" : [ 110, 128 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491232087794794496",
  "text" : "\"I firmly believe that it\u2019s time to address this injustice for every American.\" \u2014President Obama on expanding #WorkplaceEquality #LGBT",
  "id" : 491232087794794496,
  "created_at" : "2014-07-21 14:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491231906420105217",
  "text" : "\"In too many states and too many workplaces, simply being gay, lesbian, bisexual or transgender can still be a fireable offense.\" \u2014Obama",
  "id" : 491231906420105217,
  "created_at" : "2014-07-21 14:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceEquality",
      "indices" : [ 112, 130 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491231583261560833",
  "text" : "\"America\u2019s federal contracts should not subsidize discrimination against the American people.\" \u2014President Obama #WorkplaceEquality #LGBT",
  "id" : 491231583261560833,
  "created_at" : "2014-07-21 14:41:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceEquality",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491231263479435264",
  "text" : "\"We\u2019re here today to do what we can to make it right\u2014to bend the arc of the moral universe...closer to justice.\" \u2014Obama #WorkplaceEquality",
  "id" : 491231263479435264,
  "created_at" : "2014-07-21 14:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkplaceEquality",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "491230582551347200",
  "text" : "Happening now: President Obama acts to protect LGBT workers from employment discrimination. Watch: http:\/\/t.co\/b4tqL3oo0v #WorkplaceEquality",
  "id" : 491230582551347200,
  "created_at" : "2014-07-21 14:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "491225161002012672",
  "text" : "At 10:50am ET, President Obama will deliver a statement on the situation in Ukraine \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 491225161002012672,
  "created_at" : "2014-07-21 14:16:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "WorkplaceEquality",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/D6wWaX0DcF",
      "expanded_url" : "http:\/\/go.wh.gov\/ueF1ok",
      "display_url" : "go.wh.gov\/ueF1ok"
    } ]
  },
  "geo" : { },
  "id_str" : "491217187496292352",
  "text" : "RT to spread the word: President Obama's acting to protect #LGBT workers from discrimination \u2192 http:\/\/t.co\/D6wWaX0DcF #WorkplaceEquality",
  "id" : 491217187496292352,
  "created_at" : "2014-07-21 13:44:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 3, 7 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "NBPA",
      "screen_name" : "TheNBPA",
      "indices" : [ 14, 22 ],
      "id_str" : "116900697",
      "id" : 116900697
    }, {
      "name" : "NBA Alumni",
      "screen_name" : "NBAalumni",
      "indices" : [ 29, 39 ],
      "id_str" : "89794869",
      "id" : 89794869
    }, {
      "name" : "MENTOR",
      "screen_name" : "MENTORnational",
      "indices" : [ 107, 122 ],
      "id_str" : "104524102",
      "id" : 104524102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 72, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491211084087316480",
  "text" : "RT @NBA: NBA, @TheNBPA &amp; @NBAalumni announced commitment to support #MyBrothersKeeper in partnership w @MENTORnational: http:\/\/t.co\/LcnKQxO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBPA",
        "screen_name" : "TheNBPA",
        "indices" : [ 5, 13 ],
        "id_str" : "116900697",
        "id" : 116900697
      }, {
        "name" : "NBA Alumni",
        "screen_name" : "NBAalumni",
        "indices" : [ 20, 30 ],
        "id_str" : "89794869",
        "id" : 89794869
      }, {
        "name" : "MENTOR",
        "screen_name" : "MENTORnational",
        "indices" : [ 98, 113 ],
        "id_str" : "104524102",
        "id" : 104524102
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 63, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LcnKQxOr60",
        "expanded_url" : "http:\/\/on.nba.com\/1ntW88g",
        "display_url" : "on.nba.com\/1ntW88g"
      } ]
    },
    "geo" : { },
    "id_str" : "491209855110496256",
    "text" : "NBA, @TheNBPA &amp; @NBAalumni announced commitment to support #MyBrothersKeeper in partnership w @MENTORnational: http:\/\/t.co\/LcnKQxOr60",
    "id" : 491209855110496256,
    "created_at" : "2014-07-21 13:15:30 +0000",
    "user" : {
      "name" : "NBA",
      "screen_name" : "NBA",
      "protected" : false,
      "id_str" : "19923144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797568531047051264\/LcjOmxGH_normal.jpg",
      "id" : 19923144,
      "verified" : true
    }
  },
  "id" : 491211084087316480,
  "created_at" : "2014-07-21 13:20:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/490942208657195008\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/6TzTCIasIM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtAtVifCUAE5aJn.png",
      "id_str" : "490942207440867329",
      "id" : 490942207440867329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtAtVifCUAE5aJn.png",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6TzTCIasIM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/eZ7uSlAHfE",
      "expanded_url" : "http:\/\/go.wh.gov\/iTppXh",
      "display_url" : "go.wh.gov\/iTppXh"
    } ]
  },
  "geo" : { },
  "id_str" : "490942208657195008",
  "text" : "The President &amp; Prime Minister Netanyahu spoke this morning to discuss the situation in Gaza: http:\/\/t.co\/eZ7uSlAHfE http:\/\/t.co\/6TzTCIasIM",
  "id" : 490942208657195008,
  "created_at" : "2014-07-20 19:31:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/489835781402660864\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uqTDEFcNXV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsw_C86CEAAJ1Ep.jpg",
      "id_str" : "489835779418361856",
      "id" : 489835779418361856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsw_C86CEAAJ1Ep.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uqTDEFcNXV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/AqnMHEQd7K",
      "expanded_url" : "http:\/\/go.wh.gov\/BUnRit",
      "display_url" : "go.wh.gov\/BUnRit"
    } ]
  },
  "geo" : { },
  "id_str" : "490586977620594688",
  "text" : "\"Over the past 52 months, our businesses have created nearly 10 million new jobs.\" \u2014Obama: http:\/\/t.co\/AqnMHEQd7K  http:\/\/t.co\/uqTDEFcNXV",
  "id" : 490586977620594688,
  "created_at" : "2014-07-19 20:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "FamiliesSucceed",
      "indices" : [ 105, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/AqnMHEQd7K",
      "expanded_url" : "http:\/\/go.wh.gov\/BUnRit",
      "display_url" : "go.wh.gov\/BUnRit"
    } ]
  },
  "geo" : { },
  "id_str" : "490556723153747969",
  "text" : "\"We should fight for fair pay and paid family leave.\" \u2014President Obama: http:\/\/t.co\/AqnMHEQd7K #EqualPay #FamiliesSucceed",
  "id" : 490556723153747969,
  "created_at" : "2014-07-19 18:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/AqnMHEQd7K",
      "expanded_url" : "http:\/\/go.wh.gov\/BUnRit",
      "display_url" : "go.wh.gov\/BUnRit"
    } ]
  },
  "geo" : { },
  "id_str" : "490526580406366208",
  "text" : "\"We should raise the minimum wage so that no one who works full-time has to live in poverty.\" \u2014Obama: http:\/\/t.co\/AqnMHEQd7K #RaiseTheWage",
  "id" : 490526580406366208,
  "created_at" : "2014-07-19 16:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/AqnMHEQd7K",
      "expanded_url" : "http:\/\/go.wh.gov\/BUnRit",
      "display_url" : "go.wh.gov\/BUnRit"
    } ]
  },
  "geo" : { },
  "id_str" : "490511489657081856",
  "text" : "\"I will do whatever I can, whenever I can, to help families like yours.\" \u2014President Obama: http:\/\/t.co\/AqnMHEQd7K #OpportunityForAll",
  "id" : 490511489657081856,
  "created_at" : "2014-07-19 15:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/490294959501623296\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/0opkwwrtyK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bs3cSBECUAELf31.png",
      "id_str" : "490290136534372353",
      "id" : 490290136534372353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bs3cSBECUAELf31.png",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 743
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 743
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0opkwwrtyK"
    } ],
    "hashtags" : [ {
      "text" : "MandelaDay",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490294959501623296",
  "text" : "\"We can honor and emulate him by taking time...to engage in acts of service.\" \u2014President Obama on #MandelaDay: http:\/\/t.co\/0opkwwrtyK",
  "id" : 490294959501623296,
  "created_at" : "2014-07-19 00:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MandelaDay",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490288657451216896",
  "text" : "\"Nelson Mandela was one of the most influential, courageous, and profoundly decent human beings to grace the earth.\" \u2014Obama on #MandelaDay",
  "id" : 490288657451216896,
  "created_at" : "2014-07-19 00:14:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490252209318526976",
  "text" : "RT @VP: This afternoon, VP Biden spoke with President Poroshenko of Ukraine. A full readout will be available this evening.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "490251883421126658",
    "text" : "This afternoon, VP Biden spoke with President Poroshenko of Ukraine. A full readout will be available this evening.",
    "id" : 490251883421126658,
    "created_at" : "2014-07-18 21:48:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 490252209318526976,
  "created_at" : "2014-07-18 21:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490250249483874304",
  "text" : "RT @vj44: This Monday, Pres Obama will sign an Executive Order protecting #LGBT workers from employment discrimination #OpportunityForAll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 64, 69 ]
      }, {
        "text" : "OpportunityForAll",
        "indices" : [ 109, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "490219530715533312",
    "text" : "This Monday, Pres Obama will sign an Executive Order protecting #LGBT workers from employment discrimination #OpportunityForAll",
    "id" : 490219530715533312,
    "created_at" : "2014-07-18 19:40:18 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 490250249483874304,
  "created_at" : "2014-07-18 21:42:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MandelaDay",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490221111356174338",
  "text" : "RT @FLOTUS: Let's draw inspiration from Madiba's example &amp; recommit ourselves to leaving our kids a better world. #MandelaDay \u2013mo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/490219331612319744\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/ceL4CWNZ88",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bs2b4lyCAAAwOwg.jpg",
        "id_str" : "490219330970189824",
        "id" : 490219330970189824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bs2b4lyCAAAwOwg.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ceL4CWNZ88"
      } ],
      "hashtags" : [ {
        "text" : "MandelaDay",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "490219331612319744",
    "text" : "Let's draw inspiration from Madiba's example &amp; recommit ourselves to leaving our kids a better world. #MandelaDay \u2013mo http:\/\/t.co\/ceL4CWNZ88",
    "id" : 490219331612319744,
    "created_at" : "2014-07-18 19:39:31 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 490221111356174338,
  "created_at" : "2014-07-18 19:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/490201139330433024\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/X1XTNoJMMR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bs2LVp-CUAEybpa.jpg",
      "id_str" : "490201138612817921",
      "id" : 490201138612817921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bs2LVp-CUAEybpa.jpg",
      "sizes" : [ {
        "h" : 134,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/X1XTNoJMMR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/5MaqJ4YR0V",
      "expanded_url" : "http:\/\/lat.ms\/1jTMR9c",
      "display_url" : "lat.ms\/1jTMR9c"
    } ]
  },
  "geo" : { },
  "id_str" : "490201139330433024",
  "text" : "\"This is the person we are working for.\" \u2014Obama on a letter he got from a single mom in DE: http:\/\/t.co\/5MaqJ4YR0V http:\/\/t.co\/X1XTNoJMMR",
  "id" : 490201139330433024,
  "created_at" : "2014-07-18 18:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490171503468490752",
  "text" : "\"The United States will continue to lead efforts within the world community to de-escalate the situation.\" \u2014Obama on Ukraine &amp; flight #MH17",
  "id" : 490171503468490752,
  "created_at" : "2014-07-18 16:29:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490166885754089472",
  "text" : "\"There must be a credible, international investigation into what happened.\" \u2014President Obama on flight #MH17",
  "id" : 490166885754089472,
  "created_at" : "2014-07-18 16:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490166712315035648",
  "text" : "\"I want the Dutch people to know that we stand with you, shoulder to shoulder, in our grief.\" \u2014President Obama on flight #MH17",
  "id" : 490166712315035648,
  "created_at" : "2014-07-18 16:10:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "490162466874470400",
  "text" : "Happening now: President Obama delivers a statement on the situation in Ukraine \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 490162466874470400,
  "created_at" : "2014-07-18 15:53:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "490139274835427328",
  "text" : "At 11:30am ET, President Obama delivers a statement on the situation in Ukraine. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 490139274835427328,
  "created_at" : "2014-07-18 14:21:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489973547671244800",
  "text" : "RT @PressSec: The US is shocked by the downing of #MH17 &amp; we offer our deep condolences to all those who lost loved ones on board. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489965827282968576\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/rIKvNAL3Xs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsy1UqDCAAALk1m.png",
        "id_str" : "489965825965555712",
        "id" : 489965825965555712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsy1UqDCAAALk1m.png",
        "sizes" : [ {
          "h" : 466,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com\/rIKvNAL3Xs"
      } ],
      "hashtags" : [ {
        "text" : "MH17",
        "indices" : [ 36, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489971807546798081",
    "text" : "The US is shocked by the downing of #MH17 &amp; we offer our deep condolences to all those who lost loved ones on board. http:\/\/t.co\/rIKvNAL3Xs",
    "id" : 489971807546798081,
    "created_at" : "2014-07-18 03:15:56 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 489973547671244800,
  "created_at" : "2014-07-18 03:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 76, 85 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489965827282968576\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/LN4gNIXfZh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsy1UqDCAAALk1m.png",
      "id_str" : "489965825965555712",
      "id" : 489965825965555712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsy1UqDCAAALk1m.png",
      "sizes" : [ {
        "h" : 466,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/LN4gNIXfZh"
    } ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489965827282968576",
  "text" : "\"We offer our deep condolences to all those who lost loved ones on board.\" \u2014@PressSec on #MH17: http:\/\/t.co\/LN4gNIXfZh",
  "id" : 489965827282968576,
  "created_at" : "2014-07-18 02:52:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/489898559782027264\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/wFIPqFcdq0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsx4JNhCAAAa8PY.jpg",
      "id_str" : "489898559118901248",
      "id" : 489898559118901248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsx4JNhCAAAa8PY.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wFIPqFcdq0"
    } ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/epcGXUhN1V",
      "expanded_url" : "http:\/\/go.wh.gov\/D4bM2X",
      "display_url" : "go.wh.gov\/D4bM2X"
    } ]
  },
  "geo" : { },
  "id_str" : "489898559782027264",
  "text" : "President Obama spoke to Ukrainian President Poroshenko following the tragic crash of #MH17: http:\/\/t.co\/epcGXUhN1V http:\/\/t.co\/wFIPqFcdq0",
  "id" : 489898559782027264,
  "created_at" : "2014-07-17 22:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA Climate.gov",
      "screen_name" : "NOAAClimate",
      "indices" : [ 3, 15 ],
      "id_str" : "552985513",
      "id" : 552985513
    }, {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 24, 29 ],
      "id_str" : "14342564",
      "id" : 14342564
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateofClimate",
      "indices" : [ 49, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HdTxvOWfVJ",
      "expanded_url" : "http:\/\/go.usa.gov\/5rcW",
      "display_url" : "go.usa.gov\/5rcW"
    } ]
  },
  "geo" : { },
  "id_str" : "489848001125679105",
  "text" : "RT @NOAAClimate: Today, @NOAA announced the 2013 #StateofClimate Report. View our highlights, maps &amp; more at http:\/\/t.co\/HdTxvOWfVJ http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOAA",
        "screen_name" : "NOAA",
        "indices" : [ 7, 12 ],
        "id_str" : "14342564",
        "id" : 14342564
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOAAClimate\/status\/489790688146382848\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/PqySpT3Kco",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BswWCPzCUAAWPPB.jpg",
        "id_str" : "489790687332683776",
        "id" : 489790687332683776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BswWCPzCUAAWPPB.jpg",
        "sizes" : [ {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 843
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 843
        } ],
        "display_url" : "pic.twitter.com\/PqySpT3Kco"
      } ],
      "hashtags" : [ {
        "text" : "StateofClimate",
        "indices" : [ 32, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/HdTxvOWfVJ",
        "expanded_url" : "http:\/\/go.usa.gov\/5rcW",
        "display_url" : "go.usa.gov\/5rcW"
      } ]
    },
    "geo" : { },
    "id_str" : "489790688146382848",
    "text" : "Today, @NOAA announced the 2013 #StateofClimate Report. View our highlights, maps &amp; more at http:\/\/t.co\/HdTxvOWfVJ http:\/\/t.co\/PqySpT3Kco",
    "id" : 489790688146382848,
    "created_at" : "2014-07-17 15:16:14 +0000",
    "user" : {
      "name" : "NOAA Climate.gov",
      "screen_name" : "NOAAClimate",
      "protected" : false,
      "id_str" : "552985513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447064525410283520\/cClYPOLi_normal.png",
      "id" : 552985513,
      "verified" : true
    }
  },
  "id" : 489848001125679105,
  "created_at" : "2014-07-17 19:03:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489839910795616256\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/m0vJyfzmok",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsxCzY4CMAIthpN.jpg",
      "id_str" : "489839910094778370",
      "id" : 489839910094778370,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsxCzY4CMAIthpN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/m0vJyfzmok"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 93, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hgchB2nUf4",
      "expanded_url" : "http:\/\/wh.gov\/rebuild-america",
      "display_url" : "wh.gov\/rebuild-america"
    } ]
  },
  "geo" : { },
  "id_str" : "489839910795616256",
  "text" : "\u201CLet\u2019s build some roads. Let\u2019s build some bridges.\u201D \u2014President Obama: http:\/\/t.co\/hgchB2nUf4 #RebuildAmerica http:\/\/t.co\/m0vJyfzmok",
  "id" : 489839910795616256,
  "created_at" : "2014-07-17 18:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489838216649146368\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Lr9vmH8THV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsxBQx6CIAEt2sL.jpg",
      "id_str" : "489838216007000065",
      "id" : 489838216007000065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsxBQx6CIAEt2sL.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Lr9vmH8THV"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489838216649146368",
  "text" : "\"We should be making sure hard work pays off by raising the minimum wage.\" \u2014President Obama #RaiseTheWage http:\/\/t.co\/Lr9vmH8THV",
  "id" : 489838216649146368,
  "created_at" : "2014-07-17 18:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489837970271535104",
  "text" : "RT @WHLive: \"We\u2019re creating a one-stop shop for cities and states looking to partner with the private sector to fund infrastructure project\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489837931356778496",
    "text" : "\"We\u2019re creating a one-stop shop for cities and states looking to partner with the private sector to fund infrastructure projects.\" \u2014Obama",
    "id" : 489837931356778496,
    "created_at" : "2014-07-17 18:23:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 489837970271535104,
  "created_at" : "2014-07-17 18:24:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489836497047015424",
  "text" : "\"We\u2019ve got to make sure our economy works for every American. That\u2019s why I ran for President. It\u2019s what I\u2019m focused on every day.\" \u2014Obama",
  "id" : 489836497047015424,
  "created_at" : "2014-07-17 18:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/489835781402660864\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/kgSFuLKyY3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsw_C86CEAAJ1Ep.jpg",
      "id_str" : "489835779418361856",
      "id" : 489835779418361856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsw_C86CEAAJ1Ep.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kgSFuLKyY3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489835953381711872",
  "text" : "RT @WHLive: \"Our businesses have now added nearly 10 million new jobs over the past 52 months.\" \u2014President Obama http:\/\/t.co\/kgSFuLKyY3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/489835781402660864\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/kgSFuLKyY3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsw_C86CEAAJ1Ep.jpg",
        "id_str" : "489835779418361856",
        "id" : 489835779418361856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsw_C86CEAAJ1Ep.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kgSFuLKyY3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489835781402660864",
    "text" : "\"Our businesses have now added nearly 10 million new jobs over the past 52 months.\" \u2014President Obama http:\/\/t.co\/kgSFuLKyY3",
    "id" : 489835781402660864,
    "created_at" : "2014-07-17 18:15:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 489835953381711872,
  "created_at" : "2014-07-17 18:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MH17",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489835363356389378",
  "text" : "\"Our thoughts and prayers are with all the families of the passengers, wherever they call home.\" \u2014President Obama #MH17",
  "id" : 489835363356389378,
  "created_at" : "2014-07-17 18:13:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489834976683515904",
  "text" : "\"The world is watching reports of a downed passenger jet near the Russia-Ukraine border.\" \u2014President Obama",
  "id" : 489834976683515904,
  "created_at" : "2014-07-17 18:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "489833664436768768",
  "text" : "At 2:10pm ET, President Obama announces a new initiative to increase private-sector investment in our infrastructure: http:\/\/t.co\/b4tqL3oo0v",
  "id" : 489833664436768768,
  "created_at" : "2014-07-17 18:07:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/BmxJSGX73Q",
      "expanded_url" : "http:\/\/go.wh.gov\/ca8pVF",
      "display_url" : "go.wh.gov\/ca8pVF"
    } ]
  },
  "geo" : { },
  "id_str" : "489808239639285760",
  "text" : "Today, we're launching a new initiative to encourage public-private collaboration on infrastructure projects \u2192 http:\/\/t.co\/BmxJSGX73Q",
  "id" : 489808239639285760,
  "created_at" : "2014-07-17 16:25:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489794893837897728\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/n9vL7Ehtup",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BswZ3DVCcAAoWVe.jpg",
      "id_str" : "489794893053587456",
      "id" : 489794893053587456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BswZ3DVCcAAoWVe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n9vL7Ehtup"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/BmxJSGX73Q",
      "expanded_url" : "http:\/\/go.wh.gov\/ca8pVF",
      "display_url" : "go.wh.gov\/ca8pVF"
    } ]
  },
  "geo" : { },
  "id_str" : "489794893837897728",
  "text" : "65% of our roads are rated in less than good condition. It's time to fix that: http:\/\/t.co\/BmxJSGX73Q #RebuildAmerica http:\/\/t.co\/n9vL7Ehtup",
  "id" : 489794893837897728,
  "created_at" : "2014-07-17 15:32:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/1mhWIk6SaL",
      "expanded_url" : "http:\/\/go.wh.gov\/ca8pVF",
      "display_url" : "go.wh.gov\/ca8pVF"
    } ]
  },
  "geo" : { },
  "id_str" : "489790245974851584",
  "text" : "Get the latest on how President Obama's acting to modernize our infrastructure and speed up project permitting \u2192 http:\/\/t.co\/1mhWIk6SaL",
  "id" : 489790245974851584,
  "created_at" : "2014-07-17 15:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "489525975592366081",
  "text" : "Happening now: President Obama delivers a statement on Ukraine and foreign policy. Watch \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 489525975592366081,
  "created_at" : "2014-07-16 21:44:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "489513260031303681",
  "text" : "At 5:15pm ET, President Obama delivers a statement on Ukraine and foreign policy. Watch \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 489513260031303681,
  "created_at" : "2014-07-16 20:53:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489510413386907648\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/BYdN7g4wmL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BssXIIBCYAIi3ir.jpg",
      "id_str" : "489510412858056706",
      "id" : 489510412858056706,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BssXIIBCYAIi3ir.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BYdN7g4wmL"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/2FRLswnfMq",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "489510413386907648",
  "text" : "For the sake of our kids and our planet, President Obama's taking steps to #ActOnClimate \u2192 http:\/\/t.co\/2FRLswnfMq http:\/\/t.co\/BYdN7g4wmL",
  "id" : 489510413386907648,
  "created_at" : "2014-07-16 20:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Debbie Stabenow",
      "screen_name" : "SenStabenow",
      "indices" : [ 3, 15 ],
      "id_str" : "76456274",
      "id" : 76456274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Dzl2NgA5ps",
      "expanded_url" : "http:\/\/1.usa.gov\/1nJZdzX",
      "display_url" : "1.usa.gov\/1nJZdzX"
    } ]
  },
  "geo" : { },
  "id_str" : "489493265247666176",
  "text" : "RT @SenStabenow: Republicans just filibustered a bill to guarantee affordable access to contraception. #HobbyLobby http:\/\/t.co\/Dzl2NgA5ps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Dzl2NgA5ps",
        "expanded_url" : "http:\/\/1.usa.gov\/1nJZdzX",
        "display_url" : "1.usa.gov\/1nJZdzX"
      } ]
    },
    "geo" : { },
    "id_str" : "489490418758078465",
    "text" : "Republicans just filibustered a bill to guarantee affordable access to contraception. #HobbyLobby http:\/\/t.co\/Dzl2NgA5ps",
    "id" : 489490418758078465,
    "created_at" : "2014-07-16 19:23:04 +0000",
    "user" : {
      "name" : "Sen. Debbie Stabenow",
      "screen_name" : "SenStabenow",
      "protected" : false,
      "id_str" : "76456274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735149032096604161\/co-FGACV_normal.jpg",
      "id" : 76456274,
      "verified" : true
    }
  },
  "id" : 489493265247666176,
  "created_at" : "2014-07-16 19:34:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489490101576429568",
  "text" : "RT @VP: \"Here is what I believe about this nation: We are one America. We only succeed when we act as one America.\" -VP http:\/\/t.co\/Eax7afV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/489485151064588289\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/Eax7afVAg5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BssAJYxCAAAVmw2.png",
        "id_str" : "489485145766756352",
        "id" : 489485145766756352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BssAJYxCAAAVmw2.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Eax7afVAg5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489485151064588289",
    "text" : "\"Here is what I believe about this nation: We are one America. We only succeed when we act as one America.\" -VP http:\/\/t.co\/Eax7afVAg5",
    "id" : 489485151064588289,
    "created_at" : "2014-07-16 19:02:08 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 489490101576429568,
  "created_at" : "2014-07-16 19:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489482451308535808\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Mf4YXMHPjv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsr9serCEAAPgxx.jpg",
      "id_str" : "489482450112745472",
      "id" : 489482450112745472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsr9serCEAAPgxx.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Mf4YXMHPjv"
    } ],
    "hashtags" : [ {
      "text" : "NotMyBossBusiness",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489482451308535808",
  "text" : "RT if you agree: Women deserve to make personal health care decisions for themselves. #NotMyBossBusiness http:\/\/t.co\/Mf4YXMHPjv",
  "id" : 489482451308535808,
  "created_at" : "2014-07-16 18:51:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "indices" : [ 3, 18 ],
      "id_str" : "1074518754",
      "id" : 1074518754
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotMyBossBusiness",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489477971443736576",
  "text" : "RT @SenatorBaldwin: RT if you think the Senate should vote to protect women's personal health decisions &amp; pass the #NotMyBossBusiness act t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NotMyBossBusiness",
        "indices" : [ 99, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489452454178603009",
    "text" : "RT if you think the Senate should vote to protect women's personal health decisions &amp; pass the #NotMyBossBusiness act today!",
    "id" : 489452454178603009,
    "created_at" : "2014-07-16 16:52:13 +0000",
    "user" : {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "protected" : false,
      "id_str" : "1074518754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656152457756692481\/jq9YvUuw_normal.jpg",
      "id" : 1074518754,
      "verified" : true
    }
  },
  "id" : 489477971443736576,
  "created_at" : "2014-07-16 18:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotMyBossBusiness",
      "indices" : [ 107, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489476446013128704",
  "text" : "RT @PattyMurray: Women shouldn't have to ask permission from their boss for basic, guaranteed health care. #NotMyBossBusiness http:\/\/t.co\/J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PattyMurray\/status\/489054922441523201\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/JenxRBVxM2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsl43D6CcAEAWrU.png",
        "id_str" : "489054921883283457",
        "id" : 489054921883283457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsl43D6CcAEAWrU.png",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2160,
          "resize" : "fit",
          "w" : 2880
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JenxRBVxM2"
      } ],
      "hashtags" : [ {
        "text" : "NotMyBossBusiness",
        "indices" : [ 90, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489054922441523201",
    "text" : "Women shouldn't have to ask permission from their boss for basic, guaranteed health care. #NotMyBossBusiness http:\/\/t.co\/JenxRBVxM2",
    "id" : 489054922441523201,
    "created_at" : "2014-07-15 14:32:34 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 489476446013128704,
  "created_at" : "2014-07-16 18:27:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "indices" : [ 3, 17 ],
      "id_str" : "72198806",
      "id" : 72198806
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotMyBossBusiness",
      "indices" : [ 39, 57 ]
    }, {
      "text" : "HobbyLobby",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489473493386682369",
  "text" : "RT @SenGillibrand: Senate will vote on #NotMyBossBusiness bill to reverse #HobbyLobby decision today. I strongly urge all my colleagues to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NotMyBossBusiness",
        "indices" : [ 20, 38 ]
      }, {
        "text" : "HobbyLobby",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489452481043529729",
    "text" : "Senate will vote on #NotMyBossBusiness bill to reverse #HobbyLobby decision today. I strongly urge all my colleagues to support this bill.",
    "id" : 489452481043529729,
    "created_at" : "2014-07-16 16:52:19 +0000",
    "user" : {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "protected" : false,
      "id_str" : "72198806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748266569323659264\/Kv9U6DgK_normal.jpg",
      "id" : 72198806,
      "verified" : true
    }
  },
  "id" : 489473493386682369,
  "created_at" : "2014-07-16 18:15:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 3, 13 ],
      "id_str" : "970207298",
      "id" : 970207298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/nvReRo44eB",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=RyK02em7Nic",
      "display_url" : "youtube.com\/watch?v=RyK02e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489468882747682816",
  "text" : "RT @SenWarren: I can't believe we're still debating if employers can deny women access to birth control Watch: https:\/\/t.co\/nvReRo44eB #Not\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NotMyBossBusiness",
        "indices" : [ 120, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/nvReRo44eB",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=RyK02em7Nic",
        "display_url" : "youtube.com\/watch?v=RyK02e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489444349747675136",
    "text" : "I can't believe we're still debating if employers can deny women access to birth control Watch: https:\/\/t.co\/nvReRo44eB #NotMyBossBusiness",
    "id" : 489444349747675136,
    "created_at" : "2014-07-16 16:20:01 +0000",
    "user" : {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "protected" : false,
      "id_str" : "970207298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722044174799777792\/bXaodRhx_normal.jpg",
      "id" : 970207298,
      "verified" : true
    }
  },
  "id" : 489468882747682816,
  "created_at" : "2014-07-16 17:57:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489461157032239104",
  "text" : "RT @VP: \"I believe in a nation that understands the single most precious right is unfettered access to the ballot box.\" - VP at #MakeProgre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeProgress",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489460436870238208",
    "text" : "\"I believe in a nation that understands the single most precious right is unfettered access to the ballot box.\" - VP at #MakeProgress event",
    "id" : 489460436870238208,
    "created_at" : "2014-07-16 17:23:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 489461157032239104,
  "created_at" : "2014-07-16 17:26:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 22, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1plBhsOAHT",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "489457427713372160",
  "text" : "RT @EPA: It\u2019s time to #ActOnClimate. That\u2019s why we\u2019re executing President Obama\u2019s Climate Action Plan. http:\/\/t.co\/1plBhsOAHT http:\/\/t.co\/F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EPA\/status\/489456401908260864\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FNpCb3EW0J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsrmANvCEAAVpQr.jpg",
        "id_str" : "489456400884436992",
        "id" : 489456400884436992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsrmANvCEAAVpQr.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FNpCb3EW0J"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 13, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/1plBhsOAHT",
        "expanded_url" : "http:\/\/wh.gov\/climate-change",
        "display_url" : "wh.gov\/climate-change"
      } ]
    },
    "geo" : { },
    "id_str" : "489456401908260864",
    "text" : "It\u2019s time to #ActOnClimate. That\u2019s why we\u2019re executing President Obama\u2019s Climate Action Plan. http:\/\/t.co\/1plBhsOAHT http:\/\/t.co\/FNpCb3EW0J",
    "id" : 489456401908260864,
    "created_at" : "2014-07-16 17:07:54 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 489457427713372160,
  "created_at" : "2014-07-16 17:11:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PattyMurray\/status\/489428201983475712\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/JrurQvt6BI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsrMWycCUAEQw7f.png",
      "id_str" : "489428201391673345",
      "id" : 489428201391673345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsrMWycCUAEQw7f.png",
      "sizes" : [ {
        "h" : 519,
        "resize" : "fit",
        "w" : 984
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 984
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JrurQvt6BI"
    } ],
    "hashtags" : [ {
      "text" : "NotMyBossBusiness",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489449380974313475",
  "text" : "RT @PattyMurray: .@WhiteHouse statement on Murray\/Udall #NotMyBossBusiness Act. Senate to vote TODAY. http:\/\/t.co\/JrurQvt6BI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PattyMurray\/status\/489428201983475712\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/JrurQvt6BI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsrMWycCUAEQw7f.png",
        "id_str" : "489428201391673345",
        "id" : 489428201391673345,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsrMWycCUAEQw7f.png",
        "sizes" : [ {
          "h" : 519,
          "resize" : "fit",
          "w" : 984
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 984
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JrurQvt6BI"
      } ],
      "hashtags" : [ {
        "text" : "NotMyBossBusiness",
        "indices" : [ 39, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489428201983475712",
    "text" : ".@WhiteHouse statement on Murray\/Udall #NotMyBossBusiness Act. Senate to vote TODAY. http:\/\/t.co\/JrurQvt6BI",
    "id" : 489428201983475712,
    "created_at" : "2014-07-16 15:15:51 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 489449380974313475,
  "created_at" : "2014-07-16 16:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489440398805573632\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3C1lpQIGbC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsrXcvfCQAA6yXJ.jpg",
      "id_str" : "489440398306066432",
      "id" : 489440398306066432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsrXcvfCQAA6yXJ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3C1lpQIGbC"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/J1f6osEhtq",
      "expanded_url" : "http:\/\/instagram.com\/p\/qhHliuwipa",
      "display_url" : "instagram.com\/p\/qhHliuwipa"
    } ]
  },
  "geo" : { },
  "id_str" : "489440398805573632",
  "text" : "President Obama.\nBehind the wheel.\nTesting out a driving simulator.\nWatch \u2192 http:\/\/t.co\/J1f6osEhtq\n#RebuildAmerica http:\/\/t.co\/3C1lpQIGbC",
  "id" : 489440398805573632,
  "created_at" : "2014-07-16 16:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EbMVAhq83D",
      "expanded_url" : "http:\/\/go.wh.gov\/hJDpEy",
      "display_url" : "go.wh.gov\/hJDpEy"
    } ]
  },
  "geo" : { },
  "id_str" : "489428427687329792",
  "text" : "Today, we're launching a new public-private partnership to develop advanced mapping data and tools to #ActOnClimate \u2192 http:\/\/t.co\/EbMVAhq83D",
  "id" : 489428427687329792,
  "created_at" : "2014-07-16 15:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489414461028306944\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/obym4IQh89",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsq_29CCcAAUCnT.jpg",
      "id_str" : "489414460340072448",
      "id" : 489414460340072448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsq_29CCcAAUCnT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/obym4IQh89"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2FRLswnfMq",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "489414461028306944",
  "text" : "Check out President Obama's Climate Action Plan\u2014and the progress we've made to #ActOnClimate: http:\/\/t.co\/2FRLswnfMq http:\/\/t.co\/obym4IQh89",
  "id" : 489414461028306944,
  "created_at" : "2014-07-16 14:21:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/EbMVAhq83D",
      "expanded_url" : "http:\/\/go.wh.gov\/hJDpEy",
      "display_url" : "go.wh.gov\/hJDpEy"
    } ]
  },
  "geo" : { },
  "id_str" : "489405681100136448",
  "text" : "Worth sharing: President Obama's acting to help states and communities prepare for climate impacts \u2192 http:\/\/t.co\/EbMVAhq83D #ActOnClimate",
  "id" : 489405681100136448,
  "created_at" : "2014-07-16 13:46:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "POLITICO",
      "screen_name" : "politico",
      "indices" : [ 104, 113 ],
      "id_str" : "9300262",
      "id" : 9300262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/uyDAhDhp2F",
      "expanded_url" : "http:\/\/www.politico.com\/story\/2014\/07\/jack-lew-tax-maneuver-108966.html#.U8ZlyBoXRK8.twitter",
      "display_url" : "politico.com\/story\/2014\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489399083116023809",
  "text" : "RT @pfeiffer44: Jack Lew calls for \u2018economic patriotism\u2019 to end tax maneuver http:\/\/t.co\/uyDAhDhp2F via @POLITICO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "POLITICO",
        "screen_name" : "politico",
        "indices" : [ 88, 97 ],
        "id_str" : "9300262",
        "id" : 9300262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/uyDAhDhp2F",
        "expanded_url" : "http:\/\/www.politico.com\/story\/2014\/07\/jack-lew-tax-maneuver-108966.html#.U8ZlyBoXRK8.twitter",
        "display_url" : "politico.com\/story\/2014\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489375273595310082",
    "text" : "Jack Lew calls for \u2018economic patriotism\u2019 to end tax maneuver http:\/\/t.co\/uyDAhDhp2F via @POLITICO",
    "id" : 489375273595310082,
    "created_at" : "2014-07-16 11:45:32 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 489399083116023809,
  "created_at" : "2014-07-16 13:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/489165291755433984\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/1Q5d8VSLpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsndPU-CAAAqZ4U.jpg",
      "id_str" : "489165289943072768",
      "id" : 489165289943072768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsndPU-CAAAqZ4U.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/1Q5d8VSLpA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489165291755433984",
  "text" : "\"As the father of a daughter who just turned 16, any new technology that makes driving safer is important.\" \u2014Obama http:\/\/t.co\/1Q5d8VSLpA",
  "id" : 489165291755433984,
  "created_at" : "2014-07-15 21:51:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2kU4MyBGsY",
      "expanded_url" : "http:\/\/youtu.be\/nKE93aSntNs",
      "display_url" : "youtu.be\/nKE93aSntNs"
    } ]
  },
  "geo" : { },
  "id_str" : "489143826234507264",
  "text" : "\u201CAll of us are deserving of an equal opportunity to thrive\u2014no matter who we are...or how we pray.\" \u2014President Obama: http:\/\/t.co\/2kU4MyBGsY",
  "id" : 489143826234507264,
  "created_at" : "2014-07-15 20:25:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/tAfcnlbhjT",
      "expanded_url" : "http:\/\/youtu.be\/NBpABxY1nqc",
      "display_url" : "youtu.be\/NBpABxY1nqc"
    } ]
  },
  "geo" : { },
  "id_str" : "489128454760456193",
  "text" : "\"Republicans, Democrats, independents\u2014everybody uses our roads.\" \u2014President Obama: http:\/\/t.co\/tAfcnlbhjT #RebuildAmerica",
  "id" : 489128454760456193,
  "created_at" : "2014-07-15 19:24:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "489112371500425216",
  "text" : "President Obama's plan to #RebuildAmerica would provide certainty for states and investors to fix our infrastructure: http:\/\/t.co\/VAevH7GBGF",
  "id" : 489112371500425216,
  "created_at" : "2014-07-15 18:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/489095902641291264\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/YGlwbJym6C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsmeIZaCAAAyAu9.jpg",
      "id_str" : "489095901642620928",
      "id" : 489095901642620928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsmeIZaCAAAyAu9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YGlwbJym6C"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 91, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/hgchB2nUf4",
      "expanded_url" : "http:\/\/wh.gov\/rebuild-america",
      "display_url" : "wh.gov\/rebuild-america"
    } ]
  },
  "geo" : { },
  "id_str" : "489095902641291264",
  "text" : "RT if you agree: It's time to fix our crumbling roads and bridges \u2192 http:\/\/t.co\/hgchB2nUf4 #RebuildAmerica http:\/\/t.co\/YGlwbJym6C",
  "id" : 489095902641291264,
  "created_at" : "2014-07-15 17:15:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489078077558104064",
  "text" : "\"The American people have to demand that folks in Washington do their job. Do something. That\u2019s my big motto for Congress.\" \u2014President Obama",
  "id" : 489078077558104064,
  "created_at" : "2014-07-15 16:04:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489076692892143616\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/KUdTPapwr9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsmMqQhCUAA5Qke.jpg",
      "id_str" : "489076692162334720",
      "id" : 489076692162334720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsmMqQhCUAA5Qke.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KUdTPapwr9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489076692892143616",
  "text" : "\u201CThis shouldn\u2019t be a partisan issue. Republicans, Democrats, Independents; everybody uses our roads.\u201D \u2014Obama http:\/\/t.co\/KUdTPapwr9",
  "id" : 489076692892143616,
  "created_at" : "2014-07-15 15:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489076322740625408",
  "text" : "\"We should be creating jobs rebuilding the roads and bridges that help every business in America.\" \u2014President Obama #RebuildAmerica",
  "id" : 489076322740625408,
  "created_at" : "2014-07-15 15:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/9Bj9gWv4t4",
      "expanded_url" : "http:\/\/wh.gov\/rebuild-america",
      "display_url" : "wh.gov\/rebuild-america"
    } ]
  },
  "geo" : { },
  "id_str" : "489075902694064129",
  "text" : "RT @WHLive: \"I put forward a plan to rebuild our transportation infrastructure in a more responsible way.\" \u2014Obama http:\/\/t.co\/9Bj9gWv4t4 #R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/9Bj9gWv4t4",
        "expanded_url" : "http:\/\/wh.gov\/rebuild-america",
        "display_url" : "wh.gov\/rebuild-america"
      } ]
    },
    "geo" : { },
    "id_str" : "489075744312926208",
    "text" : "\"I put forward a plan to rebuild our transportation infrastructure in a more responsible way.\" \u2014Obama http:\/\/t.co\/9Bj9gWv4t4 #RebuildAmerica",
    "id" : 489075744312926208,
    "created_at" : "2014-07-15 15:55:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 489075902694064129,
  "created_at" : "2014-07-15 15:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489075434580377600\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/8aAclDMbem",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsmLhAxCQAA583G.jpg",
      "id_str" : "489075433804021760",
      "id" : 489075433804021760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsmLhAxCQAA583G.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8aAclDMbem"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "489075434580377600",
  "text" : "\"First-class infrastructure attracts first-class jobs.\" \u2014President Obama: http:\/\/t.co\/b4tqL3oo0v #RebuildAmerica http:\/\/t.co\/8aAclDMbem",
  "id" : 489075434580377600,
  "created_at" : "2014-07-15 15:54:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489074880579911680",
  "text" : "RT @WHLive: \"Americans spend 5.5 billion hours stuck in traffic each year, which costs us $120 billion in wasted time and gas.\" \u2014Obama #Reb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "489074794340831232",
    "text" : "\"Americans spend 5.5 billion hours stuck in traffic each year, which costs us $120 billion in wasted time and gas.\" \u2014Obama #RebuildAmerica",
    "id" : 489074794340831232,
    "created_at" : "2014-07-15 15:51:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 489074880579911680,
  "created_at" : "2014-07-15 15:51:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489074702217134080",
  "text" : "\"As the father of a daughter who just turned 16, any new technology that makes driving safer is important to me.\" \u2014Obama #MadeInAmerica",
  "id" : 489074702217134080,
  "created_at" : "2014-07-15 15:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/xz3W6KL2L3",
      "expanded_url" : "http:\/\/go.wh.gov\/UNQd74",
      "display_url" : "go.wh.gov\/UNQd74"
    } ]
  },
  "geo" : { },
  "id_str" : "489074346397552641",
  "text" : "Happening now: President Obama speaks on why Congress needs to fund fixing our roads and bridges \u2192 http:\/\/t.co\/xz3W6KL2L3 #RebuildAmerica",
  "id" : 489074346397552641,
  "created_at" : "2014-07-15 15:49:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/xz3W6KL2L3",
      "expanded_url" : "http:\/\/go.wh.gov\/UNQd74",
      "display_url" : "go.wh.gov\/UNQd74"
    } ]
  },
  "geo" : { },
  "id_str" : "489067330320998401",
  "text" : "Watch President Obama speak on why Congress needs to fund fixing our roads and bridges at 11:35am ET: http:\/\/t.co\/xz3W6KL2L3 #RebuildAmerica",
  "id" : 489067330320998401,
  "created_at" : "2014-07-15 15:21:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "489060592448466944",
  "text" : "President Obama's plan would increase investments to fix our roads and bridges by 38% over 4 years \u2192 http:\/\/t.co\/VAevH7GBGF #RebuildAmerica",
  "id" : 489060592448466944,
  "created_at" : "2014-07-15 14:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 3, 14 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489050720977432576",
  "text" : "RT @PeaceCorps: WATCH: A message from the President inviting you to consider making a difference as a Peace Corps Volunteer http:\/\/t.co\/sHR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ApplyPC",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/sHR33RzRrK",
        "expanded_url" : "http:\/\/bit.ly\/1wnjKLa",
        "display_url" : "bit.ly\/1wnjKLa"
      } ]
    },
    "geo" : { },
    "id_str" : "489033070373122049",
    "text" : "WATCH: A message from the President inviting you to consider making a difference as a Peace Corps Volunteer http:\/\/t.co\/sHR33RzRrK #ApplyPC",
    "id" : 489033070373122049,
    "created_at" : "2014-07-15 13:05:44 +0000",
    "user" : {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "protected" : false,
      "id_str" : "9109712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737985331815841793\/YS-240sx_normal.jpg",
      "id" : 9109712,
      "verified" : true
    }
  },
  "id" : 489050720977432576,
  "created_at" : "2014-07-15 14:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/489044103142064128\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZHjzLlcg5B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BslvBSkCYAAyaDU.jpg",
      "id_str" : "489044102499950592",
      "id" : 489044102499950592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BslvBSkCYAAyaDU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZHjzLlcg5B"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "489044103142064128",
  "text" : "FACT: 25% of our bridges need major repairs or can't handle today's traffic \u2192 http:\/\/t.co\/VAevH7GBGF #RebuildAmerica http:\/\/t.co\/ZHjzLlcg5B",
  "id" : 489044103142064128,
  "created_at" : "2014-07-15 13:49:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 62, 73 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/488857160026038272\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KCFAtbN05b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsjE_ywCcAAyki2.jpg",
      "id_str" : "488857159803760640",
      "id" : 488857159803760640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsjE_ywCcAAyki2.jpg",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KCFAtbN05b"
    } ],
    "hashtags" : [ {
      "text" : "Ramadan",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "OpportunityforAll",
      "indices" : [ 74, 92 ]
    }, {
      "text" : "Iftar",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489039107835064320",
  "text" : "RT @vj44: Celebrating the holy season of #Ramadan here at the @WhiteHouse #OpportunityforAll #Iftar http:\/\/t.co\/KCFAtbN05b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 52, 63 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/488857160026038272\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/KCFAtbN05b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsjE_ywCcAAyki2.jpg",
        "id_str" : "488857159803760640",
        "id" : 488857159803760640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsjE_ywCcAAyki2.jpg",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KCFAtbN05b"
      } ],
      "hashtags" : [ {
        "text" : "Ramadan",
        "indices" : [ 31, 39 ]
      }, {
        "text" : "OpportunityforAll",
        "indices" : [ 64, 82 ]
      }, {
        "text" : "Iftar",
        "indices" : [ 83, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488857160026038272",
    "text" : "Celebrating the holy season of #Ramadan here at the @WhiteHouse #OpportunityforAll #Iftar http:\/\/t.co\/KCFAtbN05b",
    "id" : 488857160026038272,
    "created_at" : "2014-07-15 01:26:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 489039107835064320,
  "created_at" : "2014-07-15 13:29:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RamadanKareem",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "488846701797445632",
  "text" : "Tune in at 8:55pm ET: President Obama hosts an Iftar Dinner at the White House to celebrate Ramadan \u2192 http:\/\/t.co\/7QUc084BX3 #RamadanKareem",
  "id" : 488846701797445632,
  "created_at" : "2014-07-15 00:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WwQjWsc8sL",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "488826043000946688",
  "text" : "RT @LaborSec: Congress needs to reauthorize funding to rebuild our infrastructure. 700K jobs are at stake: http:\/\/t.co\/WwQjWsc8sL http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/488817825927004162\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6bJvb9UdmF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsihOI3CQAE59oD.jpg",
        "id_str" : "488817823838257153",
        "id" : 488817823838257153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsihOI3CQAE59oD.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6bJvb9UdmF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/WwQjWsc8sL",
        "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
        "display_url" : "go.wh.gov\/4czkeK"
      } ]
    },
    "geo" : { },
    "id_str" : "488817825927004162",
    "text" : "Congress needs to reauthorize funding to rebuild our infrastructure. 700K jobs are at stake: http:\/\/t.co\/WwQjWsc8sL http:\/\/t.co\/6bJvb9UdmF",
    "id" : 488817825927004162,
    "created_at" : "2014-07-14 22:50:26 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 488826043000946688,
  "created_at" : "2014-07-14 23:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/488817535828361216\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/n4EtzkIQMY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsig9VBCUAE2gFs.jpg",
      "id_str" : "488817535043653633",
      "id" : 488817535043653633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsig9VBCUAE2gFs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n4EtzkIQMY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "488817535828361216",
  "text" : "FACT: 45% of Americans lack access to transit. It's time to modernize our infrastructure \u2192 http:\/\/t.co\/VAevH7GBGF http:\/\/t.co\/n4EtzkIQMY",
  "id" : 488817535828361216,
  "created_at" : "2014-07-14 22:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "P. Krugman",
      "screen_name" : "nytimeskrugman",
      "indices" : [ 73, 88 ],
      "id_str" : "4886807543",
      "id" : 4886807543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAworks",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488792592121741313",
  "text" : "RT @NancyPelosi: \"The truth is that health reform is \u2014 gasp! \u2014 working.\"\u2014@NYTimeskrugman on the clear fact that #ACAworks: http:\/\/t.co\/c0Je\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "P. Krugman",
        "screen_name" : "nytimeskrugman",
        "indices" : [ 56, 71 ],
        "id_str" : "4886807543",
        "id" : 4886807543
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAworks",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/c0Jerj8I6Q",
        "expanded_url" : "http:\/\/goo.gl\/M3VBhC",
        "display_url" : "goo.gl\/M3VBhC"
      } ]
    },
    "geo" : { },
    "id_str" : "488777866566721536",
    "text" : "\"The truth is that health reform is \u2014 gasp! \u2014 working.\"\u2014@NYTimeskrugman on the clear fact that #ACAworks: http:\/\/t.co\/c0Jerj8I6Q",
    "id" : 488777866566721536,
    "created_at" : "2014-07-14 20:11:39 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 488792592121741313,
  "created_at" : "2014-07-14 21:10:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StrongerThan",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488786502651232256",
  "text" : "RT @AmbassadorPower: Thank you Malala for showing the world that we can be #StrongerThan those who fear education, fear truth, and fear cha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StrongerThan",
        "indices" : [ 54, 67 ]
      }, {
        "text" : "MalalaDay",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488780770874363904",
    "text" : "Thank you Malala for showing the world that we can be #StrongerThan those who fear education, fear truth, and fear change. #MalalaDay",
    "id" : 488780770874363904,
    "created_at" : "2014-07-14 20:23:11 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 488786502651232256,
  "created_at" : "2014-07-14 20:45:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hAd5SiEeiA",
      "expanded_url" : "http:\/\/go.wh.gov\/wg9yc4",
      "display_url" : "go.wh.gov\/wg9yc4"
    } ]
  },
  "geo" : { },
  "id_str" : "488779975789912066",
  "text" : "It's time to fix our crumbling roads and bridges. Share what needs to be repaired in your area using #RebuildAmerica: http:\/\/t.co\/hAd5SiEeiA",
  "id" : 488779975789912066,
  "created_at" : "2014-07-14 20:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/488773579392421888\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/lCb3kCv4qM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bsh4-uZCYAAwlGP.jpg",
      "id_str" : "488773578569965568",
      "id" : 488773578569965568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bsh4-uZCYAAwlGP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lCb3kCv4qM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488773579392421888",
  "text" : "If Congressional Republicans don't act, more than 112,000 projects fixing our roads and bridges would be at risk. http:\/\/t.co\/lCb3kCv4qM",
  "id" : 488773579392421888,
  "created_at" : "2014-07-14 19:54:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StrongerThan",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488761405957750784",
  "text" : "RT @FLOTUS: Thank you Malala for inspiring girls around the world to be #StrongerThan adversity and pursue their education. \u2013mo http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/488753429347844098\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/526lzDlGKw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bshmp1RCEAA6slb.jpg",
        "id_str" : "488753428428886016",
        "id" : 488753428428886016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bshmp1RCEAA6slb.jpg",
        "sizes" : [ {
          "h" : 1378,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/526lzDlGKw"
      } ],
      "hashtags" : [ {
        "text" : "StrongerThan",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488753429347844098",
    "text" : "Thank you Malala for inspiring girls around the world to be #StrongerThan adversity and pursue their education. \u2013mo http:\/\/t.co\/526lzDlGKw",
    "id" : 488753429347844098,
    "created_at" : "2014-07-14 18:34:32 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 488761405957750784,
  "created_at" : "2014-07-14 19:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/MBkY0Mqlr0",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "488751905691422720",
  "text" : "RT @VP: 25% of our nation's bridges require significant repair.\n\nLet's fix them. \n\nStarting now \u2192 http:\/\/t.co\/MBkY0Mqlr0 http:\/\/t.co\/PaCnjx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/488746969465384961\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PaCnjxlocC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BshgxrsIgAAzdKR.png",
        "id_str" : "488746966227386368",
        "id" : 488746966227386368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BshgxrsIgAAzdKR.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PaCnjxlocC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/MBkY0Mqlr0",
        "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
        "display_url" : "go.wh.gov\/4czkeK"
      } ]
    },
    "geo" : { },
    "id_str" : "488746969465384961",
    "text" : "25% of our nation's bridges require significant repair.\n\nLet's fix them. \n\nStarting now \u2192 http:\/\/t.co\/MBkY0Mqlr0 http:\/\/t.co\/PaCnjxlocC",
    "id" : 488746969465384961,
    "created_at" : "2014-07-14 18:08:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 488751905691422720,
  "created_at" : "2014-07-14 18:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/488746568695422976\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/ahV6RkMJcf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BshgadcCAAER82w.jpg",
      "id_str" : "488746567264763905",
      "id" : 488746567264763905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BshgadcCAAER82w.jpg",
      "sizes" : [ {
        "h" : 1378,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ahV6RkMJcf"
    } ],
    "hashtags" : [ {
      "text" : "MalalaDay",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488746568695422976",
  "text" : "Let's recommit ourselves to helping girls around the world pursue their education &amp; achieve their dreams. #MalalaDay http:\/\/t.co\/ahV6RkMJcf",
  "id" : 488746568695422976,
  "created_at" : "2014-07-14 18:07:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "488738334693658624",
  "text" : "FACT: 65% of our major roads are rated in less than good condition. It's time to #RebuildAmerica: http:\/\/t.co\/VAevH7GBGF",
  "id" : 488738334693658624,
  "created_at" : "2014-07-14 17:34:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/488727249508921346\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wgdJwUPx7z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BshO1-VCcAEo9rp.jpg",
      "id_str" : "488727248740970497",
      "id" : 488727248740970497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BshO1-VCcAEo9rp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wgdJwUPx7z"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488727249508921346",
  "text" : "If the GOP in Congress fails to fund fixing our infrastructure, nearly 700,000 jobs would be at risk. #RebuildAmerica http:\/\/t.co\/wgdJwUPx7z",
  "id" : 488727249508921346,
  "created_at" : "2014-07-14 16:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/488719350388776960\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/BYaPeRZiTB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BshHqMGCEAAE6vy.jpg",
      "id_str" : "488719349696303104",
      "id" : 488719349696303104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BshHqMGCEAAE6vy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BYaPeRZiTB"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "488719350388776960",
  "text" : "It's time for Congress to reauthorize funding to rebuild our roads &amp; bridges: http:\/\/t.co\/VAevH7GBGF #RebuildAmerica http:\/\/t.co\/BYaPeRZiTB",
  "id" : 488719350388776960,
  "created_at" : "2014-07-14 16:19:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VAevH7GBGF",
      "expanded_url" : "http:\/\/go.wh.gov\/4czkeK",
      "display_url" : "go.wh.gov\/4czkeK"
    } ]
  },
  "geo" : { },
  "id_str" : "488715751801761792",
  "text" : "New map: Check out the state of roads and bridges in your state\u2014and why it's time to #RebuildAmerica \u2192 http:\/\/t.co\/VAevH7GBGF",
  "id" : 488715751801761792,
  "created_at" : "2014-07-14 16:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/pYAVFHIkqP",
      "expanded_url" : "http:\/\/go.wh.gov\/fjjQeP",
      "display_url" : "go.wh.gov\/fjjQeP"
    } ]
  },
  "geo" : { },
  "id_str" : "488703472339288065",
  "text" : "President Obama met with folks in Colorado and Texas last week who wrote him letters telling their stories. Watch \u2192 http:\/\/t.co\/pYAVFHIkqP",
  "id" : 488703472339288065,
  "created_at" : "2014-07-14 15:16:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kLWsCgb5Cs",
      "expanded_url" : "http:\/\/go.wh.gov\/HagVFG",
      "display_url" : "go.wh.gov\/HagVFG"
    } ]
  },
  "geo" : { },
  "id_str" : "488367286642688000",
  "text" : "\"Lifting the minimum wage, fair pay, student loan reform\u2014they\u2019ve said no to all of it\" \u2014Obama on the GOP in Congress: http:\/\/t.co\/kLWsCgb5Cs",
  "id" : 488367286642688000,
  "created_at" : "2014-07-13 17:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kLWsCgb5Cs",
      "expanded_url" : "http:\/\/go.wh.gov\/HagVFG",
      "display_url" : "go.wh.gov\/HagVFG"
    } ]
  },
  "geo" : { },
  "id_str" : "488344663552565248",
  "text" : "\"So far this year, Republicans in Congress have blocked every serious idea to strengthen the middle class.\" \u2014Obama: http:\/\/t.co\/kLWsCgb5Cs",
  "id" : 488344663552565248,
  "created_at" : "2014-07-13 15:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kLWsCgb5Cs",
      "expanded_url" : "http:\/\/go.wh.gov\/HagVFG",
      "display_url" : "go.wh.gov\/HagVFG"
    } ]
  },
  "geo" : { },
  "id_str" : "488322009953087492",
  "text" : "\"I\u2019m here because of hardworking Americans like Elizabeth and Carolyn. That\u2019s something I\u2019ll never forget.\" \u2014Obama: http:\/\/t.co\/kLWsCgb5Cs",
  "id" : 488322009953087492,
  "created_at" : "2014-07-13 14:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484693486076432385\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/yqb4kdD2fF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Brn6KDRCQAI8FBf.jpg",
      "id_str" : "484693485501431810",
      "id" : 484693485501431810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brn6KDRCQAI8FBf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yqb4kdD2fF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/kLWsCgb5Cs",
      "expanded_url" : "http:\/\/go.wh.gov\/HagVFG",
      "display_url" : "go.wh.gov\/HagVFG"
    } ]
  },
  "geo" : { },
  "id_str" : "488001116676685827",
  "text" : "\"Our businesses have now created nearly 10 million new jobs over the past 52 months.\" \u2014Obama: http:\/\/t.co\/kLWsCgb5Cs http:\/\/t.co\/yqb4kdD2fF",
  "id" : 488001116676685827,
  "created_at" : "2014-07-12 16:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/kLWsCgb5Cs",
      "expanded_url" : "http:\/\/go.wh.gov\/HagVFG",
      "display_url" : "go.wh.gov\/HagVFG"
    } ]
  },
  "geo" : { },
  "id_str" : "487982259106893825",
  "text" : "\"I ran for President to fight for Americans like Elizabeth\u2014people who work hard, do everything right.\" \u2014Obama: http:\/\/t.co\/kLWsCgb5Cs",
  "id" : 487982259106893825,
  "created_at" : "2014-07-12 15:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/kLWsCgb5Cs",
      "expanded_url" : "http:\/\/go.wh.gov\/HagVFG",
      "display_url" : "go.wh.gov\/HagVFG"
    } ]
  },
  "geo" : { },
  "id_str" : "487967173055229952",
  "text" : "\"America does better when the middle class does better.\" \u2014President Obama in his weekly address: http:\/\/t.co\/kLWsCgb5Cs #OpportunityForAll",
  "id" : 487967173055229952,
  "created_at" : "2014-07-12 14:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487733620443209728\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/y8oKcxxgoF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsTHJJaCMAA7O3F.jpg",
      "id_str" : "487733619620720640",
      "id" : 487733619620720640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsTHJJaCMAA7O3F.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/y8oKcxxgoF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487733620443209728",
  "text" : "Sharing the podium. http:\/\/t.co\/y8oKcxxgoF",
  "id" : 487733620443209728,
  "created_at" : "2014-07-11 23:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/pqAwHqS0W7",
      "expanded_url" : "http:\/\/youtu.be\/sShr5x-DA6U",
      "display_url" : "youtu.be\/sShr5x-DA6U"
    } ]
  },
  "geo" : { },
  "id_str" : "487687816701554688",
  "text" : "\u201COur economy does not grow from the top down, it grows from the middle up.\" \u2014Obama in Austin: http:\/\/t.co\/pqAwHqS0W7 #OpportunityForAll",
  "id" : 487687816701554688,
  "created_at" : "2014-07-11 20:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487678015145795584",
  "text" : "RT @VP: \"By the end of the month, I will deliver a report to the President with an extensive job training strategy to meet all of these nee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487676509151174659",
    "text" : "\"By the end of the month, I will deliver a report to the President with an extensive job training strategy to meet all of these needs.\" -VP",
    "id" : 487676509151174659,
    "created_at" : "2014-07-11 19:15:15 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 487678015145795584,
  "created_at" : "2014-07-11 19:21:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/pqAwHqS0W7",
      "expanded_url" : "http:\/\/youtu.be\/sShr5x-DA6U",
      "display_url" : "youtu.be\/sShr5x-DA6U"
    } ]
  },
  "geo" : { },
  "id_str" : "487666732715474945",
  "text" : "\u201CIf you\u2019re mad at me for helping people on my own, let\u2019s team up.\u201D \u2014Obama to the House GOP: http:\/\/t.co\/pqAwHqS0W7 #OpportunityForAll",
  "id" : 487666732715474945,
  "created_at" : "2014-07-11 18:36:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487658058727059456",
  "text" : "FACT: President Obama's QuickPay initiative has generated more than $1 billion for small businesses\u2014freeing up capital to invest and hire.",
  "id" : 487658058727059456,
  "created_at" : "2014-07-11 18:01:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487647886227030016\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/YKu3F9sU3p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsR5KvjCQAALZzz.jpg",
      "id_str" : "487647885131923456",
      "id" : 487647885131923456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsR5KvjCQAALZzz.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/YKu3F9sU3p"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/MPOO9BBMdO",
      "expanded_url" : "http:\/\/go.wh.gov\/reoi3P",
      "display_url" : "go.wh.gov\/reoi3P"
    } ]
  },
  "geo" : { },
  "id_str" : "487647886227030016",
  "text" : "\"This country succeeds when everybody has got a shot.\u201D \u2014Obama in Austin: http:\/\/t.co\/MPOO9BBMdO #OpportunityForAll http:\/\/t.co\/YKu3F9sU3p",
  "id" : 487647886227030016,
  "created_at" : "2014-07-11 17:21:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/v5D2zIEVAe",
      "expanded_url" : "http:\/\/go.wh.gov\/j9h5VS",
      "display_url" : "go.wh.gov\/j9h5VS"
    } ]
  },
  "geo" : { },
  "id_str" : "487633277709451268",
  "text" : "President Obama just announced a new partnership to strengthen small businesses by increasing their working capital \u2192 http:\/\/t.co\/v5D2zIEVAe",
  "id" : 487633277709451268,
  "created_at" : "2014-07-11 16:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 1, 12 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487614404260036608\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/L4zNXPyy2a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsRat2kCEAAPjlk.png",
      "id_str" : "487614403450114048",
      "id" : 487614403450114048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsRat2kCEAAPjlk.png",
      "sizes" : [ {
        "h" : 707,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/L4zNXPyy2a"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/1DeSSjTQsE",
      "expanded_url" : "http:\/\/go.wh.gov\/mSij2P",
      "display_url" : "go.wh.gov\/mSij2P"
    } ]
  },
  "geo" : { },
  "id_str" : "487614404260036608",
  "text" : ".@WhiteHouse just passed 5 million followers! Check out some of our favorite tweets \u2192 http:\/\/t.co\/1DeSSjTQsE http:\/\/t.co\/L4zNXPyy2a",
  "id" : 487614404260036608,
  "created_at" : "2014-07-11 15:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBiz",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/VnWvq27coY",
      "expanded_url" : "http:\/\/bit.ly\/VOM0vp",
      "display_url" : "bit.ly\/VOM0vp"
    } ]
  },
  "geo" : { },
  "id_str" : "487604852550533120",
  "text" : "RT @LaborSec: Don't think #SmallBiz supports a minimum wage increase? Think again: http:\/\/t.co\/VnWvq27coY #RaiseTheWage http:\/\/t.co\/cZrUYH0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/487602762763345920\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/cZrUYH0g5n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsRQIOdCIAIXrkh.jpg",
        "id_str" : "487602761911902210",
        "id" : 487602761911902210,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsRQIOdCIAIXrkh.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/cZrUYH0g5n"
      } ],
      "hashtags" : [ {
        "text" : "SmallBiz",
        "indices" : [ 12, 21 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/VnWvq27coY",
        "expanded_url" : "http:\/\/bit.ly\/VOM0vp",
        "display_url" : "bit.ly\/VOM0vp"
      } ]
    },
    "geo" : { },
    "id_str" : "487602762763345920",
    "text" : "Don't think #SmallBiz supports a minimum wage increase? Think again: http:\/\/t.co\/VnWvq27coY #RaiseTheWage http:\/\/t.co\/cZrUYH0g5n",
    "id" : 487602762763345920,
    "created_at" : "2014-07-11 14:22:12 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 487604852550533120,
  "created_at" : "2014-07-11 14:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487388535356682240",
  "text" : "RT @PressSec: As POTUS said today, he's the guy doing his job - lawsuit or not. GOPers in Congress must be the other guy. http:\/\/t.co\/ly3Rp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/487388183672676352\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/ly3Rpgxc7D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsOM-B3CIAAkK3_.png",
        "id_str" : "487388181965185024",
        "id" : 487388181965185024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsOM-B3CIAAkK3_.png",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 962
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 962
        } ],
        "display_url" : "pic.twitter.com\/ly3Rpgxc7D"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487388183672676352",
    "text" : "As POTUS said today, he's the guy doing his job - lawsuit or not. GOPers in Congress must be the other guy. http:\/\/t.co\/ly3Rpgxc7D",
    "id" : 487388183672676352,
    "created_at" : "2014-07-11 00:09:32 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 487388535356682240,
  "created_at" : "2014-07-11 00:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487385014938906625\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/SxdFjIJ9JO",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BsOKFj-CIAErdY1.png",
      "id_str" : "487385012845551617",
      "id" : 487385012845551617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BsOKFj-CIAErdY1.png",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SxdFjIJ9JO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487385014938906625",
  "text" : "President Obama's doing his job to fight for middle-class families. It's time for the GOP in Congress to do theirs. http:\/\/t.co\/SxdFjIJ9JO",
  "id" : 487385014938906625,
  "created_at" : "2014-07-10 23:56:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/eIi0DwuVaO",
      "expanded_url" : "http:\/\/nyti.ms\/1kJxMl2",
      "display_url" : "nyti.ms\/1kJxMl2"
    } ]
  },
  "geo" : { },
  "id_str" : "487367303533953024",
  "text" : "RT @pfeiffer44: Come on now House GOP, you have even lost Sheldon Adelson on immigration http:\/\/t.co\/eIi0DwuVaO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/eIi0DwuVaO",
        "expanded_url" : "http:\/\/nyti.ms\/1kJxMl2",
        "display_url" : "nyti.ms\/1kJxMl2"
      } ]
    },
    "geo" : { },
    "id_str" : "487366706692505600",
    "text" : "Come on now House GOP, you have even lost Sheldon Adelson on immigration http:\/\/t.co\/eIi0DwuVaO",
    "id" : 487366706692505600,
    "created_at" : "2014-07-10 22:44:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 487367303533953024,
  "created_at" : "2014-07-10 22:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whole Foods Market",
      "screen_name" : "WholeFoods",
      "indices" : [ 33, 44 ],
      "id_str" : "15131310",
      "id" : 15131310
    }, {
      "name" : "Giant Eagle, Inc.",
      "screen_name" : "GiantEagle",
      "indices" : [ 45, 56 ],
      "id_str" : "19159589",
      "id" : 19159589
    }, {
      "name" : "Kroger",
      "screen_name" : "kroger",
      "indices" : [ 57, 64 ],
      "id_str" : "36359791",
      "id" : 36359791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESNBC",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/1OqIDkqW0Q",
      "expanded_url" : "https:\/\/www.energystar.gov\/buildings\/about-us\/how-can-we-help-you\/communicate\/energy-star-communications-toolkit\/motivate-competition-0",
      "display_url" : "energystar.gov\/buildings\/abou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487347129841885184",
  "text" : "RT @Podesta44: Supermarkets like @WholeFoods @GiantEagle @kroger enter the Battle of the Buildings #ESNBC https:\/\/t.co\/1OqIDkqW0Q http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Whole Foods Market",
        "screen_name" : "WholeFoods",
        "indices" : [ 18, 29 ],
        "id_str" : "15131310",
        "id" : 15131310
      }, {
        "name" : "Giant Eagle, Inc.",
        "screen_name" : "GiantEagle",
        "indices" : [ 30, 41 ],
        "id_str" : "19159589",
        "id" : 19159589
      }, {
        "name" : "Kroger",
        "screen_name" : "kroger",
        "indices" : [ 42, 49 ],
        "id_str" : "36359791",
        "id" : 36359791
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/487336747437547520\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/MkoGwAyNlC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsNY6nICAAAnn4z.png",
        "id_str" : "487330948644470784",
        "id" : 487330948644470784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsNY6nICAAAnn4z.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 556,
          "resize" : "fit",
          "w" : 692
        }, {
          "h" : 556,
          "resize" : "fit",
          "w" : 692
        } ],
        "display_url" : "pic.twitter.com\/MkoGwAyNlC"
      } ],
      "hashtags" : [ {
        "text" : "ESNBC",
        "indices" : [ 84, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/1OqIDkqW0Q",
        "expanded_url" : "https:\/\/www.energystar.gov\/buildings\/about-us\/how-can-we-help-you\/communicate\/energy-star-communications-toolkit\/motivate-competition-0",
        "display_url" : "energystar.gov\/buildings\/abou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487336747437547520",
    "text" : "Supermarkets like @WholeFoods @GiantEagle @kroger enter the Battle of the Buildings #ESNBC https:\/\/t.co\/1OqIDkqW0Q http:\/\/t.co\/MkoGwAyNlC",
    "id" : 487336747437547520,
    "created_at" : "2014-07-10 20:45:09 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 487347129841885184,
  "created_at" : "2014-07-10 21:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487337377749565440",
  "text" : "RT @VP: Shaun Donovan is a tireless public servant who practices fiscal responsibility. We\u2019re lucky to have him as the new OMB director. \u2013VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487318197696495616",
    "text" : "Shaun Donovan is a tireless public servant who practices fiscal responsibility. We\u2019re lucky to have him as the new OMB director. \u2013VP",
    "id" : 487318197696495616,
    "created_at" : "2014-07-10 19:31:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 487337377749565440,
  "created_at" : "2014-07-10 20:47:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ortega",
      "screen_name" : "MattOrtega",
      "indices" : [ 100, 111 ],
      "id_str" : "6751172",
      "id" : 6751172
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MattOrtega\/status\/487307303839100929\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/2KVeDcdgaH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsNDaQcCUAA7X1z.jpg",
      "id_str" : "487307303054364672",
      "id" : 487307303054364672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsNDaQcCUAA7X1z.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2KVeDcdgaH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487316977011019777",
  "text" : "\"I'm the guy doing his job. You must be the other guy.\" \u2014 President Obama channels The Departed. RT @MattOrtega\nhttp:\/\/t.co\/2KVeDcdgaH",
  "id" : 487316977011019777,
  "created_at" : "2014-07-10 19:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487302458142912512",
  "text" : "\"I will always keep fighting to restore the American Dream for everyone who\u2019s willing to work for it.\" \u2014President Obama #OpportunityForAll",
  "id" : 487302458142912512,
  "created_at" : "2014-07-10 18:28:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487302099085295616",
  "text" : "\"Cynicism is a choice. Hope is a better choice.\" \u2014President Obama in Austin, Texas",
  "id" : 487302099085295616,
  "created_at" : "2014-07-10 18:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487299922388336640",
  "text" : "RT @PressSec: POTUS in Austin: owner of Silvermine Subs met POTUS in Denver yesterday - today she announced she's raising her workers pay t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487299865328627712",
    "text" : "POTUS in Austin: owner of Silvermine Subs met POTUS in Denver yesterday - today she announced she's raising her workers pay to $10.10 an hr.",
    "id" : 487299865328627712,
    "created_at" : "2014-07-10 18:18:36 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 487299922388336640,
  "created_at" : "2014-07-10 18:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487299741668352002",
  "text" : "\"There is no more denying a simple truth: America deserves a raise.\" \u2014President Obama in Austin, Texas. #RaiseTheWage",
  "id" : 487299741668352002,
  "created_at" : "2014-07-10 18:18:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487298336220000256",
  "text" : "\"Our economy doesn\u2019t grow from the top-down...It grows from a rising, thriving middle class. That\u2019s what I\u2019m fighting for.\" \u2014President Obama",
  "id" : 487298336220000256,
  "created_at" : "2014-07-10 18:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487297066151182336",
  "text" : "\"So far this year, Republicans in Congress have blocked or voted down every serious idea to strengthen the middle class.\" \u2014President Obama",
  "id" : 487297066151182336,
  "created_at" : "2014-07-10 18:07:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487296529393545216",
  "text" : "RT @PressSec: POTUS in Austin: America works better when there are more ladders into the middle class.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487295919608455168",
    "text" : "POTUS in Austin: America works better when there are more ladders into the middle class.",
    "id" : 487295919608455168,
    "created_at" : "2014-07-10 18:02:55 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 487296529393545216,
  "created_at" : "2014-07-10 18:05:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487295335212285953",
  "text" : "\"By almost every measure, we\u2019re better off now than when I took office. But the fact is, we still have a long way to go.\" \u2014President Obama",
  "id" : 487295335212285953,
  "created_at" : "2014-07-10 18:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487295068597133312",
  "text" : "Obama: \"The Affordable Care Act has given millions more families peace of mind that they won\u2019t go broke just because they get sick.\"",
  "id" : 487295068597133312,
  "created_at" : "2014-07-10 17:59:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487294819572916225",
  "text" : "RT @WHLive: \"Today, our businesses have added 10 million new jobs over the past 52 months\" \u2014President Obama #OpportunityForAll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 96, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487294744880746496",
    "text" : "\"Today, our businesses have added 10 million new jobs over the past 52 months\" \u2014President Obama #OpportunityForAll",
    "id" : 487294744880746496,
    "created_at" : "2014-07-10 17:58:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 487294819572916225,
  "created_at" : "2014-07-10 17:58:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487294372590133248\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/JuTbbuSbta",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsM3pkZCQAAH35n.png",
      "id_str" : "487294371968991232",
      "id" : 487294371968991232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsM3pkZCQAAH35n.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JuTbbuSbta"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "487294372590133248",
  "text" : "\"You are why I ran for President in the first place.\" \u2014President Obama to folks in Austin: http:\/\/t.co\/b4tqL3oo0v, http:\/\/t.co\/JuTbbuSbta",
  "id" : 487294372590133248,
  "created_at" : "2014-07-10 17:56:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487294015956873216",
  "text" : "Obama: \"I\u2019m here today because of every American...who believes in the American Dream and just wants a chance to build a decent life\"",
  "id" : 487294015956873216,
  "created_at" : "2014-07-10 17:55:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "487292012769841152",
  "text" : "Happening now: President Obama speaks in Austin on expanding opportunity for more Americans \u2192 http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 487292012769841152,
  "created_at" : "2014-07-10 17:47:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "487283364094038016",
  "text" : "At 1:15 ET, President Obama speaks in Austin, Texas on expanding opportunity for more Americans \u2192 http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 487283364094038016,
  "created_at" : "2014-07-10 17:13:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/487276184225325056\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MqvbKKJv7M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsMnG4-CEAAQ2Mb.jpg",
      "id_str" : "487276184011411456",
      "id" : 487276184011411456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsMnG4-CEAAQ2Mb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MqvbKKJv7M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487281551361978368",
  "text" : "RT @PressSec: Potus arrives at legit local institution, Magnolia Cafe, to meet Austin letter writer Kinsey Button http:\/\/t.co\/MqvbKKJv7M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/487276184225325056\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/MqvbKKJv7M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsMnG4-CEAAQ2Mb.jpg",
        "id_str" : "487276184011411456",
        "id" : 487276184011411456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsMnG4-CEAAQ2Mb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MqvbKKJv7M"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487276184225325056",
    "text" : "Potus arrives at legit local institution, Magnolia Cafe, to meet Austin letter writer Kinsey Button http:\/\/t.co\/MqvbKKJv7M",
    "id" : 487276184225325056,
    "created_at" : "2014-07-10 16:44:30 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 487281551361978368,
  "created_at" : "2014-07-10 17:05:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487265974190895104\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/q6MXgto8PB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsMd0jPCUAIZsTR.jpg",
      "id_str" : "487265973334855682",
      "id" : 487265973334855682,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsMd0jPCUAIZsTR.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/q6MXgto8PB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/HFrBP96q2G",
      "expanded_url" : "http:\/\/go.wh.gov\/PQEM4i",
      "display_url" : "go.wh.gov\/PQEM4i"
    } ]
  },
  "geo" : { },
  "id_str" : "487265974190895104",
  "text" : "President Obama is taking action to make student loan payments more affordable \u2192 http:\/\/t.co\/HFrBP96q2G http:\/\/t.co\/q6MXgto8PB",
  "id" : 487265974190895104,
  "created_at" : "2014-07-10 16:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 81, 99 ]
    }, {
      "text" : "YearOfAction",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HFrBP96q2G",
      "expanded_url" : "http:\/\/go.wh.gov\/PQEM4i",
      "display_url" : "go.wh.gov\/PQEM4i"
    } ]
  },
  "geo" : { },
  "id_str" : "487252946774917120",
  "text" : "This year, President Obama has taken more than 40 actions and counting to expand #OpportunityForAll \u2192 http:\/\/t.co\/HFrBP96q2G #YearOfAction",
  "id" : 487252946774917120,
  "created_at" : "2014-07-10 15:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/487064455042576385\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/uqgLtyazWz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BsJmibjCQAAQuZ6.png",
      "id_str" : "487064451405725696",
      "id" : 487064451405725696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BsJmibjCQAAQuZ6.png",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uqgLtyazWz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487064455042576385",
  "text" : "\u201CI will keep trying to restore the American Dream for everyone who is willing to work for it\u201D \u2014Obama in Denver today: http:\/\/t.co\/uqgLtyazWz",
  "id" : 487064455042576385,
  "created_at" : "2014-07-10 02:43:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0nSlFBlwah",
      "expanded_url" : "http:\/\/youtu.be\/0kCOK71jNxg",
      "display_url" : "youtu.be\/0kCOK71jNxg"
    } ]
  },
  "geo" : { },
  "id_str" : "487023469154934784",
  "text" : "\u201CLet\u2019s put people back to work here rebuilding our roads, our bridges, our airports.\u201D \u2014Obama: http:\/\/t.co\/0nSlFBlwah #RebuildAmerica",
  "id" : 487023469154934784,
  "created_at" : "2014-07-10 00:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "487006463391719425",
  "text" : "Starting soon: President Obama  speaks on the humanitarian situation at the southwest border \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 487006463391719425,
  "created_at" : "2014-07-09 22:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/eN93nH4qoB",
      "expanded_url" : "http:\/\/youtu.be\/0kCOK71jNxg",
      "display_url" : "youtu.be\/0kCOK71jNxg"
    } ]
  },
  "geo" : { },
  "id_str" : "487000336641826816",
  "text" : "\u201CCynicism is a choice, and hope is a better choice.\u201D \u2014President Obama in Denver on expanding #OpportunityForAll: http:\/\/t.co\/eN93nH4qoB",
  "id" : 487000336641826816,
  "created_at" : "2014-07-09 22:28:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/0nSlFBlwah",
      "expanded_url" : "http:\/\/youtu.be\/0kCOK71jNxg",
      "display_url" : "youtu.be\/0kCOK71jNxg"
    } ]
  },
  "geo" : { },
  "id_str" : "486970408046841856",
  "text" : "\"We're stronger when we're helping everybody succeed, cultivating every talent.\" \u2014President Obama: http:\/\/t.co\/0nSlFBlwah #OpportunityForAll",
  "id" : 486970408046841856,
  "created_at" : "2014-07-09 20:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/486934151677743104\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KQBa0J2VFb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsHwB8tCMAAQgZ7.png",
      "id_str" : "486934150998274048",
      "id" : 486934150998274048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsHwB8tCMAAQgZ7.png",
      "sizes" : [ {
        "h" : 321,
        "resize" : "fit",
        "w" : 858
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 858
      } ],
      "display_url" : "pic.twitter.com\/KQBa0J2VFb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486940391820636164",
  "text" : "\"Juli\u00E1n is a proven leader, a champion for safe, affordable housing and strong, sustainable neighborhoods.\" \u2014Obama: http:\/\/t.co\/KQBa0J2VFb",
  "id" : 486940391820636164,
  "created_at" : "2014-07-09 18:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486934151677743104\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KQBa0J2VFb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsHwB8tCMAAQgZ7.png",
      "id_str" : "486934150998274048",
      "id" : 486934150998274048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsHwB8tCMAAQgZ7.png",
      "sizes" : [ {
        "h" : 321,
        "resize" : "fit",
        "w" : 858
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 858
      } ],
      "display_url" : "pic.twitter.com\/KQBa0J2VFb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486934151677743104",
  "text" : "President Obama on the confirmation of Juli\u00E1n Castro as our next Secretary of Housing and Urban Development \u2192 http:\/\/t.co\/KQBa0J2VFb",
  "id" : 486934151677743104,
  "created_at" : "2014-07-09 18:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486918224475197440",
  "text" : "RT @pfeiffer44: Nothing gets a bigger response from the crowd than mentions of Boehner's plan to sue POTUS for doing his job, while they do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486916201633689601",
    "text" : "Nothing gets a bigger response from the crowd than mentions of Boehner's plan to sue POTUS for doing his job, while they do nothing",
    "id" : 486916201633689601,
    "created_at" : "2014-07-09 16:54:03 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 486918224475197440,
  "created_at" : "2014-07-09 17:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486917610747871232",
  "text" : "\"I will keep trying to restore the American Dream for everyone who\u2019s willing to work for it.\" \u2014President Obama #OpportunityForAll",
  "id" : 486917610747871232,
  "created_at" : "2014-07-09 16:59:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 90, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "486916783727992833",
  "text" : "\"Cynicism is a choice. Hope is a better choice.\" \u2014President Obama: http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 486916783727992833,
  "created_at" : "2014-07-09 16:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 98, 111 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486916335952478208",
  "text" : "\u201CIt\u2019s a good thing when women are paid the same as men for doing the same work.\u201D \u2014President Obama #WomenSucceed #EqualPay",
  "id" : 486916335952478208,
  "created_at" : "2014-07-09 16:54:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486915757973200897\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/MTniax4pzm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsHfTS9CYAALuTV.jpg",
      "id_str" : "486915757331079168",
      "id" : 486915757331079168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsHfTS9CYAALuTV.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MTniax4pzm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/fMEhvXfOhy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "486915757973200897",
  "text" : "\u201CAmerica needs a raise.\u201D \u2014President Obama: http:\/\/t.co\/fMEhvXfOhy http:\/\/t.co\/MTniax4pzm",
  "id" : 486915757973200897,
  "created_at" : "2014-07-09 16:52:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486915260612620288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/LxUyqVoGtT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsHe2TtCEAAk1_o.jpg",
      "id_str" : "486915259316178944",
      "id" : 486915259316178944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsHe2TtCEAAk1_o.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LxUyqVoGtT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486915260612620288",
  "text" : "\"I went ahead and helped nearly 5 million Americans cap their student loan payments at 10% of their income.\" \u2014Obama http:\/\/t.co\/LxUyqVoGtT",
  "id" : 486915260612620288,
  "created_at" : "2014-07-09 16:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486914978042368000\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/qpkVoOadGa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsHel5PCAAEKzYr.jpg",
      "id_str" : "486914977333116929",
      "id" : 486914977333116929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsHel5PCAAEKzYr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qpkVoOadGa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ccgeYlGmMC",
      "expanded_url" : "http:\/\/wh.gov\/year-of-action",
      "display_url" : "wh.gov\/year-of-action"
    } ]
  },
  "geo" : { },
  "id_str" : "486914978042368000",
  "text" : "\"I believe that when women succeed, America succeeds.\" \u2014President Obama: http:\/\/t.co\/ccgeYlGmMC http:\/\/t.co\/qpkVoOadGa",
  "id" : 486914978042368000,
  "created_at" : "2014-07-09 16:49:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486914671623290880",
  "text" : "RT @WHLive: Obama: \"I\u2019m not going to stand by and let partisan gridlock or political games threaten the hard work of millions of Americans.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486914648361693184",
    "text" : "Obama: \"I\u2019m not going to stand by and let partisan gridlock or political games threaten the hard work of millions of Americans.\"",
    "id" : 486914648361693184,
    "created_at" : "2014-07-09 16:47:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 486914671623290880,
  "created_at" : "2014-07-09 16:47:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486914205577396226",
  "text" : "\u201COur economy grows best from the middle-out, when everybody has a shot to get ahead.\u201D \u2014President Obama #OpportunityForAll",
  "id" : 486914205577396226,
  "created_at" : "2014-07-09 16:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486913691783557120",
  "text" : "\u201CThey said no to equal pay for equal work. They said no to unemployment insurance.\u201D \u2014Obama on Republicans in Congress blocking progress",
  "id" : 486913691783557120,
  "created_at" : "2014-07-09 16:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486912849282072576",
  "text" : "\"The only story that matters is your story.\" \u2014President Obama on why he's focused on expanding opportunity for more Americans",
  "id" : 486912849282072576,
  "created_at" : "2014-07-09 16:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/486911625883320320\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/YxBc64sIf4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BsHbir6CUAAUA3c.png",
      "id_str" : "486911623680905216",
      "id" : 486911623680905216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BsHbir6CUAAUA3c.png",
      "sizes" : [ {
        "h" : 258,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YxBc64sIf4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486911625883320320",
  "text" : "\"Our businesses have added nearly 10 million new jobs over the past 52 months.\" \u2014President Obama http:\/\/t.co\/YxBc64sIf4",
  "id" : 486911625883320320,
  "created_at" : "2014-07-09 16:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 126, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486910995240321024",
  "text" : "\"I\u2019m here for every American who works their tail off and does everything right &amp; believes in the American Dream.\" \u2014Obama #OpportunityForAll",
  "id" : 486910995240321024,
  "created_at" : "2014-07-09 16:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486910035340296193",
  "text" : "\u201CIt reminds me of why I ran for office\u2026I have a chance to hear from people.\u201D \u2014President Obama on the 10 letters he reads every night",
  "id" : 486910035340296193,
  "created_at" : "2014-07-09 16:29:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "486909225713799169",
  "text" : "Happening now: President Obama speaks on expanding opportunity for more Americans. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 486909225713799169,
  "created_at" : "2014-07-09 16:26:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "486905427381460992",
  "text" : "At 12:20pm ET, President Obama speaks in Denver on expanding opportunity for more Americans \u2192 http:\/\/t.co\/b4tqL3oo0v #OpportunityForAll",
  "id" : 486905427381460992,
  "created_at" : "2014-07-09 16:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/JHViJuDGzN",
      "expanded_url" : "http:\/\/go.wh.gov\/qf1nie",
      "display_url" : "go.wh.gov\/qf1nie"
    } ]
  },
  "geo" : { },
  "id_str" : "486900593550966784",
  "text" : "President Obama sat down for dinner with 5 Coloradans who wrote him letters about what's going on in their lives \u2192 http:\/\/t.co\/JHViJuDGzN",
  "id" : 486900593550966784,
  "created_at" : "2014-07-09 15:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hickenlooper",
      "screen_name" : "hickforco",
      "indices" : [ 35, 45 ],
      "id_str" : "117839957",
      "id" : 117839957
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/486879697574580224\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RUoep2eMLz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsG-gTYCEAAF7qO.jpg",
      "id_str" : "486879696898887680",
      "id" : 486879696898887680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsG-gTYCEAAF7qO.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RUoep2eMLz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/IJqb4UwSPF",
      "expanded_url" : "http:\/\/instagram.com\/p\/qN1VFDwirV",
      "display_url" : "instagram.com\/p\/qN1VFDwirV"
    } ]
  },
  "geo" : { },
  "id_str" : "486879697574580224",
  "text" : "President Obama meets up with Gov. @HickForCO and folks in Denver for some pool and a pint: http:\/\/t.co\/IJqb4UwSPF http:\/\/t.co\/RUoep2eMLz",
  "id" : 486879697574580224,
  "created_at" : "2014-07-09 14:29:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/486869604216872960\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/s6UDuXcmeJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsG1UyaCAAENtbe.jpg",
      "id_str" : "486869603465691137",
      "id" : 486869603465691137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsG1UyaCAAENtbe.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/s6UDuXcmeJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486869604216872960",
  "text" : "Pizza with POTUS: President Obama sits down for a bite to eat in Denver with people who had written him letters. http:\/\/t.co\/s6UDuXcmeJ",
  "id" : 486869604216872960,
  "created_at" : "2014-07-09 13:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/486696730226724866\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/9x43lHzqeu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsEYGOxCYAAL4Ig.jpg",
      "id_str" : "486696730054778880",
      "id" : 486696730054778880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsEYGOxCYAAL4Ig.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9x43lHzqeu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486862899521257472",
  "text" : "RT @PressSec: POTUS shoots pool with Gov Hickenlooper. Just another Tues night in Denver. http:\/\/t.co\/9x43lHzqeu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/486696730226724866\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/9x43lHzqeu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsEYGOxCYAAL4Ig.jpg",
        "id_str" : "486696730054778880",
        "id" : 486696730054778880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsEYGOxCYAAL4Ig.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9x43lHzqeu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486696730226724866",
    "text" : "POTUS shoots pool with Gov Hickenlooper. Just another Tues night in Denver. http:\/\/t.co\/9x43lHzqeu",
    "id" : 486696730226724866,
    "created_at" : "2014-07-09 02:21:57 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 486862899521257472,
  "created_at" : "2014-07-09 13:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 51, 59 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GmSka25Jtt",
      "expanded_url" : "http:\/\/youtu.be\/QwtzCT5W6Ns",
      "display_url" : "youtu.be\/QwtzCT5W6Ns"
    } ]
  },
  "geo" : { },
  "id_str" : "486649109315858432",
  "text" : "\u201CI don\u2019t lose hope. I still hope.\u201D \u2014Dr. Mukwege to @DrBiden on caring for survivors of sexual violence in the DRC: http:\/\/t.co\/GmSka25Jtt",
  "id" : 486649109315858432,
  "created_at" : "2014-07-08 23:12:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486606087131766785",
  "text" : "RT @FLOTUS: The students the First Lady just met with beat the odds to graduate high school. Let\u2019s help more kids #ReachHigher. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/486604244880203777\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/jfr3vn9K9u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsDD-0WIUAIIB4X.jpg",
        "id_str" : "486604243726782466",
        "id" : 486604243726782466,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsDD-0WIUAIIB4X.jpg",
        "sizes" : [ {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1030,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 703,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jfr3vn9K9u"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486604244880203777",
    "text" : "The students the First Lady just met with beat the odds to graduate high school. Let\u2019s help more kids #ReachHigher. http:\/\/t.co\/jfr3vn9K9u",
    "id" : 486604244880203777,
    "created_at" : "2014-07-08 20:14:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 486606087131766785,
  "created_at" : "2014-07-08 20:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/1sSch7sCIa",
      "expanded_url" : "http:\/\/go.wh.gov\/JCr7zh",
      "display_url" : "go.wh.gov\/JCr7zh"
    } ]
  },
  "geo" : { },
  "id_str" : "486580524467904512",
  "text" : "Alex from Colorado wrote the President on the importance of the raise she received.\nToday, she'll meet him \u2192 http:\/\/t.co\/1sSch7sCIa",
  "id" : 486580524467904512,
  "created_at" : "2014-07-08 18:40:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486554269236334592",
  "text" : "RT @DrBiden: The global pandemic of sexual violence against women &amp; girls must end. Lots of work ahead. Watch this moving video: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/tvlfcapczZ",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=QwtzCT5W6Ns&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=QwtzCT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486551874657861632",
    "text" : "The global pandemic of sexual violence against women &amp; girls must end. Lots of work ahead. Watch this moving video: http:\/\/t.co\/tvlfcapczZ",
    "id" : 486551874657861632,
    "created_at" : "2014-07-08 16:46:21 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 486554269236334592,
  "created_at" : "2014-07-08 16:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 83, 91 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/pRtquMqEP7",
      "expanded_url" : "http:\/\/go.wh.gov\/TAA4SN",
      "display_url" : "go.wh.gov\/TAA4SN"
    } ]
  },
  "geo" : { },
  "id_str" : "486549503919783937",
  "text" : "RT @FLOTUS: \u201CWe hope to improve women\u2019s lives through educational opportunities.\u201D \u2014@DrBiden in Zambia: http:\/\/t.co\/pRtquMqEP7 http:\/\/t.co\/4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 71, 79 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/486545543779610625\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/4JhQeekyGV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BsCOl7mIAAALkOn.jpg",
        "id_str" : "486545542059917312",
        "id" : 486545542059917312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsCOl7mIAAALkOn.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4JhQeekyGV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/pRtquMqEP7",
        "expanded_url" : "http:\/\/go.wh.gov\/TAA4SN",
        "display_url" : "go.wh.gov\/TAA4SN"
      } ]
    },
    "geo" : { },
    "id_str" : "486545543779610625",
    "text" : "\u201CWe hope to improve women\u2019s lives through educational opportunities.\u201D \u2014@DrBiden in Zambia: http:\/\/t.co\/pRtquMqEP7 http:\/\/t.co\/4JhQeekyGV",
    "id" : 486545543779610625,
    "created_at" : "2014-07-08 16:21:11 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 486549503919783937,
  "created_at" : "2014-07-08 16:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486535483825340416\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/unHTLAsZEv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BsCFcbQCAAAe53E.jpg",
      "id_str" : "486535483153842176",
      "id" : 486535483153842176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BsCFcbQCAAAe53E.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/unHTLAsZEv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/1sSch7sCIa",
      "expanded_url" : "http:\/\/go.wh.gov\/JCr7zh",
      "display_url" : "go.wh.gov\/JCr7zh"
    } ]
  },
  "geo" : { },
  "id_str" : "486535483825340416",
  "text" : "President Obama's on the road again this week to meet with people who wrote him letters \u2192 http:\/\/t.co\/1sSch7sCIa http:\/\/t.co\/unHTLAsZEv",
  "id" : 486535483825340416,
  "created_at" : "2014-07-08 15:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheBearIsLoose",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/1sSch7sCIa",
      "expanded_url" : "http:\/\/go.wh.gov\/JCr7zh",
      "display_url" : "go.wh.gov\/JCr7zh"
    } ]
  },
  "geo" : { },
  "id_str" : "486526833572446208",
  "text" : "#TheBearIsLoose: President Obama's headed to Denver to meet with folks who've written him letters \u2192 http:\/\/t.co\/1sSch7sCIa",
  "id" : 486526833572446208,
  "created_at" : "2014-07-08 15:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/486298652499906561\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/GxuPC0z8NL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br-ohBXCEAA3kIU.jpg",
      "id_str" : "486292570033491968",
      "id" : 486292570033491968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br-ohBXCEAA3kIU.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GxuPC0z8NL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/55B3P1hkSS",
      "expanded_url" : "http:\/\/go.wh.gov\/G3eJhj",
      "display_url" : "go.wh.gov\/G3eJhj"
    } ]
  },
  "geo" : { },
  "id_str" : "486298652499906561",
  "text" : "Family and fireworks: http:\/\/t.co\/55B3P1hkSS http:\/\/t.co\/GxuPC0z8NL",
  "id" : 486298652499906561,
  "created_at" : "2014-07-08 00:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 93, 104 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WGyAgdoCOi",
      "expanded_url" : "http:\/\/wh.gov\/fourth-of-july",
      "display_url" : "wh.gov\/fourth-of-july"
    } ]
  },
  "geo" : { },
  "id_str" : "486295071042854912",
  "text" : "RT @FLOTUS: The First Family + fireworks + military families = A great Fourth of July at the @WhiteHouse \u2192 http:\/\/t.co\/WGyAgdoCOi http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 81, 92 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/486294907699478529\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/JseabbafK8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Br-fLdqCMAIsOq5.jpg",
        "id_str" : "486282304067612674",
        "id" : 486282304067612674,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br-fLdqCMAIsOq5.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JseabbafK8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/WGyAgdoCOi",
        "expanded_url" : "http:\/\/wh.gov\/fourth-of-july",
        "display_url" : "wh.gov\/fourth-of-july"
      } ]
    },
    "geo" : { },
    "id_str" : "486294907699478529",
    "text" : "The First Family + fireworks + military families = A great Fourth of July at the @WhiteHouse \u2192 http:\/\/t.co\/WGyAgdoCOi http:\/\/t.co\/JseabbafK8",
    "id" : 486294907699478529,
    "created_at" : "2014-07-07 23:45:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 486295071042854912,
  "created_at" : "2014-07-07 23:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/486269656164872192\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/EFh9qiFO4J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br-TrN6CMAEgg3Q.jpg",
      "id_str" : "486269655456034817",
      "id" : 486269655456034817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br-TrN6CMAEgg3Q.jpg",
      "sizes" : [ {
        "h" : 365,
        "resize" : "fit",
        "w" : 505
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 505
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 505
      } ],
      "display_url" : "pic.twitter.com\/EFh9qiFO4J"
    } ],
    "hashtags" : [ {
      "text" : "parksforall",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486273778251747328",
  "text" : "RT @Interior: Please retweet if you agree! #parksforall http:\/\/t.co\/EFh9qiFO4J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/486269656164872192\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/EFh9qiFO4J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Br-TrN6CMAEgg3Q.jpg",
        "id_str" : "486269655456034817",
        "id" : 486269655456034817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br-TrN6CMAEgg3Q.jpg",
        "sizes" : [ {
          "h" : 365,
          "resize" : "fit",
          "w" : 505
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 505
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 505
        } ],
        "display_url" : "pic.twitter.com\/EFh9qiFO4J"
      } ],
      "hashtags" : [ {
        "text" : "parksforall",
        "indices" : [ 29, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486269656164872192",
    "text" : "Please retweet if you agree! #parksforall http:\/\/t.co\/EFh9qiFO4J",
    "id" : 486269656164872192,
    "created_at" : "2014-07-07 22:04:55 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 486273778251747328,
  "created_at" : "2014-07-07 22:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 58, 69 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486232999701524481\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/VZ23JEk0qd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br9yViUCEAAostU.jpg",
      "id_str" : "486232999092948992",
      "id" : 486232999092948992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br9yViUCEAAostU.jpg",
      "sizes" : [ {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 727,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VZ23JEk0qd"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/GAc3HS9s53",
      "expanded_url" : "http:\/\/go.wh.gov\/PPSFLY",
      "display_url" : "go.wh.gov\/PPSFLY"
    } ]
  },
  "geo" : { },
  "id_str" : "486232999701524481",
  "text" : "\u201CAll children are entitled to a high-quality education.\u201D \u2014@ArneDuncan: http:\/\/t.co\/GAc3HS9s53 #ReachHigher http:\/\/t.co\/VZ23JEk0qd",
  "id" : 486232999701524481,
  "created_at" : "2014-07-07 19:39:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/hBd2gnl89d",
      "expanded_url" : "http:\/\/go.wh.gov\/WkEna8",
      "display_url" : "go.wh.gov\/WkEna8"
    } ]
  },
  "geo" : { },
  "id_str" : "486219055893061632",
  "text" : "FACT: We're reducing our dependence on foreign oil by importing less than we produce at home: http:\/\/t.co\/hBd2gnl89d #ActOnClimate",
  "id" : 486219055893061632,
  "created_at" : "2014-07-07 18:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/486204779052687360\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ZkfNMfmhIe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br9Yq3GCQAApUpt.jpg",
      "id_str" : "486204778146316288",
      "id" : 486204778146316288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br9Yq3GCQAApUpt.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZkfNMfmhIe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/wHROHAKO0t",
      "expanded_url" : "http:\/\/1.usa.gov\/1tfTRkc",
      "display_url" : "1.usa.gov\/1tfTRkc"
    } ]
  },
  "geo" : { },
  "id_str" : "486204779052687360",
  "text" : "President Obama's launching a new initiative to help more students access great teachers \u2192 http:\/\/t.co\/wHROHAKO0t http:\/\/t.co\/ZkfNMfmhIe",
  "id" : 486204779052687360,
  "created_at" : "2014-07-07 17:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/oEYTukcxJF",
      "expanded_url" : "http:\/\/go.wh.gov\/WkEna8",
      "display_url" : "go.wh.gov\/WkEna8"
    } ]
  },
  "geo" : { },
  "id_str" : "486187947067047936",
  "text" : "FACT: American auto sales in June were the highest they've been since mid-2006: http:\/\/t.co\/oEYTukcxJF #MadeInAmerica",
  "id" : 486187947067047936,
  "created_at" : "2014-07-07 16:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hBd2gnl89d",
      "expanded_url" : "http:\/\/go.wh.gov\/WkEna8",
      "display_url" : "go.wh.gov\/WkEna8"
    } ]
  },
  "geo" : { },
  "id_str" : "486179939256139777",
  "text" : "FACT: Our businesses added 1.4 million jobs over the first half of this year\u2014more than in any first half since 1999: http:\/\/t.co\/hBd2gnl89d",
  "id" : 486179939256139777,
  "created_at" : "2014-07-07 16:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/486168513326120961\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/f7FbEC3ZHL",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Br83rz2CIAMR7e_.png",
      "id_str" : "486168510570045443",
      "id" : 486168510570045443,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Br83rz2CIAMR7e_.png",
      "sizes" : [ {
        "h" : 258,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f7FbEC3ZHL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/hBd2gnl89d",
      "expanded_url" : "http:\/\/go.wh.gov\/WkEna8",
      "display_url" : "go.wh.gov\/WkEna8"
    } ]
  },
  "geo" : { },
  "id_str" : "486168513326120961",
  "text" : "Our economy has come a long way over the last few years\u2014but we've got more work to do: http:\/\/t.co\/hBd2gnl89d http:\/\/t.co\/f7FbEC3ZHL",
  "id" : 486168513326120961,
  "created_at" : "2014-07-07 15:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Office of Ed Tech",
      "screen_name" : "OfficeofEdTech",
      "indices" : [ 3, 18 ],
      "id_str" : "172779883",
      "id" : 172779883
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 68, 76 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486151690367033344",
  "text" : "RT @OfficeofEdTech: POTUS is meeting with schoolteachers to discuss @usedgov's Excellent Educators initiative, including $4.2M for new tech\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 48, 56 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486118756167331840",
    "text" : "POTUS is meeting with schoolteachers to discuss @usedgov's Excellent Educators initiative, including $4.2M for new technical assistance!",
    "id" : 486118756167331840,
    "created_at" : "2014-07-07 12:05:17 +0000",
    "user" : {
      "name" : "Office of Ed Tech",
      "screen_name" : "OfficeofEdTech",
      "protected" : false,
      "id_str" : "172779883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512579850737946624\/SWziPMXc_normal.png",
      "id" : 172779883,
      "verified" : true
    }
  },
  "id" : 486151690367033344,
  "created_at" : "2014-07-07 14:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/mckF978qDv",
      "expanded_url" : "http:\/\/go.wh.gov\/txuR8H",
      "display_url" : "go.wh.gov\/txuR8H"
    } ]
  },
  "geo" : { },
  "id_str" : "485483279940726784",
  "text" : "\"You keep us safe &amp; you keep the United States of America a shining beacon of hope for the world.\" \u2014President Obama: http:\/\/t.co\/mckF978qDv",
  "id" : 485483279940726784,
  "created_at" : "2014-07-05 18:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/PemR1nzS2D",
      "expanded_url" : "http:\/\/go.wh.gov\/yXM3e8",
      "display_url" : "go.wh.gov\/yXM3e8"
    } ]
  },
  "geo" : { },
  "id_str" : "485453069115617283",
  "text" : "\"Our success is only possible because we have never treated those self-evident truths as self-executing.\" \u2014Obama: http:\/\/t.co\/PemR1nzS2D",
  "id" : 485453069115617283,
  "created_at" : "2014-07-05 16:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Happy4thOfJuly",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/PemR1nzS2D",
      "expanded_url" : "http:\/\/go.wh.gov\/yXM3e8",
      "display_url" : "go.wh.gov\/yXM3e8"
    } ]
  },
  "geo" : { },
  "id_str" : "485422913579794433",
  "text" : "\"I hope you're all having a great Fourth of July weekend!\" \u2014President Obama: http:\/\/t.co\/PemR1nzS2D #Happy4thOfJuly",
  "id" : 485422913579794433,
  "created_at" : "2014-07-05 14:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/485279040631480320\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/X2uDhVE1LX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrwOturCUAEet8n.jpg",
      "id_str" : "485279038634610689",
      "id" : 485279038634610689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrwOturCUAEet8n.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/X2uDhVE1LX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485279040631480320",
  "text" : "The view from the roof of the White House. http:\/\/t.co\/X2uDhVE1LX",
  "id" : 485279040631480320,
  "created_at" : "2014-07-05 04:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pitbull",
      "screen_name" : "pitbull",
      "indices" : [ 3, 11 ],
      "id_str" : "31927467",
      "id" : 31927467
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 56, 67 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 69, 82 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 83, 91 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "joiningforces",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/iBzoLGXtcS",
      "expanded_url" : "http:\/\/whitehouse.gov\/fourth-of-july",
      "display_url" : "whitehouse.gov\/fourth-of-july"
    } ]
  },
  "geo" : { },
  "id_str" : "485204720101781504",
  "text" : "RT @pitbull: Watch us live here http:\/\/t.co\/iBzoLGXtcS  @WhiteHouse  @lacasablanca @the_USO #joiningforces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "La Casa Blanca",
        "screen_name" : "lacasablanca",
        "indices" : [ 56, 69 ],
        "id_str" : "78138151",
        "id" : 78138151
      }, {
        "name" : "USO",
        "screen_name" : "the_USO",
        "indices" : [ 70, 78 ],
        "id_str" : "36681590",
        "id" : 36681590
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "joiningforces",
        "indices" : [ 79, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/iBzoLGXtcS",
        "expanded_url" : "http:\/\/whitehouse.gov\/fourth-of-july",
        "display_url" : "whitehouse.gov\/fourth-of-july"
      } ]
    },
    "geo" : { },
    "id_str" : "485192546750955520",
    "text" : "Watch us live here http:\/\/t.co\/iBzoLGXtcS  @WhiteHouse  @lacasablanca @the_USO #joiningforces",
    "id" : 485192546750955520,
    "created_at" : "2014-07-04 22:44:52 +0000",
    "user" : {
      "name" : "Pitbull",
      "screen_name" : "pitbull",
      "protected" : false,
      "id_str" : "31927467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746034466095661060\/E2SJPGB9_normal.jpg",
      "id" : 31927467,
      "verified" : true
    }
  },
  "id" : 485204720101781504,
  "created_at" : "2014-07-04 23:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/485188716064169984\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/mI6B6pZrOH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bru8kIRCcAAPzfj.png",
      "id_str" : "485188713752719360",
      "id" : 485188713752719360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bru8kIRCcAAPzfj.png",
      "sizes" : [ {
        "h" : 318,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/mI6B6pZrOH"
    } ],
    "hashtags" : [ {
      "text" : "Happy4thOfJuly",
      "indices" : [ 12, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485188716064169984",
  "text" : "America. \uD83C\uDDFA\uD83C\uDDF8 #Happy4thOfJuly http:\/\/t.co\/mI6B6pZrOH",
  "id" : 485188716064169984,
  "created_at" : "2014-07-04 22:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485182712018640896",
  "text" : "RT @WHLive: \"On behalf of our entire country, Michelle and I simply want to say thank you.\" \u2014President Obama to military families",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "485182680162926592",
    "text" : "\"On behalf of our entire country, Michelle and I simply want to say thank you.\" \u2014President Obama to military families",
    "id" : 485182680162926592,
    "created_at" : "2014-07-04 22:05:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 485182712018640896,
  "created_at" : "2014-07-04 22:05:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485182119837458432",
  "text" : "\"We salute our military families\u2014the spouses who put their careers on hold for their loved ones.\" \u2014President Obama",
  "id" : 485182119837458432,
  "created_at" : "2014-07-04 22:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 74, 85 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/485181623697436672\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/shVi0tiOVc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bru2HZUCEAA1cpx.jpg",
      "id_str" : "485181623042707456",
      "id" : 485181623042707456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bru2HZUCEAA1cpx.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/shVi0tiOVc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "485181623697436672",
  "text" : "Watch live: President Obama speaks at a Fourth of July celebration at the @WhiteHouse \u2192 http:\/\/t.co\/b4tqL3oo0v http:\/\/t.co\/shVi0tiOVc",
  "id" : 485181623697436672,
  "created_at" : "2014-07-04 22:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/485176282075115520\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/I4KOA1SHJ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BruxQezCQAAvDim.jpg",
      "id_str" : "485176281575604224",
      "id" : 485176281575604224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BruxQezCQAAvDim.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I4KOA1SHJ5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485176282075115520",
  "text" : "A beautiful Fourth of July at the People's House. \uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/I4KOA1SHJ5",
  "id" : 485176282075115520,
  "created_at" : "2014-07-04 21:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 85, 93 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485171823169241089",
  "text" : "RT @JoiningForces: Tonight the White House welcomes military families for a BBQ with @the_USO. Watch fireworks with them at 9:10 pm ET \u2192 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USO",
        "screen_name" : "the_USO",
        "indices" : [ 66, 74 ],
        "id_str" : "36681590",
        "id" : 36681590
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rY31qom14n",
        "expanded_url" : "http:\/\/whitehouse.gov\/fourth-of-july",
        "display_url" : "whitehouse.gov\/fourth-of-july"
      } ]
    },
    "geo" : { },
    "id_str" : "485159550216323072",
    "text" : "Tonight the White House welcomes military families for a BBQ with @the_USO. Watch fireworks with them at 9:10 pm ET \u2192 http:\/\/t.co\/rY31qom14n",
    "id" : 485159550216323072,
    "created_at" : "2014-07-04 20:33:45 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 485171823169241089,
  "created_at" : "2014-07-04 21:22:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 36, 47 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Tim Howard",
      "screen_name" : "TimHowardGK",
      "indices" : [ 64, 76 ],
      "id_str" : "2511477648",
      "id" : 2511477648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mckF978qDv",
      "expanded_url" : "http:\/\/go.wh.gov\/txuR8H",
      "display_url" : "go.wh.gov\/txuR8H"
    } ]
  },
  "geo" : { },
  "id_str" : "485136029112758273",
  "text" : "\"There\u2019s actually a petition on the @WhiteHouse website to make @TimHowardGK the next Secretary of Defense.\" \u2014Obama: http:\/\/t.co\/mckF978qDv",
  "id" : 485136029112758273,
  "created_at" : "2014-07-04 19:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/mckF978qDv",
      "expanded_url" : "http:\/\/go.wh.gov\/txuR8H",
      "display_url" : "go.wh.gov\/txuR8H"
    } ]
  },
  "geo" : { },
  "id_str" : "485113349823139840",
  "text" : "\"They were united by a belief in a simple truth\u2014that we are all created equal.\" \u2014Obama on our Founding Fathers: http:\/\/t.co\/mckF978qDv",
  "id" : 485113349823139840,
  "created_at" : "2014-07-04 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/485105866387894272\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/dr6daD5JkX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrtuGWyCIAEOucU.jpg",
      "id_str" : "485102440346165249",
      "id" : 485102440346165249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrtuGWyCIAEOucU.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 892,
        "resize" : "fit",
        "w" : 1456
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dr6daD5JkX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485105866387894272",
  "text" : "\"Together, all of you remind us that America is and always has been a nation of immigrants.\" \u2014President Obama http:\/\/t.co\/dr6daD5JkX",
  "id" : 485105866387894272,
  "created_at" : "2014-07-04 17:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Happy4thOfJuly",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/PemR1nzS2D",
      "expanded_url" : "http:\/\/go.wh.gov\/yXM3e8",
      "display_url" : "go.wh.gov\/yXM3e8"
    } ]
  },
  "geo" : { },
  "id_str" : "485100751123787777",
  "text" : "President Obama wishes all Americans a #Happy4thOfJuly \u2192 http:\/\/t.co\/PemR1nzS2D",
  "id" : 485100751123787777,
  "created_at" : "2014-07-04 16:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/mTTIjGLYi1",
      "expanded_url" : "https:\/\/vine.co\/v\/MUdpFVgqeBZ",
      "display_url" : "vine.co\/v\/MUdpFVgqeBZ"
    } ]
  },
  "geo" : { },
  "id_str" : "485090065664978944",
  "text" : "RT @FLOTUS: Happy 4th of July everyone! https:\/\/t.co\/mTTIjGLYi1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/mTTIjGLYi1",
        "expanded_url" : "https:\/\/vine.co\/v\/MUdpFVgqeBZ",
        "display_url" : "vine.co\/v\/MUdpFVgqeBZ"
      } ]
    },
    "geo" : { },
    "id_str" : "485089241995550720",
    "text" : "Happy 4th of July everyone! https:\/\/t.co\/mTTIjGLYi1",
    "id" : 485089241995550720,
    "created_at" : "2014-07-04 15:54:22 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 485090065664978944,
  "created_at" : "2014-07-04 15:57:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "indices" : [ 3, 18 ],
      "id_str" : "73206956",
      "id" : 73206956
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "USCIS",
      "screen_name" : "USCIS",
      "indices" : [ 128, 134 ],
      "id_str" : "14625398",
      "id" : 14625398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485086100374171649",
  "text" : "RT @chefjoseandres: Humbled to receive Outstanding American by Choice Award. Happy to be part of this great nation! @WhiteHouse @USCIS http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 96, 107 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "USCIS",
        "screen_name" : "USCIS",
        "indices" : [ 108, 114 ],
        "id_str" : "14625398",
        "id" : 14625398
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chefjoseandres\/status\/485085459996241920\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/033H9HMY1y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrteprLIAAAgptH.jpg",
        "id_str" : "485085454929494016",
        "id" : 485085454929494016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrteprLIAAAgptH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/033H9HMY1y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.8944932705, -77.0402463693 ]
    },
    "id_str" : "485085459996241920",
    "text" : "Humbled to receive Outstanding American by Choice Award. Happy to be part of this great nation! @WhiteHouse @USCIS http:\/\/t.co\/033H9HMY1y",
    "id" : 485085459996241920,
    "created_at" : "2014-07-04 15:39:20 +0000",
    "user" : {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "protected" : false,
      "id_str" : "73206956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468467014772600832\/vauGQ8wb_normal.jpeg",
      "id" : 73206956,
      "verified" : true
    }
  },
  "id" : 485086100374171649,
  "created_at" : "2014-07-04 15:41:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485082898476052480",
  "text" : "\"I\u2019m going to keep doing everything I can to make our immigration system smarter and more efficient\" \u2014President Obama",
  "id" : 485082898476052480,
  "created_at" : "2014-07-04 15:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485082518962855936",
  "text" : "\"Together, all of you remind us that America is and always has been a nation of immigrants.\" \u2014President Obama at a naturalization ceremony",
  "id" : 485082518962855936,
  "created_at" : "2014-07-04 15:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485081527332909056",
  "text" : "\"It is an honor to join everyone here, for the first time, in calling you our fellow Americans\"\u2014President Obama at a naturalization ceremony",
  "id" : 485081527332909056,
  "created_at" : "2014-07-04 15:23:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uzd0sMF67E",
      "expanded_url" : "http:\/\/go.wh.gov\/esrXRT",
      "display_url" : "go.wh.gov\/esrXRT"
    } ]
  },
  "geo" : { },
  "id_str" : "485079475072532481",
  "text" : "Happening now: President Obama speaks at a naturalization ceremony for service members at the White House. Watch \u2192 http:\/\/t.co\/uzd0sMF67E",
  "id" : 485079475072532481,
  "created_at" : "2014-07-04 15:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/uzd0sMF67E",
      "expanded_url" : "http:\/\/go.wh.gov\/esrXRT",
      "display_url" : "go.wh.gov\/esrXRT"
    } ]
  },
  "geo" : { },
  "id_str" : "485075854125723648",
  "text" : "Starting soon: President Obama speaks at a naturalization ceremony for active duty service members. Watch \u2192 http:\/\/t.co\/uzd0sMF67E",
  "id" : 485075854125723648,
  "created_at" : "2014-07-04 15:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "CanyonlandsNPS",
      "screen_name" : "CanyonlandsNPS",
      "indices" : [ 100, 115 ],
      "id_str" : "298047906",
      "id" : 298047906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sunset",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "Utah",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484794996617641984",
  "text" : "RT @Interior: We are going to send you into the 4th of July weekend with this amazing #sunset photo @CanyonlandsNPS. #Utah http:\/\/t.co\/5g2E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CanyonlandsNPS",
        "screen_name" : "CanyonlandsNPS",
        "indices" : [ 86, 101 ],
        "id_str" : "298047906",
        "id" : 298047906
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/484791378216759296\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/5g2EqCr3Go",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrpTMHzIAAAf44E.jpg",
        "id_str" : "484791377612767232",
        "id" : 484791377612767232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrpTMHzIAAAf44E.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5g2EqCr3Go"
      } ],
      "hashtags" : [ {
        "text" : "sunset",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "Utah",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484791378216759296",
    "text" : "We are going to send you into the 4th of July weekend with this amazing #sunset photo @CanyonlandsNPS. #Utah http:\/\/t.co\/5g2EqCr3Go",
    "id" : 484791378216759296,
    "created_at" : "2014-07-03 20:10:46 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 484794996617641984,
  "created_at" : "2014-07-03 20:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484788337753219073",
  "text" : "RT @FLOTUS: The First Lady congratulated her mentees on graduating high school by sharing a book by her own mentor, Maya Angelou. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/484787979706445825\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/iasmN3aKDQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrpQGQZIUAA6EpJ.jpg",
        "id_str" : "484787978305556480",
        "id" : 484787978305556480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrpQGQZIUAA6EpJ.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iasmN3aKDQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484787979706445825",
    "text" : "The First Lady congratulated her mentees on graduating high school by sharing a book by her own mentor, Maya Angelou. http:\/\/t.co\/iasmN3aKDQ",
    "id" : 484787979706445825,
    "created_at" : "2014-07-03 19:57:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 484788337753219073,
  "created_at" : "2014-07-03 19:58:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Crowley",
      "screen_name" : "Stcrow",
      "indices" : [ 3, 10 ],
      "id_str" : "24715018",
      "id" : 24715018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484782205550735360",
  "text" : "RT @Stcrow: President Obama pitched immigration reform as job creator during  visit to 1776, a tech startup hub in Washington D.C http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Stcrow\/status\/484750440836648961\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eI2S5jDkQ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Brot9MXIYAAAWKp.jpg",
        "id_str" : "484750439209263104",
        "id" : 484750439209263104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brot9MXIYAAAWKp.jpg",
        "sizes" : [ {
          "h" : 203,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 115,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eI2S5jDkQ2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484750440836648961",
    "text" : "President Obama pitched immigration reform as job creator during  visit to 1776, a tech startup hub in Washington D.C http:\/\/t.co\/eI2S5jDkQ2",
    "id" : 484750440836648961,
    "created_at" : "2014-07-03 17:28:05 +0000",
    "user" : {
      "name" : "Stephen Crowley",
      "screen_name" : "Stcrow",
      "protected" : false,
      "id_str" : "24715018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691718175004758020\/jqjxoXpB_normal.jpg",
      "id" : 24715018,
      "verified" : true
    }
  },
  "id" : 484782205550735360,
  "created_at" : "2014-07-03 19:34:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arthur",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/2beWtJa5Ad",
      "expanded_url" : "http:\/\/www.nhc.noaa.gov\/mobile\/",
      "display_url" : "nhc.noaa.gov\/mobile\/"
    } ]
  },
  "geo" : { },
  "id_str" : "484774545673715712",
  "text" : "RT @CraigatFEMA: Keep track of Hurricane #Arthur updates on the go. Bookmark NHC &amp; NWS mobile pages http:\/\/t.co\/2beWtJa5Ad &amp;  http:\/\/t.co\/L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Arthur",
        "indices" : [ 24, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/2beWtJa5Ad",
        "expanded_url" : "http:\/\/www.nhc.noaa.gov\/mobile\/",
        "display_url" : "nhc.noaa.gov\/mobile\/"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/L10mC3pWVk",
        "expanded_url" : "http:\/\/mobile.weather.gov",
        "display_url" : "mobile.weather.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "484773299335864320",
    "text" : "Keep track of Hurricane #Arthur updates on the go. Bookmark NHC &amp; NWS mobile pages http:\/\/t.co\/2beWtJa5Ad &amp;  http:\/\/t.co\/L10mC3pWVk",
    "id" : 484773299335864320,
    "created_at" : "2014-07-03 18:58:55 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 484774545673715712,
  "created_at" : "2014-07-03 19:03:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 3, 12 ],
      "id_str" : "7563792",
      "id" : 7563792
    }, {
      "name" : "Clint Dempsey",
      "screen_name" : "clint_dempsey",
      "indices" : [ 58, 72 ],
      "id_str" : "431429137",
      "id" : 431429137
    }, {
      "name" : "Tim Howard",
      "screen_name" : "TimHowardGK",
      "indices" : [ 79, 91 ],
      "id_str" : "2511477648",
      "id" : 2511477648
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 101, 112 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USMNT",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NcaoG3kwgy",
      "expanded_url" : "http:\/\/youtu.be\/jYeD2nrLZRU",
      "display_url" : "youtu.be\/jYeD2nrLZRU"
    } ]
  },
  "geo" : { },
  "id_str" : "484751523378106368",
  "text" : "RT @ussoccer: WATCH: President Obama calls #USMNT players @clint_dempsey &amp; @TimHowardGK from the @WhiteHouse. http:\/\/t.co\/NcaoG3kwgy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clint Dempsey",
        "screen_name" : "clint_dempsey",
        "indices" : [ 44, 58 ],
        "id_str" : "431429137",
        "id" : 431429137
      }, {
        "name" : "Tim Howard",
        "screen_name" : "TimHowardGK",
        "indices" : [ 65, 77 ],
        "id_str" : "2511477648",
        "id" : 2511477648
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 87, 98 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USMNT",
        "indices" : [ 29, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/NcaoG3kwgy",
        "expanded_url" : "http:\/\/youtu.be\/jYeD2nrLZRU",
        "display_url" : "youtu.be\/jYeD2nrLZRU"
      } ]
    },
    "geo" : { },
    "id_str" : "484698911295426560",
    "text" : "WATCH: President Obama calls #USMNT players @clint_dempsey &amp; @TimHowardGK from the @WhiteHouse. http:\/\/t.co\/NcaoG3kwgy",
    "id" : 484698911295426560,
    "created_at" : "2014-07-03 14:03:20 +0000",
    "user" : {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "protected" : false,
      "id_str" : "7563792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704355346622586884\/oGZUl3xk_normal.jpg",
      "id" : 7563792,
      "verified" : true
    }
  },
  "id" : 484751523378106368,
  "created_at" : "2014-07-03 17:32:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1776",
      "screen_name" : "1776dc",
      "indices" : [ 25, 32 ],
      "id_str" : "2838775419",
      "id" : 2838775419
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 112, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/2e0tN2IgKn",
      "expanded_url" : "https:\/\/vine.co\/v\/MU5g0P0zVK0",
      "display_url" : "vine.co\/v\/MU5g0P0zVK0"
    } ]
  },
  "geo" : { },
  "id_str" : "484722079724761088",
  "text" : "President Obama stops by @1776DC\u2014a tech start-up incubator\u2014to meet with entrepreneurs \u2192 https:\/\/t.co\/2e0tN2IgKn #InnovationNation",
  "id" : 484722079724761088,
  "created_at" : "2014-07-03 15:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474917160054059008\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xrxny1RSEc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "id_str" : "474917159269720065",
      "id" : 474917159269720065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xrxny1RSEc"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/2WCDD3YTlf",
      "expanded_url" : "http:\/\/go.wh.gov\/Cizt6X",
      "display_url" : "go.wh.gov\/Cizt6X"
    } ]
  },
  "geo" : { },
  "id_str" : "484713697353670657",
  "text" : "FACT: Our businesses added 262,000 jobs in June\u2014but there's more work to do: http:\/\/t.co\/2WCDD3YTlf #ActOnJobs http:\/\/t.co\/xrxny1RSEc",
  "id" : 484713697353670657,
  "created_at" : "2014-07-03 15:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/474917160054059008\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xrxny1RSEc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "id_str" : "474917159269720065",
      "id" : 474917159269720065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpc-o-ACYAEh9HA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xrxny1RSEc"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484700805094985728",
  "text" : "FACT: Our businesses have added jobs for 52 straight months, the longest such streak since at least 1939. #ActOnJobs http:\/\/t.co\/xrxny1RSEc",
  "id" : 484700805094985728,
  "created_at" : "2014-07-03 14:10:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/tyc3NbY7AF",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/07\/03\/employment-situation-june",
      "display_url" : "whitehouse.gov\/blog\/2014\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484697233649328128",
  "text" : "RT @CEAChair: The 1.4 million jobs added in the first half of this year are the most in any first half since 1999 http:\/\/t.co\/tyc3NbY7AF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/tyc3NbY7AF",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/07\/03\/employment-situation-june",
        "display_url" : "whitehouse.gov\/blog\/2014\/07\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484695847662530560",
    "text" : "The 1.4 million jobs added in the first half of this year are the most in any first half since 1999 http:\/\/t.co\/tyc3NbY7AF",
    "id" : 484695847662530560,
    "created_at" : "2014-07-03 13:51:09 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 484697233649328128,
  "created_at" : "2014-07-03 13:56:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/484693486076432385\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yqb4kdD2fF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Brn6KDRCQAI8FBf.jpg",
      "id_str" : "484693485501431810",
      "id" : 484693485501431810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brn6KDRCQAI8FBf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yqb4kdD2fF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484693486076432385",
  "text" : "Our businesses have added:\n9.7 million jobs over 52 months \u2714\nMore than 1.4 million this year \u2714\n262,000 in June \u2714\n\u2192 http:\/\/t.co\/yqb4kdD2fF",
  "id" : 484693486076432385,
  "created_at" : "2014-07-03 13:41:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484692069223784448",
  "text" : "RT @Simas44: This is the first time since September 1999-January 2000 we have seen total job growth above 200,000 for five straight months.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484691233835864064",
    "text" : "This is the first time since September 1999-January 2000 we have seen total job growth above 200,000 for five straight months.",
    "id" : 484691233835864064,
    "created_at" : "2014-07-03 13:32:49 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 484692069223784448,
  "created_at" : "2014-07-03 13:36:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 3, 12 ],
      "id_str" : "7563792",
      "id" : 7563792
    }, {
      "name" : "Clint Dempsey",
      "screen_name" : "clint_dempsey",
      "indices" : [ 21, 35 ],
      "id_str" : "431429137",
      "id" : 431429137
    }, {
      "name" : "Tim Howard",
      "screen_name" : "TimHowardGK",
      "indices" : [ 40, 52 ],
      "id_str" : "2511477648",
      "id" : 2511477648
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ussoccer\/status\/484489509078573056\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Vm21OhxHqX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrlAo_QCMAI-djL.jpg",
      "id_str" : "484489507836669954",
      "id" : 484489507836669954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrlAo_QCMAI-djL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Vm21OhxHqX"
    } ],
    "hashtags" : [ {
      "text" : "USMNT",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484516009064153089",
  "text" : "RT @ussoccer: #USMNT @Clint_Dempsey and @TimHowardGK got a call from President Obama earlier today in S\u00E3o Paulo. http:\/\/t.co\/Vm21OhxHqX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clint Dempsey",
        "screen_name" : "clint_dempsey",
        "indices" : [ 7, 21 ],
        "id_str" : "431429137",
        "id" : 431429137
      }, {
        "name" : "Tim Howard",
        "screen_name" : "TimHowardGK",
        "indices" : [ 26, 38 ],
        "id_str" : "2511477648",
        "id" : 2511477648
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ussoccer\/status\/484489509078573056\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Vm21OhxHqX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrlAo_QCMAI-djL.jpg",
        "id_str" : "484489507836669954",
        "id" : 484489507836669954,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrlAo_QCMAI-djL.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Vm21OhxHqX"
      } ],
      "hashtags" : [ {
        "text" : "USMNT",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484489509078573056",
    "text" : "#USMNT @Clint_Dempsey and @TimHowardGK got a call from President Obama earlier today in S\u00E3o Paulo. http:\/\/t.co\/Vm21OhxHqX",
    "id" : 484489509078573056,
    "created_at" : "2014-07-03 00:11:15 +0000",
    "user" : {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "protected" : false,
      "id_str" : "7563792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704355346622586884\/oGZUl3xk_normal.jpg",
      "id" : 7563792,
      "verified" : true
    }
  },
  "id" : 484516009064153089,
  "created_at" : "2014-07-03 01:56:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Howard",
      "screen_name" : "TimHowardGK",
      "indices" : [ 80, 92 ],
      "id_str" : "2511477648",
      "id" : 2511477648
    }, {
      "name" : "Clint Dempsey",
      "screen_name" : "clint_dempsey",
      "indices" : [ 99, 113 ],
      "id_str" : "431429137",
      "id" : 431429137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USMNT",
      "indices" : [ 138, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/SrKJBob25o",
      "expanded_url" : "http:\/\/youtu.be\/jNK93KpHaJg",
      "display_url" : "youtu.be\/jNK93KpHaJg"
    } ]
  },
  "geo" : { },
  "id_str" : "484469024219496448",
  "text" : "\"Man, I just wanted to call and say you guys did us proud!\" \u2014President Obama to @TimHowardGK &amp; @Clint_Dempsey: http:\/\/t.co\/SrKJBob25o #USMNT",
  "id" : 484469024219496448,
  "created_at" : "2014-07-02 22:49:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Howard",
      "screen_name" : "TimHowardGK",
      "indices" : [ 22, 34 ],
      "id_str" : "2511477648",
      "id" : 2511477648
    }, {
      "name" : "Clint Dempsey",
      "screen_name" : "clint_dempsey",
      "indices" : [ 39, 53 ],
      "id_str" : "431429137",
      "id" : 431429137
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 70, 79 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/484463144736423936\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1Dl8qh9Vtg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrkoqbHCAAETicP.jpg",
      "id_str" : "484463144215904257",
      "id" : 484463144215904257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrkoqbHCAAETicP.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1Dl8qh9Vtg"
    } ],
    "hashtags" : [ {
      "text" : "WorldCup",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484463144736423936",
  "text" : "President Obama calls @TimHowardGK and @Clint_Dempsey to congratulate @USSoccer on a great #WorldCup run. http:\/\/t.co\/1Dl8qh9Vtg",
  "id" : 484463144736423936,
  "created_at" : "2014-07-02 22:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "Tim Howard",
      "screen_name" : "TimHowardGK",
      "indices" : [ 57, 69 ],
      "id_str" : "2511477648",
      "id" : 2511477648
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 125, 134 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484448833309786114",
  "text" : "RT @DeptofDefense: From 1 SecDef to another: Hagel calls @timhowardgk to say thanks for defending USA. We (USA) are proud of @ussoccer! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Howard",
        "screen_name" : "TimHowardGK",
        "indices" : [ 38, 50 ],
        "id_str" : "2511477648",
        "id" : 2511477648
      }, {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 106, 115 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DeptofDefense\/status\/484438026152460288\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/M8nsYdlXFn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrkR0WJCYAA5VHv.jpg",
        "id_str" : "484438025913393152",
        "id" : 484438025913393152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrkR0WJCYAA5VHv.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/M8nsYdlXFn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484438026152460288",
    "text" : "From 1 SecDef to another: Hagel calls @timhowardgk to say thanks for defending USA. We (USA) are proud of @ussoccer! http:\/\/t.co\/M8nsYdlXFn",
    "id" : 484438026152460288,
    "created_at" : "2014-07-02 20:46:40 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 484448833309786114,
  "created_at" : "2014-07-02 21:29:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484448447765176320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/aCgp71BYsE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrkbS8jCcAEldWW.jpg",
      "id_str" : "484448447223721985",
      "id" : 484448447223721985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrkbS8jCcAEldWW.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aCgp71BYsE"
    } ],
    "hashtags" : [ {
      "text" : "CRA50",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iqm2uuiGY9",
      "expanded_url" : "http:\/\/go.wh.gov\/7YiAtZ",
      "display_url" : "go.wh.gov\/7YiAtZ"
    } ]
  },
  "geo" : { },
  "id_str" : "484448447765176320",
  "text" : "From the archives: President Obama speaks at the LBJ Library on the Civil Rights Act \u2192 http:\/\/t.co\/iqm2uuiGY9 #CRA50 http:\/\/t.co\/aCgp71BYsE",
  "id" : 484448447765176320,
  "created_at" : "2014-07-02 21:28:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arthur",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484440890912808960",
  "text" : "RT @PressSec: Potus got briefing on TS #Arthur this am. FEMA deployed assets to help prepare. If youre in storm path, follow local official\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Arthur",
        "indices" : [ 25, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484434688317358081",
    "text" : "Potus got briefing on TS #Arthur this am. FEMA deployed assets to help prepare. If youre in storm path, follow local officials instructions.",
    "id" : 484434688317358081,
    "created_at" : "2014-07-02 20:33:24 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 484440890912808960,
  "created_at" : "2014-07-02 20:58:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484432704281518080",
  "text" : "\"The Civil Rights Act brought us closer to making real the declaration at the heart of our founding\u2014that we are all created equal.\" \u2014Obama",
  "id" : 484432704281518080,
  "created_at" : "2014-07-02 20:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 94, 107 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/14usyCBoqJ",
      "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/being-biden-vol-16-50-years-later",
      "display_url" : "soundcloud.com\/whitehouse\/bei\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484422682226987009",
  "text" : "RT @VP: Don't miss the VP sharing his thoughts on the Civil Rights Act &amp; this moment with @RepJohnLewis \u2192 https:\/\/t.co\/14usyCBoqJ #BeingBid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 86, 99 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 126, 137 ]
      }, {
        "text" : "CRA50",
        "indices" : [ 138, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/14usyCBoqJ",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/being-biden-vol-16-50-years-later",
        "display_url" : "soundcloud.com\/whitehouse\/bei\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484420746048176129",
    "text" : "Don't miss the VP sharing his thoughts on the Civil Rights Act &amp; this moment with @RepJohnLewis \u2192 https:\/\/t.co\/14usyCBoqJ #BeingBiden #CRA50",
    "id" : 484420746048176129,
    "created_at" : "2014-07-02 19:38:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 484422682226987009,
  "created_at" : "2014-07-02 19:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484420025659695104\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/mcMr0RGABd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrkBcj2CAAA1qZC.png",
      "id_str" : "484420025088868352",
      "id" : 484420025088868352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrkBcj2CAAA1qZC.png",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 961
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 961
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mcMr0RGABd"
    } ],
    "hashtags" : [ {
      "text" : "CRA50",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484420025659695104",
  "text" : "\"It transformed the concepts of justice, equality, and democracy for generations to come.\" \u2014Obama #CRA50 http:\/\/t.co\/mcMr0RGABd",
  "id" : 484420025659695104,
  "created_at" : "2014-07-02 19:35:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484399874004512768\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HDoGzwHe7i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrjvHk3CcAASnPo.jpg",
      "id_str" : "484399873374973952",
      "id" : 484399873374973952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrjvHk3CcAASnPo.jpg",
      "sizes" : [ {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/HDoGzwHe7i"
    } ],
    "hashtags" : [ {
      "text" : "CRA50",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484399874004512768",
  "text" : "\u201COur rights, our freedoms\u2014they are not given. They must be won.\u201D \u2014President Obama on the Civil Rights Act #CRA50 http:\/\/t.co\/HDoGzwHe7i",
  "id" : 484399874004512768,
  "created_at" : "2014-07-02 18:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484386669119148034\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/DNM7kNgSmP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrjjG8UCUAAWwY4.jpg",
      "id_str" : "484386668351213568",
      "id" : 484386668351213568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrjjG8UCUAAWwY4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DNM7kNgSmP"
    } ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 33, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484386669119148034",
  "text" : "It's time for every state to put #PeopleOverPolitics &amp; help more Americans access health coverage through Medicaid. http:\/\/t.co\/DNM7kNgSmP",
  "id" : 484386669119148034,
  "created_at" : "2014-07-02 17:22:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 39, 48 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/bVGgSXC6Ki",
      "expanded_url" : "http:\/\/on.doi.gov\/1sXjKoQ",
      "display_url" : "on.doi.gov\/1sXjKoQ"
    } ]
  },
  "geo" : { },
  "id_str" : "484369355959177216",
  "text" : "RT @Utech44: Great #ActOnClimate news: @Interior is opening up nearly 80,000 acres in MD for wind energy \u2192 http:\/\/t.co\/bVGgSXC6Ki http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 26, 35 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/484356440547930112\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/j4MuPUSWuT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrjHnayCYAI7Uex.jpg",
        "id_str" : "484356439960346626",
        "id" : 484356439960346626,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrjHnayCYAI7Uex.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/j4MuPUSWuT"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 6, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/bVGgSXC6Ki",
        "expanded_url" : "http:\/\/on.doi.gov\/1sXjKoQ",
        "display_url" : "on.doi.gov\/1sXjKoQ"
      } ]
    },
    "geo" : { },
    "id_str" : "484368994724757505",
    "text" : "Great #ActOnClimate news: @Interior is opening up nearly 80,000 acres in MD for wind energy \u2192 http:\/\/t.co\/bVGgSXC6Ki http:\/\/t.co\/j4MuPUSWuT",
    "id" : 484368994724757505,
    "created_at" : "2014-07-02 16:12:22 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 484369355959177216,
  "created_at" : "2014-07-02 16:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484365782399606784",
  "text" : "RT @DrBiden: \"Together, we must do more to ensure that all girls &amp; boys have the opportunities everyone deserves.\" - Dr. Biden http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/484362565339066368\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/6toRoqf1Dp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrjNLfMCQAAPD4d.jpg",
        "id_str" : "484362557176561664",
        "id" : 484362557176561664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrjNLfMCQAAPD4d.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6toRoqf1Dp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484362565339066368",
    "text" : "\"Together, we must do more to ensure that all girls &amp; boys have the opportunities everyone deserves.\" - Dr. Biden http:\/\/t.co\/6toRoqf1Dp",
    "id" : 484362565339066368,
    "created_at" : "2014-07-02 15:46:49 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 484365782399606784,
  "created_at" : "2014-07-02 15:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484357672444370945\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/UIvZlLiI7C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrjIvH6CUAIpH1q.jpg",
      "id_str" : "484357671844204546",
      "id" : 484357671844204546,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrjIvH6CUAIpH1q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UIvZlLiI7C"
    } ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 25, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484357672444370945",
  "text" : "FACT: If every state put #PeopleOverPolitics &amp; expanded Medicaid coverage, we'd create 183,800 more jobs next year: http:\/\/t.co\/UIvZlLiI7C",
  "id" : 484357672444370945,
  "created_at" : "2014-07-02 15:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 49, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QfqmftW7fk",
      "expanded_url" : "http:\/\/go.wh.gov\/zG9GQY",
      "display_url" : "go.wh.gov\/zG9GQY"
    } ]
  },
  "geo" : { },
  "id_str" : "484350677913980929",
  "text" : "24 states have not expanded Medicaid through the #ACA.\nIf they don't, 5.7 million will go without coverage in 2016 \u2192 http:\/\/t.co\/QfqmftW7fk",
  "id" : 484350677913980929,
  "created_at" : "2014-07-02 14:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/484340425088831488\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KWoQPm9Mc3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bri5DL-CAAINSNb.jpg",
      "id_str" : "484340424346042370",
      "id" : 484340424346042370,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bri5DL-CAAINSNb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KWoQPm9Mc3"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 42, 46 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 94, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/QfqmftW7fk",
      "expanded_url" : "http:\/\/go.wh.gov\/zG9GQY",
      "display_url" : "go.wh.gov\/zG9GQY"
    } ]
  },
  "geo" : { },
  "id_str" : "484340425088831488",
  "text" : "Here's how expanding Medicaid through the #ACA would help your state \u2192 http:\/\/t.co\/QfqmftW7fk #PeopleOverPolitics http:\/\/t.co\/KWoQPm9Mc3",
  "id" : 484340425088831488,
  "created_at" : "2014-07-02 14:18:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 14, 23 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BelieveIt",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484118070068539392",
  "text" : "Very proud of @USSoccer. We'll win it all sooner than the world thinks. #BelieveIt -bo",
  "id" : 484118070068539392,
  "created_at" : "2014-07-01 23:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsWinThisThing",
      "indices" : [ 26, 43 ]
    }, {
      "text" : "USA",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/lzWxezTyno",
      "expanded_url" : "https:\/\/vine.co\/v\/MFLJQ97UXOY",
      "display_url" : "vine.co\/v\/MFLJQ97UXOY"
    } ]
  },
  "geo" : { },
  "id_str" : "484084550281465856",
  "text" : "President Obama believes. #LetsWinThisThing #USA https:\/\/t.co\/lzWxezTyno",
  "id" : 484084550281465856,
  "created_at" : "2014-07-01 21:22:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 62, 71 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAvsBEL",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "IBelieveThatWeWillWin",
      "indices" : [ 96, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484070902922219520",
  "text" : "RT @VP: One Nation. One Team. Excited to continue cheering on @ussoccer today. #USAvsBEL #USMNT #IBelieveThatWeWillWin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 54, 63 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAvsBEL",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "USMNT",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "IBelieveThatWeWillWin",
        "indices" : [ 88, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484060954981040128",
    "text" : "One Nation. One Team. Excited to continue cheering on @ussoccer today. #USAvsBEL #USMNT #IBelieveThatWeWillWin",
    "id" : 484060954981040128,
    "created_at" : "2014-07-01 19:48:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 484070902922219520,
  "created_at" : "2014-07-01 20:27:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 38, 47 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/484065017827188736\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/8wndLhg2yt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bre-kX0CEAA6w3v.jpg",
      "id_str" : "484065017042440192",
      "id" : 484065017042440192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bre-kX0CEAA6w3v.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/8wndLhg2yt"
    } ],
    "hashtags" : [ {
      "text" : "USAvsBEL",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "USMNT",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484068923374317569",
  "text" : "RT @FLOTUS: FLOTUS believes. Let\u2019s go @USSoccer! #USAvsBEL #USMNT http:\/\/t.co\/8wndLhg2yt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 26, 35 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/484065017827188736\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/8wndLhg2yt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bre-kX0CEAA6w3v.jpg",
        "id_str" : "484065017042440192",
        "id" : 484065017042440192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bre-kX0CEAA6w3v.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/8wndLhg2yt"
      } ],
      "hashtags" : [ {
        "text" : "USAvsBEL",
        "indices" : [ 37, 46 ]
      }, {
        "text" : "USMNT",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484065017827188736",
    "text" : "FLOTUS believes. Let\u2019s go @USSoccer! #USAvsBEL #USMNT http:\/\/t.co\/8wndLhg2yt",
    "id" : 484065017827188736,
    "created_at" : "2014-07-01 20:04:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 484068923374317569,
  "created_at" : "2014-07-01 20:19:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 94, 103 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IBelieve",
      "indices" : [ 105, 114 ]
    }, {
      "text" : "USA",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484061723390148608",
  "text" : "In America, we don't settle. We out-hustle the competition. That's who we are. Let's do this, @USSoccer! #IBelieve #USA -bo",
  "id" : 484061723390148608,
  "created_at" : "2014-07-01 19:51:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 96, 103 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484048854577594368",
  "text" : "RT @vj44: Congratulations to Admiral Michelle Howard - the first woman to achieve four stars in @USNavy history.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 86, 93 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484048321246674944",
    "text" : "Congratulations to Admiral Michelle Howard - the first woman to achieve four stars in @USNavy history.",
    "id" : 484048321246674944,
    "created_at" : "2014-07-01 18:58:07 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 484048854577594368,
  "created_at" : "2014-07-01 19:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484044322820857857",
  "text" : "RT @WHLive: Obama: \"If the American people put pressure on this town to actually get something done\u2026we can grow our economy.\" #OpportunityF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 114, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484044175097470976",
    "text" : "Obama: \"If the American people put pressure on this town to actually get something done\u2026we can grow our economy.\" #OpportunityForAll",
    "id" : 484044175097470976,
    "created_at" : "2014-07-01 18:41:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 484044322820857857,
  "created_at" : "2014-07-01 18:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/484043470118850561\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/zShEEXcEzg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Breq-I7CUAAhW0X.jpg",
      "id_str" : "484043469489328128",
      "id" : 484043469489328128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Breq-I7CUAAhW0X.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zShEEXcEzg"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484043470118850561",
  "text" : "\"Let\u2019s make sure no American who works full-time ever has to live in poverty.\" \u2014President Obama #RaiseTheWage http:\/\/t.co\/zShEEXcEzg",
  "id" : 484043470118850561,
  "created_at" : "2014-07-01 18:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484043095542358016\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/fScb4PURdW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BreqoSCCcAAo0vI.jpg",
      "id_str" : "484043093977493504",
      "id" : 484043093977493504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BreqoSCCcAAo0vI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fScb4PURdW"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484043095542358016",
  "text" : "\"Let\u2019s make sure women earn pay equal to their efforts.\" \u2014President Obama #EqualPay http:\/\/t.co\/fScb4PURdW",
  "id" : 484043095542358016,
  "created_at" : "2014-07-01 18:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ccgeYlGmMC",
      "expanded_url" : "http:\/\/wh.gov\/year-of-action",
      "display_url" : "wh.gov\/year-of-action"
    } ]
  },
  "geo" : { },
  "id_str" : "484041606723825666",
  "text" : "\"Middle-class families can\u2019t wait for Congress to do these things, and I won\u2019t.\" \u2014Obama: http:\/\/t.co\/ccgeYlGmMC #RebuildAmerica",
  "id" : 484041606723825666,
  "created_at" : "2014-07-01 18:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484039652320772096",
  "text" : "\"If this Congress does not act by the end of the summer, the Highway Trust Fund will run out.  \" \u2014President Obama #RebuildAmerica",
  "id" : 484039652320772096,
  "created_at" : "2014-07-01 18:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/EYtnnZpxN6",
      "expanded_url" : "http:\/\/go.wh.gov\/JoiZuf",
      "display_url" : "go.wh.gov\/JoiZuf"
    } ]
  },
  "geo" : { },
  "id_str" : "484039138573053952",
  "text" : "Watch live: President Obama speaks on the economy and why it's time to rebuild our infrastructure \u2192 http:\/\/t.co\/EYtnnZpxN6 #RebuildAmerica",
  "id" : 484039138573053952,
  "created_at" : "2014-07-01 18:21:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484032700475789313\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/GNAmZOoMV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrehLO7CYAAd5fl.jpg",
      "id_str" : "484032699321966592",
      "id" : 484032699321966592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrehLO7CYAAd5fl.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GNAmZOoMV4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/hJI7PH1Hny",
      "expanded_url" : "http:\/\/go.wh.gov\/7GA4wL",
      "display_url" : "go.wh.gov\/7GA4wL"
    } ]
  },
  "geo" : { },
  "id_str" : "484032700475789313",
  "text" : "\"43% of Americans now live in states where you\u2019re free to marry who you love.\" \u2014Obama: http:\/\/t.co\/hJI7PH1Hny http:\/\/t.co\/GNAmZOoMV4",
  "id" : 484032700475789313,
  "created_at" : "2014-07-01 17:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/484011170647392256\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BKZQQYteJJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BreNmDbCQAAlOT_.jpg",
      "id_str" : "484011169858863104",
      "id" : 484011169858863104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BreNmDbCQAAlOT_.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BKZQQYteJJ"
    } ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/K75k22iO6r",
      "expanded_url" : "http:\/\/go.wh.gov\/vwBykT",
      "display_url" : "go.wh.gov\/vwBykT"
    } ]
  },
  "geo" : { },
  "id_str" : "484011170647392256",
  "text" : "Women\u2014not their bosses\u2014should be able to make their own health care decisions \u2192 http:\/\/t.co\/K75k22iO6r #HobbyLobby http:\/\/t.co\/BKZQQYteJJ",
  "id" : 484011170647392256,
  "created_at" : "2014-07-01 16:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484002164550156289",
  "text" : "RT @FLOTUS: FLOTUS: \"Higher education is no longer just for kids in the top quarter or the top half of the class. College is for everyone.\"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484001096986533888",
    "text" : "FLOTUS: \"Higher education is no longer just for kids in the top quarter or the top half of the class. College is for everyone.\" #ReachHigher",
    "id" : 484001096986533888,
    "created_at" : "2014-07-01 15:50:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 484002164550156289,
  "created_at" : "2014-07-01 15:54:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484001168558145536",
  "text" : "RT @FLOTUS: \"The goal is to inspire every young person in this country to complete their education beyond high school.\" \u2014FLOTUS #ReachHigher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484000203381673984",
    "text" : "\"The goal is to inspire every young person in this country to complete their education beyond high school.\" \u2014FLOTUS #ReachHigher",
    "id" : 484000203381673984,
    "created_at" : "2014-07-01 15:46:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 484001168558145536,
  "created_at" : "2014-07-01 15:50:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "NBC Politics",
      "screen_name" : "NBCPolitics",
      "indices" : [ 21, 33 ],
      "id_str" : "11856032",
      "id" : 11856032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483984260341448704",
  "text" : "RT @pfeiffer44: From @NBCPolitics: No reasonable person can say that immigration\u2019s death -- in 2013 and 2014 -- is anyone\u2019s fault but House\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBC Politics",
        "screen_name" : "NBCPolitics",
        "indices" : [ 5, 17 ],
        "id_str" : "11856032",
        "id" : 11856032
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483980971671572481",
    "text" : "From @NBCPolitics: No reasonable person can say that immigration\u2019s death -- in 2013 and 2014 -- is anyone\u2019s fault but House Republicans.",
    "id" : 483980971671572481,
    "created_at" : "2014-07-01 14:30:30 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 483984260341448704,
  "created_at" : "2014-07-01 14:43:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 3, 12 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AreYouReady",
      "indices" : [ 14, 26 ]
    }, {
      "text" : "USA",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "BEL",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483982277077401600",
  "text" : "RT @ussoccer: #AreYouReady: #USA v #BEL pump up video! Get psyched this morning! (Just about 6 hrs until kickoff in Salvador) https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AreYouReady",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "USA",
        "indices" : [ 14, 18 ]
      }, {
        "text" : "BEL",
        "indices" : [ 21, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/bYIMQlWyC5",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=QC9FwLgDwwo",
        "display_url" : "youtube.com\/watch?v=QC9FwL\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483971961379233793",
    "text" : "#AreYouReady: #USA v #BEL pump up video! Get psyched this morning! (Just about 6 hrs until kickoff in Salvador) https:\/\/t.co\/bYIMQlWyC5",
    "id" : 483971961379233793,
    "created_at" : "2014-07-01 13:54:42 +0000",
    "user" : {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "protected" : false,
      "id_str" : "7563792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704355346622586884\/oGZUl3xk_normal.jpg",
      "id" : 7563792,
      "verified" : true
    }
  },
  "id" : 483982277077401600,
  "created_at" : "2014-07-01 14:35:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]