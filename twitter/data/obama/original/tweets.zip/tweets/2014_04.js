Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461640199299424256\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/RHuqv0Lvxr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmgTUKUIYAApa4q.jpg",
      "id_str" : "461640198892576768",
      "id" : 461640198892576768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmgTUKUIYAApa4q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RHuqv0Lvxr"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461640199299424256",
  "text" : "#1010Means higher wages for 28 million Americans.\nIt's time for Congress to #RaiseTheWage. http:\/\/t.co\/RHuqv0Lvxr",
  "id" : 461640199299424256,
  "created_at" : "2014-04-30 22:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nuriddin Ziyadinov",
      "screen_name" : "Nuriddinz",
      "indices" : [ 3, 13 ],
      "id_str" : "1069949864",
      "id" : 1069949864
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461593936776400897",
  "text" : "RT @Nuriddinz: #1010Means helping us, college students, who work to support families that are struggling with their kids in colleges",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1010Means",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461591106958802944",
    "text" : "#1010Means helping us, college students, who work to support families that are struggling with their kids in colleges",
    "id" : 461591106958802944,
    "created_at" : "2014-04-30 19:41:10 +0000",
    "user" : {
      "name" : "Nuriddin Ziyadinov",
      "screen_name" : "Nuriddinz",
      "protected" : false,
      "id_str" : "1069949864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735337313643941888\/jzSKzq_W_normal.jpg",
      "id" : 1069949864,
      "verified" : false
    }
  },
  "id" : 461593936776400897,
  "created_at" : "2014-04-30 19:52:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep.George Miller",
      "screen_name" : "askgeorge",
      "indices" : [ 3, 13 ],
      "id_str" : "7356562",
      "id" : 7356562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461588768030744577",
  "text" : "RT @askgeorge: #1010Means more than 2.1 million Californians would have seen higher wages if Congress voted to #RaiseTheWage. http:\/\/t.co\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1010Means",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/bGC7jU50mZ",
        "expanded_url" : "http:\/\/go.wh.gov\/87ofCq",
        "display_url" : "go.wh.gov\/87ofCq"
      } ]
    },
    "geo" : { },
    "id_str" : "461586519208525824",
    "text" : "#1010Means more than 2.1 million Californians would have seen higher wages if Congress voted to #RaiseTheWage. http:\/\/t.co\/bGC7jU50mZ",
    "id" : 461586519208525824,
    "created_at" : "2014-04-30 19:22:56 +0000",
    "user" : {
      "name" : "Rep.George Miller",
      "screen_name" : "askgeorge",
      "protected" : false,
      "id_str" : "7356562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459356640794275840\/X0fOERp3_normal.jpeg",
      "id" : 7356562,
      "verified" : true
    }
  },
  "id" : 461588768030744577,
  "created_at" : "2014-04-30 19:31:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 21, 31 ]
    }, {
      "text" : "RaisedTheWage",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461585718150983680",
  "text" : "RT @GovernorOMalley: #1010Means dignity to every family that works hard and plays by the rules. That's why we #RaisedTheWage in Maryland.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1010Means",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "RaisedTheWage",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461578914947944449",
    "text" : "#1010Means dignity to every family that works hard and plays by the rules. That's why we #RaisedTheWage in Maryland.",
    "id" : 461578914947944449,
    "created_at" : "2014-04-30 18:52:43 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 461585718150983680,
  "created_at" : "2014-04-30 19:19:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461583495308267520",
  "text" : "President Obama: \"Use the hashtag #1010Means: Let them know how raising the minimum wage would help you or your family or someone you know.\"",
  "id" : 461583495308267520,
  "created_at" : "2014-04-30 19:10:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461582884730834944",
  "text" : "Obama: \"This is a very simple issue: Either you're in favor of raising wages for hardworking Americans, or you're not.\" #1010Means",
  "id" : 461582884730834944,
  "created_at" : "2014-04-30 19:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461582490738905088",
  "text" : "\"In the wealthiest nation on Earth, no one who works full-time should ever have to raise a family in poverty.\" \u2014President Obama #1010Means",
  "id" : 461582490738905088,
  "created_at" : "2014-04-30 19:06:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "1010Means",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461582301605154816",
  "text" : "\"About 3 in 4 Americans support raising the minimum wage.\" \u2014President Obama #RaiseTheWage #1010Means",
  "id" : 461582301605154816,
  "created_at" : "2014-04-30 19:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461581971819593729\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yQY5Oxee7G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmfeW3dCEAAQo44.jpg",
      "id_str" : "461581971252973568",
      "id" : 461581971252973568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmfeW3dCEAAQo44.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yQY5Oxee7G"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461581971819593729",
  "text" : "\"Because Republicans in Congress said 'no,' they\u2019ll have to wait for the raise they deserve.\" \u2014Obama #1010Means http:\/\/t.co\/yQY5Oxee7G",
  "id" : 461581971819593729,
  "created_at" : "2014-04-30 19:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461581645318217728\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9qswsMmklN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmfeD3eCEAAMRzW.png",
      "id_str" : "461581644839653376",
      "id" : 461581644839653376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmfeD3eCEAAMRzW.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9qswsMmklN"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461581645318217728",
  "text" : "\"They said no to helping millions work their way out of poverty.\" \u2014President Obama on Senate Republicans #1010Means http:\/\/t.co\/9qswsMmklN",
  "id" : 461581645318217728,
  "created_at" : "2014-04-30 19:03:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461581524014755840",
  "text" : "\"This morning, a majority of Senators said 'yes,' but almost every Republican said 'no.'\" \u2014Obama on raising the minimum wage #1010Means",
  "id" : 461581524014755840,
  "created_at" : "2014-04-30 19:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Q7bfTSHFyt",
      "expanded_url" : "http:\/\/go.wh.gov\/erPaQa",
      "display_url" : "go.wh.gov\/erPaQa"
    } ]
  },
  "geo" : { },
  "id_str" : "461581263179366402",
  "text" : "Happening now: President Obama speaks on why it's time to raise the minimum wage \u2192 http:\/\/t.co\/Q7bfTSHFyt #1010Means",
  "id" : 461581263179366402,
  "created_at" : "2014-04-30 19:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Q7bfTSHFyt",
      "expanded_url" : "http:\/\/go.wh.gov\/erPaQa",
      "display_url" : "go.wh.gov\/erPaQa"
    } ]
  },
  "geo" : { },
  "id_str" : "461577200987545601",
  "text" : "At 3:10pm ET, President Obama speaks on why it's time to raise the minimum wage. Watch \u2192 http:\/\/t.co\/Q7bfTSHFyt #1010Means",
  "id" : 461577200987545601,
  "created_at" : "2014-04-30 18:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461561656968224768\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nwKwBaRZ2y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmfL4YOIIAAnUM3.jpg",
      "id_str" : "461561656263581696",
      "id" : 461561656263581696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmfL4YOIIAAnUM3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nwKwBaRZ2y"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461561656968224768",
  "text" : "Nearly every GOP senator just blocked raising wages for 28 million Americans.\nRT if you agree that's wrong #1010Means http:\/\/t.co\/nwKwBaRZ2y",
  "id" : 461561656968224768,
  "created_at" : "2014-04-30 17:44:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Van Hollen",
      "screen_name" : "ChrisVanHollen",
      "indices" : [ 3, 18 ],
      "id_str" : "18137749",
      "id" : 18137749
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisVanHollen\/status\/461526835214692353\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/i68OwCqPAt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmesNf8IYAA24YT.jpg",
      "id_str" : "461526834740748288",
      "id" : 461526834740748288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmesNf8IYAA24YT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i68OwCqPAt"
    } ],
    "hashtags" : [ {
      "text" : "Timefor1010",
      "indices" : [ 41, 53 ]
    }, {
      "text" : "1010means",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461548510345986048",
  "text" : "RT @ChrisVanHollen: RT if you think it's #Timefor1010! #1010means: http:\/\/t.co\/i68OwCqPAt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisVanHollen\/status\/461526835214692353\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/i68OwCqPAt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmesNf8IYAA24YT.jpg",
        "id_str" : "461526834740748288",
        "id" : 461526834740748288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmesNf8IYAA24YT.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/i68OwCqPAt"
      } ],
      "hashtags" : [ {
        "text" : "Timefor1010",
        "indices" : [ 21, 33 ]
      }, {
        "text" : "1010means",
        "indices" : [ 35, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461526835214692353",
    "text" : "RT if you think it's #Timefor1010! #1010means: http:\/\/t.co\/i68OwCqPAt",
    "id" : 461526835214692353,
    "created_at" : "2014-04-30 15:25:46 +0000",
    "user" : {
      "name" : "Chris Van Hollen",
      "screen_name" : "ChrisVanHollen",
      "protected" : false,
      "id_str" : "18137749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740184981134290948\/g6mNTvEh_normal.jpg",
      "id" : 18137749,
      "verified" : true
    }
  },
  "id" : 461548510345986048,
  "created_at" : "2014-04-30 16:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hodder",
      "screen_name" : "JeffHodder",
      "indices" : [ 3, 14 ],
      "id_str" : "534375921",
      "id" : 534375921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461540813038956545",
  "text" : "RT @JeffHodder: #1010Means That nobody who works for a living should have to live in poverty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1010Means",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461535315908657152",
    "text" : "#1010Means That nobody who works for a living should have to live in poverty",
    "id" : 461535315908657152,
    "created_at" : "2014-04-30 15:59:28 +0000",
    "user" : {
      "name" : "Jeff Hodder",
      "screen_name" : "JeffHodder",
      "protected" : false,
      "id_str" : "534375921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3375220041\/3734090fa27ddcf939119bc74df0618b_normal.png",
      "id" : 534375921,
      "verified" : false
    }
  },
  "id" : 461540813038956545,
  "created_at" : "2014-04-30 16:21:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/461532356814196736\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/KbMyraJaYp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmexO7TCUAEyU5J.png",
      "id_str" : "461532356822585345",
      "id" : 461532356822585345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmexO7TCUAEyU5J.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KbMyraJaYp"
    } ],
    "hashtags" : [ {
      "text" : "1010means",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461537610738196481",
  "text" : "RT @LaborSec: #1010means a stronger bottom line for America's businesses. http:\/\/t.co\/KbMyraJaYp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/461532356814196736\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/KbMyraJaYp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmexO7TCUAEyU5J.png",
        "id_str" : "461532356822585345",
        "id" : 461532356822585345,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmexO7TCUAEyU5J.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KbMyraJaYp"
      } ],
      "hashtags" : [ {
        "text" : "1010means",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461532356814196736",
    "text" : "#1010means a stronger bottom line for America's businesses. http:\/\/t.co\/KbMyraJaYp",
    "id" : 461532356814196736,
    "created_at" : "2014-04-30 15:47:43 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 461537610738196481,
  "created_at" : "2014-04-30 16:08:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 3, 16 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SenatorBoxer\/status\/461532059308003328\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/k1as13BlJW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmew9nACEAAHITs.jpg",
      "id_str" : "461532059316391936",
      "id" : 461532059316391936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmew9nACEAAHITs.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/k1as13BlJW"
    } ],
    "hashtags" : [ {
      "text" : "1010means",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461535696772423681",
  "text" : "RT @SenatorBoxer: #1010means lifting the wages of 15 million women &amp; their families #RaiseTheWage http:\/\/t.co\/k1as13BlJW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SenatorBoxer\/status\/461532059308003328\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/k1as13BlJW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmew9nACEAAHITs.jpg",
        "id_str" : "461532059316391936",
        "id" : 461532059316391936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmew9nACEAAHITs.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/k1as13BlJW"
      } ],
      "hashtags" : [ {
        "text" : "1010means",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 70, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461532059308003328",
    "text" : "#1010means lifting the wages of 15 million women &amp; their families #RaiseTheWage http:\/\/t.co\/k1as13BlJW",
    "id" : 461532059308003328,
    "created_at" : "2014-04-30 15:46:32 +0000",
    "user" : {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "protected" : false,
      "id_str" : "15442036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464147946934517760\/EZ8huLG8_normal.png",
      "id" : 15442036,
      "verified" : true
    }
  },
  "id" : 461535696772423681,
  "created_at" : "2014-04-30 16:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/01GhAvLDvL",
      "expanded_url" : "http:\/\/go.wh.gov\/4iQdKq",
      "display_url" : "go.wh.gov\/4iQdKq"
    } ]
  },
  "geo" : { },
  "id_str" : "461531846031859713",
  "text" : "Great news: The Hawaii Legislature just voted to raise the state minimum wage to $10.10 \u2192 http:\/\/t.co\/01GhAvLDvL #1010Means",
  "id" : 461531846031859713,
  "created_at" : "2014-04-30 15:45:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janice Hahn",
      "screen_name" : "Rep_JaniceHahn",
      "indices" : [ 3, 18 ],
      "id_str" : "339852137",
      "id" : 339852137
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Rep_JaniceHahn\/status\/461507866076000257\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/09v1wjf3c9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmea9YMCMAAmIHr.jpg",
      "id_str" : "461507866084388864",
      "id" : 461507866084388864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmea9YMCMAAmIHr.jpg",
      "sizes" : [ {
        "h" : 2000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/09v1wjf3c9"
    } ],
    "hashtags" : [ {
      "text" : "minimumwage",
      "indices" : [ 32, 44 ]
    }, {
      "text" : "1010Means",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461527872227012608",
  "text" : "RT @Rep_JaniceHahn: Raising the #minimumwage to #1010Means 3.5 million fewer Americans on food stamps. http:\/\/t.co\/09v1wjf3c9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Rep_JaniceHahn\/status\/461507866076000257\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/09v1wjf3c9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmea9YMCMAAmIHr.jpg",
        "id_str" : "461507866084388864",
        "id" : 461507866084388864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmea9YMCMAAmIHr.jpg",
        "sizes" : [ {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/09v1wjf3c9"
      } ],
      "hashtags" : [ {
        "text" : "minimumwage",
        "indices" : [ 12, 24 ]
      }, {
        "text" : "1010Means",
        "indices" : [ 28, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461507866076000257",
    "text" : "Raising the #minimumwage to #1010Means 3.5 million fewer Americans on food stamps. http:\/\/t.co\/09v1wjf3c9",
    "id" : 461507866076000257,
    "created_at" : "2014-04-30 14:10:24 +0000",
    "user" : {
      "name" : "Janice Hahn",
      "screen_name" : "Rep_JaniceHahn",
      "protected" : false,
      "id_str" : "339852137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738089249094799361\/dOp5NiBc_normal.jpg",
      "id" : 339852137,
      "verified" : true
    }
  },
  "id" : 461527872227012608,
  "created_at" : "2014-04-30 15:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461523812597907456\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/aXWmOCGoPc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmepdjaIQAASMIj.jpg",
      "id_str" : "461523812014899200",
      "id" : 461523812014899200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmepdjaIQAASMIj.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aXWmOCGoPc"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461523812597907456",
  "text" : "#1010Means millions of Americans would see higher wages\u2014particularly women who work full time. #RaiseTheWage http:\/\/t.co\/aXWmOCGoPc",
  "id" : 461523812597907456,
  "created_at" : "2014-04-30 15:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461518962283794433\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/3hKjCQKI4L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmelDPhIMAA4ZcR.png",
      "id_str" : "461518961952436224",
      "id" : 461518961952436224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmelDPhIMAA4ZcR.png",
      "sizes" : [ {
        "h" : 413,
        "resize" : "fit",
        "w" : 972
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 972
      } ],
      "display_url" : "pic.twitter.com\/3hKjCQKI4L"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461518962283794433",
  "text" : "\"I urge Republicans in Congress to follow Hawaii\u2019s lead and lift wages for 28 million Americans.\" \u2014Obama #1010Means http:\/\/t.co\/3hKjCQKI4L",
  "id" : 461518962283794433,
  "created_at" : "2014-04-30 14:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461516026883366912\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/SrgT37EuHz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmeiYXuIUAEs8ca.png",
      "id_str" : "461516026396823553",
      "id" : 461516026396823553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmeiYXuIUAEs8ca.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SrgT37EuHz"
    } ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461516026883366912",
  "text" : "#1010Means helping millions of American families lift themselves out of poverty. http:\/\/t.co\/SrgT37EuHz",
  "id" : 461516026883366912,
  "created_at" : "2014-04-30 14:42:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461511885926727680",
  "text" : "RT @NancyPelosi: #1010Means millions of Americans would see higher wages\u2014particularly women who work full time. #RaiseTheWage http:\/\/t.co\/S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/461511500675301377\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/SSFNzRVeEU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmeeQ8ICQAAYhUu.png",
        "id_str" : "461511500683689984",
        "id" : 461511500683689984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmeeQ8ICQAAYhUu.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/SSFNzRVeEU"
      } ],
      "hashtags" : [ {
        "text" : "1010Means",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461511500675301377",
    "text" : "#1010Means millions of Americans would see higher wages\u2014particularly women who work full time. #RaiseTheWage http:\/\/t.co\/SSFNzRVeEU",
    "id" : 461511500675301377,
    "created_at" : "2014-04-30 14:24:51 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 461511885926727680,
  "created_at" : "2014-04-30 14:26:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Joe Kennedy III",
      "screen_name" : "RepJoeKennedy",
      "indices" : [ 3, 17 ],
      "id_str" : "1055907624",
      "id" : 1055907624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1010Means",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "raisethewage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461510702063443968",
  "text" : "RT @RepJoeKennedy: #1010Means higher wages for over 450K workers in our Commonwealth. It\u2019s time for Congress to #raisethewage.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1010Means",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "raisethewage",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461509107242262528",
    "text" : "#1010Means higher wages for over 450K workers in our Commonwealth. It\u2019s time for Congress to #raisethewage.",
    "id" : 461509107242262528,
    "created_at" : "2014-04-30 14:15:20 +0000",
    "user" : {
      "name" : "Rep. Joe Kennedy III",
      "screen_name" : "RepJoeKennedy",
      "protected" : false,
      "id_str" : "1055907624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775775331605241856\/mWMJIZHq_normal.jpg",
      "id" : 1055907624,
      "verified" : true
    }
  },
  "id" : 461510702063443968,
  "created_at" : "2014-04-30 14:21:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461508091310530560\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/0ylPWXDLoZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmebKdNCcAMFZR-.jpg",
      "id_str" : "461508090769076227",
      "id" : 461508090769076227,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmebKdNCcAMFZR-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0ylPWXDLoZ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 65, 78 ]
    }, {
      "text" : "1010Means",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461508091310530560",
  "text" : "28 million Americans would see higher wages if Congress votes to #RaiseTheWage.\nShare what #1010Means to you. http:\/\/t.co\/0ylPWXDLoZ",
  "id" : 461508091310530560,
  "created_at" : "2014-04-30 14:11:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Carell",
      "screen_name" : "SteveCarell",
      "indices" : [ 29, 41 ],
      "id_str" : "500042487",
      "id" : 500042487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/cuXhp0ynFu",
      "expanded_url" : "http:\/\/youtu.be\/xLdElcv5qqc",
      "display_url" : "youtu.be\/xLdElcv5qqc"
    } ]
  },
  "geo" : { },
  "id_str" : "461499331108175874",
  "text" : "\"It's a crime. It's wrong.\" \u2014@SteveCarell on why it's time to put an end to sexual assault: http:\/\/t.co\/cuXhp0ynFu #1is2Many",
  "id" : 461499331108175874,
  "created_at" : "2014-04-30 13:36:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/461292555511267328\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uh42A83ULu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmbXIoECUAA1RC0.jpg",
      "id_str" : "461292555045326848",
      "id" : 461292555045326848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmbXIoECUAA1RC0.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 991
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 991
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uh42A83ULu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461292555511267328",
  "text" : "\"These veterans are now in their 90's. They are an inspiration to us all.\" \u2014Obama on American and Filipino WWII vets http:\/\/t.co\/uh42A83ULu",
  "id" : 461292555511267328,
  "created_at" : "2014-04-29 23:54:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461288598843953152",
  "text" : "RT @vj44: See what people are saying abt today's announcements on new steps to protect students from sexual assault #1is2Many http:\/\/t.co\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/bFUXn4Cl1j",
        "expanded_url" : "http:\/\/goo.gl\/DWMNsf",
        "display_url" : "goo.gl\/DWMNsf"
      } ]
    },
    "geo" : { },
    "id_str" : "461288372942553088",
    "text" : "See what people are saying abt today's announcements on new steps to protect students from sexual assault #1is2Many http:\/\/t.co\/bFUXn4Cl1j",
    "id" : 461288372942553088,
    "created_at" : "2014-04-29 23:38:13 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 461288598843953152,
  "created_at" : "2014-04-29 23:39:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Htznt36nlL",
      "expanded_url" : "http:\/\/youtu.be\/VAL7wiAnrlw",
      "display_url" : "youtu.be\/VAL7wiAnrlw"
    } ]
  },
  "geo" : { },
  "id_str" : "461256064647069696",
  "text" : "RT @USDOL: FACT: 57% of small biz owners support raising the federal minimum wage.Take it from these guys: http:\/\/t.co\/Htznt36nlL #RaiseThe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 119, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Htznt36nlL",
        "expanded_url" : "http:\/\/youtu.be\/VAL7wiAnrlw",
        "display_url" : "youtu.be\/VAL7wiAnrlw"
      } ]
    },
    "geo" : { },
    "id_str" : "461249392855777281",
    "text" : "FACT: 57% of small biz owners support raising the federal minimum wage.Take it from these guys: http:\/\/t.co\/Htznt36nlL #RaiseTheWage",
    "id" : 461249392855777281,
    "created_at" : "2014-04-29 21:03:19 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 461256064647069696,
  "created_at" : "2014-04-29 21:29:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461249140081844224",
  "text" : "RT @LaborSec: Businesses need more customers who can afford their goods &amp; services. Hear from biz owners who say, \"#RaiseTheWage\": http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/fzYFJ8rmGr",
        "expanded_url" : "http:\/\/youtu.be\/VAL7wiAnrlw",
        "display_url" : "youtu.be\/VAL7wiAnrlw"
      } ]
    },
    "geo" : { },
    "id_str" : "461201991730225152",
    "text" : "Businesses need more customers who can afford their goods &amp; services. Hear from biz owners who say, \"#RaiseTheWage\": http:\/\/t.co\/fzYFJ8rmGr",
    "id" : 461201991730225152,
    "created_at" : "2014-04-29 17:54:58 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 461249140081844224,
  "created_at" : "2014-04-29 21:02:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/461241264180977664\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7JchwWmVkM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmaofGuCYAA2aw0.png",
      "id_str" : "461241264185171968",
      "id" : 461241264185171968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmaofGuCYAA2aw0.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7JchwWmVkM"
    } ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461246286625112064",
  "text" : "RT @VP: \"We need to send a message to victims everywhere -- we\u2019re here for you...you\u2019re not alone.\" \u2013 VP #1is2Many http:\/\/t.co\/7JchwWmVkM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/461241264180977664\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/7JchwWmVkM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmaofGuCYAA2aw0.png",
        "id_str" : "461241264185171968",
        "id" : 461241264185171968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmaofGuCYAA2aw0.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7JchwWmVkM"
      } ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461241264180977664",
    "text" : "\"We need to send a message to victims everywhere -- we\u2019re here for you...you\u2019re not alone.\" \u2013 VP #1is2Many http:\/\/t.co\/7JchwWmVkM",
    "id" : 461241264180977664,
    "created_at" : "2014-04-29 20:31:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 461246286625112064,
  "created_at" : "2014-04-29 20:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/A6wQSZSRyU",
      "expanded_url" : "http:\/\/notalone.gsa.gov\/",
      "display_url" : "notalone.gsa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "461241799164829696",
  "text" : "RT @NancyPelosi: 1 in 5 college women is sexually assaulted. Take a stand, because #1is2Many. Learn more: http:\/\/t.co\/A6wQSZSRyU http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/A6wQSZSRyU",
        "expanded_url" : "http:\/\/notalone.gsa.gov\/",
        "display_url" : "notalone.gsa.gov"
      }, {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/9aW0UInAPT",
        "expanded_url" : "http:\/\/goo.gl\/Q5O8ep",
        "display_url" : "goo.gl\/Q5O8ep"
      } ]
    },
    "geo" : { },
    "id_str" : "461236702695399425",
    "text" : "1 in 5 college women is sexually assaulted. Take a stand, because #1is2Many. Learn more: http:\/\/t.co\/A6wQSZSRyU http:\/\/t.co\/9aW0UInAPT",
    "id" : 461236702695399425,
    "created_at" : "2014-04-29 20:12:53 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 461241799164829696,
  "created_at" : "2014-04-29 20:33:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/wmeWSURu5r",
      "expanded_url" : "http:\/\/youtu.be\/xLdElcv5qqc",
      "display_url" : "youtu.be\/xLdElcv5qqc"
    } ]
  },
  "geo" : { },
  "id_str" : "461228591041093635",
  "text" : "\"It's up to all of us to put an end to sexual assault. And that starts with you.\" \u2014President Obama: http:\/\/t.co\/wmeWSURu5r #1is2Many",
  "id" : 461228591041093635,
  "created_at" : "2014-04-29 19:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "indices" : [ 44, 53 ],
      "id_str" : "262388975",
      "id" : 262388975
    }, {
      "name" : "Seth Meyers",
      "screen_name" : "sethmeyers",
      "indices" : [ 60, 71 ],
      "id_str" : "44039298",
      "id" : 44039298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 132, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/wmeWSURu5r",
      "expanded_url" : "http:\/\/youtu.be\/xLdElcv5qqc",
      "display_url" : "youtu.be\/xLdElcv5qqc"
    } ]
  },
  "geo" : { },
  "id_str" : "461222515843411968",
  "text" : "POTUS, @VP, Daniel Craig, Benicio Del Toro, @DuleHill &amp; @SethMeyers on putting an end to sexual assault: http:\/\/t.co\/wmeWSURu5r #1is2Many",
  "id" : 461222515843411968,
  "created_at" : "2014-04-29 19:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 6, 9 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/2P4cqVrQZA",
      "expanded_url" : "http:\/\/go.wh.gov\/xU4JLm",
      "display_url" : "go.wh.gov\/xU4JLm"
    } ]
  },
  "geo" : { },
  "id_str" : "461209950992498688",
  "text" : "Watch @VP Biden speak on new steps we're taking to help prevent campus sexual assault at 2:30pm ET \u2192 http:\/\/t.co\/2P4cqVrQZA #1is2Many",
  "id" : 461209950992498688,
  "created_at" : "2014-04-29 18:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461193943934586881",
  "text" : "RT @GinaEPA: Today\u2019s SCOTUS decision on Cross-State Air Pollution Rule is a big win for nation\u2019s public health &amp; proud day for the agency #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 129, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461180489995673600",
    "text" : "Today\u2019s SCOTUS decision on Cross-State Air Pollution Rule is a big win for nation\u2019s public health &amp; proud day for the agency #ActOnClimate",
    "id" : 461180489995673600,
    "created_at" : "2014-04-29 16:29:31 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 461193943934586881,
  "created_at" : "2014-04-29 17:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Wasserman Schultz",
      "screen_name" : "DWStweets",
      "indices" : [ 3, 13 ],
      "id_str" : "115979444",
      "id" : 115979444
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 25, 36 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2many",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "NeverAlone",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Wm94sBa6wa",
      "expanded_url" : "http:\/\/nyti.ms\/1pJLcVC",
      "display_url" : "nyti.ms\/1pJLcVC"
    } ]
  },
  "geo" : { },
  "id_str" : "461191566007472128",
  "text" : "RT @DWStweets: Important @WhiteHouse Sexual Assault Task Force report out today. #1is2many #NeverAlone http:\/\/t.co\/Wm94sBa6wa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2many",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "NeverAlone",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/Wm94sBa6wa",
        "expanded_url" : "http:\/\/nyti.ms\/1pJLcVC",
        "display_url" : "nyti.ms\/1pJLcVC"
      } ]
    },
    "geo" : { },
    "id_str" : "461187546320748544",
    "text" : "Important @WhiteHouse Sexual Assault Task Force report out today. #1is2many #NeverAlone http:\/\/t.co\/Wm94sBa6wa",
    "id" : 461187546320748544,
    "created_at" : "2014-04-29 16:57:34 +0000",
    "user" : {
      "name" : "D Wasserman Schultz",
      "screen_name" : "DWStweets",
      "protected" : false,
      "id_str" : "115979444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798138866951684096\/D89mZrBJ_normal.jpg",
      "id" : 115979444,
      "verified" : true
    }
  },
  "id" : 461191566007472128,
  "created_at" : "2014-04-29 17:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EPA",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461179087063900160",
  "text" : "RT @Podesta44: Victory for lungs everywhere: SCOTUS recognizes dirty air doesn\u2019t stop at state borders, upholds #EPA pollution rules http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EPA",
        "indices" : [ 97, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/6tGvqEmraj",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/04\/30\/us\/politics\/supreme-court-backs-epa-coal-pollution-rules.html?src=twr",
        "display_url" : "nytimes.com\/2014\/04\/30\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461177865577713664",
    "text" : "Victory for lungs everywhere: SCOTUS recognizes dirty air doesn\u2019t stop at state borders, upholds #EPA pollution rules http:\/\/t.co\/6tGvqEmraj",
    "id" : 461177865577713664,
    "created_at" : "2014-04-29 16:19:06 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 461179087063900160,
  "created_at" : "2014-04-29 16:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/FPZqYyew1e",
      "expanded_url" : "http:\/\/NotAlone.gov",
      "display_url" : "NotAlone.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "461174268261568512",
  "text" : "\"To anyone out there who has ever been assaulted: You are not alone. We have your back.\" \u2014President Obama: http:\/\/t.co\/FPZqYyew1e #1is2Many",
  "id" : 461174268261568512,
  "created_at" : "2014-04-29 16:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/vK9qWA6K2t",
      "expanded_url" : "https:\/\/NotAlone.gov",
      "display_url" : "NotAlone.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "461163158820773889",
  "text" : "FACT: 1 in 5 women is sexually assaulted while in college.\nRT if you agree that's unacceptable \u2192 https:\/\/t.co\/vK9qWA6K2t #1is2Many",
  "id" : 461163158820773889,
  "created_at" : "2014-04-29 15:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/vK9qWA6K2t",
      "expanded_url" : "https:\/\/NotAlone.gov",
      "display_url" : "NotAlone.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "461154349394042880",
  "text" : "Today, we're launching https:\/\/t.co\/vK9qWA6K2t to make resources on sexual assault prevention accessible to students and schools. #1is2Many",
  "id" : 461154349394042880,
  "created_at" : "2014-04-29 14:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/9QH89qCLvd",
      "expanded_url" : "http:\/\/go.wh.gov\/dVx1tU",
      "display_url" : "go.wh.gov\/dVx1tU"
    } ]
  },
  "geo" : { },
  "id_str" : "461147907375501312",
  "text" : "RT @VP: Too many women and men are sexually assaulted in college. We must put an end to this violence. \u2192 http:\/\/t.co\/9QH89qCLvd #1is2Many",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 120, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/9QH89qCLvd",
        "expanded_url" : "http:\/\/go.wh.gov\/dVx1tU",
        "display_url" : "go.wh.gov\/dVx1tU"
      } ]
    },
    "geo" : { },
    "id_str" : "461145078850150400",
    "text" : "Too many women and men are sexually assaulted in college. We must put an end to this violence. \u2192 http:\/\/t.co\/9QH89qCLvd #1is2Many",
    "id" : 461145078850150400,
    "created_at" : "2014-04-29 14:08:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 461147907375501312,
  "created_at" : "2014-04-29 14:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 33, 36 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/FhphQKGNks",
      "expanded_url" : "http:\/\/go.wh.gov\/dVx1tU",
      "display_url" : "go.wh.gov\/dVx1tU"
    } ]
  },
  "geo" : { },
  "id_str" : "461144178798657536",
  "text" : "Here's how President Obama &amp; @VP Biden are building on the progress we've made to prevent sexual assault \u2192 http:\/\/t.co\/FhphQKGNks #1is2Many",
  "id" : 461144178798657536,
  "created_at" : "2014-04-29 14:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460928512577511425",
  "text" : "RT @arneduncan: Next goal for the nation, 90% high school grad rate by 2020. Working together, we can, and we must, achieve it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460918297350123521",
    "text" : "Next goal for the nation, 90% high school grad rate by 2020. Working together, we can, and we must, achieve it!",
    "id" : 460918297350123521,
    "created_at" : "2014-04-28 23:07:40 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 460928512577511425,
  "created_at" : "2014-04-28 23:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyree Rahman",
      "screen_name" : "SugarBlissCake",
      "indices" : [ 11, 26 ],
      "id_str" : "321570774",
      "id" : 321570774
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/460923179079577600\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/pq0D79OtsH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmWHMGFIMAAwrTT.jpg",
      "id_str" : "460923178735644672",
      "id" : 460923178735644672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmWHMGFIMAAwrTT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/pq0D79OtsH"
    } ],
    "hashtags" : [ {
      "text" : "WorkingFamilies",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/mBOIi9248V",
      "expanded_url" : "http:\/\/instagram.com\/p\/nWXWjwQij7\/",
      "display_url" : "instagram.com\/p\/nWXWjwQij7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "460923179079577600",
  "text" : "Here's how @SugarBlissCake is helping #WorkingFamilies succeed \u2192 http:\/\/t.co\/mBOIi9248V http:\/\/t.co\/pq0D79OtsH",
  "id" : 460923179079577600,
  "created_at" : "2014-04-28 23:27:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460902104400683009",
  "text" : "RT @arneduncan: Great news! The high school grad rate is 80% - the highest in US history, but we can't forget the 20%. We have more work to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460895716961832960",
    "text" : "Great news! The high school grad rate is 80% - the highest in US history, but we can't forget the 20%. We have more work to do.",
    "id" : 460895716961832960,
    "created_at" : "2014-04-28 21:37:56 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 460902104400683009,
  "created_at" : "2014-04-28 22:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460894966894825472",
  "text" : "RT @VP: \"Now is the time to invest in America, to rebuild its infrastructure, its education system...now is the time.\" -- VP http:\/\/t.co\/x8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/460892427918651392\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/x8ntxEGsRI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmVrOKZCMAAbs0o.png",
        "id_str" : "460892427927040000",
        "id" : 460892427927040000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmVrOKZCMAAbs0o.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x8ntxEGsRI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460892427918651392",
    "text" : "\"Now is the time to invest in America, to rebuild its infrastructure, its education system...now is the time.\" -- VP http:\/\/t.co\/x8ntxEGsRI",
    "id" : 460892427918651392,
    "created_at" : "2014-04-28 21:24:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 460894966894825472,
  "created_at" : "2014-04-28 21:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/460871021831393282\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vJwOnBeS7b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmVXwEFCYAE1vvJ.jpg",
      "id_str" : "460871020115550209",
      "id" : 460871020115550209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmVXwEFCYAE1vvJ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vJwOnBeS7b"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460871021831393282",
  "text" : "\"Nobody who works full-time should ever have to live in poverty.\" \u2014President Obama on why it's time to #RaiseTheWage http:\/\/t.co\/vJwOnBeS7b",
  "id" : 460871021831393282,
  "created_at" : "2014-04-28 19:59:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/G5LM6102cb",
      "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
      "display_url" : "go.wh.gov\/xZ3Drp"
    } ]
  },
  "geo" : { },
  "id_str" : "460857590545907714",
  "text" : "FACT: More than 1.1 million Pennsylvanians will benefit if Congress votes to #RaiseTheWage \u2192 http:\/\/t.co\/G5LM6102cb",
  "id" : 460857590545907714,
  "created_at" : "2014-04-28 19:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "YallDeserveARaise",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xK0HzjtaB5",
      "expanded_url" : "http:\/\/go.wh.gov\/QWgVHU",
      "display_url" : "go.wh.gov\/QWgVHU"
    } ]
  },
  "geo" : { },
  "id_str" : "460836856847147008",
  "text" : "Hey Texas: More than 2.9 million Texans would benefit if Congress voted to #RaiseTheWage \u2192 http:\/\/t.co\/xK0HzjtaB5 #YallDeserveARaise",
  "id" : 460836856847147008,
  "created_at" : "2014-04-28 17:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460826815389790208",
  "text" : "RT @NancyPelosi: Why should we #raisethewage? Because a small raise can make a big difference in lifting families out of poverty: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NancyPelosi\/status\/460810818909528065\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/pBGRnKmtXC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmUg_5JCYAA99_f.png",
        "id_str" : "460810818917916672",
        "id" : 460810818917916672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmUg_5JCYAA99_f.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/pBGRnKmtXC"
      } ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 14, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460810818909528065",
    "text" : "Why should we #raisethewage? Because a small raise can make a big difference in lifting families out of poverty: http:\/\/t.co\/pBGRnKmtXC",
    "id" : 460810818909528065,
    "created_at" : "2014-04-28 16:00:35 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 460826815389790208,
  "created_at" : "2014-04-28 17:04:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/xK0HzjtaB5",
      "expanded_url" : "http:\/\/go.wh.gov\/QWgVHU",
      "display_url" : "go.wh.gov\/QWgVHU"
    } ]
  },
  "geo" : { },
  "id_str" : "460823446709342208",
  "text" : "1-0-1-0 for O-H-I-O!\nMore than 1 million Ohioans would benefit if Congress voted to #RaiseTheWage to $10.10 \u2192 http:\/\/t.co\/xK0HzjtaB5",
  "id" : 460823446709342208,
  "created_at" : "2014-04-28 16:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenSchumer\/status\/460817947330486272\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/s2mps0Wbvr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmUne0kCIAAp6Vm.png",
      "id_str" : "460817947334680576",
      "id" : 460817947334680576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmUne0kCIAAp6Vm.png",
      "sizes" : [ {
        "h" : 775,
        "resize" : "fit",
        "w" : 621
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 775,
        "resize" : "fit",
        "w" : 621
      } ],
      "display_url" : "pic.twitter.com\/s2mps0Wbvr"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 22, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460820151550898176",
  "text" : "RT @SenSchumer: If we #RaiseTheWage we'll help 28M+ American workers, that's 1.7M+ in NY alone http:\/\/t.co\/s2mps0Wbvr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSchumer\/status\/460817947330486272\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/s2mps0Wbvr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmUne0kCIAAp6Vm.png",
        "id_str" : "460817947334680576",
        "id" : 460817947334680576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmUne0kCIAAp6Vm.png",
        "sizes" : [ {
          "h" : 775,
          "resize" : "fit",
          "w" : 621
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 775,
          "resize" : "fit",
          "w" : 621
        } ],
        "display_url" : "pic.twitter.com\/s2mps0Wbvr"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 6, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460817947330486272",
    "text" : "If we #RaiseTheWage we'll help 28M+ American workers, that's 1.7M+ in NY alone http:\/\/t.co\/s2mps0Wbvr",
    "id" : 460817947330486272,
    "created_at" : "2014-04-28 16:28:55 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 460820151550898176,
  "created_at" : "2014-04-28 16:37:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/460816542293577728\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/rG1s8X45EH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmUmNAiCIAA4uyN.jpg",
      "id_str" : "460816541798244352",
      "id" : 460816541798244352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmUmNAiCIAA4uyN.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rG1s8X45EH"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/xK0HzjtaB5",
      "expanded_url" : "http:\/\/go.wh.gov\/QWgVHU",
      "display_url" : "go.wh.gov\/QWgVHU"
    } ]
  },
  "geo" : { },
  "id_str" : "460816542293577728",
  "text" : "Here are 28 million reasons why it's time to raise the minimum wage \u2192 http:\/\/t.co\/xK0HzjtaB5 #RaiseTheWage http:\/\/t.co\/rG1s8X45EH",
  "id" : 460816542293577728,
  "created_at" : "2014-04-28 16:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/460807429778079744\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/IYU3NqdDNJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmUd6lBCMAAj3NZ.png",
      "id_str" : "460807429081411584",
      "id" : 460807429081411584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmUd6lBCMAAj3NZ.png",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 1043
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IYU3NqdDNJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460807429778079744",
  "text" : "President Obama called Arkansas Gov. Mike Beebe to express his condolences for those lost in the tornado outbreak \u2192 http:\/\/t.co\/IYU3NqdDNJ",
  "id" : 460807429778079744,
  "created_at" : "2014-04-28 15:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/sUKneKz9eE",
      "expanded_url" : "http:\/\/bit.ly\/1hIJwSf",
      "display_url" : "bit.ly\/1hIJwSf"
    } ]
  },
  "geo" : { },
  "id_str" : "460799082848464896",
  "text" : "\"Not only did it save my life\u2014it's going to give me a better quality of life.\" \u2014Dean, a former ACA skeptic: http:\/\/t.co\/sUKneKz9eE #ACAWorks",
  "id" : 460799082848464896,
  "created_at" : "2014-04-28 15:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/qwnodR6lEa",
      "expanded_url" : "http:\/\/wh.gov\/Social",
      "display_url" : "wh.gov\/Social"
    } ]
  },
  "geo" : { },
  "id_str" : "460789985705484288",
  "text" : "RT @DrBiden: Calling all teachers! You're invited to a Teacher Appreciation #WHSocial hosted by Dr. Biden: http:\/\/t.co\/qwnodR6lEa http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/460776697697034241\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/r7BKuhI3Mf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmUB9xuCYAEDWyj.jpg",
        "id_str" : "460776697705422849",
        "id" : 460776697705422849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmUB9xuCYAEDWyj.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/r7BKuhI3Mf"
      } ],
      "hashtags" : [ {
        "text" : "WHSocial",
        "indices" : [ 63, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/qwnodR6lEa",
        "expanded_url" : "http:\/\/wh.gov\/Social",
        "display_url" : "wh.gov\/Social"
      } ]
    },
    "geo" : { },
    "id_str" : "460776697697034241",
    "text" : "Calling all teachers! You're invited to a Teacher Appreciation #WHSocial hosted by Dr. Biden: http:\/\/t.co\/qwnodR6lEa http:\/\/t.co\/r7BKuhI3Mf",
    "id" : 460776697697034241,
    "created_at" : "2014-04-28 13:45:00 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 460789985705484288,
  "created_at" : "2014-04-28 14:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 6, 15 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HX751XsFz4",
      "expanded_url" : "http:\/\/youtu.be\/FDz9VROCe5M",
      "display_url" : "youtu.be\/FDz9VROCe5M"
    } ]
  },
  "geo" : { },
  "id_str" : "460783898906349568",
  "text" : "Watch @Rhodes44 break down President Obama's trip to Malaysia\u2014where he signed agreements benefiting American workers: http:\/\/t.co\/HX751XsFz4",
  "id" : 460783898906349568,
  "created_at" : "2014-04-28 14:13:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/WqHRPUVsoU",
      "expanded_url" : "http:\/\/go.wh.gov\/tpNRsK",
      "display_url" : "go.wh.gov\/tpNRsK"
    } ]
  },
  "geo" : { },
  "id_str" : "460463533482733568",
  "text" : "\"We know that our economy works best when it works for all of us\u2014not just a fortunate few.\" \u2014Obama: http:\/\/t.co\/WqHRPUVsoU #ActOn1010",
  "id" : 460463533482733568,
  "created_at" : "2014-04-27 17:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WqHRPUVsoU",
      "expanded_url" : "http:\/\/go.wh.gov\/tpNRsK",
      "display_url" : "go.wh.gov\/tpNRsK"
    } ]
  },
  "geo" : { },
  "id_str" : "460440881699373056",
  "text" : "\"The average min wage worker is 35 years old. They work hard, often in physically demanding jobs.\" \u2014Obama: http:\/\/t.co\/WqHRPUVsoU #ActOn1010",
  "id" : 460440881699373056,
  "created_at" : "2014-04-27 15:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/WqHRPUVsoU",
      "expanded_url" : "http:\/\/go.wh.gov\/tpNRsK",
      "display_url" : "go.wh.gov\/tpNRsK"
    } ]
  },
  "geo" : { },
  "id_str" : "460418234974339074",
  "text" : "\"Nearly 3 in 4 Americans support raising the minimum wage.\" \u2014President Obama on why it's time to #ActOn1010: http:\/\/t.co\/WqHRPUVsoU",
  "id" : 460418234974339074,
  "created_at" : "2014-04-27 14:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/03e6L3sXZU",
      "expanded_url" : "http:\/\/go.wh.gov\/vJpXh5",
      "display_url" : "go.wh.gov\/vJpXh5"
    } ]
  },
  "geo" : { },
  "id_str" : "460326373941194753",
  "text" : "Watch President Obama host a town hall with participants from the Young Southeast Asian Leaders Initiative \u2192 http:\/\/t.co\/03e6L3sXZU #YSEALI",
  "id" : 460326373941194753,
  "created_at" : "2014-04-27 07:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/WqHRPUVsoU",
      "expanded_url" : "http:\/\/go.wh.gov\/tpNRsK",
      "display_url" : "go.wh.gov\/tpNRsK"
    } ]
  },
  "geo" : { },
  "id_str" : "460116237213646851",
  "text" : "\"It\u2019s time for $10.10. It\u2019s time to give America a raise.\" \u2014President Obama: http:\/\/t.co\/WqHRPUVsoU #ActOn1010",
  "id" : 460116237213646851,
  "created_at" : "2014-04-26 18:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/WqHRPUVsoU",
      "expanded_url" : "http:\/\/go.wh.gov\/tpNRsK",
      "display_url" : "go.wh.gov\/tpNRsK"
    } ]
  },
  "geo" : { },
  "id_str" : "460093584939556864",
  "text" : "President Obama's Weekly Address: Congress needs to act on the minimum wage \u2192 http:\/\/t.co\/WqHRPUVsoU #ActOn1010",
  "id" : 460093584939556864,
  "created_at" : "2014-04-26 16:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 92, 105 ]
    }, {
      "text" : "ActOn1010",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WqHRPUVsoU",
      "expanded_url" : "http:\/\/go.wh.gov\/tpNRsK",
      "display_url" : "go.wh.gov\/tpNRsK"
    } ]
  },
  "geo" : { },
  "id_str" : "460068811803090944",
  "text" : "\"Nobody who works full-time should ever have to live in poverty\" \u2014Obama on why it's time to #RaiseTheWage: http:\/\/t.co\/WqHRPUVsoU #ActOn1010",
  "id" : 460068811803090944,
  "created_at" : "2014-04-26 14:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Yksosq4ppn",
      "expanded_url" : "http:\/\/go.usa.gov\/kVpA",
      "display_url" : "go.usa.gov\/kVpA"
    } ]
  },
  "geo" : { },
  "id_str" : "459821779662700544",
  "text" : "RT @usedgov: 62% of new teachers say they graduated from ed school unprepared. We want to fix that http:\/\/t.co\/Yksosq4ppn http:\/\/t.co\/zpqnL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/459799034757017600\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/zpqnLscS6R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmGIyS2CYAAVJm6.jpg",
        "id_str" : "459799034601824256",
        "id" : 459799034601824256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmGIyS2CYAAVJm6.jpg",
        "sizes" : [ {
          "h" : 743,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 743,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zpqnLscS6R"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Yksosq4ppn",
        "expanded_url" : "http:\/\/go.usa.gov\/kVpA",
        "display_url" : "go.usa.gov\/kVpA"
      } ]
    },
    "geo" : { },
    "id_str" : "459799034757017600",
    "text" : "62% of new teachers say they graduated from ed school unprepared. We want to fix that http:\/\/t.co\/Yksosq4ppn http:\/\/t.co\/zpqnLscS6R",
    "id" : 459799034757017600,
    "created_at" : "2014-04-25 21:00:07 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 459821779662700544,
  "created_at" : "2014-04-25 22:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/G5LM6102cb",
      "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
      "display_url" : "go.wh.gov\/xZ3Drp"
    } ]
  },
  "geo" : { },
  "id_str" : "459813728293494784",
  "text" : "Raising the minimum wage would help millions of Americans better afford groceries and pay the bills \u2192 http:\/\/t.co\/G5LM6102cb #ActOn1010",
  "id" : 459813728293494784,
  "created_at" : "2014-04-25 21:58:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 52, 63 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/WdXt41bJS9",
      "expanded_url" : "http:\/\/go.wh.gov\/8Rz8Zz",
      "display_url" : "go.wh.gov\/8Rz8Zz"
    } ]
  },
  "geo" : { },
  "id_str" : "459798866255429633",
  "text" : "RT @FLOTUS: RT to spread the word: You can tour the @WhiteHouse grounds for free this weekend \u2192 http:\/\/t.co\/WdXt41bJS9 #WHGarden http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/459797971274461184\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/S2qsJhCUFz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmGHy80CMAAmbvx.jpg",
        "id_str" : "459797946356084736",
        "id" : 459797946356084736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmGHy80CMAAmbvx.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1936
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/S2qsJhCUFz"
      } ],
      "hashtags" : [ {
        "text" : "WHGarden",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/WdXt41bJS9",
        "expanded_url" : "http:\/\/go.wh.gov\/8Rz8Zz",
        "display_url" : "go.wh.gov\/8Rz8Zz"
      } ]
    },
    "geo" : { },
    "id_str" : "459797971274461184",
    "text" : "RT to spread the word: You can tour the @WhiteHouse grounds for free this weekend \u2192 http:\/\/t.co\/WdXt41bJS9 #WHGarden http:\/\/t.co\/S2qsJhCUFz",
    "id" : 459797971274461184,
    "created_at" : "2014-04-25 20:55:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 459798866255429633,
  "created_at" : "2014-04-25 20:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/JD0OG3P2zc",
      "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
      "display_url" : "go.wh.gov\/xZ3Drp"
    } ]
  },
  "geo" : { },
  "id_str" : "459785141393424384",
  "text" : "Raising the minimum wage to $10.10 would benefit 28 million Americans.\nIt's time for Congress to #ActOn1010 \u2192 http:\/\/t.co\/JD0OG3P2zc",
  "id" : 459785141393424384,
  "created_at" : "2014-04-25 20:04:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459779287688945664",
  "text" : "RT @arneduncan: We owe our kids highly effective teachers &amp; we owe teachers highly effective training before entering the classroom http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/VqyFw0ApJV",
        "expanded_url" : "http:\/\/go.usa.gov\/kVpA",
        "display_url" : "go.usa.gov\/kVpA"
      } ]
    },
    "geo" : { },
    "id_str" : "459763234505900032",
    "text" : "We owe our kids highly effective teachers &amp; we owe teachers highly effective training before entering the classroom http:\/\/t.co\/VqyFw0ApJV",
    "id" : 459763234505900032,
    "created_at" : "2014-04-25 18:37:51 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 459779287688945664,
  "created_at" : "2014-04-25 19:41:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LZ2UwCVpa4",
      "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
      "display_url" : "go.wh.gov\/xZ3Drp"
    } ]
  },
  "geo" : { },
  "id_str" : "459772701914431488",
  "text" : "RT @LaborSec: New interactive map from the @WhiteHouse shows the number of  workers who'd benefit in your state: http:\/\/t.co\/LZ2UwCVpa4  #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 29, 40 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOn1010",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/LZ2UwCVpa4",
        "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
        "display_url" : "go.wh.gov\/xZ3Drp"
      } ]
    },
    "geo" : { },
    "id_str" : "459771520618090497",
    "text" : "New interactive map from the @WhiteHouse shows the number of  workers who'd benefit in your state: http:\/\/t.co\/LZ2UwCVpa4  #ActOn1010",
    "id" : 459771520618090497,
    "created_at" : "2014-04-25 19:10:47 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 459772701914431488,
  "created_at" : "2014-04-25 19:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/459768529387270144\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/fdZajiAqZa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmFtCnXCcAAFJuX.jpg",
      "id_str" : "459768528661278720",
      "id" : 459768528661278720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmFtCnXCcAAFJuX.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fdZajiAqZa"
    } ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/G5LM6102cb",
      "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
      "display_url" : "go.wh.gov\/xZ3Drp"
    } ]
  },
  "geo" : { },
  "id_str" : "459768529387270144",
  "text" : "RT if you agree: It's long past time to raise the minimum wage \u2192 http:\/\/t.co\/G5LM6102cb #ActOn1010 http:\/\/t.co\/fdZajiAqZa",
  "id" : 459768529387270144,
  "created_at" : "2014-04-25 18:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOn1010",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/G5LM6102cb",
      "expanded_url" : "http:\/\/go.wh.gov\/xZ3Drp",
      "display_url" : "go.wh.gov\/xZ3Drp"
    } ]
  },
  "geo" : { },
  "id_str" : "459762559877677057",
  "text" : "Worth sharing: Here's a state-by-state breakdown of why it's time for Congress to raise the minimum wage \u2192 http:\/\/t.co\/G5LM6102cb #ActOn1010",
  "id" : 459762559877677057,
  "created_at" : "2014-04-25 18:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 116, 127 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AMR",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459749944321384449",
  "text" : "RT @DagVega44: \"Every child deserves a highly effective teacher &amp; every teacher deserves to be well trained.\" \u2013 @arneduncan on #AMR, http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 101, 112 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AMR",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/TPIp01TJ0l",
        "expanded_url" : "http:\/\/on.msnbc.com\/1il0LyS",
        "display_url" : "on.msnbc.com\/1il0LyS"
      } ]
    },
    "geo" : { },
    "id_str" : "459749728121782272",
    "text" : "\"Every child deserves a highly effective teacher &amp; every teacher deserves to be well trained.\" \u2013 @arneduncan on #AMR, http:\/\/t.co\/TPIp01TJ0l",
    "id" : 459749728121782272,
    "created_at" : "2014-04-25 17:44:11 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 459749944321384449,
  "created_at" : "2014-04-25 17:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/459711287044636672\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/MCaC5cNzwr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmE4-j3CEAAvLti.jpg",
      "id_str" : "459711284397608960",
      "id" : 459711284397608960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmE4-j3CEAAvLti.jpg",
      "sizes" : [ {
        "h" : 742,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 691,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MCaC5cNzwr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459711287044636672",
  "text" : "\"We are a nation of immigrants.\" \u2014Obama at a naturalization ceremony for servicemembers at the War Memorial of Korea http:\/\/t.co\/MCaC5cNzwr",
  "id" : 459711287044636672,
  "created_at" : "2014-04-25 15:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 16, 23 ],
      "id_str" : "40918816",
      "id" : 40918816
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 63, 77 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/j62ZtvPjQO",
      "expanded_url" : "http:\/\/youtu.be\/iYSd9Lx_vt8",
      "display_url" : "youtu.be\/iYSd9Lx_vt8"
    } ]
  },
  "geo" : { },
  "id_str" : "459696109544570881",
  "text" : "RT @FLOTUS: The @RedSox (and their beards) are teaming up with @JoiningForces to support our military families \u2192 http:\/\/t.co\/j62ZtvPjQO #Jo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boston Red Sox",
        "screen_name" : "RedSox",
        "indices" : [ 4, 11 ],
        "id_str" : "40918816",
        "id" : 40918816
      }, {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 51, 65 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/j62ZtvPjQO",
        "expanded_url" : "http:\/\/youtu.be\/iYSd9Lx_vt8",
        "display_url" : "youtu.be\/iYSd9Lx_vt8"
      } ]
    },
    "geo" : { },
    "id_str" : "459695711596974080",
    "text" : "The @RedSox (and their beards) are teaming up with @JoiningForces to support our military families \u2192 http:\/\/t.co\/j62ZtvPjQO #JoiningForces",
    "id" : 459695711596974080,
    "created_at" : "2014-04-25 14:09:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 459696109544570881,
  "created_at" : "2014-04-25 14:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459481087245553664",
  "text" : "RT @FLOTUS: Wanna hang out in the @WhiteHouse Kitchen Garden? Find out how you can take a spring #WHGarden tour this weekend \u2192 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 22, 33 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHGarden",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/tp5OxrdgBs",
        "expanded_url" : "http:\/\/wh.gov\/lwIer",
        "display_url" : "wh.gov\/lwIer"
      } ]
    },
    "geo" : { },
    "id_str" : "459480461618601984",
    "text" : "Wanna hang out in the @WhiteHouse Kitchen Garden? Find out how you can take a spring #WHGarden tour this weekend \u2192 http:\/\/t.co\/tp5OxrdgBs",
    "id" : 459480461618601984,
    "created_at" : "2014-04-24 23:54:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 459481087245553664,
  "created_at" : "2014-04-24 23:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/zQnVV1cNbz",
      "expanded_url" : "http:\/\/youtu.be\/cfy7yV19uVA",
      "display_url" : "youtu.be\/cfy7yV19uVA"
    } ]
  },
  "geo" : { },
  "id_str" : "459432522745528320",
  "text" : "Go behind the scenes with President Obama on his trip to Japan \u2192 http:\/\/t.co\/zQnVV1cNbz",
  "id" : 459432522745528320,
  "created_at" : "2014-04-24 20:43:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459407920040792064",
  "text" : "RT @NatlParkService: Plan your visit to get a bird's eye view of the nation's capital. The Washington Monument reopens on May12th. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/1wj1WQPK9x",
        "expanded_url" : "http:\/\/go.nps.gov\/wm",
        "display_url" : "go.nps.gov\/wm"
      } ]
    },
    "geo" : { },
    "id_str" : "459405204136665088",
    "text" : "Plan your visit to get a bird's eye view of the nation's capital. The Washington Monument reopens on May12th. http:\/\/t.co\/1wj1WQPK9x",
    "id" : 459405204136665088,
    "created_at" : "2014-04-24 18:55:10 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 459407920040792064,
  "created_at" : "2014-04-24 19:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/459396990720159745\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RVpQ1JOzcL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmAbIQtCMAAi1Ui.png",
      "id_str" : "459396990728548352",
      "id" : 459396990728548352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmAbIQtCMAAi1Ui.png",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 467
      } ],
      "display_url" : "pic.twitter.com\/RVpQ1JOzcL"
    } ],
    "hashtags" : [ {
      "text" : "TakeYourChildToWorkDay",
      "indices" : [ 14, 37 ]
    }, {
      "text" : "TBT",
      "indices" : [ 38, 42 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 43, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/YKAgNYHBSV",
      "expanded_url" : "http:\/\/instagram.com\/p\/nLq6rJFwZt\/",
      "display_url" : "instagram.com\/p\/nLq6rJFwZt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459397302281834496",
  "text" : "RT @VP: Happy #TakeYourChildToWorkDay #TBT #ThrowbackThursday http:\/\/t.co\/YKAgNYHBSV http:\/\/t.co\/RVpQ1JOzcL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/459396990720159745\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/RVpQ1JOzcL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmAbIQtCMAAi1Ui.png",
        "id_str" : "459396990728548352",
        "id" : 459396990728548352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmAbIQtCMAAi1Ui.png",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 467
        } ],
        "display_url" : "pic.twitter.com\/RVpQ1JOzcL"
      } ],
      "hashtags" : [ {
        "text" : "TakeYourChildToWorkDay",
        "indices" : [ 6, 29 ]
      }, {
        "text" : "TBT",
        "indices" : [ 30, 34 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 35, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/YKAgNYHBSV",
        "expanded_url" : "http:\/\/instagram.com\/p\/nLq6rJFwZt\/",
        "display_url" : "instagram.com\/p\/nLq6rJFwZt\/"
      } ]
    },
    "geo" : { },
    "id_str" : "459396990720159745",
    "text" : "Happy #TakeYourChildToWorkDay #TBT #ThrowbackThursday http:\/\/t.co\/YKAgNYHBSV http:\/\/t.co\/RVpQ1JOzcL",
    "id" : 459396990720159745,
    "created_at" : "2014-04-24 18:22:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 459397302281834496,
  "created_at" : "2014-04-24 18:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 80, 89 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Time100",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ag6uZ2ji3x",
      "expanded_url" : "http:\/\/ti.me\/1nIm38Y",
      "display_url" : "ti.me\/1nIm38Y"
    } ]
  },
  "geo" : { },
  "id_str" : "459365410622943232",
  "text" : "\"Rare is the leader who makes us want to be better people.\" \u2014President Obama on @Pontifex: http:\/\/t.co\/ag6uZ2ji3x #Time100",
  "id" : 459365410622943232,
  "created_at" : "2014-04-24 16:17:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/459351621395570688\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/j7BC4wIPbb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl_x3XmCcAAaNIP.jpg",
      "id_str" : "459351620543737856",
      "id" : 459351620543737856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl_x3XmCcAAaNIP.jpg",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 891,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/j7BC4wIPbb"
    } ],
    "hashtags" : [ {
      "text" : "InvestInSTEM",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459351621395570688",
  "text" : "\"There\u2019s no limit to what you can achieve.\" \u2014President Obama encouraging young innovators #InvestInSTEM http:\/\/t.co\/j7BC4wIPbb",
  "id" : 459351621395570688,
  "created_at" : "2014-04-24 15:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 78, 87 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/459340814653870080\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Y9lAajYVIe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl_oCW5CIAA3eDd.jpg",
      "id_str" : "459340814217256960",
      "id" : 459340814217256960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl_oCW5CIAA3eDd.jpg",
      "sizes" : [ {
        "h" : 891,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Y9lAajYVIe"
    } ],
    "hashtags" : [ {
      "text" : "Time100",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ag6uZ2ji3x",
      "expanded_url" : "http:\/\/ti.me\/1nIm38Y",
      "display_url" : "ti.me\/1nIm38Y"
    } ]
  },
  "geo" : { },
  "id_str" : "459340814653870080",
  "text" : "\"His message of love &amp; inclusion\u2026is a tonic for a cynical age.\" \u2014Obama on @Pontifex: http:\/\/t.co\/ag6uZ2ji3x #Time100 http:\/\/t.co\/Y9lAajYVIe",
  "id" : 459340814653870080,
  "created_at" : "2014-04-24 14:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hz3RIADi96",
      "expanded_url" : "http:\/\/go.wh.gov\/1pKN4a",
      "display_url" : "go.wh.gov\/1pKN4a"
    } ]
  },
  "geo" : { },
  "id_str" : "459119832789970944",
  "text" : "RT @FLOTUS: \"I know you all can thrive in any classroom, in any business.\"\u2014FLOTUS on connecting veterans w\/ jobs: http:\/\/t.co\/hz3RIADi96 #J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/hz3RIADi96",
        "expanded_url" : "http:\/\/go.wh.gov\/1pKN4a",
        "display_url" : "go.wh.gov\/1pKN4a"
      } ]
    },
    "geo" : { },
    "id_str" : "459119794407866370",
    "text" : "\"I know you all can thrive in any classroom, in any business.\"\u2014FLOTUS on connecting veterans w\/ jobs: http:\/\/t.co\/hz3RIADi96 #JoiningForces",
    "id" : 459119794407866370,
    "created_at" : "2014-04-24 00:01:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 459119832789970944,
  "created_at" : "2014-04-24 00:01:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Detroit",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459106450649137152",
  "text" : "RT @Interior: Today we designated 4 new national historic landmarks including Diego Rivera's #Detroit Industry Murals seen here. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/459093361149091841\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/sa7bHk6ITx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl8G-neIAAAN-oX.jpg",
        "id_str" : "459093359832072192",
        "id" : 459093359832072192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl8G-neIAAAN-oX.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sa7bHk6ITx"
      } ],
      "hashtags" : [ {
        "text" : "Detroit",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459093361149091841",
    "text" : "Today we designated 4 new national historic landmarks including Diego Rivera's #Detroit Industry Murals seen here. http:\/\/t.co\/sa7bHk6ITx",
    "id" : 459093361149091841,
    "created_at" : "2014-04-23 22:16:01 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 459106450649137152,
  "created_at" : "2014-04-23 23:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 47, 61 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459053634178007040",
  "text" : "RT @LaborSec: Great news: Companies working w\/ @JoiningForces have hired more than 540,000 veterans &amp; military spouses. http:\/\/t.co\/mKvkapH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 33, 47 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnJobs",
        "indices" : [ 133, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mKvkapHNmc",
        "expanded_url" : "http:\/\/1.usa.gov\/PtPUWw",
        "display_url" : "1.usa.gov\/PtPUWw"
      } ]
    },
    "geo" : { },
    "id_str" : "459020399670730752",
    "text" : "Great news: Companies working w\/ @JoiningForces have hired more than 540,000 veterans &amp; military spouses. http:\/\/t.co\/mKvkapHNmc #ActOnJobs",
    "id" : 459020399670730752,
    "created_at" : "2014-04-23 17:26:06 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 459053634178007040,
  "created_at" : "2014-04-23 19:38:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/459036401535684608\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/A1Zk0q7CKJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl7TLMbCMAAdG8L.jpg",
      "id_str" : "459036401305006080",
      "id" : 459036401305006080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl7TLMbCMAAdG8L.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/A1Zk0q7CKJ"
    } ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 71, 85 ]
    }, {
      "text" : "ActOnJobs",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459036401535684608",
  "text" : "It's time to serve our military families as well as they've served us. #JoiningForces #ActOnJobs http:\/\/t.co\/A1Zk0q7CKJ",
  "id" : 459036401535684608,
  "created_at" : "2014-04-23 18:29:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 20, 27 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 34, 42 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "jobs",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/LCgmQ9j1jO",
      "expanded_url" : "http:\/\/go.usa.gov\/kPFJ",
      "display_url" : "go.usa.gov\/kPFJ"
    } ]
  },
  "geo" : { },
  "id_str" : "459032601169522688",
  "text" : "RT @DeptofDefense: .@FLOTUS &amp; @DrBiden announced a new site to help connect #veterans with #jobs: http:\/\/t.co\/LCgmQ9j1jO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 1, 8 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 15, 23 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 61, 70 ]
      }, {
        "text" : "jobs",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/LCgmQ9j1jO",
        "expanded_url" : "http:\/\/go.usa.gov\/kPFJ",
        "display_url" : "go.usa.gov\/kPFJ"
      } ]
    },
    "geo" : { },
    "id_str" : "459026562528968704",
    "text" : ".@FLOTUS &amp; @DrBiden announced a new site to help connect #veterans with #jobs: http:\/\/t.co\/LCgmQ9j1jO",
    "id" : 459026562528968704,
    "created_at" : "2014-04-23 17:50:35 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 459032601169522688,
  "created_at" : "2014-04-23 18:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 129, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ZOvk7lHIpU",
      "expanded_url" : "http:\/\/1.usa.gov\/Qy8EFA",
      "display_url" : "1.usa.gov\/Qy8EFA"
    } ]
  },
  "geo" : { },
  "id_str" : "459026198488961024",
  "text" : "Veterans &amp; military spouses can now access an online tool to help find jobs that match their skills \u2192 http:\/\/t.co\/ZOvk7lHIpU #JoiningForces",
  "id" : 459026198488961024,
  "created_at" : "2014-04-23 17:49:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 41, 55 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459011926924992514",
  "text" : "RT @FLOTUS: FACT: Companies working with @JoiningForces have hired more than 540,000 veterans &amp; military spouses. #JoiningForces http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 29, 43 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/459010360612519937\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/KVEXkPn3f6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl67fatIYAARLPM.jpg",
        "id_str" : "459010360457322496",
        "id" : 459010360457322496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl67fatIYAARLPM.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KVEXkPn3f6"
      } ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 106, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459010360612519937",
    "text" : "FACT: Companies working with @JoiningForces have hired more than 540,000 veterans &amp; military spouses. #JoiningForces http:\/\/t.co\/KVEXkPn3f6",
    "id" : 459010360612519937,
    "created_at" : "2014-04-23 16:46:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 459011926924992514,
  "created_at" : "2014-04-23 16:52:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 7, 14 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 103, 117 ]
    }, {
      "text" : "ActOnJobs",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/yYYxF6piHw",
      "expanded_url" : "http:\/\/fw.to\/I0eHYVF",
      "display_url" : "fw.to\/I0eHYVF"
    } ]
  },
  "geo" : { },
  "id_str" : "459001886046425088",
  "text" : "Today, @FLOTUS is announcing a new site that helps connect veterans with jobs \u2192 http:\/\/t.co\/yYYxF6piHw #JoiningForces #ActOnJobs",
  "id" : 459001886046425088,
  "created_at" : "2014-04-23 16:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9Po6eZG0up",
      "expanded_url" : "https:\/\/vine.co\/v\/MnwOWZXp9q5",
      "display_url" : "vine.co\/v\/MnwOWZXp9q5"
    } ]
  },
  "geo" : { },
  "id_str" : "458991503386632192",
  "text" : "RT @FLOTUS: RT if you agree: It's time to serve our military families as well as they've served us \u2192 https:\/\/t.co\/9Po6eZG0up #JoiningForces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 113, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/9Po6eZG0up",
        "expanded_url" : "https:\/\/vine.co\/v\/MnwOWZXp9q5",
        "display_url" : "vine.co\/v\/MnwOWZXp9q5"
      } ]
    },
    "geo" : { },
    "id_str" : "458990730586107905",
    "text" : "RT if you agree: It's time to serve our military families as well as they've served us \u2192 https:\/\/t.co\/9Po6eZG0up #JoiningForces",
    "id" : 458990730586107905,
    "created_at" : "2014-04-23 15:28:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 458991503386632192,
  "created_at" : "2014-04-23 15:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/458975493744648192\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5kH6Xh24pq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl6bx5NCYAAIY4o.jpg",
      "id_str" : "458975493509767168",
      "id" : 458975493509767168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl6bx5NCYAAIY4o.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/5kH6Xh24pq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458975493744648192",
  "text" : "President Obama views damage from the recent mudslide in Oso, WA before meeting with families who lost loved ones. http:\/\/t.co\/5kH6Xh24pq",
  "id" : 458975493744648192,
  "created_at" : "2014-04-23 14:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/OpW2k1fEb0",
      "expanded_url" : "http:\/\/go.wh.gov\/zqj5ej",
      "display_url" : "go.wh.gov\/zqj5ej"
    } ]
  },
  "geo" : { },
  "id_str" : "458745334630715392",
  "text" : "Happening now: President Obama speaks in Oso, Washington \u2192 http:\/\/t.co\/OpW2k1fEb0",
  "id" : 458745334630715392,
  "created_at" : "2014-04-22 23:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "ED Green Ribbon",
      "screen_name" : "EDGreenRibbon",
      "indices" : [ 47, 61 ],
      "id_str" : "1467410538",
      "id" : 1467410538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458730668231786497",
  "text" : "RT @arneduncan: Happy Earth Day! Congrats 2014 @EDGreenRibbon Schools! All 48 schools and 9 districts are true green leaders: http:\/\/t.co\/W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ED Green Ribbon",
        "screen_name" : "EDGreenRibbon",
        "indices" : [ 31, 45 ],
        "id_str" : "1467410538",
        "id" : 1467410538
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/WopDOfWFH7",
        "expanded_url" : "http:\/\/go.usa.gov\/kU8B",
        "display_url" : "go.usa.gov\/kU8B"
      } ]
    },
    "geo" : { },
    "id_str" : "458696940134211584",
    "text" : "Happy Earth Day! Congrats 2014 @EDGreenRibbon Schools! All 48 schools and 9 districts are true green leaders: http:\/\/t.co\/WopDOfWFH7",
    "id" : 458696940134211584,
    "created_at" : "2014-04-22 20:00:47 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 458730668231786497,
  "created_at" : "2014-04-22 22:14:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/N4dotou4lA",
      "expanded_url" : "http:\/\/go.wh.gov\/ocUY3z",
      "display_url" : "go.wh.gov\/ocUY3z"
    } ]
  },
  "geo" : { },
  "id_str" : "458727650853662720",
  "text" : "We've tripled the electricity we generate from wind power since President Obama took office \u2192 http:\/\/t.co\/N4dotou4lA #ActOnClimate #EarthDay",
  "id" : 458727650853662720,
  "created_at" : "2014-04-22 22:02:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Y8TExSJjxK",
      "expanded_url" : "http:\/\/go.wh.gov\/4Yii3Z",
      "display_url" : "go.wh.gov\/4Yii3Z"
    } ]
  },
  "geo" : { },
  "id_str" : "458712087121121281",
  "text" : "Solar power is more affordable than ever: The average cost of solar panels has dropped 60% since 2010 \u2192 http:\/\/t.co\/Y8TExSJjxK #EarthDay",
  "id" : 458712087121121281,
  "created_at" : "2014-04-22 21:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Thomas H. Marshburn",
      "screen_name" : "AstroMarshburn",
      "indices" : [ 25, 40 ],
      "id_str" : "394246259",
      "id" : 394246259
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 47, 62 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/edJLOsRLaf",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/we-the-geeks",
      "display_url" : "whitehouse.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "458694530616033281",
  "text" : "RT @NASA: At 4p ET, join @AstroMarshburn &amp; @WhiteHouseOSTP for Extreme Science #WeTheGeeks Hangout! http:\/\/t.co\/edJLOsRLaf http:\/\/t.co\/OMEz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thomas H. Marshburn",
        "screen_name" : "AstroMarshburn",
        "indices" : [ 15, 30 ],
        "id_str" : "394246259",
        "id" : 394246259
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 37, 52 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/458680713072500736\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/OMEzZaLfwu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl2PraiCYAAodUB.jpg",
        "id_str" : "458680713080889344",
        "id" : 458680713080889344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl2PraiCYAAodUB.jpg",
        "sizes" : [ {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/OMEzZaLfwu"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 73, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/edJLOsRLaf",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/we-the-geeks",
        "display_url" : "whitehouse.gov\/we-the-geeks"
      } ]
    },
    "geo" : { },
    "id_str" : "458680713072500736",
    "text" : "At 4p ET, join @AstroMarshburn &amp; @WhiteHouseOSTP for Extreme Science #WeTheGeeks Hangout! http:\/\/t.co\/edJLOsRLaf http:\/\/t.co\/OMEzZaLfwu",
    "id" : 458680713072500736,
    "created_at" : "2014-04-22 18:56:18 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 458694530616033281,
  "created_at" : "2014-04-22 19:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/458682878340370432\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/z4EuEfYGp6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl2RpcEIMAA2GB9.jpg",
      "id_str" : "458682878155829248",
      "id" : 458682878155829248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl2RpcEIMAA2GB9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z4EuEfYGp6"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Y8TExSJjxK",
      "expanded_url" : "http:\/\/go.wh.gov\/4Yii3Z",
      "display_url" : "go.wh.gov\/4Yii3Z"
    } ]
  },
  "geo" : { },
  "id_str" : "458682878340370432",
  "text" : "FACT: Every 4 minutes, another American home or business goes solar \u2192 http:\/\/t.co\/Y8TExSJjxK #ActOnClimate #EarthDay http:\/\/t.co\/z4EuEfYGp6",
  "id" : 458682878340370432,
  "created_at" : "2014-04-22 19:04:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyEarthDay",
      "indices" : [ 112, 126 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/OJO69UifZs",
      "expanded_url" : "http:\/\/go.wh.gov\/TTgq2R",
      "display_url" : "go.wh.gov\/TTgq2R"
    } ]
  },
  "geo" : { },
  "id_str" : "458670611615985664",
  "text" : "Here are some great tools to help you save energy at home and use less gas on the road \u2192 http:\/\/t.co\/OJO69UifZs #HappyEarthDay #ActOnClimate",
  "id" : 458670611615985664,
  "created_at" : "2014-04-22 18:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/458660767169282048\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/gjJKHBixsg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl19iZMIUAIDPMi.jpg",
      "id_str" : "458660766892445698",
      "id" : 458660766892445698,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl19iZMIUAIDPMi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gjJKHBixsg"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 51, 64 ]
    }, {
      "text" : "HappyEarthDay",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nLHR8pQkgC",
      "expanded_url" : "http:\/\/go.wh.gov\/m5hxL8",
      "display_url" : "go.wh.gov\/m5hxL8"
    } ]
  },
  "geo" : { },
  "id_str" : "458660767169282048",
  "text" : "RT if you agree with President Obama: It's time to #ActOnClimate change \u2192 http:\/\/t.co\/nLHR8pQkgC #HappyEarthDay http:\/\/t.co\/gjJKHBixsg",
  "id" : 458660767169282048,
  "created_at" : "2014-04-22 17:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 21, 29 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 33, 46 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Uwp4fUNtTi",
      "expanded_url" : "http:\/\/on.cc.com\/1twczlg",
      "display_url" : "on.cc.com\/1twczlg"
    } ]
  },
  "geo" : { },
  "id_str" : "458657360823992320",
  "text" : "RT @DagVega44: Watch @GinaEPA on @TheDailyShow talk about the President's Climate Action plan \u2192 http:\/\/t.co\/Uwp4fUNtTi #EarthDay, http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 6, 14 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      }, {
        "name" : "The Daily Show",
        "screen_name" : "TheDailyShow",
        "indices" : [ 18, 31 ],
        "id_str" : "158414847",
        "id" : 158414847
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DagVega44\/status\/458656705480781824\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/N9We1v1b8U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl151-0IEAAnQ2f.jpg",
        "id_str" : "458656705363316736",
        "id" : 458656705363316736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl151-0IEAAnQ2f.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 692
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 692
        } ],
        "display_url" : "pic.twitter.com\/N9We1v1b8U"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/Uwp4fUNtTi",
        "expanded_url" : "http:\/\/on.cc.com\/1twczlg",
        "display_url" : "on.cc.com\/1twczlg"
      } ]
    },
    "geo" : { },
    "id_str" : "458656705480781824",
    "text" : "Watch @GinaEPA on @TheDailyShow talk about the President's Climate Action plan \u2192 http:\/\/t.co\/Uwp4fUNtTi #EarthDay, http:\/\/t.co\/N9We1v1b8U",
    "id" : 458656705480781824,
    "created_at" : "2014-04-22 17:20:54 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 458657360823992320,
  "created_at" : "2014-04-22 17:23:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 6, 17 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6aoYbCTuBO",
      "expanded_url" : "http:\/\/go.wh.gov\/u2L4vE",
      "display_url" : "go.wh.gov\/u2L4vE"
    } ]
  },
  "geo" : { },
  "id_str" : "458651574852919296",
  "text" : "Watch #WeTheGeeks at 4pm ET to fInd out what it's like to work atop volcanoes or on the ocean floor \u2192 http:\/\/t.co\/6aoYbCTuBO #EarthDay",
  "id" : 458651574852919296,
  "created_at" : "2014-04-22 17:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/458636399025999872\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/dGbJDeTgGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl1nX_VCAAIudNb.jpg",
      "id_str" : "458636398895955970",
      "id" : 458636398895955970,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl1nX_VCAAIudNb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dGbJDeTgGu"
    } ],
    "hashtags" : [ {
      "text" : "HappyEarthDay",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/yxKfJn0esh",
      "expanded_url" : "http:\/\/go.wh.gov\/rGVdSr",
      "display_url" : "go.wh.gov\/rGVdSr"
    } ]
  },
  "geo" : { },
  "id_str" : "458636399025999872",
  "text" : "#HappyEarthDay! Let's all do our part to protect our planet \u2192 http:\/\/t.co\/yxKfJn0esh #ActOnClimate http:\/\/t.co\/dGbJDeTgGu",
  "id" : 458636399025999872,
  "created_at" : "2014-04-22 16:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 13, 27 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 67, 75 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458630058929057793",
  "text" : "RT @FLOTUS: .@JoiningForces is turning 3! Ask the First Lady &amp; @DrBiden your questions about supporting our military families using #Joinin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 1, 15 ],
        "id_str" : "26278266",
        "id" : 26278266
      }, {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 55, 63 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458598313244508160",
    "text" : ".@JoiningForces is turning 3! Ask the First Lady &amp; @DrBiden your questions about supporting our military families using #JoiningForces.",
    "id" : 458598313244508160,
    "created_at" : "2014-04-22 13:28:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 458630058929057793,
  "created_at" : "2014-04-22 15:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 98, 107 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458627736563879937",
  "text" : "RT @SecretaryJewell: Happy #EarthDay! Celebrate by visiting your public lands, which great people @Interior care for every day for this &amp; f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 77, 86 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 6, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458623360235503617",
    "text" : "Happy #EarthDay! Celebrate by visiting your public lands, which great people @Interior care for every day for this &amp; future generations. SJ",
    "id" : 458623360235503617,
    "created_at" : "2014-04-22 15:08:24 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 458627736563879937,
  "created_at" : "2014-04-22 15:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/458621539647107072\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hc2OfnupGX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl1Z3DiCAAAL7qE.jpg",
      "id_str" : "458621539437379584",
      "id" : 458621539437379584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl1Z3DiCAAAL7qE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hc2OfnupGX"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 69, 82 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/8VFtPymmQV",
      "expanded_url" : "http:\/\/go.wh.gov\/m5hxL8",
      "display_url" : "go.wh.gov\/m5hxL8"
    } ]
  },
  "geo" : { },
  "id_str" : "458621539647107072",
  "text" : "12 of the hottest years on record have come since 1998.\nIt's time to #ActOnClimate. http:\/\/t.co\/8VFtPymmQV #EarthDay http:\/\/t.co\/hc2OfnupGX",
  "id" : 458621539647107072,
  "created_at" : "2014-04-22 15:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/458613796039188482\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HlbT3CFXoO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl1S0USCAAEcuzj.jpg",
      "id_str" : "458613795812671489",
      "id" : 458613795812671489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl1S0USCAAEcuzj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HlbT3CFXoO"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 25, 38 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/8VFtPymmQV",
      "expanded_url" : "http:\/\/go.wh.gov\/m5hxL8",
      "display_url" : "go.wh.gov\/m5hxL8"
    } ]
  },
  "geo" : { },
  "id_str" : "458613796039188482",
  "text" : "We owe it to our kids to #ActOnClimate change. Share President Obama's plan \u2192 http:\/\/t.co\/8VFtPymmQV #EarthDay http:\/\/t.co\/HlbT3CFXoO",
  "id" : 458613796039188482,
  "created_at" : "2014-04-22 14:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/N4dotou4lA",
      "expanded_url" : "http:\/\/go.wh.gov\/ocUY3z",
      "display_url" : "go.wh.gov\/ocUY3z"
    } ]
  },
  "geo" : { },
  "id_str" : "458601279502434304",
  "text" : "\"When Americans unite in common purpose, we can overcome any obstacle.\" \u2014President Obama: http:\/\/t.co\/N4dotou4lA #ActOnClimate #EarthDay",
  "id" : 458601279502434304,
  "created_at" : "2014-04-22 13:40:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhereTheWildThingsAre",
      "indices" : [ 54, 76 ]
    }, {
      "text" : "EasterEggRoll",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/1Ww5hbKF7e",
      "expanded_url" : "http:\/\/youtu.be\/fMMVn6w_KVc",
      "display_url" : "youtu.be\/fMMVn6w_KVc"
    } ]
  },
  "geo" : { },
  "id_str" : "458382196399947776",
  "text" : "\"Let the wild rumpus start!\" \u2014President Obama reading #WhereTheWildThingsAre at the White House #EasterEggRoll: http:\/\/t.co\/1Ww5hbKF7e",
  "id" : 458382196399947776,
  "created_at" : "2014-04-21 23:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 3, 13 ],
      "id_str" : "11026952",
      "id" : 11026952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 127, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458347735125860353",
  "text" : "RT @MiamiHEAT: To our troops, veterans &amp; military families: Thank you for your service and sacrifice. Happy Anniversary to #JoiningForces. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 112, 126 ]
      }, {
        "text" : "HoopsForTroops",
        "indices" : [ 128, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458338666847694850",
    "text" : "To our troops, veterans &amp; military families: Thank you for your service and sacrifice. Happy Anniversary to #JoiningForces. #HoopsForTroops",
    "id" : 458338666847694850,
    "created_at" : "2014-04-21 20:17:08 +0000",
    "user" : {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "protected" : false,
      "id_str" : "11026952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798740661449134081\/CO3PJbBB_normal.jpg",
      "id" : 11026952,
      "verified" : true
    }
  },
  "id" : 458347735125860353,
  "created_at" : "2014-04-21 20:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 61, 68 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 75, 83 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/shIQ4PZBup",
      "expanded_url" : "http:\/\/go.wh.gov\/YvAsA7",
      "display_url" : "go.wh.gov\/YvAsA7"
    } ]
  },
  "geo" : { },
  "id_str" : "458334528474738688",
  "text" : "RT @JoiningForces: On the 3rd anniversary of #JoiningForces, @FLOTUS &amp; @DrBiden are answering your questions \u2192 http:\/\/t.co\/shIQ4PZBup\n\nAsk \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 42, 49 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 56, 64 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 26, 40 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 129, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/shIQ4PZBup",
        "expanded_url" : "http:\/\/go.wh.gov\/YvAsA7",
        "display_url" : "go.wh.gov\/YvAsA7"
      } ]
    },
    "geo" : { },
    "id_str" : "458327419057762304",
    "text" : "On the 3rd anniversary of #JoiningForces, @FLOTUS &amp; @DrBiden are answering your questions \u2192 http:\/\/t.co\/shIQ4PZBup\n\nAsk with #JoiningForces",
    "id" : 458327419057762304,
    "created_at" : "2014-04-21 19:32:26 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 458334528474738688,
  "created_at" : "2014-04-21 20:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/a2u1AoqjnQ",
      "expanded_url" : "http:\/\/bit.ly\/1i2VJ3Y",
      "display_url" : "bit.ly\/1i2VJ3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "458323498935787520",
  "text" : "RT @LaborSec: Glad to see tipped workers get a minwage raise in 4 states: http:\/\/t.co\/a2u1AoqjnQ. It's past time to #RaiseTheWage for them \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/a2u1AoqjnQ",
        "expanded_url" : "http:\/\/bit.ly\/1i2VJ3Y",
        "display_url" : "bit.ly\/1i2VJ3Y"
      } ]
    },
    "geo" : { },
    "id_str" : "458303928682426368",
    "text" : "Glad to see tipped workers get a minwage raise in 4 states: http:\/\/t.co\/a2u1AoqjnQ. It's past time to #RaiseTheWage for them nationally.",
    "id" : 458303928682426368,
    "created_at" : "2014-04-21 17:59:06 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 458323498935787520,
  "created_at" : "2014-04-21 19:16:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458321609036939265",
  "text" : "RT @GinaEPA: Cheering on the Boston Marathon racers today with my family. So proud of this city and these runners. #BostonStrong http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/458267966249775104\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/whQTuXgnWA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlwYSYyCMAEBaMP.jpg",
        "id_str" : "458267966253969409",
        "id" : 458267966253969409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlwYSYyCMAEBaMP.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/whQTuXgnWA"
      } ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458267966249775104",
    "text" : "Cheering on the Boston Marathon racers today with my family. So proud of this city and these runners. #BostonStrong http:\/\/t.co\/whQTuXgnWA",
    "id" : 458267966249775104,
    "created_at" : "2014-04-21 15:36:12 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 458321609036939265,
  "created_at" : "2014-04-21 19:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meb keflezighi",
      "screen_name" : "runmeb",
      "indices" : [ 12, 19 ],
      "id_str" : "69002830",
      "id" : 69002830
    }, {
      "name" : "Shalane Flanagan",
      "screen_name" : "ShalaneFlanagan",
      "indices" : [ 24, 40 ],
      "id_str" : "174893399",
      "id" : 174893399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458298019755339776",
  "text" : "Congrats to @RunMeb and @ShalaneFlanagan for making America proud! All of today's runners showed the world the meaning of #BostonStrong. -bo",
  "id" : 458298019755339776,
  "created_at" : "2014-04-21 17:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarathonMonday",
      "indices" : [ 61, 76 ]
    }, {
      "text" : "WeRunTogether",
      "indices" : [ 129, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458289027729592320",
  "text" : "RT @JohnKerry: Proud to see runners &amp; Bostonians reclaim #MarathonMonday. Triumph for all those tested by tragedy last year. #WeRunTogether\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarathonMonday",
        "indices" : [ 46, 61 ]
      }, {
        "text" : "WeRunTogether",
        "indices" : [ 114, 128 ]
      }, {
        "text" : "BostonStrong",
        "indices" : [ 129, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458285893615648769",
    "text" : "Proud to see runners &amp; Bostonians reclaim #MarathonMonday. Triumph for all those tested by tragedy last year. #WeRunTogether #BostonStrong",
    "id" : 458285893615648769,
    "created_at" : "2014-04-21 16:47:26 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 458289027729592320,
  "created_at" : "2014-04-21 16:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458287264788140032",
  "text" : "RT @DrBiden: Sending love &amp; support to everyone running today. -Jill #BostonStrong",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "458284972026392576",
    "text" : "Sending love &amp; support to everyone running today. -Jill #BostonStrong",
    "id" : 458284972026392576,
    "created_at" : "2014-04-21 16:43:46 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 458287264788140032,
  "created_at" : "2014-04-21 16:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/PROuvSEGYd",
      "expanded_url" : "http:\/\/go.wh.gov\/NJxZsz",
      "display_url" : "go.wh.gov\/NJxZsz"
    } ]
  },
  "geo" : { },
  "id_str" : "458277057626386432",
  "text" : "Here are the 10 most eggcellent reasons why you should tune in to today's White House #EasterEggRoll \u2192 http:\/\/t.co\/PROuvSEGYd",
  "id" : 458277057626386432,
  "created_at" : "2014-04-21 16:12:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 35, 42 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/jeqH3zzuwF",
      "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
      "display_url" : "wh.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "458253233178566657",
  "text" : "Happening now: President Obama and @FLOTUS speak at the White House #EasterEggRoll \u2192 http:\/\/t.co\/jeqH3zzuwF",
  "id" : 458253233178566657,
  "created_at" : "2014-04-21 14:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/458081124032716800\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/egVcCl9CBi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BltuWuiIEAADbDj.jpg",
      "id_str" : "458081123835580416",
      "id" : 458081123835580416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BltuWuiIEAADbDj.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/egVcCl9CBi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458081124032716800",
  "text" : "Happy Easter! http:\/\/t.co\/egVcCl9CBi",
  "id" : 458081124032716800,
  "created_at" : "2014-04-21 03:13:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/hgUL4tiZb7",
      "expanded_url" : "http:\/\/go.wh.gov\/tRdDCD",
      "display_url" : "go.wh.gov\/tRdDCD"
    } ]
  },
  "geo" : { },
  "id_str" : "457911661546848256",
  "text" : "\"We recommit ourselves to following His example, to love and serve one another.\" \u2014Obama on Easter and Passover: http:\/\/t.co\/hgUL4tiZb7",
  "id" : 457911661546848256,
  "created_at" : "2014-04-20 16:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hgUL4tiZb7",
      "expanded_url" : "http:\/\/go.wh.gov\/tRdDCD",
      "display_url" : "go.wh.gov\/tRdDCD"
    } ]
  },
  "geo" : { },
  "id_str" : "457881459886268416",
  "text" : "\"To all Christians who are celebrating, from my family to yours, Happy Easter.\" \u2014President Obama: http:\/\/t.co\/hgUL4tiZb7",
  "id" : 457881459886268416,
  "created_at" : "2014-04-20 14:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/hgUL4tiZb7",
      "expanded_url" : "http:\/\/go.wh.gov\/tRdDCD",
      "display_url" : "go.wh.gov\/tRdDCD"
    } ]
  },
  "geo" : { },
  "id_str" : "457549267322691584",
  "text" : "\"For me and for countless other Christians, Holy Week &amp; Easter are times for reflection &amp; renewal.\" \u2014President Obama: http:\/\/t.co\/hgUL4tiZb7",
  "id" : 457549267322691584,
  "created_at" : "2014-04-19 16:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/hgUL4tiZb7",
      "expanded_url" : "http:\/\/go.wh.gov\/tRdDCD",
      "display_url" : "go.wh.gov\/tRdDCD"
    } ]
  },
  "geo" : { },
  "id_str" : "457526613672865794",
  "text" : "\"The common thread of humanity...is our shared commitment to love our neighbors as we love ourselves.\" \u2014Obama: http:\/\/t.co\/hgUL4tiZb7",
  "id" : 457526613672865794,
  "created_at" : "2014-04-19 14:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/457280533920092160\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/q4fGZX9IBp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BliWOQtCEAAHv0x.jpg",
      "id_str" : "457280533924286464",
      "id" : 457280533924286464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BliWOQtCEAAHv0x.jpg",
      "sizes" : [ {
        "h" : 1212,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1212,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/q4fGZX9IBp"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457282758768070656",
  "text" : "RT @USDOL: If we #RaiseTheWage, here's how many workers would be impacted in your state: http:\/\/t.co\/q4fGZX9IBp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/457280533920092160\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/q4fGZX9IBp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BliWOQtCEAAHv0x.jpg",
        "id_str" : "457280533924286464",
        "id" : 457280533924286464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BliWOQtCEAAHv0x.jpg",
        "sizes" : [ {
          "h" : 1212,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1212,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 745,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/q4fGZX9IBp"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 6, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "457280533920092160",
    "text" : "If we #RaiseTheWage, here's how many workers would be impacted in your state: http:\/\/t.co\/q4fGZX9IBp",
    "id" : 457280533920092160,
    "created_at" : "2014-04-18 22:12:29 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 457282758768070656,
  "created_at" : "2014-04-18 22:21:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ComfortTech",
      "screen_name" : "ComfortTechBand",
      "indices" : [ 4, 20 ],
      "id_str" : "2450862488",
      "id" : 2450862488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BarackNRoll",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VnjnXoUAM8",
      "expanded_url" : "http:\/\/youtu.be\/bsZSM6zE7k8",
      "display_url" : "youtu.be\/bsZSM6zE7k8"
    } ]
  },
  "geo" : { },
  "id_str" : "457263368089632768",
  "text" : "Hey @ComfortTechBand, the President really enjoyed meeting you. Remember to send over your next album: http:\/\/t.co\/VnjnXoUAM8 #BarackNRoll \u266B",
  "id" : 457263368089632768,
  "created_at" : "2014-04-18 21:04:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2yYPdM181P",
      "expanded_url" : "http:\/\/go.wh.gov\/3d8fy4",
      "display_url" : "go.wh.gov\/3d8fy4"
    } ]
  },
  "geo" : { },
  "id_str" : "457238824377413632",
  "text" : "Everyone deserves the peace of mind that comes with health insurance.\nIf you recently got covered, share your story \u2192 http:\/\/t.co\/2yYPdM181P",
  "id" : 457238824377413632,
  "created_at" : "2014-04-18 19:26:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naval Academy",
      "screen_name" : "NavalAcademy",
      "indices" : [ 126, 139 ],
      "id_str" : "18090660",
      "id" : 18090660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457219103384928256",
  "text" : "\"That\u2019s what camaraderie is all about. Honor. Courage. Commitment. That\u2019s what makes the Midshipmen so strong.\" \u2014Obama on the @NavalAcademy",
  "id" : 457219103384928256,
  "created_at" : "2014-04-18 18:08:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naval Academy",
      "screen_name" : "NavalAcademy",
      "indices" : [ 74, 87 ],
      "id_str" : "18090660",
      "id" : 18090660
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/457217111580880898\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/oG9o8G6nK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlhciljCAAEBnjj.jpg",
      "id_str" : "457217111442456577",
      "id" : 457217111442456577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlhciljCAAEBnjj.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oG9o8G6nK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/tULBCZ7Rh0",
      "expanded_url" : "http:\/\/go.wh.gov\/wZYvjJ",
      "display_url" : "go.wh.gov\/wZYvjJ"
    } ]
  },
  "geo" : { },
  "id_str" : "457217111580880898",
  "text" : "Watch live: President Obama presents the Commander-in-Chief Trophy to the @NavalAcademy \u2192 http:\/\/t.co\/tULBCZ7Rh0 http:\/\/t.co\/oG9o8G6nK1",
  "id" : 457217111580880898,
  "created_at" : "2014-04-18 18:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "ACA",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2yYPdM181P",
      "expanded_url" : "http:\/\/go.wh.gov\/3d8fy4",
      "display_url" : "go.wh.gov\/3d8fy4"
    } ]
  },
  "geo" : { },
  "id_str" : "457206895024279552",
  "text" : "#8Million Americans have signed up for private health plans thanks to the #ACA. Share your story if you're 1 of them: http:\/\/t.co\/2yYPdM181P",
  "id" : 457206895024279552,
  "created_at" : "2014-04-18 17:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 28, 38 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/qwHwCuLs5E",
      "expanded_url" : "http:\/\/bit.ly\/1eI5gmj",
      "display_url" : "bit.ly\/1eI5gmj"
    } ]
  },
  "geo" : { },
  "id_str" : "457202115044466688",
  "text" : "RT @Simas44: Yep, way more. @voxdotcom Way more than 8 million people have signed up for Obamacare. http:\/\/t.co\/qwHwCuLs5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vox",
        "screen_name" : "voxdotcom",
        "indices" : [ 15, 25 ],
        "id_str" : "2347049341",
        "id" : 2347049341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/qwHwCuLs5E",
        "expanded_url" : "http:\/\/bit.ly\/1eI5gmj",
        "display_url" : "bit.ly\/1eI5gmj"
      } ]
    },
    "geo" : { },
    "id_str" : "457199279955005440",
    "text" : "Yep, way more. @voxdotcom Way more than 8 million people have signed up for Obamacare. http:\/\/t.co\/qwHwCuLs5E",
    "id" : 457199279955005440,
    "created_at" : "2014-04-18 16:49:37 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 457202115044466688,
  "created_at" : "2014-04-18 17:00:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/cImAzgey8E",
      "expanded_url" : "http:\/\/go.wh.gov\/tKmjpF",
      "display_url" : "go.wh.gov\/tKmjpF"
    } ]
  },
  "geo" : { },
  "id_str" : "457188152126754816",
  "text" : "RT @PressSec: \"Tell your story. Make sure people know what it is we're trying to get done.\" \u2014President Obama: http:\/\/t.co\/cImAzgey8E #ACAWo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 119, 128 ]
      }, {
        "text" : "8Million",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/cImAzgey8E",
        "expanded_url" : "http:\/\/go.wh.gov\/tKmjpF",
        "display_url" : "go.wh.gov\/tKmjpF"
      } ]
    },
    "geo" : { },
    "id_str" : "457182264603181056",
    "text" : "\"Tell your story. Make sure people know what it is we're trying to get done.\" \u2014President Obama: http:\/\/t.co\/cImAzgey8E #ACAWorks #8Million",
    "id" : 457182264603181056,
    "created_at" : "2014-04-18 15:42:00 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 457188152126754816,
  "created_at" : "2014-04-18 16:05:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 115, 124 ]
    }, {
      "text" : "8Million",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/enI54OZnM1",
      "expanded_url" : "http:\/\/go.wh.gov\/tKmjpF",
      "display_url" : "go.wh.gov\/tKmjpF"
    } ]
  },
  "geo" : { },
  "id_str" : "457175542110752769",
  "text" : "\"I was paying $10,000\/year for insurance and now I'm paying less than $1,500\/year.\"\nWatch \u2192 http:\/\/t.co\/enI54OZnM1 #ACAWorks #8Million",
  "id" : 457175542110752769,
  "created_at" : "2014-04-18 15:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VK6iFQIjT1",
      "expanded_url" : "http:\/\/go.wh.gov\/tKmjpF",
      "display_url" : "go.wh.gov\/tKmjpF"
    } ]
  },
  "geo" : { },
  "id_str" : "457169021310603264",
  "text" : "\"You saved our son's life.\"\nWatch President Obama meet 6 families who wrote to him on how the #ACA is helping them \u2192 http:\/\/t.co\/VK6iFQIjT1",
  "id" : 457169021310603264,
  "created_at" : "2014-04-18 14:49:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456929144866373632\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/E7NIo24f3y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BldWot9IIAAJFh-.png",
      "id_str" : "456929144732131328",
      "id" : 456929144732131328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BldWot9IIAAJFh-.png",
      "sizes" : [ {
        "h" : 415,
        "resize" : "fit",
        "w" : 936
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 936
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E7NIo24f3y"
    } ],
    "hashtags" : [ {
      "text" : "GraciasGabo",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/6krPIVgzDO",
      "expanded_url" : "http:\/\/go.wh.gov\/Z4Ui1f",
      "display_url" : "go.wh.gov\/Z4Ui1f"
    } ]
  },
  "geo" : { },
  "id_str" : "456929144866373632",
  "text" : "#GraciasGabo. http:\/\/t.co\/6krPIVgzDO, http:\/\/t.co\/E7NIo24f3y",
  "id" : 456929144866373632,
  "created_at" : "2014-04-17 22:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456927273590222848",
  "text" : "RT @Interior: Did you know that fees are waived this weekend on all of America's National Parks? RT to spread the word!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456927036570087424",
    "text" : "Did you know that fees are waived this weekend on all of America's National Parks? RT to spread the word!",
    "id" : 456927036570087424,
    "created_at" : "2014-04-17 22:47:49 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 456927273590222848,
  "created_at" : "2014-04-17 22:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456918371372523520\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/OzrwD4aLeI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BldM1m2CEAAVSJ7.jpg",
      "id_str" : "456918371045347328",
      "id" : 456918371045347328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BldM1m2CEAAVSJ7.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OzrwD4aLeI"
    } ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456918371372523520",
  "text" : "FACT: 35% of those who enrolled through the federal Affordable Care Act marketplace are under 35. #8Million http:\/\/t.co\/OzrwD4aLeI",
  "id" : 456918371372523520,
  "created_at" : "2014-04-17 22:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456890379522936832\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/t4lQlusjbt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlczYROCUAAU8W7.jpg",
      "id_str" : "456890379233546240",
      "id" : 456890379233546240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlczYROCUAAU8W7.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/t4lQlusjbt"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "8Million",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456890379522936832",
  "text" : "\"We are a nation that does what is hard. What is necessary. What is right.\" \u2014Obama signing the ACA #TBT #8Million http:\/\/t.co\/t4lQlusjbt",
  "id" : 456890379522936832,
  "created_at" : "2014-04-17 20:22:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/456885621211295744\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/efl948lfbO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlcvDTXIEAAYSuF.jpg",
      "id_str" : "456885620984778752",
      "id" : 456885620984778752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlcvDTXIEAAYSuF.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/efl948lfbO"
    } ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456885621211295744",
  "text" : "President Obama: \u201CWe\u2019re going to keep on doing what we\u2019re doing, which is making this work.\u201D #8Million http:\/\/t.co\/efl948lfbO",
  "id" : 456885621211295744,
  "created_at" : "2014-04-17 20:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456883611825111040",
  "text" : "RT @NancyPelosi: Great news:\u00A0#8Million Americans\u00A0have signed up for private health plans thanks to the Affordable Care Act. http:\/\/t.co\/JFa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/456882393874325504\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/JFa2rU8uJO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlcsHdCCIAAHURF.jpg",
        "id_str" : "456882393765257216",
        "id" : 456882393765257216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlcsHdCCIAAHURF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/JFa2rU8uJO"
      } ],
      "hashtags" : [ {
        "text" : "8Million",
        "indices" : [ 12, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456882393874325504",
    "text" : "Great news:\u00A0#8Million Americans\u00A0have signed up for private health plans thanks to the Affordable Care Act. http:\/\/t.co\/JFa2rU8uJO",
    "id" : 456882393874325504,
    "created_at" : "2014-04-17 19:50:25 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 456883611825111040,
  "created_at" : "2014-04-17 19:55:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456881271151407104",
  "text" : "\"The 50 or so votes Republicans have taken to repeal this law could have been 50 votes to create jobs.\" \u2014President Obama #8Million",
  "id" : 456881271151407104,
  "created_at" : "2014-04-17 19:45:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456881080168357888",
  "text" : "\"They still can\u2019t bring themselves to admit that the Affordable Care Act is working.\" \u2014Obama on Congressional Republicans #8Million",
  "id" : 456881080168357888,
  "created_at" : "2014-04-17 19:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456880971464589312",
  "text" : "\u201CNo woman can be charged more just for being a woman. Those days are over.\u201D \u2014President Obama #8Million #WomenSucceed",
  "id" : 456880971464589312,
  "created_at" : "2014-04-17 19:44:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456880895387922432",
  "text" : "\"No American with a pre-existing condition like asthma or cancer can be denied coverage.\" \u2014President Obama #8Million",
  "id" : 456880895387922432,
  "created_at" : "2014-04-17 19:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456880778660413440",
  "text" : "\"Under the Affordable Care Act, the share of Americans with insurance is up, the growth of health care costs is down.\" \u2014Obama #8Million",
  "id" : 456880778660413440,
  "created_at" : "2014-04-17 19:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456880555343478784",
  "text" : "President Obama: \"Millions of Americans who were uninsured have gained coverage this year\u2014with millions more to come.\" #8Million",
  "id" : 456880555343478784,
  "created_at" : "2014-04-17 19:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456880443548119040",
  "text" : "President Obama: \"35% of people who enrolled through the federal marketplace are under the age of 35.\" #8Million",
  "id" : 456880443548119040,
  "created_at" : "2014-04-17 19:42:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456880311457316864\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/PPOa6VwySI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlcqOO0IAAAgS52.jpg",
      "id_str" : "456880311184654336",
      "id" : 456880311184654336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlcqOO0IAAAgS52.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PPOa6VwySI"
    } ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456880311457316864",
  "text" : "President Obama: \"The number of Americans who\u2019ve signed up for private insurance...has grown to #8Million.\" http:\/\/t.co\/PPOa6VwySI",
  "id" : 456880311457316864,
  "created_at" : "2014-04-17 19:42:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ODxwMltMAz",
      "expanded_url" : "http:\/\/go.wh.gov\/Ra2kN9",
      "display_url" : "go.wh.gov\/Ra2kN9"
    } ]
  },
  "geo" : { },
  "id_str" : "456879944959025154",
  "text" : "Happening now: President Obama speaks from the Briefing Room on the Affordable Care Act. Watch \u2192 http:\/\/t.co\/ODxwMltMAz",
  "id" : 456879944959025154,
  "created_at" : "2014-04-17 19:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456868692882509824",
  "text" : "RT @JoiningForces: \"Your resolve, your resilience, your tenacity, your optimism\u2014it makes me proud to be your Commander-in-Chief\" \u2014Obama htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1MOihvu4dA",
        "expanded_url" : "https:\/\/vine.co\/v\/M1h19B5gMVn",
        "display_url" : "vine.co\/v\/M1h19B5gMVn"
      } ]
    },
    "geo" : { },
    "id_str" : "456868416973205504",
    "text" : "\"Your resolve, your resilience, your tenacity, your optimism\u2014it makes me proud to be your Commander-in-Chief\" \u2014Obama https:\/\/t.co\/1MOihvu4dA",
    "id" : 456868416973205504,
    "created_at" : "2014-04-17 18:54:53 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 456868692882509824,
  "created_at" : "2014-04-17 18:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/456842935774879744\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/X1X5YIiS0q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlcIOr-CUAADLzg.png",
      "id_str" : "456842935615508480",
      "id" : 456842935615508480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlcIOr-CUAADLzg.png",
      "sizes" : [ {
        "h" : 125,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 955
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 955
      } ],
      "display_url" : "pic.twitter.com\/X1X5YIiS0q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/S28QD2nN4o",
      "expanded_url" : "http:\/\/go.wh.gov\/ueax97",
      "display_url" : "go.wh.gov\/ueax97"
    } ]
  },
  "geo" : { },
  "id_str" : "456842935774879744",
  "text" : "\"Our hearts ache to see our Korean friends going through such a terrible loss.\" \u2014Obama: http:\/\/t.co\/S28QD2nN4o, http:\/\/t.co\/X1X5YIiS0q",
  "id" : 456842935774879744,
  "created_at" : "2014-04-17 17:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456824139894906880",
  "text" : "FACT: Every 4 minutes, another American home or business goes solar.\n\nRT if a building in your community is one of them. #ActOnClimate",
  "id" : 456824139894906880,
  "created_at" : "2014-04-17 15:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456812242890010624",
  "text" : "\"Your courage, your resolve, your resilience...it makes me proud to be your Commander-in-Chief.\" \u2014President Obama to Wounded Warriors",
  "id" : 456812242890010624,
  "created_at" : "2014-04-17 15:11:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/yexukMrlnL",
      "expanded_url" : "http:\/\/go.wh.gov\/JJ13gH",
      "display_url" : "go.wh.gov\/JJ13gH"
    } ]
  },
  "geo" : { },
  "id_str" : "456810905829789696",
  "text" : "Happening now: President Obama speaks at the 7th annual Wounded Warrior Project's Soldier Ride \u2192 http:\/\/t.co\/yexukMrlnL",
  "id" : 456810905829789696,
  "created_at" : "2014-04-17 15:06:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Ja4nOC30D5",
      "expanded_url" : "http:\/\/go.wh.gov\/AHBbgi",
      "display_url" : "go.wh.gov\/AHBbgi"
    } ]
  },
  "geo" : { },
  "id_str" : "456806854933233664",
  "text" : "Get the latest on how President Obama is supporting solar power deployment and clean energy jobs \u2192 http:\/\/t.co\/Ja4nOC30D5 #ActOnClimate",
  "id" : 456806854933233664,
  "created_at" : "2014-04-17 14:50:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Ja4nOC30D5",
      "expanded_url" : "http:\/\/go.wh.gov\/AHBbgi",
      "display_url" : "go.wh.gov\/AHBbgi"
    } ]
  },
  "geo" : { },
  "id_str" : "456799212194111489",
  "text" : "Solar power is more affordable than ever: The average cost of solar panels has dropped 60% since 2010 \u2192 http:\/\/t.co\/Ja4nOC30D5 #ActOnClimate",
  "id" : 456799212194111489,
  "created_at" : "2014-04-17 14:19:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/a4Fcexuw7l",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "456786977208008704",
  "text" : "RT @ErnestMoniz: Join me in congratulating the @WhiteHouse solar deployment Champions of Change, happening now \u2192 http:\/\/t.co\/a4Fcexuw7l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 30, 41 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/a4Fcexuw7l",
        "expanded_url" : "http:\/\/whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "456781933293211648",
    "text" : "Join me in congratulating the @WhiteHouse solar deployment Champions of Change, happening now \u2192 http:\/\/t.co\/a4Fcexuw7l",
    "id" : 456781933293211648,
    "created_at" : "2014-04-17 13:11:14 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 456786977208008704,
  "created_at" : "2014-04-17 13:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solar",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/tGzDVTn2v7",
      "expanded_url" : "http:\/\/m.washingtonpost.com\/national\/health-science\/obama-to-challenge-private-companies-to-boost-solar-power-use\/2014\/04\/16\/76bd2b20-c5a3-11e3-bf7a-be01a9b69cf1_story.html?tid=hpModule_ba0d4c2a-86a2-11e2-9d71-f0feafdd1394&hpid=z10",
      "display_url" : "m.washingtonpost.com\/national\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456784995139321858",
  "text" : "RT @Podesta44: Clean #solar power is more affordable than ever. We're announcing new efforts to expand solar: http:\/\/t.co\/tGzDVTn2v7 #ActOn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "solar",
        "indices" : [ 6, 12 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 118, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/tGzDVTn2v7",
        "expanded_url" : "http:\/\/m.washingtonpost.com\/national\/health-science\/obama-to-challenge-private-companies-to-boost-solar-power-use\/2014\/04\/16\/76bd2b20-c5a3-11e3-bf7a-be01a9b69cf1_story.html?tid=hpModule_ba0d4c2a-86a2-11e2-9d71-f0feafdd1394&hpid=z10",
        "display_url" : "m.washingtonpost.com\/national\/healt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456783254247333888",
    "text" : "Clean #solar power is more affordable than ever. We're announcing new efforts to expand solar: http:\/\/t.co\/tGzDVTn2v7 #ActOnClimate",
    "id" : 456783254247333888,
    "created_at" : "2014-04-17 13:16:29 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 456784995139321858,
  "created_at" : "2014-04-17 13:23:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456603722101964800\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/yt5MjtLYPi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlYuqnqCIAA0z9p.jpg",
      "id_str" : "456603721959350272",
      "id" : 456603721959350272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlYuqnqCIAA0z9p.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yt5MjtLYPi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456603722101964800",
  "text" : "Pals. http:\/\/t.co\/yt5MjtLYPi",
  "id" : 456603722101964800,
  "created_at" : "2014-04-17 01:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 59, 77 ]
    }, {
      "text" : "CostOfInaction",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/PwUpT7Qcd3",
      "expanded_url" : "http:\/\/go.wh.gov\/p17JnH",
      "display_url" : "go.wh.gov\/p17JnH"
    } ]
  },
  "geo" : { },
  "id_str" : "456574795199422464",
  "text" : "1 year ago today, the Senate introduced &amp; later passed #ImmigrationReform.\n\nThe House has yet to act: http:\/\/t.co\/PwUpT7Qcd3 #CostOfInaction",
  "id" : 456574795199422464,
  "created_at" : "2014-04-16 23:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 48, 66 ]
    }, {
      "text" : "CostOfInaction",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/PwUpT7Qcd3",
      "expanded_url" : "http:\/\/go.wh.gov\/p17JnH",
      "display_url" : "go.wh.gov\/p17JnH"
    } ]
  },
  "geo" : { },
  "id_str" : "456559159022866432",
  "text" : "Here's how House Republicans' failure to act on #ImmigrationReform is hurting our economy \u2192 http:\/\/t.co\/PwUpT7Qcd3 #CostOfInaction",
  "id" : 456559159022866432,
  "created_at" : "2014-04-16 22:26:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/3kbmGDcaVA",
      "expanded_url" : "http:\/\/go.wh.gov\/d3zUZa",
      "display_url" : "go.wh.gov\/d3zUZa"
    } ]
  },
  "geo" : { },
  "id_str" : "456543039712817154",
  "text" : "Here's a pretty awesome story about how job training programs can turn your life around \u2192 http:\/\/t.co\/3kbmGDcaVA #ActOnJobs",
  "id" : 456543039712817154,
  "created_at" : "2014-04-16 21:21:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456539552291639296",
  "text" : "RT @LaborSec: Learn about new job training initiatives to give Americans critical skills &amp; build a stronger middle class http:\/\/t.co\/HW6EJL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnJobs",
        "indices" : [ 134, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/HW6EJLMBgD",
        "expanded_url" : "http:\/\/wh.gov\/lwxWW",
        "display_url" : "wh.gov\/lwxWW"
      } ]
    },
    "geo" : { },
    "id_str" : "456538503635955714",
    "text" : "Learn about new job training initiatives to give Americans critical skills &amp; build a stronger middle class http:\/\/t.co\/HW6EJLMBgD #ActOnJobs",
    "id" : 456538503635955714,
    "created_at" : "2014-04-16 21:03:56 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 456539552291639296,
  "created_at" : "2014-04-16 21:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456530526623764480",
  "text" : "\"Everybody who works hard and takes responsibility deserves the chance to get ahead. That's what this country is built on.\" \u2014President Obama",
  "id" : 456530526623764480,
  "created_at" : "2014-04-16 20:32:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456529691860402176\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/j77Je1QyaS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlXrVfOCAAAXvtt.jpg",
      "id_str" : "456529691638104064",
      "id" : 456529691638104064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlXrVfOCAAAXvtt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j77Je1QyaS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456529691860402176",
  "text" : "\"Nearly 9 out of 10 apprentices get hired when they\u2019re finished.\" \u2014Obama on expanding apprenticeship programs http:\/\/t.co\/j77Je1QyaS",
  "id" : 456529691860402176,
  "created_at" : "2014-04-16 20:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456528766077251584",
  "text" : "Obama: \"I\u2019ve asked Congress to invest in serious programs that connect ready-to-work Americans with ready-to-be-filled jobs.\" #ActOnJobs",
  "id" : 456528766077251584,
  "created_at" : "2014-04-16 20:25:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456528590746955776",
  "text" : "RT @WHLive: Obama: \"We\u2019re working with a bipartisan coalition of governors and mayors...to make job training partnerships a reality for mor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456528553103097856",
    "text" : "Obama: \"We\u2019re working with a bipartisan coalition of governors and mayors...to make job training partnerships a reality for more Americans.\"",
    "id" : 456528553103097856,
    "created_at" : "2014-04-16 20:24:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 456528590746955776,
  "created_at" : "2014-04-16 20:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456528401713483776",
  "text" : "Obama: \"We\u2019re rewarding high schools that redesign their curriculums to help students gain ready-to-work skills even earlier.\" #ActOnJobs",
  "id" : 456528401713483776,
  "created_at" : "2014-04-16 20:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456527514069123072",
  "text" : "\"I want to focus on...training more Americans with the skills they need for the good jobs of today &amp; tomorrow.\" \u2014President Obama #ActOnJobs",
  "id" : 456527514069123072,
  "created_at" : "2014-04-16 20:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456526170712862721\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/kfS5SKt2od",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlXoIhOCcAAaczw.jpg",
      "id_str" : "456526170301820928",
      "id" : 456526170301820928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlXoIhOCcAAaczw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kfS5SKt2od"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456526170712862721",
  "text" : "President Obama: \"Our economy is growing again. Our businesses are creating jobs.\" #ActOnJobs http:\/\/t.co\/kfS5SKt2od",
  "id" : 456526170712862721,
  "created_at" : "2014-04-16 20:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456525880425480192",
  "text" : "President Obama: \"I\u2019m taking some new action to expand this kind of job-driven training to all 50 states.\" #ActOnJobs",
  "id" : 456525880425480192,
  "created_at" : "2014-04-16 20:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/4hQMp47d2c",
      "expanded_url" : "http:\/\/go.wh.gov\/P5pt7T",
      "display_url" : "go.wh.gov\/P5pt7T"
    } ]
  },
  "geo" : { },
  "id_str" : "456525503571443712",
  "text" : "Happening now: President Obama speaks on expanding job-training partnerships between businesses &amp; community colleges: http:\/\/t.co\/4hQMp47d2c",
  "id" : 456525503571443712,
  "created_at" : "2014-04-16 20:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 14, 17 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/456516802257100800\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yAvotFvmm7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlXfnN-IQAA61dw.jpg",
      "id_str" : "456516802106114048",
      "id" : 456516802106114048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlXfnN-IQAA61dw.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/yAvotFvmm7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/4hQMp47d2c",
      "expanded_url" : "http:\/\/go.wh.gov\/P5pt7T",
      "display_url" : "go.wh.gov\/P5pt7T"
    } ]
  },
  "geo" : { },
  "id_str" : "456516802257100800",
  "text" : "POTUS and the @VP are in PA to announce new job training initiatives. Watch at 3:45pm ET \u2192 http:\/\/t.co\/4hQMp47d2c, http:\/\/t.co\/yAvotFvmm7",
  "id" : 456516802257100800,
  "created_at" : "2014-04-16 19:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NCGlgxaKw9",
      "expanded_url" : "http:\/\/go.wh.gov\/WXbPe1",
      "display_url" : "go.wh.gov\/WXbPe1"
    } ]
  },
  "geo" : { },
  "id_str" : "456506462203047936",
  "text" : "President Obama is taking new steps to #ActOnJobs by expanding partnerships with businesses and community colleges: http:\/\/t.co\/NCGlgxaKw9",
  "id" : 456506462203047936,
  "created_at" : "2014-04-16 18:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 4, 7 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 26, 36 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456482423878873088\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/4yFJoMYEwI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlXAWIiCYAAF7gp.jpg",
      "id_str" : "456482423727874048",
      "id" : 456482423727874048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlXAWIiCYAAF7gp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4yFJoMYEwI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/pduQcCkFVx",
      "expanded_url" : "http:\/\/instagram.com\/vp",
      "display_url" : "instagram.com\/vp"
    } ]
  },
  "geo" : { },
  "id_str" : "456482423878873088",
  "text" : "The @VP? \u2714\nAviators? \u2714\nOn @Instagram? \u2714\nYou're gonna want to follow along \u2192\nhttp:\/\/t.co\/pduQcCkFVx, http:\/\/t.co\/4yFJoMYEwI",
  "id" : 456482423878873088,
  "created_at" : "2014-04-16 17:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 27, 37 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/geXVSoM6Ev",
      "expanded_url" : "http:\/\/instagram.com\/vp",
      "display_url" : "instagram.com\/vp"
    } ]
  },
  "geo" : { },
  "id_str" : "456477448168038400",
  "text" : "RT @VP: The VP just joined @Instagram \u2192 http:\/\/t.co\/geXVSoM6Ev\n\nFollow along for the latest\u2014and the occasional aviators pic. http:\/\/t.co\/Zc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 19, 29 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/456477384426807297\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ZcW6SR5uuh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlW7wzBCAAAZtvz.jpg",
        "id_str" : "456477384250621952",
        "id" : 456477384250621952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlW7wzBCAAAZtvz.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZcW6SR5uuh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/geXVSoM6Ev",
        "expanded_url" : "http:\/\/instagram.com\/vp",
        "display_url" : "instagram.com\/vp"
      } ]
    },
    "geo" : { },
    "id_str" : "456477384426807297",
    "text" : "The VP just joined @Instagram \u2192 http:\/\/t.co\/geXVSoM6Ev\n\nFollow along for the latest\u2014and the occasional aviators pic. http:\/\/t.co\/ZcW6SR5uuh",
    "id" : 456477384426807297,
    "created_at" : "2014-04-16 17:01:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 456477448168038400,
  "created_at" : "2014-04-16 17:01:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456463904604815361\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/p7qU57tmwR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlWvgKiCUAARVsg.jpg",
      "id_str" : "456463904365760512",
      "id" : 456463904365760512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlWvgKiCUAARVsg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/p7qU57tmwR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456463904604815361",
  "text" : "FACT: After completing their programs, 87% of apprentices have jobs with an avg starting wage of more than $50,000. http:\/\/t.co\/p7qU57tmwR",
  "id" : 456463904604815361,
  "created_at" : "2014-04-16 16:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/NCGlgxaKw9",
      "expanded_url" : "http:\/\/go.wh.gov\/WXbPe1",
      "display_url" : "go.wh.gov\/WXbPe1"
    } ]
  },
  "geo" : { },
  "id_str" : "456445284391063552",
  "text" : "Here's how President Obama's helping more Americans learn the skills they need for good middle-class jobs: http:\/\/t.co\/NCGlgxaKw9 #ActOnJobs",
  "id" : 456445284391063552,
  "created_at" : "2014-04-16 14:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 36, 43 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456256305414410240\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xnY7LYOUeR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlTysTUCMAAkqH9.jpg",
      "id_str" : "456256305183731712",
      "id" : 456256305183731712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlTysTUCMAAkqH9.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xnY7LYOUeR"
    } ],
    "hashtags" : [ {
      "text" : "HappyPassover",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456256305414410240",
  "text" : "#HappyPassover! President Obama and @FLOTUS host a Seder at the White House. http:\/\/t.co\/xnY7LYOUeR",
  "id" : 456256305414410240,
  "created_at" : "2014-04-16 02:22:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456186369854152705\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GXpaSA49Dx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlSzFhKIAAA-Hg8.jpg",
      "id_str" : "456186369652817920",
      "id" : 456186369652817920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlSzFhKIAAA-Hg8.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GXpaSA49Dx"
    } ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456186369854152705",
  "text" : "President Obama observes a moment of silence to honor victims of last year's Boston Marathon bombing. #BostonStrong http:\/\/t.co\/GXpaSA49Dx",
  "id" : 456186369854152705,
  "created_at" : "2014-04-15 21:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456163885737725953\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/z4Oe0xsgQA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlSeoxNCEAAXmO3.jpg",
      "id_str" : "456163885511217152",
      "id" : 456163885511217152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlSeoxNCEAAXmO3.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/z4Oe0xsgQA"
    } ],
    "hashtags" : [ {
      "text" : "JackieRobinsonDay",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456163885737725953",
  "text" : "Here's to #42. #JackieRobinsonDay http:\/\/t.co\/z4Oe0xsgQA",
  "id" : 456163885737725953,
  "created_at" : "2014-04-15 20:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/456153491052826625\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/qVEhqbjz5R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlSVLsZCQAAyUD6.jpg",
      "id_str" : "456153490398527488",
      "id" : 456153490398527488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlSVLsZCQAAyUD6.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/qVEhqbjz5R"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/NIzOAm36s9",
      "expanded_url" : "http:\/\/go.wh.gov\/w7YizX",
      "display_url" : "go.wh.gov\/w7YizX"
    } ]
  },
  "geo" : { },
  "id_str" : "456153491052826625",
  "text" : "Your taxes at work: See how your tax dollars are being spent \u2192 http:\/\/t.co\/NIzOAm36s9 #TaxDay http:\/\/t.co\/qVEhqbjz5R",
  "id" : 456153491052826625,
  "created_at" : "2014-04-15 19:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456139947011866626",
  "text" : "Please join President Obama in a moment of silence to honor the victims of last year's Boston Marathon bombing at 2:49pm ET. #BostonStrong",
  "id" : 456139947011866626,
  "created_at" : "2014-04-15 18:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 39, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456139342600482818",
  "text" : "RT @GinaEPA: Boston is my home, we are #BostonStrong. Join in a moment of silence to honor victims of last year's Boston Marathon bombing @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 26, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456136681251696640",
    "text" : "Boston is my home, we are #BostonStrong. Join in a moment of silence to honor victims of last year's Boston Marathon bombing @ 2:49pm ET",
    "id" : 456136681251696640,
    "created_at" : "2014-04-15 18:27:14 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 456139342600482818,
  "created_at" : "2014-04-15 18:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456131702331801601",
  "text" : "RT @VP: \u201CWe will never yield. We will never cower. America will never, never stand down. We are Boston.\u201D \u2013 VP #BostonStrong http:\/\/t.co\/7x1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/456130419876827136\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/7x1Y1nYm0A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlSAM0CCEAEYJaJ.jpg",
        "id_str" : "456130419885215745",
        "id" : 456130419885215745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlSAM0CCEAEYJaJ.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7x1Y1nYm0A"
      } ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456130419876827136",
    "text" : "\u201CWe will never yield. We will never cower. America will never, never stand down. We are Boston.\u201D \u2013 VP #BostonStrong http:\/\/t.co\/7x1Y1nYm0A",
    "id" : 456130419876827136,
    "created_at" : "2014-04-15 18:02:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 456131702331801601,
  "created_at" : "2014-04-15 18:07:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456128788813062145",
  "text" : "RT @PennyPritzker: As a marathoner my thoughts are w\/ the victims of last yr\u2019s Boston Marathon bombing. Join me for a moment of silence at \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BostonStrong",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456123430161874944",
    "text" : "As a marathoner my thoughts are w\/ the victims of last yr\u2019s Boston Marathon bombing. Join me for a moment of silence at 2:49pm #BostonStrong",
    "id" : 456123430161874944,
    "created_at" : "2014-04-15 17:34:34 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 456128788813062145,
  "created_at" : "2014-04-15 17:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456118907175456768",
  "text" : "At 2:49pm ET, please join President Obama in a moment of silence to honor the victims of last year's Boston Marathon bombing. #BostonStrong",
  "id" : 456118907175456768,
  "created_at" : "2014-04-15 17:16:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "indices" : [ 3, 15 ],
      "id_str" : "31127446",
      "id" : 31127446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dWValTzU4y",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/2013-taxreceipt?utm_source=email&utm_medium=email&utm_content=email321-graphic&utm_campaign=economy",
      "display_url" : "whitehouse.gov\/2013-taxreceip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "456102623918436352",
  "text" : "RT @markknoller: On tax filing deadline day, WH offering taxpayers a template to calculate how their taxes are spent. http:\/\/t.co\/dWValTzU4y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/dWValTzU4y",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/2013-taxreceipt?utm_source=email&utm_medium=email&utm_content=email321-graphic&utm_campaign=economy",
        "display_url" : "whitehouse.gov\/2013-taxreceip\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "456087371646529536",
    "text" : "On tax filing deadline day, WH offering taxpayers a template to calculate how their taxes are spent. http:\/\/t.co\/dWValTzU4y",
    "id" : 456087371646529536,
    "created_at" : "2014-04-15 15:11:17 +0000",
    "user" : {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "protected" : false,
      "id_str" : "31127446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/137394623\/knoller_normal.jpg",
      "id" : 31127446,
      "verified" : true
    }
  },
  "id" : 456102623918436352,
  "created_at" : "2014-04-15 16:11:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456088355168464896",
  "text" : "\"We also stand in awe of the men and women who continue to inspire us\u2014learning to stand, walk, dance and run again.\" \u2014Obama #BostonStrong",
  "id" : 456088355168464896,
  "created_at" : "2014-04-15 15:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SAfJkrZZ6E",
      "expanded_url" : "http:\/\/go.wh.gov\/Q9obAx",
      "display_url" : "go.wh.gov\/Q9obAx"
    } ]
  },
  "geo" : { },
  "id_str" : "456084147350831104",
  "text" : "\"The most vivid images from that day were not of smoke and chaos, but of compassion, kindness and strength.\" \u2014Obama: http:\/\/t.co\/SAfJkrZZ6E",
  "id" : 456084147350831104,
  "created_at" : "2014-04-15 14:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456080623044927488",
  "text" : "\"Today, we recognize the incredible courage and leadership of so many Bostonians in the wake of unspeakable tragedy.\" \u2014Obama #BostonStrong",
  "id" : 456080623044927488,
  "created_at" : "2014-04-15 14:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyPassover",
      "indices" : [ 134, 148 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Wzc1bXB4aL",
      "expanded_url" : "http:\/\/go.wh.gov\/7pJgJZ",
      "display_url" : "go.wh.gov\/7pJgJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "455829874545262593",
  "text" : "\"We will never lose faith that compassion &amp; justice will ultimately triumph over hate &amp; fear.\" \u2014Obama: http:\/\/t.co\/Wzc1bXB4aL #HappyPassover",
  "id" : 455829874545262593,
  "created_at" : "2014-04-14 22:08:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyPassover",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/zh1bDumOOk",
      "expanded_url" : "http:\/\/go.wh.gov\/7pJgJZ",
      "display_url" : "go.wh.gov\/7pJgJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "455817816365477888",
  "text" : "\"Michelle and I send our warmest greetings to all those celebrating Passover.\" \u2014President Obama: http:\/\/t.co\/zh1bDumOOk #HappyPassover",
  "id" : 455817816365477888,
  "created_at" : "2014-04-14 21:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/455807570234441728\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eUnDQb1qkD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlNakerCMAAIvAr.jpg",
      "id_str" : "455807570049904640",
      "id" : 455807570049904640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlNakerCMAAIvAr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eUnDQb1qkD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455807570234441728",
  "text" : "On average, women still earn just $0.77 for every $1 men earn.\n\nRT if you agree it's long past time to change that. http:\/\/t.co\/eUnDQb1qkD",
  "id" : 455807570234441728,
  "created_at" : "2014-04-14 20:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/455800297630474240\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VDwgGQS6do",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlNT9KCIgAAT1e-.jpg",
      "id_str" : "455800297424977920",
      "id" : 455800297424977920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlNT9KCIgAAT1e-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VDwgGQS6do"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 58, 67 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/svvNDeERUU",
      "expanded_url" : "http:\/\/go.wh.gov\/Gx5LRR",
      "display_url" : "go.wh.gov\/Gx5LRR"
    } ]
  },
  "geo" : { },
  "id_str" : "455800297630474240",
  "text" : "Here's how President Obama's taking action to help ensure #EqualPay for women \u2192 http:\/\/t.co\/svvNDeERUU #WomenSucceed http:\/\/t.co\/VDwgGQS6do",
  "id" : 455800297630474240,
  "created_at" : "2014-04-14 20:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/455790815911350272\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/q0fnkGCmr0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlNLVOfIMAAQUx5.jpg",
      "id_str" : "455790815332544512",
      "id" : 455790815332544512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlNLVOfIMAAQUx5.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/q0fnkGCmr0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/DWIoHC1ysO",
      "expanded_url" : "http:\/\/go.wh.gov\/CV7RWJ",
      "display_url" : "go.wh.gov\/CV7RWJ"
    } ]
  },
  "geo" : { },
  "id_str" : "455790815911350272",
  "text" : "Use the White House tax receipt calculator to find out how your tax dollars are being spent \u2192 http:\/\/t.co\/DWIoHC1ysO http:\/\/t.co\/q0fnkGCmr0",
  "id" : 455790815911350272,
  "created_at" : "2014-04-14 19:32:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Business Insider",
      "screen_name" : "businessinsider",
      "indices" : [ 15, 31 ],
      "id_str" : "20562637",
      "id" : 20562637
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/carVraMJot",
      "expanded_url" : "http:\/\/read.bi\/1qWPBQp",
      "display_url" : "read.bi\/1qWPBQp"
    } ]
  },
  "geo" : { },
  "id_str" : "455781174871617536",
  "text" : "RT @PressSec: .@BusinessInsider: \"This CBO report is another big win for Obamacare.\" http:\/\/t.co\/carVraMJot #ACAWorks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Business Insider",
        "screen_name" : "businessinsider",
        "indices" : [ 1, 17 ],
        "id_str" : "20562637",
        "id" : 20562637
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/carVraMJot",
        "expanded_url" : "http:\/\/read.bi\/1qWPBQp",
        "display_url" : "read.bi\/1qWPBQp"
      } ]
    },
    "geo" : { },
    "id_str" : "455775646548230144",
    "text" : ".@BusinessInsider: \"This CBO report is another big win for Obamacare.\" http:\/\/t.co\/carVraMJot #ACAWorks",
    "id" : 455775646548230144,
    "created_at" : "2014-04-14 18:32:36 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 455781174871617536,
  "created_at" : "2014-04-14 18:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/455772355172646912\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/JzAEVAI0AO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlM6isrCQAAxqa4.jpg",
      "id_str" : "455772355076177920",
      "id" : 455772355076177920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlM6isrCQAAxqa4.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/JzAEVAI0AO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/vHkMySLifl",
      "expanded_url" : "http:\/\/go.wh.gov\/Qe6iWV",
      "display_url" : "go.wh.gov\/Qe6iWV"
    } ]
  },
  "geo" : { },
  "id_str" : "455772355172646912",
  "text" : "Filed your taxes yet? Find out how your tax dollars are being spent \u2192 http:\/\/t.co\/vHkMySLifl, http:\/\/t.co\/JzAEVAI0AO",
  "id" : 455772355172646912,
  "created_at" : "2014-04-14 18:19:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wonkblog",
      "screen_name" : "Wonkblog",
      "indices" : [ 3, 12 ],
      "id_str" : "353225544",
      "id" : 353225544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/IsXYOUuEyH",
      "expanded_url" : "http:\/\/wapo.st\/1gwqAd6",
      "display_url" : "wapo.st\/1gwqAd6"
    } ]
  },
  "geo" : { },
  "id_str" : "455765841553137664",
  "text" : "RT @Wonkblog: Lower premiums (yes, really) drive down Obamacare\u2019s expected costs, CBO says http:\/\/t.co\/IsXYOUuEyH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/IsXYOUuEyH",
        "expanded_url" : "http:\/\/wapo.st\/1gwqAd6",
        "display_url" : "wapo.st\/1gwqAd6"
      } ]
    },
    "geo" : { },
    "id_str" : "455748494272495616",
    "text" : "Lower premiums (yes, really) drive down Obamacare\u2019s expected costs, CBO says http:\/\/t.co\/IsXYOUuEyH",
    "id" : 455748494272495616,
    "created_at" : "2014-04-14 16:44:43 +0000",
    "user" : {
      "name" : "Wonkblog",
      "screen_name" : "Wonkblog",
      "protected" : false,
      "id_str" : "353225544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753694483989032960\/O6WfaPnH_normal.jpg",
      "id" : 353225544,
      "verified" : true
    }
  },
  "id" : 455765841553137664,
  "created_at" : "2014-04-14 17:53:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 39, 43 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455759935335190528",
  "text" : "Lower-than-expected premiums under the #ACA will help reduce the cost of expanding coverage by $104 billion over the next decade. #ACAWorks",
  "id" : 455759935335190528,
  "created_at" : "2014-04-14 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. CBO",
      "screen_name" : "USCBO",
      "indices" : [ 100, 106 ],
      "id_str" : "1531265618",
      "id" : 1531265618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455755137794183168",
  "text" : "Good news: Our budget deficit will drop by nearly one-third this year, according to the nonpartisan @USCBO.",
  "id" : 455755137794183168,
  "created_at" : "2014-04-14 17:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "YALINetwork",
      "screen_name" : "YALINetwork",
      "indices" : [ 57, 69 ],
      "id_str" : "2371024465",
      "id" : 2371024465
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Africa",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/eXqmvLrupM",
      "expanded_url" : "http:\/\/youtu.be\/sSyXtFik29Y",
      "display_url" : "youtu.be\/sSyXtFik29Y"
    } ]
  },
  "geo" : { },
  "id_str" : "455726286179418112",
  "text" : "RT @macon44: Watch Obama's msg to young #Africa. Through @YALINetwork we're all building something amazing http:\/\/t.co\/eXqmvLrupM Please RT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YALINetwork",
        "screen_name" : "YALINetwork",
        "indices" : [ 44, 56 ],
        "id_str" : "2371024465",
        "id" : 2371024465
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Africa",
        "indices" : [ 27, 34 ]
      }, {
        "text" : "YALICHAT",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/eXqmvLrupM",
        "expanded_url" : "http:\/\/youtu.be\/sSyXtFik29Y",
        "display_url" : "youtu.be\/sSyXtFik29Y"
      } ]
    },
    "geo" : { },
    "id_str" : "455707026937503744",
    "text" : "Watch Obama's msg to young #Africa. Through @YALINetwork we're all building something amazing http:\/\/t.co\/eXqmvLrupM Please RT #YALICHAT",
    "id" : 455707026937503744,
    "created_at" : "2014-04-14 13:59:56 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 455726286179418112,
  "created_at" : "2014-04-14 15:16:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 135, 144 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455701148704329728",
  "text" : "\"I had a wonderful conversation w\/ Pope Francis\u2014mainly about the imperative of addressing poverty &amp; inequality.\" \u2014Obama on meeting @Pontifex",
  "id" : 455701148704329728,
  "created_at" : "2014-04-14 13:36:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455700401103179776",
  "text" : "\"We\u2019ve got to stand united against this kind of terrible violence\u2014which has no place in our society\" \u2014Obama on yesterday's tragedy in Kansas",
  "id" : 455700401103179776,
  "created_at" : "2014-04-14 13:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455699873497505793",
  "text" : "\"No one should ever have to fear for their safety when they go to pray.\" \u2014President Obama",
  "id" : 455699873497505793,
  "created_at" : "2014-04-14 13:31:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455699620748722176",
  "text" : "President Obama: \"Nobody should have to worry about their security when gathering with their fellow believers.\"",
  "id" : 455699620748722176,
  "created_at" : "2014-04-14 13:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455699289952378881",
  "text" : "President Obama: \"This morning, our prayers are with the people of Overland Park.\"",
  "id" : 455699289952378881,
  "created_at" : "2014-04-14 13:29:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/4I32GuOpwN",
      "expanded_url" : "http:\/\/go.wh.gov\/qD4rpC",
      "display_url" : "go.wh.gov\/qD4rpC"
    } ]
  },
  "geo" : { },
  "id_str" : "455699005339496448",
  "text" : "Happening now: President Obama speaks at an Easter Prayer Breakfast \u2192 http:\/\/t.co\/4I32GuOpwN",
  "id" : 455699005339496448,
  "created_at" : "2014-04-14 13:28:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/455523342666063872\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/wUkvkhI7KC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlJYEQdCAAEqqd-.jpg",
      "id_str" : "455523342477295617",
      "id" : 455523342477295617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlJYEQdCAAEqqd-.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/wUkvkhI7KC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455523342666063872",
  "text" : "Best seat in the White House. http:\/\/t.co\/wUkvkhI7KC",
  "id" : 455523342666063872,
  "created_at" : "2014-04-14 01:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/W9YPXmePEh",
      "expanded_url" : "http:\/\/go.wh.gov\/RqMfdd",
      "display_url" : "go.wh.gov\/RqMfdd"
    } ]
  },
  "geo" : { },
  "id_str" : "455473040202027009",
  "text" : "Take a peek behind the scenes this week at the White House as President Obama honors #EqualPayDay &amp; more \u2192 http:\/\/t.co\/W9YPXmePEh",
  "id" : 455473040202027009,
  "created_at" : "2014-04-13 22:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/h1gilWRc10",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "455450386334105600",
  "text" : "\"When women succeed, America succeeds.\" \u2014President Obama on why it's time to ensure #EqualPay for women: http:\/\/t.co\/h1gilWRc10",
  "id" : 455450386334105600,
  "created_at" : "2014-04-13 21:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/h1gilWRc10",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "455405089784479744",
  "text" : "\"It\u2019s time to do away with workplace policies that belong in a Mad Men episode.\" \u2014Obama on helping #WomenSucceed: http:\/\/t.co\/h1gilWRc10",
  "id" : 455405089784479744,
  "created_at" : "2014-04-13 18:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/h1gilWRc10",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "455344688967340033",
  "text" : "\"The days when you could be charged more just for being a woman are over for good.\" \u2014Obama in his Weekly Address: http:\/\/t.co\/h1gilWRc10",
  "id" : 455344688967340033,
  "created_at" : "2014-04-13 14:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/h1gilWRc10",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "455072890962976768",
  "text" : "\"Thanks to the Affordable Care Act, tens of millions of women are now guaranteed free preventive care.\" \u2014Obama: http:\/\/t.co\/h1gilWRc10",
  "id" : 455072890962976768,
  "created_at" : "2014-04-12 20:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/h1gilWRc10",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "455042695015051264",
  "text" : "\"It\u2019s good for everyone when women are paid fairly.\" \u2014President Obama: http:\/\/t.co\/h1gilWRc10 #EqualPay",
  "id" : 455042695015051264,
  "created_at" : "2014-04-12 18:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/h1gilWRc10",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "455012495833313280",
  "text" : "\"It\u2019s wrong. In 2014, it\u2019s an embarrassment. Women deserve equal pay for equal work.\" \u2014Obama on the gender pay gap: http:\/\/t.co\/h1gilWRc10",
  "id" : 455012495833313280,
  "created_at" : "2014-04-12 16:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/N5kmbCVBPm",
      "expanded_url" : "http:\/\/go.wh.gov\/Vz32r8",
      "display_url" : "go.wh.gov\/Vz32r8"
    } ]
  },
  "geo" : { },
  "id_str" : "454993842023178240",
  "text" : "\"The average woman who works full-time in America earns less than a man.\" \u2014Obama on fighting for #EqualPay for women: http:\/\/t.co\/N5kmbCVBPm",
  "id" : 454993842023178240,
  "created_at" : "2014-04-12 14:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 91, 100 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 104, 111 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/454748971286556672\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/SaiB2dnAOB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk-Xx6KCYAEx5OS.jpg",
      "id_str" : "454748971068448769",
      "id" : 454748971068448769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk-Xx6KCYAEx5OS.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/SaiB2dnAOB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454748971286556672",
  "text" : "\"7.5 million people across the country...have the security of health insurance.\" \u2014Obama on @Sebelius at @HHSgov: http:\/\/t.co\/SaiB2dnAOB",
  "id" : 454748971286556672,
  "created_at" : "2014-04-11 22:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Erin Lindsay",
      "screen_name" : "ErinELindsay",
      "indices" : [ 85, 98 ],
      "id_str" : "4515851",
      "id" : 4515851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockofCheeseDay",
      "indices" : [ 119, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454708923485159424",
  "text" : "RT @Erin44: It's been an honor to work at the @WhiteHouse. Now I'll be tweeting from @ErinELindsay, where every day is #BigBlockofCheeseDay\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 34, 45 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Erin Lindsay",
        "screen_name" : "ErinELindsay",
        "indices" : [ 73, 86 ],
        "id_str" : "4515851",
        "id" : 4515851
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockofCheeseDay",
        "indices" : [ 107, 127 ]
      }, {
        "text" : "WhatsNext",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454708445770711040",
    "text" : "It's been an honor to work at the @WhiteHouse. Now I'll be tweeting from @ErinELindsay, where every day is #BigBlockofCheeseDay. #WhatsNext",
    "id" : 454708445770711040,
    "created_at" : "2014-04-11 19:51:56 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 454708923485159424,
  "created_at" : "2014-04-11 19:53:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/454647153726853120\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/GHzowx3ezN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk87LUKIQAAQXRJ.jpg",
      "id_str" : "454647152963502080",
      "id" : 454647152963502080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk87LUKIQAAQXRJ.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GHzowx3ezN"
    } ],
    "hashtags" : [ {
      "text" : "CherryBlossomDC",
      "indices" : [ 81, 97 ]
    }, {
      "text" : "DC",
      "indices" : [ 98, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454692905928884224",
  "text" : "RT @Interior: Peak bloom for the Cherry Blossoms has arrived on the Tidal Basin! #CherryBlossomDC #DC http:\/\/t.co\/GHzowx3ezN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/454647153726853120\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/GHzowx3ezN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk87LUKIQAAQXRJ.jpg",
        "id_str" : "454647152963502080",
        "id" : 454647152963502080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk87LUKIQAAQXRJ.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GHzowx3ezN"
      } ],
      "hashtags" : [ {
        "text" : "CherryBlossomDC",
        "indices" : [ 67, 83 ]
      }, {
        "text" : "DC",
        "indices" : [ 84, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454647153726853120",
    "text" : "Peak bloom for the Cherry Blossoms has arrived on the Tidal Basin! #CherryBlossomDC #DC http:\/\/t.co\/GHzowx3ezN",
    "id" : 454647153726853120,
    "created_at" : "2014-04-11 15:48:23 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 454692905928884224,
  "created_at" : "2014-04-11 18:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454686356963594240",
  "text" : "Under the House GOP budget, 200,000 new moms &amp; kids could be cut off from programs that help families afford healthy foods. #HouseOfCuts",
  "id" : 454686356963594240,
  "created_at" : "2014-04-11 18:24:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/454663154161569792\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/aN0YGm1NtP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk9JuskCUAAjmby.jpg",
      "id_str" : "454663153972826112",
      "id" : 454663153972826112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk9JuskCUAAjmby.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aN0YGm1NtP"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454663154161569792",
  "text" : "FACT: The House GOP budget would eliminate private health plans for more than 7 million Americans. #HouseOfCuts http:\/\/t.co\/aN0YGm1NtP",
  "id" : 454663154161569792,
  "created_at" : "2014-04-11 16:51:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/V9lWim5PkG",
      "expanded_url" : "http:\/\/go.wh.gov\/sDenQq",
      "display_url" : "go.wh.gov\/sDenQq"
    } ]
  },
  "geo" : { },
  "id_str" : "454652230927261696",
  "text" : "The House GOP just passed a budget that:\n\u2704's programs for the middle class\n\u2704's taxes for millionaires\nhttp:\/\/t.co\/V9lWim5PkG #HouseOfCuts",
  "id" : 454652230927261696,
  "created_at" : "2014-04-11 16:08:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 21, 30 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454645421785493504",
  "text" : "RT @JohnKerry: Known @Sebelius since \u201802, a public servant to the core. Today over 7.5M reasons to appreciate her service even more. Miss h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathleen Sebelius",
        "screen_name" : "Sebelius",
        "indices" : [ 6, 15 ],
        "id_str" : "2556859698",
        "id" : 2556859698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454643891921514496",
    "text" : "Known @Sebelius since \u201802, a public servant to the core. Today over 7.5M reasons to appreciate her service even more. Miss her in Cabinet Rm",
    "id" : 454643891921514496,
    "created_at" : "2014-04-11 15:35:25 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 454645421785493504,
  "created_at" : "2014-04-11 15:41:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 25, 34 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454638538148286464",
  "text" : "RT @arneduncan: Kathleen @Sebelius is an extraordinary advocate for children &amp; families &amp; has been a tremendous partner. Wishing her all th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathleen Sebelius",
        "screen_name" : "Sebelius",
        "indices" : [ 9, 18 ],
        "id_str" : "2556859698",
        "id" : 2556859698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454636389057839104",
    "text" : "Kathleen @Sebelius is an extraordinary advocate for children &amp; families &amp; has been a tremendous partner. Wishing her all the best!",
    "id" : 454636389057839104,
    "created_at" : "2014-04-11 15:05:36 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 454638538148286464,
  "created_at" : "2014-04-11 15:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454636957424168960",
  "text" : "\"I know you\u2019re going to do an outstanding job as America\u2019s Secretary of Health and Human Services.\" \u2014President Obama to Sylvia Burwell",
  "id" : 454636957424168960,
  "created_at" : "2014-04-11 15:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454636571611131905",
  "text" : "\"In the year since she arrived, the deficit has plunged by more than $400 billion.\" \u2014President Obama on Sylvia Burwell's record at OMB",
  "id" : 454636571611131905,
  "created_at" : "2014-04-11 15:06:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 126, 135 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454635706347188224",
  "text" : "\"Kathleen\u2019s work over the past five years will benefit our families and our country for decades to come.\" \u2014President Obama on @Sebelius",
  "id" : 454635706347188224,
  "created_at" : "2014-04-11 15:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 89, 98 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 102, 109 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 110, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454634402094796800",
  "text" : "\"7.5 million Americans...signed up for health coverage through the exchanges.\" \u2014Obama on @Sebelius at @HHSgov #7MillionAndCounting",
  "id" : 454634402094796800,
  "created_at" : "2014-04-11 14:57:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 46, 53 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/V8LlVyph5t",
      "expanded_url" : "http:\/\/go.wh.gov\/KaJVUX",
      "display_url" : "go.wh.gov\/KaJVUX"
    } ]
  },
  "geo" : { },
  "id_str" : "454633930696953856",
  "text" : "Watch now: President Obama nominates the next @HHSgov Secretary \u2192 http:\/\/t.co\/V8LlVyph5t",
  "id" : 454633930696953856,
  "created_at" : "2014-04-11 14:55:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 57, 64 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/V8LlVyph5t",
      "expanded_url" : "http:\/\/go.wh.gov\/KaJVUX",
      "display_url" : "go.wh.gov\/KaJVUX"
    } ]
  },
  "geo" : { },
  "id_str" : "454628029957156864",
  "text" : "Tune in at 11am ET as President Obama nominates the next @HHSgov Secretary \u2192 http:\/\/t.co\/V8LlVyph5t",
  "id" : 454628029957156864,
  "created_at" : "2014-04-11 14:32:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 65, 74 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454624507610038272",
  "text" : "RT @Cecilia44: As a mom and a Latina, I am grateful for Kathleen @Sebelius\u2019 many accomplishments for women\u2019s health. Gracias, Kathleen! \u00A1Ad\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathleen Sebelius",
        "screen_name" : "Sebelius",
        "indices" : [ 50, 59 ],
        "id_str" : "2556859698",
        "id" : 2556859698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454605732877701120",
    "text" : "As a mom and a Latina, I am grateful for Kathleen @Sebelius\u2019 many accomplishments for women\u2019s health. Gracias, Kathleen! \u00A1Adelante!",
    "id" : 454605732877701120,
    "created_at" : "2014-04-11 13:03:47 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 454624507610038272,
  "created_at" : "2014-04-11 14:18:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/GYi8z0ItLj",
      "expanded_url" : "http:\/\/vox.com\/e\/5366711",
      "display_url" : "vox.com\/e\/5366711"
    } ]
  },
  "geo" : { },
  "id_str" : "454617138620559361",
  "text" : "RT @ezraklein: Kathleen Sebelius is resigning because Obamacare has won http:\/\/t.co\/GYi8z0ItLj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.vox.com\" rel=\"nofollow\"\u003EVox.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/GYi8z0ItLj",
        "expanded_url" : "http:\/\/vox.com\/e\/5366711",
        "display_url" : "vox.com\/e\/5366711"
      } ]
    },
    "geo" : { },
    "id_str" : "454401345462603776",
    "text" : "Kathleen Sebelius is resigning because Obamacare has won http:\/\/t.co\/GYi8z0ItLj",
    "id" : 454401345462603776,
    "created_at" : "2014-04-10 23:31:37 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 454617138620559361,
  "created_at" : "2014-04-11 13:49:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McCain",
      "screen_name" : "SenJohnMcCain",
      "indices" : [ 3, 17 ],
      "id_str" : "19394188",
      "id" : 19394188
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HHS",
      "indices" : [ 72, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454615323023798272",
  "text" : "RT @SenJohnMcCain: Sylvia Burwell is an excellent choice to be the next #HHS Secretary",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HHS",
        "indices" : [ 53, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454410334963392512",
    "text" : "Sylvia Burwell is an excellent choice to be the next #HHS Secretary",
    "id" : 454410334963392512,
    "created_at" : "2014-04-11 00:07:21 +0000",
    "user" : {
      "name" : "John McCain",
      "screen_name" : "SenJohnMcCain",
      "protected" : false,
      "id_str" : "19394188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1189622627\/twitter_normal.jpg",
      "id" : 19394188,
      "verified" : true
    }
  },
  "id" : 454615323023798272,
  "created_at" : "2014-04-11 13:41:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/454390953403375616\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/JLEQ92wwI2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk5SKhQCAAAVokO.jpg",
      "id_str" : "454390953088778240",
      "id" : 454390953088778240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk5SKhQCAAAVokO.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JLEQ92wwI2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/9iYPPj8fj9",
      "expanded_url" : "http:\/\/go.wh.gov\/YKTVWa",
      "display_url" : "go.wh.gov\/YKTVWa"
    } ]
  },
  "geo" : { },
  "id_str" : "454390953403375616",
  "text" : "President Obama admires President Johnson's Oval Office replica at the LBJ Library: http:\/\/t.co\/9iYPPj8fj9, http:\/\/t.co\/JLEQ92wwI2",
  "id" : 454390953403375616,
  "created_at" : "2014-04-10 22:50:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/TCOHCCaenb",
      "expanded_url" : "http:\/\/go.wh.gov\/cGWUjp",
      "display_url" : "go.wh.gov\/cGWUjp"
    } ]
  },
  "geo" : { },
  "id_str" : "454379928193335296",
  "text" : "\"I urge Congress to follow Minnesota\u2019s lead: Raise the federal minimum wage.\" \u2014President Obama: http:\/\/t.co\/TCOHCCaenb #RaiseTheWage",
  "id" : 454379928193335296,
  "created_at" : "2014-04-10 22:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/454360949898489856\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vSz79guufs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk424GOCIAAG7nD.jpg",
      "id_str" : "454360949781045248",
      "id" : 454360949781045248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk424GOCIAAG7nD.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vSz79guufs"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454360949898489856",
  "text" : "The Minnesota Legislature just voted to #RaiseTheWage.\n\nRT if you agree it's time to do the same for all Americans. http:\/\/t.co\/vSz79guufs",
  "id" : 454360949898489856,
  "created_at" : "2014-04-10 20:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/454347453404164096\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sc60MZ8GoL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk4qmfmCIAA0Y4T.jpg",
      "id_str" : "454347453215416320",
      "id" : 454347453215416320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk4qmfmCIAA0Y4T.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sc60MZ8GoL"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454347453404164096",
  "text" : "The House GOP budget could force 170,000 kids off of critical early childhood programs like Head Start. #HouseOfCuts http:\/\/t.co\/sc60MZ8GoL",
  "id" : 454347453404164096,
  "created_at" : "2014-04-10 19:57:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/cxdfQlCrOC",
      "expanded_url" : "http:\/\/go.wh.gov\/XoNR5u",
      "display_url" : "go.wh.gov\/XoNR5u"
    } ]
  },
  "geo" : { },
  "id_str" : "454336777403117568",
  "text" : "Here's how the House GOP budget \u2704's programs for the middle class while cutting taxes for millionaires: http:\/\/t.co\/cxdfQlCrOC #HouseOfCuts",
  "id" : 454336777403117568,
  "created_at" : "2014-04-10 19:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/454333371183669248\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/p8l0mIwKXX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk4dyzNCIAACQS0.jpg",
      "id_str" : "454333370986536960",
      "id" : 454333370986536960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk4dyzNCIAACQS0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/p8l0mIwKXX"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454333371183669248",
  "text" : "Under the House GOP budget, 616,000 students could lose Pell Grants that help them pay for college. #HouseOfCuts http:\/\/t.co\/p8l0mIwKXX",
  "id" : 454333371183669248,
  "created_at" : "2014-04-10 19:01:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/454329304776597504\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QkUbuYAOsN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk4aGGyCAAAwKNr.jpg",
      "id_str" : "454329304612995072",
      "id" : 454329304612995072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk4aGGyCAAAwKNr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QkUbuYAOsN"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454329304776597504",
  "text" : "The House GOP budget:\n\u2704's vital programs\n\u2704's taxes for millionaires\n\u2191 taxes for middle-class families\n#HouseOfCuts http:\/\/t.co\/QkUbuYAOsN",
  "id" : 454329304776597504,
  "created_at" : "2014-04-10 18:45:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454314626134847488",
  "text" : "\"He believed that, together, we can build an America that is more fair, more equal, and more free than the one we inherited.\" \u2014Obama on LBJ",
  "id" : 454314626134847488,
  "created_at" : "2014-04-10 17:47:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454314435910569985",
  "text" : "\"President Johnson knew that ours is a story of optimism, a story of achievement &amp; constant striving that is unique upon this Earth.\" \u2014Obama",
  "id" : 454314435910569985,
  "created_at" : "2014-04-10 17:46:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454314030103273472",
  "text" : "\"With enough effort, and enough empathy, and enough perseverance, and enough courage, people who love their country can change it.\" \u2014Obama",
  "id" : 454314030103273472,
  "created_at" : "2014-04-10 17:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454313634492346368",
  "text" : "\"Making their lives better was what the hell the presidency is for.\" \u2014President Obama on LBJ's efforts to expand #OpportunityForAll",
  "id" : 454313634492346368,
  "created_at" : "2014-04-10 17:43:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454313081162977280",
  "text" : "President Obama: \"The story of America is a story of progress. However slow, however incomplete, however harshly challenged.\"",
  "id" : 454313081162977280,
  "created_at" : "2014-04-10 17:40:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454312754216972288",
  "text" : "President Obama: \"We are here today because we know we cannot be complacent. History travels not only forwards, but backwards and sideways.\"",
  "id" : 454312754216972288,
  "created_at" : "2014-04-10 17:39:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454312641570566144",
  "text" : "\u201CThat\u2019s why I\u2019m standing here today. Because of those efforts. Because of that legacy.\u201D \u2014President Obama on LBJ's accomplishments",
  "id" : 454312641570566144,
  "created_at" : "2014-04-10 17:39:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454311154148732928",
  "text" : "Obama: LBJ \"freed millions of seniors from the fear that illness could rob them of...security...which we now know today as Medicare.\"",
  "id" : 454311154148732928,
  "created_at" : "2014-04-10 17:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454310749813628928",
  "text" : "President Obama: \"President Johnson fought for...until ultimately he signed the Civil Rights Act into law.\"",
  "id" : 454310749813628928,
  "created_at" : "2014-04-10 17:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454310558821785600",
  "text" : "Obama on LBJ: \"He had a unique capacity, as...a white politician from the South\u2014to...dismantle for good the structures of legal segregation\"",
  "id" : 454310558821785600,
  "created_at" : "2014-04-10 17:30:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454309693708853248",
  "text" : "President Obama on LBJ: \"He knew that poverty and injustice are as inseparable as opportunity and justice are joined.\"",
  "id" : 454309693708853248,
  "created_at" : "2014-04-10 17:27:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454309468466335744",
  "text" : "President Obama: LBJ \"had known the metallic taste of hunger; the feel of a mother\u2019s calloused hands, rubbed raw from washing and cleaning.\"",
  "id" : 454309468466335744,
  "created_at" : "2014-04-10 17:26:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454308809239191552",
  "text" : "\"Passing laws was what LBJ knew how to do. No one knew politics and no one loved legislating more than President Johnson.\" \u2014President Obama",
  "id" : 454308809239191552,
  "created_at" : "2014-04-10 17:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454308381218852864",
  "text" : "\"As a master of politics &amp; the legislative process, he grasped like few others the power of government to bring about change.\" \u2014Obama on LBJ",
  "id" : 454308381218852864,
  "created_at" : "2014-04-10 17:22:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454308200800862208",
  "text" : "\"You\u2019re reminded daily that in this great democracy, you are but a relay swimmer in the currents of history.\" \u2014Obama on the Presidency",
  "id" : 454308200800862208,
  "created_at" : "2014-04-10 17:21:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454307763540463616",
  "text" : "\"As we commemorate the 50th anniversary of the Civil Rights Act, we honor the men and women who made it possible.\" \u2014President Obama",
  "id" : 454307763540463616,
  "created_at" : "2014-04-10 17:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/U1xJW8x6ka",
      "expanded_url" : "http:\/\/go.wh.gov\/EWuitM",
      "display_url" : "go.wh.gov\/EWuitM"
    } ]
  },
  "geo" : { },
  "id_str" : "454306786645131265",
  "text" : "Happening now: President Obama speaks on the 50th anniversary of the Civil Rights Act. Watch \u2192 http:\/\/t.co\/U1xJW8x6ka",
  "id" : 454306786645131265,
  "created_at" : "2014-04-10 17:15:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/454271279000870912\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/SROglf91eP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk3lUkACQAAqAox.jpg",
      "id_str" : "454271278858256384",
      "id" : 454271278858256384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk3lUkACQAAqAox.jpg",
      "sizes" : [ {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/SROglf91eP"
    } ],
    "hashtags" : [ {
      "text" : "NationalSiblingsDay",
      "indices" : [ 18, 38 ]
    }, {
      "text" : "TBT",
      "indices" : [ 40, 44 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 45, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454293317342461953",
  "text" : "RT @FLOTUS: Happy #NationalSiblingsDay! #TBT #ThrowbackThursday http:\/\/t.co\/SROglf91eP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/454271279000870912\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/SROglf91eP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk3lUkACQAAqAox.jpg",
        "id_str" : "454271278858256384",
        "id" : 454271278858256384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk3lUkACQAAqAox.jpg",
        "sizes" : [ {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/SROglf91eP"
      } ],
      "hashtags" : [ {
        "text" : "NationalSiblingsDay",
        "indices" : [ 6, 26 ]
      }, {
        "text" : "TBT",
        "indices" : [ 28, 32 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 33, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454271279000870912",
    "text" : "Happy #NationalSiblingsDay! #TBT #ThrowbackThursday http:\/\/t.co\/SROglf91eP",
    "id" : 454271279000870912,
    "created_at" : "2014-04-10 14:54:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 454293317342461953,
  "created_at" : "2014-04-10 16:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Pip31xxgcL",
      "expanded_url" : "http:\/\/go.wh.gov\/729sEM",
      "display_url" : "go.wh.gov\/729sEM"
    } ]
  },
  "geo" : { },
  "id_str" : "454283925246861312",
  "text" : "At 12:50pm ET, President Obama speaks at a summit commemorating the 50th anniversary of the Civil Rights Act. Watch \u2192 http:\/\/t.co\/Pip31xxgcL",
  "id" : 454283925246861312,
  "created_at" : "2014-04-10 15:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/brAJMOKpA8",
      "expanded_url" : "http:\/\/go.wh.gov\/K2JA6j",
      "display_url" : "go.wh.gov\/K2JA6j"
    } ]
  },
  "geo" : { },
  "id_str" : "454275986507710464",
  "text" : "Many Rosie the Riveters earned #EqualPay for equal work in the 1940s. It's long past time to ensure equal pay today: http:\/\/t.co\/brAJMOKpA8",
  "id" : 454275986507710464,
  "created_at" : "2014-04-10 15:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/rBV4oQ8h5h",
      "expanded_url" : "http:\/\/youtu.be\/hoLtezQfoBo",
      "display_url" : "youtu.be\/hoLtezQfoBo"
    } ]
  },
  "geo" : { },
  "id_str" : "454268380036734976",
  "text" : "\"We lean on each other. We hold each other up. We carry on.\" \u2014President Obama yesterday at #FortHood: http:\/\/t.co\/rBV4oQ8h5h",
  "id" : 454268380036734976,
  "created_at" : "2014-04-10 14:43:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/FZ1dAfy5AM",
      "expanded_url" : "http:\/\/youtu.be\/hoLtezQfoBo",
      "display_url" : "youtu.be\/hoLtezQfoBo"
    } ]
  },
  "geo" : { },
  "id_str" : "454061204684550145",
  "text" : "\"It is love, tested by tragedy, that brings us together again.\" \u2014Obama at today's memorial ceremony at #FortHood: http:\/\/t.co\/FZ1dAfy5AM",
  "id" : 454061204684550145,
  "created_at" : "2014-04-10 01:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/454051619382898688\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gh53VI2VsQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk0dir3CMAArvEJ.jpg",
      "id_str" : "454051619160600576",
      "id" : 454051619160600576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk0dir3CMAArvEJ.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 975,
        "resize" : "fit",
        "w" : 1514
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gh53VI2VsQ"
    } ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454051619382898688",
  "text" : "\"This nation stands with you for all the days to come.\" \u2014Obama to families of the victims of the #FortHood shooting: http:\/\/t.co\/gh53VI2VsQ",
  "id" : 454051619382898688,
  "created_at" : "2014-04-10 00:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/454044100090548224\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/5uL9mA80PU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk0WtAvCMAE7NtP.jpg",
      "id_str" : "454044099981488129",
      "id" : 454044099981488129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk0WtAvCMAE7NtP.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/5uL9mA80PU"
    } ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/SSJxEX9uJi",
      "expanded_url" : "http:\/\/go.wh.gov\/s6RVKt",
      "display_url" : "go.wh.gov\/s6RVKt"
    } ]
  },
  "geo" : { },
  "id_str" : "454044100090548224",
  "text" : "President Obama pays his respects to the victims of the shooting at #FortHood \u2192 http:\/\/t.co\/SSJxEX9uJi, http:\/\/t.co\/5uL9mA80PU",
  "id" : 454044100090548224,
  "created_at" : "2014-04-09 23:52:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453975372351426560",
  "text" : "\"May God watch over these American soldiers. May He keep strong their families, whose love endures.\" \u2014President Obama #FortHood",
  "id" : 453975372351426560,
  "created_at" : "2014-04-09 19:18:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453975236908961792",
  "text" : "\"We lean on each other. We hold each other up. We carry on. With God\u2019s amazing grace\u2014we somehow bear what seems unbearable\" \u2014Obama #FortHood",
  "id" : 453975236908961792,
  "created_at" : "2014-04-09 19:18:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453974888957902848",
  "text" : "\"We need them\u2014not just to fight in other countries, but to build up our own.\" \u2014President Obama on our veterans #FortHood",
  "id" : 453974888957902848,
  "created_at" : "2014-04-09 19:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453974463223435264",
  "text" : "\"We must honor these men by doing more to care for our fellow Americans living with mental illness\u2014civilian and military.\" \u2014Obama #FortHood",
  "id" : 453974463223435264,
  "created_at" : "2014-04-09 19:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453974239990022144",
  "text" : "\"We must honor these men with a renewed commitment to keep our troops safe\u2014not just in battle, but on the home front.\" \u2014Obama #FortHood",
  "id" : 453974239990022144,
  "created_at" : "2014-04-09 19:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453973930119032833",
  "text" : "\"Know that you will never be alone. This Army, this nation, stands with you for all the days to come.\" \u2014President Obama at #FortHood",
  "id" : 453973930119032833,
  "created_at" : "2014-04-09 19:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453973622269673472",
  "text" : "\"Even as your hearts break, we see in you that eternal truth: Love never ends.\" \u2014Obama to loved ones of the #FortHood shooting victims",
  "id" : 453973622269673472,
  "created_at" : "2014-04-09 19:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453973528501841920",
  "text" : "\"We are here, on behalf of the American people, to honor your loved ones and to offer whatever comfort we can.\" \u2014President Obama #FortHood",
  "id" : 453973528501841920,
  "created_at" : "2014-04-09 19:11:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453973250952155136",
  "text" : "\"It was love\u2014for their comrades, for all of you\u2014that defined their last moments.\" \u2014Obama on the victims of the #FortHood shooting",
  "id" : 453973250952155136,
  "created_at" : "2014-04-09 19:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453973084106932224",
  "text" : "\"They lived those shining values\u2014loyalty, duty, honor\u2014that keep us strong and free.\" \u2014Obama on the victims of the #FortHood shooting",
  "id" : 453973084106932224,
  "created_at" : "2014-04-09 19:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453972923301494784",
  "text" : "\"It was love for country that inspired these 3 Americans to put on the uniform and join the greatest Army the world has ever known.\" \u2014Obama",
  "id" : 453972923301494784,
  "created_at" : "2014-04-09 19:09:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453972769500561408",
  "text" : "\"It is love, tested by tragedy, that brings us together again.\" \u2014President Obama at #FortHood",
  "id" : 453972769500561408,
  "created_at" : "2014-04-09 19:08:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453972603024445440",
  "text" : "\"In our lives, our joys, and our sorrows\u2014we have learned that there is a time for every matter under heaven.\" \u2014President Obama #FortHood",
  "id" : 453972603024445440,
  "created_at" : "2014-04-09 19:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/KnO4ssBUOE",
      "expanded_url" : "http:\/\/go.wh.gov\/25Hi2G",
      "display_url" : "go.wh.gov\/25Hi2G"
    } ]
  },
  "geo" : { },
  "id_str" : "453972294764101632",
  "text" : "Happening now: President Obama speaks at a memorial ceremony in #FortHood, Texas \u2192 http:\/\/t.co\/KnO4ssBUOE",
  "id" : 453972294764101632,
  "created_at" : "2014-04-09 19:06:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/halEHbnGKz",
      "expanded_url" : "http:\/\/go.wh.gov\/Lj2sFq",
      "display_url" : "go.wh.gov\/Lj2sFq"
    } ]
  },
  "geo" : { },
  "id_str" : "453943079964512256",
  "text" : "At 3pm ET, President Obama speaks at a memorial ceremony in #FortHood, Texas. Watch \u2192 http:\/\/t.co\/halEHbnGKz",
  "id" : 453943079964512256,
  "created_at" : "2014-04-09 17:10:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453675962752700417\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/xe1kPkWJeG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkvH4mMCAAA_zI0.jpg",
      "id_str" : "453675962618478592",
      "id" : 453675962618478592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkvH4mMCAAA_zI0.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xe1kPkWJeG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/9EkOK77OQT",
      "expanded_url" : "http:\/\/go.wh.gov\/PddAK4",
      "display_url" : "go.wh.gov\/PddAK4"
    } ]
  },
  "geo" : { },
  "id_str" : "453675962752700417",
  "text" : "\"I\u2019m going to take action...to make it easier for working women to earn fair pay.\" \u2014Obama: http:\/\/t.co\/9EkOK77OQT, http:\/\/t.co\/xe1kPkWJeG",
  "id" : 453675962752700417,
  "created_at" : "2014-04-08 23:29:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lilly Ledbetter",
      "screen_name" : "Lilly_Ledbetter",
      "indices" : [ 3, 19 ],
      "id_str" : "1093338182",
      "id" : 1093338182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453669037810393088",
  "text" : "RT @Lilly_Ledbetter: So wonderful to hear from so many advocates today. These executive orders are great news - next step the Paycheck Fair\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoMadMenPay",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453606912790388736",
    "text" : "So wonderful to hear from so many advocates today. These executive orders are great news - next step the Paycheck Fairness Act. #NoMadMenPay",
    "id" : 453606912790388736,
    "created_at" : "2014-04-08 18:54:50 +0000",
    "user" : {
      "name" : "Lilly Ledbetter",
      "screen_name" : "Lilly_Ledbetter",
      "protected" : false,
      "id_str" : "1093338182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3162198877\/8d9a0ec44111436723db405af946fc60_normal.jpeg",
      "id" : 1093338182,
      "verified" : false
    }
  },
  "id" : 453669037810393088,
  "created_at" : "2014-04-08 23:01:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453663857144111104\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/WmrVsut7IE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bku839TCUAAP-3P.jpg",
      "id_str" : "453663857014099968",
      "id" : 453663857014099968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bku839TCUAAP-3P.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WmrVsut7IE"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453663857144111104",
  "text" : "\"Let your senators know where you stand, because America deserves #EqualPay for equal work.\" \u2014President Obama: http:\/\/t.co\/WmrVsut7IE",
  "id" : 453663857144111104,
  "created_at" : "2014-04-08 22:41:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453646850961072129\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/yWJzpR2q6C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkutaELCAAECcoq.jpg",
      "id_str" : "453646850789081089",
      "id" : 453646850789081089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkutaELCAAECcoq.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/yWJzpR2q6C"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453646850961072129",
  "text" : "\"I\u2019ve got two daughters and I expect them to be treated just like anybody\u2019s sons.\" \u2014Obama on #EqualPay for women http:\/\/t.co\/yWJzpR2q6C",
  "id" : 453646850961072129,
  "created_at" : "2014-04-08 21:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dpmrdO6shn",
      "expanded_url" : "http:\/\/instagram.com\/p\/mikAQeQiqI\/",
      "display_url" : "instagram.com\/p\/mikAQeQiqI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "453621044243226625",
  "text" : "\"It's nice to have a day, but it's even better to have #EqualPay. And our job's not finished yet.\" \u2014President Obama: http:\/\/t.co\/dpmrdO6shn",
  "id" : 453621044243226625,
  "created_at" : "2014-04-08 19:50:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453611025489604609\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KTVSvLSPlJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkuM0vUCcAABiaQ.jpg",
      "id_str" : "453611025162465280",
      "id" : 453611025162465280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkuM0vUCcAABiaQ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KTVSvLSPlJ"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453611025489604609",
  "text" : "Many Rosie the Riveters earned #EqualPay for equal work in the 1940s. It's long past time to ensure equal pay today. http:\/\/t.co\/KTVSvLSPlJ",
  "id" : 453611025489604609,
  "created_at" : "2014-04-08 19:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoMadMenPay",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453600786086641664",
  "text" : "FACT: Women account for nearly half of our workforce, yet on average, they still earn just $0.77 for every $1 men earn. #NoMadMenPay",
  "id" : 453600786086641664,
  "created_at" : "2014-04-08 18:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453591125354221569\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/LEubmRDtW0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkt6uZvCAAApKo4.jpg",
      "id_str" : "453591125081587712",
      "id" : 453591125081587712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkt6uZvCAAApKo4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LEubmRDtW0"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 6, 19 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/QCM0noR451",
      "expanded_url" : "http:\/\/go.wh.gov\/5Y9J47",
      "display_url" : "go.wh.gov\/5Y9J47"
    } ]
  },
  "geo" : { },
  "id_str" : "453591125354221569",
  "text" : "\"When #WomenSucceed, America succeeds.\" \u2014President Obama on why he's fighting for #EqualPay: http:\/\/t.co\/QCM0noR451 http:\/\/t.co\/LEubmRDtW0",
  "id" : 453591125354221569,
  "created_at" : "2014-04-08 17:52:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453583068545028096\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ELM6SWii8s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BktzZbpCIAAZcMq.jpg",
      "id_str" : "453583068234653696",
      "id" : 453583068234653696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BktzZbpCIAAZcMq.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ELM6SWii8s"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "EqualPayDay2014",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453583068545028096",
  "text" : "It's long past time to ensure #EqualPay for women. #EqualPayDay2014, http:\/\/t.co\/ELM6SWii8s",
  "id" : 453583068545028096,
  "created_at" : "2014-04-08 17:20:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453576867942244352",
  "text" : "RT @NancyPelosi: On #EqualPay Day, let\u2019s work to make equal pay for equal work more than a mantra, but a reality for all Americans: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/453558312907182080\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/UGByrjIFYq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bktc4e4CEAAofMI.png",
        "id_str" : "453558312911376384",
        "id" : 453558312911376384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bktc4e4CEAAofMI.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UGByrjIFYq"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 3, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453558312907182080",
    "text" : "On #EqualPay Day, let\u2019s work to make equal pay for equal work more than a mantra, but a reality for all Americans: http:\/\/t.co\/UGByrjIFYq",
    "id" : 453558312907182080,
    "created_at" : "2014-04-08 15:41:43 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 453576867942244352,
  "created_at" : "2014-04-08 16:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453567652955709440",
  "text" : "\u201CI\u2019ve got two daughters, and I expect them to be treated just like anybody\u2019s sons.\u201D \u2014President Obama on #EqualPay for women",
  "id" : 453567652955709440,
  "created_at" : "2014-04-08 16:18:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453567147101655040",
  "text" : "President Obama: \"If you care about this issue, let your senators know where you stand. Because America deserves #EqualPay for equal work.\"",
  "id" : 453567147101655040,
  "created_at" : "2014-04-08 16:16:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453566052690325504",
  "text" : "\"A majority of senators support this bill. But 2 years ago, a minority of Senate Republicans blocked it\" \u2014Obama on the Paycheck Fairness Act",
  "id" : 453566052690325504,
  "created_at" : "2014-04-08 16:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453565460962091009",
  "text" : "\"America, you don't have to sit still. You can make sure you're putting pressure on members of Congress\" \u2014Obama on the Paycheck Fairness Act",
  "id" : 453565460962091009,
  "created_at" : "2014-04-08 16:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453565018643398656",
  "text" : "\"She lost more than $200K in salary, even more in pension &amp; Social Security benefits...because she was a woman.\" \u2014Obama on Lilly Ledbetter",
  "id" : 453565018643398656,
  "created_at" : "2014-04-08 16:08:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453564838292488192",
  "text" : "RT @WHLive: \"Tomorrow, the Senate has the chance to start making this right by passing a bill called the Paycheck Fairness Act.\" \u2014Obama on \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453564764711821312",
    "text" : "\"Tomorrow, the Senate has the chance to start making this right by passing a bill called the Paycheck Fairness Act.\" \u2014Obama on #EqualPay",
    "id" : 453564764711821312,
    "created_at" : "2014-04-08 16:07:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 453564838292488192,
  "created_at" : "2014-04-08 16:07:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453564523585482753",
  "text" : "President Obama: \"Today, the average full-time working woman earns just $0.77 for every $1 that a man earns.\" #EqualPay",
  "id" : 453564523585482753,
  "created_at" : "2014-04-08 16:06:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 6, 19 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453564441603633152",
  "text" : "\"When #WomenSucceed, America succeeds.\" \u2014President Obama on why he's fighting for #EqualPay",
  "id" : 453564441603633152,
  "created_at" : "2014-04-08 16:06:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453563916518699009",
  "text" : "RT @WHLive: \"More than 7 million Americans now have signed up for health coverage under the Affordable Care Act.\" \u2014Obama: http:\/\/t.co\/2CPMP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/453563814210834432\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/2CPMPAtsfN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkth4sACEAAehgp.jpg",
        "id_str" : "453563813992730624",
        "id" : 453563813992730624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkth4sACEAAehgp.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2CPMPAtsfN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453563814210834432",
    "text" : "\"More than 7 million Americans now have signed up for health coverage under the Affordable Care Act.\" \u2014Obama: http:\/\/t.co\/2CPMPAtsfN",
    "id" : 453563814210834432,
    "created_at" : "2014-04-08 16:03:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 453563916518699009,
  "created_at" : "2014-04-08 16:03:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453563589933412352",
  "text" : "\"America should be a level playing field\u2014a fair race\u2014a place where anyone who works hard has the chance to get ahead.\" \u2014Obama #EqualPay",
  "id" : 453563589933412352,
  "created_at" : "2014-04-08 16:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453563120896978944",
  "text" : "Obama on Lilly Ledbetter: \"She set out to make sure this country lived up to it\u2019s founding: the idea that all of us are created equal.\"",
  "id" : 453563120896978944,
  "created_at" : "2014-04-08 16:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453562752037294080",
  "text" : "President Obama: \"Thanks to my friend, Lilly Ledbetter...for fighting for a simple principle: #EqualPay for equal work.\"",
  "id" : 453562752037294080,
  "created_at" : "2014-04-08 15:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/WMTQ6V7cKs",
      "expanded_url" : "http:\/\/go.wh.gov\/VtqDRq",
      "display_url" : "go.wh.gov\/VtqDRq"
    } ]
  },
  "geo" : { },
  "id_str" : "453561164778438656",
  "text" : "Happening now: President Obama speaks on why it's time to ensure #EqualPay for women \u2192 http:\/\/t.co\/WMTQ6V7cKs #WomenSucceed",
  "id" : 453561164778438656,
  "created_at" : "2014-04-08 15:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 55, 64 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/cXErg4oAct",
      "expanded_url" : "http:\/\/go.wh.gov\/VtqDRq",
      "display_url" : "go.wh.gov\/VtqDRq"
    } ]
  },
  "geo" : { },
  "id_str" : "453555423170154496",
  "text" : "Watch President Obama speak on why it's time to ensure #EqualPay for women at 11:45am ET \u2192 http:\/\/t.co\/cXErg4oAct #WomenSucceed",
  "id" : 453555423170154496,
  "created_at" : "2014-04-08 15:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/L8ZWUBlxzm",
      "expanded_url" : "http:\/\/go.wh.gov\/KiwfxN",
      "display_url" : "go.wh.gov\/KiwfxN"
    } ]
  },
  "geo" : { },
  "id_str" : "453550386289205249",
  "text" : "When #WomenSucceed, America succeeds. That's why President Obama's fighting for #EqualPay for women \u2192 http:\/\/t.co\/L8ZWUBlxzm",
  "id" : 453550386289205249,
  "created_at" : "2014-04-08 15:10:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453541168048242688",
  "text" : "FACT: Full-time working women still earn just $0.77 for every $1 men earn.\n\nRT if you agree it's time to change that. #WomenSucceed",
  "id" : 453541168048242688,
  "created_at" : "2014-04-08 14:33:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PoSsKT4hrY",
      "expanded_url" : "http:\/\/go.wh.gov\/KiwfxN",
      "display_url" : "go.wh.gov\/KiwfxN"
    } ]
  },
  "geo" : { },
  "id_str" : "453529731368222720",
  "text" : "Worth sharing: Here's how President Obama's expanding opportunity by fighting for #EqualPay for women \u2192 http:\/\/t.co\/PoSsKT4hrY #WomenSucceed",
  "id" : 453529731368222720,
  "created_at" : "2014-04-08 13:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aretha Franklin",
      "screen_name" : "ArethaFranklin",
      "indices" : [ 61, 76 ],
      "id_str" : "469478156",
      "id" : 469478156
    }, {
      "name" : "Janelle Mon\u00E1e, Cindi",
      "screen_name" : "JanelleMonae",
      "indices" : [ 78, 91 ],
      "id_str" : "12266442",
      "id" : 12266442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenOfSoul",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/lFOolbD3jt",
      "expanded_url" : "http:\/\/youtu.be\/ZguiNXjBiJg",
      "display_url" : "youtu.be\/ZguiNXjBiJg"
    } ]
  },
  "geo" : { },
  "id_str" : "453340245774196738",
  "text" : "In Performance at the White House: Go behind the scenes with @ArethaFranklin, @JanelleMonae, and more \u2192 http:\/\/t.co\/lFOolbD3jt #WomenOfSoul",
  "id" : 453340245774196738,
  "created_at" : "2014-04-08 01:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 13, 25 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PointsOfLight",
      "indices" : [ 36, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453330969979027456",
  "text" : "Great to see @Number10gov launch UK #PointsOfLight\u2014an exciting partnership recognizing outstanding service on both sides of the pond. -bo",
  "id" : 453330969979027456,
  "created_at" : "2014-04-08 00:38:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/3tv4yKlpV2",
      "expanded_url" : "http:\/\/go.wh.gov\/YgbtvK",
      "display_url" : "go.wh.gov\/YgbtvK"
    } ]
  },
  "geo" : { },
  "id_str" : "453317595203002368",
  "text" : "Obama on the Senate vote to #RenewUI: \"I urge House Republicans to stop blocking a bipartisan compromise.\" http:\/\/t.co\/3tv4yKlpV2",
  "id" : 453317595203002368,
  "created_at" : "2014-04-07 23:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/utpXaFFoue",
      "expanded_url" : "http:\/\/go.wh.gov\/YgbtvK",
      "display_url" : "go.wh.gov\/YgbtvK"
    } ]
  },
  "geo" : { },
  "id_str" : "453311055616565250",
  "text" : "President Obama on the Senate's bipartisan vote to #RenewUI for 2.3 million Americans \u2192 http:\/\/t.co\/utpXaFFoue",
  "id" : 453311055616565250,
  "created_at" : "2014-04-07 23:19:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453304350350118912\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6TnXa667b3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkp155tCUAEVZbb.jpg",
      "id_str" : "453304350106865665",
      "id" : 453304350106865665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkp155tCUAEVZbb.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6TnXa667b3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/FxsUxidHpe",
      "expanded_url" : "http:\/\/go.wh.gov\/x8xJge",
      "display_url" : "go.wh.gov\/x8xJge"
    } ]
  },
  "geo" : { },
  "id_str" : "453304350350118912",
  "text" : "\"A world-class education means preparing every young person w\/ the skills they need.\" \u2014Obama: http:\/\/t.co\/FxsUxidHpe http:\/\/t.co\/6TnXa667b3",
  "id" : 453304350350118912,
  "created_at" : "2014-04-07 22:52:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 86, 93 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "453255311043067904",
  "text" : "Watch President Obama speak at the Ceremonial Swearing In of Maria Contreras-Sweet as @SBAgov Administrator \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 453255311043067904,
  "created_at" : "2014-04-07 19:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/gQNmcCNx9R",
      "expanded_url" : "http:\/\/go.wh.gov\/9pzFMV",
      "display_url" : "go.wh.gov\/9pzFMV"
    } ]
  },
  "geo" : { },
  "id_str" : "453239865019469825",
  "text" : "\"There\u2019s only one group who can get the job done for the entire country\u2014that\u2019s Congress.\" \u2014Obama: http:\/\/t.co\/gQNmcCNx9R #RaiseTheWage",
  "id" : 453239865019469825,
  "created_at" : "2014-04-07 18:36:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gQNmcCNx9R",
      "expanded_url" : "http:\/\/go.wh.gov\/9pzFMV",
      "display_url" : "go.wh.gov\/9pzFMV"
    } ]
  },
  "geo" : { },
  "id_str" : "453227311052369921",
  "text" : "Obama: \"The MD Legislature did the right thing for its workers today by increasing the state minimum wage to $10.10.\" http:\/\/t.co\/gQNmcCNx9R",
  "id" : 453227311052369921,
  "created_at" : "2014-04-07 17:46:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453217037905428481\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/z7JbrD1Nuw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkomfp2CAAA-ONi.jpg",
      "id_str" : "453217037754433536",
      "id" : 453217037754433536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkomfp2CAAA-ONi.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z7JbrD1Nuw"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453217037905428481",
  "text" : "Maryland's Legislature just voted to #RaiseTheWage to $10.10.\n\nRT if you agree we should raise it for all Americans. http:\/\/t.co\/z7JbrD1Nuw",
  "id" : 453217037905428481,
  "created_at" : "2014-04-07 17:05:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453209123707174912",
  "text" : "RT @GovernorOMalley: Our General Assembly voted to #RaiseTheWage in Maryland - it's time Congress does the same for the rest of the country.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 30, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453204961619243009",
    "text" : "Our General Assembly voted to #RaiseTheWage in Maryland - it's time Congress does the same for the rest of the country.",
    "id" : 453204961619243009,
    "created_at" : "2014-04-07 16:17:37 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 453209123707174912,
  "created_at" : "2014-04-07 16:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453198696700973056",
  "text" : "Obama: \"Businesses and foundations around the country want to help fund more CareerConnect programs\u2014because it\u2019s in their interest.\"",
  "id" : 453198696700973056,
  "created_at" : "2014-04-07 15:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453198414604685313",
  "text" : "Obama: \"We want an education that engages you; an education that equips you with the rigorous &amp; relevant skills for college &amp; your career.\"",
  "id" : 453198414604685313,
  "created_at" : "2014-04-07 15:51:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453196198351237120",
  "text" : "\"No young person should be denied a higher education just because your family has trouble affording it\" \u2014President Obama #CollegeOpportunity",
  "id" : 453196198351237120,
  "created_at" : "2014-04-07 15:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453195550750277633\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uUqiWTJFt1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkoS87yCIAA5lle.jpg",
      "id_str" : "453195550553153536",
      "id" : 453195550553153536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkoS87yCIAA5lle.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/uUqiWTJFt1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453195550750277633",
  "text" : "\"More than 7 million Americans have now signed up for health coverage through the Affordable Care Act.\" \u2014Obama http:\/\/t.co\/uUqiWTJFt1",
  "id" : 453195550750277633,
  "created_at" : "2014-04-07 15:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/453195322764718080\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/POMoFF23gb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkoSvqRCUAEQr1M.jpg",
      "id_str" : "453195322513051649",
      "id" : 453195322513051649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkoSvqRCUAEQr1M.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/POMoFF23gb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453195322764718080",
  "text" : "\"Our businesses have created almost 9 million new jobs over the last four years.\" \u2014President Obama http:\/\/t.co\/POMoFF23gb",
  "id" : 453195322764718080,
  "created_at" : "2014-04-07 15:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453194895403253761",
  "text" : "\"You all remind me...that young people today are working on cooler stuff than I ever was in high school.\" \u2014Obama in MD #CollegeOpportunity",
  "id" : 453194895403253761,
  "created_at" : "2014-04-07 15:37:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/TERjeG2aiH",
      "expanded_url" : "http:\/\/go.wh.gov\/2L1rLF",
      "display_url" : "go.wh.gov\/2L1rLF"
    } ]
  },
  "geo" : { },
  "id_str" : "453194776100495360",
  "text" : "Happening now: President Obama speaks on his plan to help connect education with good jobs \u2192 http:\/\/t.co\/TERjeG2aiH",
  "id" : 453194776100495360,
  "created_at" : "2014-04-07 15:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/TERjeG2aiH",
      "expanded_url" : "http:\/\/go.wh.gov\/2L1rLF",
      "display_url" : "go.wh.gov\/2L1rLF"
    } ]
  },
  "geo" : { },
  "id_str" : "453185786113175552",
  "text" : "Watch President Obama speak at 11:35am ET on helping high school students gain access to real-world career skills \u2192 http:\/\/t.co\/TERjeG2aiH",
  "id" : 453185786113175552,
  "created_at" : "2014-04-07 15:01:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 107, 113 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/1CnAn1kZE6",
      "expanded_url" : "http:\/\/on.msnbc.com\/1fY7iJW",
      "display_url" : "on.msnbc.com\/1fY7iJW"
    } ]
  },
  "geo" : { },
  "id_str" : "453183885514637312",
  "text" : "RT @pfeiffer44: With his 'pen and phone,' Obama tackles education and equal pay http:\/\/t.co\/1CnAn1kZE6 via @msnbc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 91, 97 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/1CnAn1kZE6",
        "expanded_url" : "http:\/\/on.msnbc.com\/1fY7iJW",
        "display_url" : "on.msnbc.com\/1fY7iJW"
      } ]
    },
    "geo" : { },
    "id_str" : "453164486988292096",
    "text" : "With his 'pen and phone,' Obama tackles education and equal pay http:\/\/t.co\/1CnAn1kZE6 via @msnbc",
    "id" : 453164486988292096,
    "created_at" : "2014-04-07 13:36:47 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 453183885514637312,
  "created_at" : "2014-04-07 14:53:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OnssdvKiNy",
      "expanded_url" : "http:\/\/go.wh.gov\/cANe3h",
      "display_url" : "go.wh.gov\/cANe3h"
    } ]
  },
  "geo" : { },
  "id_str" : "452974160956780544",
  "text" : "The GOP \"budget guts the rules we put in place to protect the middle class from another financial crisis.\" \u2014Obama: http:\/\/t.co\/OnssdvKiNy",
  "id" : 452974160956780544,
  "created_at" : "2014-04-07 01:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/0hOxSFoKPW",
      "expanded_url" : "http:\/\/go.wh.gov\/oV8x8g",
      "display_url" : "go.wh.gov\/oV8x8g"
    } ]
  },
  "geo" : { },
  "id_str" : "452897653202755585",
  "text" : "\"It shrinks opportunity &amp; makes it harder for Americans who work hard to get ahead.\" \u2014Obama on the House GOP budget: http:\/\/t.co\/0hOxSFoKPW",
  "id" : 452897653202755585,
  "created_at" : "2014-04-06 19:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Az1qmpT3dt",
      "expanded_url" : "http:\/\/go.wh.gov\/djb8bi",
      "display_url" : "go.wh.gov\/djb8bi"
    } ]
  },
  "geo" : { },
  "id_str" : "452819386298941440",
  "text" : "\"Our economy doesn\u2019t grow best from the top-down; it grows best from the middle-out.\" \u2014Obama: http:\/\/t.co\/Az1qmpT3dt #OpportunityForAll",
  "id" : 452819386298941440,
  "created_at" : "2014-04-06 14:45:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 70, 88 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/7V3HxnxZs0",
      "expanded_url" : "http:\/\/go.wh.gov\/6AT3i9",
      "display_url" : "go.wh.gov\/6AT3i9"
    } ]
  },
  "geo" : { },
  "id_str" : "452564199827185664",
  "text" : "\"The budget I sent Congress earlier this year is built on the idea of #OpportunityForAll.\" \u2014Obama: http:\/\/t.co\/7V3HxnxZs0 #OpportunityForAll",
  "id" : 452564199827185664,
  "created_at" : "2014-04-05 21:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6KeiuGJ6pM",
      "expanded_url" : "http:\/\/go.wh.gov\/vbfSnh",
      "display_url" : "go.wh.gov\/vbfSnh"
    } ]
  },
  "geo" : { },
  "id_str" : "452537243828506626",
  "text" : "\"I congratulate the millions of Afghans who enthusiastically participated in today\u2019s historic elections\" Statement: http:\/\/t.co\/6KeiuGJ6pM",
  "id" : 452537243828506626,
  "created_at" : "2014-04-05 20:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/qqwQpsaP69",
      "expanded_url" : "http:\/\/go.wh.gov\/wzhWN6",
      "display_url" : "go.wh.gov\/wzhWN6"
    } ]
  },
  "geo" : { },
  "id_str" : "452498516351283200",
  "text" : "President Obama's Weekly Address: Ensuring opportunity for all hardworking Americans \u2192 http:\/\/t.co\/qqwQpsaP69 #OpportunityForAll",
  "id" : 452498516351283200,
  "created_at" : "2014-04-05 17:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 69, 88 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6MkQjoy6Et",
      "expanded_url" : "http:\/\/go.wh.gov\/RzqeSe",
      "display_url" : "go.wh.gov\/RzqeSe"
    } ]
  },
  "geo" : { },
  "id_str" : "452449441350311936",
  "text" : "President Obama's #OpportunityForAll agenda:\n+ Jobs\n+ Job training\n\u2191 #CollegeOpportunity\n#RaiseTheWage\nWatch \u2192 http:\/\/t.co\/6MkQjoy6Et",
  "id" : 452449441350311936,
  "created_at" : "2014-04-05 14:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452216599815417857",
  "text" : "RT @LaborSec: We are at near-record levels of long-term unemployment. The most immediate thing we can do to help is pass emergency UI comp.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "452187480641785857",
    "text" : "We are at near-record levels of long-term unemployment. The most immediate thing we can do to help is pass emergency UI comp. #RenewUI",
    "id" : 452187480641785857,
    "created_at" : "2014-04-04 20:54:31 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 452216599815417857,
  "created_at" : "2014-04-04 22:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/P2LyRXGtRH",
      "expanded_url" : "http:\/\/go.wh.gov\/6wuH1i",
      "display_url" : "go.wh.gov\/6wuH1i"
    } ]
  },
  "geo" : { },
  "id_str" : "452192746040614914",
  "text" : "FACT: Thanks to the Affordable Care Act, Kentucky has seen a 40% drop in its uninsured rate since Oct 1. http:\/\/t.co\/P2LyRXGtRH #GetCovered",
  "id" : 452192746040614914,
  "created_at" : "2014-04-04 21:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 56, 67 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "EasterEggRoll",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/BuJn0XdkAv",
      "expanded_url" : "http:\/\/wh.gov\/eer",
      "display_url" : "wh.gov\/eer"
    } ]
  },
  "geo" : { },
  "id_str" : "452187799429857280",
  "text" : "RT @ks44: Announcing the next #WHSocial: Join us at the @WhiteHouse for the annual #EasterEggRoll \u2192 http:\/\/t.co\/BuJn0XdkAv http:\/\/t.co\/XjBY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 46, 57 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/452185097072943104\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/XjBYjp1Nhe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkZ78y0CcAALF5d.jpg",
        "id_str" : "452185096959717376",
        "id" : 452185096959717376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkZ78y0CcAALF5d.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 805
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 805
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XjBYjp1Nhe"
      } ],
      "hashtags" : [ {
        "text" : "WHSocial",
        "indices" : [ 20, 29 ]
      }, {
        "text" : "EasterEggRoll",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/BuJn0XdkAv",
        "expanded_url" : "http:\/\/wh.gov\/eer",
        "display_url" : "wh.gov\/eer"
      } ]
    },
    "geo" : { },
    "id_str" : "452185097072943104",
    "text" : "Announcing the next #WHSocial: Join us at the @WhiteHouse for the annual #EasterEggRoll \u2192 http:\/\/t.co\/BuJn0XdkAv http:\/\/t.co\/XjBYjp1Nhe",
    "id" : 452185097072943104,
    "created_at" : "2014-04-04 20:45:03 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 452187799429857280,
  "created_at" : "2014-04-04 20:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/452147324429402112\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ir2cauztHo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkZZmIcCMAAtqgp.jpg",
      "id_str" : "452147324232282112",
      "id" : 452147324232282112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkZZmIcCMAAtqgp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ir2cauztHo"
    } ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 0, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452147324429402112",
  "text" : "#7MillionAndCounting have signed up for private plans through the ACA\u2014enough to sell out the Big House for 65 games. http:\/\/t.co\/Ir2cauztHo",
  "id" : 452147324429402112,
  "created_at" : "2014-04-04 18:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 53, 57 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/P2LyRXGtRH",
      "expanded_url" : "http:\/\/go.wh.gov\/6wuH1i",
      "display_url" : "go.wh.gov\/6wuH1i"
    } ]
  },
  "geo" : { },
  "id_str" : "452136123557376000",
  "text" : "FACT: States refusing to expand Medicaid through the #ACA are denying coverage to 5.7 million Americans \u2192 http:\/\/t.co\/P2LyRXGtRH #GetCovered",
  "id" : 452136123557376000,
  "created_at" : "2014-04-04 17:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 26, 30 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/k3ZmcZ3j6l",
      "expanded_url" : "http:\/\/go.wh.gov\/hwy7vN",
      "display_url" : "go.wh.gov\/hwy7vN"
    } ]
  },
  "geo" : { },
  "id_str" : "452129215933345792",
  "text" : "Great news: Thanks to the #ACA, 3 million more Americans were covered through Medicaid as of March 1st \u2192 http:\/\/t.co\/k3ZmcZ3j6l #GetCovered",
  "id" : 452129215933345792,
  "created_at" : "2014-04-04 17:02:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/452083216002740225\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/LcE3LOWDBv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkYfShvCYAEzUeK.jpg",
      "id_str" : "452083215751077889",
      "id" : 452083215751077889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkYfShvCYAEzUeK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LcE3LOWDBv"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/zUu0YoQoKZ",
      "expanded_url" : "http:\/\/go.wh.gov\/7kQhru",
      "display_url" : "go.wh.gov\/7kQhru"
    } ]
  },
  "geo" : { },
  "id_str" : "452094598462971905",
  "text" : "FACT: Our manufacturers have added nearly 100,000 jobs since July. http:\/\/t.co\/zUu0YoQoKZ #MadeInAmerica http:\/\/t.co\/LcE3LOWDBv",
  "id" : 452094598462971905,
  "created_at" : "2014-04-04 14:45:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/WaiH05X2S5",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/04\/04\/employment-situation-march",
      "display_url" : "whitehouse.gov\/blog\/2014\/04\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452087096241819648",
  "text" : "RT @CEAChair: The initial estimate of job growth has been revised up in 18 of the last 19 months http:\/\/t.co\/WaiH05X2S5 http:\/\/t.co\/WON6YeM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/452084314415443969\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/WON6YeMzYE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkYgSemCMAE8Pcf.jpg",
        "id_str" : "452084314419638273",
        "id" : 452084314419638273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkYgSemCMAE8Pcf.jpg",
        "sizes" : [ {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 911
        } ],
        "display_url" : "pic.twitter.com\/WON6YeMzYE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/WaiH05X2S5",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/04\/04\/employment-situation-march",
        "display_url" : "whitehouse.gov\/blog\/2014\/04\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452084314415443969",
    "text" : "The initial estimate of job growth has been revised up in 18 of the last 19 months http:\/\/t.co\/WaiH05X2S5 http:\/\/t.co\/WON6YeMzYE",
    "id" : 452084314415443969,
    "created_at" : "2014-04-04 14:04:34 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 452087096241819648,
  "created_at" : "2014-04-04 14:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/452083216002740225\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LcE3LOWDBv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkYfShvCYAEzUeK.jpg",
      "id_str" : "452083215751077889",
      "id" : 452083215751077889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkYfShvCYAEzUeK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LcE3LOWDBv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452083216002740225",
  "text" : "Our businesses have added:\n\u2022 8.9 million jobs over 49 months\n\u2022 2.3 million in the past year\n\u2022 192,000 in March\n\u2192 http:\/\/t.co\/LcE3LOWDBv",
  "id" : 452083216002740225,
  "created_at" : "2014-04-04 14:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 34, 44 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451884006502453250\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vcGvhcRf2H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkVqHAkCUAA9L8m.jpg",
      "id_str" : "451884006263377920",
      "id" : 451884006263377920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkVqHAkCUAA9L8m.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vcGvhcRf2H"
    } ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/4o7E2gO0XO",
      "expanded_url" : "http:\/\/go.wh.gov\/doVRTa",
      "display_url" : "go.wh.gov\/doVRTa"
    } ]
  },
  "geo" : { },
  "id_str" : "451884006502453250",
  "text" : "Check out the highlights from the @USOlympic Team's visit to the White House \u2192 http:\/\/t.co\/4o7E2gO0XO #WHTeamUSA http:\/\/t.co\/vcGvhcRf2H",
  "id" : 451884006502453250,
  "created_at" : "2014-04-04 00:48:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451871875786760192",
  "text" : "\"You remind us, just like the Olympic creed states, the most important thing in life is not the triumph, but the fight.\" \u2014Obama to #TeamUSA",
  "id" : 451871875786760192,
  "created_at" : "2014-04-04 00:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451866842454171650",
  "text" : "\"Women\u2019s ski jumping was added as an Olympic sport, and they did outstanding. So women can fly just like men.\" \u2014President Obama #WHTeamUSA",
  "id" : 451866842454171650,
  "created_at" : "2014-04-03 23:40:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 114, 124 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451861808840601600",
  "text" : "\"Our men\u2019s hockey team played a game for the ages with an epic shootout victory over the Russians.\" \u2014Obama on the @USOlympic Team #WHTeamUSA",
  "id" : 451861808840601600,
  "created_at" : "2014-04-03 23:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 111, 121 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451856775667384320",
  "text" : "\"American women won more medals in the Olympics than women of any other nation.\" \u2014President Obama honoring the @USOlympic Team #WHTeamUSA",
  "id" : 451856775667384320,
  "created_at" : "2014-04-03 23:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451839158902738945",
  "text" : "\"We\u2019re going to make sure that we\u2019re doing everything in our power to keep our troops safe.\" \u2014President Obama on the shooting at #FortHood",
  "id" : 451839158902738945,
  "created_at" : "2014-04-03 21:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortHood",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451836161733181443",
  "text" : "\"We stand with their families and their loved ones as they grieve.\" \u2014President Obama on the victims of the shooting at #FortHood",
  "id" : 451836161733181443,
  "created_at" : "2014-04-03 21:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Innovation",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "Innovategov",
      "indices" : [ 112, 124 ]
    }, {
      "text" : "serve",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/uaHd0SnaMg",
      "expanded_url" : "http:\/\/Pif.gsa.gov",
      "display_url" : "Pif.gsa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "451817231253770240",
  "text" : "RT @whitehouseostp: 1 week left! Apply to the Presidential #Innovation Fellows program: http:\/\/t.co\/uaHd0SnaMg  #Innovategov #serve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Innovation",
        "indices" : [ 39, 50 ]
      }, {
        "text" : "Innovategov",
        "indices" : [ 92, 104 ]
      }, {
        "text" : "serve",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/uaHd0SnaMg",
        "expanded_url" : "http:\/\/Pif.gsa.gov",
        "display_url" : "Pif.gsa.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "451776978744786944",
    "text" : "1 week left! Apply to the Presidential #Innovation Fellows program: http:\/\/t.co\/uaHd0SnaMg  #Innovategov #serve",
    "id" : 451776978744786944,
    "created_at" : "2014-04-03 17:43:20 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 451817231253770240,
  "created_at" : "2014-04-03 20:23:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451805348270055424\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/FMZnu8zo50",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkUikgDCEAARxTY.jpg",
      "id_str" : "451805348093890560",
      "id" : 451805348093890560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkUikgDCEAARxTY.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FMZnu8zo50"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451805348270055424",
  "text" : "RT if you agree: No one who works full time should have to live in poverty. It's time to #RaiseTheWage. http:\/\/t.co\/FMZnu8zo50",
  "id" : 451805348270055424,
  "created_at" : "2014-04-03 19:36:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 41, 51 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    }, {
      "name" : "U.S. Paralympics",
      "screen_name" : "USParalympics",
      "indices" : [ 56, 70 ],
      "id_str" : "28652197",
      "id" : 28652197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/LFCGrEu7Vp",
      "expanded_url" : "http:\/\/go.wh.gov\/dKpH13",
      "display_url" : "go.wh.gov\/dKpH13"
    } ]
  },
  "geo" : { },
  "id_str" : "451792795125436416",
  "text" : "At 3:20pm ET, President Obama honors the @USOlympic and @USParalympics teams at the White House. Watch \u2192 http:\/\/t.co\/LFCGrEu7Vp #WHTeamUSA",
  "id" : 451792795125436416,
  "created_at" : "2014-04-03 18:46:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "indices" : [ 3, 18 ],
      "id_str" : "1074518754",
      "id" : 1074518754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451785306942210048",
  "text" : "RT @SenatorBaldwin: Raising the minimum wage (for tipped workers too) will reward hard work for 15 million women\u2013 including 330,000 women i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Wi",
        "indices" : [ 121, 124 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451739896143962113",
    "text" : "Raising the minimum wage (for tipped workers too) will reward hard work for 15 million women\u2013 including 330,000 women in #Wi. #RaiseTheWage",
    "id" : 451739896143962113,
    "created_at" : "2014-04-03 15:15:58 +0000",
    "user" : {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "protected" : false,
      "id_str" : "1074518754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656152457756692481\/jq9YvUuw_normal.jpg",
      "id" : 1074518754,
      "verified" : true
    }
  },
  "id" : 451785306942210048,
  "created_at" : "2014-04-03 18:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451777977479462912\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/K8Tcd1lxZ9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkUJrT4CUAAfXKC.jpg",
      "id_str" : "451777977294934016",
      "id" : 451777977294934016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkUJrT4CUAAfXKC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K8Tcd1lxZ9"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451777977479462912",
  "text" : "The minimum wage for tipped workers is just $2.13\/hour.\nNearly 3 out of 4 are women.\nIt's time to #RaiseTheWage. http:\/\/t.co\/K8Tcd1lxZ9",
  "id" : 451777977479462912,
  "created_at" : "2014-04-03 17:47:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 3, 18 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451767897703329792",
  "text" : "RT @HillaryClinton: A majority of lower wage jobs are held by women. Raising the minimum wage is good for women &amp; for the economy. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/7UgMrmMIad",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/20140325minimumwageandwomenreportfinal.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451501362464190464",
    "text" : "A majority of lower wage jobs are held by women. Raising the minimum wage is good for women &amp; for the economy. http:\/\/t.co\/7UgMrmMIad",
    "id" : 451501362464190464,
    "created_at" : "2014-04-02 23:28:07 +0000",
    "user" : {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "protected" : false,
      "id_str" : "1339835893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796243884636512260\/zHVoWqKV_normal.jpg",
      "id" : 1339835893,
      "verified" : true
    }
  },
  "id" : 451767897703329792,
  "created_at" : "2014-04-03 17:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451757452107583488\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ewqqe8ITDo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkT3Ak8CUAAgDtT.jpg",
      "id_str" : "451757451931439104",
      "id" : 451757451931439104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkT3Ak8CUAAgDtT.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ewqqe8ITDo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451757452107583488",
  "text" : "On average, women still earn just $0.77 for every $1 men earn.\nRaising the minimum wage would help close that gap. http:\/\/t.co\/ewqqe8ITDo",
  "id" : 451757452107583488,
  "created_at" : "2014-04-03 16:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ohRB8nGnuU",
      "expanded_url" : "http:\/\/go.wh.gov\/zF4EVu",
      "display_url" : "go.wh.gov\/zF4EVu"
    } ]
  },
  "geo" : { },
  "id_str" : "451526552594161664",
  "text" : "President Obama just delivered a statement on the shooting at Fort Hood \u2192 http:\/\/t.co\/ohRB8nGnuU",
  "id" : 451526552594161664,
  "created_at" : "2014-04-03 01:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAutismAwarenessDay",
      "indices" : [ 4, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/iGBGlN1Z4S",
      "expanded_url" : "http:\/\/go.wh.gov\/H2sjwj",
      "display_url" : "go.wh.gov\/H2sjwj"
    } ]
  },
  "geo" : { },
  "id_str" : "451471734655307776",
  "text" : "\"On #WorldAutismAwarenessDay, we offer our support &amp; respect to all those on the autism spectrum.\" \u2014President Obama: http:\/\/t.co\/iGBGlN1Z4S",
  "id" : 451471734655307776,
  "created_at" : "2014-04-02 21:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 3, 14 ],
      "id_str" : "232268199",
      "id" : 232268199
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 121, 132 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreK",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451467631019978752",
  "text" : "RT @NYGovCuomo: Thanks President Obama for your support for statewide #PreK for all NY'ers. Look forward to working with @whitehouse: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 105, 116 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PreK",
        "indices" : [ 54, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/WKrvocTCmZ",
        "expanded_url" : "http:\/\/1.usa.gov\/1s96GtP",
        "display_url" : "1.usa.gov\/1s96GtP"
      } ]
    },
    "geo" : { },
    "id_str" : "451465556676608001",
    "text" : "Thanks President Obama for your support for statewide #PreK for all NY'ers. Look forward to working with @whitehouse: http:\/\/t.co\/WKrvocTCmZ",
    "id" : 451465556676608001,
    "created_at" : "2014-04-02 21:05:51 +0000",
    "user" : {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "protected" : false,
      "id_str" : "232268199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788019377870348288\/83Xj5Zh3_normal.jpg",
      "id" : 232268199,
      "verified" : true
    }
  },
  "id" : 451467631019978752,
  "created_at" : "2014-04-02 21:14:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 25, 36 ],
      "id_str" : "232268199",
      "id" : 232268199
    }, {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 41, 54 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/451459245020434432\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GhWCIlxOQ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkPnypFCMAAXZ5k.png",
      "id_str" : "451459244873625600",
      "id" : 451459244873625600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkPnypFCMAAXZ5k.png",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 668
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 668
      } ],
      "display_url" : "pic.twitter.com\/GhWCIlxOQ1"
    } ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451459245020434432",
  "text" : "President Obama applauds @NYGovCuomo and @BillDeBlasio for expanding access to preschool in New York. #PreKForAll http:\/\/t.co\/GhWCIlxOQ1",
  "id" : 451459245020434432,
  "created_at" : "2014-04-02 20:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451452649057959936\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CZa5JeTaPD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkPhytHCAAASZRu.jpg",
      "id_str" : "451452648885977088",
      "id" : 451452648885977088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkPhytHCAAASZRu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CZa5JeTaPD"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451452649057959936",
  "text" : "The minimum wage for tipped workers has been stuck at $2.13 for more than 20 years.\n\nIt's time to #RaiseTheWage. http:\/\/t.co\/CZa5JeTaPD",
  "id" : 451452649057959936,
  "created_at" : "2014-04-02 20:14:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451441632802791424",
  "text" : "\"We\u2019ve got more work to do to make sure that everyone...knows that America has a place for them.\" \u2014President Obama #OpportunityForAll",
  "id" : 451441632802791424,
  "created_at" : "2014-04-02 19:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451441296952295425",
  "text" : "RT @WHLive: \"We\u2019ve got more jobs to create, and kids to educate, and clean energy to generate.\" \u2014President Obama #OpportunityForAll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 101, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451440499153702912",
    "text" : "\"We\u2019ve got more jobs to create, and kids to educate, and clean energy to generate.\" \u2014President Obama #OpportunityForAll",
    "id" : 451440499153702912,
    "created_at" : "2014-04-02 19:26:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 451441296952295425,
  "created_at" : "2014-04-02 19:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451439734574026752",
  "text" : "\"It\u2019s like that movie Groundhog Day. Except it's not funny.\" \u2014Obama on the House GOP continuing to push for policies that limit opportunity",
  "id" : 451439734574026752,
  "created_at" : "2014-04-02 19:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451438078696378368",
  "text" : "Obama: \"3 in 4 Americans support raising the minimum wage. Here\u2019s the problem. Republicans in Congress don\u2019t want to vote to raise it.\"",
  "id" : 451438078696378368,
  "created_at" : "2014-04-02 19:16:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451437735203438598\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/MwPH9CeWcS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkPUOmfCMAAYJz8.jpg",
      "id_str" : "451437734981152768",
      "id" : 451437734981152768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkPUOmfCMAAYJz8.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MwPH9CeWcS"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451437735203438598",
  "text" : "\"It would help lift wages for nearly 28 million Americans.\" \u2014Obama on raising the minimum wage #RaiseTheWage http:\/\/t.co\/MwPH9CeWcS",
  "id" : 451437735203438598,
  "created_at" : "2014-04-02 19:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451437166946959360",
  "text" : "\"If you cook our troops\u2019 meals or wash their dishes, your country should pay you a living wage.\" \u2014President Obama #RaiseTheWage",
  "id" : 451437166946959360,
  "created_at" : "2014-04-02 19:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451436223253323777\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1NceJ7SYHt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkPS2mcCUAAX4as.jpg",
      "id_str" : "451436223140089856",
      "id" : 451436223140089856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkPS2mcCUAAX4as.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1NceJ7SYHt"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451436223253323777",
  "text" : "\u201CNobody who works full time should have to live in poverty.\u201D \u2014President Obama #RaiseTheWage http:\/\/t.co\/1NceJ7SYHt",
  "id" : 451436223253323777,
  "created_at" : "2014-04-02 19:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/451435658209288192\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/hfxdJpW498",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkPSVtJCMAAAmdo.jpg",
      "id_str" : "451435658003755008",
      "id" : 451435658003755008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkPSVtJCMAAAmdo.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/hfxdJpW498"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451435658209288192",
  "text" : "\u201CI do not want my daughters paid less than somebody else\u2019s sons for doing the same work.\u201D \u2014Obama #EqualPay http:\/\/t.co\/hfxdJpW498",
  "id" : 451435658209288192,
  "created_at" : "2014-04-02 19:07:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451434466310115328",
  "text" : "Obama: \"In America, we don\u2019t believe in opportunity for a few\u2014we believe that everybody should have a chance at success.\" #OpportunityForAll",
  "id" : 451434466310115328,
  "created_at" : "2014-04-02 19:02:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 67, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451434037459316736",
  "text" : "\"7.1 million Americans have now signed up for coverage through the #ACA...that's enough to fill up the Big House 65 times.\" \u2014President Obama",
  "id" : 451434037459316736,
  "created_at" : "2014-04-02 19:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zingerman's",
      "screen_name" : "zingermans",
      "indices" : [ 28, 39 ],
      "id_str" : "20008239",
      "id" : 20008239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451433452173557760",
  "text" : "\"The Reuben is killer...and @Zingermans is a business that treats its workers well.\" \u2014President Obama #RaiseTheWage",
  "id" : 451433452173557760,
  "created_at" : "2014-04-02 18:58:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UniversityofMichigan",
      "screen_name" : "UMich",
      "indices" : [ 88, 94 ],
      "id_str" : "88836132",
      "id" : 88836132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoBlue",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451432741352247296",
  "text" : "\"I have learned my lesson. I will not pick against the Wolverines.\" \u2014President Obama at @UMich on his NCAA Tournament bracket #GoBlue",
  "id" : 451432741352247296,
  "created_at" : "2014-04-02 18:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UniversityofMichigan",
      "screen_name" : "UMich",
      "indices" : [ 38, 44 ],
      "id_str" : "88836132",
      "id" : 88836132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/L77tBJCNn6",
      "expanded_url" : "http:\/\/go.wh.gov\/grP3rD",
      "display_url" : "go.wh.gov\/grP3rD"
    } ]
  },
  "geo" : { },
  "id_str" : "451432035006308353",
  "text" : "Watch live: President Obama speaks at @UMich about why it's time to raise the minimum wage \u2192 http:\/\/t.co\/L77tBJCNn6 #RaiseTheWage",
  "id" : 451432035006308353,
  "created_at" : "2014-04-02 18:52:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cabivele1986",
      "screen_name" : "RepGaryPeters",
      "indices" : [ 3, 17 ],
      "id_str" : "2982232534",
      "id" : 2982232534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451430427182764032",
  "text" : "RT @RepGaryPeters: Raising the minimum wage is good for workers in Michigan and it will strengthen the middle class. Let's work together to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451419050808467456",
    "text" : "Raising the minimum wage is good for workers in Michigan and it will strengthen the middle class. Let's work together to #RaiseTheWage",
    "id" : 451419050808467456,
    "created_at" : "2014-04-02 18:01:03 +0000",
    "user" : {
      "name" : "Senator Gary Peters",
      "screen_name" : "SenGaryPeters",
      "protected" : false,
      "id_str" : "236511574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565664435516506115\/a_4YIiVj_normal.jpeg",
      "id" : 236511574,
      "verified" : true
    }
  },
  "id" : 451430427182764032,
  "created_at" : "2014-04-02 18:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zingerman's",
      "screen_name" : "zingermans",
      "indices" : [ 34, 45 ],
      "id_str" : "20008239",
      "id" : 20008239
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/451426367054155776\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xefL6Fd0dq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkPJ45NCQAA1XTa.jpg",
      "id_str" : "451426366932533248",
      "id" : 451426366932533248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkPJ45NCQAA1XTa.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/xefL6Fd0dq"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451426367054155776",
  "text" : "President Obama just had lunch at @Zingermans to highlight how they pay their employees fair wages. #RaiseTheWage http:\/\/t.co\/xefL6Fd0dq",
  "id" : 451426367054155776,
  "created_at" : "2014-04-02 18:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zingerman's",
      "screen_name" : "zingermans",
      "indices" : [ 3, 14 ],
      "id_str" : "20008239",
      "id" : 20008239
    }, {
      "name" : "BFMW",
      "screen_name" : "MinimumWageBiz",
      "indices" : [ 57, 72 ],
      "id_str" : "2178748327",
      "id" : 2178748327
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/zingermans\/status\/451415144925388801\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ZhYk7xiga4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkO_rrSCQAAhERB.jpg",
      "id_str" : "451415144740831232",
      "id" : 451415144740831232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkO_rrSCQAAhERB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/ZhYk7xiga4"
    } ],
    "hashtags" : [ {
      "text" : "Zingermans",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451418377010307072",
  "text" : "RT @zingermans: President Obama visits #Zingermans Deli! @minimumwagebiz http:\/\/t.co\/ZhYk7xiga4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BFMW",
        "screen_name" : "MinimumWageBiz",
        "indices" : [ 41, 56 ],
        "id_str" : "2178748327",
        "id" : 2178748327
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/zingermans\/status\/451415144925388801\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/ZhYk7xiga4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkO_rrSCQAAhERB.jpg",
        "id_str" : "451415144740831232",
        "id" : 451415144740831232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkO_rrSCQAAhERB.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/ZhYk7xiga4"
      } ],
      "hashtags" : [ {
        "text" : "Zingermans",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451415144925388801",
    "text" : "President Obama visits #Zingermans Deli! @minimumwagebiz http:\/\/t.co\/ZhYk7xiga4",
    "id" : 451415144925388801,
    "created_at" : "2014-04-02 17:45:32 +0000",
    "user" : {
      "name" : "Zingerman's",
      "screen_name" : "zingermans",
      "protected" : false,
      "id_str" : "20008239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2624207520\/h6gpc8b1kxrr1oj020ci_normal.jpeg",
      "id" : 20008239,
      "verified" : false
    }
  },
  "id" : 451418377010307072,
  "created_at" : "2014-04-02 17:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 43, 58 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451415244053942272",
  "text" : "RT @Lehrich44: As Obama calls for $10.10...@HuffingtonPost: \"Even Goldman Sachs Analysts Say A Minimum Wage Hike Wouldn't Kill Jobs\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 28, 43 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/DTIh6EHl51",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/04\/02\/goldman-sachs-minimum-wage_n_5077677.html?1396459803",
        "display_url" : "huffingtonpost.com\/2014\/04\/02\/gol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451414413409792000",
    "text" : "As Obama calls for $10.10...@HuffingtonPost: \"Even Goldman Sachs Analysts Say A Minimum Wage Hike Wouldn't Kill Jobs\" http:\/\/t.co\/DTIh6EHl51",
    "id" : 451414413409792000,
    "created_at" : "2014-04-02 17:42:37 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 451415244053942272,
  "created_at" : "2014-04-02 17:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DAZgQ5i86u",
      "expanded_url" : "http:\/\/go.wh.gov\/p4kHsu",
      "display_url" : "go.wh.gov\/p4kHsu"
    } ]
  },
  "geo" : { },
  "id_str" : "451413402318299137",
  "text" : "Raising the min wage will help millions of Americans. Share how it would help you or someone you know \u2192 http:\/\/t.co\/DAZgQ5i86u #RaiseTheWage",
  "id" : 451413402318299137,
  "created_at" : "2014-04-02 17:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 113, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/oSIcn2efSe",
      "expanded_url" : "http:\/\/go.wh.gov\/wpYoZp",
      "display_url" : "go.wh.gov\/wpYoZp"
    } ]
  },
  "geo" : { },
  "id_str" : "451398998176575488",
  "text" : "\"This law will continue to make life better for millions of Americans.\" \u2014President Obama: http:\/\/t.co\/oSIcn2efSe #7MillionAndCounting",
  "id" : 451398998176575488,
  "created_at" : "2014-04-02 16:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451389179406995457\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qf2WZeX9pv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkOoESECMAAQMvO.jpg",
      "id_str" : "451389179188883456",
      "id" : 451389179188883456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkOoESECMAAQMvO.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qf2WZeX9pv"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/8rowSAYxvN",
      "expanded_url" : "http:\/\/go.wh.gov\/HDGkTP",
      "display_url" : "go.wh.gov\/HDGkTP"
    } ]
  },
  "geo" : { },
  "id_str" : "451389179406995457",
  "text" : "FACT: Raising the minimum wage would benefit more than 28 million Americans \u2192 http:\/\/t.co\/8rowSAYxvN #RaiseTheWage http:\/\/t.co\/qf2WZeX9pv",
  "id" : 451389179406995457,
  "created_at" : "2014-04-02 16:02:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451378401811513344\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/n7dQBtc2wK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkOeQ8kCYAANN74.jpg",
      "id_str" : "451378401639555072",
      "id" : 451378401639555072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkOeQ8kCYAANN74.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n7dQBtc2wK"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451378401811513344",
  "text" : "Who makes the minimum wage?\nMore than half \u2192 Women\nMore than half \u2192 Work full time\nIt's time to #RaiseTheWage. http:\/\/t.co\/n7dQBtc2wK",
  "id" : 451378401811513344,
  "created_at" : "2014-04-02 15:19:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 3, 17 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451372855746646016",
  "text" : "RT @StephenAtHome: More than 7.1 million people signed up for Obamacare. So embarrassing. Obama missed his goal of 7 million people by over\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451202563699138560",
    "text" : "More than 7.1 million people signed up for Obamacare. So embarrassing. Obama missed his goal of 7 million people by over 100,000.",
    "id" : 451202563699138560,
    "created_at" : "2014-04-02 03:40:48 +0000",
    "user" : {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "protected" : false,
      "id_str" : "16303106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627669832549441536\/hv1AMpO0_normal.jpg",
      "id" : 16303106,
      "verified" : true
    }
  },
  "id" : 451372855746646016,
  "created_at" : "2014-04-02 14:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/451142532798226433\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/1rzRmzv9aY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkLHvjdCMAEC-Kt.jpg",
      "id_str" : "451142532475269121",
      "id" : 451142532475269121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkLHvjdCMAEC-Kt.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1rzRmzv9aY"
    } ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 10, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451142532798226433",
  "text" : "Progress. #7MillionAndCounting http:\/\/t.co\/1rzRmzv9aY",
  "id" : 451142532798226433,
  "created_at" : "2014-04-01 23:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 31, 38 ],
      "id_str" : "40918816",
      "id" : 40918816
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451128826982961152\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kA85Kht70J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkK7Rx9CAAMLA3e.jpg",
      "id_str" : "451128826831962115",
      "id" : 451128826831962115,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkK7Rx9CAAMLA3e.jpg",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kA85Kht70J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/KYWoUzmOva",
      "expanded_url" : "http:\/\/go.wh.gov\/92JBBU",
      "display_url" : "go.wh.gov\/92JBBU"
    } ]
  },
  "geo" : { },
  "id_str" : "451128826982961152",
  "text" : "\"Congratulations to the Boston @RedSox...good luck this season. May the best Sox win\" \u2014Obama: http:\/\/t.co\/KYWoUzmOva http:\/\/t.co\/kA85Kht70J",
  "id" : 451128826982961152,
  "created_at" : "2014-04-01 22:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    }, {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 134, 141 ],
      "id_str" : "40918816",
      "id" : 40918816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451116898747285504",
  "text" : "RT @Jordan44: Comeback day at the White House: Obamacare fights its way back to hit 7mn goal &amp; worst-to-first World Series champs @RedSox d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boston Red Sox",
        "screen_name" : "RedSox",
        "indices" : [ 120, 127 ],
        "id_str" : "40918816",
        "id" : 40918816
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451114838115483648",
    "text" : "Comeback day at the White House: Obamacare fights its way back to hit 7mn goal &amp; worst-to-first World Series champs @RedSox drop by.",
    "id" : 451114838115483648,
    "created_at" : "2014-04-01 21:52:13 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 451116898747285504,
  "created_at" : "2014-04-01 22:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siapa saya",
      "screen_name" : "evanmcsan",
      "indices" : [ 3, 13 ],
      "id_str" : "777412254560124928",
      "id" : 777412254560124928
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 43, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451109876501336065",
  "text" : "RT @EvanMcSan: nearly 14,000 tweets on the #7MillionAndCounting hashtag today, per WH stats. Here\u2019s WH Topsy chart of ACA tags http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EvanMcSan\/status\/451108535175090176\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/eg96VC9cfS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKo0o3CYAA_bZg.png",
        "id_str" : "451108534965395456",
        "id" : 451108534965395456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKo0o3CYAA_bZg.png",
        "sizes" : [ {
          "h" : 388,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eg96VC9cfS"
      } ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 28, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451108535175090176",
    "text" : "nearly 14,000 tweets on the #7MillionAndCounting hashtag today, per WH stats. Here\u2019s WH Topsy chart of ACA tags http:\/\/t.co\/eg96VC9cfS",
    "id" : 451108535175090176,
    "created_at" : "2014-04-01 21:27:10 +0000",
    "user" : {
      "name" : "E McMorris-Santoro",
      "screen_name" : "EvanMcS",
      "protected" : false,
      "id_str" : "20281013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771409622649364480\/Lt3Ex868_normal.jpg",
      "id" : 20281013,
      "verified" : true
    }
  },
  "id" : 451109876501336065,
  "created_at" : "2014-04-01 21:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451106917965119488",
  "text" : "RT @vj44: \u201CAfter using my new insurance for the 1st time\u2026I felt like a human being again. I felt that I had value.\u201D\u2014Marla Morine #7MillionA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 119, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451106761072988162",
    "text" : "\u201CAfter using my new insurance for the 1st time\u2026I felt like a human being again. I felt that I had value.\u201D\u2014Marla Morine #7MillionAndCounting",
    "id" : 451106761072988162,
    "created_at" : "2014-04-01 21:20:07 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 451106917965119488,
  "created_at" : "2014-04-01 21:20:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 120, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451095779839868928",
  "text" : "Obama: \"The goal we\u2019ve set for ourselves\u2014that no American should go without the health care they need...is achievable.\" #7MillionAndCounting",
  "id" : 451095779839868928,
  "created_at" : "2014-04-01 20:36:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 104, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451095308823707649",
  "text" : "\"That's why 7.1 million people got health insurance. Because people got the word out.\" \u2014President Obama #7MillionAndCounting",
  "id" : 451095308823707649,
  "created_at" : "2014-04-01 20:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451094900621459456",
  "text" : "RT @WHLive: \"History isn\u2019t kind to those who would deny Americans their basic economic security.\" \u2014Obama on those who have tried to repeal \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451094813832937474",
    "text" : "\"History isn\u2019t kind to those who would deny Americans their basic economic security.\" \u2014Obama on those who have tried to repeal the ACA",
    "id" : 451094813832937474,
    "created_at" : "2014-04-01 20:32:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 451094900621459456,
  "created_at" : "2014-04-01 20:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 78, 98 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451094689006235648",
  "text" : "President Obama: \"Why are folks so mad about people having health insurance?\" #7MillionAndCounting #ACAWorks",
  "id" : 451094689006235648,
  "created_at" : "2014-04-01 20:32:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "7MillionAndCounting",
      "indices" : [ 111, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451094309555929088",
  "text" : "\"The debate over repealing this law is over. The Affordable Care Act here to stay.\" \u2014President Obama #ACAWorks #7MillionAndCounting",
  "id" : 451094309555929088,
  "created_at" : "2014-04-01 20:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 119, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451094039723380736",
  "text" : "\"This law is doing what it is supposed to do. It\u2019s working. It\u2019s helping people from coast to coast.\" \u2014President Obama #7MillionAndCounting",
  "id" : 451094039723380736,
  "created_at" : "2014-04-01 20:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 101, 121 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451093887504117760",
  "text" : "\"Women, the sick, survivors\u2014they deserve fair treatment in our health care system.\" \u2014President Obama #7MillionAndCounting #ACAWorks",
  "id" : 451093887504117760,
  "created_at" : "2014-04-01 20:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 110, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451092691187933184",
  "text" : "Obama: \"Because of this law, millions of our fellow citizens know the economic security of health insurance.\" #7MillionAndCounting",
  "id" : 451092691187933184,
  "created_at" : "2014-04-01 20:24:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451092561550385153",
  "text" : "RT @WHLive: \"Nearly eight million seniors have saved almost $10 billion on their medicine.\" \u2014President Obama #ACAWorks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451092040043229184",
    "text" : "\"Nearly eight million seniors have saved almost $10 billion on their medicine.\" \u2014President Obama #ACAWorks",
    "id" : 451092040043229184,
    "created_at" : "2014-04-01 20:21:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 451092561550385153,
  "created_at" : "2014-04-01 20:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 115, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451092210529103872",
  "text" : "\"Under this law, the share of Americans with insurance is up, and the growth of health care costs is down.\" \u2014Obama #7MillionAndCounting",
  "id" : 451092210529103872,
  "created_at" : "2014-04-01 20:22:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451091981406834690",
  "text" : "\"100 million Americans have gained free preventive care like mammograms and contraceptive care under their existing plans.\" \u2014Obama #ACAWorks",
  "id" : 451091981406834690,
  "created_at" : "2014-04-01 20:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451091904894357505",
  "text" : "RT @WHLive: \"Anybody who was stuck in line because of the huge surge in demand...can still go back &amp; finish your enrollment\" \u2014Obama #7Milli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 124, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451091709901156353",
    "text" : "\"Anybody who was stuck in line because of the huge surge in demand...can still go back &amp; finish your enrollment\" \u2014Obama #7MillionAndCounting",
    "id" : 451091709901156353,
    "created_at" : "2014-04-01 20:20:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 451091904894357505,
  "created_at" : "2014-04-01 20:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451091533060505601\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/gfGJr9Cxjq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKZW-uCEAE5UCl.jpg",
      "id_str" : "451091532762714113",
      "id" : 451091532762714113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKZW-uCEAE5UCl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gfGJr9Cxjq"
    } ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 79, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451091533060505601",
  "text" : "\"7.1 million Americans have now signed up for private insurance plans.\" \u2014Obama #7MillionAndCounting http:\/\/t.co\/gfGJr9Cxjq",
  "id" : 451091533060505601,
  "created_at" : "2014-04-01 20:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 97, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/8fJzQqhY2T",
      "expanded_url" : "http:\/\/go.wh.gov\/ozKqHg",
      "display_url" : "go.wh.gov\/ozKqHg"
    } ]
  },
  "geo" : { },
  "id_str" : "451091341502857216",
  "text" : "Happening now: President Obama speaks on the Affordable Care Act. Watch \u2192\nhttp:\/\/t.co\/8fJzQqhY2T #7MillionAndCounting",
  "id" : 451091341502857216,
  "created_at" : "2014-04-01 20:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 98, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/8fJzQqhY2T",
      "expanded_url" : "http:\/\/go.wh.gov\/ozKqHg",
      "display_url" : "go.wh.gov\/ozKqHg"
    } ]
  },
  "geo" : { },
  "id_str" : "451087650737631234",
  "text" : "Don't miss President Obama speak on the Affordable Care Act at 4:15pm ET \u2192\nhttp:\/\/t.co\/8fJzQqhY2T #7MillionAndCounting",
  "id" : 451087650737631234,
  "created_at" : "2014-04-01 20:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451084883029663744",
  "text" : "RT @Cecilia44: Before: Margaret from WA paid $300\/month for limited coverage. Now: She has more extensive benefits for $150\/month. #7Millio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 116, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451082354678050817",
    "text" : "Before: Margaret from WA paid $300\/month for limited coverage. Now: She has more extensive benefits for $150\/month. #7MillionAndCounting",
    "id" : 451082354678050817,
    "created_at" : "2014-04-01 19:43:08 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 451084883029663744,
  "created_at" : "2014-04-01 19:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 3, 16 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451082323933822976",
  "text" : "RT @SenatorBoxer: Republicans have been predicting the failure of the Affordable Care Act \u2013 and today they have been proven wrong. #7Millio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 113, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451081005248823296",
    "text" : "Republicans have been predicting the failure of the Affordable Care Act \u2013 and today they have been proven wrong. #7MillionAndCounting",
    "id" : 451081005248823296,
    "created_at" : "2014-04-01 19:37:46 +0000",
    "user" : {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "protected" : false,
      "id_str" : "15442036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464147946934517760\/EZ8huLG8_normal.png",
      "id" : 15442036,
      "verified" : true
    }
  },
  "id" : 451082323933822976,
  "created_at" : "2014-04-01 19:43:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 114, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "451080628294144001",
  "text" : "\"I signed up at http:\/\/t.co\/5zeR2RQuXe and I'm going to save $2,300 a year on my premium alone.\" \u2014Lucy from Texas #7MillionAndCounting",
  "id" : 451080628294144001,
  "created_at" : "2014-04-01 19:36:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451079033145421824\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ZrmHPVzx86",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKN_ZXCQAAFJ1V.jpg",
      "id_str" : "451079032969248768",
      "id" : 451079032969248768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKN_ZXCQAAFJ1V.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZrmHPVzx86"
    } ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 62, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451079033145421824",
  "text" : "Share what quality, affordable health care means to you using #7MillionAndCounting. http:\/\/t.co\/ZrmHPVzx86",
  "id" : 451079033145421824,
  "created_at" : "2014-04-01 19:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "7MillionAndCounting",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/tRBF5dpYkh",
      "expanded_url" : "http:\/\/go.wh.gov\/ykfdm2",
      "display_url" : "go.wh.gov\/ykfdm2"
    } ]
  },
  "geo" : { },
  "id_str" : "451075376484081664",
  "text" : "Thanks to the #ACA, more than 7 million Americans have signed up for private health coverage \u2192 http:\/\/t.co\/tRBF5dpYkh #7MillionAndCounting",
  "id" : 451075376484081664,
  "created_at" : "2014-04-01 19:15:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 20, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451066905605193728",
  "text" : "RT @VP: Great news: #7MillionAndCounting have signed up for private health coverage thanks to the Affordable Care Act.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 12, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451059116421967872",
    "text" : "Great news: #7MillionAndCounting have signed up for private health coverage thanks to the Affordable Care Act.",
    "id" : 451059116421967872,
    "created_at" : "2014-04-01 18:10:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 451066905605193728,
  "created_at" : "2014-04-01 18:41:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451061360009310209\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/upyKHaBvi3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJ96rrCMAAvJUs.jpg",
      "id_str" : "451061359799578624",
      "id" : 451061359799578624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJ96rrCMAAvJUs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/upyKHaBvi3"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "7MillionAndCounting",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451061360009310209",
  "text" : "FACT: More than 7 million Americans have signed up for private health plans thanks to the #ACA. #7MillionAndCounting http:\/\/t.co\/upyKHaBvi3",
  "id" : 451061360009310209,
  "created_at" : "2014-04-01 18:19:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/451057430139392000\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/oGSr0Ysmie",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJ6V7_CAAATcpo.jpg",
      "id_str" : "451057429988376576",
      "id" : 451057429988376576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJ6V7_CAAATcpo.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oGSr0Ysmie"
    } ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 40, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451058708983078913",
  "text" : "RT @Sebelius: Please RT the great news\u2014 #7MillionAndCounting have enrolled in private health coverage! http:\/\/t.co\/oGSr0Ysmie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/451057430139392000\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/oGSr0Ysmie",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJ6V7_CAAATcpo.jpg",
        "id_str" : "451057429988376576",
        "id" : 451057429988376576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJ6V7_CAAATcpo.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oGSr0Ysmie"
      } ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 26, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451057430139392000",
    "text" : "Please RT the great news\u2014 #7MillionAndCounting have enrolled in private health coverage! http:\/\/t.co\/oGSr0Ysmie",
    "id" : 451057430139392000,
    "created_at" : "2014-04-01 18:04:06 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 451058708983078913,
  "created_at" : "2014-04-01 18:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "7MillionAndCounting",
      "indices" : [ 33, 53 ]
    }, {
      "text" : "ACA",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/yvDf3aHUTJ",
      "expanded_url" : "http:\/\/bzfd.it\/1fol6xk",
      "display_url" : "bzfd.it\/1fol6xk"
    } ]
  },
  "geo" : { },
  "id_str" : "451058060774367232",
  "text" : "RT @Bobby44: Obamacare is a BFD: #7MillionAndCounting have signed up for private health plans thx to #ACA. http:\/\/t.co\/yvDf3aHUTJ http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451053780327346176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/TgnTs8Oi0l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJ3BfPCQAAAg9r.jpg",
        "id_str" : "451053780138606592",
        "id" : 451053780138606592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJ3BfPCQAAAg9r.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TgnTs8Oi0l"
      } ],
      "hashtags" : [ {
        "text" : "7MillionAndCounting",
        "indices" : [ 20, 40 ]
      }, {
        "text" : "ACA",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/yvDf3aHUTJ",
        "expanded_url" : "http:\/\/bzfd.it\/1fol6xk",
        "display_url" : "bzfd.it\/1fol6xk"
      } ]
    },
    "geo" : { },
    "id_str" : "451057447357382656",
    "text" : "Obamacare is a BFD: #7MillionAndCounting have signed up for private health plans thx to #ACA. http:\/\/t.co\/yvDf3aHUTJ http:\/\/t.co\/TgnTs8Oi0l",
    "id" : 451057447357382656,
    "created_at" : "2014-04-01 18:04:10 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 451058060774367232,
  "created_at" : "2014-04-01 18:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/451053780327346176\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/e1LV4qPrDe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJ3BfPCQAAAg9r.jpg",
      "id_str" : "451053780138606592",
      "id" : 451053780138606592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJ3BfPCQAAAg9r.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e1LV4qPrDe"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "7MillionAndCounting",
      "indices" : [ 39, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451053780327346176",
  "text" : "RT the great news: Thanks to the #ACA, #7MillionAndCounting have signed up for private health coverage. http:\/\/t.co\/e1LV4qPrDe",
  "id" : 451053780327346176,
  "created_at" : "2014-04-01 17:49:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451052883925291008",
  "text" : "RT @NancyPelosi: Just met with Pres. Obama to discuss progress on health care &amp; America\u2019s top priorities. Stay tuned for great news! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NancyPelosi\/status\/451050575447093248\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/Dd3wADEi8s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJ0G82CcAAfuv0.jpg",
        "id_str" : "451050575451287552",
        "id" : 451050575451287552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJ0G82CcAAfuv0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 799
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 799
        } ],
        "display_url" : "pic.twitter.com\/Dd3wADEi8s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "451050575447093248",
    "text" : "Just met with Pres. Obama to discuss progress on health care &amp; America\u2019s top priorities. Stay tuned for great news! http:\/\/t.co\/Dd3wADEi8s",
    "id" : 451050575447093248,
    "created_at" : "2014-04-01 17:36:52 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 451052883925291008,
  "created_at" : "2014-04-01 17:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451035345044664320",
  "text" : "RT @PressSec: Honored to chair a new Presidential Council that's deeply rooted in our nation's history &amp; even more important today. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/cpoe5Lxwbf",
        "expanded_url" : "http:\/\/go.wh.gov\/58nyMb",
        "display_url" : "go.wh.gov\/58nyMb"
      } ]
    },
    "geo" : { },
    "id_str" : "451033767214579712",
    "text" : "Honored to chair a new Presidential Council that's deeply rooted in our nation's history &amp; even more important today. http:\/\/t.co\/cpoe5Lxwbf",
    "id" : 451033767214579712,
    "created_at" : "2014-04-01 16:30:04 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 451035345044664320,
  "created_at" : "2014-04-01 16:36:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ortiz",
      "screen_name" : "davidortiz",
      "indices" : [ 3, 14 ],
      "id_str" : "28153561",
      "id" : 28153561
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/davidortiz\/status\/451032513679749120\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Bo6TA5MhEy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJjrfqIMAAU0mQ.jpg",
      "id_str" : "451032511574192128",
      "id" : 451032511574192128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJjrfqIMAAU0mQ.jpg",
      "sizes" : [ {
        "h" : 1199,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1199,
        "resize" : "fit",
        "w" : 674
      } ],
      "display_url" : "pic.twitter.com\/Bo6TA5MhEy"
    } ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451034309894635520",
  "text" : "MT @DavidOrtiz: What an honor! Thanks for the #selfie, President Obama http:\/\/t.co\/Bo6TA5MhEy",
  "id" : 451034309894635520,
  "created_at" : "2014-04-01 16:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BostonStrong",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451022110992113664",
  "text" : "\"The world will return to Boston, and run harder than ever, and cheer louder than ever, for the 118th Boston Marathon.\" \u2014Obama #BostonStrong",
  "id" : 451022110992113664,
  "created_at" : "2014-04-01 15:43:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 132, 139 ],
      "id_str" : "40918816",
      "id" : 40918816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451020705350828032",
  "text" : "\"They symbolized the grit and resilience of one of America\u2019s iconic cities during one of its most difficult moments.\" \u2014Obama on the @RedSox",
  "id" : 451020705350828032,
  "created_at" : "2014-04-01 15:38:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 103, 110 ],
      "id_str" : "40918816",
      "id" : 40918816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451020200432123905",
  "text" : "President Obama: \"Beards or no beards, it is an honor to welcome the 2013 World Series Champion Boston @RedSox to the White House.\"",
  "id" : 451020200432123905,
  "created_at" : "2014-04-01 15:36:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 64, 71 ],
      "id_str" : "40918816",
      "id" : 40918816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Bgo1Cb0dKL",
      "expanded_url" : "http:\/\/go.wh.gov\/K8s4bU",
      "display_url" : "go.wh.gov\/K8s4bU"
    } ]
  },
  "geo" : { },
  "id_str" : "451019886358450176",
  "text" : "Happening now: President Obama honors the World Champion Boston @RedSox \u2192 http:\/\/t.co\/Bgo1Cb0dKL",
  "id" : 451019886358450176,
  "created_at" : "2014-04-01 15:34:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 26, 33 ],
      "id_str" : "40918816",
      "id" : 40918816
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetBeard",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ezA5iUC8de",
      "expanded_url" : "http:\/\/go.wh.gov\/K8s4bU",
      "display_url" : "go.wh.gov\/K8s4bU"
    } ]
  },
  "geo" : { },
  "id_str" : "451011195630153728",
  "text" : "The World Champion Boston @RedSox are at the @WhiteHouse. Watch President Obama honor them at 11:35am ET \u2192 http:\/\/t.co\/ezA5iUC8de #GetBeard",
  "id" : 451011195630153728,
  "created_at" : "2014-04-01 15:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AprilFoolsDay",
      "indices" : [ 95, 109 ]
    }, {
      "text" : "WishItWasTrue",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451004442075463680",
  "text" : "RT @NancyPelosi: I must confess, was pleasantly surprised to see these headlines this morning. #AprilFoolsDay  #WishItWasTrue http:\/\/t.co\/T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/450996641751781376\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/T9krIdThXo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkJDDmMCUAEJ-03.png",
        "id_str" : "450996641760169985",
        "id" : 450996641760169985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkJDDmMCUAEJ-03.png",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/T9krIdThXo"
      } ],
      "hashtags" : [ {
        "text" : "AprilFoolsDay",
        "indices" : [ 78, 92 ]
      }, {
        "text" : "WishItWasTrue",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450996641751781376",
    "text" : "I must confess, was pleasantly surprised to see these headlines this morning. #AprilFoolsDay  #WishItWasTrue http:\/\/t.co\/T9krIdThXo",
    "id" : 450996641751781376,
    "created_at" : "2014-04-01 14:02:33 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 451004442075463680,
  "created_at" : "2014-04-01 14:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450998001830748160",
  "text" : "RT @pfeiffer44: Millions of Americans with the economic security that comes from having health insurance is EXACTLY what Change looks like",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450993956294504450",
    "text" : "Millions of Americans with the economic security that comes from having health insurance is EXACTLY what Change looks like",
    "id" : 450993956294504450,
    "created_at" : "2014-04-01 13:51:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 450998001830748160,
  "created_at" : "2014-04-01 14:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 1, 10 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Boston Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 43, 50 ],
      "id_str" : "40918816",
      "id" : 40918816
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/450990113049153536\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IBWJxBDMyK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkI9HkOCMAAZy2F.jpg",
      "id_str" : "450990112881389568",
      "id" : 450990112881389568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkI9HkOCMAAZy2F.jpg",
      "sizes" : [ {
        "h" : 595,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 786
      } ],
      "display_url" : "pic.twitter.com\/IBWJxBDMyK"
    } ],
    "hashtags" : [ {
      "text" : "GetBeard",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/ezA5iUC8de",
      "expanded_url" : "http:\/\/go.wh.gov\/K8s4bU",
      "display_url" : "go.wh.gov\/K8s4bU"
    } ]
  },
  "geo" : { },
  "id_str" : "450990113049153536",
  "text" : ".@PressSec Jay Carney is ready for today's @RedSox visit. Watch at 11:35am ET \u2192 http:\/\/t.co\/ezA5iUC8de #GetBeard http:\/\/t.co\/IBWJxBDMyK",
  "id" : 450990113049153536,
  "created_at" : "2014-04-01 13:36:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]