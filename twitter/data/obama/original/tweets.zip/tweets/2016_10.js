Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/793272062529839104\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/DCqRPXutHt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwJEjjtWAAAkQcB.jpg",
      "id_str" : "793271862042165248",
      "id" : 793271862042165248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwJEjjtWAAAkQcB.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DCqRPXutHt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793272062529839104",
  "text" : "The Man of Steel meets with the Commander-in-Chief. \uD83C\uDF83 https:\/\/t.co\/DCqRPXutHt",
  "id" : 793272062529839104,
  "created_at" : "2016-11-01 02:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HauntedWH",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/TXyY7aDvfp",
      "expanded_url" : "http:\/\/wh.gov\/Halloween",
      "display_url" : "wh.gov\/Halloween"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/HNrC31u7yE",
      "expanded_url" : "http:\/\/snpy.tv\/2eglRSm",
      "display_url" : "snpy.tv\/2eglRSm"
    } ]
  },
  "geo" : { },
  "id_str" : "793237180567195653",
  "text" : "Presidents only get two terms, but the Constitution doesn\u2019t cover their ghosts: https:\/\/t.co\/TXyY7aDvfp #HauntedWH https:\/\/t.co\/HNrC31u7yE",
  "id" : 793237180567195653,
  "created_at" : "2016-10-31 23:44:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 61, 70 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/4dFrryI0vc",
      "expanded_url" : "http:\/\/snpy.tv\/2eVjCSy",
      "display_url" : "snpy.tv\/2eVjCSy"
    } ]
  },
  "geo" : { },
  "id_str" : "793228749735137280",
  "text" : "Happy Halloween from @POTUS and @FLOTUS! Add 'WhiteHouse' on @Snapchat to watch more scenes from the day: https:\/\/t.co\/4dFrryI0vc",
  "id" : 793228749735137280,
  "created_at" : "2016-10-31 23:10:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793224983556128768",
  "text" : "RT @WHWeb: We're opening up social media data to the public. Share your ideas to archive it &amp; make it useful in the future: https:\/\/t.co\/2k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/2kePwd4AYg",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/participate\/opening-our-data-public",
        "display_url" : "whitehouse.gov\/participate\/op\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793221147894489088",
    "text" : "We're opening up social media data to the public. Share your ideas to archive it &amp; make it useful in the future: https:\/\/t.co\/2kePwd4AYg",
    "id" : 793221147894489088,
    "created_at" : "2016-10-31 22:40:33 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 793224983556128768,
  "created_at" : "2016-10-31 22:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/dg57hwz5of",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "793214105377058816",
  "text" : "RT @FLOTUS: Open enrollment starts tomorrow! Check out your options at https:\/\/t.co\/dg57hwz5of and share your #GetCovered story. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/793212249863139328\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/QycOVYhOz9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwIOTnHUsAA_Dhi.jpg",
        "id_str" : "793211366869987329",
        "id" : 793211366869987329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwIOTnHUsAA_Dhi.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/QycOVYhOz9"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/dg57hwz5of",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "793212249863139328",
    "text" : "Open enrollment starts tomorrow! Check out your options at https:\/\/t.co\/dg57hwz5of and share your #GetCovered story. https:\/\/t.co\/QycOVYhOz9",
    "id" : 793212249863139328,
    "created_at" : "2016-10-31 22:05:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 793214105377058816,
  "created_at" : "2016-10-31 22:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793213104129617921",
  "text" : "RT @Goldman44: Have ideas for making this White House's social media content accessible, useful, and available? Share yours: https:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/vXWAuEEPd9",
        "expanded_url" : "http:\/\/go.wh.gov\/iPjwxD",
        "display_url" : "go.wh.gov\/iPjwxD"
      } ]
    },
    "in_reply_to_status_id_str" : "793182461186289664",
    "geo" : { },
    "id_str" : "793212592365899776",
    "in_reply_to_user_id" : 131144091,
    "text" : "Have ideas for making this White House's social media content accessible, useful, and available? Share yours: https:\/\/t.co\/vXWAuEEPd9",
    "id" : 793212592365899776,
    "in_reply_to_status_id" : 793182461186289664,
    "created_at" : "2016-10-31 22:06:33 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 793213104129617921,
  "created_at" : "2016-10-31 22:08:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 57, 68 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/QrC8iGOhEx",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/31\/digital-transition-how-presidential-transition-works-social-media-age",
      "display_url" : "whitehouse.gov\/blog\/2016\/10\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793208785208680448",
  "text" : "RT @anildash: Thoughtful, considered transition plan for @whitehouse online legacy:  https:\/\/t.co\/QrC8iGOhEx \"The archive belongs to the Am\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/QrC8iGOhEx",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/31\/digital-transition-how-presidential-transition-works-social-media-age",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793186058762674176",
    "text" : "Thoughtful, considered transition plan for @whitehouse online legacy:  https:\/\/t.co\/QrC8iGOhEx \"The archive belongs to the American people.\"",
    "id" : 793186058762674176,
    "created_at" : "2016-10-31 20:21:07 +0000",
    "user" : {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786179830266167296\/AmZpJJLv_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 793208785208680448,
  "created_at" : "2016-10-31 21:51:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/periscope.tv\" rel=\"nofollow\"\u003EPeriscope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 51, 58 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Periscope",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/AHbmvjyQk4",
      "expanded_url" : "https:\/\/www.periscope.tv\/w\/auZReDFNV0V3b3JWTHhFYll8MXZBeFJYTEVXcWdHbFDlUiz74G8MxnJQj7KTKqo_2tEbncqFcHETt8w-lFDc",
      "display_url" : "periscope.tv\/w\/auZReDFNV0V3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793190107473850368",
  "text" : "LIVE on #Periscope: Trick or treat with @POTUS and @FLOTUS! https:\/\/t.co\/AHbmvjyQk4",
  "id" : 793190107473850368,
  "created_at" : "2016-10-31 20:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 48, 55 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/793185779631599616\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Zo034YcVLY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwH0JlSUIAABQH_.jpg",
      "id_str" : "793183454858846208",
      "id" : 793183454858846208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwH0JlSUIAABQH_.jpg",
      "sizes" : [ {
        "h" : 1961,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1434,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Zo034YcVLY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/hTY4yqjVGJ",
      "expanded_url" : "http:\/\/go.wh.gov\/Cc6cmL",
      "display_url" : "go.wh.gov\/Cc6cmL"
    } ]
  },
  "geo" : { },
  "id_str" : "793185779631599616",
  "text" : "Happy Halloween! Trick-or-treat with @POTUS and @FLOTUS at 4:35pm ET: https:\/\/t.co\/hTY4yqjVGJ https:\/\/t.co\/Zo034YcVLY",
  "id" : 793185779631599616,
  "created_at" : "2016-10-31 20:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/793184814257930241\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/GXik5ZiDEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwH1I0dVMAAknAi.jpg",
      "id_str" : "793184541263343616",
      "id" : 793184541263343616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwH1I0dVMAAknAi.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GXik5ZiDEx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/iIoFiRXDJ7",
      "expanded_url" : "http:\/\/go.wh.gov\/iPjwxD",
      "display_url" : "go.wh.gov\/iPjwxD"
    } ]
  },
  "geo" : { },
  "id_str" : "793184814257930241",
  "text" : "Over 470K petitions \u2713\nNearly 30K @WhiteHouse tweets \u2713\n1,000s of hours of video \u2713\n\nPreserving our digital legacy: https:\/\/t.co\/iIoFiRXDJ7 https:\/\/t.co\/GXik5ZiDEx",
  "id" : 793184814257930241,
  "created_at" : "2016-10-31 20:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793183275615293441",
  "text" : "RT @ks44: What happens to @POTUS on January 20th? Here's how the presidential transition works in the social media age: https:\/\/t.co\/iI6XiX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ks44\/status\/793182327580925952\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/bOxVm0bqjO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwHy_z9UMAAmgO9.jpg",
        "id_str" : "793182187486982144",
        "id" : 793182187486982144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwHy_z9UMAAmgO9.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1494,
          "resize" : "fit",
          "w" : 2240
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/bOxVm0bqjO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/iI6XiXSmAb",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/31\/digital-transition-how-presidential-transition-works-social-media-age",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793182327580925952",
    "text" : "What happens to @POTUS on January 20th? Here's how the presidential transition works in the social media age: https:\/\/t.co\/iI6XiXSmAb https:\/\/t.co\/bOxVm0bqjO",
    "id" : 793182327580925952,
    "created_at" : "2016-10-31 20:06:18 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 793183275615293441,
  "created_at" : "2016-10-31 20:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/793162129939365888\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/FGOQhjFkeD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwHgbPUXYAAZIKX.jpg",
      "id_str" : "793161767966957568",
      "id" : 793161767966957568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwHgbPUXYAAZIKX.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/FGOQhjFkeD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793166109704716289",
  "text" : "RT @VP: All you need for a Biden Halloween: Pumpkins and aviators. https:\/\/t.co\/FGOQhjFkeD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/793162129939365888\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/FGOQhjFkeD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwHgbPUXYAAZIKX.jpg",
        "id_str" : "793161767966957568",
        "id" : 793161767966957568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwHgbPUXYAAZIKX.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/FGOQhjFkeD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "793162129939365888",
    "text" : "All you need for a Biden Halloween: Pumpkins and aviators. https:\/\/t.co\/FGOQhjFkeD",
    "id" : 793162129939365888,
    "created_at" : "2016-10-31 18:46:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 793166109704716289,
  "created_at" : "2016-10-31 19:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "Andy Slavitt",
      "screen_name" : "ASlavitt",
      "indices" : [ 84, 93 ],
      "id_str" : "1383272101",
      "id" : 1383272101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793153703658127360",
  "text" : "RT @SecBurwell: Happy Halloween! It\u2019s time to debunk some myths about the #ACA, and @ASlavitt and I are dressed the part! https:\/\/t.co\/heTf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Slavitt",
        "screen_name" : "ASlavitt",
        "indices" : [ 68, 77 ],
        "id_str" : "1383272101",
        "id" : 1383272101
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecBurwell\/status\/793144473794609152\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/Zz2ayvircy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwHQBgaW8AAA0OT.jpg",
        "id_str" : "793143733692854272",
        "id" : 793143733692854272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwHQBgaW8AAA0OT.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2726,
          "resize" : "fit",
          "w" : 4096
        } ],
        "display_url" : "pic.twitter.com\/Zz2ayvircy"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 58, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/heTftdx0uQ",
        "expanded_url" : "http:\/\/www.hhs.gov\/blog\/2016\/10\/31\/affordable-care-act-myths-busted.html",
        "display_url" : "hhs.gov\/blog\/2016\/10\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793144473794609152",
    "text" : "Happy Halloween! It\u2019s time to debunk some myths about the #ACA, and @ASlavitt and I are dressed the part! https:\/\/t.co\/heTftdx0uQ https:\/\/t.co\/Zz2ayvircy",
    "id" : 793144473794609152,
    "created_at" : "2016-10-31 17:35:53 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 793153703658127360,
  "created_at" : "2016-10-31 18:12:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/793100768991514624\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Cup3ovw4bE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwGovaVUIAE6VZv.jpg",
      "id_str" : "793100541869957121",
      "id" : 793100541869957121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwGovaVUIAE6VZv.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Cup3ovw4bE"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/5zeR2RPWAE",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "793100768991514624",
  "text" : "Being uninsured can be scary. Starting tomorrow, #GetCovered at https:\/\/t.co\/5zeR2RPWAE. \uD83C\uDF83\uD83D\uDC7B https:\/\/t.co\/Cup3ovw4bE",
  "id" : 793100768991514624,
  "created_at" : "2016-10-31 14:42:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 3, 11 ],
      "id_str" : "24024778",
      "id" : 24024778
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793090131783667716",
  "text" : "RT @kalpenn: This is pretty amazing. A sitting president observing Diwali in the Oval Office. Bet that's a first! \uD83C\uDDFA\uD83C\uDDF8 Thank you @POTUS https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 114, 120 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kalpenn\/status\/792892419863879681\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/D1AGwkJhEq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwDrcdqWIAAjLDu.jpg",
        "id_str" : "792892408648310784",
        "id" : 792892408648310784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwDrcdqWIAAjLDu.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/D1AGwkJhEq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792892419863879681",
    "text" : "This is pretty amazing. A sitting president observing Diwali in the Oval Office. Bet that's a first! \uD83C\uDDFA\uD83C\uDDF8 Thank you @POTUS https:\/\/t.co\/D1AGwkJhEq",
    "id" : 792892419863879681,
    "created_at" : "2016-10-31 00:54:18 +0000",
    "user" : {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "protected" : false,
      "id_str" : "24024778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684472236175036416\/yTKSwENk_normal.jpg",
      "id" : 24024778,
      "verified" : true
    }
  },
  "id" : 793090131783667716,
  "created_at" : "2016-10-31 13:59:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "indices" : [ 3, 13 ],
      "id_str" : "1665386791",
      "id" : 1665386791
    }, {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 29, 38 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793085955104137216",
  "text" : "RT @Patrick44: Worth a read: @CEAChair offers some important facts and perspective on current state and future of Obamacare https:\/\/t.co\/90\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Furman",
        "screen_name" : "CEAChair",
        "indices" : [ 14, 23 ],
        "id_str" : "1861751828",
        "id" : 1861751828
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/90MYRwbfQ6",
        "expanded_url" : "http:\/\/www.vox.com\/science-and-health\/2016\/10\/31\/13459818\/obamacare-white-house-economist",
        "display_url" : "vox.com\/science-and-he\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "793077317266345984",
    "text" : "Worth a read: @CEAChair offers some important facts and perspective on current state and future of Obamacare https:\/\/t.co\/90MYRwbfQ6",
    "id" : 793077317266345984,
    "created_at" : "2016-10-31 13:09:01 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 793085955104137216,
  "created_at" : "2016-10-31 13:43:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 93, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KG0uAmfg0p",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792788177203453952",
  "text" : "\u201CWe're at an inflection point\u201D \u2014@VP Biden on using science, medicine, and technology for the #CancerMoonshot effort: https:\/\/t.co\/KG0uAmfg0p",
  "id" : 792788177203453952,
  "created_at" : "2016-10-30 18:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/KG0uAmfg0p",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792773070197063682",
  "text" : "Science \u2713\nMedicine \u2713\nTechnology \u2713\n\nThe #CancerMoonshot is bringing together innovative tools to end cancer: https:\/\/t.co\/KG0uAmfg0p",
  "id" : 792773070197063682,
  "created_at" : "2016-10-30 17:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 57, 60 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/KG0uAmwQRX",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792757970140483584",
  "text" : "\"The private sector is also reimagining what it can do\" \u2014@VP on the #CancerMoonshot effort to end cancer: https:\/\/t.co\/KG0uAmwQRX",
  "id" : 792757970140483584,
  "created_at" : "2016-10-30 16:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 24, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KG0uAmwQRX",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792742867030544384",
  "text" : "Watch: @VP Biden on the #CancerMoonshot initiative and the steps we're taking to put an end to cancer as we know it: https:\/\/t.co\/KG0uAmwQRX",
  "id" : 792742867030544384,
  "created_at" : "2016-10-30 15:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/792731552492814336\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/tLsjyXJnDs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwBY_ZEVMAAX9Ny.jpg",
      "id_str" : "792731380501262336",
      "id" : 792731380501262336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwBY_ZEVMAAX9Ny.jpg",
      "sizes" : [ {
        "h" : 1021,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/tLsjyXJnDs"
    } ],
    "hashtags" : [ {
      "text" : "Diwali",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HOyk3I4Mqc",
      "expanded_url" : "http:\/\/go.wh.gov\/kt8ZSQ",
      "display_url" : "go.wh.gov\/kt8ZSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "792731552492814336",
  "text" : "\"I wish you and your loved ones peace and happiness on this Diwali.\" \u2014@POTUS to all of those celebrating #Diwali: https:\/\/t.co\/HOyk3I4Mqc https:\/\/t.co\/tLsjyXJnDs",
  "id" : 792731552492814336,
  "created_at" : "2016-10-30 14:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 81, 84 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/YrDtYyj5fX",
      "expanded_url" : "http:\/\/cancer.serve.gov",
      "display_url" : "cancer.serve.gov"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/KG0uAmwQRX",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792418224771960833",
  "text" : "\"The Moonshot is about all of us doing our part. Visit https:\/\/t.co\/YrDtYyj5fX\" \u2014@VP on the effort to end cancer: https:\/\/t.co\/KG0uAmwQRX",
  "id" : 792418224771960833,
  "created_at" : "2016-10-29 17:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 85, 88 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/KG0uAmwQRX",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792403121569828864",
  "text" : "\"We have to do everything...enhancing prevention efforts, expanding access to care\" \u2014@VP on the #CancerMoonshot https:\/\/t.co\/KG0uAmwQRX",
  "id" : 792403121569828864,
  "created_at" : "2016-10-29 16:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 7, 12 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "PIF",
      "screen_name" : "InnovFellows",
      "indices" : [ 15, 28 ],
      "id_str" : "3184883153",
      "id" : 3184883153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/WhyE9WDfQa",
      "expanded_url" : "http:\/\/WH.gov\/Cancer",
      "display_url" : "WH.gov\/Cancer"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/KG0uAmfg0p",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792388027289112580",
  "text" : ".@VP \u2713\n@NASA \u2713\n@InnovFellows \u2713\n\nAnd so many more. See who's joining the fight to end cancer: https:\/\/t.co\/WhyE9WDfQa https:\/\/t.co\/KG0uAmfg0p",
  "id" : 792388027289112580,
  "created_at" : "2016-10-29 15:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 64, 67 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/KG0uAmfg0p",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792372923482996736",
  "text" : "\"Science, medicine, technology all advancing faster than ever\" \u2014@VP Biden on the #CancerMoonshot effort: https:\/\/t.co\/KG0uAmfg0p",
  "id" : 792372923482996736,
  "created_at" : "2016-10-29 14:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 71, 74 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/KG0uAmwQRX",
      "expanded_url" : "http:\/\/go.wh.gov\/gLjsES",
      "display_url" : "go.wh.gov\/gLjsES"
    } ]
  },
  "geo" : { },
  "id_str" : "792363240902627328",
  "text" : "\u201CWith the Moonshot, we now have a clear strategy for the road ahead.\u201D \u2014@VP on the fight against cancer: https:\/\/t.co\/KG0uAmwQRX",
  "id" : 792363240902627328,
  "created_at" : "2016-10-29 13:51:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 21, 26 ],
      "id_str" : "41144996",
      "id" : 41144996
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/kMXBEjv0iF",
      "expanded_url" : "http:\/\/snpy.tv\/2eNP7hd",
      "display_url" : "snpy.tv\/2eNP7hd"
    } ]
  },
  "geo" : { },
  "id_str" : "792161533870477312",
  "text" : "\"I don't usually let @Cubs fans in here\" \u2014@POTUS welcoming Bill Murray in this week's edition of #WestWingWeek https:\/\/t.co\/kMXBEjv0iF",
  "id" : 792161533870477312,
  "created_at" : "2016-10-29 00:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/792140560404393984\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/7LQgFw9zQN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv4_kK8VUAATiGo.jpg",
      "id_str" : "792140475109036032",
      "id" : 792140475109036032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv4_kK8VUAATiGo.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/7LQgFw9zQN"
    } ],
    "hashtags" : [ {
      "text" : "HauntedWH",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792140560404393984",
  "text" : "Abe drops by his old haunts. #HauntedWH https:\/\/t.co\/7LQgFw9zQN",
  "id" : 792140560404393984,
  "created_at" : "2016-10-28 23:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 86, 96 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/YiDkktw2f9",
      "expanded_url" : "http:\/\/go.wh.gov\/UQyj3e",
      "display_url" : "go.wh.gov\/UQyj3e"
    } ]
  },
  "geo" : { },
  "id_str" : "792085922162483201",
  "text" : "One year ago, @POTUS called on organizations to strengthen workers' voices. Hear from @Cecilia44 on our progress: https:\/\/t.co\/YiDkktw2f9",
  "id" : 792085922162483201,
  "created_at" : "2016-10-28 19:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/YiDkktw2f9",
      "expanded_url" : "http:\/\/go.wh.gov\/UQyj3e",
      "display_url" : "go.wh.gov\/UQyj3e"
    } ]
  },
  "geo" : { },
  "id_str" : "792068687322685441",
  "text" : "From opening up data to launching online tools, see the innovative ways workers are lifting their voices: https:\/\/t.co\/YiDkktw2f9",
  "id" : 792068687322685441,
  "created_at" : "2016-10-28 18:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792064971072901120",
  "text" : "RT @Cecilia44: One year after the @WhiteHouse Worker Voice Summit, workers' voices are continuing to change the workplace. https:\/\/t.co\/L5m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 19, 30 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/L5mYTFx1iL",
        "expanded_url" : "https:\/\/medium.com\/@Cecilia44\/a-year-of-action-lifting-worker-voices-to-make-change-in-the-workplace-f36e50b3144a#.k2iyrgfsk",
        "display_url" : "medium.com\/@Cecilia44\/a-y\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792063015738748928",
    "text" : "One year after the @WhiteHouse Worker Voice Summit, workers' voices are continuing to change the workplace. https:\/\/t.co\/L5mYTFx1iL",
    "id" : 792063015738748928,
    "created_at" : "2016-10-28 17:58:33 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 792064971072901120,
  "created_at" : "2016-10-28 18:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/792028150523768832\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/R2qOEvX5hc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv3U2apVMAAQuJh.jpg",
      "id_str" : "792023140817776640",
      "id" : 792023140817776640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv3U2apVMAAQuJh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/R2qOEvX5hc"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/JxkdfhYxgO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "792028150523768832",
  "text" : "Most people can find a health care plan for less than $75\/month on https:\/\/t.co\/JxkdfhYxgO. #GetCovered starting November 1. https:\/\/t.co\/R2qOEvX5hc",
  "id" : 792028150523768832,
  "created_at" : "2016-10-28 15:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/792021171369709568\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/833J07LNBy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv3SfCfWAAUfF8S.jpg",
      "id_str" : "792020540173189125",
      "id" : 792020540173189125,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv3SfCfWAAUfF8S.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1051
      }, {
        "h" : 2338,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 616
      } ],
      "display_url" : "pic.twitter.com\/833J07LNBy"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Dtajk7iM0N",
      "expanded_url" : "http:\/\/go.wh.gov\/1944dd",
      "display_url" : "go.wh.gov\/1944dd"
    } ]
  },
  "geo" : { },
  "id_str" : "792021171369709568",
  "text" : "Here's where insured Americans #GetCovered and how the Affordable Care Act impacts them: https:\/\/t.co\/Dtajk7iM0N https:\/\/t.co\/833J07LNBy",
  "id" : 792021171369709568,
  "created_at" : "2016-10-28 15:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792002478527033345",
  "text" : "RT @CEAChair: Q3 GDP up 2.9%, noticeable pickup from previous quarters with strong export growth &amp; solid consumer spending. https:\/\/t.co\/Ag\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/791996253802405890\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/6f0TPEFDVU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv28XmKVMAELr-R.jpg",
        "id_str" : "791996223053967361",
        "id" : 791996223053967361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv28XmKVMAELr-R.jpg",
        "sizes" : [ {
          "h" : 661,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 910
        } ],
        "display_url" : "pic.twitter.com\/6f0TPEFDVU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/AgbU8vt18C",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/28\/advance-estimate-gross-domestic-product-third-quarter-2016",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791996253802405890",
    "text" : "Q3 GDP up 2.9%, noticeable pickup from previous quarters with strong export growth &amp; solid consumer spending. https:\/\/t.co\/AgbU8vt18C https:\/\/t.co\/6f0TPEFDVU",
    "id" : 791996253802405890,
    "created_at" : "2016-10-28 13:33:16 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 792002478527033345,
  "created_at" : "2016-10-28 13:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/j6XVV8RXxk",
      "expanded_url" : "https:\/\/www.quora.com\/What-is-the-Trans-Pacific-Partnership-TPP-in-laymans-terms",
      "display_url" : "quora.com\/What-is-the-Tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791786161773568002",
  "text" : "Wondering what exactly the #TPP is? @POTUS provides the answer: https:\/\/t.co\/j6XVV8RXxk",
  "id" : 791786161773568002,
  "created_at" : "2016-10-27 23:38:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/vAIBObP4i8",
      "expanded_url" : "https:\/\/www.quora.com\/What-are-the-major-differences-between-NAFTA-and-TPP",
      "display_url" : "quora.com\/What-are-the-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791780341757259777",
  "text" : "\"Junking the TPP actually means sticking with the status quo that NAFTA created\"  \u2014@POTUS on why we need the #TPP: https:\/\/t.co\/vAIBObP4i8",
  "id" : 791780341757259777,
  "created_at" : "2016-10-27 23:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "indices" : [ 3, 12 ],
      "id_str" : "113439399",
      "id" : 113439399
    }, {
      "name" : "NAEP",
      "screen_name" : "NAEP_NCES",
      "indices" : [ 18, 28 ],
      "id_str" : "296288727",
      "id" : 296288727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/FGAS7V75FN",
      "expanded_url" : "http:\/\/nationsreportcard.gov",
      "display_url" : "nationsreportcard.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "791777677531152384",
  "text" : "RT @smrtgrls: The @NAEP_NCES has released promising new science scores \uD83D\uDC49 https:\/\/t.co\/FGAS7V75FN \uD83C\uDF89\uD83D\uDCDA RT to keep closing the gap in #STEMEduc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NAEP",
        "screen_name" : "NAEP_NCES",
        "indices" : [ 4, 14 ],
        "id_str" : "296288727",
        "id" : 296288727
      }, {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 132, 140 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/smrtgrls\/status\/791740426092945409\/video\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/4cIdK1PM56",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791737818712203264\/pu\/img\/i8P4wIh_o8ttRaPs.jpg",
        "id_str" : "791737818712203264",
        "id" : 791737818712203264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791737818712203264\/pu\/img\/i8P4wIh_o8ttRaPs.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4cIdK1PM56"
      } ],
      "hashtags" : [ {
        "text" : "STEMEducation",
        "indices" : [ 116, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/FGAS7V75FN",
        "expanded_url" : "http:\/\/nationsreportcard.gov",
        "display_url" : "nationsreportcard.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "791740426092945409",
    "text" : "The @NAEP_NCES has released promising new science scores \uD83D\uDC49 https:\/\/t.co\/FGAS7V75FN \uD83C\uDF89\uD83D\uDCDA RT to keep closing the gap in #STEMEducation! @usedgov https:\/\/t.co\/4cIdK1PM56",
    "id" : 791740426092945409,
    "created_at" : "2016-10-27 20:36:42 +0000",
    "user" : {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "protected" : false,
      "id_str" : "113439399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700467562413297664\/0qESscTd_normal.png",
      "id" : 113439399,
      "verified" : true
    }
  },
  "id" : 791777677531152384,
  "created_at" : "2016-10-27 23:04:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Kasich",
      "screen_name" : "JohnKasich",
      "indices" : [ 72, 83 ],
      "id_str" : "18020081",
      "id" : 18020081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/R1Q8t64m8J",
      "expanded_url" : "https:\/\/www.quora.com\/Why-is-the-TPP-so-controversial\/answer\/Barack-Obama",
      "display_url" : "quora.com\/Why-is-the-TPP\u2026"
    }, {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/nvHkuEXfFw",
      "expanded_url" : "http:\/\/snpy.tv\/2eg1wtC",
      "display_url" : "snpy.tv\/2eg1wtC"
    } ]
  },
  "geo" : { },
  "id_str" : "791772089971642368",
  "text" : "\"It's a bipartisan agreement that puts America first.\" @POTUS &amp; Gov @JohnKasich on the #TPP: https:\/\/t.co\/R1Q8t64m8J https:\/\/t.co\/nvHkuEXfFw",
  "id" : 791772089971642368,
  "created_at" : "2016-10-27 22:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/o6FsJSSY3J",
      "expanded_url" : "https:\/\/www.quora.com\/profile\/Barack-Obama",
      "display_url" : "quora.com\/profile\/Barack\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791765184104701952",
  "text" : "What is the #TPP? Why is it so controversial? What does it mean for underemployed workers? @POTUS offers answers \u2192 https:\/\/t.co\/o6FsJSSY3J",
  "id" : 791765184104701952,
  "created_at" : "2016-10-27 22:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/LWu3ZlEQMw",
      "expanded_url" : "https:\/\/medium.com\/@JusticeForUs\/life-in-prison-for-selling-lsd-at-a-rock-concert-1bd6c7e16b4f#.itldkfdwk",
      "display_url" : "medium.com\/@JusticeForUs\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791759693341265920",
  "text" : "RT @vj44: At #SXSL, an interactive experience asks attendees to be the judge in true-to-life court cases: https:\/\/t.co\/LWu3ZlEQMw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 3, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/LWu3ZlEQMw",
        "expanded_url" : "https:\/\/medium.com\/@JusticeForUs\/life-in-prison-for-selling-lsd-at-a-rock-concert-1bd6c7e16b4f#.itldkfdwk",
        "display_url" : "medium.com\/@JusticeForUs\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791758404557561857",
    "text" : "At #SXSL, an interactive experience asks attendees to be the judge in true-to-life court cases: https:\/\/t.co\/LWu3ZlEQMw",
    "id" : 791758404557561857,
    "created_at" : "2016-10-27 21:48:08 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 791759693341265920,
  "created_at" : "2016-10-27 21:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/791757620625506304\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/paXQPQEj9Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvzgPmRUAAAqvOt.jpg",
      "id_str" : "791754193086185472",
      "id" : 791754193086185472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvzgPmRUAAAqvOt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/paXQPQEj9Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0jTlXff1sd",
      "expanded_url" : "http:\/\/go.wh.gov\/bPYMYP",
      "display_url" : "go.wh.gov\/bPYMYP"
    } ]
  },
  "geo" : { },
  "id_str" : "791757620625506304",
  "text" : "FACT: Americans shopping on https:\/\/t.co\/GNfbft9Ewv can choose from an average of 30 plans. Hear more from @POTUS: https:\/\/t.co\/0jTlXff1sd https:\/\/t.co\/paXQPQEj9Z",
  "id" : 791757620625506304,
  "created_at" : "2016-10-27 21:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/791753604646342656\/photo\/1",
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/EkAeDgQJjT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvzfpYuUIAA5PR0.jpg",
      "id_str" : "791753536614703104",
      "id" : 791753536614703104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvzfpYuUIAA5PR0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/EkAeDgQJjT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/JxkdfhYxgO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/0jTlXeXq3D",
      "expanded_url" : "http:\/\/go.wh.gov\/bPYMYP",
      "display_url" : "go.wh.gov\/bPYMYP"
    } ]
  },
  "geo" : { },
  "id_str" : "791753604646342656",
  "text" : "In 2017, 72% of Americans who get coverage on https:\/\/t.co\/JxkdfhYxgO can find a plan for less than $75\/month: https:\/\/t.co\/0jTlXeXq3D https:\/\/t.co\/EkAeDgQJjT",
  "id" : 791753604646342656,
  "created_at" : "2016-10-27 21:29:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791743651080605696",
  "text" : "RT @anildash: If you\u2019re not one of the 25k people on the call as @POTUS discusses ACA enrollment, you can listen in here, now: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 51, 57 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/WHK8HZWqAt",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=RMdssfjmjd0",
        "display_url" : "youtube.com\/watch?v=RMdssf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791741466855018496",
    "text" : "If you\u2019re not one of the 25k people on the call as @POTUS discusses ACA enrollment, you can listen in here, now: https:\/\/t.co\/WHK8HZWqAt",
    "id" : 791741466855018496,
    "created_at" : "2016-10-27 20:40:50 +0000",
    "user" : {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786179830266167296\/AmZpJJLv_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 791743651080605696,
  "created_at" : "2016-10-27 20:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/791742026714787840\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/fV7LCjdHuz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvzVEmSVIAACWPk.jpg",
      "id_str" : "791741909483986944",
      "id" : 791741909483986944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvzVEmSVIAACWPk.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/fV7LCjdHuz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/MG3GvxxgfP",
      "expanded_url" : "http:\/\/go.wh.gov\/Nn7PnG",
      "display_url" : "go.wh.gov\/Nn7PnG"
    } ]
  },
  "geo" : { },
  "id_str" : "791742026714787840",
  "text" : "This year, @POTUS has commuted more sentences than any other president in a single year. Today, he granted 98 more: https:\/\/t.co\/MG3GvxxgfP https:\/\/t.co\/fV7LCjdHuz",
  "id" : 791742026714787840,
  "created_at" : "2016-10-27 20:43:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 3, 9 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 68, 79 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Quora\/status\/791735005651361792\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/lRXHI9ozR8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvzOyl7XYAM4wSK.jpg",
      "id_str" : "791735003080253443",
      "id" : 791735003080253443,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvzOyl7XYAM4wSK.jpg",
      "sizes" : [ {
        "h" : 378,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 810
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 810
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 810
      } ],
      "display_url" : "pic.twitter.com\/lRXHI9ozR8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/5rnnCYTJTd",
      "expanded_url" : "https:\/\/www.quora.com\/Why-is-the-TPP-so-controversial\/answer\/Barack-Obama?srid=7h",
      "display_url" : "quora.com\/Why-is-the-TPP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791736568612388864",
  "text" : "RT @Quora: Why is the TPP so controversial? by Barack Obama  @POTUS @WhiteHouse https:\/\/t.co\/5rnnCYTJTd https:\/\/t.co\/lRXHI9ozR8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 50, 56 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 57, 68 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Quora\/status\/791735005651361792\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/lRXHI9ozR8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvzOyl7XYAM4wSK.jpg",
        "id_str" : "791735003080253443",
        "id" : 791735003080253443,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvzOyl7XYAM4wSK.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 810
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 810
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 810
        } ],
        "display_url" : "pic.twitter.com\/lRXHI9ozR8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/5rnnCYTJTd",
        "expanded_url" : "https:\/\/www.quora.com\/Why-is-the-TPP-so-controversial\/answer\/Barack-Obama?srid=7h",
        "display_url" : "quora.com\/Why-is-the-TPP\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791735005651361792",
    "text" : "Why is the TPP so controversial? by Barack Obama  @POTUS @WhiteHouse https:\/\/t.co\/5rnnCYTJTd https:\/\/t.co\/lRXHI9ozR8",
    "id" : 791735005651361792,
    "created_at" : "2016-10-27 20:15:09 +0000",
    "user" : {
      "name" : "Quora",
      "screen_name" : "Quora",
      "protected" : false,
      "id_str" : "33696409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615648367943651328\/51pM5n5v_normal.png",
      "id" : 33696409,
      "verified" : true
    }
  },
  "id" : 791736568612388864,
  "created_at" : "2016-10-27 20:21:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/791734295622594561\/photo\/1",
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/vf5eMmbyTl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvzOGVxUIAA-FOK.jpg",
      "id_str" : "791734242828886016",
      "id" : 791734242828886016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvzOGVxUIAA-FOK.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/vf5eMmbyTl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791734295622594561",
  "text" : ".@POTUS has commuted more sentences than the past 11 presidents combined. Today, 98 deserving people get a second chance: https:\/\/t.co\/vf5eMmbyTl",
  "id" : 791734295622594561,
  "created_at" : "2016-10-27 20:12:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 34, 43 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 90, 94 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FacebookLive",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/B1pRffrIt8",
      "expanded_url" : "https:\/\/www.facebook.com\/cnn",
      "display_url" : "facebook.com\/cnn"
    } ]
  },
  "geo" : { },
  "id_str" : "791691980308754432",
  "text" : "RT @NSC44: TUNE IN: At 1:30pm ET, @Rhodes44 talks US-Cuba relations on #FacebookLive with @CNN. \n\nJoin at: https:\/\/t.co\/B1pRffrIt8 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 23, 32 ],
        "id_str" : "249722522",
        "id" : 249722522
      }, {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 79, 83 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSC44\/status\/791687741687889920\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/CZXLnPkz25",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvyjWGqUMAAH5V-.jpg",
        "id_str" : "791687234650910720",
        "id" : 791687234650910720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvyjWGqUMAAH5V-.jpg",
        "sizes" : [ {
          "h" : 570,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CZXLnPkz25"
      } ],
      "hashtags" : [ {
        "text" : "FacebookLive",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/B1pRffrIt8",
        "expanded_url" : "https:\/\/www.facebook.com\/cnn",
        "display_url" : "facebook.com\/cnn"
      } ]
    },
    "geo" : { },
    "id_str" : "791687741687889920",
    "text" : "TUNE IN: At 1:30pm ET, @Rhodes44 talks US-Cuba relations on #FacebookLive with @CNN. \n\nJoin at: https:\/\/t.co\/B1pRffrIt8 https:\/\/t.co\/CZXLnPkz25",
    "id" : 791687741687889920,
    "created_at" : "2016-10-27 17:07:21 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 791691980308754432,
  "created_at" : "2016-10-27 17:24:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/791665658564050948\/photo\/1",
      "indices" : [ 129, 152 ],
      "url" : "https:\/\/t.co\/hnDyq3UQij",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvyPqSqXYAAcA-v.jpg",
      "id_str" : "791665591237173248",
      "id" : 791665591237173248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvyPqSqXYAAcA-v.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/hnDyq3UQij"
    } ],
    "hashtags" : [ {
      "text" : "InclusionWorks",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/vxUOn292Ch",
      "expanded_url" : "http:\/\/go.wh.gov\/66zGbd",
      "display_url" : "go.wh.gov\/66zGbd"
    } ]
  },
  "geo" : { },
  "id_str" : "791665658564050948",
  "text" : "Our government should reflect the diversity of our nation. @POTUS is leading by example: https:\/\/t.co\/vxUOn292Ch #InclusionWorks https:\/\/t.co\/hnDyq3UQij",
  "id" : 791665658564050948,
  "created_at" : "2016-10-27 15:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "indices" : [ 3, 13 ],
      "id_str" : "4796005523",
      "id" : 4796005523
    }, {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 28, 38 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791661184369856513",
  "text" : "RT @Charlie44: READ THIS: A @voxdotcom tour de force on non-compete clauses &amp; how the Obama Admin is curbing their overuse: https:\/\/t.co\/4Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vox",
        "screen_name" : "voxdotcom",
        "indices" : [ 13, 23 ],
        "id_str" : "2347049341",
        "id" : 2347049341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/4QjepQqy1Z",
        "expanded_url" : "http:\/\/www.vox.com\/the-big-idea\/2016\/10\/27\/13433632\/noncompete-agreements-wage-labor-market",
        "display_url" : "vox.com\/the-big-idea\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791651521268154372",
    "text" : "READ THIS: A @voxdotcom tour de force on non-compete clauses &amp; how the Obama Admin is curbing their overuse: https:\/\/t.co\/4QjepQqy1Z",
    "id" : 791651521268154372,
    "created_at" : "2016-10-27 14:43:25 +0000",
    "user" : {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "protected" : false,
      "id_str" : "4796005523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689598827691520000\/6gRd26qn_normal.jpg",
      "id" : 4796005523,
      "verified" : true
    }
  },
  "id" : 791661184369856513,
  "created_at" : "2016-10-27 15:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/791654577175158784\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/CVjFkmuUvX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvyFXQyUEAACQPy.jpg",
      "id_str" : "791654269199847424",
      "id" : 791654269199847424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvyFXQyUEAACQPy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CVjFkmuUvX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vxUOn292Ch",
      "expanded_url" : "http:\/\/go.wh.gov\/66zGbd",
      "display_url" : "go.wh.gov\/66zGbd"
    } ]
  },
  "geo" : { },
  "id_str" : "791654577175158784",
  "text" : ".@POTUS challenged the federal government to hire 100K people with disabilities within 5 years. The results are in: https:\/\/t.co\/vxUOn292Ch https:\/\/t.co\/CVjFkmuUvX",
  "id" : 791654577175158784,
  "created_at" : "2016-10-27 14:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791426939776999424",
  "text" : "RT @VP: The determined veteran, immigrant, single mom going back to community college to get ahead. That's what built America. #FreeCommuni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/791415654691799046\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/qreB6dqJ9A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvusVDkWgAAKeJR.jpg",
        "id_str" : "791415637268660224",
        "id" : 791415637268660224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvusVDkWgAAKeJR.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/qreB6dqJ9A"
      } ],
      "hashtags" : [ {
        "text" : "FreeCommunityCollege",
        "indices" : [ 119, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791415654691799046",
    "text" : "The determined veteran, immigrant, single mom going back to community college to get ahead. That's what built America. #FreeCommunityCollege https:\/\/t.co\/qreB6dqJ9A",
    "id" : 791415654691799046,
    "created_at" : "2016-10-26 23:06:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 791426939776999424,
  "created_at" : "2016-10-26 23:51:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/791397242905038849\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/s4TtFK7LcU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvuXN3GUsAA062u.jpg",
      "id_str" : "791392423918219264",
      "id" : 791392423918219264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvuXN3GUsAA062u.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/s4TtFK7LcU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/0jTlXeXq3D",
      "expanded_url" : "http:\/\/go.wh.gov\/bPYMYP",
      "display_url" : "go.wh.gov\/bPYMYP"
    } ]
  },
  "geo" : { },
  "id_str" : "791397242905038849",
  "text" : "For the first time ever, more than 90% of Americans have health insurance. Get the facts: https:\/\/t.co\/0jTlXeXq3D https:\/\/t.co\/s4TtFK7LcU",
  "id" : 791397242905038849,
  "created_at" : "2016-10-26 21:53:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/JxkdfhYxgO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ItTRwMcKkN",
      "expanded_url" : "http:\/\/snpy.tv\/2eRJ4rk",
      "display_url" : "snpy.tv\/2eRJ4rk"
    } ]
  },
  "geo" : { },
  "id_str" : "791392042496634880",
  "text" : "FACT: 72% of Americans who #GetCovered on https:\/\/t.co\/JxkdfhYxgO can find a plan for less than $75\/month. https:\/\/t.co\/ItTRwMcKkN",
  "id" : 791392042496634880,
  "created_at" : "2016-10-26 21:32:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Denis44\/status\/791361969290743810\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/vUaMgkR0oJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvt7etGVYAAJ038.jpg",
      "id_str" : "791361926966108160",
      "id" : 791361926966108160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvt7etGVYAAJ038.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 349
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1051
      }, {
        "h" : 2338,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 616
      } ],
      "display_url" : "pic.twitter.com\/vUaMgkR0oJ"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "ThanksObama",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791362419830378496",
  "text" : "RT @Denis44: Where Americans get their health coverage &amp; what the #ACA has done for them, in 1 chart. #ThanksObama https:\/\/t.co\/vUaMgkR0oJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Denis44\/status\/791361969290743810\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/vUaMgkR0oJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvt7etGVYAAJ038.jpg",
        "id_str" : "791361926966108160",
        "id" : 791361926966108160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvt7etGVYAAJ038.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 349
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1051
        }, {
          "h" : 2338,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 616
        } ],
        "display_url" : "pic.twitter.com\/vUaMgkR0oJ"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 57, 61 ]
      }, {
        "text" : "ThanksObama",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791361969290743810",
    "text" : "Where Americans get their health coverage &amp; what the #ACA has done for them, in 1 chart. #ThanksObama https:\/\/t.co\/vUaMgkR0oJ",
    "id" : 791361969290743810,
    "created_at" : "2016-10-26 19:32:50 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 791362419830378496,
  "created_at" : "2016-10-26 19:34:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/sF6LyzEwDg",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "791343785674354689",
  "text" : "RT @PressSec: Some confusion on ACA plans. Enrolled via https:\/\/t.co\/sF6LyzEwDg? Tax credits can help. Need a plan? See options: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/sF6LyzEwDg",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      }, {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/k6mgtnhDZ6",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      }, {
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/92khyWFHGP",
        "expanded_url" : "https:\/\/twitter.com\/colinb1123\/status\/791003558044770305",
        "display_url" : "twitter.com\/colinb1123\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791338011581566976",
    "text" : "Some confusion on ACA plans. Enrolled via https:\/\/t.co\/sF6LyzEwDg? Tax credits can help. Need a plan? See options: https:\/\/t.co\/k6mgtnhDZ6 https:\/\/t.co\/92khyWFHGP",
    "id" : 791338011581566976,
    "created_at" : "2016-10-26 17:57:38 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 791343785674354689,
  "created_at" : "2016-10-26 18:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "indices" : [ 3, 10 ],
      "id_str" : "2151620534",
      "id" : 2151620534
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 19, 28 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791330634538950656",
  "text" : "RT @Hill44: Watch: @PressSec answers Qs about premium increases in individual market. Vast majority qualify for tax credits: https:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 7, 16 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/1nHYLlQNyX",
        "expanded_url" : "http:\/\/snpy.tv\/2eM8tV0",
        "display_url" : "snpy.tv\/2eM8tV0"
      } ]
    },
    "geo" : { },
    "id_str" : "791327804558221312",
    "text" : "Watch: @PressSec answers Qs about premium increases in individual market. Vast majority qualify for tax credits: https:\/\/t.co\/1nHYLlQNyX",
    "id" : 791327804558221312,
    "created_at" : "2016-10-26 17:17:05 +0000",
    "user" : {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "protected" : false,
      "id_str" : "2151620534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658658579142959104\/85LEK24P_normal.jpg",
      "id" : 2151620534,
      "verified" : true
    }
  },
  "id" : 791330634538950656,
  "created_at" : "2016-10-26 17:28:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 17, 26 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CareAboutCare",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791329778431320064",
  "text" : "RT @SecBurwell: .@LaborSec and I know how important affordable child care is for families. It\u2019s time we #CareAboutCare. https:\/\/t.co\/D4rWrO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 1, 10 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/791286585555726337\/video\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/D4rWrOEDBR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvs1PfUVIAAU4ae.jpg",
        "id_str" : "791010695085031425",
        "id" : 791010695085031425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvs1PfUVIAAU4ae.jpg",
        "sizes" : [ {
          "h" : 751,
          "resize" : "fit",
          "w" : 1179
        }, {
          "h" : 751,
          "resize" : "fit",
          "w" : 1179
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/D4rWrOEDBR"
      } ],
      "hashtags" : [ {
        "text" : "CareAboutCare",
        "indices" : [ 88, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791324743165247488",
    "text" : ".@LaborSec and I know how important affordable child care is for families. It\u2019s time we #CareAboutCare. https:\/\/t.co\/D4rWrOEDBR",
    "id" : 791324743165247488,
    "created_at" : "2016-10-26 17:04:55 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 791329778431320064,
  "created_at" : "2016-10-26 17:24:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791307985809240064",
  "text" : "RT @rhodes44: The embargo denies opportunities to Cubans and isolates the U.S. For the sake of our interests and the Cuban people it should\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791305419033423873",
    "text" : "The embargo denies opportunities to Cubans and isolates the U.S. For the sake of our interests and the Cuban people it should be lifted.",
    "id" : 791305419033423873,
    "created_at" : "2016-10-26 15:48:08 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 791307985809240064,
  "created_at" : "2016-10-26 15:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791307953294962688",
  "text" : "RT @rhodes44: US will abstain for first time on UNGA Resolution calling for end to embargo on Cuba. No reason to vote to defend a failed po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791304986395193344",
    "text" : "US will abstain for first time on UNGA Resolution calling for end to embargo on Cuba. No reason to vote to defend a failed policy we oppose",
    "id" : 791304986395193344,
    "created_at" : "2016-10-26 15:46:25 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 791307953294962688,
  "created_at" : "2016-10-26 15:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 3, 11 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Reuters\/status\/791075643631042560\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/dNGKcMNNge",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp3GrTWIAAptjY.jpg",
      "id_str" : "791075641143730176",
      "id" : 791075641143730176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp3GrTWIAAptjY.jpg",
      "sizes" : [ {
        "h" : 545,
        "resize" : "fit",
        "w" : 914
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 914
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 914
      } ],
      "display_url" : "pic.twitter.com\/dNGKcMNNge"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/w5eAZ0ks5Y",
      "expanded_url" : "http:\/\/reut.rs\/2eEa7qV",
      "display_url" : "reut.rs\/2eEa7qV"
    } ]
  },
  "geo" : { },
  "id_str" : "791305076430123009",
  "text" : "RT @Reuters: White House urges ban on non-compete agreements for many workers https:\/\/t.co\/w5eAZ0ks5Y https:\/\/t.co\/dNGKcMNNge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/trueanthem.com\/\" rel=\"nofollow\"\u003EtrueAnthem\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Reuters\/status\/791075643631042560\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/dNGKcMNNge",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp3GrTWIAAptjY.jpg",
        "id_str" : "791075641143730176",
        "id" : 791075641143730176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp3GrTWIAAptjY.jpg",
        "sizes" : [ {
          "h" : 545,
          "resize" : "fit",
          "w" : 914
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 914
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 914
        } ],
        "display_url" : "pic.twitter.com\/dNGKcMNNge"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/w5eAZ0ks5Y",
        "expanded_url" : "http:\/\/reut.rs\/2eEa7qV",
        "display_url" : "reut.rs\/2eEa7qV"
      } ]
    },
    "geo" : { },
    "id_str" : "791075643631042560",
    "text" : "White House urges ban on non-compete agreements for many workers https:\/\/t.co\/w5eAZ0ks5Y https:\/\/t.co\/dNGKcMNNge",
    "id" : 791075643631042560,
    "created_at" : "2016-10-26 00:35:05 +0000",
    "user" : {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "protected" : false,
      "id_str" : "1652541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3379693153\/1008914c0ae75c9efb5f9c0161fce9a2_normal.png",
      "id" : 1652541,
      "verified" : true
    }
  },
  "id" : 791305076430123009,
  "created_at" : "2016-10-26 15:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "David Westin",
      "screen_name" : "DavidWestin",
      "indices" : [ 114, 126 ],
      "id_str" : "15535510",
      "id" : 15535510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791042184216649728",
  "text" : "RT @vj44: Equitable workplaces are good for workers, families, employers, &amp; the economy. Check out my chat w\/ @DavidWestin: https:\/\/t.co\/1D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Westin",
        "screen_name" : "DavidWestin",
        "indices" : [ 104, 116 ],
        "id_str" : "15535510",
        "id" : 15535510
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/1DSw2bYS8u",
        "expanded_url" : "http:\/\/bloom.bg\/2e8hcPK",
        "display_url" : "bloom.bg\/2e8hcPK"
      } ]
    },
    "geo" : { },
    "id_str" : "791041575556030464",
    "text" : "Equitable workplaces are good for workers, families, employers, &amp; the economy. Check out my chat w\/ @DavidWestin: https:\/\/t.co\/1DSw2bYS8u",
    "id" : 791041575556030464,
    "created_at" : "2016-10-25 22:19:43 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 791042184216649728,
  "created_at" : "2016-10-25 22:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IEA",
      "screen_name" : "IEA",
      "indices" : [ 3, 7 ],
      "id_str" : "84679163",
      "id" : 84679163
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Renewables",
      "indices" : [ 9, 20 ]
    }, {
      "text" : "electricity",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791036600549376000",
  "text" : "RT @IEA: #Renewables surpassed coal to become largest source of global #electricity capacity in 2015, our latest report shows https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IEA\/status\/790828169049825280\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/5UAFSlqAEI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvmWBxVWYAAAmeB.jpg",
        "id_str" : "790828166747152384",
        "id" : 790828166747152384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvmWBxVWYAAAmeB.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/5UAFSlqAEI"
      } ],
      "hashtags" : [ {
        "text" : "Renewables",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "electricity",
        "indices" : [ 62, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/oznHvvguzW",
        "expanded_url" : "http:\/\/bit.ly\/2eqcK4l",
        "display_url" : "bit.ly\/2eqcK4l"
      } ]
    },
    "geo" : { },
    "id_str" : "790828169049825280",
    "text" : "#Renewables surpassed coal to become largest source of global #electricity capacity in 2015, our latest report shows https:\/\/t.co\/oznHvvguzW https:\/\/t.co\/5UAFSlqAEI",
    "id" : 790828169049825280,
    "created_at" : "2016-10-25 08:11:43 +0000",
    "user" : {
      "name" : "IEA",
      "screen_name" : "IEA",
      "protected" : false,
      "id_str" : "84679163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761509540240171008\/LKmMrLco_normal.jpg",
      "id" : 84679163,
      "verified" : true
    }
  },
  "id" : 791036600549376000,
  "created_at" : "2016-10-25 21:59:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LRDiYRZtwo",
      "expanded_url" : "http:\/\/dol.gov\/noncompetes",
      "display_url" : "dol.gov\/noncompetes"
    } ]
  },
  "geo" : { },
  "id_str" : "791033913867014144",
  "text" : "RT @USDOL: There are 5.4M job openings \u2013 but that\u2019s little use if you can\u2019t change jobs because of a non-compete. https:\/\/t.co\/LRDiYRZtwo #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/791020287408111617\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/MSyWxDQk6m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvpEwfvWIAA1HH4.jpg",
        "id_str" : "791020284501434368",
        "id" : 791020284501434368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvpEwfvWIAA1HH4.jpg",
        "sizes" : [ {
          "h" : 1563,
          "resize" : "fit",
          "w" : 3125
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/MSyWxDQk6m"
      } ],
      "hashtags" : [ {
        "text" : "LetUsCompete",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/LRDiYRZtwo",
        "expanded_url" : "http:\/\/dol.gov\/noncompetes",
        "display_url" : "dol.gov\/noncompetes"
      } ]
    },
    "geo" : { },
    "id_str" : "791020287408111617",
    "text" : "There are 5.4M job openings \u2013 but that\u2019s little use if you can\u2019t change jobs because of a non-compete. https:\/\/t.co\/LRDiYRZtwo #LetUsCompete https:\/\/t.co\/MSyWxDQk6m",
    "id" : 791020287408111617,
    "created_at" : "2016-10-25 20:55:07 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 791033913867014144,
  "created_at" : "2016-10-25 21:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/791009246707974145\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/QOHso3za5Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvo5ik4VIAAYlot.jpg",
      "id_str" : "791007950735220736",
      "id" : 791007950735220736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvo5ik4VIAAYlot.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1563,
        "resize" : "fit",
        "w" : 3125
      } ],
      "display_url" : "pic.twitter.com\/QOHso3za5Y"
    } ],
    "hashtags" : [ {
      "text" : "LetUsCompete",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/S05n0nzmsi",
      "expanded_url" : "http:\/\/go.wh.gov\/ntC3oS",
      "display_url" : "go.wh.gov\/ntC3oS"
    } ]
  },
  "geo" : { },
  "id_str" : "791009246707974145",
  "text" : "Every American deserves a fair shot at a decent wage, and the ability to pursue the jobs they want: https:\/\/t.co\/S05n0nzmsi #LetUsCompete https:\/\/t.co\/QOHso3za5Y",
  "id" : 791009246707974145,
  "created_at" : "2016-10-25 20:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 3, 7 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 104, 112 ],
      "id_str" : "35936474",
      "id" : 35936474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 10, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/NLmenxWDev",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "791004315401854976",
  "text" : "RT @NBA: \u201C#MyBrothersKeeper is connecting kids with mentors who can help them reach their potential!\u201D - @KDtrey5 https:\/\/t.co\/NLmenxWDev #M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Durant",
        "screen_name" : "KDTrey5",
        "indices" : [ 95, 103 ],
        "id_str" : "35936474",
        "id" : 35936474
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NBA\/status\/790923393583292420\/video\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/gJY5DKCSnC",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/790544991743389697\/img\/c3uR-rTEqmfjZDkw.jpg",
        "id_str" : "790544991743389697",
        "id" : 790544991743389697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/790544991743389697\/img\/c3uR-rTEqmfjZDkw.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gJY5DKCSnC"
      } ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 1, 18 ]
      }, {
        "text" : "MentorIRL",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/NLmenxWDev",
        "expanded_url" : "http:\/\/Mentor.gov",
        "display_url" : "Mentor.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "790923393583292420",
    "text" : "\u201C#MyBrothersKeeper is connecting kids with mentors who can help them reach their potential!\u201D - @KDtrey5 https:\/\/t.co\/NLmenxWDev #MentorIRL https:\/\/t.co\/gJY5DKCSnC",
    "id" : 790923393583292420,
    "created_at" : "2016-10-25 14:30:06 +0000",
    "user" : {
      "name" : "NBA",
      "screen_name" : "NBA",
      "protected" : false,
      "id_str" : "19923144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797568531047051264\/LcjOmxGH_normal.jpg",
      "id" : 19923144,
      "verified" : true
    }
  },
  "id" : 791004315401854976,
  "created_at" : "2016-10-25 19:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "theSkimm",
      "screen_name" : "theskimm",
      "indices" : [ 43, 52 ],
      "id_str" : "515034648",
      "id" : 515034648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790968801751920640",
  "text" : "RT @vj44: Today at 2pm ET, I'll be joining @theSkimm on Facebook Live for a chat on the #ACA. #GetCovered starting Nov. 1: https:\/\/t.co\/JbM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "theSkimm",
        "screen_name" : "theskimm",
        "indices" : [ 33, 42 ],
        "id_str" : "515034648",
        "id" : 515034648
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 78, 82 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 84, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/JbMfqEou06",
        "expanded_url" : "https:\/\/www.facebook.com\/TheSkimm\/",
        "display_url" : "facebook.com\/TheSkimm\/"
      } ]
    },
    "geo" : { },
    "id_str" : "790967936898957313",
    "text" : "Today at 2pm ET, I'll be joining @theSkimm on Facebook Live for a chat on the #ACA. #GetCovered starting Nov. 1: https:\/\/t.co\/JbMfqEou06",
    "id" : 790967936898957313,
    "created_at" : "2016-10-25 17:27:06 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 790968801751920640,
  "created_at" : "2016-10-25 17:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 24, 33 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NSC44\/status\/790943606563491840\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/EHe66wLCnD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvn-_5dUkAAG18a.jpg",
      "id_str" : "790943583289249792",
      "id" : 790943583289249792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvn-_5dUkAAG18a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1409
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1409
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/EHe66wLCnD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/rMJJ2LtPja",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/10\/25\/statement-press-secretary-presidents-travel-greece-germany-and-peru",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790955776332271616",
  "text" : "RT @NSC44: Statement by @PressSec on the @POTUS' Travel to Greece, Germany, and Peru: \nhttps:\/\/t.co\/rMJJ2LtPja https:\/\/t.co\/EHe66wLCnD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 13, 22 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 30, 36 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSC44\/status\/790943606563491840\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/EHe66wLCnD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvn-_5dUkAAG18a.jpg",
        "id_str" : "790943583289249792",
        "id" : 790943583289249792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvn-_5dUkAAG18a.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1409
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1409
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/EHe66wLCnD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/rMJJ2LtPja",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/10\/25\/statement-press-secretary-presidents-travel-greece-germany-and-peru",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "790943606563491840",
    "text" : "Statement by @PressSec on the @POTUS' Travel to Greece, Germany, and Peru: \nhttps:\/\/t.co\/rMJJ2LtPja https:\/\/t.co\/EHe66wLCnD",
    "id" : 790943606563491840,
    "created_at" : "2016-10-25 15:50:25 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 790955776332271616,
  "created_at" : "2016-10-25 16:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 63, 71 ],
      "id_str" : "35936474",
      "id" : 35936474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 97, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/kKAv3VfWTu",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7V2mJoEU5c",
      "expanded_url" : "http:\/\/snpy.tv\/2dFumr9",
      "display_url" : "snpy.tv\/2dFumr9"
    } ]
  },
  "geo" : { },
  "id_str" : "790952669556846597",
  "text" : "You can make the difference in a kid's life. Just take it from @KDTrey5: https:\/\/t.co\/kKAv3VfWTu #MyBrothersKeeper https:\/\/t.co\/7V2mJoEU5c",
  "id" : 790952669556846597,
  "created_at" : "2016-10-25 16:26:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 6, 14 ],
      "id_str" : "35936474",
      "id" : 35936474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/kKAv3VfWTu",
      "expanded_url" : "http:\/\/Mentor.gov",
      "display_url" : "Mentor.gov"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/7V2mJoEU5c",
      "expanded_url" : "http:\/\/snpy.tv\/2dFumr9",
      "display_url" : "snpy.tv\/2dFumr9"
    } ]
  },
  "geo" : { },
  "id_str" : "790944028808228864",
  "text" : "Watch @KDTrey5 on #MyBrothersKeeper and how you can help kids succeed. Head to https:\/\/t.co\/kKAv3VfWTu: https:\/\/t.co\/7V2mJoEU5c",
  "id" : 790944028808228864,
  "created_at" : "2016-10-25 15:52:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 35, 49 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790928775617847296",
  "text" : "RT @HHSGov: The numbers don\u2019t lie. @HealthCareGov consumers will have options. Tax credits will make coverage affordable. https:\/\/t.co\/K1Sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 23, 37 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/K1SakOwPsv",
        "expanded_url" : "http:\/\/go.usa.gov\/xkfSV",
        "display_url" : "go.usa.gov\/xkfSV"
      } ]
    },
    "geo" : { },
    "id_str" : "790923419919355904",
    "text" : "The numbers don\u2019t lie. @HealthCareGov consumers will have options. Tax credits will make coverage affordable. https:\/\/t.co\/K1SakOwPsv",
    "id" : 790923419919355904,
    "created_at" : "2016-10-25 14:30:12 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 790928775617847296,
  "created_at" : "2016-10-25 14:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "indices" : [ 3, 6 ],
      "id_str" : "18949452",
      "id" : 18949452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/rkoGMUG35x",
      "expanded_url" : "http:\/\/on.ft.com\/2eqCIos",
      "display_url" : "on.ft.com\/2eqCIos"
    } ]
  },
  "geo" : { },
  "id_str" : "790911915568476160",
  "text" : "RT @FT: Good morning America. Our top story - Renewables overtake coal as world\u2019s largest source of power capacity https:\/\/t.co\/rkoGMUG35x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FT\/status\/790886116735975424\/photo\/1",
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/dlbvw1EmFx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvnKuxfWEAArcwf.jpg",
        "id_str" : "790886114487832576",
        "id" : 790886114487832576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvnKuxfWEAArcwf.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/dlbvw1EmFx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/rkoGMUG35x",
        "expanded_url" : "http:\/\/on.ft.com\/2eqCIos",
        "display_url" : "on.ft.com\/2eqCIos"
      } ]
    },
    "geo" : { },
    "id_str" : "790886116735975424",
    "text" : "Good morning America. Our top story - Renewables overtake coal as world\u2019s largest source of power capacity https:\/\/t.co\/rkoGMUG35x https:\/\/t.co\/dlbvw1EmFx",
    "id" : 790886116735975424,
    "created_at" : "2016-10-25 12:01:58 +0000",
    "user" : {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "protected" : false,
      "id_str" : "18949452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466972537704824832\/eflEColL_normal.png",
      "id" : 18949452,
      "verified" : true
    }
  },
  "id" : 790911915568476160,
  "created_at" : "2016-10-25 13:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Kimmel Live",
      "screen_name" : "JimmyKimmelLive",
      "indices" : [ 3, 19 ],
      "id_str" : "34036028",
      "id" : 34036028
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 108, 119 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SneakPeek",
      "indices" : [ 21, 31 ]
    }, {
      "text" : "MeanTweets",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "Kimmel",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790717522609930240",
  "text" : "RT @JimmyKimmelLive: #SneakPeek of a NEW #MeanTweets with President Obama! Watch @POTUS on #Kimmel TONIGHT! @WhiteHouse https:\/\/t.co\/qW7oQZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 60, 66 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 87, 98 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JimmyKimmelLive\/status\/790705507296169984\/video\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/qW7oQZoBaY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvkmShRVMAEtytf.jpg",
        "id_str" : "790705106052222978",
        "id" : 790705106052222978,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvkmShRVMAEtytf.jpg",
        "sizes" : [ {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/qW7oQZoBaY"
      } ],
      "hashtags" : [ {
        "text" : "SneakPeek",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "MeanTweets",
        "indices" : [ 20, 31 ]
      }, {
        "text" : "Kimmel",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790705507296169984",
    "text" : "#SneakPeek of a NEW #MeanTweets with President Obama! Watch @POTUS on #Kimmel TONIGHT! @WhiteHouse https:\/\/t.co\/qW7oQZoBaY",
    "id" : 790705507296169984,
    "created_at" : "2016-10-25 00:04:18 +0000",
    "user" : {
      "name" : "Jimmy Kimmel Live",
      "screen_name" : "JimmyKimmelLive",
      "protected" : false,
      "id_str" : "34036028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780842066922266624\/eUkI-1wF_normal.jpg",
      "id" : 34036028,
      "verified" : true
    }
  },
  "id" : 790717522609930240,
  "created_at" : "2016-10-25 00:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 40, 54 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790682748595810304",
  "text" : "RT @SecBurwell: Most people shopping on @HealthCareGov will again find plans with premiums of less than $75\/month, thanks to financial assi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 24, 38 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "790671123172233217",
    "geo" : { },
    "id_str" : "790671553272934400",
    "in_reply_to_user_id" : 2458567464,
    "text" : "Most people shopping on @HealthCareGov will again find plans with premiums of less than $75\/month, thanks to financial assistance.",
    "id" : 790671553272934400,
    "in_reply_to_status_id" : 790671123172233217,
    "created_at" : "2016-10-24 21:49:22 +0000",
    "in_reply_to_screen_name" : "SecBurwell",
    "in_reply_to_user_id_str" : "2458567464",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 790682748595810304,
  "created_at" : "2016-10-24 22:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 118, 129 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HumanTrafficking",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790679567811829760",
  "text" : "RT @JohnKerry: We all must share the moral urgency to end #HumanTrafficking in all forms. Important discussion at the @WhiteHouse today to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JohnKerry\/status\/790664365850656769\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/PpeO4465Hv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvkA4S3WcAEj7Cx.jpg",
        "id_str" : "790664176716902401",
        "id" : 790664176716902401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvkA4S3WcAEj7Cx.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/PpeO4465Hv"
      } ],
      "hashtags" : [ {
        "text" : "HumanTrafficking",
        "indices" : [ 43, 60 ]
      }, {
        "text" : "EndSlavery",
        "indices" : [ 124, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790664365850656769",
    "text" : "We all must share the moral urgency to end #HumanTrafficking in all forms. Important discussion at the @WhiteHouse today to #EndSlavery. https:\/\/t.co\/PpeO4465Hv",
    "id" : 790664365850656769,
    "created_at" : "2016-10-24 21:20:49 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 790679567811829760,
  "created_at" : "2016-10-24 22:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 27, 39 ],
      "id_str" : "18726942",
      "id" : 18726942
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 3, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KevqEMmp8n",
      "expanded_url" : "http:\/\/bit.ly\/2eM9T1t",
      "display_url" : "bit.ly\/2eM9T1t"
    } ]
  },
  "geo" : { },
  "id_str" : "790676104289722368",
  "text" : "At #SXSL, attendees toured @YosemiteNPS 1-1 with @POTUS\u2014thanks to virtual reality: https:\/\/t.co\/KevqEMmp8n",
  "id" : 790676104289722368,
  "created_at" : "2016-10-24 22:07:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/TSzA6LInmh",
      "expanded_url" : "http:\/\/snpy.tv\/2eKUgpt",
      "display_url" : "snpy.tv\/2eKUgpt"
    } ]
  },
  "geo" : { },
  "id_str" : "790658446097993728",
  "text" : "9-year-old Jacob asked @POTUS if he had a Kid Science Advisor. Six months later, Jacob returned here Friday as one: https:\/\/t.co\/TSzA6LInmh",
  "id" : 790658446097993728,
  "created_at" : "2016-10-24 20:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndTrafficking",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/NqXyf14Hka",
      "expanded_url" : "http:\/\/go.usa.gov\/xkfPD",
      "display_url" : "go.usa.gov\/xkfPD"
    } ]
  },
  "geo" : { },
  "id_str" : "790641308398264320",
  "text" : "RT @AmbassadorRice: Every nation must act to #EndTrafficking. Here's how we're taking action across the US Gov't: https:\/\/t.co\/NqXyf14Hka\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EndTrafficking",
        "indices" : [ 25, 40 ]
      }, {
        "text" : "HumanTrafficking",
        "indices" : [ 119, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/NqXyf14Hka",
        "expanded_url" : "http:\/\/go.usa.gov\/xkfPD",
        "display_url" : "go.usa.gov\/xkfPD"
      } ]
    },
    "geo" : { },
    "id_str" : "790638350130524160",
    "text" : "Every nation must act to #EndTrafficking. Here's how we're taking action across the US Gov't: https:\/\/t.co\/NqXyf14Hka \n#HumanTrafficking",
    "id" : 790638350130524160,
    "created_at" : "2016-10-24 19:37:26 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 790641308398264320,
  "created_at" : "2016-10-24 19:49:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/EaqcpOoFYC",
      "expanded_url" : "http:\/\/wh.gov\/KidScienceAdvisors",
      "display_url" : "wh.gov\/KidScienceAdvi\u2026"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/TSzA6LInmh",
      "expanded_url" : "http:\/\/snpy.tv\/2eKUgpt",
      "display_url" : "snpy.tv\/2eKUgpt"
    } ]
  },
  "geo" : { },
  "id_str" : "790633275463053312",
  "text" : ".@POTUS\u2019s team of advisors just got a little larger. Meet the Kid Science Advisors: https:\/\/t.co\/EaqcpOoFYC https:\/\/t.co\/TSzA6LInmh",
  "id" : 790633275463053312,
  "created_at" : "2016-10-24 19:17:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 31, 38 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6vJYH0uutH",
      "expanded_url" : "http:\/\/portal.hud.gov\/hudportal\/HUD?src=\/press\/press_releases_media_advisories\/2016\/HUDNo_16-159",
      "display_url" : "portal.hud.gov\/hudportal\/HUD?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790580641536413697",
  "text" : "RT @SecretaryCastro: BREAKING: @HUDgov issues new housing protections for survivors of domestic violence \u2192 https:\/\/t.co\/6vJYH0uutH https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 10, 17 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryCastro\/status\/790570030815674369\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/RLDUC6zFHB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvirKZGWgAAoFKT.png",
        "id_str" : "790569929628090368",
        "id" : 790569929628090368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvirKZGWgAAoFKT.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RLDUC6zFHB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/6vJYH0uutH",
        "expanded_url" : "http:\/\/portal.hud.gov\/hudportal\/HUD?src=\/press\/press_releases_media_advisories\/2016\/HUDNo_16-159",
        "display_url" : "portal.hud.gov\/hudportal\/HUD?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "790570030815674369",
    "text" : "BREAKING: @HUDgov issues new housing protections for survivors of domestic violence \u2192 https:\/\/t.co\/6vJYH0uutH https:\/\/t.co\/RLDUC6zFHB",
    "id" : 790570030815674369,
    "created_at" : "2016-10-24 15:05:58 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 790580641536413697,
  "created_at" : "2016-10-24 15:48:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 69, 72 ],
      "id_str" : "14159148",
      "id" : 14159148
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/790575802286952449\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/6El40q9wM4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cviwc_wWgAAVDX7.jpg",
      "id_str" : "790575746800582656",
      "id" : 790575746800582656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cviwc_wWgAAVDX7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/6El40q9wM4"
    } ],
    "hashtags" : [ {
      "text" : "UNDay",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Rsyk6EorrZ",
      "expanded_url" : "http:\/\/go.wh.gov\/6uoqAS",
      "display_url" : "go.wh.gov\/6uoqAS"
    } ]
  },
  "geo" : { },
  "id_str" : "790575802286952449",
  "text" : "Today we celebrate 71 years of international cooperation through the @UN. @POTUS on the anniversary: https:\/\/t.co\/Rsyk6EorrZ #UNDay https:\/\/t.co\/6El40q9wM4",
  "id" : 790575802286952449,
  "created_at" : "2016-10-24 15:28:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/pqdrS2TsrJ",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "790323166606299137",
  "text" : "\"It\u2019s all about taking steps, big and small, that can make your life a little bit better.\" Watch @POTUS's address: https:\/\/t.co\/pqdrS2TsrJ",
  "id" : 790323166606299137,
  "created_at" : "2016-10-23 22:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 3, 8 ],
      "id_str" : "41144996",
      "id" : 41144996
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cubs\/status\/790244932464349184\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/BQDr9GotzL",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CveDi2mXEAArNGW.jpg",
      "id_str" : "790244894422011904",
      "id" : 790244894422011904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CveDi2mXEAArNGW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/BQDr9GotzL"
    } ],
    "hashtags" : [ {
      "text" : "FlyTheW",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790299057969180673",
  "text" : "RT @Cubs: @POTUS Thank you, Mr. President! #FlyTheW https:\/\/t.co\/BQDr9GotzL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cubs\/status\/790244932464349184\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/BQDr9GotzL",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CveDi2mXEAArNGW.jpg",
        "id_str" : "790244894422011904",
        "id" : 790244894422011904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CveDi2mXEAArNGW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/BQDr9GotzL"
      } ],
      "hashtags" : [ {
        "text" : "FlyTheW",
        "indices" : [ 33, 41 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "790236602584948736",
    "geo" : { },
    "id_str" : "790244932464349184",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS Thank you, Mr. President! #FlyTheW https:\/\/t.co\/BQDr9GotzL",
    "id" : 790244932464349184,
    "in_reply_to_status_id" : 790236602584948736,
    "created_at" : "2016-10-23 17:34:08 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "protected" : false,
      "id_str" : "41144996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794039281945808896\/cxLl4jrK_normal.jpg",
      "id" : 41144996,
      "verified" : true
    }
  },
  "id" : 790299057969180673,
  "created_at" : "2016-10-23 21:09:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pqdrS2BRAb",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "790287936386465793",
  "text" : "\"You shouldn\u2019t have to pay extra for a service you don\u2019t even receive.\" \u2014@POTUS on new actions to protect consumers: https:\/\/t.co\/pqdrS2BRAb",
  "id" : 790287936386465793,
  "created_at" : "2016-10-23 20:25:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pqdrS2TsrJ",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "790243895074357248",
  "text" : "Delayed baggage refunds \u2713\nProtections for travelers with disabilities \u2713\n\n@POTUS is standing up for consumers. Watch: https:\/\/t.co\/pqdrS2TsrJ",
  "id" : 790243895074357248,
  "created_at" : "2016-10-23 17:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 34, 39 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlyTheW",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790237394712662016",
  "text" : "RT @POTUS: I'll say it: Holy Cow, @Cubs fans. Even this White Sox fan was happy to see Wrigley rocking last night. #FlyTheW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 23, 28 ],
        "id_str" : "41144996",
        "id" : 41144996
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlyTheW",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790236602584948736",
    "text" : "I'll say it: Holy Cow, @Cubs fans. Even this White Sox fan was happy to see Wrigley rocking last night. #FlyTheW",
    "id" : 790236602584948736,
    "created_at" : "2016-10-23 17:01:02 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 790237394712662016,
  "created_at" : "2016-10-23 17:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NtzXSPsofz",
      "expanded_url" : "http:\/\/energy.gov\/revolutionnow",
      "display_url" : "energy.gov\/revolutionnow"
    } ]
  },
  "geo" : { },
  "id_str" : "790222506808475652",
  "text" : "RT @ErnestMoniz: We are experiencing a #CleanEnergy revolution in the United States, and this report confirms it. \u2192 https:\/\/t.co\/NtzXSPsofz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/790213455093444609\/video\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/MubkX7tK1b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdCBDGWYAAW8Vv.jpg",
        "id_str" : "781165202016342016",
        "id" : 781165202016342016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdCBDGWYAAW8Vv.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/MubkX7tK1b"
      } ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 22, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/NtzXSPsofz",
        "expanded_url" : "http:\/\/energy.gov\/revolutionnow",
        "display_url" : "energy.gov\/revolutionnow"
      } ]
    },
    "geo" : { },
    "id_str" : "790213455093444609",
    "text" : "We are experiencing a #CleanEnergy revolution in the United States, and this report confirms it. \u2192 https:\/\/t.co\/NtzXSPsofz https:\/\/t.co\/MubkX7tK1b",
    "id" : 790213455093444609,
    "created_at" : "2016-10-23 15:29:03 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 790222506808475652,
  "created_at" : "2016-10-23 16:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 22, 27 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790206547574030336",
  "text" : "RT @FLOTUS: Way to go @Cubs!! My Dad is the reason I'm a true Cubs fan. He'd be so proud! \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 10, 15 ],
        "id_str" : "41144996",
        "id" : 41144996
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790197406184812544",
    "text" : "Way to go @Cubs!! My Dad is the reason I'm a true Cubs fan. He'd be so proud! \u2013mo",
    "id" : 790197406184812544,
    "created_at" : "2016-10-23 14:25:17 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 790206547574030336,
  "created_at" : "2016-10-23 15:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/pqdrS2BRAb",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "790205779597033476",
  "text" : "When your bags are delayed, you should be able to get a refund on those fees. @POTUS is taking action: https:\/\/t.co\/pqdrS2BRAb",
  "id" : 790205779597033476,
  "created_at" : "2016-10-23 14:58:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "\u2B50Jill Scott\u2B50",
      "screen_name" : "missjillscott",
      "indices" : [ 28, 42 ],
      "id_str" : "128990079",
      "id" : 128990079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/8P4CqWRJTw",
      "expanded_url" : "http:\/\/snpy.tv\/2esVxHf",
      "display_url" : "snpy.tv\/2esVxHf"
    } ]
  },
  "geo" : { },
  "id_str" : "789958260560236545",
  "text" : "Last night, @POTUS welcomed @MissJillScott to kick off the final White House concert of his presidency: https:\/\/t.co\/8P4CqWRJTw",
  "id" : 789958260560236545,
  "created_at" : "2016-10-22 22:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/8P4CqWRJTw",
      "expanded_url" : "http:\/\/snpy.tv\/2esVxHf",
      "display_url" : "snpy.tv\/2esVxHf"
    } ]
  },
  "geo" : { },
  "id_str" : "789924247657295872",
  "text" : "\"Music...is an essential part of the American experience\" \u2014@POTUS marks his final White House concert https:\/\/t.co\/8P4CqWRJTw",
  "id" : 789924247657295872,
  "created_at" : "2016-10-22 20:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/q01OxIVxX7",
      "expanded_url" : "http:\/\/go.wh.gov\/1NuNrf",
      "display_url" : "go.wh.gov\/1NuNrf"
    } ]
  },
  "geo" : { },
  "id_str" : "789915516865351680",
  "text" : "RT @usedgov: \"Nobody should be priced out of a higher education.\" \u2014@POTUS on the progress we've made: https:\/\/t.co\/q01OxIVxX7 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 54, 60 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/789881509087850496\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/KJZGO6tTE8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvNhamwWEAA85bb.jpg",
        "id_str" : "789081469427781632",
        "id" : 789081469427781632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvNhamwWEAA85bb.jpg",
        "sizes" : [ {
          "h" : 674,
          "resize" : "fit",
          "w" : 1199
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 1199
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 1199
        } ],
        "display_url" : "pic.twitter.com\/KJZGO6tTE8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/q01OxIVxX7",
        "expanded_url" : "http:\/\/go.wh.gov\/1NuNrf",
        "display_url" : "go.wh.gov\/1NuNrf"
      } ]
    },
    "geo" : { },
    "id_str" : "789881509087850496",
    "text" : "\"Nobody should be priced out of a higher education.\" \u2014@POTUS on the progress we've made: https:\/\/t.co\/q01OxIVxX7 https:\/\/t.co\/KJZGO6tTE8",
    "id" : 789881509087850496,
    "created_at" : "2016-10-22 17:30:01 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 789915516865351680,
  "created_at" : "2016-10-22 19:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/pqdrS2BRAb",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "789901134748061696",
  "text" : ".@POTUS is acting to:\n \nSave you money on flights \u2713\nCreate more competition \u2713\nEnsure you get what you pay for \u2713https:\/\/t.co\/pqdrS2BRAb",
  "id" : 789901134748061696,
  "created_at" : "2016-10-22 18:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/35Q4jIdBuz",
      "expanded_url" : "http:\/\/snpy.tv\/2duOOej",
      "display_url" : "snpy.tv\/2duOOej"
    } ]
  },
  "geo" : { },
  "id_str" : "789886095127216128",
  "text" : "One in eight women in the United States will develop breast cancer in their lifetime. Together, we can change that. https:\/\/t.co\/35Q4jIdBuz",
  "id" : 789886095127216128,
  "created_at" : "2016-10-22 17:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/pqdrS2TsrJ",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "789855836851941376",
  "text" : "\"I know what a pain the whole process can be\" \u2014@POTUS on how he\u2019s acting to make air travel easier for everyone: https:\/\/t.co\/pqdrS2TsrJ",
  "id" : 789855836851941376,
  "created_at" : "2016-10-22 15:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789841220990275584\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/82cTjlmXfQ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvYSoqzVIAAdM3Q.jpg",
      "id_str" : "789839274543751168",
      "id" : 789839274543751168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvYSoqzVIAAdM3Q.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/82cTjlmXfQ"
    } ],
    "hashtags" : [ {
      "text" : "TakeBackDay",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/IzZjoE3NJs",
      "expanded_url" : "http:\/\/go.wh.gov\/uxYShy",
      "display_url" : "go.wh.gov\/uxYShy"
    } ]
  },
  "geo" : { },
  "id_str" : "789841220990275584",
  "text" : "#TakeBackDay is a concrete way we can all help end the opioid epidemic. Drop off unused prescription drugs today: https:\/\/t.co\/IzZjoE3NJs https:\/\/t.co\/82cTjlmXfQ",
  "id" : 789841220990275584,
  "created_at" : "2016-10-22 14:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 3, 9 ],
      "id_str" : "15460572",
      "id" : 15460572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RMolJ1K5NB",
      "expanded_url" : "https:\/\/apps.deadiversion.usdoj.gov\/SEARCH-NTBI",
      "display_url" : "apps.deadiversion.usdoj.gov\/SEARCH-NTBI"
    } ]
  },
  "geo" : { },
  "id_str" : "789838901926035456",
  "text" : "RT @ONDCP: Preventing overdose deaths begins by preventing misuse from ever beginning. Drop off unused Rx TODAY: https:\/\/t.co\/RMolJ1K5NB #T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TakeBackDay",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/RMolJ1K5NB",
        "expanded_url" : "https:\/\/apps.deadiversion.usdoj.gov\/SEARCH-NTBI",
        "display_url" : "apps.deadiversion.usdoj.gov\/SEARCH-NTBI"
      } ]
    },
    "geo" : { },
    "id_str" : "789828913711181824",
    "text" : "Preventing overdose deaths begins by preventing misuse from ever beginning. Drop off unused Rx TODAY: https:\/\/t.co\/RMolJ1K5NB #TakeBackDay",
    "id" : 789828913711181824,
    "created_at" : "2016-10-22 14:01:01 +0000",
    "user" : {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "protected" : false,
      "id_str" : "15460572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446652455552430080\/t6umtSs5_normal.png",
      "id" : 15460572,
      "verified" : true
    }
  },
  "id" : 789838901926035456,
  "created_at" : "2016-10-22 14:40:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/pqdrS2TsrJ",
      "expanded_url" : "http:\/\/go.wh.gov\/ZEtrGk",
      "display_url" : "go.wh.gov\/ZEtrGk"
    } ]
  },
  "geo" : { },
  "id_str" : "789824832649035777",
  "text" : "In this week\u2019s address, @POTUS explains how he\u2019s taking steps to improve air travel and save you money: https:\/\/t.co\/pqdrS2TsrJ",
  "id" : 789824832649035777,
  "created_at" : "2016-10-22 13:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 60, 71 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 74, 90 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Earth",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789629832153931776",
  "text" : "RT @StationCDRKelly: Great day on #Earth! Met @POTUS at the @WhiteHouse w @ShuttleCDRKelly today and talked about the environment and our #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 25, 31 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 39, 50 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Mark Kelly",
        "screen_name" : "ShuttleCDRKelly",
        "indices" : [ 53, 69 ],
        "id_str" : "65707359",
        "id" : 65707359
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/StationCDRKelly\/status\/789602801420820480\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/kQJ24zba4V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvU7jwnWIAAxd3u.jpg",
        "id_str" : "789602795204780032",
        "id" : 789602795204780032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvU7jwnWIAAxd3u.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kQJ24zba4V"
      } ],
      "hashtags" : [ {
        "text" : "Earth",
        "indices" : [ 13, 19 ]
      }, {
        "text" : "journeytomars",
        "indices" : [ 117, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789602801420820480",
    "text" : "Great day on #Earth! Met @POTUS at the @WhiteHouse w @ShuttleCDRKelly today and talked about the environment and our #journeytomars! https:\/\/t.co\/kQJ24zba4V",
    "id" : 789602801420820480,
    "created_at" : "2016-10-21 23:02:32 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 789629832153931776,
  "created_at" : "2016-10-22 00:49:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789598336873488384",
  "text" : "RT @POTUS: Check out my newest science advisors! These kids are fearless in using science to tackle our toughest problems. Thanks for the i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/789598150541635588\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/qe7h3IfTTZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvU3ODPUsAAdrIT.jpg",
        "id_str" : "789598024200663040",
        "id" : 789598024200663040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvU3ODPUsAAdrIT.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qe7h3IfTTZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789598150541635588",
    "text" : "Check out my newest science advisors! These kids are fearless in using science to tackle our toughest problems. Thanks for the inspiration. https:\/\/t.co\/qe7h3IfTTZ",
    "id" : 789598150541635588,
    "created_at" : "2016-10-21 22:44:03 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 789598336873488384,
  "created_at" : "2016-10-21 22:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/jwGCigGjAK",
      "expanded_url" : "http:\/\/snpy.tv\/2dw0Cbf",
      "display_url" : "snpy.tv\/2dw0Cbf"
    } ]
  },
  "geo" : { },
  "id_str" : "789593036384722944",
  "text" : "\"May we always be bold.\u201D Watch as @POTUS toasts his final State Dinner in style in this #WestWingWeek: https:\/\/t.co\/jwGCigGjAK",
  "id" : 789593036384722944,
  "created_at" : "2016-10-21 22:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FairChanceBusinessPledge",
      "indices" : [ 45, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789562083650199552",
  "text" : "RT @vj44: We encourage employers to take the #FairChanceBusinessPledge to ensure job opportunities are available for re-entry: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FairChanceBusinessPledge",
        "indices" : [ 35, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7jA6oZefPi",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/criminal-justice\/fair-chance-pledge",
        "display_url" : "whitehouse.gov\/issues\/crimina\u2026"
      }, {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/n39Y4Nygq1",
        "expanded_url" : "https:\/\/twitter.com\/Krissy_Roth\/status\/789557911437602816",
        "display_url" : "twitter.com\/Krissy_Roth\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "789559116477952000",
    "text" : "We encourage employers to take the #FairChanceBusinessPledge to ensure job opportunities are available for re-entry: https:\/\/t.co\/7jA6oZefPi https:\/\/t.co\/n39Y4Nygq1",
    "id" : 789559116477952000,
    "created_at" : "2016-10-21 20:08:57 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 789562083650199552,
  "created_at" : "2016-10-21 20:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 14, 22 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "DASH",
      "screen_name" : "SheIsDash",
      "indices" : [ 39, 49 ],
      "id_str" : "1206398228",
      "id" : 1206398228
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 76, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789552975295447045",
  "text" : "RT @vj44: Hi, @Twitter!  I'm here with @SheIsDash to take your questions on #CriminalJusticeReform. I'll start: Dash, why do you care about\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 4, 12 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "DASH",
        "screen_name" : "SheIsDash",
        "indices" : [ 29, 39 ],
        "id_str" : "1206398228",
        "id" : 1206398228
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 66, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789550807993741312",
    "text" : "Hi, @Twitter!  I'm here with @SheIsDash to take your questions on #CriminalJusticeReform. I'll start: Dash, why do you care about CJ reform?",
    "id" : 789550807993741312,
    "created_at" : "2016-10-21 19:35:56 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 789552975295447045,
  "created_at" : "2016-10-21 19:44:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789528667433074688\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/EaE61KLkY4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvT34E9XEAAZygv.jpg",
      "id_str" : "789528377472520192",
      "id" : 789528377472520192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvT34E9XEAAZygv.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EaE61KLkY4"
    } ],
    "hashtags" : [ {
      "text" : "TakeBackDay",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/IzZjoE3NJs",
      "expanded_url" : "http:\/\/go.wh.gov\/uxYShy",
      "display_url" : "go.wh.gov\/uxYShy"
    } ]
  },
  "geo" : { },
  "id_str" : "789528667433074688",
  "text" : "Nearly 130 people in the U.S. die every day from a drug overdose. You can help change that tomorrow on #TakeBackDay: https:\/\/t.co\/IzZjoE3NJs https:\/\/t.co\/EaE61KLkY4",
  "id" : 789528667433074688,
  "created_at" : "2016-10-21 18:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "DASH",
      "screen_name" : "SheIsDash",
      "indices" : [ 55, 65 ],
      "id_str" : "1206398228",
      "id" : 1206398228
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OITNB",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "CriminalJusticeReform",
      "indices" : [ 119, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789510474329096192",
  "text" : "RT @vj44: Qs on criminal justice issues? Join me &amp; @SheIsDash from #OITNB for a Q&amp;A 3:30pm ET today. Ask using #CriminalJusticeReform. See\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DASH",
        "screen_name" : "SheIsDash",
        "indices" : [ 45, 55 ],
        "id_str" : "1206398228",
        "id" : 1206398228
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OITNB",
        "indices" : [ 61, 67 ]
      }, {
        "text" : "CriminalJusticeReform",
        "indices" : [ 109, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789503594735296512",
    "text" : "Qs on criminal justice issues? Join me &amp; @SheIsDash from #OITNB for a Q&amp;A 3:30pm ET today. Ask using #CriminalJusticeReform. See you then!",
    "id" : 789503594735296512,
    "created_at" : "2016-10-21 16:28:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 789510474329096192,
  "created_at" : "2016-10-21 16:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TakeBackDay",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789504009354768384",
  "text" : "RT @Denis44: Most people who misuse Rx drugs say they obtained them from family or friends. Help change that tmrw on #TakeBackDay https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/789503344251469828\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/jkTu6NWxvB",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvTg7-JWYAAAa9_.jpg",
        "id_str" : "789503155595796480",
        "id" : 789503155595796480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvTg7-JWYAAAa9_.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jkTu6NWxvB"
      } ],
      "hashtags" : [ {
        "text" : "TakeBackDay",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/UrrnqR89RN",
        "expanded_url" : "http:\/\/go.wh.gov\/uxYShy",
        "display_url" : "go.wh.gov\/uxYShy"
      } ]
    },
    "geo" : { },
    "id_str" : "789503344251469828",
    "text" : "Most people who misuse Rx drugs say they obtained them from family or friends. Help change that tmrw on #TakeBackDay https:\/\/t.co\/UrrnqR89RN https:\/\/t.co\/jkTu6NWxvB",
    "id" : 789503344251469828,
    "created_at" : "2016-10-21 16:27:20 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 789504009354768384,
  "created_at" : "2016-10-21 16:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 3, 16 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/cnX4vTIqOJ",
      "expanded_url" : "https:\/\/apps.deadiversion.usdoj.gov\/SEARCH-NTBI",
      "display_url" : "apps.deadiversion.usdoj.gov\/SEARCH-NTBI"
    } ]
  },
  "geo" : { },
  "id_str" : "789500245344387073",
  "text" : "RT @Botticelli44: A lot of local communities have year round Take Back locations. Find your closest site here: https:\/\/t.co\/cnX4vTIqOJ #Tak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TakeBackDay",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/cnX4vTIqOJ",
        "expanded_url" : "https:\/\/apps.deadiversion.usdoj.gov\/SEARCH-NTBI",
        "display_url" : "apps.deadiversion.usdoj.gov\/SEARCH-NTBI"
      }, {
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/7hZ74hz7BG",
        "expanded_url" : "https:\/\/twitter.com\/Denise__Mariano\/status\/789495103584862208",
        "display_url" : "twitter.com\/Denise__Marian\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "789498244766191616",
    "text" : "A lot of local communities have year round Take Back locations. Find your closest site here: https:\/\/t.co\/cnX4vTIqOJ #TakeBackDay https:\/\/t.co\/7hZ74hz7BG",
    "id" : 789498244766191616,
    "created_at" : "2016-10-21 16:07:04 +0000",
    "user" : {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "protected" : false,
      "id_str" : "2382297056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789238935159312385\/z7RppzRN_normal.jpg",
      "id" : 2382297056,
      "verified" : true
    }
  },
  "id" : 789500245344387073,
  "created_at" : "2016-10-21 16:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 3, 9 ],
      "id_str" : "15460572",
      "id" : 15460572
    }, {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 66, 79 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    }, {
      "name" : "CVS Health",
      "screen_name" : "CVSHealth",
      "indices" : [ 81, 91 ],
      "id_str" : "122473388",
      "id" : 122473388
    }, {
      "name" : "Walgreens",
      "screen_name" : "Walgreens",
      "indices" : [ 99, 109 ],
      "id_str" : "46177695",
      "id" : 46177695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789497180893708288",
  "text" : "RT @ONDCP: Starting now: Prescription Drug Take Back Q&amp;A with @Botticelli44, @CVSHealth, &amp; @Walgreens. Follow &amp; submit questions using #Tak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Botticelli",
        "screen_name" : "Botticelli44",
        "indices" : [ 55, 68 ],
        "id_str" : "2382297056",
        "id" : 2382297056
      }, {
        "name" : "CVS Health",
        "screen_name" : "CVSHealth",
        "indices" : [ 70, 80 ],
        "id_str" : "122473388",
        "id" : 122473388
      }, {
        "name" : "Walgreens",
        "screen_name" : "Walgreens",
        "indices" : [ 88, 98 ],
        "id_str" : "46177695",
        "id" : 46177695
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TakeBackDay",
        "indices" : [ 136, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789496990715510784",
    "text" : "Starting now: Prescription Drug Take Back Q&amp;A with @Botticelli44, @CVSHealth, &amp; @Walgreens. Follow &amp; submit questions using #TakeBackDay",
    "id" : 789496990715510784,
    "created_at" : "2016-10-21 16:02:05 +0000",
    "user" : {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "protected" : false,
      "id_str" : "15460572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446652455552430080\/t6umtSs5_normal.png",
      "id" : 15460572,
      "verified" : true
    }
  },
  "id" : 789497180893708288,
  "created_at" : "2016-10-21 16:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 17, 23 ],
      "id_str" : "15460572",
      "id" : 15460572
    }, {
      "name" : "CVS Health",
      "screen_name" : "CVSHealth",
      "indices" : [ 41, 51 ],
      "id_str" : "122473388",
      "id" : 122473388
    }, {
      "name" : "Walgreens",
      "screen_name" : "Walgreens",
      "indices" : [ 52, 62 ],
      "id_str" : "46177695",
      "id" : 46177695
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789462366085865472\/photo\/1",
      "indices" : [ 145, 168 ],
      "url" : "https:\/\/t.co\/m9Yh1rGI85",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvS7xC3UEAAgh98.jpg",
      "id_str" : "789462285953536000",
      "id" : 789462285953536000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvS7xC3UEAAgh98.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/m9Yh1rGI85"
    } ],
    "hashtags" : [ {
      "text" : "TakeBackDay",
      "indices" : [ 132, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789462366085865472",
  "text" : "At 12pm ET, join @ONDCP Dir. Botticelli, @CVSHealth @Walgreens for Q&amp;A on the importance of safe drug disposal. Submit Qs using #TakeBackDay https:\/\/t.co\/m9Yh1rGI85",
  "id" : 789462366085865472,
  "created_at" : "2016-10-21 13:44:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "indices" : [ 3, 10 ],
      "id_str" : "1601549102",
      "id" : 1601549102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/HHNCg4rUCL",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/letters?utm_source=email&utm_medium=email&utm_content=email651&utm_campaign=aca",
      "display_url" : "whitehouse.gov\/letters?utm_so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "789460071625416704",
  "text" : "RT @Tara44: When I was working on Obamacare my favorite thing was the letters to POTUS, you can see them here: https:\/\/t.co\/HHNCg4rUCL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/HHNCg4rUCL",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/letters?utm_source=email&utm_medium=email&utm_content=email651&utm_campaign=aca",
        "display_url" : "whitehouse.gov\/letters?utm_so\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "789453934435954688",
    "text" : "When I was working on Obamacare my favorite thing was the letters to POTUS, you can see them here: https:\/\/t.co\/HHNCg4rUCL",
    "id" : 789453934435954688,
    "created_at" : "2016-10-21 13:10:59 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 789460071625416704,
  "created_at" : "2016-10-21 13:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/789245835494252544\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/kmxgHWxJcP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvP25rUWcAEgDAI.jpg",
      "id_str" : "789245830461026305",
      "id" : 789245830461026305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvP25rUWcAEgDAI.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/kmxgHWxJcP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789246214785105920",
  "text" : "RT @vj44: Tonight we honor those affected by breast cancer and their families. https:\/\/t.co\/kmxgHWxJcP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/789245835494252544\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/kmxgHWxJcP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvP25rUWcAEgDAI.jpg",
        "id_str" : "789245830461026305",
        "id" : 789245830461026305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvP25rUWcAEgDAI.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/kmxgHWxJcP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789245835494252544",
    "text" : "Tonight we honor those affected by breast cancer and their families. https:\/\/t.co\/kmxgHWxJcP",
    "id" : 789245835494252544,
    "created_at" : "2016-10-20 23:24:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 789246214785105920,
  "created_at" : "2016-10-20 23:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789239581300359168",
  "text" : "RT @vj44: We lit the @WhiteHouse pink tonight to commemorate Breast Cancer Awareness Month. Make sure to enroll in #ACA starting Nov. 1 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/789237393719255044\/photo\/1",
        "indices" : [ 126, 149 ],
        "url" : "https:\/\/t.co\/RGc3N8ZkRb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPvOOdWAAAVM4p.jpg",
        "id_str" : "789237387398348800",
        "id" : 789237387398348800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPvOOdWAAAVM4p.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/RGc3N8ZkRb"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 105, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789237393719255044",
    "text" : "We lit the @WhiteHouse pink tonight to commemorate Breast Cancer Awareness Month. Make sure to enroll in #ACA starting Nov. 1 https:\/\/t.co\/RGc3N8ZkRb",
    "id" : 789237393719255044,
    "created_at" : "2016-10-20 22:50:32 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 789239581300359168,
  "created_at" : "2016-10-20 22:59:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789217169946972160\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/gzX2NIFloL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPcwgzXEAEcqs7.jpg",
      "id_str" : "789217085717155841",
      "id" : 789217085717155841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPcwgzXEAEcqs7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/gzX2NIFloL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/oc1AEfD6mt",
      "expanded_url" : "http:\/\/go.wh.gov\/6QwPYT",
      "display_url" : "go.wh.gov\/6QwPYT"
    } ]
  },
  "geo" : { },
  "id_str" : "789217169946972160",
  "text" : "Lowest uninsured rate in history \u2713\n20M adults covered \u2713\nHealth spending less than expected \u2713\n \nThat\u2019s progress. https:\/\/t.co\/oc1AEfD6mt https:\/\/t.co\/gzX2NIFloL",
  "id" : 789217169946972160,
  "created_at" : "2016-10-20 21:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789204142317301760\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/NfebcNBc88",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPQ9kWVUAAxZqx.jpg",
      "id_str" : "789204115867914240",
      "id" : 789204115867914240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPQ9kWVUAAxZqx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NfebcNBc88"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/oc1AEfUHL3",
      "expanded_url" : "http:\/\/go.wh.gov\/6QwPYT",
      "display_url" : "go.wh.gov\/6QwPYT"
    } ]
  },
  "geo" : { },
  "id_str" : "789204142317301760",
  "text" : "Under the #ACA, 20 million adults can now get the health care they need. Some shared their stories with @POTUS: https:\/\/t.co\/oc1AEfUHL3 https:\/\/t.co\/NfebcNBc88",
  "id" : 789204142317301760,
  "created_at" : "2016-10-20 20:38:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 54, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/TvHYmLLOnO",
      "expanded_url" : "http:\/\/snpy.tv\/2el76yg",
      "display_url" : "snpy.tv\/2el76yg"
    } ]
  },
  "geo" : { },
  "id_str" : "789193607659986945",
  "text" : ".@POTUS outlines the steps we can take to improve the #ACA and ensure every American has the health care they need: https:\/\/t.co\/TvHYmLLOnO",
  "id" : 789193607659986945,
  "created_at" : "2016-10-20 19:56:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/oeurtrUTFT",
      "expanded_url" : "http:\/\/snpy.tv\/2dqYDdo",
      "display_url" : "snpy.tv\/2dqYDdo"
    } ]
  },
  "geo" : { },
  "id_str" : "789186655697547265",
  "text" : "Free preventive care \u2713\nFree check-ups for women \u2713\nFree mammograms \u2713\n\n\u201CThanks, Obama.\u201D \u2014@POTUS https:\/\/t.co\/oeurtrUTFT",
  "id" : 789186655697547265,
  "created_at" : "2016-10-20 19:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Nn1JBpPe3W",
      "expanded_url" : "http:\/\/snpy.tv\/2dRXdEY",
      "display_url" : "snpy.tv\/2dRXdEY"
    } ]
  },
  "geo" : { },
  "id_str" : "789181743806894081",
  "text" : "\u201CNever in American history has the uninsured rate been lower than it is today\u201D \u2014@POTUS on the #ACA https:\/\/t.co\/Nn1JBpPe3W",
  "id" : 789181743806894081,
  "created_at" : "2016-10-20 19:09:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789174355750039552",
  "text" : "\"You stood up for the idea that no American should have to go without the health care they need. And it's still true today.\" \u2014@POTUS",
  "id" : 789174355750039552,
  "created_at" : "2016-10-20 18:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789173889658068992",
  "text" : "\"Breaking gridlock will come only when the American people demand it.\" \u2014@POTUS",
  "id" : 789173889658068992,
  "created_at" : "2016-10-20 18:38:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789172441738129409",
  "text" : "\"The sum of those parts that are popular in Obamacare is Obamacare...Repealing it would make the majority of Americans worse off\" \u2014@POTUS",
  "id" : 789172441738129409,
  "created_at" : "2016-10-20 18:32:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789171896860278784",
  "text" : "\"Now is not the time to move backwards on health care reform.  It\u2019s time to move forward.\" \u2014@POTUS",
  "id" : 789171896860278784,
  "created_at" : "2016-10-20 18:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789171353500856321",
  "text" : "\"Finally, we should continue to encourage innovation by the states.\" \u2014@POTUS",
  "id" : 789171353500856321,
  "created_at" : "2016-10-20 18:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "indices" : [ 3, 10 ],
      "id_str" : "2151620534",
      "id" : 2151620534
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789171170360688640",
  "text" : "RT @Hill44: Next, @POTUS says, Congress should enact a public plan fallback in some parts of the country  -- modeled on Republican idea in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "789170708219781120",
    "geo" : { },
    "id_str" : "789171010041880589",
    "in_reply_to_user_id" : 2151620534,
    "text" : "Next, @POTUS says, Congress should enact a public plan fallback in some parts of the country  -- modeled on Republican idea in Part D.",
    "id" : 789171010041880589,
    "in_reply_to_status_id" : 789170708219781120,
    "created_at" : "2016-10-20 18:26:45 +0000",
    "in_reply_to_screen_name" : "Hill44",
    "in_reply_to_user_id_str" : "2151620534",
    "user" : {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "protected" : false,
      "id_str" : "2151620534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658658579142959104\/85LEK24P_normal.jpg",
      "id" : 2151620534,
      "verified" : true
    }
  },
  "id" : 789171170360688640,
  "created_at" : "2016-10-20 18:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789170759574827008",
  "text" : "\"Provide more tax credits for more middle-income families...to help them buy insurance\" \u2014@POTUS",
  "id" : 789170759574827008,
  "created_at" : "2016-10-20 18:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789170360117637120",
  "text" : "\"Every state should expand Medicaid.\" \u2014@POTUS on what we can do to improve the #ACA",
  "id" : 789170360117637120,
  "created_at" : "2016-10-20 18:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789170100758720512\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/KUSx1Fwmaw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOx_byVYAAHq9E.jpg",
      "id_str" : "789170063068717056",
      "id" : 789170063068717056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOx_byVYAAHq9E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/KUSx1Fwmaw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789170100758720512",
  "text" : "\"Progress that\u2019s helped hold growth in the price of health care to the slowest rate in 50 years\u2014that goes away\" \u2014@POTUS on what repeal means https:\/\/t.co\/KUSx1Fwmaw",
  "id" : 789170100758720512,
  "created_at" : "2016-10-20 18:23:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789169759204048896",
  "text" : "\"I can tell you what won\u2019t work: repealing the Affordable Care Act.\" \u2014@POTUS on improving the #ACA",
  "id" : 789169759204048896,
  "created_at" : "2016-10-20 18:21:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/5zeR2RPWAE",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "789169512536944641",
  "text" : "\"With the ability to shop around on https:\/\/t.co\/5zeR2RPWAE...people can find plans for prices even lower than this year\u2019s prices\" \u2014@POTUS",
  "id" : 789169512536944641,
  "created_at" : "2016-10-20 18:20:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789168581640466438",
  "text" : "\"There are some states where there\u2019s still not enough competition between insurers.\" \u2014@POTUS",
  "id" : 789168581640466438,
  "created_at" : "2016-10-20 18:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789168290027364352",
  "text" : "\"If the 19 states who so far have not expanded Medicaid would just do so, another 4 million people would have coverage right now.\" \u2014@POTUS",
  "id" : 789168290027364352,
  "created_at" : "2016-10-20 18:15:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789167095044911104",
  "text" : "\"The Affordable Care Act has done for us what it was designed to do: It gave us affordable health care.\" \u2014@POTUS",
  "id" : 789167095044911104,
  "created_at" : "2016-10-20 18:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "789167017450278912",
  "text" : "\"Most people\u2014today\u2014can find a plan for less than $75 a month at the https:\/\/t.co\/GNfbftrfo3 marketplace\" \u2014@POTUS",
  "id" : 789167017450278912,
  "created_at" : "2016-10-20 18:10:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789166448056766464",
  "text" : "\"We gave states funding to expand Medicaid...more than 4 million people have coverage who didn\u2019t have it before\" \u2014@POTUS",
  "id" : 789166448056766464,
  "created_at" : "2016-10-20 18:08:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789165326088802305",
  "text" : "\"We made it illegal to discriminate against people with pre-existing conditions.\" \u2014@POTUS",
  "id" : 789165326088802305,
  "created_at" : "2016-10-20 18:04:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789165167716077569",
  "text" : "\"Because of the law, your annual out-of pocket spending is capped...Young people can stay on their parents' plan\" \u2014@POTUS",
  "id" : 789165167716077569,
  "created_at" : "2016-10-20 18:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789164659311976448",
  "text" : "\"We can do even more...if we're honest about what's working, what needs fixing, and how to fix it.\" \u2014@POTUS on improving the #ACA",
  "id" : 789164659311976448,
  "created_at" : "2016-10-20 18:01:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789164310245146624",
  "text" : "\"And that\u2019s true across the board\u2014it has dropped among women, young adults, Latinos, African Americans.\" \u2014@POTUS on the uninsured rate #ACA",
  "id" : 789164310245146624,
  "created_at" : "2016-10-20 18:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789164200643862528\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/o6nx45ZITL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOsn8BUMAY7XPR.jpg",
      "id_str" : "789164161846489094",
      "id" : 789164161846489094,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOsn8BUMAY7XPR.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/o6nx45ZITL"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789164200643862528",
  "text" : "\"Never in American history has the uninsured rate been lower than it is today.\" \u2014@POTUS on the importance of the #ACA https:\/\/t.co\/o6nx45ZITL",
  "id" : 789164200643862528,
  "created_at" : "2016-10-20 17:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789164069202763776\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/3uyu39axca",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOse-9UsAU4qDJ.jpg",
      "id_str" : "789164008016228357",
      "id" : 789164008016228357,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOse-9UsAU4qDJ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3uyu39axca"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789164069202763776",
  "text" : "\"So do another 3 million children\" \u2014@POTUS on kids who have gained insurance since he took office https:\/\/t.co\/3uyu39axca",
  "id" : 789164069202763776,
  "created_at" : "2016-10-20 17:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789163902646890496\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/eCoz6txbc3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOsI_3UkAAxB2C.jpg",
      "id_str" : "789163630302367744",
      "id" : 789163630302367744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOsI_3UkAAxB2C.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/eCoz6txbc3"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789163902646890496",
  "text" : "\"Because of this law...another 20 million Americans now know the financial security of health insurance.\" \u2014@POTUS on progress under the #ACA https:\/\/t.co\/eCoz6txbc3",
  "id" : 789163902646890496,
  "created_at" : "2016-10-20 17:58:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789163506046078976",
  "text" : "\"It was about children like Zoe Lihn...halfway to hitting her lifetime insurance cap before she was old enough to walk\" \u2014@POTUS on the #ACA",
  "id" : 789163506046078976,
  "created_at" : "2016-10-20 17:56:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789163008014503936",
  "text" : "\"Health care is not just a privilege, but a right for every single American.\" \u2014@POTUS speaking on the #ACA",
  "id" : 789163008014503936,
  "created_at" : "2016-10-20 17:54:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789162761070714880\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/7g1B0wxW7C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOrVdRVYAEweXK.jpg",
      "id_str" : "789162744842903553",
      "id" : 789162744842903553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOrVdRVYAEweXK.jpg",
      "sizes" : [ {
        "h" : 663,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1436
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1436
      } ],
      "display_url" : "pic.twitter.com\/7g1B0wxW7C"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Wp4TFNZJI1",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv7KHN",
      "display_url" : "go.wh.gov\/Rv7KHN"
    } ]
  },
  "geo" : { },
  "id_str" : "789162761070714880",
  "text" : "Happening now: @POTUS speaks on the progress we've made every American gets the coverage they need under the #ACA: https:\/\/t.co\/Wp4TFNZJI1 https:\/\/t.co\/7g1B0wxW7C",
  "id" : 789162761070714880,
  "created_at" : "2016-10-20 17:53:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Wp4TFNZJI1",
      "expanded_url" : "http:\/\/go.wh.gov\/Rv7KHN",
      "display_url" : "go.wh.gov\/Rv7KHN"
    } ]
  },
  "geo" : { },
  "id_str" : "789158273102602240",
  "text" : "Tune in at 1:55pm ET as @POTUS speaks on the progress we\u2019ve made under the #ACA\u2014and how we can keep moving forward: https:\/\/t.co\/Wp4TFNZJI1",
  "id" : 789158273102602240,
  "created_at" : "2016-10-20 17:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789151486492094464\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/qlGfSiCUnm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOhDqPWgAE1pJY.jpg",
      "id_str" : "789151443970326529",
      "id" : 789151443970326529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOhDqPWgAE1pJY.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 5250,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/qlGfSiCUnm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ebv5Blapf0",
      "expanded_url" : "http:\/\/WH.gov\/letters",
      "display_url" : "WH.gov\/letters"
    } ]
  },
  "geo" : { },
  "id_str" : "789151486492094464",
  "text" : "Read the letters from Americans who have written to @POTUS on the impact that health care has had on their lives: https:\/\/t.co\/ebv5Blapf0 https:\/\/t.co\/qlGfSiCUnm",
  "id" : 789151486492094464,
  "created_at" : "2016-10-20 17:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/bqK6KxawW3",
      "expanded_url" : "http:\/\/go.wh.gov\/oL3NH8",
      "display_url" : "go.wh.gov\/oL3NH8"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/nPz3zXbULo",
      "expanded_url" : "http:\/\/snpy.tv\/2eklLd6",
      "display_url" : "snpy.tv\/2eklLd6"
    } ]
  },
  "geo" : { },
  "id_str" : "789143401614704640",
  "text" : "Today @POTUS speaks on our progress under the #ACA. Watch new clips from the day it passed: https:\/\/t.co\/bqK6KxawW3 https:\/\/t.co\/nPz3zXbULo",
  "id" : 789143401614704640,
  "created_at" : "2016-10-20 16:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/789132463486464000\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/kI4HcDlyDI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOPrx7WEAIzBth.jpg",
      "id_str" : "789132342019362818",
      "id" : 789132342019362818,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOPrx7WEAIzBth.jpg",
      "sizes" : [ {
        "h" : 1375,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2308,
        "resize" : "fit",
        "w" : 3438
      } ],
      "display_url" : "pic.twitter.com\/kI4HcDlyDI"
    } ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789132463486464000",
  "text" : "We are all more free when we are treated as equals. Today, White House staff stand against bullying and in support of LGBTQ youth #SpiritDay https:\/\/t.co\/kI4HcDlyDI",
  "id" : 789132463486464000,
  "created_at" : "2016-10-20 15:53:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/789121703075078145\/photo\/1",
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/lYQdb2Aykl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOFypAVIAAzhMb.jpg",
      "id_str" : "789121464767160320",
      "id" : 789121464767160320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOFypAVIAAzhMb.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lYQdb2Aykl"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/ebv5Bls0DA",
      "expanded_url" : "http:\/\/WH.gov\/letters",
      "display_url" : "WH.gov\/letters"
    } ]
  },
  "geo" : { },
  "id_str" : "789121703075078145",
  "text" : "Each day, @POTUS reads 10 letters from Americans. Today, we're sharing some of the letters written about #ACA: https:\/\/t.co\/ebv5Bls0DA https:\/\/t.co\/lYQdb2Aykl",
  "id" : 789121703075078145,
  "created_at" : "2016-10-20 15:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 78, 90 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Dglde2aSim",
      "expanded_url" : "http:\/\/snpy.tv\/2elvG3F",
      "display_url" : "snpy.tv\/2elvG3F"
    } ]
  },
  "geo" : { },
  "id_str" : "788902556751826944",
  "text" : "\"We are ready to preserve...and invest in Obama's legacy also in Europe.\" \u2014PM @MatteoRenzi https:\/\/t.co\/Dglde2aSim",
  "id" : 788902556751826944,
  "created_at" : "2016-10-20 00:40:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 14, 21 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 34, 46 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788895251775623168\/photo\/1",
      "indices" : [ 147, 170 ],
      "url" : "https:\/\/t.co\/8vqrys2fcl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvK27KKWIAEdNa2.jpg",
      "id_str" : "788894012199542785",
      "id" : 788894012199542785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvK27KKWIAEdNa2.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/8vqrys2fcl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/c2owH6D7EI",
      "expanded_url" : "http:\/\/go.wh.gov\/p7CXPw",
      "display_url" : "go.wh.gov\/p7CXPw"
    } ]
  },
  "geo" : { },
  "id_str" : "788895251775623168",
  "text" : ".@POTUS &amp; @FLOTUS welcomed PM @matteorenzi &amp; Mrs. Landini of Italy to their last State Dinner in style. In photos: https:\/\/t.co\/c2owH6D7EI https:\/\/t.co\/8vqrys2fcl",
  "id" : 788895251775623168,
  "created_at" : "2016-10-20 00:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 56, 68 ],
      "id_str" : "18762875",
      "id" : 18762875
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Dglde1TgTM",
      "expanded_url" : "http:\/\/snpy.tv\/2elvG3F",
      "display_url" : "snpy.tv\/2elvG3F"
    } ]
  },
  "geo" : { },
  "id_str" : "788887783758635009",
  "text" : "Before heading to last night\u2019s State Dinner, Italian PM @MatteoRenzi reflected on @POTUS\u2019s leadership in the world: https:\/\/t.co\/Dglde1TgTM",
  "id" : 788887783758635009,
  "created_at" : "2016-10-19 23:41:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 2, 8 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 11, 18 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 27, 35 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 38, 50 ],
      "id_str" : "18762875",
      "id" : 18762875
    }, {
      "name" : "Mario Batali",
      "screen_name" : "Mariobatali",
      "indices" : [ 53, 65 ],
      "id_str" : "148496087",
      "id" : 148496087
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788866979851415552\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/YyUpfL76G7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvKd6MrUMAAOfXF.jpg",
      "id_str" : "788866507904135168",
      "id" : 788866507904135168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvKd6MrUMAAOfXF.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/YyUpfL76G7"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788866979851415552\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/YyUpfL76G7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvKd6NsVMAAA7bp.jpg",
      "id_str" : "788866508176830464",
      "id" : 788866508176830464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvKd6NsVMAAA7bp.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/YyUpfL76G7"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788866979851415552\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/YyUpfL76G7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvKd6N8UsAAFc1D.jpg",
      "id_str" : "788866508243906560",
      "id" : 788866508243906560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvKd6N8UsAAFc1D.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/YyUpfL76G7"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788866979851415552\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/YyUpfL76G7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvKeAHXUEAAa-xO.jpg",
      "id_str" : "788866609557278720",
      "id" : 788866609557278720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvKeAHXUEAAa-xO.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/YyUpfL76G7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/c2owH6D7EI",
      "expanded_url" : "http:\/\/go.wh.gov\/p7CXPw",
      "display_url" : "go.wh.gov\/p7CXPw"
    } ]
  },
  "geo" : { },
  "id_str" : "788866979851415552",
  "text" : "\u2713 @POTUS\n\u2713 @FLOTUS\n\u2713 @VP\n\u2713 @DrBiden\n\u2713 @matteorenzi\n\u2713 @MarioBatali in orange crocs\n \nThe last State Visit in photos: https:\/\/t.co\/c2owH6D7EI https:\/\/t.co\/YyUpfL76G7",
  "id" : 788866979851415552,
  "created_at" : "2016-10-19 22:18:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788855649631219712\/photo\/1",
      "indices" : [ 143, 166 ],
      "url" : "https:\/\/t.co\/j96JWNA3Nu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvKT_SoXEAAVJe2.jpg",
      "id_str" : "788855600285421568",
      "id" : 788855600285421568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvKT_SoXEAAVJe2.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/j96JWNA3Nu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/c2owH6D7EI",
      "expanded_url" : "http:\/\/go.wh.gov\/p7CXPw",
      "display_url" : "go.wh.gov\/p7CXPw"
    } ]
  },
  "geo" : { },
  "id_str" : "788855649631219712",
  "text" : "\"To the enduring alliance between the United States &amp; Italy\" \u2014@POTUS at his last State Dinner. See the highlights: https:\/\/t.co\/c2owH6D7EI https:\/\/t.co\/j96JWNA3Nu",
  "id" : 788855649631219712,
  "created_at" : "2016-10-19 21:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788841896386801664",
  "text" : "RT @SecBurwell: It\u2019s important to look back at the progress we\u2019ve made improving access, quality, and affordability under the #ACA. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecBurwell\/status\/788820119279407106\/video\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/vwdCu1YcO0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvJzEsmW8AAoq15.jpg",
        "id_str" : "788798144150593536",
        "id" : 788798144150593536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvJzEsmW8AAoq15.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/vwdCu1YcO0"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 110, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788820119279407106",
    "text" : "It\u2019s important to look back at the progress we\u2019ve made improving access, quality, and affordability under the #ACA. https:\/\/t.co\/vwdCu1YcO0",
    "id" : 788820119279407106,
    "created_at" : "2016-10-19 19:12:26 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 788841896386801664,
  "created_at" : "2016-10-19 20:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788794047288586244",
  "text" : "RT @SecBurwell: Today, 20M more Americans have coverage thanks to the #ACA. Our uninsured rate is the lowest in our nation\u2019s history. Lowes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 54, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788755666857029632",
    "text" : "Today, 20M more Americans have coverage thanks to the #ACA. Our uninsured rate is the lowest in our nation\u2019s history. Lowest. In. History.",
    "id" : 788755666857029632,
    "created_at" : "2016-10-19 14:56:20 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 788794047288586244,
  "created_at" : "2016-10-19 17:28:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 113, 120 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788787166549651457",
  "text" : "RT @NSC44: In today's interconnected world, countering violent extremism requires action online. Learn more from @DHSgov: https:\/\/t.co\/XUZj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 102, 109 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/788755335855079424\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/WVrB9RSRNF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvI3MNwUkAASvIR.jpg",
        "id_str" : "788753567733551104",
        "id" : 788753567733551104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvI3MNwUkAASvIR.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/WVrB9RSRNF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/XUZjdDcfHy",
        "expanded_url" : "https:\/\/www.dhs.gov\/blog\/2016\/10\/19\/updating-our-plan-counter-violent-extremism-home",
        "display_url" : "dhs.gov\/blog\/2016\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788755335855079424",
    "text" : "In today's interconnected world, countering violent extremism requires action online. Learn more from @DHSgov: https:\/\/t.co\/XUZjdDcfHy https:\/\/t.co\/WVrB9RSRNF",
    "id" : 788755335855079424,
    "created_at" : "2016-10-19 14:55:01 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 788787166549651457,
  "created_at" : "2016-10-19 17:01:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 76, 82 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/E04lO52kAl",
      "expanded_url" : "https:\/\/twitter.com\/FlyerTalk\/status\/788780372054069248",
      "display_url" : "twitter.com\/FlyerTalk\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788783329780695042",
  "text" : "Got questions on the steps @POTUS is taking to improve airline travel? Join @USDOT for a Q&amp;A starting 1:00 PM ET. https:\/\/t.co\/E04lO52kAl",
  "id" : 788783329780695042,
  "created_at" : "2016-10-19 16:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788780330966667264",
  "text" : "RT @JFriedman44: \u2713 Delayed baggage refunds\n\u2713 Better protections for travelers with disabilities\n\u2713 Transparency on tickets\nRead more: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JFriedman44\/status\/788778877178949636\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/V2Gl2sMTtU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvJOLxmVYAA_3_-.jpg",
        "id_str" : "788778848942907392",
        "id" : 788778848942907392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvJOLxmVYAA_3_-.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/V2Gl2sMTtU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/9eOZdOLfU3",
        "expanded_url" : "http:\/\/go.wh.gov\/1Nxmek",
        "display_url" : "go.wh.gov\/1Nxmek"
      } ]
    },
    "geo" : { },
    "id_str" : "788778877178949636",
    "text" : "\u2713 Delayed baggage refunds\n\u2713 Better protections for travelers with disabilities\n\u2713 Transparency on tickets\nRead more: https:\/\/t.co\/9eOZdOLfU3 https:\/\/t.co\/V2Gl2sMTtU",
    "id" : 788778877178949636,
    "created_at" : "2016-10-19 16:28:33 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 788780330966667264,
  "created_at" : "2016-10-19 16:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "indices" : [ 3, 18 ],
      "id_str" : "3755263512",
      "id" : 3755263512
    }, {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "indices" : [ 101, 116 ],
      "id_str" : "3755263512",
      "id" : 3755263512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788774639564533760",
  "text" : "RT @BetterMakeRoom: A bunch of celebrities got together and they\u2019d like to say something in honor of @BetterMakeRoom\u2019s FIRST Anniversary. \uD83C\uDF89\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Better Make Room",
        "screen_name" : "BetterMakeRoom",
        "indices" : [ 81, 96 ],
        "id_str" : "3755263512",
        "id" : 3755263512
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BetterMakeRoom\/status\/788761639667445760\/video\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/viSKVWcWa8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvKiOs0XEAEphF4.jpg",
        "id_str" : "788759687894147073",
        "id" : 788759687894147073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvKiOs0XEAEphF4.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/viSKVWcWa8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788761639667445760",
    "text" : "A bunch of celebrities got together and they\u2019d like to say something in honor of @BetterMakeRoom\u2019s FIRST Anniversary. \uD83C\uDF89 https:\/\/t.co\/viSKVWcWa8",
    "id" : 788761639667445760,
    "created_at" : "2016-10-19 15:20:04 +0000",
    "user" : {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "protected" : false,
      "id_str" : "3755263512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654436849671213056\/ozIogTsC_normal.png",
      "id" : 3755263512,
      "verified" : false
    }
  },
  "id" : 788774639564533760,
  "created_at" : "2016-10-19 16:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788771747856314373",
  "text" : "RT @NSC44: Strong &amp; resilient local communities are the most effective means of safeguarding the US against violent extremist recruitment.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/788761629739536385\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/BFKp09Zk6N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvI3nLiUAAA1pPH.jpg",
        "id_str" : "788754030994391040",
        "id" : 788754030994391040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvI3nLiUAAA1pPH.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/BFKp09Zk6N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788761629739536385",
    "text" : "Strong &amp; resilient local communities are the most effective means of safeguarding the US against violent extremist recruitment. https:\/\/t.co\/BFKp09Zk6N",
    "id" : 788761629739536385,
    "created_at" : "2016-10-19 15:20:01 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 788771747856314373,
  "created_at" : "2016-10-19 16:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/788766328500867073\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/ftZJ7zjE3U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvJCj6FVYAAoHQY.jpg",
      "id_str" : "788766069397741568",
      "id" : 788766069397741568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvJCj6FVYAAoHQY.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 367
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 370
      } ],
      "display_url" : "pic.twitter.com\/ftZJ7zjE3U"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/zY4rRHKJHy",
      "expanded_url" : "http:\/\/go.wh.gov\/1Nxmek",
      "display_url" : "go.wh.gov\/1Nxmek"
    } ]
  },
  "geo" : { },
  "id_str" : "788766328500867073",
  "text" : "\"When American families and workers fly, they deserve to know exactly what they\u2019re buying\u201D \u2014@POTUS: https:\/\/t.co\/zY4rRHKJHy https:\/\/t.co\/ftZJ7zjE3U",
  "id" : 788766328500867073,
  "created_at" : "2016-10-19 15:38:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788758729227317253",
  "text" : "RT @Goldman44: Love this #SXSL recap from the Shepaug Video Club, creators of one of the Official Selections from the Film Fest! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 10, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/RMmh7OKAya",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ISjZR0f3Kl8",
        "display_url" : "youtube.com\/watch?v=ISjZR0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788758304948310016",
    "text" : "Love this #SXSL recap from the Shepaug Video Club, creators of one of the Official Selections from the Film Fest! https:\/\/t.co\/RMmh7OKAya",
    "id" : 788758304948310016,
    "created_at" : "2016-10-19 15:06:48 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 788758729227317253,
  "created_at" : "2016-10-19 15:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788755653313437696\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/vTXazU8Koz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvI43SpUMAAAURs.jpg",
      "id_str" : "788755407292346368",
      "id" : 788755407292346368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvI43SpUMAAAURs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/vTXazU8Koz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zY4rRHKJHy",
      "expanded_url" : "http:\/\/go.wh.gov\/1Nxmek",
      "display_url" : "go.wh.gov\/1Nxmek"
    } ]
  },
  "geo" : { },
  "id_str" : "788755653313437696",
  "text" : ".@POTUS is making the airline market fairer and more transparent than ever before. Read why he's taking these steps: https:\/\/t.co\/zY4rRHKJHy https:\/\/t.co\/vTXazU8Koz",
  "id" : 788755653313437696,
  "created_at" : "2016-10-19 14:56:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Italy in US",
      "screen_name" : "ItalyinUS",
      "indices" : [ 3, 13 ],
      "id_str" : "887055386",
      "id" : 887055386
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 103, 115 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Italy",
      "indices" : [ 64, 70 ]
    }, {
      "text" : "ItalyState",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788562420084117504",
  "text" : "RT @ItalyinUS: \uD83C\uDDEE\uD83C\uDDF9\uD83C\uDDFA\uD83C\uDDF8 @POTUS toasts the enduring alliance between #Italy and the US at state dinner with @matteorenzi #ItalyState #BehindTheS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Matteo Renzi",
        "screen_name" : "matteorenzi",
        "indices" : [ 88, 100 ],
        "id_str" : "18762875",
        "id" : 18762875
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItalyinUS\/status\/788557203213025280\/video\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/1pYLWxKOly",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/788557086879784960\/pu\/img\/Jay7aNVivZv4wT1d.jpg",
        "id_str" : "788557086879784960",
        "id" : 788557086879784960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/788557086879784960\/pu\/img\/Jay7aNVivZv4wT1d.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1pYLWxKOly"
      } ],
      "hashtags" : [ {
        "text" : "Italy",
        "indices" : [ 49, 55 ]
      }, {
        "text" : "ItalyState",
        "indices" : [ 101, 112 ]
      }, {
        "text" : "BehindTheScenes",
        "indices" : [ 113, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788557203213025280",
    "text" : "\uD83C\uDDEE\uD83C\uDDF9\uD83C\uDDFA\uD83C\uDDF8 @POTUS toasts the enduring alliance between #Italy and the US at state dinner with @matteorenzi #ItalyState #BehindTheScenes https:\/\/t.co\/1pYLWxKOly",
    "id" : 788557203213025280,
    "created_at" : "2016-10-19 01:47:42 +0000",
    "user" : {
      "name" : "Italy in US",
      "screen_name" : "ItalyinUS",
      "protected" : false,
      "id_str" : "887055386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710898019286159362\/Rf3bpNPu_normal.jpg",
      "id" : 887055386,
      "verified" : true
    }
  },
  "id" : 788562420084117504,
  "created_at" : "2016-10-19 02:08:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Batali",
      "screen_name" : "Mariobatali",
      "indices" : [ 5, 17 ],
      "id_str" : "148496087",
      "id" : 148496087
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788551648125652992\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/RziKQNkAxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvF_cxCVMAAyU6_.jpg",
      "id_str" : "788551541942726656",
      "id" : 788551541942726656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvF_cxCVMAAyU6_.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 977
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1668
      }, {
        "h" : 2702,
        "resize" : "fit",
        "w" : 2200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 554
      } ],
      "display_url" : "pic.twitter.com\/RziKQNkAxj"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788551648125652992\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/RziKQNkAxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvF_fGUVYAA44TW.jpg",
      "id_str" : "788551582015119360",
      "id" : 788551582015119360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvF_fGUVYAA44TW.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 503
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1516
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 888
      }, {
        "h" : 2723,
        "resize" : "fit",
        "w" : 2016
      } ],
      "display_url" : "pic.twitter.com\/RziKQNkAxj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788551648125652992",
  "text" : "Chef @MarioBatali is here for the final State Dinner. On the menu: dishes like sweet potato agnolotti and beef braciole pinwheel. Mangia! https:\/\/t.co\/RziKQNkAxj",
  "id" : 788551648125652992,
  "created_at" : "2016-10-19 01:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 64, 73 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateVisit",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/b0iCmjvhZ8",
      "expanded_url" : "http:\/\/snpy.tv\/2ejnw8z",
      "display_url" : "snpy.tv\/2ejnw8z"
    } ]
  },
  "geo" : { },
  "id_str" : "788532832008146944",
  "text" : "Go behind the scenes of the entire Italy #StateVisit with us on @Snapchat. Add \u2018whitehouse\u2019 to follow along: https:\/\/t.co\/b0iCmjvhZ8",
  "id" : 788532832008146944,
  "created_at" : "2016-10-19 00:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Italy in US",
      "screen_name" : "ItalyinUS",
      "indices" : [ 3, 13 ],
      "id_str" : "887055386",
      "id" : 887055386
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 31, 38 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 80, 91 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItalyState",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788530466739617792",
  "text" : "RT @ItalyinUS: \uD83C\uDDEE\uD83C\uDDF9\uD83C\uDDFA\uD83C\uDDF8 @POTUS and @FLOTUS with Prime Minister and Mrs Renzi at the @WhiteHouse for the State Dinner #ItalyState #BehindTheScen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 16, 23 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 65, 76 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItalyinUS\/status\/788528549548462080\/video\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/IOaTv1GNwa",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/788528377569353732\/pu\/img\/4sRY_WqNgBLPxBfT.jpg",
        "id_str" : "788528377569353732",
        "id" : 788528377569353732,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/788528377569353732\/pu\/img\/4sRY_WqNgBLPxBfT.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IOaTv1GNwa"
      } ],
      "hashtags" : [ {
        "text" : "ItalyState",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "BehindTheScenes",
        "indices" : [ 110, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788528549548462080",
    "text" : "\uD83C\uDDEE\uD83C\uDDF9\uD83C\uDDFA\uD83C\uDDF8 @POTUS and @FLOTUS with Prime Minister and Mrs Renzi at the @WhiteHouse for the State Dinner #ItalyState #BehindTheScenes https:\/\/t.co\/IOaTv1GNwa",
    "id" : 788528549548462080,
    "created_at" : "2016-10-18 23:53:51 +0000",
    "user" : {
      "name" : "Italy in US",
      "screen_name" : "ItalyinUS",
      "protected" : false,
      "id_str" : "887055386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710898019286159362\/Rf3bpNPu_normal.jpg",
      "id" : 887055386,
      "verified" : true
    }
  },
  "id" : 788530466739617792,
  "created_at" : "2016-10-19 00:01:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 12, 19 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 37, 49 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QcmYNPgjxM",
      "expanded_url" : "http:\/\/snpy.tv\/2ejd7tk",
      "display_url" : "snpy.tv\/2ejd7tk"
    } ]
  },
  "geo" : { },
  "id_str" : "788523079970525184",
  "text" : ".@POTUS and @FLOTUS just welcomed PM @matteorenzi &amp; Mrs. Agnese Landini to their final State Dinner. Buona sera! https:\/\/t.co\/QcmYNPgjxM",
  "id" : 788523079970525184,
  "created_at" : "2016-10-18 23:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 56, 68 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/rpvwjnY6qq",
      "expanded_url" : "http:\/\/go.wh.gov\/sz9tWD",
      "display_url" : "go.wh.gov\/sz9tWD"
    } ]
  },
  "geo" : { },
  "id_str" : "788504690304491520",
  "text" : "Tune in at 6:45pm ET as @POTUS &amp; @FLOTUS welcome PM @MatteoRenzi &amp; Mrs. Agnese Landini to their final State Dinner: https:\/\/t.co\/rpvwjnY6qq",
  "id" : 788504690304491520,
  "created_at" : "2016-10-18 22:19:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 103, 115 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788492161272602624\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mGilbFKh3s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvFG1uRXYAAchgI.jpg",
      "id_str" : "788489298534424576",
      "id" : 788489298534424576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvFG1uRXYAAchgI.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mGilbFKh3s"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788492161272602624\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mGilbFKh3s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvFG1t2WYAEDDA9.jpg",
      "id_str" : "788489298421112833",
      "id" : 788489298421112833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvFG1t2WYAEDDA9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1167,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1167,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/mGilbFKh3s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788492161272602624",
  "text" : "\"The American people could not ask for a better friend and ally than Italy.\" \u2014@POTUS to Prime Minister @MatteoRenzi https:\/\/t.co\/mGilbFKh3s",
  "id" : 788492161272602624,
  "created_at" : "2016-10-18 21:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788481797063528448\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/DQYHXQEIVs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvE_kbVUEAAt7gz.jpg",
      "id_str" : "788481304811540480",
      "id" : 788481304811540480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvE_kbVUEAAt7gz.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DQYHXQEIVs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/IHmH7sOvI0",
      "expanded_url" : "http:\/\/go.wh.gov\/XvNAfR",
      "display_url" : "go.wh.gov\/XvNAfR"
    } ]
  },
  "geo" : { },
  "id_str" : "788481797063528448",
  "text" : "Getting ready for @POTUS's final State Dinner. Go behind the scenes to see our favorite moments from past visits: https:\/\/t.co\/IHmH7sOvI0 https:\/\/t.co\/DQYHXQEIVs",
  "id" : 788481797063528448,
  "created_at" : "2016-10-18 20:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 55, 62 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 94, 105 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788470992087552001",
  "text" : "RT @letsmove: Today, as part of the Italy State Visit, @FLOTUS showed Mrs. Agnese Landini the @WhiteHouse Kitchen Garden https:\/\/t.co\/AjrpN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 41, 48 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 80, 91 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/788467446915162112\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/AjrpNmeaLV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEy8YEW8AA_szd.jpg",
        "id_str" : "788467422600818688",
        "id" : 788467422600818688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEy8YEW8AA_szd.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/AjrpNmeaLV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788467446915162112",
    "text" : "Today, as part of the Italy State Visit, @FLOTUS showed Mrs. Agnese Landini the @WhiteHouse Kitchen Garden https:\/\/t.co\/AjrpNmeaLV",
    "id" : 788467446915162112,
    "created_at" : "2016-10-18 19:51:03 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 788470992087552001,
  "created_at" : "2016-10-18 20:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 60, 67 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788460385833660416\/photo\/1",
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/yvKsGHCBjF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEsP-HUEAAfC5z.jpg",
      "id_str" : "788460062649880576",
      "id" : 788460062649880576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEsP-HUEAAfC5z.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/yvKsGHCBjF"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788460385833660416\/photo\/1",
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/yvKsGHCBjF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEsP9wVYAAkp4l.jpg",
      "id_str" : "788460062553497600",
      "id" : 788460062553497600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEsP9wVYAAkp4l.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/yvKsGHCBjF"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788460385833660416\/photo\/1",
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/yvKsGHCBjF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEsP_sUIAA-AAZ.jpg",
      "id_str" : "788460063073509376",
      "id" : 788460063073509376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEsP_sUIAA-AAZ.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/yvKsGHCBjF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/IHmH7sOvI0",
      "expanded_url" : "http:\/\/go.wh.gov\/XvNAfR",
      "display_url" : "go.wh.gov\/XvNAfR"
    } ]
  },
  "geo" : { },
  "id_str" : "788460385833660416",
  "text" : "Today marks the 14th and final State Visit for @POTUS &amp; @FLOTUS. See the highlights from the past 8 years: https:\/\/t.co\/IHmH7sOvI0 https:\/\/t.co\/yvKsGHCBjF",
  "id" : 788460385833660416,
  "created_at" : "2016-10-18 19:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/rFLDeuac3X",
      "expanded_url" : "https:\/\/twitter.com\/Mariobatali\/status\/788442254788747265",
      "display_url" : "twitter.com\/Mariobatali\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788453825141092353",
  "text" : "Thrilled to have you here with us, Chef Batali! https:\/\/t.co\/rFLDeuac3X",
  "id" : 788453825141092353,
  "created_at" : "2016-10-18 18:56:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 14, 21 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788431132261883904\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/e04wsEH77f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvERspQVUAEahmk.jpg",
      "id_str" : "788430868452823041",
      "id" : 788430868452823041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvERspQVUAEahmk.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/e04wsEH77f"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788431132261883904\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/e04wsEH77f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvERsnhVIAAjEaN.jpg",
      "id_str" : "788430867987243008",
      "id" : 788430867987243008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvERsnhVIAAjEaN.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/e04wsEH77f"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788431132261883904\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/e04wsEH77f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvERslxUAAAglK5.jpg",
      "id_str" : "788430867517407232",
      "id" : 788430867517407232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvERslxUAAAglK5.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 1333
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 1333
      } ],
      "display_url" : "pic.twitter.com\/e04wsEH77f"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788431132261883904\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/e04wsEH77f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvERsrmVMAAyy06.jpg",
      "id_str" : "788430869081960448",
      "id" : 788430869081960448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvERsrmVMAAyy06.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/e04wsEH77f"
    } ],
    "hashtags" : [ {
      "text" : "StateVisit",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IHmH7sOvI0",
      "expanded_url" : "http:\/\/go.wh.gov\/XvNAfR",
      "display_url" : "go.wh.gov\/XvNAfR"
    } ]
  },
  "geo" : { },
  "id_str" : "788431132261883904",
  "text" : "As @POTUS and @FLOTUS host their final #StateVisit, take a look back at the highlights from over the past 8 years: https:\/\/t.co\/IHmH7sOvI0 https:\/\/t.co\/e04wsEH77f",
  "id" : 788431132261883904,
  "created_at" : "2016-10-18 17:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8GpweWYRLb",
      "expanded_url" : "http:\/\/snpy.tv\/2dl3oow",
      "display_url" : "snpy.tv\/2dl3oow"
    } ]
  },
  "geo" : { },
  "id_str" : "788423398221242368",
  "text" : "\"We\u2019ve brought the #ParisAgreement on climate change into force\u201D \u2014@POTUS on working together with nations like Italy https:\/\/t.co\/8GpweWYRLb",
  "id" : 788423398221242368,
  "created_at" : "2016-10-18 16:56:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/8GpweWYRLb",
      "expanded_url" : "http:\/\/snpy.tv\/2dl3oow",
      "display_url" : "snpy.tv\/2dl3oow"
    } ]
  },
  "geo" : { },
  "id_str" : "788417805599158272",
  "text" : "\"That\u2019s a necessity for the United States and a necessity for the world.\" \u2014@POTUS on a strong and united Europe https:\/\/t.co\/8GpweWYRLb",
  "id" : 788417805599158272,
  "created_at" : "2016-10-18 16:33:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 47, 59 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/rpvwjnY6qq",
      "expanded_url" : "http:\/\/go.wh.gov\/sz9tWD",
      "display_url" : "go.wh.gov\/sz9tWD"
    } ]
  },
  "geo" : { },
  "id_str" : "788406000319549440",
  "text" : "Happening now: watch @POTUS and Prime Minister @matteorenzi of Italy speak on the partnership between our nations: https:\/\/t.co\/rpvwjnY6qq",
  "id" : 788406000319549440,
  "created_at" : "2016-10-18 15:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/pW9hTk8gbU",
      "expanded_url" : "http:\/\/snpy.tv\/2eMVuER",
      "display_url" : "snpy.tv\/2eMVuER"
    } ]
  },
  "geo" : { },
  "id_str" : "788395490719125504",
  "text" : "\"This marks the final official visit and state dinner of my presidency...we save the best for last\" \u2014@POTUS https:\/\/t.co\/pW9hTk8gbU",
  "id" : 788395490719125504,
  "created_at" : "2016-10-18 15:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 61, 73 ],
      "id_str" : "18762875",
      "id" : 18762875
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/pW9hTkpRAu",
      "expanded_url" : "http:\/\/snpy.tv\/2eMVuER",
      "display_url" : "snpy.tv\/2eMVuER"
    } ]
  },
  "geo" : { },
  "id_str" : "788376509312565248",
  "text" : "\"It is my great honor to welcome, from Italy, Prime Minister @matteorenzi and Mrs. Agnese Landini\" \u2014@POTUS https:\/\/t.co\/pW9hTkpRAu",
  "id" : 788376509312565248,
  "created_at" : "2016-10-18 13:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788372517215961088",
  "text" : "\"When Americans and Italians stand together, we can leave the world a little better than we found it.\" \u2014@POTUS on our friendship with Italy",
  "id" : 788372517215961088,
  "created_at" : "2016-10-18 13:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788372243638288384",
  "text" : "\"We are united not only by our interests, but also by our values...our commitment to the dignity of every human being\" \u2014@POTUS",
  "id" : 788372243638288384,
  "created_at" : "2016-10-18 13:32:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788371705970515969",
  "text" : "\"In the Italian American experience...we see a truth that we must never forget: America was built by immigrants\" \u2014@POTUS",
  "id" : 788371705970515969,
  "created_at" : "2016-10-18 13:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788371595601510400",
  "text" : "\"Because of Michelle, like every good Italian home, the White House now has a garden. With tomatoes. And garlic.\" \u2014@POTUS",
  "id" : 788371595601510400,
  "created_at" : "2016-10-18 13:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788371433298747392",
  "text" : "\"Nowhere does our love for Italy run deeper than among the millions of very proud Italian Americans.\" \u2014@POTUS",
  "id" : 788371433298747392,
  "created_at" : "2016-10-18 13:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788370876836286464",
  "text" : "\"As Americans and Italians, we are here because of each other.\" \u2014@POTUS on the historic bonds between our nations",
  "id" : 788370876836286464,
  "created_at" : "2016-10-18 13:27:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 128, 140 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788370738231275521",
  "text" : "\"This marks the final official visit and state dinner of my presidency...we save the best for last\" \u2014@POTUS welcomes Italian PM @MatteoRenzi",
  "id" : 788370738231275521,
  "created_at" : "2016-10-18 13:26:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 26, 33 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Matteo Renzi",
      "screen_name" : "matteorenzi",
      "indices" : [ 45, 57 ],
      "id_str" : "18762875",
      "id" : 18762875
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788361978351869952\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/I19Gp4HRNx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvDTBJIVYAAp71f.jpg",
      "id_str" : "788361951374041088",
      "id" : 788361951374041088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvDTBJIVYAAp71f.jpg",
      "sizes" : [ {
        "h" : 468,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/I19Gp4HRNx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rpvwjnGvyS",
      "expanded_url" : "http:\/\/go.wh.gov\/sz9tWD",
      "display_url" : "go.wh.gov\/sz9tWD"
    } ]
  },
  "geo" : { },
  "id_str" : "788361978351869952",
  "text" : "Happening now: @POTUS and @FLOTUS welcome PM @MatteoRenzi of Italy for their 14th and final State Arrival Ceremony \u2192 https:\/\/t.co\/rpvwjnGvyS https:\/\/t.co\/I19Gp4HRNx",
  "id" : 788361978351869952,
  "created_at" : "2016-10-18 12:51:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788160479759740928\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/bpRjAeIG0Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvAbfQ8UMAEMYaV.jpg",
      "id_str" : "788160158727680001",
      "id" : 788160158727680001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvAbfQ8UMAEMYaV.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/bpRjAeIG0Q"
    } ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fiG9HC84b9",
      "expanded_url" : "http:\/\/go.wh.gov\/52fsT6",
      "display_url" : "go.wh.gov\/52fsT6"
    } ]
  },
  "geo" : { },
  "id_str" : "788160479759740928",
  "text" : "Today, @VP Biden updated @POTUS on the progress of the #CancerMoonshot. Read how we can end cancer in our lifetime: https:\/\/t.co\/fiG9HC84b9 https:\/\/t.co\/bpRjAeIG0Q",
  "id" : 788160479759740928,
  "created_at" : "2016-10-17 23:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 55, 69 ],
      "id_str" : "16303106",
      "id" : 16303106
    }, {
      "name" : "The Late Show",
      "screen_name" : "colbertlateshow",
      "indices" : [ 77, 93 ],
      "id_str" : "2835886194",
      "id" : 2835886194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/liRKHLNhlT",
      "expanded_url" : "http:\/\/snpy.tv\/2dj1qFm",
      "display_url" : "snpy.tv\/2dj1qFm"
    } ]
  },
  "geo" : { },
  "id_str" : "788138980034306049",
  "text" : "Tune in tonight at 11:35pm ET to watch as @POTUS joins @StephenAtHome on the @ColbertLateShow: https:\/\/t.co\/liRKHLNhlT",
  "id" : 788138980034306049,
  "created_at" : "2016-10-17 22:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 21, 28 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788133487345709056",
  "text" : "RT @ErnestMoniz: The @Energy Dept. has some of the best supercomputers in the world. Now, they\u2019re joining the #CancerMoonshot. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 4, 11 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/788132460789768193\/video\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/qxJJ2jgLPz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Csf5Z5ZUMAAy-X0.jpg",
        "id_str" : "776863318363344897",
        "id" : 776863318363344897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csf5Z5ZUMAAy-X0.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/qxJJ2jgLPz"
      } ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 93, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/f89NtOm1P8",
        "expanded_url" : "https:\/\/medium.com\/cancer-moonshot\/supercomputers-join-the-fight-against-cancer-724fcc9910ce#.54vm8qvd5",
        "display_url" : "medium.com\/cancer-moonsho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788132460789768193",
    "text" : "The @Energy Dept. has some of the best supercomputers in the world. Now, they\u2019re joining the #CancerMoonshot. https:\/\/t.co\/f89NtOm1P8 https:\/\/t.co\/qxJJ2jgLPz",
    "id" : 788132460789768193,
    "created_at" : "2016-10-17 21:39:56 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 788133487345709056,
  "created_at" : "2016-10-17 21:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/788117079144566784\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/Kz3W5tCkJo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu_0E3PUMAAjm3k.jpg",
      "id_str" : "788116824197967872",
      "id" : 788116824197967872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu_0E3PUMAAjm3k.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Kz3W5tCkJo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788117079144566784",
  "text" : "\"Bottom line is: higher graduation rates, higher college attendance rates, more money for Pell Grants\" \u2014@POTUS on our progress on education. https:\/\/t.co\/Kz3W5tCkJo",
  "id" : 788117079144566784,
  "created_at" : "2016-10-17 20:38:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788100261877125120",
  "text" : "RT @POTUS: For the loved ones we've lost and the ones we can still save, thank you Joe for putting us on the path to ending cancer as we kn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/O0twPYcRSc",
        "expanded_url" : "https:\/\/twitter.com\/vp\/status\/788097252522721280",
        "display_url" : "twitter.com\/vp\/status\/7880\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788098889140219904",
    "text" : "For the loved ones we've lost and the ones we can still save, thank you Joe for putting us on the path to ending cancer as we know it. https:\/\/t.co\/O0twPYcRSc",
    "id" : 788098889140219904,
    "created_at" : "2016-10-17 19:26:31 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 788100261877125120,
  "created_at" : "2016-10-17 19:31:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 12, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788097845601546240",
  "text" : "RT @VP: The #CancerMoonshot carries the hopes &amp; dreams of millions praying we succeed. Read the report I just handed @POTUS: https:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 113, 119 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 4, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/m3r4rw4aG3",
        "expanded_url" : "http:\/\/medium.com\/cancer-moonshot",
        "display_url" : "medium.com\/cancer-moonshot"
      } ]
    },
    "geo" : { },
    "id_str" : "788097252522721280",
    "text" : "The #CancerMoonshot carries the hopes &amp; dreams of millions praying we succeed. Read the report I just handed @POTUS: https:\/\/t.co\/m3r4rw4aG3",
    "id" : 788097252522721280,
    "created_at" : "2016-10-17 19:20:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 788097845601546240,
  "created_at" : "2016-10-17 19:22:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/NNYinjCrNJ",
      "expanded_url" : "http:\/\/wh.gov\/CancerMoonshot",
      "display_url" : "wh.gov\/CancerMoonshot"
    } ]
  },
  "geo" : { },
  "id_str" : "788082806844903424",
  "text" : "RT @VPLive: The @VP\u2019s getting ready for his remarks on how we\u2019re fighting cancer: https:\/\/t.co\/NNYinjCrNJ\nGot Qs? Ask by 5:30pm ET using #C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 4, 7 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/788078919450701824\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/QoNbSw1eT3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu_Rav9WYAE_Mas.jpg",
        "id_str" : "788078717293715457",
        "id" : 788078717293715457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu_Rav9WYAE_Mas.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/QoNbSw1eT3"
      } ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/NNYinjCrNJ",
        "expanded_url" : "http:\/\/wh.gov\/CancerMoonshot",
        "display_url" : "wh.gov\/CancerMoonshot"
      } ]
    },
    "geo" : { },
    "id_str" : "788078919450701824",
    "text" : "The @VP\u2019s getting ready for his remarks on how we\u2019re fighting cancer: https:\/\/t.co\/NNYinjCrNJ\nGot Qs? Ask by 5:30pm ET using #CancerMoonshot https:\/\/t.co\/QoNbSw1eT3",
    "id" : 788078919450701824,
    "created_at" : "2016-10-17 18:07:10 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 788082806844903424,
  "created_at" : "2016-10-17 18:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788076586616496128",
  "text" : "RT @arneduncan: Access to preK- UP\nHS grad rates- UP\nAccess to Pell grants- UP\n@POTUS has transformed the life chances of children. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 63, 69 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arneduncan\/status\/788065877585526789\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/K1nrddsnX7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu_FvRoWcAAVjEZ.jpg",
        "id_str" : "788065875790295040",
        "id" : 788065875790295040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu_FvRoWcAAVjEZ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/K1nrddsnX7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788065877585526789",
    "text" : "Access to preK- UP\nHS grad rates- UP\nAccess to Pell grants- UP\n@POTUS has transformed the life chances of children. https:\/\/t.co\/K1nrddsnX7",
    "id" : 788065877585526789,
    "created_at" : "2016-10-17 17:15:21 +0000",
    "user" : {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "protected" : false,
      "id_str" : "4662969794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682923684063870977\/Cnr0_5cg_normal.jpg",
      "id" : 4662969794,
      "verified" : true
    }
  },
  "id" : 788076586616496128,
  "created_at" : "2016-10-17 17:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "indices" : [ 3, 16 ],
      "id_str" : "44873497",
      "id" : 44873497
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gradrates",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788072915585474560",
  "text" : "RT @JohnKingatED: Great news from @POTUS today! HS #gradrates are at an all-time high and more AfAm and Latino students are graduating than\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKingatED\/status\/788062366890135552\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/gx5BJ39nhh",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cu_CU9FWIAAtWh-.jpg",
        "id_str" : "788062125063282688",
        "id" : 788062125063282688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cu_CU9FWIAAtWh-.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gx5BJ39nhh"
      } ],
      "hashtags" : [ {
        "text" : "gradrates",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788062366890135552",
    "text" : "Great news from @POTUS today! HS #gradrates are at an all-time high and more AfAm and Latino students are graduating than ever before. https:\/\/t.co\/gx5BJ39nhh",
    "id" : 788062366890135552,
    "created_at" : "2016-10-17 17:01:24 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 788072915585474560,
  "created_at" : "2016-10-17 17:43:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 3, 15 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788069526181060608",
  "text" : "RT @ReachHigher: Listen to @POTUS: your education can't stop at high school &amp; the college scorecard can help you pick a great fit https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1RfoHPaZRx",
        "expanded_url" : "http:\/\/snpy.tv\/2egBsUp",
        "display_url" : "snpy.tv\/2egBsUp"
      } ]
    },
    "geo" : { },
    "id_str" : "788063016604409856",
    "text" : "Listen to @POTUS: your education can't stop at high school &amp; the college scorecard can help you pick a great fit https:\/\/t.co\/1RfoHPaZRx",
    "id" : 788063016604409856,
    "created_at" : "2016-10-17 17:03:59 +0000",
    "user" : {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "protected" : false,
      "id_str" : "2461821548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508240407688663040\/El8GILjl_normal.jpeg",
      "id" : 2461821548,
      "verified" : true
    }
  },
  "id" : 788069526181060608,
  "created_at" : "2016-10-17 17:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 41, 44 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788053872673591296",
  "text" : "RT @VPLive: RT to show your support: The @VP just released his report on the #CancerMoonshot. Check out the work we\u2019re doing: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 29, 32 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/788052513723408384\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/ezAbKvlCJJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-5hbuVIAAZKyl.jpg",
        "id_str" : "788052443842027520",
        "id" : 788052443842027520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-5hbuVIAAZKyl.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ezAbKvlCJJ"
      } ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/AWpGAszX7w",
        "expanded_url" : "http:\/\/medium.com\/cancer-moonshot",
        "display_url" : "medium.com\/cancer-moonshot"
      } ]
    },
    "geo" : { },
    "id_str" : "788052513723408384",
    "text" : "RT to show your support: The @VP just released his report on the #CancerMoonshot. Check out the work we\u2019re doing: https:\/\/t.co\/AWpGAszX7w https:\/\/t.co\/ezAbKvlCJJ",
    "id" : 788052513723408384,
    "created_at" : "2016-10-17 16:22:15 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 788053872673591296,
  "created_at" : "2016-10-17 16:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "indices" : [ 3, 18 ],
      "id_str" : "3755263512",
      "id" : 3755263512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788047472962641921",
  "text" : "RT @BetterMakeRoom: A degree past HS is essential in today's world.\n-2 year degree = $300k over your lifetime \uD83C\uDF93\n-4 year degree = $1 million\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788041215501565952",
    "text" : "A degree past HS is essential in today's world.\n-2 year degree = $300k over your lifetime \uD83C\uDF93\n-4 year degree = $1 million over your lifetime \uD83C\uDF93",
    "id" : 788041215501565952,
    "created_at" : "2016-10-17 15:37:21 +0000",
    "user" : {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "protected" : false,
      "id_str" : "3755263512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654436849671213056\/ozIogTsC_normal.png",
      "id" : 3755263512,
      "verified" : false
    }
  },
  "id" : 788047472962641921,
  "created_at" : "2016-10-17 16:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 36, 42 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/gfWDBtQX1L",
      "expanded_url" : "http:\/\/FAFSA.gov",
      "display_url" : "FAFSA.gov"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/RyYkOr8EF8",
      "expanded_url" : "http:\/\/snpy.tv\/2eeRUA7",
      "display_url" : "snpy.tv\/2eeRUA7"
    } ]
  },
  "geo" : { },
  "id_str" : "788046030394851328",
  "text" : "Students and parents: Fill out your @FAFSA today at https:\/\/t.co\/gfWDBtQX1L to access free money for college.\nhttps:\/\/t.co\/RyYkOr8EF8",
  "id" : 788046030394851328,
  "created_at" : "2016-10-17 15:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788043685459927040",
  "text" : "RT @FLOTUS: More students today are walking across a HS graduation stage. The progress is inspiring. Keep reaching higher for that college\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/788037157461962752\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/3xMFhNSA6z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-rRXgVMAAEndr.jpg",
        "id_str" : "788036774668873728",
        "id" : 788036774668873728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-rRXgVMAAEndr.jpg",
        "sizes" : [ {
          "h" : 1884,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 1378,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 807,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/3xMFhNSA6z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788037157461962752",
    "text" : "More students today are walking across a HS graduation stage. The progress is inspiring. Keep reaching higher for that college degree! -mo https:\/\/t.co\/3xMFhNSA6z",
    "id" : 788037157461962752,
    "created_at" : "2016-10-17 15:21:14 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 788043685459927040,
  "created_at" : "2016-10-17 15:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788042624858923009\/photo\/1",
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/quqpi9t6YL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-wiGzUIAAu-8Z.jpg",
      "id_str" : "788042559801008128",
      "id" : 788042559801008128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-wiGzUIAAu-8Z.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/quqpi9t6YL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788042624858923009",
  "text" : "\"We all have a part to play in making sure every single child has every single opportunity to achieve his or her dreams.\" \u2014@POTUS https:\/\/t.co\/quqpi9t6YL",
  "id" : 788042624858923009,
  "created_at" : "2016-10-17 15:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/788042007541264385\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/VhdDVIJg43",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-vzDyUAAAkeDW.jpg",
      "id_str" : "788041751537647616",
      "id" : 788041751537647616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-vzDyUAAAkeDW.jpg",
      "sizes" : [ {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/VhdDVIJg43"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/4YohVv7Qea",
      "expanded_url" : "http:\/\/go.wh.gov\/1NuNrf",
      "display_url" : "go.wh.gov\/1NuNrf"
    } ]
  },
  "geo" : { },
  "id_str" : "788042007541264385",
  "text" : "\"Nobody should be priced out of a higher education.\" \u2014@POTUS on the progress we've made: https:\/\/t.co\/4YohVv7Qea https:\/\/t.co\/VhdDVIJg43",
  "id" : 788042007541264385,
  "created_at" : "2016-10-17 15:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788041484901548032\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/r65ldBH3Tt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-vdE5UIAAf5DA.jpg",
      "id_str" : "788041373878329344",
      "id" : 788041373878329344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-vdE5UIAAf5DA.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/r65ldBH3Tt"
    } ],
    "hashtags" : [ {
      "text" : "FAFSA",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/gfWDBu8xTj",
      "expanded_url" : "http:\/\/FAFSA.gov",
      "display_url" : "FAFSA.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "788041484901548032",
  "text" : "\"Fill out the #FAFSA, the Free Application for Federal Student Aid.\" \u2014@POTUS. Get started at https:\/\/t.co\/gfWDBu8xTj https:\/\/t.co\/r65ldBH3Tt",
  "id" : 788041484901548032,
  "created_at" : "2016-10-17 15:38:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/788040338468245504\/photo\/1",
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/3BL457N9o0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-ue26XYAAAVp-.jpg",
      "id_str" : "788040304972750848",
      "id" : 788040304972750848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-ue26XYAAAVp-.jpg",
      "sizes" : [ {
        "h" : 243,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 516
      } ],
      "display_url" : "pic.twitter.com\/3BL457N9o0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788040338468245504",
  "text" : "\"Teachers deserve more than our gratitude, they deserve our full support\" \u2014@POTUS at Banneker Academic High School in D.C. https:\/\/t.co\/3BL457N9o0",
  "id" : 788040338468245504,
  "created_at" : "2016-10-17 15:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788039636157280256",
  "text" : "\"High-quality early education is one of the best investments we can make...we\u2019ve added over 60,000 children to Head Start\" \u2014@POTUS",
  "id" : 788039636157280256,
  "created_at" : "2016-10-17 15:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/4YohVv7Qea",
      "expanded_url" : "http:\/\/go.wh.gov\/1NuNrf",
      "display_url" : "go.wh.gov\/1NuNrf"
    } ]
  },
  "geo" : { },
  "id_str" : "788039251422085121",
  "text" : "\u201CMore African-American and Latino students are graduating than ever before.\u201D \u2014@POTUS on our progress: https:\/\/t.co\/4YohVv7Qea",
  "id" : 788039251422085121,
  "created_at" : "2016-10-17 15:29:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788038788433842176\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/WE219SK879",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cu-tEgsUIAAlpHP.jpg",
      "id_str" : "788038752820011008",
      "id" : 788038752820011008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cu-tEgsUIAAlpHP.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WE219SK879"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788038788433842176",
  "text" : "\u201CWe recently learned that America\u2019s high school graduation rate went up to 83 percent\u2026the highest on record.\u201D \u2014@POTUS https:\/\/t.co\/WE219SK879",
  "id" : 788038788433842176,
  "created_at" : "2016-10-17 15:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788037380884144128",
  "text" : "RT @WHLive: Watch as @POTUS speaks on the progress made to ensure every student has the opportunity to realize their potential: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ud6NM3BWwZ",
        "expanded_url" : "http:\/\/go.wh.gov\/1NuNrf",
        "display_url" : "go.wh.gov\/1NuNrf"
      } ]
    },
    "geo" : { },
    "id_str" : "788037304191373312",
    "text" : "Watch as @POTUS speaks on the progress made to ensure every student has the opportunity to realize their potential: https:\/\/t.co\/ud6NM3BWwZ",
    "id" : 788037304191373312,
    "created_at" : "2016-10-17 15:21:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 788037380884144128,
  "created_at" : "2016-10-17 15:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/788031587187167233\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/EINnpmzthY",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cu-l2emUMAAsPbo.jpg",
      "id_str" : "788030815158415360",
      "id" : 788030815158415360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cu-l2emUMAAsPbo.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EINnpmzthY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/4YohVv7Qea",
      "expanded_url" : "http:\/\/go.wh.gov\/1NuNrf",
      "display_url" : "go.wh.gov\/1NuNrf"
    } ]
  },
  "geo" : { },
  "id_str" : "788031587187167233",
  "text" : "Good news: America's high school graduation rate reached a new record high of 83%. \n\nTune in at 11:25am ET: https:\/\/t.co\/4YohVv7Qea https:\/\/t.co\/EINnpmzthY",
  "id" : 788031587187167233,
  "created_at" : "2016-10-17 14:59:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ICnVTcZIhx",
      "expanded_url" : "http:\/\/snpy.tv\/2dWV1yV",
      "display_url" : "snpy.tv\/2dWV1yV"
    } ]
  },
  "geo" : { },
  "id_str" : "787829452575240192",
  "text" : "Robotic fist-bump \u2713\nHelicopter drones \u2713\nReal life space capsules \u2713\n\nWatch @POTUS behind the scenes at #WHFrontiers: https:\/\/t.co\/ICnVTcZIhx",
  "id" : 787829452575240192,
  "created_at" : "2016-10-17 01:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/w5sH7TudIJ",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787722280906420224",
  "text" : "Jump-started clean energy revolution \u2713\nUnleashed precision medicine \u2713\n\n@POTUS on our progress over the past 8 years: https:\/\/t.co\/w5sH7TudIJ",
  "id" : 787722280906420224,
  "created_at" : "2016-10-16 18:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/w5sH7TLOAh",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787703403514179584",
  "text" : "In his first inaugural address, @POTUS vowed to return science to its rightful place. \n\nWe've come a long way. https:\/\/t.co\/w5sH7TLOAh",
  "id" : 787703403514179584,
  "created_at" : "2016-10-16 17:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/w5sH7TLOAh",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787686037803773953",
  "text" : "\"It's so backward when some folks choose to stick their heads in the sand about basic scientific facts.\" \u2014@POTUS https:\/\/t.co\/w5sH7TLOAh",
  "id" : 787686037803773953,
  "created_at" : "2016-10-16 16:06:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/w5sH7TLOAh",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787675719727915008",
  "text" : "With the right investments, and the brilliance and ingenuity of the American people, there's nothing we can't do. https:\/\/t.co\/w5sH7TLOAh",
  "id" : 787675719727915008,
  "created_at" : "2016-10-16 15:25:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/w5sH7TLOAh",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787666600891518976",
  "text" : "Over the past 8 years we\u2019ve launched moonshots for:\n\u2713Cancer\n\u2713Brain research\n\u2713Solar energy\n\n@POTUS on #WHFrontiers: https:\/\/t.co\/w5sH7TLOAh",
  "id" : 787666600891518976,
  "created_at" : "2016-10-16 14:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "100YearsStrong",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787662837074239488",
  "text" : "RT @POTUS: For a century, Planned Parenthood has made it possible for women to determine their own lives. Here's to another #100YearsStrong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "100YearsStrong",
        "indices" : [ 113, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787662124197830656",
    "text" : "For a century, Planned Parenthood has made it possible for women to determine their own lives. Here's to another #100YearsStrong.",
    "id" : 787662124197830656,
    "created_at" : "2016-10-16 14:30:59 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 787662837074239488,
  "created_at" : "2016-10-16 14:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787419045679206400",
  "text" : "RT @vj44: On Blind Americans Equality Day, &amp; everyday, let's work to ensure blind individuals face no barriers to success: https:\/\/t.co\/408\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/408n0YCljs",
        "expanded_url" : "http:\/\/go.wh.gov\/58zXEn",
        "display_url" : "go.wh.gov\/58zXEn"
      } ]
    },
    "in_reply_to_status_id_str" : "787401652949180417",
    "geo" : { },
    "id_str" : "787401938656718848",
    "in_reply_to_user_id" : 595515713,
    "text" : "On Blind Americans Equality Day, &amp; everyday, let's work to ensure blind individuals face no barriers to success: https:\/\/t.co\/408n0YCljs",
    "id" : 787401938656718848,
    "in_reply_to_status_id" : 787401652949180417,
    "created_at" : "2016-10-15 21:17:06 +0000",
    "in_reply_to_screen_name" : "vj44",
    "in_reply_to_user_id_str" : "595515713",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 787419045679206400,
  "created_at" : "2016-10-15 22:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787404916499312641",
  "text" : "RT @vj44: As we celebrate Blind Americans Equality Day, I want to shout out two unique innovators who are my heroes - Stevie Wonder &amp; @Habe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Haben Girma",
        "screen_name" : "HabenGirma",
        "indices" : [ 128, 139 ],
        "id_str" : "1703305712",
        "id" : 1703305712
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/787401652949180417\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/CYcwEAVgfU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu1pgVLXEAERyLF.jpg",
        "id_str" : "787401514021228545",
        "id" : 787401514021228545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu1pgVLXEAERyLF.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CYcwEAVgfU"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/787401652949180417\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/CYcwEAVgfU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu1pgVLW8AEQb_y.jpg",
        "id_str" : "787401514021220353",
        "id" : 787401514021220353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu1pgVLW8AEQb_y.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CYcwEAVgfU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787401652949180417",
    "text" : "As we celebrate Blind Americans Equality Day, I want to shout out two unique innovators who are my heroes - Stevie Wonder &amp; @HabenGirma https:\/\/t.co\/CYcwEAVgfU",
    "id" : 787401652949180417,
    "created_at" : "2016-10-15 21:15:57 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 787404916499312641,
  "created_at" : "2016-10-15 21:28:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787397970966618112",
  "text" : "RT @Deese44: HFCs phased out; 0.5 degrees of global warming avoided. Long road, but patient deliberate diplomacy pays off. https:\/\/t.co\/VUp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/VUpghfsLVQ",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/10\/15\/world\/africa\/kigali-deal-hfc-air-conditioners.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
        "display_url" : "nytimes.com\/2016\/10\/15\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787294957031653376",
    "text" : "HFCs phased out; 0.5 degrees of global warming avoided. Long road, but patient deliberate diplomacy pays off. https:\/\/t.co\/VUpghfsLVQ",
    "id" : 787294957031653376,
    "created_at" : "2016-10-15 14:11:59 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 787397970966618112,
  "created_at" : "2016-10-15 21:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/w5sH7TudIJ",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787346299309985793",
  "text" : "\"Only through science can we cure diseases, and save the only planet we've got\" \u2014@POTUS #WHFrontiers  https:\/\/t.co\/w5sH7TudIJ",
  "id" : 787346299309985793,
  "created_at" : "2016-10-15 17:36:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/w5sH7TudIJ",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787333469563224064",
  "text" : "Here's how investing in science and tech can help develop new industries and new discoveries that improve lives:  https:\/\/t.co\/w5sH7TudIJ",
  "id" : 787333469563224064,
  "created_at" : "2016-10-15 16:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/w5sH7TLOAh",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787325919836766209",
  "text" : ".@POTUS explains how we can be the nation that leads the world into the next frontier: https:\/\/t.co\/w5sH7TLOAh",
  "id" : 787325919836766209,
  "created_at" : "2016-10-15 16:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787321239836712960",
  "text" : "RT @FactsOnClimate: Good news: Today, nearly 200 countries reached a global deal to phase down HFCs and avoid up to 0.5\u00B0C of warming: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/787311800140333056\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/j4G1ORrIII",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu0X4dAUkAAUuXs.jpg",
        "id_str" : "787311768485793792",
        "id" : 787311768485793792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu0X4dAUkAAUuXs.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/j4G1ORrIII"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/hrIsABSneT",
        "expanded_url" : "http:\/\/go.wh.gov\/Mi4J6P",
        "display_url" : "go.wh.gov\/Mi4J6P"
      } ]
    },
    "geo" : { },
    "id_str" : "787311800140333056",
    "text" : "Good news: Today, nearly 200 countries reached a global deal to phase down HFCs and avoid up to 0.5\u00B0C of warming: https:\/\/t.co\/hrIsABSneT https:\/\/t.co\/j4G1ORrIII",
    "id" : 787311800140333056,
    "created_at" : "2016-10-15 15:18:55 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 787321239836712960,
  "created_at" : "2016-10-15 15:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/w5sH7TLOAh",
      "expanded_url" : "http:\/\/snpy.tv\/2dhW7kv",
      "display_url" : "snpy.tv\/2dhW7kv"
    } ]
  },
  "geo" : { },
  "id_str" : "787310816273969152",
  "text" : "\u201CInnovation is in our DNA. And today, we need it more than ever.\u201D \u2014@POTUS on #WHFrontiers: https:\/\/t.co\/w5sH7TLOAh",
  "id" : 787310816273969152,
  "created_at" : "2016-10-15 15:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/787280006871330820\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/f2wUyaLTt3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuz6nL7UkAA8HI-.jpg",
      "id_str" : "787279586006437888",
      "id" : 787279586006437888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuz6nL7UkAA8HI-.jpg",
      "sizes" : [ {
        "h" : 760,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 735
      } ],
      "display_url" : "pic.twitter.com\/f2wUyaLTt3"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/AbE72ztIeO",
      "expanded_url" : "http:\/\/go.wh.gov\/qnkYar",
      "display_url" : "go.wh.gov\/qnkYar"
    } ]
  },
  "geo" : { },
  "id_str" : "787280006871330820",
  "text" : "Today, nearly 200 countries took an historic step to #ActOnClimate for future generations by phasing down HFCs: https:\/\/t.co\/AbE72ztIeO https:\/\/t.co\/f2wUyaLTt3",
  "id" : 787280006871330820,
  "created_at" : "2016-10-15 13:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/787156255248965634\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/SvCFxLhDJA",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787156182062526464\/pu\/img\/6Hd48eM24O7L56i4.jpg",
      "id_str" : "787156182062526464",
      "id" : 787156182062526464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787156182062526464\/pu\/img\/6Hd48eM24O7L56i4.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SvCFxLhDJA"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787270864567988225",
  "text" : "RT @GinaEPA: We did it! With our kids future at stake, the world came together to phasedown HFCs and #ActOnClimate https:\/\/t.co\/SvCFxLhDJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/787156255248965634\/video\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/SvCFxLhDJA",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787156182062526464\/pu\/img\/6Hd48eM24O7L56i4.jpg",
        "id_str" : "787156182062526464",
        "id" : 787156182062526464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787156182062526464\/pu\/img\/6Hd48eM24O7L56i4.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SvCFxLhDJA"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787156255248965634",
    "text" : "We did it! With our kids future at stake, the world came together to phasedown HFCs and #ActOnClimate https:\/\/t.co\/SvCFxLhDJA",
    "id" : 787156255248965634,
    "created_at" : "2016-10-15 05:00:50 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 787270864567988225,
  "created_at" : "2016-10-15 12:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787109563799449600",
  "text" : "RT @NSC44: Today @POTUS convened his National Security Council to review progress in the campaign to degrade &amp; destroy ISIL: https:\/\/t.co\/4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/787083762655961089\/photo\/1",
        "indices" : [ 142, 165 ],
        "url" : "https:\/\/t.co\/WOcNN4UlDx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuxIKjgUMAAQ52K.jpg",
        "id_str" : "787083381049667584",
        "id" : 787083381049667584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuxIKjgUMAAQ52K.jpg",
        "sizes" : [ {
          "h" : 410,
          "resize" : "fit",
          "w" : 947
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 947
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 947
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/WOcNN4UlDx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/4c2Ez5ttsc",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/10\/14\/readout-presidents-national-security-council-meeting",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787083762655961089",
    "text" : "Today @POTUS convened his National Security Council to review progress in the campaign to degrade &amp; destroy ISIL: https:\/\/t.co\/4c2Ez5ttsc https:\/\/t.co\/WOcNN4UlDx",
    "id" : 787083762655961089,
    "created_at" : "2016-10-15 00:12:46 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 787109563799449600,
  "created_at" : "2016-10-15 01:55:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 76, 88 ]
    }, {
      "text" : "WestWingWeek",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/p32F4XqlhJ",
      "expanded_url" : "http:\/\/snpy.tv\/2ddbobm",
      "display_url" : "snpy.tv\/2ddbobm"
    } ]
  },
  "geo" : { },
  "id_str" : "787106857198374913",
  "text" : "\"Future astronaut! He's going to Mars!\" Go behind the scenes with @POTUS at #WHFrontiers in this #WestWingWeek: https:\/\/t.co\/p32F4XqlhJ",
  "id" : 787106857198374913,
  "created_at" : "2016-10-15 01:44:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/787035632145141760\/photo\/1",
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/e00dKnIiC0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuwbqVvUsAAn3ZH.jpg",
      "id_str" : "787034449087082496",
      "id" : 787034449087082496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuwbqVvUsAAn3ZH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/e00dKnIiC0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/UYE1rHrEFL",
      "expanded_url" : "http:\/\/go.wh.gov\/7VxYCP",
      "display_url" : "go.wh.gov\/7VxYCP"
    } ]
  },
  "geo" : { },
  "id_str" : "787035632145141760",
  "text" : "From solar to wind, renewable energy across the board has seen costs drop and deployment increase: https:\/\/t.co\/UYE1rHrEFL https:\/\/t.co\/e00dKnIiC0",
  "id" : 787035632145141760,
  "created_at" : "2016-10-14 21:01:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/i4z2dzoCpL",
      "expanded_url" : "http:\/\/go.wh.gov\/7VxYCP",
      "display_url" : "go.wh.gov\/7VxYCP"
    } ]
  },
  "geo" : { },
  "id_str" : "787031339400822784",
  "text" : "RT @FactsOnClimate: Since @POTUS took office, we've been leading by example in clean energy: https:\/\/t.co\/i4z2dzoCpL  #ActOnClimate https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/787030188148129796\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/aInGMIRF2y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuwXxWKUIAITJSC.jpg",
        "id_str" : "787030171412865026",
        "id" : 787030171412865026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuwXxWKUIAITJSC.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/aInGMIRF2y"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/i4z2dzoCpL",
        "expanded_url" : "http:\/\/go.wh.gov\/7VxYCP",
        "display_url" : "go.wh.gov\/7VxYCP"
      } ]
    },
    "geo" : { },
    "id_str" : "787030188148129796",
    "text" : "Since @POTUS took office, we've been leading by example in clean energy: https:\/\/t.co\/i4z2dzoCpL  #ActOnClimate https:\/\/t.co\/aInGMIRF2y",
    "id" : 787030188148129796,
    "created_at" : "2016-10-14 20:39:53 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 787031339400822784,
  "created_at" : "2016-10-14 20:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Technical.ly DC",
      "screen_name" : "TechnicallyDC",
      "indices" : [ 3, 17 ],
      "id_str" : "785459905",
      "id" : 785459905
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TechnicallyDC\/status\/786958596886106112\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/I0KiE5POsW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuvWrBbWgAEeTPa.jpg",
      "id_str" : "786958594512158721",
      "id" : 786958594512158721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuvWrBbWgAEeTPa.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/I0KiE5POsW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/LppfgNT0AT",
      "expanded_url" : "http:\/\/bit.ly\/2ee62sk",
      "display_url" : "bit.ly\/2ee62sk"
    } ]
  },
  "geo" : { },
  "id_str" : "787027692344320001",
  "text" : "RT @TechnicallyDC: The White House is open-sourcing that Facebook Messenger bot https:\/\/t.co\/LppfgNT0AT https:\/\/t.co\/I0KiE5POsW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TechnicallyDC\/status\/786958596886106112\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/I0KiE5POsW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuvWrBbWgAEeTPa.jpg",
        "id_str" : "786958594512158721",
        "id" : 786958594512158721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuvWrBbWgAEeTPa.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/I0KiE5POsW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/LppfgNT0AT",
        "expanded_url" : "http:\/\/bit.ly\/2ee62sk",
        "display_url" : "bit.ly\/2ee62sk"
      } ]
    },
    "geo" : { },
    "id_str" : "786958596886106112",
    "text" : "The White House is open-sourcing that Facebook Messenger bot https:\/\/t.co\/LppfgNT0AT https:\/\/t.co\/I0KiE5POsW",
    "id" : 786958596886106112,
    "created_at" : "2016-10-14 15:55:25 +0000",
    "user" : {
      "name" : "Technical.ly DC",
      "screen_name" : "TechnicallyDC",
      "protected" : false,
      "id_str" : "785459905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755821841998942208\/FWpSKJE2_normal.jpg",
      "id" : 785459905,
      "verified" : false
    }
  },
  "id" : 787027692344320001,
  "created_at" : "2016-10-14 20:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787024182441811970",
  "text" : "RT @NSC44: \"The embargo failed to achieve its stated purpose of overturning the Castro regime, while harming the Cuban people\"-@AmbassadorR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Rice",
        "screen_name" : "AmbassadorRice",
        "indices" : [ 116, 131 ],
        "id_str" : "19674502",
        "id" : 19674502
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/786962803319984137\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/it0MnOTpq0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuvaai4UAAAypXg.jpg",
        "id_str" : "786962709480734720",
        "id" : 786962709480734720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuvaai4UAAAypXg.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/it0MnOTpq0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786962803319984137",
    "text" : "\"The embargo failed to achieve its stated purpose of overturning the Castro regime, while harming the Cuban people\"-@AmbassadorRice. https:\/\/t.co\/it0MnOTpq0",
    "id" : 786962803319984137,
    "created_at" : "2016-10-14 16:12:08 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 787024182441811970,
  "created_at" : "2016-10-14 20:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786990920294031360\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/Li14GOMAf8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuvz3GfUkAAfGUZ.jpg",
      "id_str" : "786990687866621952",
      "id" : 786990687866621952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuvz3GfUkAAfGUZ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Li14GOMAf8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2khWEh27b2",
      "expanded_url" : "http:\/\/go.wh.gov\/Cuba",
      "display_url" : "go.wh.gov\/Cuba"
    } ]
  },
  "geo" : { },
  "id_str" : "786990920294031360",
  "text" : "Today @POTUS took another major step forward in our efforts to normalize relations with Cuba. What you need to know: https:\/\/t.co\/2khWEh27b2 https:\/\/t.co\/Li14GOMAf8",
  "id" : 786990920294031360,
  "created_at" : "2016-10-14 18:03:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 3, 13 ],
      "id_str" : "50393960",
      "id" : 50393960
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/XNN0pq68iQ",
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786657957052243968",
      "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786988756117037057",
  "text" : "RT @BillGates: .@POTUS, welcome to the club. https:\/\/t.co\/XNN0pq68iQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/XNN0pq68iQ",
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786657957052243968",
        "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786974048148258817",
    "text" : ".@POTUS, welcome to the club. https:\/\/t.co\/XNN0pq68iQ",
    "id" : 786974048148258817,
    "created_at" : "2016-10-14 16:56:49 +0000",
    "user" : {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "protected" : false,
      "id_str" : "50393960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558109954561679360\/j1f9DiJi_normal.jpeg",
      "id" : 50393960,
      "verified" : true
    }
  },
  "id" : 786988756117037057,
  "created_at" : "2016-10-14 17:55:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lin-Manuel Miranda",
      "screen_name" : "Lin_Manuel",
      "indices" : [ 31, 42 ],
      "id_str" : "79923701",
      "id" : 79923701
    }, {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "indices" : [ 63, 73 ],
      "id_str" : "14089195",
      "id" : 14089195
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 5, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/yxG9wNsejb",
      "expanded_url" : "http:\/\/p4k.in\/yFZUcGt",
      "display_url" : "p4k.in\/yFZUcGt"
    } ]
  },
  "geo" : { },
  "id_str" : "786984232782442496",
  "text" : "From #SXSL to freestyling with @Lin_Manuel in the Rose Garden, @Pitchfork recounts @POTUS's musical milestones: https:\/\/t.co\/yxG9wNsejb",
  "id" : 786984232782442496,
  "created_at" : "2016-10-14 17:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786975871416475652\/photo\/1",
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/rhKup89Mcr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuvmWY3UsAAg_Ix.jpg",
      "id_str" : "786975832212287488",
      "id" : 786975832212287488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuvmWY3UsAAg_Ix.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rhKup89Mcr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/lVlHaGKAeF",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnyT2",
      "display_url" : "go.wh.gov\/FGnyT2"
    } ]
  },
  "geo" : { },
  "id_str" : "786975871416475652",
  "text" : "1.5 million people have messaged us on Facebook. Now we\u2019re helping other governments do the same: https:\/\/t.co\/lVlHaGKAeF https:\/\/t.co\/rhKup89Mcr",
  "id" : 786975871416475652,
  "created_at" : "2016-10-14 17:04:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/yxG9wNsejb",
      "expanded_url" : "http:\/\/p4k.in\/yFZUcGt",
      "display_url" : "p4k.in\/yFZUcGt"
    } ]
  },
  "geo" : { },
  "id_str" : "786966704291061761",
  "text" : "Sings Al Green \u2714\nHosts #SXSL \u2714\nMakes summer mixtape \u2714\nDrops mic \uD83C\uDFA4  \n\nOn @POTUS's musical milestones: https:\/\/t.co\/yxG9wNsejb",
  "id" : 786966704291061761,
  "created_at" : "2016-10-14 16:27:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786954416339361792\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/iWzWWDQbPw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuvSxjZVMAA6rfH.jpg",
      "id_str" : "786954308663193600",
      "id" : 786954308663193600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuvSxjZVMAA6rfH.jpg",
      "sizes" : [ {
        "h" : 1575,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1575,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/iWzWWDQbPw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/2khWEh27b2",
      "expanded_url" : "http:\/\/go.wh.gov\/Cuba",
      "display_url" : "go.wh.gov\/Cuba"
    } ]
  },
  "geo" : { },
  "id_str" : "786954416339361792",
  "text" : "54 years after the Cuban Missile Crisis began, we are marking a new day in our relationship with Cuba. https:\/\/t.co\/2khWEh27b2 https:\/\/t.co\/iWzWWDQbPw",
  "id" : 786954416339361792,
  "created_at" : "2016-10-14 15:38:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786943122756345856\/photo\/1",
      "indices" : [ 126, 149 ],
      "url" : "https:\/\/t.co\/B9ifnhCIwH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuvIaOuUEAAlLGQ.jpg",
      "id_str" : "786942912860786688",
      "id" : 786942912860786688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuvIaOuUEAAlLGQ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/B9ifnhCIwH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/lVlHaGKAeF",
      "expanded_url" : "http:\/\/go.wh.gov\/FGnyT2",
      "display_url" : "go.wh.gov\/FGnyT2"
    } ]
  },
  "geo" : { },
  "id_str" : "786943122756345856",
  "text" : "We've made sending a message to @POTUS easier than ever. And today, we're helping others do the same: https:\/\/t.co\/lVlHaGKAeF https:\/\/t.co\/B9ifnhCIwH",
  "id" : 786943122756345856,
  "created_at" : "2016-10-14 14:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786936172194861058",
  "text" : "RT @Goldman44: Since launch @POTUS has received 1.5M messages on FB. And today we're open-sourcing our bot code for everyone to use https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/pvRthSsMtO",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/13\/removing-barriers-constituent-conversations",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786935942074425344",
    "text" : "Since launch @POTUS has received 1.5M messages on FB. And today we're open-sourcing our bot code for everyone to use https:\/\/t.co\/pvRthSsMtO",
    "id" : 786935942074425344,
    "created_at" : "2016-10-14 14:25:23 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 786936172194861058,
  "created_at" : "2016-10-14 14:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786746385110487040\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/o3aA2oIAG5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CusVSWXUkAApk2R.jpg",
      "id_str" : "786745964891508736",
      "id" : 786745964891508736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusVSWXUkAApk2R.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/o3aA2oIAG5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786746385110487040\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/o3aA2oIAG5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CusVTdUVIAAMibS.jpg",
      "id_str" : "786745983937880064",
      "id" : 786745983937880064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusVTdUVIAAMibS.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/o3aA2oIAG5"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/SsqBlWPetL",
      "expanded_url" : "http:\/\/go.wh.gov\/Frontiers",
      "display_url" : "go.wh.gov\/Frontiers"
    } ]
  },
  "geo" : { },
  "id_str" : "786746385110487040",
  "text" : "\"I am a science geek. I'm a nerd, and I don\u2019t make any apologies for it.\" \u2014@POTUS: https:\/\/t.co\/SsqBlWPetL #WHFrontiers https:\/\/t.co\/o3aA2oIAG5",
  "id" : 786746385110487040,
  "created_at" : "2016-10-14 01:52:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 113, 120 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786717412087390208",
  "text" : "RT @VP: For 241 years, you have selflessly defended our nation and preserved freedom on the seas. Happy Birthday @USNavy! https:\/\/t.co\/j1qz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 105, 112 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/786712891420467200\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/j1qzWcsKB2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cur2-D8WIAEeRVf.jpg",
        "id_str" : "786712631000309761",
        "id" : 786712631000309761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cur2-D8WIAEeRVf.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3840,
          "resize" : "fit",
          "w" : 5760
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/j1qzWcsKB2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786712891420467200",
    "text" : "For 241 years, you have selflessly defended our nation and preserved freedom on the seas. Happy Birthday @USNavy! https:\/\/t.co\/j1qzWcsKB2",
    "id" : 786712891420467200,
    "created_at" : "2016-10-13 23:39:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 786717412087390208,
  "created_at" : "2016-10-13 23:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 3, 17 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StephenAtHome\/status\/786693753050394626\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/FqMB7zKj6o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CurlzAWWIAAOQUs.jpg",
      "id_str" : "786693749359386624",
      "id" : 786693749359386624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CurlzAWWIAAOQUs.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/FqMB7zKj6o"
    } ],
    "hashtags" : [ {
      "text" : "LSSC",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786700165902131201",
  "text" : "RT @StephenAtHome: Hey, if you're hiring, this guy's looking for a new gig. Watch #LSSC Monday for more. https:\/\/t.co\/FqMB7zKj6o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StephenAtHome\/status\/786693753050394626\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/FqMB7zKj6o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CurlzAWWIAAOQUs.jpg",
        "id_str" : "786693749359386624",
        "id" : 786693749359386624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CurlzAWWIAAOQUs.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/FqMB7zKj6o"
      } ],
      "hashtags" : [ {
        "text" : "LSSC",
        "indices" : [ 63, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786693753050394626",
    "text" : "Hey, if you're hiring, this guy's looking for a new gig. Watch #LSSC Monday for more. https:\/\/t.co\/FqMB7zKj6o",
    "id" : 786693753050394626,
    "created_at" : "2016-10-13 22:23:01 +0000",
    "user" : {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "protected" : false,
      "id_str" : "16303106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627669832549441536\/hv1AMpO0_normal.jpg",
      "id" : 16303106,
      "verified" : true
    }
  },
  "id" : 786700165902131201,
  "created_at" : "2016-10-13 22:48:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 13, 21 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786675713579462656",
  "text" : "RT @vj44: Hi @Twitter! Thanks to #ItsOnUs for organizing this important conversation on campus sexual assault. Here to answer your Qs and t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 3, 11 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786673763094032384",
    "text" : "Hi @Twitter! Thanks to #ItsOnUs for organizing this important conversation on campus sexual assault. Here to answer your Qs and to ask some!",
    "id" : 786673763094032384,
    "created_at" : "2016-10-13 21:03:35 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 786675713579462656,
  "created_at" : "2016-10-13 21:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 118, 133 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/cLsX5VM5p4",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/12\/advancing-frontiers-clean-energy-innovation",
      "display_url" : "whitehouse.gov\/blog\/2016\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786673039358496768",
  "text" : "RT @ENERGY: How #CleanEnergy innovation can help in the global fight against climate change \u279F https:\/\/t.co\/cLsX5VM5p4 @WhiteHouseOSTP #WHFr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 106, 121 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/786655356126715904\/video\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/kkIZH6DnJq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuCFufsVYAAWFOM.jpg",
        "id_str" : "783772648748625920",
        "id" : 783772648748625920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuCFufsVYAAWFOM.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/kkIZH6DnJq"
      } ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 4, 16 ]
      }, {
        "text" : "WHFrontiers",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/cLsX5VM5p4",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/12\/advancing-frontiers-clean-energy-innovation",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786655356126715904",
    "text" : "How #CleanEnergy innovation can help in the global fight against climate change \u279F https:\/\/t.co\/cLsX5VM5p4 @WhiteHouseOSTP #WHFrontiers https:\/\/t.co\/kkIZH6DnJq",
    "id" : 786655356126715904,
    "created_at" : "2016-10-13 19:50:26 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 786673039358496768,
  "created_at" : "2016-10-13 21:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/JskiRopPqV",
      "expanded_url" : "http:\/\/snpy.tv\/2dzA1eo",
      "display_url" : "snpy.tv\/2dzA1eo"
    } ]
  },
  "geo" : { },
  "id_str" : "786669433452322816",
  "text" : "\u201CWe are working to help all of our children understand that they too have a place in science and tech\u201D \u2014@POTUS https:\/\/t.co\/JskiRopPqV",
  "id" : 786669433452322816,
  "created_at" : "2016-10-13 20:46:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA Exhibit",
      "screen_name" : "NASAExhibit",
      "indices" : [ 51, 63 ],
      "id_str" : "717734908399976448",
      "id" : 717734908399976448
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 98, 109 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JourneyToMars",
      "indices" : [ 21, 35 ]
    }, {
      "text" : "WHFrontiers",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786665539330375680",
  "text" : "RT @NASA: We\u2019re on a #JourneyToMars! Check out our @NASAExhibit at the #WHFrontiers Conference on @WhiteHouse Snapchat. https:\/\/t.co\/kTwQ3e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA Exhibit",
        "screen_name" : "NASAExhibit",
        "indices" : [ 41, 53 ],
        "id_str" : "717734908399976448",
        "id" : 717734908399976448
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 88, 99 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/786641096738824192\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/kTwQ3eFMDM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq16FhWgAAsCwK.jpg",
        "id_str" : "786641094448676864",
        "id" : 786641094448676864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq16FhWgAAsCwK.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/kTwQ3eFMDM"
      } ],
      "hashtags" : [ {
        "text" : "JourneyToMars",
        "indices" : [ 11, 25 ]
      }, {
        "text" : "WHFrontiers",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786641096738824192",
    "text" : "We\u2019re on a #JourneyToMars! Check out our @NASAExhibit at the #WHFrontiers Conference on @WhiteHouse Snapchat. https:\/\/t.co\/kTwQ3eFMDM",
    "id" : 786641096738824192,
    "created_at" : "2016-10-13 18:53:47 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 786665539330375680,
  "created_at" : "2016-10-13 20:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/jFnU3QyXZ8",
      "expanded_url" : "http:\/\/snpy.tv\/2dzB5yI",
      "display_url" : "snpy.tv\/2dzB5yI"
    } ]
  },
  "geo" : { },
  "id_str" : "786661538807554049",
  "text" : "As Americans, innovation is in our DNA. Science has always been central to our progress. #WHFrontiers https:\/\/t.co\/jFnU3QyXZ8",
  "id" : 786661538807554049,
  "created_at" : "2016-10-13 20:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/pxdVwLATrD",
      "expanded_url" : "http:\/\/snpy.tv\/2e0cWmK",
      "display_url" : "snpy.tv\/2e0cWmK"
    } ]
  },
  "geo" : { },
  "id_str" : "786657957052243968",
  "text" : "\"I'm a science geek. I'm a nerd, and I don't make any apologies for it.\" \u2014@POTUS  #WHFrontiers https:\/\/t.co\/pxdVwLATrD",
  "id" : 786657957052243968,
  "created_at" : "2016-10-13 20:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786652827129032704",
  "text" : "\"We\u2019re the nation that just had six of our scientists and researchers win Nobel Prizes\u2014and every one of them was an immigrant.\" \u2014@POTUS",
  "id" : 786652827129032704,
  "created_at" : "2016-10-13 19:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Xn8qGGDr7y",
      "expanded_url" : "http:\/\/frontiersconference.org",
      "display_url" : "frontiersconference.org"
    } ]
  },
  "geo" : { },
  "id_str" : "786651523379978240",
  "text" : "\"I must confess I\u2019m a science geek. I\u2019m a nerd. I won\u2019t make any apologies for it\" \u2014@POTUS speaking at #WHFrontiers: https:\/\/t.co\/Xn8qGGDr7y",
  "id" : 786651523379978240,
  "created_at" : "2016-10-13 19:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786651175449874432\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/FLY64hXbOf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq-8hMUMAQB82j.jpg",
      "id_str" : "786651031841026052",
      "id" : 786651031841026052,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq-8hMUMAQB82j.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1210
      } ],
      "display_url" : "pic.twitter.com\/FLY64hXbOf"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786651175449874432",
  "text" : "\"To lead humanity farther out into the final frontier of space, not just to visit but to stay.\" \u2014@POTUS on our next frontiers #WHFrontiers https:\/\/t.co\/FLY64hXbOf",
  "id" : 786651175449874432,
  "created_at" : "2016-10-13 19:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786650586540146688\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/yxpsvbhZPU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq-ZGbVIAAE5Gm.jpg",
      "id_str" : "786650423360823296",
      "id" : 786650423360823296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq-ZGbVIAAE5Gm.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/yxpsvbhZPU"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786650586540146688",
  "text" : "\"Only with science can we reengineer our cities to be smarter and more productive.\" \u2014@POTUS at #WHFrontiers https:\/\/t.co\/yxpsvbhZPU",
  "id" : 786650586540146688,
  "created_at" : "2016-10-13 19:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786650133744132096\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/PHEBFokjSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq-HCoUIAAqy3S.jpg",
      "id_str" : "786650113103896576",
      "id" : 786650113103896576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq-HCoUIAAqy3S.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/PHEBFokjSi"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786650133744132096",
  "text" : "\"Only with science can we make a shift to cleaner sources of energy and take steps to save the only planet we have.\" \u2014@POTUS at #WHFrontiers https:\/\/t.co\/PHEBFokjSi",
  "id" : 786650133744132096,
  "created_at" : "2016-10-13 19:29:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786649495526264832\/photo\/1",
      "indices" : [ 126, 149 ],
      "url" : "https:\/\/t.co\/fzcx2Ks48S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq9gfdUIAACuFC.jpg",
      "id_str" : "786649450827489280",
      "id" : 786649450827489280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq9gfdUIAACuFC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/fzcx2Ks48S"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Xn8qGGDr7y",
      "expanded_url" : "http:\/\/frontiersconference.org",
      "display_url" : "frontiersconference.org"
    } ]
  },
  "geo" : { },
  "id_str" : "786649495526264832",
  "text" : "\"Innovation is in our DNA. Science has always been central to our progress.\" \u2014@POTUS at #WHFrontiers: https:\/\/t.co\/Xn8qGGDr7y https:\/\/t.co\/fzcx2Ks48S",
  "id" : 786649495526264832,
  "created_at" : "2016-10-13 19:27:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786648414536671233",
  "text" : "RT @WHLive: Happening now: Watch @POTUS at #WHFrontiers discuss the future of American innovation, science, and technology: https:\/\/t.co\/ze\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFrontiers",
        "indices" : [ 31, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/zeZAhrh6uD",
        "expanded_url" : "http:\/\/frontiersconference.org",
        "display_url" : "frontiersconference.org"
      } ]
    },
    "geo" : { },
    "id_str" : "786648170197422080",
    "text" : "Happening now: Watch @POTUS at #WHFrontiers discuss the future of American innovation, science, and technology: https:\/\/t.co\/zeZAhrh6uD",
    "id" : 786648170197422080,
    "created_at" : "2016-10-13 19:21:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 786648414536671233,
  "created_at" : "2016-10-13 19:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 94, 100 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786647560114937856\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/uv31PbFW2C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq7f8DVIAAAx5S.jpg",
      "id_str" : "786647242300006400",
      "id" : 786647242300006400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq7f8DVIAAAx5S.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 763
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 763
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 763
      } ],
      "display_url" : "pic.twitter.com\/uv31PbFW2C"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/G5t5IFr5RM",
      "expanded_url" : "http:\/\/bit.ly\/2d6YlIn",
      "display_url" : "bit.ly\/2d6YlIn"
    } ]
  },
  "geo" : { },
  "id_str" : "786647560114937856",
  "text" : "From interplanetary travel to artificial intelligence, @POTUS reflects on coming frontiers in @Wired: https:\/\/t.co\/G5t5IFr5RM #WHFrontiers https:\/\/t.co\/uv31PbFW2C",
  "id" : 786647560114937856,
  "created_at" : "2016-10-13 19:19:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/SsqBlWPetL",
      "expanded_url" : "http:\/\/go.wh.gov\/Frontiers",
      "display_url" : "go.wh.gov\/Frontiers"
    } ]
  },
  "geo" : { },
  "id_str" : "786642725101723648",
  "text" : "Reimagining what\u2019s possible enables breakthroughs that shape the future. One astrophysicist\u2019s take on #WHFrontiers: https:\/\/t.co\/SsqBlWPetL",
  "id" : 786642725101723648,
  "created_at" : "2016-10-13 19:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786636192229969920\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/yMYVdwtiXs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqxaAgWIAAma0G.jpg",
      "id_str" : "786636145299955712",
      "id" : 786636145299955712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqxaAgWIAAma0G.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/yMYVdwtiXs"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Xn8qGGDr7y",
      "expanded_url" : "http:\/\/frontiersconference.org",
      "display_url" : "frontiersconference.org"
    } ]
  },
  "geo" : { },
  "id_str" : "786636192229969920",
  "text" : "Tune in at 3:30pm ET: Watch @POTUS discuss the future of American innovation, science, and technology: https:\/\/t.co\/Xn8qGGDr7y #WHFrontiers https:\/\/t.co\/yMYVdwtiXs",
  "id" : 786636192229969920,
  "created_at" : "2016-10-13 18:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "indices" : [ 3, 14 ],
      "id_str" : "562456722",
      "id" : 562456722
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786635726200770561",
  "text" : "RT @LizAllen44: Amazing. @POTUS shakes robotic hand of brain implant patient Nathan who controls it w\/ his mind. #WHFrontiers https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LizAllen44\/status\/786634726253756416\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/iomJ3kgUWA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqwBESWYAAX5yb.jpg",
        "id_str" : "786634617306636288",
        "id" : 786634617306636288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqwBESWYAAX5yb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 464
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1398
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1398
        } ],
        "display_url" : "pic.twitter.com\/iomJ3kgUWA"
      } ],
      "hashtags" : [ {
        "text" : "WHFrontiers",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786634726253756416",
    "text" : "Amazing. @POTUS shakes robotic hand of brain implant patient Nathan who controls it w\/ his mind. #WHFrontiers https:\/\/t.co\/iomJ3kgUWA",
    "id" : 786634726253756416,
    "created_at" : "2016-10-13 18:28:28 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 786635726200770561,
  "created_at" : "2016-10-13 18:32:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786622165026082816\/photo\/1",
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/PKuJwf7zXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuqjr0pUMAA1KaI.jpg",
      "id_str" : "786621058191208448",
      "id" : 786621058191208448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuqjr0pUMAA1KaI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/PKuJwf7zXO"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786622165026082816",
  "text" : "America has always been a leader in innovation\u2014and under @POTUS, we\u2019re continuing to build the industries of the future. #WHFrontiers https:\/\/t.co\/PKuJwf7zXO",
  "id" : 786622165026082816,
  "created_at" : "2016-10-13 17:38:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786616132132188160\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/eAjMPgaOmm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqfDdoW8AAGDPS.jpg",
      "id_str" : "786615966771900416",
      "id" : 786615966771900416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqfDdoW8AAGDPS.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/eAjMPgaOmm"
    } ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Xn8qGGDr7y",
      "expanded_url" : "http:\/\/frontiersconference.org",
      "display_url" : "frontiersconference.org"
    } ]
  },
  "geo" : { },
  "id_str" : "786616132132188160",
  "text" : "What innovations will shape America's future? @POTUS explores the possibilities at today's #WHFrontiers Conference: https:\/\/t.co\/Xn8qGGDr7y https:\/\/t.co\/eAjMPgaOmm",
  "id" : 786616132132188160,
  "created_at" : "2016-10-13 17:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "refinery29",
      "screen_name" : "Refinery29",
      "indices" : [ 56, 67 ],
      "id_str" : "19546942",
      "id" : 19546942
    }, {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "indices" : [ 73, 81 ],
      "id_str" : "2840712124",
      "id" : 2840712124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786611464933171200",
  "text" : "RT @vj44: Together we can stop sexual assault. Join me, @Refinery29, and @ItsOnUs today at 5:00pm ET for a Q&amp;A using #ItsOnUs: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "refinery29",
        "screen_name" : "Refinery29",
        "indices" : [ 46, 57 ],
        "id_str" : "19546942",
        "id" : 19546942
      }, {
        "name" : "It's On Us",
        "screen_name" : "ItsOnUs",
        "indices" : [ 63, 71 ],
        "id_str" : "2840712124",
        "id" : 2840712124
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/sOoGM9km6j",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wNMZo31LziM",
        "display_url" : "youtube.com\/watch?v=wNMZo3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786601205245943808",
    "text" : "Together we can stop sexual assault. Join me, @Refinery29, and @ItsOnUs today at 5:00pm ET for a Q&amp;A using #ItsOnUs: https:\/\/t.co\/sOoGM9km6j",
    "id" : 786601205245943808,
    "created_at" : "2016-10-13 16:15:16 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 786611464933171200,
  "created_at" : "2016-10-13 16:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/786608372829163520\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/iLCT49BVWZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqYGXdUEAAH3Uj.jpg",
      "id_str" : "786608320073175040",
      "id" : 786608320073175040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqYGXdUEAAH3Uj.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/iLCT49BVWZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/jvhhLCPxhz",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/10\/13\/statement-president-passing-his-majesty-king-bhumibol-adulyadej",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786609450811404289",
  "text" : "RT @NSC44: Statement by @POTUS on the Passing of His Majesty King Bhumibol Adulyadej: https:\/\/t.co\/jvhhLCPxhz https:\/\/t.co\/iLCT49BVWZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/786608372829163520\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/iLCT49BVWZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuqYGXdUEAAH3Uj.jpg",
        "id_str" : "786608320073175040",
        "id" : 786608320073175040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuqYGXdUEAAH3Uj.jpg",
        "sizes" : [ {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/iLCT49BVWZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/jvhhLCPxhz",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/10\/13\/statement-president-passing-his-majesty-king-bhumibol-adulyadej",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786608372829163520",
    "text" : "Statement by @POTUS on the Passing of His Majesty King Bhumibol Adulyadej: https:\/\/t.co\/jvhhLCPxhz https:\/\/t.co\/iLCT49BVWZ",
    "id" : 786608372829163520,
    "created_at" : "2016-10-13 16:43:45 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 786609450811404289,
  "created_at" : "2016-10-13 16:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/c9cnANWPCS",
      "expanded_url" : "http:\/\/spoti.fi\/25fTuWt",
      "display_url" : "spoti.fi\/25fTuWt"
    } ]
  },
  "geo" : { },
  "id_str" : "786607074155397120",
  "text" : "RT @POTUS: Congratulations to one of my favorite poets, Bob Dylan, on a well-deserved Nobel. https:\/\/t.co\/c9cnANWPCS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/c9cnANWPCS",
        "expanded_url" : "http:\/\/spoti.fi\/25fTuWt",
        "display_url" : "spoti.fi\/25fTuWt"
      } ]
    },
    "geo" : { },
    "id_str" : "786598777482153988",
    "text" : "Congratulations to one of my favorite poets, Bob Dylan, on a well-deserved Nobel. https:\/\/t.co\/c9cnANWPCS",
    "id" : 786598777482153988,
    "created_at" : "2016-10-13 16:05:37 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 786607074155397120,
  "created_at" : "2016-10-13 16:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786586386182746112",
  "text" : "RT @DrBiden: In Cuba, Dr. Biden highlighted the shared interests and aspirations between the people of our two countries. https:\/\/t.co\/tDtO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/786216587363700740\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/tDtOz7yif8",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/786207830143447040\/img\/9UJXOEpBMFDpussi.jpg",
        "id_str" : "786207830143447040",
        "id" : 786207830143447040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/786207830143447040\/img\/9UJXOEpBMFDpussi.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tDtOz7yif8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786216587363700740",
    "text" : "In Cuba, Dr. Biden highlighted the shared interests and aspirations between the people of our two countries. https:\/\/t.co\/tDtOz7yif8",
    "id" : 786216587363700740,
    "created_at" : "2016-10-12 14:46:56 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 786586386182746112,
  "created_at" : "2016-10-13 15:16:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hail to Pitt",
      "screen_name" : "PittTweet",
      "indices" : [ 3, 13 ],
      "id_str" : "68503423",
      "id" : 68503423
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/9LvNnd4j4O",
      "expanded_url" : "http:\/\/www.frontiersconference.org",
      "display_url" : "frontiersconference.org"
    } ]
  },
  "geo" : { },
  "id_str" : "786574452855304192",
  "text" : "RT @PittTweet: Today @Potus visits our campus along with leading innovators from across the country. Stream it at https:\/\/t.co\/9LvNnd4j4O #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PittTweet\/status\/786529416566411264\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/JFy7lautwl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CunWb0BWcAAHeg_.png",
        "id_str" : "786395383261982720",
        "id" : 786395383261982720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CunWb0BWcAAHeg_.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/JFy7lautwl"
      } ],
      "hashtags" : [ {
        "text" : "WHFrontiers",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/9LvNnd4j4O",
        "expanded_url" : "http:\/\/www.frontiersconference.org",
        "display_url" : "frontiersconference.org"
      } ]
    },
    "geo" : { },
    "id_str" : "786529416566411264",
    "text" : "Today @Potus visits our campus along with leading innovators from across the country. Stream it at https:\/\/t.co\/9LvNnd4j4O #WHFrontiers https:\/\/t.co\/JFy7lautwl",
    "id" : 786529416566411264,
    "created_at" : "2016-10-13 11:30:00 +0000",
    "user" : {
      "name" : "Hail to Pitt",
      "screen_name" : "PittTweet",
      "protected" : false,
      "id_str" : "68503423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773167414494257152\/AHypGwQE_normal.jpg",
      "id" : 68503423,
      "verified" : false
    }
  },
  "id" : 786574452855304192,
  "created_at" : "2016-10-13 14:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786567715557404672",
  "text" : "RT @NASA: Today, we\u2019re joining @POTUS &amp; innovators from around the country at #WHFrontiers Conference. Live streams available: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFrontiers",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/8qRe6qkJCR",
        "expanded_url" : "http:\/\/frontiersconference.org\/",
        "display_url" : "frontiersconference.org"
      } ]
    },
    "geo" : { },
    "id_str" : "786556337509527552",
    "text" : "Today, we\u2019re joining @POTUS &amp; innovators from around the country at #WHFrontiers Conference. Live streams available: https:\/\/t.co\/8qRe6qkJCR",
    "id" : 786556337509527552,
    "created_at" : "2016-10-13 13:16:59 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 786567715557404672,
  "created_at" : "2016-10-13 14:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stranger Things",
      "screen_name" : "Stranger_Things",
      "indices" : [ 3, 19 ],
      "id_str" : "3320478908",
      "id" : 3320478908
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StrangerThings",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786390926792929280",
  "text" : "RT @Stranger_Things: The Duffer Brothers and the cast of #StrangerThings visited the @WhiteHouse to meet @POTUS and get inspired by young f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 84, 90 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Stranger_Things\/status\/786003956455452672\/video\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/PUI39q1leF",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/786003530079309824\/img\/4ATSk6_WiFOyBSgZ.jpg",
        "id_str" : "786003530079309824",
        "id" : 786003530079309824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/786003530079309824\/img\/4ATSk6_WiFOyBSgZ.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/PUI39q1leF"
      } ],
      "hashtags" : [ {
        "text" : "StrangerThings",
        "indices" : [ 36, 51 ]
      }, {
        "text" : "SXSL",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786003956455452672",
    "text" : "The Duffer Brothers and the cast of #StrangerThings visited the @WhiteHouse to meet @POTUS and get inspired by young filmmakers at #SXSL. https:\/\/t.co\/PUI39q1leF",
    "id" : 786003956455452672,
    "created_at" : "2016-10-12 00:42:01 +0000",
    "user" : {
      "name" : "Stranger Things",
      "screen_name" : "Stranger_Things",
      "protected" : false,
      "id_str" : "3320478908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740914180190937088\/JmkrQA8y_normal.jpg",
      "id" : 3320478908,
      "verified" : true
    }
  },
  "id" : 786390926792929280,
  "created_at" : "2016-10-13 02:19:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 50, 57 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 127, 131 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/786365421364518912\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/RM3dYx3yt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cum61JJVUAEZL7g.jpg",
      "id_str" : "786365032103759873",
      "id" : 786365032103759873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cum61JJVUAEZL7g.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/RM3dYx3yt4"
    } ],
    "hashtags" : [ {
      "text" : "WeWillRise",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786365421364518912",
  "text" : "Far too many girls are not in school today. Watch @FLOTUS\u2019s mission to break barriers to education on #WeWillRise at 9PM ET on @CNN. https:\/\/t.co\/RM3dYx3yt4",
  "id" : 786365421364518912,
  "created_at" : "2016-10-13 00:38:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HispanicHeritageMonth",
      "indices" : [ 72, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786312336420339713",
  "text" : "\"We\u2019ve opened up a new chapter with the people of Cuba.\" \u2014@POTUS during #HispanicHeritageMonth",
  "id" : 786312336420339713,
  "created_at" : "2016-10-12 21:07:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786312309539016704",
  "text" : "RT @WHLive: \"Latinos experienced the fastest income growth and biggest drop in poverty of any group in America.\" \u2014@POTUS #HispanicHeritageM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 102, 108 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/786312196175331328\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/ORCGYZera3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CumKwDZUsAAkPz5.jpg",
        "id_str" : "786312168102735872",
        "id" : 786312168102735872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CumKwDZUsAAkPz5.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/ORCGYZera3"
      } ],
      "hashtags" : [ {
        "text" : "HispanicHeritageMonth",
        "indices" : [ 109, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786312196175331328",
    "text" : "\"Latinos experienced the fastest income growth and biggest drop in poverty of any group in America.\" \u2014@POTUS #HispanicHeritageMonth https:\/\/t.co\/ORCGYZera3",
    "id" : 786312196175331328,
    "created_at" : "2016-10-12 21:06:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 786312309539016704,
  "created_at" : "2016-10-12 21:07:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786311979828936705\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/sJdxEsdMgB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CumJKqfUsAAQxwB.jpg",
      "id_str" : "786310426250227712",
      "id" : 786310426250227712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CumJKqfUsAAQxwB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sJdxEsdMgB"
    } ],
    "hashtags" : [ {
      "text" : "HispanicHeritageMonth",
      "indices" : [ 107, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786311979828936705",
  "text" : "\"More Hispanic students are graduating high school and more are going to college than ever\" \u2014@POTUS at the #HispanicHeritageMonth reception https:\/\/t.co\/sJdxEsdMgB",
  "id" : 786311979828936705,
  "created_at" : "2016-10-12 21:05:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HispanicHeritageMonth",
      "indices" : [ 36, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/1ASHWak1DG",
      "expanded_url" : "http:\/\/go.wh.gov\/QorqLz",
      "display_url" : "go.wh.gov\/QorqLz"
    } ]
  },
  "geo" : { },
  "id_str" : "786310049744510976",
  "text" : "Happening now: @POTUS speaks at the #HispanicHeritageMonth Reception: https:\/\/t.co\/1ASHWak1DG",
  "id" : 786310049744510976,
  "created_at" : "2016-10-12 20:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786267895965724676",
  "text" : "RT @POTUS: Now this was fun. Artificial intelligence, space travel\u2014hope you enjoy exploring new frontiers as much as I did. https:\/\/t.co\/WW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/WWBUm5eJ08",
        "expanded_url" : "https:\/\/twitter.com\/wired\/status\/786159612940656641",
        "display_url" : "twitter.com\/wired\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786254141182074880",
    "text" : "Now this was fun. Artificial intelligence, space travel\u2014hope you enjoy exploring new frontiers as much as I did. https:\/\/t.co\/WWBUm5eJ08",
    "id" : 786254141182074880,
    "created_at" : "2016-10-12 17:16:09 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 786267895965724676,
  "created_at" : "2016-10-12 18:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786251082947186688\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/dHpGlqAnU3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulBe8fWEAIIPI3.jpg",
      "id_str" : "786231609842339842",
      "id" : 786231609842339842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulBe8fWEAIIPI3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/dHpGlqAnU3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/qusl3KAlfk",
      "expanded_url" : "http:\/\/go.wh.gov\/fSZ3J2",
      "display_url" : "go.wh.gov\/fSZ3J2"
    } ]
  },
  "geo" : { },
  "id_str" : "786251082947186688",
  "text" : "Income \u2191\nUnemployment \u2193\nGraduation Rate \u2191\nUninsured Rate \u2193\n\nLearn how under @POTUS, Hispanic Americans are thriving: https:\/\/t.co\/qusl3KAlfk https:\/\/t.co\/dHpGlqAnU3",
  "id" : 786251082947186688,
  "created_at" : "2016-10-12 17:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786243534781165569\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/YHRb5jLCTh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulBNK2XYAApnjR.jpg",
      "id_str" : "786231304459345920",
      "id" : 786231304459345920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulBNK2XYAApnjR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/YHRb5jLCTh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qusl3KAlfk",
      "expanded_url" : "http:\/\/go.wh.gov\/fSZ3J2",
      "display_url" : "go.wh.gov\/fSZ3J2"
    } ]
  },
  "geo" : { },
  "id_str" : "786243534781165569",
  "text" : "Over the past 8 years, @POTUS's policies have paid off in real ways for Hispanic families. Here's why this matters: https:\/\/t.co\/qusl3KAlfk https:\/\/t.co\/YHRb5jLCTh",
  "id" : 786243534781165569,
  "created_at" : "2016-10-12 16:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786235983717171200\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/gNVLG7tiOI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulBCr1WIAABMji.jpg",
      "id_str" : "786231124334878720",
      "id" : 786231124334878720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulBCr1WIAABMji.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/gNVLG7tiOI"
    } ],
    "hashtags" : [ {
      "text" : "HispanicHeritageMonth",
      "indices" : [ 5, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/qusl3KRWDU",
      "expanded_url" : "http:\/\/go.wh.gov\/fSZ3J2",
      "display_url" : "go.wh.gov\/fSZ3J2"
    } ]
  },
  "geo" : { },
  "id_str" : "786235983717171200",
  "text" : "This #HispanicHeritageMonth, we celebrate the Hispanic American students who've made historic strides: https:\/\/t.co\/qusl3KRWDU https:\/\/t.co\/gNVLG7tiOI",
  "id" : 786235983717171200,
  "created_at" : "2016-10-12 16:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/786229841737592832\/photo\/1",
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/u2FU9oN8Pu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuk_sd6UEAA7eDz.jpg",
      "id_str" : "786229643128868864",
      "id" : 786229643128868864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuk_sd6UEAA7eDz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/u2FU9oN8Pu"
    } ],
    "hashtags" : [ {
      "text" : "HispanicHeritageMonth",
      "indices" : [ 12, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/qusl3KAlfk",
      "expanded_url" : "http:\/\/go.wh.gov\/fSZ3J2",
      "display_url" : "go.wh.gov\/fSZ3J2"
    } ]
  },
  "geo" : { },
  "id_str" : "786229841737592832",
  "text" : "In honor of #HispanicHeritageMonth, we celebrate the progress that Hispanic Americans have made under @POTUS: https:\/\/t.co\/qusl3KAlfk https:\/\/t.co\/u2FU9oN8Pu",
  "id" : 786229841737592832,
  "created_at" : "2016-10-12 15:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786035276191629312\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/pS9PmHIxk8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuiOQeOVMAAhFVq.jpg",
      "id_str" : "786034548618375168",
      "id" : 786034548618375168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuiOQeOVMAAhFVq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/pS9PmHIxk8"
    } ],
    "hashtags" : [ {
      "text" : "UndefeatedConvo",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/qtf5dCNxBC",
      "expanded_url" : "http:\/\/mentor.gov",
      "display_url" : "mentor.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "786035276191629312",
  "text" : "\"It doesn\u2019t take a lot to transform the lives of young men.\" \u2014@POTUS on importance of mentorship: https:\/\/t.co\/qtf5dCNxBC #UndefeatedConvo https:\/\/t.co\/pS9PmHIxk8",
  "id" : 786035276191629312,
  "created_at" : "2016-10-12 02:46:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESPN",
      "screen_name" : "espn",
      "indices" : [ 14, 19 ],
      "id_str" : "2557521",
      "id" : 2557521
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/786024511263039488\/photo\/1",
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/hPGRejGvbl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuiE-XeUAAAtf1g.jpg",
      "id_str" : "786024341964062720",
      "id" : 786024341964062720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuiE-XeUAAAtf1g.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/hPGRejGvbl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/DjyYdX0um8",
      "expanded_url" : "http:\/\/theundefeated.com\/features\/watch-an-undefeated-conversation-with-president-obama-sports-race-and-achievement\/",
      "display_url" : "theundefeated.com\/features\/watch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786024511263039488",
  "text" : "Watch live on @ESPN: @POTUS speaks on why every young person in America deserves an equal shot at success: https:\/\/t.co\/DjyYdX0um8 https:\/\/t.co\/hPGRejGvbl",
  "id" : 786024511263039488,
  "created_at" : "2016-10-12 02:03:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Undefeated",
      "screen_name" : "TheUndefeated",
      "indices" : [ 3, 17 ],
      "id_str" : "3033098871",
      "id" : 3033098871
    }, {
      "name" : "ESPN",
      "screen_name" : "espn",
      "indices" : [ 64, 69 ],
      "id_str" : "2557521",
      "id" : 2557521
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheUndefeated\/status\/786008512606244866\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/HnRcz4SuUY",
      "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/786001807243816960\/img\/yI6QN0hI4Yhdllt4.jpg",
      "id_str" : "786001807243816960",
      "id" : 786001807243816960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/786001807243816960\/img\/yI6QN0hI4Yhdllt4.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HnRcz4SuUY"
    } ],
    "hashtags" : [ {
      "text" : "UndefeatedConvo",
      "indices" : [ 34, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786021300489842688",
  "text" : "RT @TheUndefeated: Tune in to our #UndefeatedConvo at 10p et on @espn as @POTUS reveals what makes him UNDEFEATED. https:\/\/t.co\/HnRcz4SuUY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ESPN",
        "screen_name" : "espn",
        "indices" : [ 45, 50 ],
        "id_str" : "2557521",
        "id" : 2557521
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 54, 60 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheUndefeated\/status\/786008512606244866\/video\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/HnRcz4SuUY",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/786001807243816960\/img\/yI6QN0hI4Yhdllt4.jpg",
        "id_str" : "786001807243816960",
        "id" : 786001807243816960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/786001807243816960\/img\/yI6QN0hI4Yhdllt4.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HnRcz4SuUY"
      } ],
      "hashtags" : [ {
        "text" : "UndefeatedConvo",
        "indices" : [ 15, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786008512606244866",
    "text" : "Tune in to our #UndefeatedConvo at 10p et on @espn as @POTUS reveals what makes him UNDEFEATED. https:\/\/t.co\/HnRcz4SuUY",
    "id" : 786008512606244866,
    "created_at" : "2016-10-12 01:00:07 +0000",
    "user" : {
      "name" : "The Undefeated",
      "screen_name" : "TheUndefeated",
      "protected" : false,
      "id_str" : "3033098871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758514647813263360\/yzufTV7j_normal.jpg",
      "id" : 3033098871,
      "verified" : true
    }
  },
  "id" : 786021300489842688,
  "created_at" : "2016-10-12 01:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785977768060198912",
  "text" : "RT @LaborSec: Helping young Americans land their #FirstJob \u2013 and teaching them the dignity of work \u2013 is not just good for them, it\u2019s good f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FirstJob",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785868881554472960",
    "text" : "Helping young Americans land their #FirstJob \u2013 and teaching them the dignity of work \u2013 is not just good for them, it\u2019s good for our country.",
    "id" : 785868881554472960,
    "created_at" : "2016-10-11 15:45:16 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 785977768060198912,
  "created_at" : "2016-10-11 22:57:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DadsAndDaughters",
      "indices" : [ 110, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785961020464386048",
  "text" : "RT @rhodes44: As Ella's dad, I am proud to work in an Administration that lifts up women at home &amp; abroad #DadsAndDaughters: https:\/\/t.co\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/785958428191490049\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/ngcBfjyBzm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuhIzF1VIAATgd3.jpg",
        "id_str" : "785958177552539648",
        "id" : 785958177552539648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuhIzF1VIAATgd3.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ngcBfjyBzm"
      } ],
      "hashtags" : [ {
        "text" : "DadsAndDaughters",
        "indices" : [ 96, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/bzspOpsVsr",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/11\/dadsanddaughters-celebrating-international-day-girl",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785958428191490049",
    "text" : "As Ella's dad, I am proud to work in an Administration that lifts up women at home &amp; abroad #DadsAndDaughters: https:\/\/t.co\/bzspOpsVsr https:\/\/t.co\/ngcBfjyBzm",
    "id" : 785958428191490049,
    "created_at" : "2016-10-11 21:41:06 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 785961020464386048,
  "created_at" : "2016-10-11 21:51:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785958152328114176\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/Aavxh4Olzh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuhG0QiVMAATJRS.jpg",
      "id_str" : "785955998582255616",
      "id" : 785955998582255616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuhG0QiVMAATJRS.jpg",
      "sizes" : [ {
        "h" : 467,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Aavxh4Olzh"
    } ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/UzbaVLHxxg",
      "expanded_url" : "http:\/\/go.wh.gov\/USi6C7",
      "display_url" : "go.wh.gov\/USi6C7"
    } ]
  },
  "geo" : { },
  "id_str" : "785958152328114176",
  "text" : "Here\u2019s how companies across the country are helping to connect more young people with their #FirstJob: https:\/\/t.co\/UzbaVLHxxg https:\/\/t.co\/Aavxh4Olzh",
  "id" : 785958152328114176,
  "created_at" : "2016-10-11 21:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785954833362812933\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/gBCj8CNjlJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuhFryuWcAQmSOL.jpg",
      "id_str" : "785954753629024260",
      "id" : 785954753629024260,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuhFryuWcAQmSOL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/gBCj8CNjlJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785954833362812933",
  "text" : "\u201COn behalf of Michelle and our family, G\u2019mar Chatimah Tovah.\u201D \u2014@POTUS on Yom Kippur https:\/\/t.co\/gBCj8CNjlJ",
  "id" : 785954833362812933,
  "created_at" : "2016-10-11 21:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 3, 16 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    }, {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 40, 44 ],
      "id_str" : "2367911",
      "id" : 2367911
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 62, 73 ],
      "id_str" : "18159470",
      "id" : 18159470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpioidEpidemic",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785951086427332609",
  "text" : "RT @Botticelli44: Tonight at 9pm EST on @MTV\u2192 @POTUS talks w\/ @Macklemore about the #OpioidEpidemic &amp; why we need more resources for treatm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MTV",
        "screen_name" : "MTV",
        "indices" : [ 22, 26 ],
        "id_str" : "2367911",
        "id" : 2367911
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 28, 34 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Macklemore",
        "screen_name" : "macklemore",
        "indices" : [ 44, 55 ],
        "id_str" : "18159470",
        "id" : 18159470
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Botticelli44\/status\/785916299079618560\/photo\/1",
        "indices" : [ 142, 165 ],
        "url" : "https:\/\/t.co\/4B4vXE8z8q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cugir37VUAAQ6Yq.jpg",
        "id_str" : "785916272118681600",
        "id" : 785916272118681600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cugir37VUAAQ6Yq.jpg",
        "sizes" : [ {
          "h" : 414,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/4B4vXE8z8q"
      } ],
      "hashtags" : [ {
        "text" : "OpioidEpidemic",
        "indices" : [ 66, 81 ]
      }, {
        "text" : "RxForChange",
        "indices" : [ 129, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785916299079618560",
    "text" : "Tonight at 9pm EST on @MTV\u2192 @POTUS talks w\/ @Macklemore about the #OpioidEpidemic &amp; why we need more resources for treatment #RxForChange https:\/\/t.co\/4B4vXE8z8q",
    "id" : 785916299079618560,
    "created_at" : "2016-10-11 18:53:41 +0000",
    "user" : {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "protected" : false,
      "id_str" : "2382297056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789238935159312385\/z7RppzRN_normal.jpg",
      "id" : 2382297056,
      "verified" : true
    }
  },
  "id" : 785951086427332609,
  "created_at" : "2016-10-11 21:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785950649041113088",
  "text" : "RT @Cecilia44: My #FirstJob taught me to be quick on my feet and how to be friendly to people even when they're hungry. \uD83C\uDF54 \uD83C\uDF5F https:\/\/t.co\/l4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FirstJob",
        "indices" : [ 3, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/l4JehQTUR2",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=7UDJdFDmXB4",
        "display_url" : "youtube.com\/watch?v=7UDJdF\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "785942678416429056",
    "geo" : { },
    "id_str" : "785943058248499201",
    "in_reply_to_user_id" : 1613223313,
    "text" : "My #FirstJob taught me to be quick on my feet and how to be friendly to people even when they're hungry. \uD83C\uDF54 \uD83C\uDF5F https:\/\/t.co\/l4JehQTUR2",
    "id" : 785943058248499201,
    "in_reply_to_status_id" : 785942678416429056,
    "created_at" : "2016-10-11 20:40:01 +0000",
    "in_reply_to_screen_name" : "Cecilia44",
    "in_reply_to_user_id_str" : "1613223313",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 785950649041113088,
  "created_at" : "2016-10-11 21:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "indices" : [ 11, 16 ],
      "id_str" : "214112621",
      "id" : 214112621
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785911812222885888",
  "text" : "RT @vj44: .@attn The wage gap has continued to close but we still have work to do. That's why we started the #EqualPay Pledge\u2192 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ATTN:",
        "screen_name" : "attn",
        "indices" : [ 1, 6 ],
        "id_str" : "214112621",
        "id" : 214112621
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/785911259661074432\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/XhpuqcQkxr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cugd9qXWcAAgSLO.jpg",
        "id_str" : "785911080157605888",
        "id" : 785911080157605888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cugd9qXWcAAgSLO.jpg",
        "sizes" : [ {
          "h" : 776,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1224
        } ],
        "display_url" : "pic.twitter.com\/XhpuqcQkxr"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ndLXES7uuI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/webform\/white-house-equal-pay-pledge",
        "display_url" : "whitehouse.gov\/webform\/white-\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "785910664975888384",
    "geo" : { },
    "id_str" : "785911259661074432",
    "in_reply_to_user_id" : 214112621,
    "text" : ".@attn The wage gap has continued to close but we still have work to do. That's why we started the #EqualPay Pledge\u2192 https:\/\/t.co\/ndLXES7uuI https:\/\/t.co\/XhpuqcQkxr",
    "id" : 785911259661074432,
    "in_reply_to_status_id" : 785910664975888384,
    "created_at" : "2016-10-11 18:33:40 +0000",
    "in_reply_to_screen_name" : "attn",
    "in_reply_to_user_id_str" : "214112621",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 785911812222885888,
  "created_at" : "2016-10-11 18:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayoftheGirl",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785888211700551680",
  "text" : "RT @POTUS: On International #DayoftheGirl, we remain committed to providing what we all want for our daughters: a future of limitless possi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DayoftheGirl",
        "indices" : [ 17, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785887247727857664",
    "text" : "On International #DayoftheGirl, we remain committed to providing what we all want for our daughters: a future of limitless possibility.",
    "id" : 785887247727857664,
    "created_at" : "2016-10-11 16:58:15 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 785888211700551680,
  "created_at" : "2016-10-11 17:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 69, 84 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785882018663964672\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/KAQk4dCekx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CugDW_MVIAESF4v.jpg",
      "id_str" : "785881828431306753",
      "id" : 785881828431306753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CugDW_MVIAESF4v.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/KAQk4dCekx"
    } ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tsEobhRQCP",
      "expanded_url" : "http:\/\/huff.to\/2e3vjFD",
      "display_url" : "huff.to\/2e3vjFD"
    } ]
  },
  "geo" : { },
  "id_str" : "785882018663964672",
  "text" : "\"I\u2019m proud to work for a boss who has declared himself a feminist.\" \u2014@AmbassadorRice on International #DayOfTheGirl https:\/\/t.co\/tsEobhRQCP https:\/\/t.co\/KAQk4dCekx",
  "id" : 785882018663964672,
  "created_at" : "2016-10-11 16:37:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 15, 23 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 28, 42 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785877729111441408\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/JESe6xTywL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuf_axzWAAAeJll.jpg",
      "id_str" : "785877495509811200",
      "id" : 785877495509811200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuf_axzWAAAeJll.jpg",
      "sizes" : [ {
        "h" : 789,
        "resize" : "fit",
        "w" : 1438
      }, {
        "h" : 789,
        "resize" : "fit",
        "w" : 1438
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JESe6xTywL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/O3eIAtWdMt",
      "expanded_url" : "https:\/\/www.facebook.com\/whitehouse",
      "display_url" : "facebook.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "785877729111441408",
  "text" : "Happening now: @Denis44 and @SecretaryFoxx speak to two innovators about the future of American aviation. Tune in: https:\/\/t.co\/O3eIAtWdMt https:\/\/t.co\/JESe6xTywL",
  "id" : 785877729111441408,
  "created_at" : "2016-10-11 16:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/3yMyEo8UKz",
      "expanded_url" : "http:\/\/Facebook.com\/Glamour",
      "display_url" : "Facebook.com\/Glamour"
    } ]
  },
  "geo" : { },
  "id_str" : "785871747178377216",
  "text" : "RT @FLOTUS: \"It's true: Knowledge is power.\" -The First Lady. #DayOfTheGirl | Join us live at https:\/\/t.co\/3yMyEo8UKz https:\/\/t.co\/v9OQfXzZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/785870271706267648\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/v9OQfXzZW7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuf4zkpXEAEUd6d.jpg",
        "id_str" : "785870224893612033",
        "id" : 785870224893612033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuf4zkpXEAEUd6d.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/v9OQfXzZW7"
      } ],
      "hashtags" : [ {
        "text" : "DayOfTheGirl",
        "indices" : [ 50, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/3yMyEo8UKz",
        "expanded_url" : "http:\/\/Facebook.com\/Glamour",
        "display_url" : "Facebook.com\/Glamour"
      } ]
    },
    "geo" : { },
    "id_str" : "785870271706267648",
    "text" : "\"It's true: Knowledge is power.\" -The First Lady. #DayOfTheGirl | Join us live at https:\/\/t.co\/3yMyEo8UKz https:\/\/t.co\/v9OQfXzZW7",
    "id" : 785870271706267648,
    "created_at" : "2016-10-11 15:50:48 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 785871747178377216,
  "created_at" : "2016-10-11 15:56:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785868392989208576\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/t6YYdHMf3Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuf2fLFWYAA8Ik9.jpg",
      "id_str" : "785867675411046400",
      "id" : 785867675411046400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuf2fLFWYAA8Ik9.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/t6YYdHMf3Y"
    } ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/qUTDr205Mc",
      "expanded_url" : "http:\/\/go.wh.gov\/2oNn1e",
      "display_url" : "go.wh.gov\/2oNn1e"
    } ]
  },
  "geo" : { },
  "id_str" : "785868392989208576",
  "text" : "No matter where she lives, every girl deserves the chance to live a life of her own choosing. https:\/\/t.co\/qUTDr205Mc #DayOfTheGirl https:\/\/t.co\/t6YYdHMf3Y",
  "id" : 785868392989208576,
  "created_at" : "2016-10-11 15:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "indices" : [ 83, 88 ],
      "id_str" : "214112621",
      "id" : 214112621
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785852118347476992",
  "text" : "RT @vj44: Today we celebrate the #DayOfTheGirl! Join me 2:00pm ET for a Q&amp;A w\/ @ATTN on @POTUS\u2019 work to advance women &amp; girls. Ask using #W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ATTN:",
        "screen_name" : "attn",
        "indices" : [ 73, 78 ],
        "id_str" : "214112621",
        "id" : 214112621
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 82, 88 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/785851176210276352\/photo\/1",
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/hSP0B9neYJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CufnczDVIAAR40e.jpg",
        "id_str" : "785851141925969920",
        "id" : 785851141925969920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufnczDVIAAR40e.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/hSP0B9neYJ"
      } ],
      "hashtags" : [ {
        "text" : "DayOfTheGirl",
        "indices" : [ 23, 36 ]
      }, {
        "text" : "WHWomen",
        "indices" : [ 135, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785851176210276352",
    "text" : "Today we celebrate the #DayOfTheGirl! Join me 2:00pm ET for a Q&amp;A w\/ @ATTN on @POTUS\u2019 work to advance women &amp; girls. Ask using #WHWomen! https:\/\/t.co\/hSP0B9neYJ",
    "id" : 785851176210276352,
    "created_at" : "2016-10-11 14:34:55 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 785852118347476992,
  "created_at" : "2016-10-11 14:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 101, 116 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785838931606634496",
  "text" : "RT @NASA: We\u2019re pushing the boundaries of exploration and imagination. See how in Admin Bolden &amp; @WhiteHouseOSTP blog: https:\/\/t.co\/SzH8DnU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 91, 106 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/785834543177752576\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/6DG2sD3X84",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CufYVxhW8AA3Hah.jpg",
        "id_str" : "785834528581545984",
        "id" : 785834528581545984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufYVxhW8AA3Hah.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6DG2sD3X84"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/785834543177752576\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/6DG2sD3X84",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CufYWJzWAAAovVv.jpg",
        "id_str" : "785834535099432960",
        "id" : 785834535099432960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufYWJzWAAAovVv.jpg",
        "sizes" : [ {
          "h" : 618,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 618,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6DG2sD3X84"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/785834543177752576\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/6DG2sD3X84",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CufYWdKW8AAOVRf.jpg",
        "id_str" : "785834540296237056",
        "id" : 785834540296237056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufYWdKW8AAOVRf.jpg",
        "sizes" : [ {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6DG2sD3X84"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/SzH8DnUt8f",
        "expanded_url" : "http:\/\/go.nasa.gov\/2dGhFev",
        "display_url" : "go.nasa.gov\/2dGhFev"
      } ]
    },
    "geo" : { },
    "id_str" : "785834543177752576",
    "text" : "We\u2019re pushing the boundaries of exploration and imagination. See how in Admin Bolden &amp; @WhiteHouseOSTP blog: https:\/\/t.co\/SzH8DnUt8f https:\/\/t.co\/6DG2sD3X84",
    "id" : 785834543177752576,
    "created_at" : "2016-10-11 13:28:49 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 785838931606634496,
  "created_at" : "2016-10-11 13:46:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 100, 104 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785835630538395649\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/bLeDaIlMIT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CufYw0EUEAEMOXe.jpg",
      "id_str" : "785834993121497089",
      "id" : 785834993121497089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufYw0EUEAEMOXe.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4096,
        "resize" : "fit",
        "w" : 2730
      } ],
      "display_url" : "pic.twitter.com\/bLeDaIlMIT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/RExUE1ilx1",
      "expanded_url" : "http:\/\/cnn.it\/2dGfdF6",
      "display_url" : "cnn.it\/2dGfdF6"
    } ]
  },
  "geo" : { },
  "id_str" : "785835630538395649",
  "text" : "\"I still have the same sense of wonder about our space program that I did as a child.\" \u2014@POTUS in a @CNN op-ed: https:\/\/t.co\/RExUE1ilx1 https:\/\/t.co\/bLeDaIlMIT",
  "id" : 785835630538395649,
  "created_at" : "2016-10-11 13:33:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 28, 36 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 41, 55 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785833717642190848\/photo\/1",
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/FiDsX5kN6X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CufXdNTXEAAo_VG.jpg",
      "id_str" : "785833556786483200",
      "id" : 785833556786483200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufXdNTXEAAo_VG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/FiDsX5kN6X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/tDkdRefDNY",
      "expanded_url" : "http:\/\/go.wh.gov\/91PTmv",
      "display_url" : "go.wh.gov\/91PTmv"
    } ]
  },
  "geo" : { },
  "id_str" : "785833717642190848",
  "text" : "Tune in today at 12pm ET as @Denis44 and @SecretaryFoxx lead a live discussion on the future of aviation: https:\/\/t.co\/tDkdRefDNY. https:\/\/t.co\/FiDsX5kN6X",
  "id" : 785833717642190848,
  "created_at" : "2016-10-11 13:25:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 3, 7 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/raXQmLOudr",
      "expanded_url" : "http:\/\/cnn.it\/2dGfdF6",
      "display_url" : "cnn.it\/2dGfdF6"
    } ]
  },
  "geo" : { },
  "id_str" : "785831269825449984",
  "text" : "RT @CNN: Exclusive to CNN, President Obama's mission to Mars: We can reach beyond earth's orbit https:\/\/t.co\/raXQmLOudr https:\/\/t.co\/UrfddA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CNN\/status\/785828552398761984\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/UrfddAaRBO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CufS5vfWAAEKM-k.jpg",
        "id_str" : "785828549441748993",
        "id" : 785828549441748993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufS5vfWAAEKM-k.jpg",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/UrfddAaRBO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/raXQmLOudr",
        "expanded_url" : "http:\/\/cnn.it\/2dGfdF6",
        "display_url" : "cnn.it\/2dGfdF6"
      } ]
    },
    "geo" : { },
    "id_str" : "785828552398761984",
    "text" : "Exclusive to CNN, President Obama's mission to Mars: We can reach beyond earth's orbit https:\/\/t.co\/raXQmLOudr https:\/\/t.co\/UrfddAaRBO",
    "id" : 785828552398761984,
    "created_at" : "2016-10-11 13:05:01 +0000",
    "user" : {
      "name" : "CNN",
      "screen_name" : "CNN",
      "protected" : false,
      "id_str" : "759251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508960761826131968\/LnvhR8ED_normal.png",
      "id" : 759251,
      "verified" : true
    }
  },
  "id" : 785831269825449984,
  "created_at" : "2016-10-11 13:15:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldMentalHealthDay",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785605380202266624",
  "text" : "Today, we recommit to ensuring Americans with mental health conditions know they are not alone\u2014and healing is possible #WorldMentalHealthDay",
  "id" : 785605380202266624,
  "created_at" : "2016-10-10 22:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/785517756032569346\/video\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/FXY8DoNdCo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
      "id_str" : "781143135065808901",
      "id" : 781143135065808901,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/FXY8DoNdCo"
    } ],
    "hashtags" : [ {
      "text" : "FAFSA",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785567760474640384",
  "text" : "RT @usedgov: Just a reminder ... you can now fill out your #FAFSA! Make plans to do it today! https:\/\/t.co\/FXY8DoNdCo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/785517756032569346\/video\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/FXY8DoNdCo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
        "id_str" : "781143135065808901",
        "id" : 781143135065808901,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtcuVjlWYAAP1UW.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/FXY8DoNdCo"
      } ],
      "hashtags" : [ {
        "text" : "FAFSA",
        "indices" : [ 46, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785517756032569346",
    "text" : "Just a reminder ... you can now fill out your #FAFSA! Make plans to do it today! https:\/\/t.co\/FXY8DoNdCo",
    "id" : 785517756032569346,
    "created_at" : "2016-10-10 16:30:01 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 785567760474640384,
  "created_at" : "2016-10-10 19:48:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Greiner",
      "screen_name" : "helengreiner",
      "indices" : [ 3, 16 ],
      "id_str" : "70174894",
      "id" : 70174894
    }, {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 38, 46 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 48, 62 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785533775341989889",
  "text" : "RT @helengreiner: I'm excited to join @Denis44, @SecretaryFoxx &amp; Eric Allison for this important conversation.  I hope you will join us. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denis McDonough",
        "screen_name" : "Denis44",
        "indices" : [ 20, 28 ],
        "id_str" : "3093573484",
        "id" : 3093573484
      }, {
        "name" : "Anthony Foxx",
        "screen_name" : "SecretaryFoxx",
        "indices" : [ 30, 44 ],
        "id_str" : "43920155",
        "id" : 43920155
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/oaxCId5i7n",
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785198298403639298",
        "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785234570383921152",
    "text" : "I'm excited to join @Denis44, @SecretaryFoxx &amp; Eric Allison for this important conversation.  I hope you will join us. https:\/\/t.co\/oaxCId5i7n",
    "id" : 785234570383921152,
    "created_at" : "2016-10-09 21:44:45 +0000",
    "user" : {
      "name" : "Helen Greiner",
      "screen_name" : "helengreiner",
      "protected" : false,
      "id_str" : "70174894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607620641156530177\/WgPo4nmg_normal.jpg",
      "id" : 70174894,
      "verified" : false
    }
  },
  "id" : 785533775341989889,
  "created_at" : "2016-10-10 17:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 41, 53 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785530236305670145\/photo\/1",
      "indices" : [ 145, 168 ],
      "url" : "https:\/\/t.co\/4Nzi7kRluO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CubDfC-VMAAvgwH.jpg",
      "id_str" : "785530123164397568",
      "id" : 785530123164397568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CubDfC-VMAAvgwH.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 929
      } ],
      "display_url" : "pic.twitter.com\/4Nzi7kRluO"
    } ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 135, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785530236305670145",
  "text" : "This morning, @POTUS spoke by phone with @CraigAtFEMA &amp; homeland security advisor Lisa Monaco on the ongoing response to Hurricane #Matthew. https:\/\/t.co\/4Nzi7kRluO",
  "id" : 785530236305670145,
  "created_at" : "2016-10-10 17:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/785510715830460416\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/WqNmoQuYIE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuax1M8VIAAcmiC.jpg",
      "id_str" : "785510712588181504",
      "id" : 785510712588181504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuax1M8VIAAcmiC.jpg",
      "sizes" : [ {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1201
      } ],
      "display_url" : "pic.twitter.com\/WqNmoQuYIE"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/OxNksAnHSI",
      "expanded_url" : "http:\/\/go.usa.gov\/xkgVU",
      "display_url" : "go.usa.gov\/xkgVU"
    } ]
  },
  "geo" : { },
  "id_str" : "785521225434923008",
  "text" : "RT @HHSGov: Open Enrollment starts November 1. Shop, compare and enroll! https:\/\/t.co\/OxNksAnHSI #GetCovered https:\/\/t.co\/WqNmoQuYIE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/785510715830460416\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/WqNmoQuYIE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuax1M8VIAAcmiC.jpg",
        "id_str" : "785510712588181504",
        "id" : 785510712588181504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuax1M8VIAAcmiC.jpg",
        "sizes" : [ {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1201
        } ],
        "display_url" : "pic.twitter.com\/WqNmoQuYIE"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 85, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/OxNksAnHSI",
        "expanded_url" : "http:\/\/go.usa.gov\/xkgVU",
        "display_url" : "go.usa.gov\/xkgVU"
      } ]
    },
    "geo" : { },
    "id_str" : "785510715830460416",
    "text" : "Open Enrollment starts November 1. Shop, compare and enroll! https:\/\/t.co\/OxNksAnHSI #GetCovered https:\/\/t.co\/WqNmoQuYIE",
    "id" : 785510715830460416,
    "created_at" : "2016-10-10 16:02:03 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 785521225434923008,
  "created_at" : "2016-10-10 16:43:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 117, 125 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 132, 146 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785488221039800322\/photo\/1",
      "indices" : [ 148, 171 ],
      "url" : "https:\/\/t.co\/A6ahnmbAOm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuadRGGUkAANWSJ.jpg",
      "id_str" : "785488102043193344",
      "id" : 785488102043193344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuadRGGUkAANWSJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/A6ahnmbAOm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785488221039800322",
  "text" : "Advances in science &amp; tech are transforming the future of our skies. Watch a LIVE discussion Tues. at 12pm ET w\/ @Denis44 &amp; @SecretaryFoxx. https:\/\/t.co\/A6ahnmbAOm",
  "id" : 785488221039800322,
  "created_at" : "2016-10-10 14:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Lemaitre",
      "screen_name" : "FEMAspox",
      "indices" : [ 3, 12 ],
      "id_str" : "2794913876",
      "id" : 2794913876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785480849311412224",
  "text" : "RT @FEMAspox: Latest on #Matthew:\n800+ FEMA boots on ground\n75 FEMA USAR rescues\n98 Emergency comms vehicles deployed\n2.8+ million meals &amp;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Matthew",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785461313099079680",
    "text" : "Latest on #Matthew:\n800+ FEMA boots on ground\n75 FEMA USAR rescues\n98 Emergency comms vehicles deployed\n2.8+ million meals &amp; water staged",
    "id" : 785461313099079680,
    "created_at" : "2016-10-10 12:45:44 +0000",
    "user" : {
      "name" : "Rafael Lemaitre",
      "screen_name" : "FEMAspox",
      "protected" : false,
      "id_str" : "2794913876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766051587819204609\/2apYvvvY_normal.jpg",
      "id" : 2794913876,
      "verified" : true
    }
  },
  "id" : 785480849311412224,
  "created_at" : "2016-10-10 14:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/4HkrsKK6DB",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/07\/white-house-frontiers-conference-robots-space-exploration-and-future-american",
      "display_url" : "whitehouse.gov\/blog\/2016\/10\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785479185091338240",
  "text" : "RT @DJ44: Join us on the next frontier Thurs! From AI to space to precision medicine its an awesome line up! \uD83C\uDDFA\uD83C\uDDF8\nhttps:\/\/t.co\/4HkrsKK6DB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/4HkrsKK6DB",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/07\/white-house-frontiers-conference-robots-space-exploration-and-future-american",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785454567722848256",
    "text" : "Join us on the next frontier Thurs! From AI to space to precision medicine its an awesome line up! \uD83C\uDDFA\uD83C\uDDF8\nhttps:\/\/t.co\/4HkrsKK6DB",
    "id" : 785454567722848256,
    "created_at" : "2016-10-10 12:18:56 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 785479185091338240,
  "created_at" : "2016-10-10 13:56:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5DMpxckmOJ",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "785219536584904704",
  "text" : ".@POTUS on Americans getting ahead:\nAffordable childcare \u2713\n\u2191 min wage \u2713\nEqual pay \u2713\nPaid family &amp; sick leave \u2713\nhttps:\/\/t.co\/5DMpxckmOJ",
  "id" : 785219536584904704,
  "created_at" : "2016-10-09 20:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 66, 74 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/785198298403639298\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/txYT8zwY2t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuWVdbvVUAEgYaJ.jpg",
      "id_str" : "785198042941050881",
      "id" : 785198042941050881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuWVdbvVUAEgYaJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/txYT8zwY2t"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tDkdRefDNY",
      "expanded_url" : "http:\/\/go.wh.gov\/91PTmv",
      "display_url" : "go.wh.gov\/91PTmv"
    } ]
  },
  "geo" : { },
  "id_str" : "785198298403639298",
  "text" : "We're at the forefront of a wave of innovation in our skies. Join @Denis44 for a live discussion Tuesday at 12pm ET: https:\/\/t.co\/tDkdRefDNY https:\/\/t.co\/txYT8zwY2t",
  "id" : 785198298403639298,
  "created_at" : "2016-10-09 19:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/5DMpxckmOJ",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "785189338237825024",
  "text" : "\"Last week...I took action to make sure up to 1 million more workers can earn 7 days of paid sick leave\" \u2014@POTUS: https:\/\/t.co\/5DMpxckmOJ",
  "id" : 785189338237825024,
  "created_at" : "2016-10-09 18:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minwage",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/5DMpxc2Lq9",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "785161655080542208",
  "text" : "Lower &amp; middle-income families saw the biggest income growth last year\u2014thanks in part to states raising #minwage: https:\/\/t.co\/5DMpxc2Lq9",
  "id" : 785161655080542208,
  "created_at" : "2016-10-09 16:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HurricaneMathew",
      "indices" : [ 43, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785160037366767616",
  "text" : "RT @fema: On the road in areas affected by #HurricaneMathew? Stay well away from flooded roads &amp; don't drive around barricades. Be smart, s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/785140699918241792\/photo\/1",
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/LjpBAZUbSj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuVgwOfVUAIl84j.jpg",
        "id_str" : "785140091685523458",
        "id" : 785140091685523458,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuVgwOfVUAIl84j.jpg",
        "sizes" : [ {
          "h" : 651,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/LjpBAZUbSj"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/785140699918241792\/photo\/1",
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/LjpBAZUbSj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuVgykPUsAA9e8w.jpg",
        "id_str" : "785140131883692032",
        "id" : 785140131883692032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuVgykPUsAA9e8w.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/LjpBAZUbSj"
      } ],
      "hashtags" : [ {
        "text" : "HurricaneMathew",
        "indices" : [ 33, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785140699918241792",
    "text" : "On the road in areas affected by #HurricaneMathew? Stay well away from flooded roads &amp; don't drive around barricades. Be smart, stay safe! https:\/\/t.co\/LjpBAZUbSj",
    "id" : 785140699918241792,
    "created_at" : "2016-10-09 15:31:44 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 785160037366767616,
  "created_at" : "2016-10-09 16:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5DMpxc2Lq9",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "785137746415190016",
  "text" : "\u201CAcross every race and age group in America, incomes rose and poverty rates fell.\u201D \u2014@POTUS on our economic progress: https:\/\/t.co\/5DMpxc2Lq9",
  "id" : 785137746415190016,
  "created_at" : "2016-10-09 15:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecondChances",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785136554616365056",
  "text" : "RT @LaborSec: It's not every day that I get a handwritten note, like this one from Liam, a man who benefits from #SecondChances: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecondChances",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/bXeDnidDHT",
        "expanded_url" : "https:\/\/medium.com\/@LaborSec\/a-new-start-in-new-haven-69e52c37e861#.5i4e22qcg",
        "display_url" : "medium.com\/@LaborSec\/a-ne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785107617412710400",
    "text" : "It's not every day that I get a handwritten note, like this one from Liam, a man who benefits from #SecondChances: https:\/\/t.co\/bXeDnidDHT",
    "id" : 785107617412710400,
    "created_at" : "2016-10-09 13:20:17 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 785136554616365056,
  "created_at" : "2016-10-09 15:15:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/5DMpxc2Lq9",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "785121215568498688",
  "text" : "It\u2019s time to put the politics aside and act on commonsense ideas. Watch @POTUS\u2019s weekly address: https:\/\/t.co\/5DMpxc2Lq9",
  "id" : 785121215568498688,
  "created_at" : "2016-10-09 14:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hail to Pitt",
      "screen_name" : "PittTweet",
      "indices" : [ 3, 13 ],
      "id_str" : "68503423",
      "id" : 68503423
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784859587124064260",
  "text" : "RT @PittTweet: .@POTUS will visit Pitt Thursday for a discussion on health care &amp; innovation frontiers as part of #WHFrontiers https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFrontiers",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/vlXHmOUMA6",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/07\/white-house-frontiers-conference-robots-space-exploration-and-future-american",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784509247853854721",
    "text" : ".@POTUS will visit Pitt Thursday for a discussion on health care &amp; innovation frontiers as part of #WHFrontiers https:\/\/t.co\/vlXHmOUMA6",
    "id" : 784509247853854721,
    "created_at" : "2016-10-07 21:42:34 +0000",
    "user" : {
      "name" : "Hail to Pitt",
      "screen_name" : "PittTweet",
      "protected" : false,
      "id_str" : "68503423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773167414494257152\/AHypGwQE_normal.jpg",
      "id" : 68503423,
      "verified" : false
    }
  },
  "id" : 784859587124064260,
  "created_at" : "2016-10-08 20:54:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5DMpxckmOJ",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "784850156789309440",
  "text" : "2015:\nFastest household income growth on record \u2713\nLargest drop in poverty rate since 1968 \u2713\n \n@POTUS on our economy: https:\/\/t.co\/5DMpxckmOJ",
  "id" : 784850156789309440,
  "created_at" : "2016-10-08 20:17:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 60, 65 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784816130624028676\/photo\/1",
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/BkBIkhJlMu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQ14qFXYAUWXTQ.jpg",
      "id_str" : "784811482555047941",
      "id" : 784811482555047941,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQ14qFXYAUWXTQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/BkBIkhJlMu"
    } ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Q7B4sGwqnV",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "784816130624028676",
  "text" : "Today, @POTUS received an update on Hurricane #Matthew from @FEMA Administrator Fugate. Take precautions: https:\/\/t.co\/Q7B4sGwqnV https:\/\/t.co\/BkBIkhJlMu",
  "id" : 784816130624028676,
  "created_at" : "2016-10-08 18:02:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784811722666348544",
  "text" : "RT @CEAChair: Since 2012, real wages have grown around 20 times faster than they did over the almost three decades between 1980 and 2007 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/784766729771585536\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/4uEqErJ2BV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQNKZnUIAYySzh.jpg",
        "id_str" : "784766707394945030",
        "id" : 784766707394945030,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQNKZnUIAYySzh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4uEqErJ2BV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "784766490499088385",
    "geo" : { },
    "id_str" : "784766729771585536",
    "in_reply_to_user_id" : 1861751828,
    "text" : "Since 2012, real wages have grown around 20 times faster than they did over the almost three decades between 1980 and 2007 https:\/\/t.co\/4uEqErJ2BV",
    "id" : 784766729771585536,
    "in_reply_to_status_id" : 784766490499088385,
    "created_at" : "2016-10-08 14:45:43 +0000",
    "in_reply_to_screen_name" : "CEAChair",
    "in_reply_to_user_id_str" : "1861751828",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 784811722666348544,
  "created_at" : "2016-10-08 17:44:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/5DMpxckmOJ",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "784805949764734978",
  "text" : "\u201CWorking families are finally seeing their wages and incomes rise.\u201D \u2014@POTUS. Get the facts: https:\/\/t.co\/5DMpxckmOJ",
  "id" : 784805949764734978,
  "created_at" : "2016-10-08 17:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/5DMpxc2Lq9",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "784761768727896064",
  "text" : "\u201CWe turned a recession into a record streak of job growth.\u201D \u2014@POTUS on our growing economy https:\/\/t.co\/5DMpxc2Lq9",
  "id" : 784761768727896064,
  "created_at" : "2016-10-08 14:26:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/5DMpxc2Lq9",
      "expanded_url" : "http:\/\/go.wh.gov\/RS8Apu",
      "display_url" : "go.wh.gov\/RS8Apu"
    } ]
  },
  "geo" : { },
  "id_str" : "784740277130973184",
  "text" : "In this week\u2019s address, @POTUS highlights the economic progress we\u2019ve made over the past eight years. Watch: https:\/\/t.co\/5DMpxc2Lq9",
  "id" : 784740277130973184,
  "created_at" : "2016-10-08 13:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 18, 29 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1of1million",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784553476944789504",
  "text" : "Each #1of1million @AmeriCorps members is living proof that people who love their country can change it. Congratulations on this milestone!",
  "id" : 784553476944789504,
  "created_at" : "2016-10-08 00:38:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shinola",
      "screen_name" : "Shinola",
      "indices" : [ 5, 13 ],
      "id_str" : "419719338",
      "id" : 419719338
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784508277740670976\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ruV8QoUk66",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuMiAMUUIAAMkwb.jpg",
      "id_str" : "784508146794373120",
      "id" : 784508146794373120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuMiAMUUIAAMkwb.jpg",
      "sizes" : [ {
        "h" : 1306,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1306,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/ruV8QoUk66"
    } ],
    "hashtags" : [ {
      "text" : "MFGDay16",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/bGe4BKUVCr",
      "expanded_url" : "http:\/\/go.wh.gov\/AUA8eC",
      "display_url" : "go.wh.gov\/AUA8eC"
    } ]
  },
  "geo" : { },
  "id_str" : "784508277740670976",
  "text" : "Read @Shinola\u2019s president on the enduring strength of American manufacturing: https:\/\/t.co\/bGe4BKUVCr #MFGDay16 https:\/\/t.co\/ruV8QoUk66",
  "id" : 784508277740670976,
  "created_at" : "2016-10-07 21:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Juan Manuel Santos",
      "screen_name" : "JuanManSantos",
      "indices" : [ 103, 117 ],
      "id_str" : "64839766",
      "id" : 64839766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784502571972960256",
  "text" : "RT @NSC44: Statement by @POTUS on the Awarding of the Nobel Peace Prize to Colombian President Santos (@JuanManSantos): https:\/\/t.co\/ZZRCtl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Juan Manuel Santos",
        "screen_name" : "JuanManSantos",
        "indices" : [ 92, 106 ],
        "id_str" : "64839766",
        "id" : 64839766
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/784491683073228800\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/YuoC9WdzQ8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuMTBGPVMAEpftr.jpg",
        "id_str" : "784491669668311041",
        "id" : 784491669668311041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuMTBGPVMAEpftr.jpg",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 1083
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 1083
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 1083
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/YuoC9WdzQ8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/ZZRCtluZbR",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/10\/07\/statement-president-awarding-nobel-peace-prize-colombian-president",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784491683073228800",
    "text" : "Statement by @POTUS on the Awarding of the Nobel Peace Prize to Colombian President Santos (@JuanManSantos): https:\/\/t.co\/ZZRCtluZbR https:\/\/t.co\/YuoC9WdzQ8",
    "id" : 784491683073228800,
    "created_at" : "2016-10-07 20:32:47 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 784502571972960256,
  "created_at" : "2016-10-07 21:16:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784497978128105476\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/PjEw70aTCp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuMXoqWVMAAFYPD.jpg",
      "id_str" : "784496747422756864",
      "id" : 784496747422756864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuMXoqWVMAAFYPD.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/PjEw70aTCp"
    } ],
    "hashtags" : [ {
      "text" : "MFGDay16",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784497978128105476",
  "text" : "Since 2010, we\u2019ve:\nAdded more than 800,000 manufacturing jobs \u2714 \nWitnessed the fastest manufacturing job growth since the 1990s \u2714 \n#MFGDay16 https:\/\/t.co\/PjEw70aTCp",
  "id" : 784497978128105476,
  "created_at" : "2016-10-07 20:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rise",
      "screen_name" : "RiseNowUS",
      "indices" : [ 83, 93 ],
      "id_str" : "2961466710",
      "id" : 2961466710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784454639550799872",
  "text" : "RT @vj44: .@POTUS just signed the sexual assault survivor bill of rights. Congrats @risenowus &amp; all who work to end sexual assault every da\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Rise",
        "screen_name" : "RiseNowUS",
        "indices" : [ 73, 83 ],
        "id_str" : "2961466710",
        "id" : 2961466710
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 136, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784453074240741376",
    "text" : ".@POTUS just signed the sexual assault survivor bill of rights. Congrats @risenowus &amp; all who work to end sexual assault every day! #ItsOnUs",
    "id" : 784453074240741376,
    "created_at" : "2016-10-07 17:59:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 784454639550799872,
  "created_at" : "2016-10-07 18:05:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784452328690561024\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/apKy5xCgdX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuLvI_yWgAABuQ-.jpg",
      "id_str" : "784452222956503040",
      "id" : 784452222956503040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuLvI_yWgAABuQ-.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/apKy5xCgdX"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784452328690561024",
  "text" : "Great news: Thanks to the #ACA, the share of Americans without health insurance has fallen to an all-time low. https:\/\/t.co\/apKy5xCgdX",
  "id" : 784452328690561024,
  "created_at" : "2016-10-07 17:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784446944345153536\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/Vw84GDtBrk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuLhylIWYAAQ58p.jpg",
      "id_str" : "784437544192729088",
      "id" : 784437544192729088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuLhylIWYAAQ58p.jpg",
      "sizes" : [ {
        "h" : 1400,
        "resize" : "fit",
        "w" : 2065
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 814,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1388,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Vw84GDtBrk"
    } ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6voo6pu0NC",
      "expanded_url" : "http:\/\/go.wh.gov\/6YY4UA",
      "display_url" : "go.wh.gov\/6YY4UA"
    } ]
  },
  "geo" : { },
  "id_str" : "784446944345153536",
  "text" : "\u201CThis is still a really dangerous hurricane\u201D \u2014@POTUS on #Matthew. Learn how you can prepare and help those affected: https:\/\/t.co\/6voo6pu0NC https:\/\/t.co\/Vw84GDtBrk",
  "id" : 784446944345153536,
  "created_at" : "2016-10-07 17:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784437050460086272\/photo\/1",
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/NGB9iqq7ie",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuLhQnhXEAE1Q86.jpg",
      "id_str" : "784436960718950401",
      "id" : 784436960718950401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuLhQnhXEAE1Q86.jpg",
      "sizes" : [ {
        "h" : 458,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 809,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2025
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2025
      } ],
      "display_url" : "pic.twitter.com\/NGB9iqq7ie"
    } ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6voo6pu0NC",
      "expanded_url" : "http:\/\/go.wh.gov\/6YY4UA",
      "display_url" : "go.wh.gov\/6YY4UA"
    } ]
  },
  "geo" : { },
  "id_str" : "784437050460086272",
  "text" : "Today, @POTUS received an update on Hurricane #Matthew from his national security team. Here\u2019s the latest: https:\/\/t.co\/6voo6pu0NC https:\/\/t.co\/NGB9iqq7ie",
  "id" : 784437050460086272,
  "created_at" : "2016-10-07 16:55:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784421248965062657\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/FWm9dUBJIK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuLStJ0VIAAswL4.jpg",
      "id_str" : "784420958287241216",
      "id" : 784420958287241216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuLStJ0VIAAswL4.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/FWm9dUBJIK"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/MQdfHMaVDA",
      "expanded_url" : "http:\/\/go.wh.gov\/UneCUC",
      "display_url" : "go.wh.gov\/UneCUC"
    } ]
  },
  "geo" : { },
  "id_str" : "784421248965062657",
  "text" : "FACT: American businesses have added over 15 million jobs over 6.5 years of job growth \u2192 https:\/\/t.co\/MQdfHMaVDA #JobsReport https:\/\/t.co\/FWm9dUBJIK",
  "id" : 784421248965062657,
  "created_at" : "2016-10-07 15:52:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/MQdfHMaVDA",
      "expanded_url" : "http:\/\/go.wh.gov\/UneCUC",
      "display_url" : "go.wh.gov\/UneCUC"
    } ]
  },
  "geo" : { },
  "id_str" : "784403471076171777",
  "text" : "Our economy added 156,000 jobs in September\u2014extending the longest streak of total job growth on record \u2192 https:\/\/t.co\/MQdfHMaVDA #JobsReport",
  "id" : 784403471076171777,
  "created_at" : "2016-10-07 14:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784397289192239104\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/jkhB4i1qC4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuK8yZVVYAAfbtz.jpg",
      "id_str" : "784396859095736320",
      "id" : 784396859095736320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuK8yZVVYAAfbtz.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/jkhB4i1qC4"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/MQdfHMaVDA",
      "expanded_url" : "http:\/\/go.wh.gov\/UneCUC",
      "display_url" : "go.wh.gov\/UneCUC"
    } ]
  },
  "geo" : { },
  "id_str" : "784397289192239104",
  "text" : "Good news: Our businesses have added over 15 million jobs over the past 79 months \u2192 https:\/\/t.co\/MQdfHMaVDA #JobsReport https:\/\/t.co\/jkhB4i1qC4",
  "id" : 784397289192239104,
  "created_at" : "2016-10-07 14:17:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Vaf8Xubs0s",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "784172430784770049",
  "text" : "RT @POTUS: Hurricane Matthew is as serious as it gets. Listen to local officials, prepare, take care of each other. https:\/\/t.co\/Vaf8Xubs0s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Vaf8Xubs0s",
        "expanded_url" : "http:\/\/Ready.gov",
        "display_url" : "Ready.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "784170804279992320",
    "text" : "Hurricane Matthew is as serious as it gets. Listen to local officials, prepare, take care of each other. https:\/\/t.co\/Vaf8Xubs0s",
    "id" : 784170804279992320,
    "created_at" : "2016-10-06 23:17:43 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 784172430784770049,
  "created_at" : "2016-10-06 23:24:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/6voo6pu0NC",
      "expanded_url" : "http:\/\/go.wh.gov\/6YY4UA",
      "display_url" : "go.wh.gov\/6YY4UA"
    } ]
  },
  "geo" : { },
  "id_str" : "784145440501489664",
  "text" : "Today @POTUS called the governors in GA, SC, NC, and FL about preparations ahead of Hurricane #Matthew: https:\/\/t.co\/6voo6pu0NC",
  "id" : 784145440501489664,
  "created_at" : "2016-10-06 21:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784133608839589888\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/cxc1fdmiUE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuHMinYWgAAGhPI.jpg",
      "id_str" : "784132705197916160",
      "id" : 784132705197916160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuHMinYWgAAGhPI.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 993
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 993
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 993
      } ],
      "display_url" : "pic.twitter.com\/cxc1fdmiUE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/hQztO31mi6",
      "expanded_url" : "http:\/\/go.wh.gov\/Qy1Gg9",
      "display_url" : "go.wh.gov\/Qy1Gg9"
    } ]
  },
  "geo" : { },
  "id_str" : "784133608839589888",
  "text" : ".@POTUS just granted commutations to another 102 people who have shown that they are deserving of a second chance: https:\/\/t.co\/hQztO31mi6 https:\/\/t.co\/cxc1fdmiUE",
  "id" : 784133608839589888,
  "created_at" : "2016-10-06 20:49:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784129076042735616",
  "text" : "RT @vj44: Since taking office, @POTUS has commuted the sentences of 774 men and women\u2014more than the past 11 presidents combined. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/784126630545412096\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/Gy4pHRD2gY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuHG62kWAAA5TqW.jpg",
        "id_str" : "784126524521840640",
        "id" : 784126524521840640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuHG62kWAAA5TqW.jpg",
        "sizes" : [ {
          "h" : 564,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Gy4pHRD2gY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "784126260649734144",
    "geo" : { },
    "id_str" : "784126630545412096",
    "in_reply_to_user_id" : 595515713,
    "text" : "Since taking office, @POTUS has commuted the sentences of 774 men and women\u2014more than the past 11 presidents combined. https:\/\/t.co\/Gy4pHRD2gY",
    "id" : 784126630545412096,
    "in_reply_to_status_id" : 784126260649734144,
    "created_at" : "2016-10-06 20:22:11 +0000",
    "in_reply_to_screen_name" : "vj44",
    "in_reply_to_user_id_str" : "595515713",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 784129076042735616,
  "created_at" : "2016-10-06 20:31:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/784123156923420672\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/734VSwYzsS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuHB2jwVIAEHDOM.jpg",
      "id_str" : "784120953194225665",
      "id" : 784120953194225665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuHB2jwVIAEHDOM.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/734VSwYzsS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784123156923420672",
  "text" : "BREAKING: @POTUS just commuted the sentences of 102 people, bringing the total to more than the past 11 presidents combined. https:\/\/t.co\/734VSwYzsS",
  "id" : 784123156923420672,
  "created_at" : "2016-10-06 20:08:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784118954339864577\/photo\/1",
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/zr9VULntD5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuG_upuUIAA3Lqc.jpg",
      "id_str" : "784118618334175232",
      "id" : 784118618334175232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuG_upuUIAA3Lqc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1292,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1292,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 775,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zr9VULntD5"
    } ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/6voo6pu0NC",
      "expanded_url" : "http:\/\/go.wh.gov\/6YY4UA",
      "display_url" : "go.wh.gov\/6YY4UA"
    } ]
  },
  "geo" : { },
  "id_str" : "784118954339864577",
  "text" : "Today, @POTUS declared a state of emergency in Florida ahead of Hurricane #Matthew. Here\u2019s what you need to know: https:\/\/t.co\/6voo6pu0NC https:\/\/t.co\/zr9VULntD5",
  "id" : 784118954339864577,
  "created_at" : "2016-10-06 19:51:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 12, 19 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784110761052221440\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/e4bhBY9UMJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuG2OHjUsAAT70O.jpg",
      "id_str" : "784108163800805376",
      "id" : 784108163800805376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuG2OHjUsAAT70O.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/e4bhBY9UMJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Hys40q7QvK",
      "expanded_url" : "http:\/\/go.wh.gov\/vJadaZ",
      "display_url" : "go.wh.gov\/vJadaZ"
    } ]
  },
  "geo" : { },
  "id_str" : "784110761052221440",
  "text" : "Watch live: @FLOTUS welcomes students, along with some special guests, for her final harvest of the Kitchen Garden: https:\/\/t.co\/Hys40q7QvK https:\/\/t.co\/e4bhBY9UMJ",
  "id" : 784110761052221440,
  "created_at" : "2016-10-06 19:19:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Readygov",
      "screen_name" : "Readygov",
      "indices" : [ 3, 12 ],
      "id_str" : "16028241",
      "id" : 16028241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HurricaneMatthew",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784087791579848704",
  "text" : "RT @Readygov: It's not too late to talk with your family about how you'll stay in touch throughout #HurricaneMatthew. Send a text, email, D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Readygov\/status\/784017418893099008\/video\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/ZsG0mQwgEM",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/784017370381713408\/pu\/img\/KwK1CpuWp9TkpYGU.jpg",
        "id_str" : "784017370381713408",
        "id" : 784017370381713408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/784017370381713408\/pu\/img\/KwK1CpuWp9TkpYGU.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZsG0mQwgEM"
      } ],
      "hashtags" : [ {
        "text" : "HurricaneMatthew",
        "indices" : [ 85, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784017418893099008",
    "text" : "It's not too late to talk with your family about how you'll stay in touch throughout #HurricaneMatthew. Send a text, email, DM--NOW. https:\/\/t.co\/ZsG0mQwgEM",
    "id" : 784017418893099008,
    "created_at" : "2016-10-06 13:08:13 +0000",
    "user" : {
      "name" : "Readygov",
      "screen_name" : "Readygov",
      "protected" : false,
      "id_str" : "16028241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646417752811532288\/D4M4w2f0_normal.jpg",
      "id" : 16028241,
      "verified" : true
    }
  },
  "id" : 784087791579848704,
  "created_at" : "2016-10-06 17:47:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 7, 16 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Q7B4sGwqnV",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/S2B2V63KDu",
      "expanded_url" : "http:\/\/snpy.tv\/2dNLy9B",
      "display_url" : "snpy.tv\/2dNLy9B"
    } ]
  },
  "geo" : { },
  "id_str" : "784075752190926848",
  "text" : "Today, @PressSec provided the latest on preparations for Hurricane #Matthew. Be prepared: https:\/\/t.co\/Q7B4sGwqnV https:\/\/t.co\/S2B2V63KDu",
  "id" : 784075752190926848,
  "created_at" : "2016-10-06 17:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/AwD0K2fkAS",
      "expanded_url" : "http:\/\/snpy.tv\/2e5OyCz",
      "display_url" : "snpy.tv\/2e5OyCz"
    } ]
  },
  "geo" : { },
  "id_str" : "784070573294968836",
  "text" : "\"Let\u2019s give it up for the Pittsburgh Penguins!\" \u2014@POTUS with the 2016 Stanley Cup Champions https:\/\/t.co\/AwD0K2fkAS",
  "id" : 784070573294968836,
  "created_at" : "2016-10-06 16:39:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pittsburgh Penguins",
      "screen_name" : "penguins",
      "indices" : [ 130, 139 ],
      "id_str" : "15020865",
      "id" : 15020865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784065604906999808",
  "text" : "\u201CIn my first year, you guys won the Cup \u2013 and now your coming back for my final year.\u201D \u2014@POTUS with the 2016 Stanley Cup Champion @Penguins",
  "id" : 784065604906999808,
  "created_at" : "2016-10-06 16:19:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pittsburgh Penguins",
      "screen_name" : "penguins",
      "indices" : [ 84, 93 ],
      "id_str" : "15020865",
      "id" : 15020865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PensAndPOTUS",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/a0eBkmgZ1E",
      "expanded_url" : "http:\/\/go.wh.gov\/qRj6bV",
      "display_url" : "go.wh.gov\/qRj6bV"
    } ]
  },
  "geo" : { },
  "id_str" : "784065082917396481",
  "text" : "RT @WHLive: Happening now: @POTUS welcomes the 2016 Stanley Cup Champion Pittsburgh @penguins: https:\/\/t.co\/a0eBkmgZ1E #PensAndPOTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Pittsburgh Penguins",
        "screen_name" : "penguins",
        "indices" : [ 72, 81 ],
        "id_str" : "15020865",
        "id" : 15020865
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PensAndPOTUS",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/a0eBkmgZ1E",
        "expanded_url" : "http:\/\/go.wh.gov\/qRj6bV",
        "display_url" : "go.wh.gov\/qRj6bV"
      } ]
    },
    "geo" : { },
    "id_str" : "784064967850889216",
    "text" : "Happening now: @POTUS welcomes the 2016 Stanley Cup Champion Pittsburgh @penguins: https:\/\/t.co\/a0eBkmgZ1E #PensAndPOTUS",
    "id" : 784064967850889216,
    "created_at" : "2016-10-06 16:17:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 784065082917396481,
  "created_at" : "2016-10-06 16:17:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 43, 50 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/jhrwzDO2ke",
      "expanded_url" : "https:\/\/medium.com\/@DrBiden\/why-im-going-to-cuba-and-the-dominican-republic-c3aa97306a4#.1cjby9d8v",
      "display_url" : "medium.com\/@DrBiden\/why-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784063456622153728",
  "text" : "RT @DrBiden: Check out Dr. Biden's note on @Medium about her upcoming trip to Cuba and the Dominican Republic \u2192 https:\/\/t.co\/jhrwzDO2ke htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 30, 37 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/784033330979299328\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/Fc9p8lhLQH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuFxleZUkAAiKF6.jpg",
        "id_str" : "784032698767544320",
        "id" : 784032698767544320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuFxleZUkAAiKF6.jpg",
        "sizes" : [ {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2726,
          "resize" : "fit",
          "w" : 4096
        } ],
        "display_url" : "pic.twitter.com\/Fc9p8lhLQH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/jhrwzDO2ke",
        "expanded_url" : "https:\/\/medium.com\/@DrBiden\/why-im-going-to-cuba-and-the-dominican-republic-c3aa97306a4#.1cjby9d8v",
        "display_url" : "medium.com\/@DrBiden\/why-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784033330979299328",
    "text" : "Check out Dr. Biden's note on @Medium about her upcoming trip to Cuba and the Dominican Republic \u2192 https:\/\/t.co\/jhrwzDO2ke https:\/\/t.co\/Fc9p8lhLQH",
    "id" : 784033330979299328,
    "created_at" : "2016-10-06 14:11:27 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 784063456622153728,
  "created_at" : "2016-10-06 16:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pittsburgh Penguins",
      "screen_name" : "penguins",
      "indices" : [ 78, 87 ],
      "id_str" : "15020865",
      "id" : 15020865
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/784059255141785600\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ytxRad3ISl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuGJktwUEAAxwkm.jpg",
      "id_str" : "784059073989709824",
      "id" : 784059073989709824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuGJktwUEAAxwkm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ytxRad3ISl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/KOy1WQeVW6",
      "expanded_url" : "http:\/\/go.wh.gov\/qRj6bV",
      "display_url" : "go.wh.gov\/qRj6bV"
    } ]
  },
  "geo" : { },
  "id_str" : "784059255141785600",
  "text" : "At 12pm ET, watch as @POTUS welcomes the 2016 Stanley Cup Champion Pittsburgh @Penguins: https:\/\/t.co\/KOy1WQeVW6 https:\/\/t.co\/ytxRad3ISl",
  "id" : 784059255141785600,
  "created_at" : "2016-10-06 15:54:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/BbvvMEaQTF",
      "expanded_url" : "http:\/\/WH.gov\/SXSL",
      "display_url" : "WH.gov\/SXSL"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/RZUm1H3Mxf",
      "expanded_url" : "http:\/\/snpy.tv\/2e5DLIk",
      "display_url" : "snpy.tv\/2e5DLIk"
    } ]
  },
  "geo" : { },
  "id_str" : "784056427979665408",
  "text" : "This is #SXSL: The White House festival of ideas, art, and action. Take a peek inside: https:\/\/t.co\/BbvvMEaQTF https:\/\/t.co\/RZUm1H3Mxf",
  "id" : 784056427979665408,
  "created_at" : "2016-10-06 15:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/tA2h9QcJ3W",
      "expanded_url" : "http:\/\/go.wh.gov\/z3NCC7",
      "display_url" : "go.wh.gov\/z3NCC7"
    } ]
  },
  "geo" : { },
  "id_str" : "784053099803529216",
  "text" : "Chloe from Illinois wrote @POTUS about the challenges she'd like to see her rural town overcome. Read his reply \u2192 https:\/\/t.co\/tA2h9QcJ3W",
  "id" : 784053099803529216,
  "created_at" : "2016-10-06 15:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784046794644652033\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tuQxgTjMmx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuF99zeUMAMWvig.jpg",
      "id_str" : "784046310882029571",
      "id" : 784046310882029571,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuF99zeUMAMWvig.jpg",
      "sizes" : [ {
        "h" : 1045,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1045,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1045,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/tuQxgTjMmx"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/784046794644652033\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/tuQxgTjMmx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuF9_hWUsAMTR03.jpg",
      "id_str" : "784046340376408067",
      "id" : 784046340376408067,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuF9_hWUsAMTR03.jpg",
      "sizes" : [ {
        "h" : 1044,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1044,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 1044,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/tuQxgTjMmx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/tA2h9QcJ3W",
      "expanded_url" : "http:\/\/go.wh.gov\/z3NCC7",
      "display_url" : "go.wh.gov\/z3NCC7"
    } ]
  },
  "geo" : { },
  "id_str" : "784046794644652033",
  "text" : "Rural communities are the backbone of our nation. Read @POTUS\u2019s letter to Chloe in Illinois: https:\/\/t.co\/tA2h9QcJ3W https:\/\/t.co\/tuQxgTjMmx",
  "id" : 784046794644652033,
  "created_at" : "2016-10-06 15:04:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityProject",
      "indices" : [ 33, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784025379778494464",
  "text" : "RT @Cecilia44: Starting now! The #OpportunityProject is expanding + releasing new tools to create opportunities in your community: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityProject",
        "indices" : [ 18, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/dseVZZL0YC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "784015997942411264",
    "text" : "Starting now! The #OpportunityProject is expanding + releasing new tools to create opportunities in your community: https:\/\/t.co\/dseVZZL0YC",
    "id" : 784015997942411264,
    "created_at" : "2016-10-06 13:02:34 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 784025379778494464,
  "created_at" : "2016-10-06 13:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/783970835300245504\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LWk23pZQVZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuE5UWnXEAAHNch.jpg",
      "id_str" : "783970831970013184",
      "id" : 783970831970013184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuE5UWnXEAAHNch.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1911
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1911
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/LWk23pZQVZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/OMjy0zqc0U",
      "expanded_url" : "http:\/\/econ.st\/2dMRvod",
      "display_url" : "econ.st\/2dMRvod"
    } ]
  },
  "geo" : { },
  "id_str" : "784022531133112320",
  "text" : "RT @TheEconomist: President Obama lays out the main economic challenges facing his successor https:\/\/t.co\/OMjy0zqc0U https:\/\/t.co\/LWk23pZQVZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheEconomist\/status\/783970835300245504\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/LWk23pZQVZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuE5UWnXEAAHNch.jpg",
        "id_str" : "783970831970013184",
        "id" : 783970831970013184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuE5UWnXEAAHNch.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1911
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1911
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/LWk23pZQVZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/OMjy0zqc0U",
        "expanded_url" : "http:\/\/econ.st\/2dMRvod",
        "display_url" : "econ.st\/2dMRvod"
      } ]
    },
    "geo" : { },
    "id_str" : "783970835300245504",
    "text" : "President Obama lays out the main economic challenges facing his successor https:\/\/t.co\/OMjy0zqc0U https:\/\/t.co\/LWk23pZQVZ",
    "id" : 783970835300245504,
    "created_at" : "2016-10-06 10:03:07 +0000",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461499742950678528\/2JnpHjUo_normal.png",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 784022531133112320,
  "created_at" : "2016-10-06 13:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vywVyLiXFT",
      "expanded_url" : "http:\/\/snpy.tv\/2cT3vI5",
      "display_url" : "snpy.tv\/2cT3vI5"
    } ]
  },
  "geo" : { },
  "id_str" : "783792633328046081",
  "text" : "Today, @POTUS received a briefing on Hurricane #Matthew, which could soon affect areas all across the Southeast. https:\/\/t.co\/vywVyLiXFT",
  "id" : 783792633328046081,
  "created_at" : "2016-10-05 22:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/zeToNxDjUc",
      "expanded_url" : "http:\/\/ready.gov",
      "display_url" : "ready.gov"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/vywVyLAyxr",
      "expanded_url" : "http:\/\/snpy.tv\/2cT3vI5",
      "display_url" : "snpy.tv\/2cT3vI5"
    } ]
  },
  "geo" : { },
  "id_str" : "783781308346437632",
  "text" : "Watch @POTUS give an update on Hurricane #Matthew\u2014and learn how you can prepare at https:\/\/t.co\/zeToNxDjUc: https:\/\/t.co\/vywVyLAyxr",
  "id" : 783781308346437632,
  "created_at" : "2016-10-05 21:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/TFijImTbyH",
      "expanded_url" : "http:\/\/go.wh.gov\/climate",
      "display_url" : "go.wh.gov\/climate"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/pOZN7DSeWr",
      "expanded_url" : "http:\/\/snpy.tv\/2dLxyCs",
      "display_url" : "snpy.tv\/2dLxyCs"
    } ]
  },
  "geo" : { },
  "id_str" : "783777536295645184",
  "text" : "No nation can #ActOnClimate alone. All of us have to solve it together: https:\/\/t.co\/TFijImTbyH https:\/\/t.co\/pOZN7DSeWr",
  "id" : 783777536295645184,
  "created_at" : "2016-10-05 21:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783776651230322689",
  "text" : "RT @GinaEPA: Today's a historic day! As the Paris Agreement goes into force, we\u2019ll continue to cut GHG emissions &amp; #ActOnClimate. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/783760665282506752\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/4TWYi9pilR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuB6G4OXgAA8jTb.jpg",
        "id_str" : "783760593752915968",
        "id" : 783760593752915968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuB6G4OXgAA8jTb.jpg",
        "sizes" : [ {
          "h" : 184,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 671
        } ],
        "display_url" : "pic.twitter.com\/4TWYi9pilR"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 106, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783760665282506752",
    "text" : "Today's a historic day! As the Paris Agreement goes into force, we\u2019ll continue to cut GHG emissions &amp; #ActOnClimate. https:\/\/t.co\/4TWYi9pilR",
    "id" : 783760665282506752,
    "created_at" : "2016-10-05 20:07:58 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 783776651230322689,
  "created_at" : "2016-10-05 21:11:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783774844181553152",
  "text" : "RT @ErnestMoniz: Today, the world passed the threshold for the #ParisAgreement to enter into force. This is just the beginning. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/783771522863210496\/video\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/827c5L730d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuCDtONVIAAhCYu.jpg",
        "id_str" : "783770451512262657",
        "id" : 783770451512262657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuCDtONVIAAhCYu.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/827c5L730d"
      } ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 46, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/kaHGQ2gpgY",
        "expanded_url" : "http:\/\/energy.gov\/articles\/secretary-moniz-statement-reaching-threshold-paris-agreement-s-entry-force",
        "display_url" : "energy.gov\/articles\/secre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783771522863210496",
    "text" : "Today, the world passed the threshold for the #ParisAgreement to enter into force. This is just the beginning. https:\/\/t.co\/kaHGQ2gpgY https:\/\/t.co\/827c5L730d",
    "id" : 783771522863210496,
    "created_at" : "2016-10-05 20:51:07 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 783774844181553152,
  "created_at" : "2016-10-05 21:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783772316849147904",
  "text" : "RT @POTUS: Thank you to every nation that moved to bring the Paris Agreement into force. History will judge today as a turning point for ou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783771904297447424",
    "text" : "Thank you to every nation that moved to bring the Paris Agreement into force. History will judge today as a turning point for our planet.",
    "id" : 783771904297447424,
    "created_at" : "2016-10-05 20:52:38 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 783772316849147904,
  "created_at" : "2016-10-05 20:54:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/783770793809285120\/photo\/1",
      "indices" : [ 126, 149 ],
      "url" : "https:\/\/t.co\/ZDP7BYygOE",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuCDMcmUsAAQ12v.jpg",
      "id_str" : "783770585021067264",
      "id" : 783770585021067264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuCDMcmUsAAQ12v.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZDP7BYygOE"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/TFijImTbyH",
      "expanded_url" : "http:\/\/go.wh.gov\/climate",
      "display_url" : "go.wh.gov\/climate"
    } ]
  },
  "geo" : { },
  "id_str" : "783770793809285120",
  "text" : "Today @POTUS marked a historic moment in our global efforts to #ActOnClimate. See how far we've come: https:\/\/t.co\/TFijImTbyH https:\/\/t.co\/ZDP7BYygOE",
  "id" : 783770793809285120,
  "created_at" : "2016-10-05 20:48:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 87, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/pOZN7DSeWr",
      "expanded_url" : "http:\/\/snpy.tv\/2dLxyCs",
      "display_url" : "snpy.tv\/2dLxyCs"
    } ]
  },
  "geo" : { },
  "id_str" : "783754458257723393",
  "text" : "\u201CThis gives us the best possible shot to save the one planet we\u2019ve got\u201D \u2014@POTUS on the #ParisAgreement   https:\/\/t.co\/pOZN7DSeWr",
  "id" : 783754458257723393,
  "created_at" : "2016-10-05 19:43:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783753054982017024",
  "text" : "\u201CNo nation, not even one as powerful as ours, can solve this challenge alone. All of us have to solve it together.\u201D \u2014@POTUS #ActOnClimate",
  "id" : 783753054982017024,
  "created_at" : "2016-10-05 19:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783752619143536640\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/XSeAPQMHic",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuBywM6XYAEurZk.jpg",
      "id_str" : "783752507587780609",
      "id" : 783752507587780609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuBywM6XYAEurZk.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/XSeAPQMHic"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783752619143536640",
  "text" : "\u201CWe drove economic output to new highs and we drove our carbon pollution to its lowest levels in two decades.\u201D \u2014@POTUS #ActOnClimate https:\/\/t.co\/XSeAPQMHic",
  "id" : 783752619143536640,
  "created_at" : "2016-10-05 19:36:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783751803011600384\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/3bSCf8J6Te",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuBx-a2WIAEMYNY.jpg",
      "id_str" : "783751652335558657",
      "id" : 783751652335558657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuBx-a2WIAEMYNY.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3bSCf8J6Te"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 51, 66 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783751803011600384",
  "text" : "\u201CToday the world has crossed the threshold for the #ParisAgreement to take effect\"  \u2014@POTUS #ActOnClimate https:\/\/t.co\/3bSCf8J6Te",
  "id" : 783751803011600384,
  "created_at" : "2016-10-05 19:32:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783751539328294913\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/Iop7LA5kxo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuBx3CTXYAAPBSz.jpg",
      "id_str" : "783751525487304704",
      "id" : 783751525487304704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuBx3CTXYAAPBSz.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2670
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1432,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Iop7LA5kxo"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783751539328294913\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/Iop7LA5kxo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuBx3ClWgAEmjdZ.jpg",
      "id_str" : "783751525562744833",
      "id" : 783751525562744833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuBx3ClWgAEmjdZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Iop7LA5kxo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783751539328294913",
  "text" : "\u201CLast month, the United States and China\u2014the world\u2019s two largest economies and largest emitters\u2014formally joined that agreement\u201D \u2014@POTUS https:\/\/t.co\/Iop7LA5kxo",
  "id" : 783751539328294913,
  "created_at" : "2016-10-05 19:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7sH5Fyk9R7",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/8e5e2209-a35d-4cb7-9d03-6fa822b2633e",
      "display_url" : "amp.twimg.com\/v\/8e5e2209-a35\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783751368649551872",
  "text" : "\"In Paris, I said before the world that we needed a strong global agreement to reduce carbon pollution\" \u2014@POTUS https:\/\/t.co\/7sH5Fyk9R7",
  "id" : 783751368649551872,
  "created_at" : "2016-10-05 19:31:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783744238508847104\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/PcTHExizTk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuBqk5yUkAAqxxy.jpg",
      "id_str" : "783743517382184960",
      "id" : 783743517382184960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuBqk5yUkAAqxxy.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/PcTHExizTk"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/TFijImTbyH",
      "expanded_url" : "http:\/\/go.wh.gov\/climate",
      "display_url" : "go.wh.gov\/climate"
    } ]
  },
  "geo" : { },
  "id_str" : "783744238508847104",
  "text" : "At 3:30pm ET, @POTUS will deliver a statement in the Rose garden on the #ParisAgreement: https:\/\/t.co\/TFijImTbyH #ActOnClimate https:\/\/t.co\/PcTHExizTk",
  "id" : 783744238508847104,
  "created_at" : "2016-10-05 19:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783742330809487360",
  "text" : "RT @PressSec: Breaking: @POTUS will provide an update from the Rose Garden on the #ParisAgreement at 3:30pm ET. Tune in: https:\/\/t.co\/EfjOH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 68, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/EfjOH4S1ML",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "783741954798608384",
    "text" : "Breaking: @POTUS will provide an update from the Rose Garden on the #ParisAgreement at 3:30pm ET. Tune in: https:\/\/t.co\/EfjOH4S1ML",
    "id" : 783741954798608384,
    "created_at" : "2016-10-05 18:53:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 783742330809487360,
  "created_at" : "2016-10-05 18:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783703867808681985\/photo\/1",
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/9Xr91BJFJv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuBANJBWcAQjwSr.jpg",
      "id_str" : "783696929666527236",
      "id" : 783696929666527236,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuBANJBWcAQjwSr.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/9Xr91BJFJv"
    } ],
    "hashtags" : [ {
      "text" : "WorldTeachersDay",
      "indices" : [ 5, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783703867808681985",
  "text" : "This #WorldTeachersDay, we celebrate the men &amp; women who teach our kids to fulfill the promise of a nation that's always looking forward. https:\/\/t.co\/9Xr91BJFJv",
  "id" : 783703867808681985,
  "created_at" : "2016-10-05 16:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783701246708441089",
  "text" : "RT @fema: Stay up-to-date as #Matthew makes its way toward the U.S. &amp; follow this list of trusted sources for the latest: https:\/\/t.co\/imjr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Matthew",
        "indices" : [ 19, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/imjr7rQo8n",
        "expanded_url" : "https:\/\/twitter.com\/FEMAlive\/lists\/happening-now",
        "display_url" : "twitter.com\/FEMAlive\/lists\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783668328409673730",
    "text" : "Stay up-to-date as #Matthew makes its way toward the U.S. &amp; follow this list of trusted sources for the latest: https:\/\/t.co\/imjr7rQo8n",
    "id" : 783668328409673730,
    "created_at" : "2016-10-05 14:01:04 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 783701246708441089,
  "created_at" : "2016-10-05 16:11:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 42, 47 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HurricaneMatthew",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783693188481646592",
  "text" : "RT @JFriedman44: Today, @POTUS will visit @fema headquarters to get a briefing on #HurricaneMatthew \n\nHere's what you can do to prepare: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 25, 30 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HurricaneMatthew",
        "indices" : [ 65, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/8dppZSxeSU",
        "expanded_url" : "https:\/\/twitter.com\/Readygov\/status\/783640336765779969",
        "display_url" : "twitter.com\/Readygov\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783659249910050816",
    "text" : "Today, @POTUS will visit @fema headquarters to get a briefing on #HurricaneMatthew \n\nHere's what you can do to prepare: https:\/\/t.co\/8dppZSxeSU",
    "id" : 783659249910050816,
    "created_at" : "2016-10-05 13:24:59 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 783693188481646592,
  "created_at" : "2016-10-05 15:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783689009046454277",
  "text" : "RT @AmbassadorRice: America's diversity is one of our greatest strengths. Drawing on it is a national security imperative. Here's why: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorRice\/status\/783682910838587392\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/7RSt6S8oRz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuAzZ_BVIAAMjE-.jpg",
        "id_str" : "783682856669224960",
        "id" : 783682856669224960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuAzZ_BVIAAMjE-.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/7RSt6S8oRz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/tDdJItXSf1",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/10\/05\/building-national-security-workforce-fully-reflects-america",
        "display_url" : "whitehouse.gov\/blog\/2016\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783682910838587392",
    "text" : "America's diversity is one of our greatest strengths. Drawing on it is a national security imperative. Here's why: https:\/\/t.co\/tDdJItXSf1 https:\/\/t.co\/7RSt6S8oRz",
    "id" : 783682910838587392,
    "created_at" : "2016-10-05 14:59:00 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 783689009046454277,
  "created_at" : "2016-10-05 15:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/783446605211037696\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/WvURuXNEWR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct9aPNeUAAANU_-.jpg",
      "id_str" : "783444077547094016",
      "id" : 783444077547094016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct9aPNeUAAANU_-.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 4400,
        "resize" : "fit",
        "w" : 3400
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1583
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 927
      } ],
      "display_url" : "pic.twitter.com\/WvURuXNEWR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/PqCtpZL7K4",
      "expanded_url" : "http:\/\/go.wh.gov\/cqCPCf",
      "display_url" : "go.wh.gov\/cqCPCf"
    } ]
  },
  "geo" : { },
  "id_str" : "783446605211037696",
  "text" : "During Filipino American History Month, we celebrate the ways Filipino Americans have helped shape our country: https:\/\/t.co\/PqCtpZL7K4 https:\/\/t.co\/WvURuXNEWR",
  "id" : 783446605211037696,
  "created_at" : "2016-10-04 23:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "indices" : [ 3, 8 ],
      "id_str" : "4073671214",
      "id" : 4073671214
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rD44\/status\/783437034241142790\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/emmmjiB1no",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct9TvYrUIAE6DDY.jpg",
      "id_str" : "783436933728837633",
      "id" : 783436933728837633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct9TvYrUIAE6DDY.jpg",
      "sizes" : [ {
        "h" : 790,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 999,
        "resize" : "fit",
        "w" : 1518
      }, {
        "h" : 999,
        "resize" : "fit",
        "w" : 1518
      } ],
      "display_url" : "pic.twitter.com\/emmmjiB1no"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/EeWinh0eAY",
      "expanded_url" : "https:\/\/medium.com\/the-white-house\/on-the-strength-and-resilience-of-rural-america-33144592637e#.1hz7ekmmi",
      "display_url" : "medium.com\/the-white-hous\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783440690562949120",
  "text" : "RT @rD44: Just in: @POTUS's tribute to innovative, dynamic rural America: https:\/\/t.co\/EeWinh0eAY https:\/\/t.co\/emmmjiB1no",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rD44\/status\/783437034241142790\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/emmmjiB1no",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct9TvYrUIAE6DDY.jpg",
        "id_str" : "783436933728837633",
        "id" : 783436933728837633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct9TvYrUIAE6DDY.jpg",
        "sizes" : [ {
          "h" : 790,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 999,
          "resize" : "fit",
          "w" : 1518
        }, {
          "h" : 999,
          "resize" : "fit",
          "w" : 1518
        } ],
        "display_url" : "pic.twitter.com\/emmmjiB1no"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/EeWinh0eAY",
        "expanded_url" : "https:\/\/medium.com\/the-white-house\/on-the-strength-and-resilience-of-rural-america-33144592637e#.1hz7ekmmi",
        "display_url" : "medium.com\/the-white-hous\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783437034241142790",
    "text" : "Just in: @POTUS's tribute to innovative, dynamic rural America: https:\/\/t.co\/EeWinh0eAY https:\/\/t.co\/emmmjiB1no",
    "id" : 783437034241142790,
    "created_at" : "2016-10-04 22:41:59 +0000",
    "user" : {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "protected" : false,
      "id_str" : "4073671214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664566060801216513\/-QEofkKM_normal.jpg",
      "id" : 4073671214,
      "verified" : true
    }
  },
  "id" : 783440690562949120,
  "created_at" : "2016-10-04 22:56:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "COMMON",
      "screen_name" : "common",
      "indices" : [ 3, 10 ],
      "id_str" : "17169320",
      "id" : 17169320
    }, {
      "name" : "nprmusic",
      "screen_name" : "nprmusic",
      "indices" : [ 20, 29 ],
      "id_str" : "13784592",
      "id" : 13784592
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tinydesk",
      "indices" : [ 32, 41 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Ttb5xPYDo2",
      "expanded_url" : "http:\/\/n.pr\/2dH5SKz",
      "display_url" : "n.pr\/2dH5SKz"
    } ]
  },
  "geo" : { },
  "id_str" : "783438539480559617",
  "text" : "RT @common: We took @nprmusic\u2019s #tinydesk and brought it all the way to the @WhiteHouse! #SXSL https:\/\/t.co\/Ttb5xPYDo2 This was EPIC!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nprmusic",
        "screen_name" : "nprmusic",
        "indices" : [ 8, 17 ],
        "id_str" : "13784592",
        "id" : 13784592
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tinydesk",
        "indices" : [ 20, 29 ]
      }, {
        "text" : "SXSL",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/Ttb5xPYDo2",
        "expanded_url" : "http:\/\/n.pr\/2dH5SKz",
        "display_url" : "n.pr\/2dH5SKz"
      } ]
    },
    "geo" : { },
    "id_str" : "783359890567864321",
    "text" : "We took @nprmusic\u2019s #tinydesk and brought it all the way to the @WhiteHouse! #SXSL https:\/\/t.co\/Ttb5xPYDo2 This was EPIC!",
    "id" : 783359890567864321,
    "created_at" : "2016-10-04 17:35:26 +0000",
    "user" : {
      "name" : "COMMON",
      "screen_name" : "common",
      "protected" : false,
      "id_str" : "17169320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795292316072366080\/i6dOR8P7_normal.jpg",
      "id" : 17169320,
      "verified" : true
    }
  },
  "id" : 783438539480559617,
  "created_at" : "2016-10-04 22:47:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/o7auDc5h8i",
      "expanded_url" : "http:\/\/snpy.tv\/2dnXja3",
      "display_url" : "snpy.tv\/2dnXja3"
    } ]
  },
  "geo" : { },
  "id_str" : "783428233572130817",
  "text" : "Watch @POTUS and @LeonardoDiCaprio talk about how conservation goes hand-in-hand with acting on climate. #SXSL https:\/\/t.co\/o7auDc5h8i",
  "id" : 783428233572130817,
  "created_at" : "2016-10-04 22:07:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/783423098620084224\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/d0k52PjK7V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct9HCOoUsAAX_Ec.jpg",
      "id_str" : "783422963798290432",
      "id" : 783422963798290432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct9HCOoUsAAX_Ec.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/d0k52PjK7V"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783423098620084224",
  "text" : "\"Climate change is happening even faster than the predictions would have told us 5 years ago or 10 years ago\" \u2014@POTUS at #SXSL https:\/\/t.co\/d0k52PjK7V",
  "id" : 783423098620084224,
  "created_at" : "2016-10-04 21:46:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yp1xg6Bhlk",
      "expanded_url" : "http:\/\/go.wh.gov\/Rural-America",
      "display_url" : "go.wh.gov\/Rural-America"
    } ]
  },
  "geo" : { },
  "id_str" : "783412430907043840",
  "text" : "In Rural America:\nUnemployment \u2193\nChild poverty \u2193\nHousehold incomes \u2191\n\n@POTUS reflects on America's rural resilience: https:\/\/t.co\/yp1xg6Bhlk",
  "id" : 783412430907043840,
  "created_at" : "2016-10-04 21:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/GEEHcCrfRE",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "783381227751346176",
  "text" : "RT @PressSec: If you're in the path of Hurricane Matthew, see how you can prepare yourself &amp; your family: https:\/\/t.co\/GEEHcCrfRE https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/GEEHcCrfRE",
        "expanded_url" : "http:\/\/Ready.gov",
        "display_url" : "Ready.gov"
      }, {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/lnSerj69ek",
        "expanded_url" : "http:\/\/snpy.tv\/2dBIMYP",
        "display_url" : "snpy.tv\/2dBIMYP"
      } ]
    },
    "geo" : { },
    "id_str" : "783377413451288576",
    "text" : "If you're in the path of Hurricane Matthew, see how you can prepare yourself &amp; your family: https:\/\/t.co\/GEEHcCrfRE https:\/\/t.co\/lnSerj69ek",
    "id" : 783377413451288576,
    "created_at" : "2016-10-04 18:45:04 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 783381227751346176,
  "created_at" : "2016-10-04 19:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 44, 49 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783378050532593668",
  "text" : "RT @PressSec: Tomorrow, @POTUS will head to @FEMA headquarters to learn more about federal preparation efforts for Hurricane Matthew.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 30, 35 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783376934558314496",
    "text" : "Tomorrow, @POTUS will head to @FEMA headquarters to learn more about federal preparation efforts for Hurricane Matthew.",
    "id" : 783376934558314496,
    "created_at" : "2016-10-04 18:43:10 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 783378050532593668,
  "created_at" : "2016-10-04 18:47:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Undefeated",
      "screen_name" : "TheUndefeated",
      "indices" : [ 3, 17 ],
      "id_str" : "3033098871",
      "id" : 3033098871
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "North Carolina A&T",
      "screen_name" : "ncatsuaggies",
      "indices" : [ 82, 95 ],
      "id_str" : "52487302",
      "id" : 52487302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UndefeatedConvo",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/VxX6rYCWzx",
      "expanded_url" : "http:\/\/undf.td\/2d0kjep",
      "display_url" : "undf.td\/2d0kjep"
    } ]
  },
  "geo" : { },
  "id_str" : "783368479164370944",
  "text" : "RT @TheUndefeated: BREAKING: We will be hosting an HBCU Student Forum w\/@POTUS at @ncatsuaggies. #UndefeatedConvo https:\/\/t.co\/VxX6rYCWzx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 53, 59 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "North Carolina A&T",
        "screen_name" : "ncatsuaggies",
        "indices" : [ 63, 76 ],
        "id_str" : "52487302",
        "id" : 52487302
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UndefeatedConvo",
        "indices" : [ 78, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/VxX6rYCWzx",
        "expanded_url" : "http:\/\/undf.td\/2d0kjep",
        "display_url" : "undf.td\/2d0kjep"
      } ]
    },
    "geo" : { },
    "id_str" : "783337762057510912",
    "text" : "BREAKING: We will be hosting an HBCU Student Forum w\/@POTUS at @ncatsuaggies. #UndefeatedConvo https:\/\/t.co\/VxX6rYCWzx",
    "id" : 783337762057510912,
    "created_at" : "2016-10-04 16:07:30 +0000",
    "user" : {
      "name" : "The Undefeated",
      "screen_name" : "TheUndefeated",
      "protected" : false,
      "id_str" : "3033098871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758514647813263360\/yzufTV7j_normal.jpg",
      "id" : 3033098871,
      "verified" : true
    }
  },
  "id" : 783368479164370944,
  "created_at" : "2016-10-04 18:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 15, 26 ],
      "id_str" : "18159470",
      "id" : 18159470
    }, {
      "name" : "MTV News",
      "screen_name" : "MTVNews",
      "indices" : [ 28, 36 ],
      "id_str" : "40076725",
      "id" : 40076725
    }, {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 59, 65 ],
      "id_str" : "15460572",
      "id" : 15460572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/WDeHw7vjyd",
      "expanded_url" : "http:\/\/go.wh.gov\/UYLQPu",
      "display_url" : "go.wh.gov\/UYLQPu"
    } ]
  },
  "geo" : { },
  "id_str" : "783364349104619520",
  "text" : "Happening now: @Macklemore, @MTVNews' Ana Marie Cox, &amp; @ONDCP Director Botticelli discuss the opioid crisis. Watch: https:\/\/t.co\/WDeHw7vjyd",
  "id" : 783364349104619520,
  "created_at" : "2016-10-04 17:53:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 3, 14 ],
      "id_str" : "18159470",
      "id" : 18159470
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 92, 96 ],
      "id_str" : "2367911",
      "id" : 2367911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783350731625594880",
  "text" : "RT @macklemore: I'm at the @WhiteHouse today talking on a panel about opioid addiction with @MTV at 2pm EDT.  Stream it live at https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "MTV",
        "screen_name" : "MTV",
        "indices" : [ 76, 80 ],
        "id_str" : "2367911",
        "id" : 2367911
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/HiD58nRunh",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "783345236206583809",
    "text" : "I'm at the @WhiteHouse today talking on a panel about opioid addiction with @MTV at 2pm EDT.  Stream it live at https:\/\/t.co\/HiD58nRunh",
    "id" : 783345236206583809,
    "created_at" : "2016-10-04 16:37:12 +0000",
    "user" : {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "protected" : false,
      "id_str" : "18159470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785934991817445377\/a1y-3oro_normal.jpg",
      "id" : 18159470,
      "verified" : true
    }
  },
  "id" : 783350731625594880,
  "created_at" : "2016-10-04 16:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Matthew",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783348335369457664",
  "text" : "RT @fema: Get ready for #Matthew:\n\n\uD83D\uDE97 Review your evacuation route &amp; fill your gas tank\n\n\uD83C\uDFE1 Bring lightweight items indoors\n\n\uD83D\uDCDD\uD83D\uDC36 Make a plan f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Matthew",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783067984797446144",
    "text" : "Get ready for #Matthew:\n\n\uD83D\uDE97 Review your evacuation route &amp; fill your gas tank\n\n\uD83C\uDFE1 Bring lightweight items indoors\n\n\uD83D\uDCDD\uD83D\uDC36 Make a plan for pets",
    "id" : 783067984797446144,
    "created_at" : "2016-10-03 22:15:30 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 783348335369457664,
  "created_at" : "2016-10-04 16:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHC Atlantic Ops",
      "screen_name" : "NHC_Atlantic",
      "indices" : [ 3, 16 ],
      "id_str" : "299798272",
      "id" : 299798272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783347488652660736",
  "text" : "RT @NHC_Atlantic: Tropical Storm and\/or Hurricane Watches are likely for portions of the Florida Peninsula &amp; Florida Keys later this mornin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NHC_Atlantic\/status\/783277033031860224\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/Hlk28QE2z9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct7CTjfWcAAo94B.jpg",
        "id_str" : "783277026409082880",
        "id" : 783277026409082880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct7CTjfWcAAo94B.jpg",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        } ],
        "display_url" : "pic.twitter.com\/Hlk28QE2z9"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NHC_Atlantic\/status\/783277033031860224\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/Hlk28QE2z9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct7CTjiWIAAYN4h.jpg",
        "id_str" : "783277026421645312",
        "id" : 783277026421645312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct7CTjiWIAAYN4h.jpg",
        "sizes" : [ {
          "h" : 543,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 896
        } ],
        "display_url" : "pic.twitter.com\/Hlk28QE2z9"
      } ],
      "hashtags" : [ {
        "text" : "Matthew",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783277033031860224",
    "text" : "Tropical Storm and\/or Hurricane Watches are likely for portions of the Florida Peninsula &amp; Florida Keys later this morning for #Matthew. https:\/\/t.co\/Hlk28QE2z9",
    "id" : 783277033031860224,
    "created_at" : "2016-10-04 12:06:11 +0000",
    "user" : {
      "name" : "NHC Atlantic Ops",
      "screen_name" : "NHC_Atlantic",
      "protected" : false,
      "id_str" : "299798272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1370242639\/twitter_nhc1_normal.jpg",
      "id" : 299798272,
      "verified" : true
    }
  },
  "id" : 783347488652660736,
  "created_at" : "2016-10-04 16:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/hYqe5lCQZz",
      "expanded_url" : "http:\/\/huff.to\/2d0xagC",
      "display_url" : "huff.to\/2d0xagC"
    } ]
  },
  "geo" : { },
  "id_str" : "783343637493002240",
  "text" : "RT @SCOTUSnom: \"Enough is enough\" \u2014@POTUS on Republican obstruction of his #SCOTUS nominee, Judge Garland. https:\/\/t.co\/hYqe5lCQZz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 20, 26 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/hYqe5lCQZz",
        "expanded_url" : "http:\/\/huff.to\/2d0xagC",
        "display_url" : "huff.to\/2d0xagC"
      } ]
    },
    "geo" : { },
    "id_str" : "783338894628564992",
    "text" : "\"Enough is enough\" \u2014@POTUS on Republican obstruction of his #SCOTUS nominee, Judge Garland. https:\/\/t.co\/hYqe5lCQZz",
    "id" : 783338894628564992,
    "created_at" : "2016-10-04 16:12:00 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 783343637493002240,
  "created_at" : "2016-10-04 16:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nprmusic",
      "screen_name" : "nprmusic",
      "indices" : [ 3, 12 ],
      "id_str" : "13784592",
      "id" : 13784592
    }, {
      "name" : "COMMON",
      "screen_name" : "common",
      "indices" : [ 20, 27 ],
      "id_str" : "17169320",
      "id" : 17169320
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Bilal",
      "screen_name" : "Bilal",
      "indices" : [ 81, 87 ],
      "id_str" : "93993462",
      "id" : 93993462
    }, {
      "name" : "Robert Glasper",
      "screen_name" : "robertglasper",
      "indices" : [ 92, 106 ],
      "id_str" : "154953218",
      "id" : 154953218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tinydesk",
      "indices" : [ 66, 75 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/4KjF4fgVsV",
      "expanded_url" : "http:\/\/n.pr\/2dH5SKz",
      "display_url" : "n.pr\/2dH5SKz"
    } ]
  },
  "geo" : { },
  "id_str" : "783337837194117120",
  "text" : "RT @nprmusic: Watch @common inaugurate the @WhiteHouse edition of #tinydesk with @Bilal and @robertglasper #SXSL https:\/\/t.co\/4KjF4fgVsV ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "COMMON",
        "screen_name" : "common",
        "indices" : [ 6, 13 ],
        "id_str" : "17169320",
        "id" : 17169320
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 29, 40 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Bilal",
        "screen_name" : "Bilal",
        "indices" : [ 67, 73 ],
        "id_str" : "93993462",
        "id" : 93993462
      }, {
        "name" : "Robert Glasper",
        "screen_name" : "robertglasper",
        "indices" : [ 78, 92 ],
        "id_str" : "154953218",
        "id" : 154953218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nprmusic\/status\/783337168886431744\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/6Y74CBcSL3",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ct746U4WcAE92o3.jpg",
        "id_str" : "783337066130206721",
        "id" : 783337066130206721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ct746U4WcAE92o3.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6Y74CBcSL3"
      } ],
      "hashtags" : [ {
        "text" : "tinydesk",
        "indices" : [ 52, 61 ]
      }, {
        "text" : "SXSL",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/4KjF4fgVsV",
        "expanded_url" : "http:\/\/n.pr\/2dH5SKz",
        "display_url" : "n.pr\/2dH5SKz"
      } ]
    },
    "geo" : { },
    "id_str" : "783337168886431744",
    "text" : "Watch @common inaugurate the @WhiteHouse edition of #tinydesk with @Bilal and @robertglasper #SXSL https:\/\/t.co\/4KjF4fgVsV https:\/\/t.co\/6Y74CBcSL3",
    "id" : 783337168886431744,
    "created_at" : "2016-10-04 16:05:09 +0000",
    "user" : {
      "name" : "nprmusic",
      "screen_name" : "nprmusic",
      "protected" : false,
      "id_str" : "13784592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768169011859324928\/-2frWHaT_normal.jpg",
      "id" : 13784592,
      "verified" : true
    }
  },
  "id" : 783337837194117120,
  "created_at" : "2016-10-04 16:07:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 3, 14 ],
      "id_str" : "15693493",
      "id" : 15693493
    }, {
      "name" : "ADAMDEVINE",
      "screen_name" : "ADAMDEVINE",
      "indices" : [ 17, 28 ],
      "id_str" : "18091925",
      "id" : 18091925
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 51, 54 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783301808391348224",
  "text" : "RT @funnyordie: .@AdamDevine &amp; his new partner @VP Joe Biden go undercover at a college party to get the word out about a serious issue. #I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ADAMDEVINE",
        "screen_name" : "ADAMDEVINE",
        "indices" : [ 1, 12 ],
        "id_str" : "18091925",
        "id" : 18091925
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 35, 38 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/funnyordie\/status\/783283046694780928\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/cBcpnu8STE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct54i9cXYAAAkaV.jpg",
        "id_str" : "783182945322405888",
        "id" : 783182945322405888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct54i9cXYAAAkaV.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1140,
          "resize" : "fit",
          "w" : 1972
        } ],
        "display_url" : "pic.twitter.com\/cBcpnu8STE"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783283046694780928",
    "text" : ".@AdamDevine &amp; his new partner @VP Joe Biden go undercover at a college party to get the word out about a serious issue. #ItsOnUs https:\/\/t.co\/cBcpnu8STE",
    "id" : 783283046694780928,
    "created_at" : "2016-10-04 12:30:05 +0000",
    "user" : {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "protected" : false,
      "id_str" : "15693493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796062959185182720\/FN6QGp0H_normal.jpg",
      "id" : 15693493,
      "verified" : true
    }
  },
  "id" : 783301808391348224,
  "created_at" : "2016-10-04 13:44:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/783115423671869441\/photo\/1",
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/yK2WE1qMg9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct4q7aJW8AISCzX.jpg",
      "id_str" : "783110585328267266",
      "id" : 783110585328267266,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct4q7aJW8AISCzX.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/yK2WE1qMg9"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/1Gk8VZRM3S",
      "expanded_url" : "http:\/\/wh.gov\/SXSL",
      "display_url" : "wh.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "783115423671869441",
  "text" : "We can all be the change in our own communities\u2014all it takes is the courage to get started. https:\/\/t.co\/1Gk8VZRM3S #SXSL https:\/\/t.co\/yK2WE1qMg9",
  "id" : 783115423671869441,
  "created_at" : "2016-10-04 01:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/783107965687476224\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/eMwc5J6AjV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct4ogboVUAEGRdd.jpg",
      "id_str" : "783107922846896129",
      "id" : 783107922846896129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct4ogboVUAEGRdd.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/eMwc5J6AjV"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/CaAklOe8Ci",
      "expanded_url" : "http:\/\/wh.gov\/sxsl",
      "display_url" : "wh.gov\/sxsl"
    } ]
  },
  "geo" : { },
  "id_str" : "783107965687476224",
  "text" : "Thanks for joining the conversation. Check out what the day was all about: https:\/\/t.co\/CaAklOe8Ci #SXSL https:\/\/t.co\/eMwc5J6AjV",
  "id" : 783107965687476224,
  "created_at" : "2016-10-04 00:54:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/o7auDc5h8i",
      "expanded_url" : "http:\/\/snpy.tv\/2dnXja3",
      "display_url" : "snpy.tv\/2dnXja3"
    } ]
  },
  "geo" : { },
  "id_str" : "783100153456537600",
  "text" : "\"Lift up the power and the values that are embodied in conservation.\" \u2014@POTUS on combating climate change #SXSL https:\/\/t.co\/o7auDc5h8i",
  "id" : 783100153456537600,
  "created_at" : "2016-10-04 00:23:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 3, 15 ],
      "id_str" : "133880286",
      "id" : 133880286
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LeoDiCaprio\/status\/783057156601942017\/video\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/myPqJRBggR",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/783054349236899840\/pu\/img\/mZ0MnjtCGpJzhjxI.jpg",
      "id_str" : "783054349236899840",
      "id" : 783054349236899840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/783054349236899840\/pu\/img\/mZ0MnjtCGpJzhjxI.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/myPqJRBggR"
    } ],
    "hashtags" : [ {
      "text" : "BeforeTheFlood",
      "indices" : [ 46, 61 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783098787917103105",
  "text" : "RT @LeoDiCaprio: Looking forward to screening #BeforeTheFlood today at #SXSL. Watch the trailer here. https:\/\/t.co\/myPqJRBggR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LeoDiCaprio\/status\/783057156601942017\/video\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/myPqJRBggR",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/783054349236899840\/pu\/img\/mZ0MnjtCGpJzhjxI.jpg",
        "id_str" : "783054349236899840",
        "id" : 783054349236899840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/783054349236899840\/pu\/img\/mZ0MnjtCGpJzhjxI.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/myPqJRBggR"
      } ],
      "hashtags" : [ {
        "text" : "BeforeTheFlood",
        "indices" : [ 29, 44 ]
      }, {
        "text" : "SXSL",
        "indices" : [ 54, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783057156601942017",
    "text" : "Looking forward to screening #BeforeTheFlood today at #SXSL. Watch the trailer here. https:\/\/t.co\/myPqJRBggR",
    "id" : 783057156601942017,
    "created_at" : "2016-10-03 21:32:29 +0000",
    "user" : {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "protected" : false,
      "id_str" : "133880286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694662257586892802\/mdc5ELjj_normal.jpg",
      "id" : 133880286,
      "verified" : true
    }
  },
  "id" : 783098787917103105,
  "created_at" : "2016-10-04 00:17:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 88, 100 ],
      "id_str" : "133880286",
      "id" : 133880286
    }, {
      "name" : "Katharine Hayhoe",
      "screen_name" : "KHayhoe",
      "indices" : [ 107, 115 ],
      "id_str" : "34317032",
      "id" : 34317032
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/783087361345269760\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/gvvdBBsn7c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct4VvlMUAAAQNmX.jpg",
      "id_str" : "783087292390834176",
      "id" : 783087292390834176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct4VvlMUAAAQNmX.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 938
      } ],
      "display_url" : "pic.twitter.com\/gvvdBBsn7c"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 69, 82 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783087361345269760",
  "text" : "\"We're in a race against time.\" \u2014@POTUS talking about why we need to #ActOnClimate with @LeoDiCaprio &amp; @KHayhoe at #SXSL https:\/\/t.co\/gvvdBBsn7c",
  "id" : 783087361345269760,
  "created_at" : "2016-10-03 23:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783085158605783040",
  "text" : "RT @WHLive: \"If we're going to be able to solve this problem we're going to have to come up with new sources of energy that are clean and c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 134, 140 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783085123411390464",
    "text" : "\"If we're going to be able to solve this problem we're going to have to come up with new sources of energy that are clean and cheap\" \u2014@POTUS",
    "id" : 783085123411390464,
    "created_at" : "2016-10-03 23:23:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 783085158605783040,
  "created_at" : "2016-10-03 23:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783084676218966016",
  "text" : "\"Climate change is happening even faster than 5 years ago or 10 years ago.\" \u2014@POTUS on why we need to #ActOnClimate",
  "id" : 783084676218966016,
  "created_at" : "2016-10-03 23:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 68, 83 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783084107433508864",
  "text" : "\"India just this past week signed on.\" \u2014@POTUS on India joining the #ParisAgreement this week #ActOnClimate",
  "id" : 783084107433508864,
  "created_at" : "2016-10-03 23:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/1Gk8VZAaFi",
      "expanded_url" : "http:\/\/wh.gov\/SXSL",
      "display_url" : "wh.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "783083556666904576",
  "text" : "We've doubled the production of clean energy since I came into office.\"  \u2014@POTUS at #SXSL \n\nWatch Live: https:\/\/t.co\/1Gk8VZAaFi",
  "id" : 783083556666904576,
  "created_at" : "2016-10-03 23:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 39, 46 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783083085822693376",
  "text" : "\"It is my anniversary today...24 years @FLOTUS has put up with me.\" \u2014@POTUS at #SXSL",
  "id" : 783083085822693376,
  "created_at" : "2016-10-03 23:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 23, 35 ],
      "id_str" : "133880286",
      "id" : 133880286
    }, {
      "name" : "Katharine Hayhoe",
      "screen_name" : "KHayhoe",
      "indices" : [ 43, 51 ],
      "id_str" : "34317032",
      "id" : 34317032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/opgtuN4638",
      "expanded_url" : "http:\/\/go.wh.gov\/zQfoaw",
      "display_url" : "go.wh.gov\/zQfoaw"
    } ]
  },
  "geo" : { },
  "id_str" : "783081649114341376",
  "text" : "Happening now: @POTUS, @LeoDiCaprio, &amp; @KHayhoe in conversation on climate change \u2192 https:\/\/t.co\/opgtuN4638 #ActOnClimate #SXSL",
  "id" : 783081649114341376,
  "created_at" : "2016-10-03 23:09:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 27, 39 ],
      "id_str" : "133880286",
      "id" : 133880286
    }, {
      "name" : "Katharine Hayhoe",
      "screen_name" : "KHayhoe",
      "indices" : [ 46, 54 ],
      "id_str" : "34317032",
      "id" : 34317032
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/783072485478662145\/photo\/1",
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/yYkI92u05G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct4H33HVIAAZd_l.jpg",
      "id_str" : "783072041477939200",
      "id" : 783072041477939200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct4H33HVIAAZd_l.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/yYkI92u05G"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 136, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/opgtuN4638",
      "expanded_url" : "http:\/\/go.wh.gov\/zQfoaw",
      "display_url" : "go.wh.gov\/zQfoaw"
    } ]
  },
  "geo" : { },
  "id_str" : "783072485478662145",
  "text" : "Live at 7:00pm ET: @POTUS, @LeoDiCaprio &amp; @KHayhoe in conversation on protecting our planet. Don\u2019t miss it: https:\/\/t.co\/opgtuN4638 #SXSL https:\/\/t.co\/yYkI92u05G",
  "id" : 783072485478662145,
  "created_at" : "2016-10-03 22:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/pT3yKei5s0",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/sxsl",
      "display_url" : "whitehouse.gov\/sxsl"
    }, {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/vn2CYTG0gJ",
      "expanded_url" : "https:\/\/twitter.com\/potus\/status\/782970909229326336",
      "display_url" : "twitter.com\/potus\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783069504104501248",
  "text" : "RT @kerrywashington: Join the #SXSL conversation! https:\/\/t.co\/pT3yKei5s0 https:\/\/t.co\/vn2CYTG0gJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 9, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/pT3yKei5s0",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/sxsl",
        "display_url" : "whitehouse.gov\/sxsl"
      }, {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/vn2CYTG0gJ",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/782970909229326336",
        "display_url" : "twitter.com\/potus\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783014106580283392",
    "text" : "Join the #SXSL conversation! https:\/\/t.co\/pT3yKei5s0 https:\/\/t.co\/vn2CYTG0gJ",
    "id" : 783014106580283392,
    "created_at" : "2016-10-03 18:41:25 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 783069504104501248,
  "created_at" : "2016-10-03 22:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "CancerMoonshot",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783067386371014656",
  "text" : "RT @VPLive: Thanks to everyone at #SXSL who stopped by the #CancerMoonshot booth today to see hands-on how tech and data are advancing canc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/783065873439297536\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/NxgoThr7Y6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct4CNxoXEAA5WsB.jpg",
        "id_str" : "783065820893220864",
        "id" : 783065820893220864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct4CNxoXEAA5WsB.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/NxgoThr7Y6"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 22, 27 ]
      }, {
        "text" : "CancerMoonshot",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783065873439297536",
    "text" : "Thanks to everyone at #SXSL who stopped by the #CancerMoonshot booth today to see hands-on how tech and data are advancing cancer research. https:\/\/t.co\/NxgoThr7Y6",
    "id" : 783065873439297536,
    "created_at" : "2016-10-03 22:07:07 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 783067386371014656,
  "created_at" : "2016-10-03 22:13:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/gZ3ilMVptW",
      "expanded_url" : "http:\/\/go.wh.gov\/8mPs6a",
      "display_url" : "go.wh.gov\/8mPs6a"
    } ]
  },
  "in_reply_to_status_id_str" : "783034644086358017",
  "geo" : { },
  "id_str" : "783035414722510848",
  "in_reply_to_user_id" : 30313925,
  "text" : "Also happening now: Leaders from across Los Angeles discuss how we can help our cities thrive: https:\/\/t.co\/gZ3ilMVptW #SXSL",
  "id" : 783035414722510848,
  "in_reply_to_status_id" : 783034644086358017,
  "created_at" : "2016-10-03 20:06:05 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 1, 14 ],
      "id_str" : "29450962",
      "id" : 29450962
    }, {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "indices" : [ 15, 24 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Brittany Packnett",
      "screen_name" : "MsPackyetti",
      "indices" : [ 25, 37 ],
      "id_str" : "239509917",
      "id" : 239509917
    }, {
      "name" : "Carmen Rojas, PhD",
      "screen_name" : "crojasphd",
      "indices" : [ 38, 48 ],
      "id_str" : "568412239",
      "id" : 568412239
    }, {
      "name" : "Evan Wolfson",
      "screen_name" : "evanwolfson",
      "indices" : [ 49, 61 ],
      "id_str" : "14056817",
      "id" : 14056817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/QXNpRtjyq3",
      "expanded_url" : "http:\/\/go.wh.gov\/PHPJJC",
      "display_url" : "go.wh.gov\/PHPJJC"
    } ]
  },
  "geo" : { },
  "id_str" : "783034644086358017",
  "text" : ".@RepJohnLewis\n@AnilDash\n@MsPackyetti\n@CRojasPhD\n@EvanWolfson\n \nWatch them talk about making change happen: https:\/\/t.co\/QXNpRtjyq3",
  "id" : 783034644086358017,
  "created_at" : "2016-10-03 20:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "COMMON",
      "screen_name" : "common",
      "indices" : [ 63, 70 ],
      "id_str" : "17169320",
      "id" : 17169320
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/783030104876158976\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/5kIW06BT2I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3htRXVIAAFGBo.jpg",
      "id_str" : "783030078103953408",
      "id" : 783030078103953408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3htRXVIAAFGBo.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/5kIW06BT2I"
    } ],
    "hashtags" : [ {
      "text" : "JusticeForUs",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "criminaljusticereform",
      "indices" : [ 71, 93 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783031030827679744",
  "text" : "RT @vj44: Checking out #JusticeForUs digital experience app w\/ @common #criminaljusticereform #SXSL https:\/\/t.co\/5kIW06BT2I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "COMMON",
        "screen_name" : "common",
        "indices" : [ 53, 60 ],
        "id_str" : "17169320",
        "id" : 17169320
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/783030104876158976\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/5kIW06BT2I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3htRXVIAAFGBo.jpg",
        "id_str" : "783030078103953408",
        "id" : 783030078103953408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3htRXVIAAFGBo.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/5kIW06BT2I"
      } ],
      "hashtags" : [ {
        "text" : "JusticeForUs",
        "indices" : [ 13, 26 ]
      }, {
        "text" : "criminaljusticereform",
        "indices" : [ 61, 83 ]
      }, {
        "text" : "SXSL",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783030104876158976",
    "text" : "Checking out #JusticeForUs digital experience app w\/ @common #criminaljusticereform #SXSL https:\/\/t.co\/5kIW06BT2I",
    "id" : 783030104876158976,
    "created_at" : "2016-10-03 19:44:59 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 783031030827679744,
  "created_at" : "2016-10-03 19:48:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Challenge Detroit",
      "screen_name" : "ChallengeDet",
      "indices" : [ 3, 16 ],
      "id_str" : "142798973",
      "id" : 142798973
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 102, 113 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783024104098193417",
  "text" : "RT @ChallengeDet: \"We have to change the narrative of who even is a farmer.\" Feeding the Future Panel @WhiteHouse #SXSL https:\/\/t.co\/ukmC1e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 84, 95 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChallengeDet\/status\/783023627629453312\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ukmC1eRa2y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3b0lSWAAE_7ND.jpg",
        "id_str" : "783023606641065985",
        "id" : 783023606641065985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3b0lSWAAE_7ND.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ukmC1eRa2y"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 96, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783023627629453312",
    "text" : "\"We have to change the narrative of who even is a farmer.\" Feeding the Future Panel @WhiteHouse #SXSL https:\/\/t.co\/ukmC1eRa2y",
    "id" : 783023627629453312,
    "created_at" : "2016-10-03 19:19:15 +0000",
    "user" : {
      "name" : "Challenge Detroit",
      "screen_name" : "ChallengeDet",
      "protected" : false,
      "id_str" : "142798973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777962248249540608\/qNVdsOp3_normal.jpg",
      "id" : 142798973,
      "verified" : false
    }
  },
  "id" : 783024104098193417,
  "created_at" : "2016-10-03 19:21:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/b4dnhzb1NS",
      "expanded_url" : "http:\/\/go.wh.gov\/dFn53X",
      "display_url" : "go.wh.gov\/dFn53X"
    } ]
  },
  "in_reply_to_status_id_str" : "783016724438261760",
  "geo" : { },
  "id_str" : "783021018709385216",
  "in_reply_to_user_id" : 30313925,
  "text" : "Also happening now: How will we sustainably feed ourselves in the coming decades? Tune in for a #SXSL conversation \u2192 https:\/\/t.co\/b4dnhzb1NS",
  "id" : 783021018709385216,
  "in_reply_to_status_id" : 783016724438261760,
  "created_at" : "2016-10-03 19:08:53 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Mayor Adler",
      "screen_name" : "MayorAdler",
      "indices" : [ 46, 57 ],
      "id_str" : "2300278368",
      "id" : 2300278368
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/783015597319737344\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/mEdn0F65xr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3UZpDUIAAFN9x.jpg",
      "id_str" : "783015447213907968",
      "id" : 783015447213907968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3UZpDUIAAFN9x.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/mEdn0F65xr"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783019896959565824",
  "text" : "RT @vj44: Kicking off #SXSL with Austin Mayor @MayorAdler! https:\/\/t.co\/mEdn0F65xr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Adler",
        "screen_name" : "MayorAdler",
        "indices" : [ 36, 47 ],
        "id_str" : "2300278368",
        "id" : 2300278368
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/783015597319737344\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/mEdn0F65xr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3UZpDUIAAFN9x.jpg",
        "id_str" : "783015447213907968",
        "id" : 783015447213907968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3UZpDUIAAFN9x.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/mEdn0F65xr"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783015597319737344",
    "text" : "Kicking off #SXSL with Austin Mayor @MayorAdler! https:\/\/t.co\/mEdn0F65xr",
    "id" : 783015597319737344,
    "created_at" : "2016-10-03 18:47:20 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 783019896959565824,
  "created_at" : "2016-10-03 19:04:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/bNArbn1Aks",
      "expanded_url" : "http:\/\/go.wh.gov\/6u8TdG",
      "display_url" : "go.wh.gov\/6u8TdG"
    } ]
  },
  "geo" : { },
  "id_str" : "783016724438261760",
  "text" : "Happening now: a conversation on how can we harness technology to solve our most stubborn problems. https:\/\/t.co\/bNArbn1Aks #SXSL",
  "id" : 783016724438261760,
  "created_at" : "2016-10-03 18:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Lumineers",
      "screen_name" : "thelumineers",
      "indices" : [ 3, 16 ],
      "id_str" : "186129806",
      "id" : 186129806
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thelumineers\/status\/783011548964855808\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/WOSKdLARW1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3Q1pyUMAEvDDR.jpg",
      "id_str" : "783011530400870401",
      "id" : 783011530400870401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3Q1pyUMAEvDDR.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/WOSKdLARW1"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783013548838440960",
  "text" : "RT @thelumineers: Getting ready for #SXSL \uD83D\uDC4C https:\/\/t.co\/WOSKdLARW1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thelumineers\/status\/783011548964855808\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/WOSKdLARW1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3Q1pyUMAEvDDR.jpg",
        "id_str" : "783011530400870401",
        "id" : 783011530400870401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3Q1pyUMAEvDDR.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/WOSKdLARW1"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 18, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783011548964855808",
    "text" : "Getting ready for #SXSL \uD83D\uDC4C https:\/\/t.co\/WOSKdLARW1",
    "id" : 783011548964855808,
    "created_at" : "2016-10-03 18:31:15 +0000",
    "user" : {
      "name" : "The Lumineers",
      "screen_name" : "thelumineers",
      "protected" : false,
      "id_str" : "186129806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760133805239697410\/9tmRi2Pk_normal.jpg",
      "id" : 186129806,
      "verified" : true
    }
  },
  "id" : 783013548838440960,
  "created_at" : "2016-10-03 18:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/BbvvMDTfv5",
      "expanded_url" : "http:\/\/WH.gov\/SXSL",
      "display_url" : "WH.gov\/SXSL"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/aMhTqSQfkH",
      "expanded_url" : "http:\/\/snpy.tv\/2dyUfZ1",
      "display_url" : "snpy.tv\/2dyUfZ1"
    } ]
  },
  "geo" : { },
  "id_str" : "783010808024358912",
  "text" : "Adam Savage and his team of makers created this innovative sign for #SXSL. More here: https:\/\/t.co\/BbvvMDTfv5 https:\/\/t.co\/aMhTqSQfkH",
  "id" : 783010808024358912,
  "created_at" : "2016-10-03 18:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Anne McClain",
      "screen_name" : "AstroAnnimal",
      "indices" : [ 11, 24 ],
      "id_str" : "1533844754",
      "id" : 1533844754
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 72, 83 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783007495258124288",
  "text" : "RT @NASA: .@AstroAnnimal McClain goes behind-the-scenes of the 1st-ever @WhiteHouse South by South Lawn festival. Watch: https:\/\/t.co\/ZC4v0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anne McClain",
        "screen_name" : "AstroAnnimal",
        "indices" : [ 1, 14 ],
        "id_str" : "1533844754",
        "id" : 1533844754
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 62, 73 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/783002163131871236\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/TiejWDpkcW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct3IUOLXgAA_m_1.jpg",
        "id_str" : "783002159961047040",
        "id" : 783002159961047040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct3IUOLXgAA_m_1.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/TiejWDpkcW"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/ZC4v0HcBMX",
        "expanded_url" : "http:\/\/go.nasa.gov\/2dnahEY",
        "display_url" : "go.nasa.gov\/2dnahEY"
      } ]
    },
    "geo" : { },
    "id_str" : "783002163131871236",
    "text" : ".@AstroAnnimal McClain goes behind-the-scenes of the 1st-ever @WhiteHouse South by South Lawn festival. Watch: https:\/\/t.co\/ZC4v0HcBMX #SXSL https:\/\/t.co\/TiejWDpkcW",
    "id" : 783002163131871236,
    "created_at" : "2016-10-03 17:53:57 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 783007495258124288,
  "created_at" : "2016-10-03 18:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 52, 62 ],
      "id_str" : "131144091",
      "id" : 131144091
    }, {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 67, 72 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/bS9DTua3mr",
      "expanded_url" : "http:\/\/go.wh.gov\/eqP5mM",
      "display_url" : "go.wh.gov\/eqP5mM"
    } ]
  },
  "geo" : { },
  "id_str" : "782993140470976512",
  "text" : "Live from behind the scenes of South by South Lawn, @Goldman44 and @DJ44 preview the day with special guests: https:\/\/t.co\/bS9DTua3mr #SXSL",
  "id" : 782993140470976512,
  "created_at" : "2016-10-03 17:18:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 61, 71 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782983951883313153",
  "text" : "RT @DJ44: Always wanted to say \"Live from the @WhiteHouse!\"\uD83C\uDF99 @Goldman44 &amp; I will be live from #SXSL \uD83C\uDDFA\uD83C\uDDF8 at 1:15 ET\/10:15 PT https:\/\/t.co\/o5a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 36, 47 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Jason Goldman",
        "screen_name" : "Goldman44",
        "indices" : [ 51, 61 ],
        "id_str" : "131144091",
        "id" : 131144091
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/o5aPSWAqOx",
        "expanded_url" : "http:\/\/Facebook.com\/WhiteHouse",
        "display_url" : "Facebook.com\/WhiteHouse"
      } ]
    },
    "geo" : { },
    "id_str" : "782983348918550528",
    "text" : "Always wanted to say \"Live from the @WhiteHouse!\"\uD83C\uDF99 @Goldman44 &amp; I will be live from #SXSL \uD83C\uDDFA\uD83C\uDDF8 at 1:15 ET\/10:15 PT https:\/\/t.co\/o5aPSWAqOx",
    "id" : 782983348918550528,
    "created_at" : "2016-10-03 16:39:12 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 782983951883313153,
  "created_at" : "2016-10-03 16:41:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Gallant",
      "screen_name" : "SoGallant",
      "indices" : [ 18, 28 ],
      "id_str" : "23324892",
      "id" : 23324892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/czI6Vc3fyr",
      "expanded_url" : "http:\/\/go.wh.gov\/3XZWmS",
      "display_url" : "go.wh.gov\/3XZWmS"
    } ]
  },
  "geo" : { },
  "id_str" : "782980806461587456",
  "text" : "RT @WHLive: Watch @SoGallant perform live from the White House as part of #SXSL: https:\/\/t.co\/czI6Vc3fyr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gallant",
        "screen_name" : "SoGallant",
        "indices" : [ 6, 16 ],
        "id_str" : "23324892",
        "id" : 23324892
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 62, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/czI6Vc3fyr",
        "expanded_url" : "http:\/\/go.wh.gov\/3XZWmS",
        "display_url" : "go.wh.gov\/3XZWmS"
      } ]
    },
    "geo" : { },
    "id_str" : "782980576617824256",
    "text" : "Watch @SoGallant perform live from the White House as part of #SXSL: https:\/\/t.co\/czI6Vc3fyr",
    "id" : 782980576617824256,
    "created_at" : "2016-10-03 16:28:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 782980806461587456,
  "created_at" : "2016-10-03 16:29:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Santana",
      "screen_name" : "JessWorldwide",
      "indices" : [ 3, 17 ],
      "id_str" : "278423378",
      "id" : 278423378
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JessWorldwide\/status\/782977784587190272\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/zXdpEWX4Ue",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782977560166723585\/pu\/img\/fRuuII7vet5ykTRE.jpg",
      "id_str" : "782977560166723585",
      "id" : 782977560166723585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782977560166723585\/pu\/img\/fRuuII7vet5ykTRE.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zXdpEWX4Ue"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782979325146660867",
  "text" : "RT @JessWorldwide: Live from the East Wing @WhiteHouse #SXSL https:\/\/t.co\/zXdpEWX4Ue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JessWorldwide\/status\/782977784587190272\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/zXdpEWX4Ue",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782977560166723585\/pu\/img\/fRuuII7vet5ykTRE.jpg",
        "id_str" : "782977560166723585",
        "id" : 782977560166723585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782977560166723585\/pu\/img\/fRuuII7vet5ykTRE.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zXdpEWX4Ue"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 36, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782977784587190272",
    "text" : "Live from the East Wing @WhiteHouse #SXSL https:\/\/t.co\/zXdpEWX4Ue",
    "id" : 782977784587190272,
    "created_at" : "2016-10-03 16:17:05 +0000",
    "user" : {
      "name" : "Jessica Santana",
      "screen_name" : "JessWorldwide",
      "protected" : false,
      "id_str" : "278423378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797144845425016833\/EYUCglgI_normal.jpg",
      "id" : 278423378,
      "verified" : false
    }
  },
  "id" : 782979325146660867,
  "created_at" : "2016-10-03 16:23:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 3, 8 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    }, {
      "name" : "PIF",
      "screen_name" : "InnovFellows",
      "indices" : [ 52, 65 ],
      "id_str" : "3184883153",
      "id" : 3184883153
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDS\/status\/782943869059076096\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/bTnZcCGvNb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2TR-EWIAApcVA.jpg",
      "id_str" : "782943847160619008",
      "id" : 782943847160619008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2TR-EWIAApcVA.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bTnZcCGvNb"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782975223880491008",
  "text" : "RT @USDS: Attending #SXSL? \n\nCome meet USDS and the @InnovFellows to learn about our latest work. https:\/\/t.co\/bTnZcCGvNb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PIF",
        "screen_name" : "InnovFellows",
        "indices" : [ 42, 55 ],
        "id_str" : "3184883153",
        "id" : 3184883153
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDS\/status\/782943869059076096\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/bTnZcCGvNb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2TR-EWIAApcVA.jpg",
        "id_str" : "782943847160619008",
        "id" : 782943847160619008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2TR-EWIAApcVA.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/bTnZcCGvNb"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 10, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782943869059076096",
    "text" : "Attending #SXSL? \n\nCome meet USDS and the @InnovFellows to learn about our latest work. https:\/\/t.co\/bTnZcCGvNb",
    "id" : 782943869059076096,
    "created_at" : "2016-10-03 14:02:19 +0000",
    "user" : {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "protected" : false,
      "id_str" : "2983206962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557352808672817152\/HWxVbTrV_normal.png",
      "id" : 2983206962,
      "verified" : true
    }
  },
  "id" : 782975223880491008,
  "created_at" : "2016-10-03 16:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/782970909229326336\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/nTb10I3GHP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2rkEWUsAAnI2K.jpg",
      "id_str" : "782970546363346944",
      "id" : 782970546363346944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2rkEWUsAAnI2K.jpg",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1037,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1769,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2812,
        "resize" : "fit",
        "w" : 3255
      } ],
      "display_url" : "pic.twitter.com\/nTb10I3GHP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/qCXwVI0uLH",
      "expanded_url" : "http:\/\/wh.gov\/SXSL",
      "display_url" : "wh.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "782971854483062784",
  "text" : "RT @POTUS: Bringing a little Austin to the South Lawn today. https:\/\/t.co\/qCXwVI0uLH https:\/\/t.co\/nTb10I3GHP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/782970909229326336\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/nTb10I3GHP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2rkEWUsAAnI2K.jpg",
        "id_str" : "782970546363346944",
        "id" : 782970546363346944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2rkEWUsAAnI2K.jpg",
        "sizes" : [ {
          "h" : 587,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1037,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1769,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2812,
          "resize" : "fit",
          "w" : 3255
        } ],
        "display_url" : "pic.twitter.com\/nTb10I3GHP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/qCXwVI0uLH",
        "expanded_url" : "http:\/\/wh.gov\/SXSL",
        "display_url" : "wh.gov\/SXSL"
      } ]
    },
    "geo" : { },
    "id_str" : "782970909229326336",
    "text" : "Bringing a little Austin to the South Lawn today. https:\/\/t.co\/qCXwVI0uLH https:\/\/t.co\/nTb10I3GHP",
    "id" : 782970909229326336,
    "created_at" : "2016-10-03 15:49:46 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 782971854483062784,
  "created_at" : "2016-10-03 15:53:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/JvtZFKpQKZ",
      "expanded_url" : "http:\/\/go.wh.gov\/oLS3Kt",
      "display_url" : "go.wh.gov\/oLS3Kt"
    } ]
  },
  "geo" : { },
  "id_str" : "782971657048563712",
  "text" : "Today, @POTUS is bringing something new to the South Lawn. Find out why: https:\/\/t.co\/JvtZFKpQKZ",
  "id" : 782971657048563712,
  "created_at" : "2016-10-03 15:52:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Garibaldi",
      "screen_name" : "garibaldiarts",
      "indices" : [ 3, 17 ],
      "id_str" : "25614782",
      "id" : 25614782
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/garibaldiarts\/status\/782948802877685760\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/7xOOmUG1eT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2XxjKXYAApH9t.jpg",
      "id_str" : "782948787740434432",
      "id" : 782948787740434432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2XxjKXYAApH9t.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/7xOOmUG1eT"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782963969204035584",
  "text" : "RT @garibaldiarts: Whoa we made it!  Performing later today for #SXSL @POTUS https:\/\/t.co\/7xOOmUG1eT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 51, 57 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/garibaldiarts\/status\/782948802877685760\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/7xOOmUG1eT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2XxjKXYAApH9t.jpg",
        "id_str" : "782948787740434432",
        "id" : 782948787740434432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2XxjKXYAApH9t.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/7xOOmUG1eT"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782948802877685760",
    "text" : "Whoa we made it!  Performing later today for #SXSL @POTUS https:\/\/t.co\/7xOOmUG1eT",
    "id" : 782948802877685760,
    "created_at" : "2016-10-03 14:21:55 +0000",
    "user" : {
      "name" : "David Garibaldi",
      "screen_name" : "garibaldiarts",
      "protected" : false,
      "id_str" : "25614782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634782131273633792\/7hQWI4Ii_normal.jpg",
      "id" : 25614782,
      "verified" : true
    }
  },
  "id" : 782963969204035584,
  "created_at" : "2016-10-03 15:22:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "indices" : [ 3, 18 ],
      "id_str" : "3755263512",
      "id" : 3755263512
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 51, 62 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 63, 68 ]
    }, {
      "text" : "BetterMakeRoom",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782960808800165889",
  "text" : "RT @BetterMakeRoom: What's the coolest place to be @WhiteHouse #SXSL? The Up Next Lounge. Can't wait to see you here! \uD83C\uDD92\uD83D\uDE0E\uD83D\uDC4D#BetterMakeRoom ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 31, 42 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BetterMakeRoom\/status\/782960251339497472\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/nG93ZRlMqW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2iH-5XgAAkhZN.jpg",
        "id_str" : "782960168258732032",
        "id" : 782960168258732032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2iH-5XgAAkhZN.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/nG93ZRlMqW"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BetterMakeRoom\/status\/782960251339497472\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/nG93ZRlMqW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2iH__WAAAdk8H.jpg",
        "id_str" : "782960168552235008",
        "id" : 782960168552235008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2iH__WAAAdk8H.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/nG93ZRlMqW"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 43, 48 ]
      }, {
        "text" : "BetterMakeRoom",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782960251339497472",
    "text" : "What's the coolest place to be @WhiteHouse #SXSL? The Up Next Lounge. Can't wait to see you here! \uD83C\uDD92\uD83D\uDE0E\uD83D\uDC4D#BetterMakeRoom https:\/\/t.co\/nG93ZRlMqW",
    "id" : 782960251339497472,
    "created_at" : "2016-10-03 15:07:25 +0000",
    "user" : {
      "name" : "Better Make Room",
      "screen_name" : "BetterMakeRoom",
      "protected" : false,
      "id_str" : "3755263512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654436849671213056\/ozIogTsC_normal.png",
      "id" : 3755263512,
      "verified" : false
    }
  },
  "id" : 782960808800165889,
  "created_at" : "2016-10-03 15:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782957183679901699\/photo\/1",
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/QYgWu9qtGA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2fLPpUIAAZT9A.jpg",
      "id_str" : "782956925759528960",
      "id" : 782956925759528960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2fLPpUIAAZT9A.jpg",
      "sizes" : [ {
        "h" : 1500,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/QYgWu9qtGA"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/JvtZFKpQKZ",
      "expanded_url" : "http:\/\/go.wh.gov\/oLS3Kt",
      "display_url" : "go.wh.gov\/oLS3Kt"
    } ]
  },
  "geo" : { },
  "id_str" : "782957183679901699",
  "text" : "Artists \u2713\nCreators \u2713\nEntrepreneurs \u2713\nInnovators \u2713\n\nLearn why @POTUS is bringing #SXSL to his backyard: https:\/\/t.co\/JvtZFKpQKZ https:\/\/t.co\/QYgWu9qtGA",
  "id" : 782957183679901699,
  "created_at" : "2016-10-03 14:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kim drew",
      "screen_name" : "museummammy",
      "indices" : [ 3, 15 ],
      "id_str" : "511273965",
      "id" : 511273965
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 58, 68 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782956385445097472",
  "text" : "RT @museummammy: Today, I'm taking over the @WhiteHouse's @Instagram story for the first-ever #SXSL! Follow along here: https:\/\/t.co\/iWHd9E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 27, 38 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 41, 51 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/museummammy\/status\/782955106518110208\/video\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/PBo3pwYB03",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782953790848770048\/pu\/img\/tmadDdsHsTBOVxw4.jpg",
        "id_str" : "782953790848770048",
        "id" : 782953790848770048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782953790848770048\/pu\/img\/tmadDdsHsTBOVxw4.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/PBo3pwYB03"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/iWHd9E8i03",
        "expanded_url" : "http:\/\/instagram.com\/whitehouse",
        "display_url" : "instagram.com\/whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "782955106518110208",
    "text" : "Today, I'm taking over the @WhiteHouse's @Instagram story for the first-ever #SXSL! Follow along here: https:\/\/t.co\/iWHd9E8i03 https:\/\/t.co\/PBo3pwYB03",
    "id" : 782955106518110208,
    "created_at" : "2016-10-03 14:46:58 +0000",
    "user" : {
      "name" : "kim drew",
      "screen_name" : "museummammy",
      "protected" : false,
      "id_str" : "511273965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755198523751145472\/4ghETuTa_normal.jpg",
      "id" : 511273965,
      "verified" : false
    }
  },
  "id" : 782956385445097472,
  "created_at" : "2016-10-03 14:52:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newseum",
      "screen_name" : "Newseum",
      "indices" : [ 3, 11 ],
      "id_str" : "19781646",
      "id" : 19781646
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782951805730816001",
  "text" : "RT @Newseum: James Turrell: using light to create space wasn't a new concept, but light essentially became my medium  #SXSL https:\/\/t.co\/Wk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Newseum\/status\/782945751878033408\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Wkwyp0pnC0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2VAjzXYAAu8kM.jpg",
        "id_str" : "782945747075555328",
        "id" : 782945747075555328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2VAjzXYAAu8kM.jpg",
        "sizes" : [ {
          "h" : 759,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Wkwyp0pnC0"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 105, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782945751878033408",
    "text" : "James Turrell: using light to create space wasn't a new concept, but light essentially became my medium  #SXSL https:\/\/t.co\/Wkwyp0pnC0",
    "id" : 782945751878033408,
    "created_at" : "2016-10-03 14:09:48 +0000",
    "user" : {
      "name" : "Newseum",
      "screen_name" : "Newseum",
      "protected" : false,
      "id_str" : "19781646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740150060231630849\/GjeUE--2_normal.jpg",
      "id" : 19781646,
      "verified" : true
    }
  },
  "id" : 782951805730816001,
  "created_at" : "2016-10-03 14:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR Extra",
      "screen_name" : "NPRextra",
      "indices" : [ 3, 12 ],
      "id_str" : "14062180",
      "id" : 14062180
    }, {
      "name" : "nprmusic",
      "screen_name" : "nprmusic",
      "indices" : [ 21, 30 ],
      "id_str" : "13784592",
      "id" : 13784592
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 61, 72 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NPRextra\/status\/782947304387018753\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ujFTG2xrdm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2WawSXgAAJHPk.jpg",
      "id_str" : "782947296615038976",
      "id" : 782947296615038976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2WawSXgAAJHPk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ujFTG2xrdm"
    } ],
    "hashtags" : [ {
      "text" : "TinyDesk",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782949900392603648",
  "text" : "RT @NPRextra: What's @NPRMusic doing with a #TinyDesk at The @WhiteHouse? Stay tuned for a #SXSL reveal! https:\/\/t.co\/ujFTG2xrdm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nprmusic",
        "screen_name" : "nprmusic",
        "indices" : [ 7, 16 ],
        "id_str" : "13784592",
        "id" : 13784592
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 47, 58 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NPRextra\/status\/782947304387018753\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ujFTG2xrdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2WawSXgAAJHPk.jpg",
        "id_str" : "782947296615038976",
        "id" : 782947296615038976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2WawSXgAAJHPk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ujFTG2xrdm"
      } ],
      "hashtags" : [ {
        "text" : "TinyDesk",
        "indices" : [ 30, 39 ]
      }, {
        "text" : "SXSL",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782947304387018753",
    "text" : "What's @NPRMusic doing with a #TinyDesk at The @WhiteHouse? Stay tuned for a #SXSL reveal! https:\/\/t.co\/ujFTG2xrdm",
    "id" : 782947304387018753,
    "created_at" : "2016-10-03 14:15:58 +0000",
    "user" : {
      "name" : "NPR Extra",
      "screen_name" : "NPRextra",
      "protected" : false,
      "id_str" : "14062180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623874833068236800\/eN5WiO7i_normal.png",
      "id" : 14062180,
      "verified" : true
    }
  },
  "id" : 782949900392603648,
  "created_at" : "2016-10-03 14:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat Geo Channel",
      "screen_name" : "NatGeoChannel",
      "indices" : [ 3, 17 ],
      "id_str" : "18244358",
      "id" : 18244358
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 52, 64 ],
      "id_str" : "133880286",
      "id" : 133880286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/yCN9K74Jnj",
      "expanded_url" : "http:\/\/Wh.gov\/SXSL",
      "display_url" : "Wh.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "782947892394807296",
  "text" : "RT @NatGeoChannel: Tonight @POTUS will be joined by @LeoDiCaprio for a conversation on combating climate change: https:\/\/t.co\/yCN9K74Jnj #S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 8, 14 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Leonardo DiCaprio",
        "screen_name" : "LeoDiCaprio",
        "indices" : [ 33, 45 ],
        "id_str" : "133880286",
        "id" : 133880286
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatGeoChannel\/status\/782938260792147968\/video\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/WDNuaogsgs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2LLmzVIAAVjk-.jpg",
        "id_str" : "782930235830394880",
        "id" : 782930235830394880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2LLmzVIAAVjk-.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WDNuaogsgs"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 118, 123 ]
      }, {
        "text" : "BeforeTheFlood",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/yCN9K74Jnj",
        "expanded_url" : "http:\/\/Wh.gov\/SXSL",
        "display_url" : "Wh.gov\/SXSL"
      } ]
    },
    "geo" : { },
    "id_str" : "782938260792147968",
    "text" : "Tonight @POTUS will be joined by @LeoDiCaprio for a conversation on combating climate change: https:\/\/t.co\/yCN9K74Jnj #SXSL #BeforeTheFlood https:\/\/t.co\/WDNuaogsgs",
    "id" : 782938260792147968,
    "created_at" : "2016-10-03 13:40:02 +0000",
    "user" : {
      "name" : "Nat Geo Channel",
      "screen_name" : "NatGeoChannel",
      "protected" : false,
      "id_str" : "18244358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767771700796743680\/v5IPVvjS_normal.jpg",
      "id" : 18244358,
      "verified" : true
    }
  },
  "id" : 782947892394807296,
  "created_at" : "2016-10-03 14:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 41, 50 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Carmen Rojas, PhD",
      "screen_name" : "crojasphd",
      "indices" : [ 52, 62 ],
      "id_str" : "568412239",
      "id" : 568412239
    }, {
      "name" : "Jukay Hsu",
      "screen_name" : "JukayHsu",
      "indices" : [ 68, 77 ],
      "id_str" : "18879261",
      "id" : 18879261
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782946641120628736",
  "text" : "RT @PressSec: Looking forward to hosting @anildash, @crojasphd, and @JukayHsu at today's briefing to talk about #SXSL. https:\/\/t.co\/Td6BnUT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 27, 36 ],
        "id_str" : "36823",
        "id" : 36823
      }, {
        "name" : "Carmen Rojas, PhD",
        "screen_name" : "crojasphd",
        "indices" : [ 38, 48 ],
        "id_str" : "568412239",
        "id" : 568412239
      }, {
        "name" : "Jukay Hsu",
        "screen_name" : "JukayHsu",
        "indices" : [ 54, 63 ],
        "id_str" : "18879261",
        "id" : 18879261
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 98, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Td6BnUTLnZ",
        "expanded_url" : "http:\/\/wh.gov\/SXSL",
        "display_url" : "wh.gov\/SXSL"
      } ]
    },
    "geo" : { },
    "id_str" : "782940554992779265",
    "text" : "Looking forward to hosting @anildash, @crojasphd, and @JukayHsu at today's briefing to talk about #SXSL. https:\/\/t.co\/Td6BnUTLnZ",
    "id" : 782940554992779265,
    "created_at" : "2016-10-03 13:49:09 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 782946641120628736,
  "created_at" : "2016-10-03 14:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782938319453876224\/photo\/1",
      "indices" : [ 145, 168 ],
      "url" : "https:\/\/t.co\/a4H1koQ51v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2N1I9WgAApCLX.jpg",
      "id_str" : "782937854309728256",
      "id" : 782937854309728256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2N1I9WgAApCLX.jpg",
      "sizes" : [ {
        "h" : 714,
        "resize" : "fit",
        "w" : 1378
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1378
      }, {
        "h" : 622,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/a4H1koQ51v"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/BbvvMEaQTF",
      "expanded_url" : "http:\/\/WH.gov\/SXSL",
      "display_url" : "WH.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "782938319453876224",
  "text" : "Tune in at 9:45am ET as we kick off #SXSL with a conversation between artist James Turrell &amp; architect David Adjaye: https:\/\/t.co\/BbvvMEaQTF https:\/\/t.co\/a4H1koQ51v",
  "id" : 782938319453876224,
  "created_at" : "2016-10-03 13:40:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782936082564251648\/photo\/1",
      "indices" : [ 126, 149 ],
      "url" : "https:\/\/t.co\/jZVuuMAs7k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct2L3pOVIAAALU-.jpg",
      "id_str" : "782935698307358720",
      "id" : 782935698307358720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct2L3pOVIAAALU-.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/jZVuuMAs7k"
    } ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/1Gk8VZAaFi",
      "expanded_url" : "http:\/\/wh.gov\/SXSL",
      "display_url" : "wh.gov\/SXSL"
    } ]
  },
  "geo" : { },
  "id_str" : "782936082564251648",
  "text" : "We're making the final touches to the South Lawn! Get all the details and full schedule for #SXSL at https:\/\/t.co\/1Gk8VZAaFi. https:\/\/t.co\/jZVuuMAs7k",
  "id" : 782936082564251648,
  "created_at" : "2016-10-03 13:31:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RyderCup",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782782299368595457",
  "text" : "RT @POTUS: What a win by the USA in #RyderCup. Proud to see our guys bring the trophy back home. Arnie is smiling down.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RyderCup",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782762238616727552",
    "text" : "What a win by the USA in #RyderCup. Proud to see our guys bring the trophy back home. Arnie is smiling down.",
    "id" : 782762238616727552,
    "created_at" : "2016-10-03 02:00:35 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 782782299368595457,
  "created_at" : "2016-10-03 03:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Magazine",
      "screen_name" : "NYMag",
      "indices" : [ 3, 9 ],
      "id_str" : "45564482",
      "id" : 45564482
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NYMag\/status\/782747353941942277\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/5oDOFlgvSy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtzgkYTWAAAnEg3.jpg",
      "id_str" : "782747350859120640",
      "id" : 782747350859120640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtzgkYTWAAAnEg3.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 895
      }, {
        "h" : 1575,
        "resize" : "fit",
        "w" : 1175
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1575,
        "resize" : "fit",
        "w" : 1175
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/5oDOFlgvSy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/5zo6RQpxrg",
      "expanded_url" : "http:\/\/nym.ag\/2djtLNa",
      "display_url" : "nym.ag\/2djtLNa"
    } ]
  },
  "geo" : { },
  "id_str" : "782755750389149696",
  "text" : "RT @NYMag: New this issue: Hope, and what came after, by @POTUS. https:\/\/t.co\/5zo6RQpxrg https:\/\/t.co\/5oDOFlgvSy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 46, 52 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NYMag\/status\/782747353941942277\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/5oDOFlgvSy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtzgkYTWAAAnEg3.jpg",
        "id_str" : "782747350859120640",
        "id" : 782747350859120640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtzgkYTWAAAnEg3.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 1575,
          "resize" : "fit",
          "w" : 1175
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1575,
          "resize" : "fit",
          "w" : 1175
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 507
        } ],
        "display_url" : "pic.twitter.com\/5oDOFlgvSy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/5zo6RQpxrg",
        "expanded_url" : "http:\/\/nym.ag\/2djtLNa",
        "display_url" : "nym.ag\/2djtLNa"
      } ]
    },
    "geo" : { },
    "id_str" : "782747353941942277",
    "text" : "New this issue: Hope, and what came after, by @POTUS. https:\/\/t.co\/5zo6RQpxrg https:\/\/t.co\/5oDOFlgvSy",
    "id" : 782747353941942277,
    "created_at" : "2016-10-03 01:01:26 +0000",
    "user" : {
      "name" : "New York Magazine",
      "screen_name" : "NYMag",
      "protected" : false,
      "id_str" : "45564482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2939680330\/56f025f0104892f84a84c00bdb4ec812_normal.png",
      "id" : 45564482,
      "verified" : true
    }
  },
  "id" : 782755750389149696,
  "created_at" : "2016-10-03 01:34:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "indices" : [ 3, 15 ],
      "id_str" : "15661871",
      "id" : 15661871
    }, {
      "name" : "Digital Harbor Fdn",
      "screen_name" : "DHFBaltimore",
      "indices" : [ 24, 37 ],
      "id_str" : "333585533",
      "id" : 333585533
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 114, 125 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782735329891487744",
  "text" : "RT @donttrythis: I'm at @DHFBaltimore w\/50 amazing kids, assembling something SPECTACULAR for tomorrow's #SXSL at @whitehouse. Check it out\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Digital Harbor Fdn",
        "screen_name" : "DHFBaltimore",
        "indices" : [ 7, 20 ],
        "id_str" : "333585533",
        "id" : 333585533
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 97, 108 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/donttrythis\/status\/782732136314867712\/video\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/8vfcbT4oNr",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782731191690461184\/pu\/img\/KpFIe-TOx9za0diR.jpg",
        "id_str" : "782731191690461184",
        "id" : 782731191690461184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/782731191690461184\/pu\/img\/KpFIe-TOx9za0diR.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8vfcbT4oNr"
      } ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 88, 93 ]
      }, {
        "text" : "NationofMakers",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782732136314867712",
    "text" : "I'm at @DHFBaltimore w\/50 amazing kids, assembling something SPECTACULAR for tomorrow's #SXSL at @whitehouse. Check it out! #NationofMakers https:\/\/t.co\/8vfcbT4oNr",
    "id" : 782732136314867712,
    "created_at" : "2016-10-03 00:00:58 +0000",
    "user" : {
      "name" : "Adam Savage",
      "screen_name" : "donttrythis",
      "protected" : false,
      "id_str" : "15661871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458749057985282048\/cre48Dcf_normal.jpeg",
      "id" : 15661871,
      "verified" : true
    }
  },
  "id" : 782735329891487744,
  "created_at" : "2016-10-03 00:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AFI",
      "screen_name" : "AmericanFilm",
      "indices" : [ 3, 16 ],
      "id_str" : "24254832",
      "id" : 24254832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/LGyle1zXlB",
      "expanded_url" : "http:\/\/bit.ly\/2diCM93",
      "display_url" : "bit.ly\/2diCM93"
    } ]
  },
  "geo" : { },
  "id_str" : "782681481097285634",
  "text" : "RT @AmericanFilm: Watch ALL of the finalists &amp; honorable mentions in the 2016 #WHFilmFest right here: https:\/\/t.co\/LGyle1zXlB https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmericanFilm\/status\/782656452615770113\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/58byHfzcVF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtyN5OcXgAA9xab.jpg",
        "id_str" : "782656449524760576",
        "id" : 782656449524760576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtyN5OcXgAA9xab.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1099
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1099
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1099
        } ],
        "display_url" : "pic.twitter.com\/58byHfzcVF"
      } ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 64, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/LGyle1zXlB",
        "expanded_url" : "http:\/\/bit.ly\/2diCM93",
        "display_url" : "bit.ly\/2diCM93"
      } ]
    },
    "geo" : { },
    "id_str" : "782656452615770113",
    "text" : "Watch ALL of the finalists &amp; honorable mentions in the 2016 #WHFilmFest right here: https:\/\/t.co\/LGyle1zXlB https:\/\/t.co\/58byHfzcVF",
    "id" : 782656452615770113,
    "created_at" : "2016-10-02 19:00:14 +0000",
    "user" : {
      "name" : "AFI",
      "screen_name" : "AmericanFilm",
      "protected" : false,
      "id_str" : "24254832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540945210235031552\/fBxxwEiy_normal.png",
      "id" : 24254832,
      "verified" : true
    }
  },
  "id" : 782681481097285634,
  "created_at" : "2016-10-02 20:39:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RoshHashanah",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/UqhVjRB2kb",
      "expanded_url" : "http:\/\/go.wh.gov\/Qdp8bf",
      "display_url" : "go.wh.gov\/Qdp8bf"
    }, {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/pio7Tg5smh",
      "expanded_url" : "http:\/\/snpy.tv\/2dxNWq9",
      "display_url" : "snpy.tv\/2dxNWq9"
    } ]
  },
  "geo" : { },
  "id_str" : "782675320285585409",
  "text" : "Shanah Tovah! Wishing a sweet &amp; healthy new year to all of those celebrating #RoshHashanah: https:\/\/t.co\/UqhVjRB2kb https:\/\/t.co\/pio7Tg5smh",
  "id" : 782675320285585409,
  "created_at" : "2016-10-02 20:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stranger Things",
      "screen_name" : "Stranger_Things",
      "indices" : [ 1, 17 ],
      "id_str" : "3320478908",
      "id" : 3320478908
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782648869788135424\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/b0cqyMcHC1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtyGx9_UkAASq6Z.jpg",
      "id_str" : "782648628267487232",
      "id" : 782648628267487232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtyGx9_UkAASq6Z.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 929
      } ],
      "display_url" : "pic.twitter.com\/b0cqyMcHC1"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 60, 71 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/eZwdRbEJQc",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "782648869788135424",
  "text" : ".@Stranger_Things creators Matt and Ross Duffer drop by the #WHFilmFest\u2014tune in: https:\/\/t.co\/eZwdRbEJQc #SXSL https:\/\/t.co\/b0cqyMcHC1",
  "id" : 782648869788135424,
  "created_at" : "2016-10-02 18:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782627871969845248",
  "text" : "RT @WHLive: Happening now: Tune in for the 3rd annual #WHFilmFest featuring student filmmakers from across the country: https:\/\/t.co\/AfRoD9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/782627786087202816\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/q4o4BC9tUc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxyAltUEAAM_YV.jpg",
        "id_str" : "782625789703360512",
        "id" : 782625789703360512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxyAltUEAAM_YV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1099
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1099
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1099
        } ],
        "display_url" : "pic.twitter.com\/q4o4BC9tUc"
      } ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/AfRoD9YPvw",
        "expanded_url" : "http:\/\/wh.gov\/FilmFest",
        "display_url" : "wh.gov\/FilmFest"
      } ]
    },
    "geo" : { },
    "id_str" : "782627786087202816",
    "text" : "Happening now: Tune in for the 3rd annual #WHFilmFest featuring student filmmakers from across the country: https:\/\/t.co\/AfRoD9YPvw https:\/\/t.co\/q4o4BC9tUc",
    "id" : 782627786087202816,
    "created_at" : "2016-10-02 17:06:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 782627871969845248,
  "created_at" : "2016-10-02 17:06:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "indices" : [ 3, 16 ],
      "id_str" : "18839785",
      "id" : 18839785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782627157314985984",
  "text" : "RT @narendramodi: Care &amp; concern towards nature is integral to the Indian ethos. India is committed to doing everything possible to mitigat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/cKLlIu2J7S",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/782594690738597888",
        "display_url" : "twitter.com\/potus\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782622679538860032",
    "text" : "Care &amp; concern towards nature is integral to the Indian ethos. India is committed to doing everything possible to mitigate climate change. https:\/\/t.co\/cKLlIu2J7S",
    "id" : 782622679538860032,
    "created_at" : "2016-10-02 16:46:01 +0000",
    "user" : {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "protected" : false,
      "id_str" : "18839785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718314968102367232\/ypY1GPCQ_normal.jpg",
      "id" : 18839785,
      "verified" : true
    }
  },
  "id" : 782627157314985984,
  "created_at" : "2016-10-02 17:03:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stranger Things",
      "screen_name" : "Stranger_Things",
      "indices" : [ 6, 22 ],
      "id_str" : "3320478908",
      "id" : 3320478908
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782622425305329664\/photo\/1",
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/1HhqZIJFYg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxoETWWgAU8CCu.jpg",
      "id_str" : "782614858378412037",
      "id" : 782614858378412037,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxoETWWgAU8CCu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1HhqZIJFYg"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/jEOCgtcm8s",
      "expanded_url" : "http:\/\/wh.gov\/filmfest",
      "display_url" : "wh.gov\/filmfest"
    } ]
  },
  "geo" : { },
  "id_str" : "782622425305329664",
  "text" : "Today @Stranger_Things cast, creators and executive producers join us for the 3rd annual #WHFilmFest. Tune in: https:\/\/t.co\/jEOCgtcm8s https:\/\/t.co\/1HhqZIJFYg",
  "id" : 782622425305329664,
  "created_at" : "2016-10-02 16:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stranger Things",
      "screen_name" : "Stranger_Things",
      "indices" : [ 65, 81 ],
      "id_str" : "3320478908",
      "id" : 3320478908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/69bPGl9fzk",
      "expanded_url" : "http:\/\/go.wh.gov\/67Yyhb",
      "display_url" : "go.wh.gov\/67Yyhb"
    } ]
  },
  "geo" : { },
  "id_str" : "782616132918345736",
  "text" : "\u201CThis is the coolest film festival, hands-down.\u201D The creators of @Stranger_Things kick off the #WHFilmFest: https:\/\/t.co\/69bPGl9fzk",
  "id" : 782616132918345736,
  "created_at" : "2016-10-02 16:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782611372370722817\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/ihiCcdBXhA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctxk1NlUsAEpYUe.jpg",
      "id_str" : "782611300597673985",
      "id" : 782611300597673985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctxk1NlUsAEpYUe.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ihiCcdBXhA"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/eZwdRbn8YE",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "782611372370722817",
  "text" : "We're rolling out the red carpet today for the #WHFilmFest, featuring short films from students across the country: https:\/\/t.co\/eZwdRbn8YE https:\/\/t.co\/ihiCcdBXhA",
  "id" : 782611372370722817,
  "created_at" : "2016-10-02 16:01:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSL",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782605473627328512",
  "text" : "RT @Goldman44: It's finally here! #SXSL starts today with the 3rd Annual White House Student Film Festival. Tune in starting at 1p: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SXSL",
        "indices" : [ 19, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/4NXzghphNe",
        "expanded_url" : "https:\/\/www.wh.gov\/filmfest",
        "display_url" : "wh.gov\/filmfest"
      } ]
    },
    "geo" : { },
    "id_str" : "782602849867792388",
    "text" : "It's finally here! #SXSL starts today with the 3rd Annual White House Student Film Festival. Tune in starting at 1p: https:\/\/t.co\/4NXzghphNe",
    "id" : 782602849867792388,
    "created_at" : "2016-10-02 15:27:14 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 782605473627328512,
  "created_at" : "2016-10-02 15:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782603716713074689\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/asuOEtXYkY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxdVDnUIAEkCue.jpg",
      "id_str" : "782603051584462849",
      "id" : 782603051584462849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxdVDnUIAEkCue.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/asuOEtXYkY"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "SXSL",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/YWRdEl9V0U",
      "expanded_url" : "https:\/\/www.wh.gov\/filmfest",
      "display_url" : "wh.gov\/filmfest"
    } ]
  },
  "geo" : { },
  "id_str" : "782603716713074689",
  "text" : "Lights, camera, action! \nTune in to the 3rd annual #WHFilmFest today at 1pm ET \uD83C\uDFA5: https:\/\/t.co\/YWRdEl9V0U #SXSL https:\/\/t.co\/asuOEtXYkY",
  "id" : 782603716713074689,
  "created_at" : "2016-10-02 15:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "indices" : [ 96, 109 ],
      "id_str" : "18839785",
      "id" : 18839785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782595987252445185",
  "text" : "RT @POTUS: Gandhiji believed in a world worthy of our children. In joining the Paris Agreement, @narendramodi &amp; the Indian people carry on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Narendra Modi",
        "screen_name" : "narendramodi",
        "indices" : [ 85, 98 ],
        "id_str" : "18839785",
        "id" : 18839785
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782594690738597888",
    "text" : "Gandhiji believed in a world worthy of our children. In joining the Paris Agreement, @narendramodi &amp; the Indian people carry on that legacy.",
    "id" : 782594690738597888,
    "created_at" : "2016-10-02 14:54:48 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 782595987252445185,
  "created_at" : "2016-10-02 14:59:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PaidSickLeave",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/AyQ4ohsUhg",
      "expanded_url" : "http:\/\/go.wh.gov\/QfeifZ",
      "display_url" : "go.wh.gov\/QfeifZ"
    } ]
  },
  "geo" : { },
  "id_str" : "782552020293132288",
  "text" : "This week, @POTUS addresses the nation on the importance of #PaidSickLeave for working families: https:\/\/t.co\/AyQ4ohsUhg",
  "id" : 782552020293132288,
  "created_at" : "2016-10-02 12:05:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/AyQ4ohbiSG",
      "expanded_url" : "http:\/\/go.wh.gov\/QfeifZ",
      "display_url" : "go.wh.gov\/QfeifZ"
    } ]
  },
  "geo" : { },
  "id_str" : "782286806335098881",
  "text" : "\u201CLast year, the typical household saw its income grow by about $2800\u2014the biggest one-year increase ever.\u201D \u2014@POTUS https:\/\/t.co\/AyQ4ohbiSG",
  "id" : 782286806335098881,
  "created_at" : "2016-10-01 18:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Garibaldi",
      "screen_name" : "garibaldiarts",
      "indices" : [ 3, 17 ],
      "id_str" : "25614782",
      "id" : 25614782
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/9a4S8ond48",
      "expanded_url" : "https:\/\/garibaldiarts.com\/performing-at-the-white-house-sxsl\/",
      "display_url" : "garibaldiarts.com\/performing-at-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782276209493192704",
  "text" : "RT @garibaldiarts: Yes... Excited to be performing at the @WhiteHouse October 3rd!  All info can be found here: https:\/\/t.co\/9a4S8ond48 #sx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 39, 50 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/garibaldiarts\/status\/780509009904369664\/video\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/BvOjPlUvyR",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780508930539651072\/pu\/img\/3xBs92YppURtI5rx.jpg",
        "id_str" : "780508930539651072",
        "id" : 780508930539651072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780508930539651072\/pu\/img\/3xBs92YppURtI5rx.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BvOjPlUvyR"
      } ],
      "hashtags" : [ {
        "text" : "sxsl",
        "indices" : [ 117, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/9a4S8ond48",
        "expanded_url" : "https:\/\/garibaldiarts.com\/performing-at-the-white-house-sxsl\/",
        "display_url" : "garibaldiarts.com\/performing-at-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780509009904369664",
    "text" : "Yes... Excited to be performing at the @WhiteHouse October 3rd!  All info can be found here: https:\/\/t.co\/9a4S8ond48 #sxsl https:\/\/t.co\/BvOjPlUvyR",
    "id" : 780509009904369664,
    "created_at" : "2016-09-26 20:47:03 +0000",
    "user" : {
      "name" : "David Garibaldi",
      "screen_name" : "garibaldiarts",
      "protected" : false,
      "id_str" : "25614782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634782131273633792\/7hQWI4Ii_normal.jpg",
      "id" : 25614782,
      "verified" : true
    }
  },
  "id" : 782276209493192704,
  "created_at" : "2016-10-01 17:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 50, 56 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782272812908240896\/photo\/1",
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/RG7uPxG5Km",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctsw77vVUAA157j.jpg",
      "id_str" : "782272766485549056",
      "id" : 782272766485549056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctsw77vVUAA157j.jpg",
      "sizes" : [ {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/RG7uPxG5Km"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gfWDBtQX1L",
      "expanded_url" : "http:\/\/FAFSA.gov",
      "display_url" : "FAFSA.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "782272812908240896",
  "text" : "Don\u2019t leave any money on the table. Fill out your @FAFSA starting today and get free money for college: https:\/\/t.co\/gfWDBtQX1L https:\/\/t.co\/RG7uPxG5Km",
  "id" : 782272812908240896,
  "created_at" : "2016-10-01 17:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/AyQ4ohsUhg",
      "expanded_url" : "http:\/\/go.wh.gov\/QfeifZ",
      "display_url" : "go.wh.gov\/QfeifZ"
    } ]
  },
  "geo" : { },
  "id_str" : "782263672747986944",
  "text" : "\u201CPaid sick leave isn\u2019t a side issue, or a women\u2019s issue...It\u2019s a must-have\u201D \u2014@POTUS on why we need to #LeadOnLeave: https:\/\/t.co\/AyQ4ohsUhg",
  "id" : 782263672747986944,
  "created_at" : "2016-10-01 16:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 53, 59 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/782256189765722112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kEoTjQe3un",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtshzSfVMAEhBD6.jpg",
      "id_str" : "782256125299208193",
      "id" : 782256125299208193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtshzSfVMAEhBD6.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/kEoTjQe3un"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/gfWDBtQX1L",
      "expanded_url" : "http:\/\/FAFSA.gov",
      "display_url" : "FAFSA.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "782256189765722112",
  "text" : "Parents and students: today\u2019s the day! Fill out your @FAFSA to get free money for college \u2192 https:\/\/t.co\/gfWDBtQX1L https:\/\/t.co\/kEoTjQe3un",
  "id" : 782256189765722112,
  "created_at" : "2016-10-01 16:29:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PaidSickLeave",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/AyQ4ohsUhg",
      "expanded_url" : "http:\/\/go.wh.gov\/QfeifZ",
      "display_url" : "go.wh.gov\/QfeifZ"
    } ]
  },
  "geo" : { },
  "id_str" : "782231376158400512",
  "text" : "No one should have to choose between their job &amp; their health. Here's how @POTUS is taking action on #PaidSickLeave: https:\/\/t.co\/AyQ4ohsUhg",
  "id" : 782231376158400512,
  "created_at" : "2016-10-01 14:51:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/AyQ4ohbiSG",
      "expanded_url" : "http:\/\/go.wh.gov\/QfeifZ",
      "display_url" : "go.wh.gov\/QfeifZ"
    } ]
  },
  "geo" : { },
  "id_str" : "782221449981333504",
  "text" : "\u201CRight now, millions of Americans don\u2019t have access to even a single day of paid sick leave.\u201D \u2014@POTUS: https:\/\/t.co\/AyQ4ohbiSG",
  "id" : 782221449981333504,
  "created_at" : "2016-10-01 14:11:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782219378226032640",
  "text" : "RT @POTUS: Paid leave shouldn't be a luxury. It's a basic necessity that we should secure for every working American. https:\/\/t.co\/OPeQiVPJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/OPeQiVPJlK",
        "expanded_url" : "http:\/\/nyti.ms\/2cIsldp",
        "display_url" : "nyti.ms\/2cIsldp"
      } ]
    },
    "geo" : { },
    "id_str" : "782218662228942848",
    "text" : "Paid leave shouldn't be a luxury. It's a basic necessity that we should secure for every working American. https:\/\/t.co\/OPeQiVPJlK",
    "id" : 782218662228942848,
    "created_at" : "2016-10-01 14:00:36 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 782219378226032640,
  "created_at" : "2016-10-01 14:03:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]