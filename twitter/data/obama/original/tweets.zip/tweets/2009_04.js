Grailbird.data.tweets_2009_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1670203165",
  "text" : "Welcome to the official Twitter page for the White House!",
  "id" : 1670203165,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC Emergency",
      "screen_name" : "CDCemergency",
      "indices" : [ 43, 56 ],
      "id_str" : "19658936",
      "id" : 19658936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1670232301",
  "text" : "Check out the CDC website (www.cdc.gov) or @CDCemergency to learn more about H1N1 flu (swine flu), as well as prevention tips.",
  "id" : 1670232301,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC_eHealth",
      "screen_name" : "CDC_eHealth",
      "indices" : [ 3, 15 ],
      "id_str" : "15587500",
      "id" : 15587500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1670337417",
  "text" : "RT @CDC_eHealth Check out CDC's new webpage highlighting several new social media tools developed for swine flu. http:\/\/is.gd\/vfHZ",
  "id" : 1670337417,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1670926411",
  "text" : "Shooting Around With the Huskies: The President shot a few hoops with the undefeated women's basketball national.. http:\/\/tinyurl.com\/c2qo7x",
  "id" : 1670926411,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1671794059",
  "text" : "WhiteHouse 2.0: Today the White House is taking steps to expand how the Administration is communicating with the.. http:\/\/tinyurl.com\/djh4d5",
  "id" : 1671794059,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1673282363",
  "text" : "The President's Remarks on Justice Souter: The President made an appearance at today's press briefing to discuss.. http:\/\/tinyurl.com\/dyl7r2",
  "id" : 1673282363,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC_eHealth",
      "screen_name" : "CDC_eHealth",
      "indices" : [ 3, 15 ],
      "id_str" : "15587500",
      "id" : 15587500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1673410611",
  "text" : "RT @CDC_eHealth Add a graphic with flu prevention messages to your webpage. Help spread the word about H1N1 (Swine Flu): http:\/\/is.gd\/vXN6",
  "id" : 1673410611,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1674138668",
  "text" : "RT @DHSJournal: Press Briefing VIDEO: Homeland Security Sec Napolitano & Education Sec Duncan on H1N1 flu outbreak.  http:\/\/bit.ly\/pWGRQ",
  "id" : 1674138668,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC_eHealth",
      "screen_name" : "CDC_eHealth",
      "indices" : [ 3, 15 ],
      "id_str" : "15587500",
      "id" : 15587500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1674140972",
  "text" : "RT @CDC_eHealth: New CDC widget - Tips for preventing H1N1 (Swine Flu). Add it to your webpage\/blog today! http:\/\/bit.ly\/smgFi",
  "id" : 1674140972,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]